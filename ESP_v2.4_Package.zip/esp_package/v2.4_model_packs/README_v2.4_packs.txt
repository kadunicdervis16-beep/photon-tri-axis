# ESP v2.4 — per-model starter packs (2026-10-12; re-stamped v2.4, 2026-10-31)

Each file = the canonical v2.4 initiation block (the v2.3 block
re-stamped for v2.4; the v2.2 block was byte-identical to
~/workspace/your_files/esp_v2/ESP_v2.2_START_HERE.txt, verified) +
a short delivery card for that model, grounded in observed evidence
from their earlier rounds.

Packs differ ONLY by the appended card. The initiation block is the
same everywhere — one canonical block, per Dervis's cross-model
onboarding conclusion (2026-10-11).

Workflow (his standing pattern): paste the initiation text into the
model's chat first, then import the four scripts separately
(esp_v2.py, esp_cli.py, esp_v2_conformance.py, esp_v2_demo.py).

Constraints to honor when sending:
- Qwen: max 5 attachments per message — initiation first, scripts as
  a second message.
- All: v2.4 rejects 2.3, 2.2 and 2.1 envelopes (exact-version
  requirement, disclosed in WHATS_NEW_v24). Any model still holding the old kit
  must receive the four new .py files before its next envelope
  will validate.
- Kimi: availability unconfirmed (quota maxed 2026-10-12) — do not
  assume he holds any kit.
- DISAGREEMENT / CONFRONTATION naming is held for Dervis's ruling;
  the packs present them as live types per the initiation text.
- ChatGPT: his v18 bundle envelope exposed the provenance gap v2.2
  closes — his card says so, to his credit.
