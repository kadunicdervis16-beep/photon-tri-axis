# ESP v2.4 — PACKAGE README

Epistemic Swarm Protocol (ESP) v2.4 — an agent-to-agent
communication protocol by Dervis Kadunic.
Standalone package for Paper 12, "The Aggregated Ledger."
Built 2026-10-31 from the ESP v2.3 package, whose engine is the
Paper 11.5 v26 canonical build (published ESP v2.2 package:
Zenodo DOI 10.5281/zenodo.23628524). The v2.3 package is untouched
and remains in place beside this one.

## What changed in v2.4 (the complete delta)

One envelope-schema change, plus its supporting plumbing:

- `payload.provenance` gains an OPTIONAL field,
  `bundle_manifest_hash`: the SHA-256 of a bundle's
  MANIFEST.sha256, carried as 64 lowercase hex chars.
  Absent → behavior identical to v2.3. Present at the chat
  tier → the validator checks the SHAPE only and does NOT
  claim the named bundle exists. Present at the machine tier
  with a bundle supplied alongside the envelope (the
  validator's `bundle_manifest_path`, or the CLI's
  `--bundle-manifest`) → the validator computes the SHA-256
  of the bundle's MANIFEST.sha256 and compares: mismatch →
  REJECTED; match → VALIDATED with the bundle check noted in
  the checks list. Mixed tier (one of `content_hash` /
  `envelope_hash` blank, the other present) is treated like
  the machine tier for this comparison: with a bundle supplied
  it is computed and compared; with no bundle supplied it is
  shape-only, recorded as
  `bundle_manifest_hash:shape-only-no-bundle-supplied`. Only
  the chat tier (both hashes blank) is shape-only regardless
  of whether a bundle is supplied. Forged, non-hex, or wrong-length values are
  REJECTED in every tier. `make_message` gains the matching
  optional parameter. Full rule: the bundle_manifest_hash
  bullet in the Honesty rules section below, and design
  decision 23 in the engine docstring.
- `VERSION` is `"2.4"`. The exact-version gate is unchanged in
  kind — fail-closed, no negotiation — so v2.3-stamped
  envelopes are REJECTED by this engine, exactly as v2.2
  envelopes were under v2.3. Re-stamp and resend.
- One decisions-log entry (decision 23) appended in the engine
  docstring recording this change.
- `esp_cli.py`: gains `--bundle-manifest` and a plain-language
  WHY_MAP entry for the new rejection; its presenter-never-fixer
  trust boundary is unchanged.
- `DEMO_REGISTRY_HASH`: value and seed logic **unchanged**
  from v2.3.
- Nothing else in the engine changes: no lineage change, no
  firewall or static-check change. All user-facing documents
  are re-stamped 2.3 → 2.4 where they name the current engine
  version; historical mentions of v2.3 stay as written.

## What it is

ESP is a JSON envelope format plus a Python validator. Two AI
agents exchange messages as envelopes; the engine checks each
envelope for well-formedness, honest badging (provenance,
capability, hashes), and lexical discipline. It does NOT judge
whether a claim inside an envelope is true — it judges whether
the message is honestly and correctly presented. Envelopes come
in two completeness tiers (working / archival) under one schema.

## Files

Engine and battery:

- `esp_v2.py` — the validator engine (283-case build;
  sha256 85742e9fd35ae03f32ca4dc255f1893d5b27823696740af5a9f695953351e9d2)
- `esp_v2_conformance.py` — the conformance battery (283 cases:
  v2.3's 270 carried, version needles re-pointed at 2.4, plus
  section 26 with thirteen bundle_manifest_hash cases —
  `bundle-manifest-hash-chat-shape-valid`,
  `bundle-manifest-hash-chat-no-existence-claim`,
  `bundle-manifest-hash-forged-nonhex-rejected`,
  `bundle-manifest-hash-wrong-length-rejected`,
  `bundle-manifest-hash-machine-match-validated`,
  `bundle-manifest-hash-machine-mismatch-rejected`,
  `bundle-manifest-hash-machine-no-bundle-shape-only`,
  `bundle-manifest-hash-absent-unchanged`,
  `bundle-manifest-hash-zip-match-and-mismatch`,
  `bundle-manifest-hash-bare-manifest-match-validated`,
  `bundle-manifest-hash-uppercase-hex-rejected`,
  `bundle-manifest-hash-mixed-tier-bundle-match-validated`,
  `bundle-manifest-hash-mixed-tier-no-bundle-shape-only`)
- `esp_cli.py` — command-line validator for envelope files
  (v2.4: gains `--bundle-manifest`; otherwise as v2.3)
- `fixtures/` — sample Paper 11.5 excerpts used by the battery
  (unchanged; the fixture filenames carry paper versions)

User-facing documents:

- `ESP_v2.4_START_HERE.txt` — the initiation block: paste the
  whole file into an AI chat to start an ESP v2.4 exchange
- `READ_ME_FIRST_v24.txt` — orientation: what ESP does and
  does not do, and the reading paths
- `esp_v2.4_COMPENDIUM.txt` — code-free master compendium: the
  whole kit as plain text, for chat interfaces that accept
  neither zips nor .py files
- `esp_v2.4_WHATS_NEW.txt` — the v2.4 entry (the delta above),
  with the v2.3 and v2.2 entries preserved below it as the
  historical record
- `esp_v2_chat_kit.txt` — how to talk agent-to-agent in a chat
  window (preamble + envelope shape)
- `v2.4_model_packs/` — per-model starter packs: the canonical
  initiation block plus a short delivery card per model
  (ChatGPT, DeepSeek, Grok, Kimi, Qwen; a Claude pack is
  included, still marked DRAFT and unfinished, re-stamped
  as-is)

## How to run

Python 3, standard library only. From this folder:

- Conformance battery (expect 283/283, exit code 0):
  `python3 esp_v2_conformance.py`
- Engine selftest:
  `python3 esp_v2.py selftest`
- Validate envelope files with the CLI:
  `python3 esp_cli.py validate <file> [file ...]`
  (see: `python3 esp_cli.py --help`)
- Validate an envelope against a bundle supplied alongside it:
  `python3 esp_cli.py validate --bundle-manifest <bundle-dir|.zip|MANIFEST.sha256> <file>`
- Verify this package against its manifest:
  `sha256sum -c MANIFEST.sha256`

## Honesty rules (the point of the protocol)

- Chat tier: hash fields may be left blank ("computed-locally")
  — a blank hash is honest. A FORGED hex hash (typed, invented,
  not actually computed) is REJECTED.
- Disclosed inability PASSES; fabricated capability FAILS.
  Saying "I cannot compute hashes in this chat" is compliant;
  claiming a capability you do not have is not.
- The machine tier verifies hashes strictly. Machine-tier
  checking is corruption detection — it is not tamper-evidence
  against a competent attacker, and ESP does not claim it is.
- bundle_manifest_hash (NEW in v2.4): the optional
  `payload.provenance.bundle_manifest_hash` field names the
  SHA-256 of a bundle's MANIFEST.sha256. Chat tier: the
  validator checks the SHAPE only (64 lowercase hex chars;
  anything else is REJECTED) and does NOT claim the named
  bundle exists. Machine tier with the bundle supplied
  alongside the envelope: the validator computes the SHA-256
  of the bundle's MANIFEST.sha256 and compares — mismatch is
  REJECTED, match is VALIDATED with the bundle check noted.
  Machine tier with no bundle supplied: shape only, recorded
  as such — no verification is claimed. Mixed tier (one of
  `content_hash` / `envelope_hash` blank, the other present)
  is treated like the machine tier for this comparison: with
  a bundle supplied alongside, the digest is computed and
  compared (match → VALIDATED with
  `bundle_manifest_hash:verified-against-bundle-manifest`;
  mismatch → REJECTED); with no bundle supplied, shape only,
  recorded as `bundle_manifest_hash:shape-only-no-bundle-supplied`.
  This compares the digest of the bundle's MANIFEST.sha256 file; it does not verify the bundle's contents against that manifest (that is the manifest's own sha256sum -c step).
- ESP does NOT authenticate senders. A valid envelope proves
  the envelope is well-formed and honestly badged, not who
  sent it.
- Exact-version gate: this engine accepts v2.4 envelopes
  only. Envelopes stamped with earlier versions (2.3, 2.2,
  2.1, 2.0.x) are rejected by design.
