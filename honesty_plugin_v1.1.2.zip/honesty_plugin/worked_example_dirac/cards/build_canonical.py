#!/usr/bin/env python3
"""Build the adjudicated canonical card set for the Dirac worked example.

Coordinator adjudication under FREEZE v1.1 Annex §A3.3: every canonical card
is one carder's card taken as base (verbatim), with the field-level changes
enumerated in OVERRIDES below and justified in ADJUDICATION_LOG.md. Nothing
is silently rewritten: this script + the log are the record.
"""
import copy
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
A = {c["card_id"]: c for c in json.loads((HERE / "carder_A.json").read_text())["cards"]}
B = {c["card_id"]: c for c in json.loads((HERE / "carder_B.json").read_text())["cards"]}

# canonical_id -> (base_card_id, {field: ("A"|"B", source_card_id) or literal})
PLAN = [
    # ---- Dirac 1928 ----
    ("D28-01", "A-D28-01", {}),
    ("D28-02", "B-D28-02", {}),
    ("D28-03", "B-D28-03", {}),
    ("D28-04", "A-D28-03", {}),                      # layer ruling: dynamics (log L1)
    ("D28-05", "B-D28-11", {}),
    ("D28-06", "B-D28-12", {}),                      # quotation ruling: full span (log Q1)
    ("D28-07", "B-D28-05", {"premises": ("A", "A-D28-06")}),
    ("D28-08", "B-D28-06", {"freedoms": ("A", "A-D28-07"),
                            "bridges": ("B", "B-D28-06")}),
    ("D28-09", "A-D28-08", {}),
    ("D28-10", "A-D28-09", {}),
    ("D28-11", "A-D28-10", {}),
    ("D28-12", "B-D28-09", {}),
    ("D28-13", "A-D28-11", {}),
    ("D28-14", "A-D28-12", {"claim": "LITERAL:claim_d28_14"}),  # extraction-sign caution (log Q2)
    ("D28-15", "A-D28-13", {}),
    ("D28-16", "A-D28-14", {}),                      # bridge ruling: declared-as-doubted (log B2)
    ("D28-17", "A-D28-15", {"scope": ("B", "B-D28-13")}),       # layer ruling: interpretation (log L2)
    ("D28-18", "B-D28-16", {"premises": ("A", "A-D28-16")}),
    # ---- Tong QFT notes ----
    ("TNG-01", "B-TNG-01", {"bridges": ("A", "A-TNG-01")}),
    ("TNG-02", "A-TNG-02", {}),
    ("TNG-03", "B-TNG-03", {}),
    ("TNG-04", "B-TNG-04", {}),
    ("TNG-05", "A-TNG-04", {}),
    ("TNG-06", "B-TNG-05", {}),
    ("TNG-07", "B-TNG-06", {}),
    ("TNG-08", "A-TNG-05", {}),
    ("TNG-09", "B-TNG-08", {"premises": ("A", "A-TNG-06")}),
    ("TNG-10", "A-TNG-07", {}),
    ("TNG-11", "B-TNG-09", {"freedoms": ("A", "A-TNG-08")}),   # freedom ruling (log F1)
    ("TNG-12", "B-TNG-10", {"bridges": "LITERAL:empty_bridges"}),  # loop recode DA-9: an aesthetic aside is not an M3 bridge
    ("TNG-13", "A-TNG-09", {}),
    ("TNG-14", "B-TNG-12", {"bridges": ("A", "A-TNG-10")}),
    ("TNG-15", "B-TNG-13", {}),
    ("TNG-16", "A-TNG-12", {}),
    ("TNG-17", "A-TNG-13", {"era_note": "LITERAL:era_tng_17"}),  # loop correction DA-5: era note over-asserted a 1930 dating in the gloss
    ("TNG-18", "B-TNG-15", {}),
    ("TNG-19", "A-TNG-14", {}),
    ("TNG-20", "A-TNG-15", {}),
    ("TNG-21", "A-TNG-16", {}),
]

LITERALS = {
    "empty_bridges": [],
    "era_tng_17": (
        "2006/2007 Cambridge Part III lecture notes (DAMTP edition as held), a modern "
        "teaching presentation written with the completed quantum-field-theory account "
        "available to the author. As a modern gloss it receives no era shelter (Annex "
        "A4.2). The section is framed by its author as a historical detour (its opening "
        "sentence, carded at TNG-16), but the carded spans of the section print no year "
        "or paper boundary for the sea/hole material, which is Dirac's 1930-31 "
        "development, not the 1928 paper's content."
    ),
    "claim_d28_14": (
        "Dirac states that half the solutions of equation (14) must be rejected as "
        "referring to the other charge value, leaving the correct number to account "
        "for duplexity phenomena. (The held extraction reads 'the charge - e' in "
        "this sentence; both carders flagged the sign glyph as extraction-suspect "
        "against the section 1 context, and it is flagged here rather than "
        "silently corrected.)"
    ),
}

# Thematic membership: which carder cards each canonical card adjudicates.
# Used to rewrite carder-set cross-references inside card text fields to
# canonical ids (loop charge DA-21: pointers must resolve inside the set
# a reader actually holds).
MEMBERS = {
    "D28-01": ["A-D28-01", "B-D28-01"], "D28-02": ["B-D28-02"],
    "D28-03": ["B-D28-03", "A-D28-02"], "D28-04": ["A-D28-03", "B-D28-04"],
    "D28-05": ["A-D28-04", "B-D28-11"], "D28-06": ["A-D28-05", "B-D28-12"],
    "D28-07": ["A-D28-06", "B-D28-05"], "D28-08": ["A-D28-07", "B-D28-06"],
    "D28-09": ["A-D28-08", "B-D28-07"], "D28-10": ["A-D28-09", "B-D28-08"],
    "D28-11": ["A-D28-10"], "D28-12": ["B-D28-09"],
    "D28-13": ["A-D28-11", "B-D28-10"], "D28-14": ["A-D28-12", "B-D28-10"],
    "D28-15": ["A-D28-13", "B-D28-14"], "D28-16": ["A-D28-14", "B-D28-15"],
    "D28-17": ["A-D28-15", "B-D28-13"], "D28-18": ["A-D28-16", "B-D28-16"],
    "TNG-01": ["A-TNG-01", "B-TNG-01"], "TNG-02": ["A-TNG-02", "B-TNG-02"],
    "TNG-03": ["B-TNG-03"], "TNG-04": ["A-TNG-03", "B-TNG-04"],
    "TNG-05": ["A-TNG-04"], "TNG-06": ["B-TNG-05"], "TNG-07": ["B-TNG-06"],
    "TNG-08": ["A-TNG-05", "B-TNG-07"], "TNG-09": ["A-TNG-06", "B-TNG-08"],
    "TNG-10": ["A-TNG-07"], "TNG-11": ["A-TNG-08", "B-TNG-09"],
    "TNG-12": ["B-TNG-10"], "TNG-13": ["A-TNG-09", "B-TNG-11"],
    "TNG-14": ["A-TNG-10", "B-TNG-12"], "TNG-15": ["A-TNG-11", "B-TNG-13"],
    "TNG-16": ["A-TNG-12"], "TNG-17": ["A-TNG-13", "B-TNG-14"],
    "TNG-18": ["B-TNG-15"], "TNG-19": ["A-TNG-14", "B-TNG-16"],
    "TNG-20": ["A-TNG-15"], "TNG-21": ["A-TNG-16"],
}
REVERSE = {}
for canon, members in MEMBERS.items():
    for m in members:
        REVERSE.setdefault(m, canon)

import re as _re
_TOKEN = _re.compile(r"\b[AB]-(?:D28|TNG)-\d{2}\b")


def _rewrite(value):
    if isinstance(value, str):
        return _TOKEN.sub(lambda mo: REVERSE.get(mo.group(0), mo.group(0)), value)
    if isinstance(value, list):
        return [_rewrite(v) for v in value]
    if isinstance(value, dict):
        return {k: _rewrite(v) for k, v in value.items()}
    return value


pools = {"A": A, "B": B}
out = []
for new_id, base_id, overrides in PLAN:
    base = copy.deepcopy((A if base_id.startswith("A-") else B)[base_id])
    for field, spec in overrides.items():
        if isinstance(spec, str) and spec.startswith("LITERAL:"):
            base[field] = LITERALS[spec.split(":", 1)[1]]
        else:
            src, src_id = spec
            base[field] = copy.deepcopy(pools[src][src_id][field])
    base["card_id"] = new_id
    base["carder"] = "dual-carded (carder-A + carder-B); adjudicated merge"
    out.append(_rewrite(base))

doc = {
    "sources": {"dirac1928": "dirac1928.txt", "tong_qft": "tong_qft_2006_2007.txt"},
    "cards": out,
}
dest = HERE / "canonical_cards.json"
dest.write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
print(f"wrote {dest}: {len(out)} cards "
      f"({sum(1 for c in out if c['source_id']=='dirac1928')} dirac1928, "
      f"{sum(1 for c in out if c['source_id']=='tong_qft')} tong_qft)")
