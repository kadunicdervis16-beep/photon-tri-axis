# SOURCES — Dirac worked example (DEMONSTRATION scope, Annex v1.1 §A6)

Retrieval date for all files: **2026-11-08**. Carding is valid only against
the hashes below (Annex §A2.4).

## S1 — `dirac1928` — the original

- **Text:** P. A. M. Dirac, "The Quantum Theory of the Electron,"
  *Proceedings of the Royal Society of London, Series A*, Vol. 117, No. 778
  (Feb. 1, 1928), pp. 610–624. Stable URL (JSTOR): http://www.jstor.org/stable/94981
- **Held files:**
  - `dirac1928_rutgers.pdf` — the JSTOR scan of the journal issue (16 PDF
    pages: JSTOR cover + pp. 610–624 complete), retrieved from
    https://www.physics.rutgers.edu/~chakhalian/QM2020/Dirac.pdf
    sha256 `393ee5b0b7a95520e91574a6f5a4bdad1d2597942d241e8f5763c6c092305115`
  - `dirac1928.txt` — **the file as carded**: `pdftotext -layout` extraction
    of the PDF above (42,263 bytes; extraction artefacts exist — occasional
    missing spaces at column joins, e.g. "Communicatedby" — and quotes are
    taken from this extraction verbatim, so validation is consistent
    against it).
    sha256 `b684ec4c305193502585169226dcf847a4f5be2ba3ecee8f8b7913e43e29dd2a`
- **Fraction held:** the complete paper, pp. 610–624 (all sections,
  introduction through §7 and the concluding summary). Nothing is carded
  from outside these files.
- **Retrieval note:** the Royal Society's own PDF endpoint
  (royalsocietypublishing.org, DOI 10.1098/rspa.1928.0023) is behind a
  Cloudflare challenge from this environment and the Wayback Machine
  refused the archived copy as bot traffic; the Rutgers-hosted JSTOR scan
  is the held copy of the same journal text.

## S2 — `tong_qft` — the modern presentation

- **Text:** David Tong, *Quantum Field Theory* (University of Cambridge
  Part III Mathematical Tripos lecture notes, DAMTP). Carded portions:
  **the whole of Chapter 4, "The Dirac Equation"** (notes pp. 81–105;
  §§4.1–4.7 in this edition, including the plane-wave sections) and
  **§5.3, "Dirac's Hole Interpretation"** (p. 111), the chapter's own
  forward reference for the negative-energy material. (Correction,
  2026-11-08 loop pass RT-1: an earlier wording of this entry listed
  only §§4.1–4.4; the carded window was always the whole chapter, as
  the card locations show.)
- **Held file:** `tong_qft_2006_2007.txt` — full text of the notes,
  **Michaelmas Term 2006 and 2007 "hyper version" edition**, retrieved as
  the archive.org item "D TONG qft" djvu text:
  https://archive.org/download/dtongqft/D%20TONG%20qft_djvu.txt
  (269,598 bytes; the complete edition text — title page through final
  page — verified to contain the Chapter 4 body and §5.3 body.)
  sha256 `ffc727f882bc1bc17bd8ad81c774a15579c9fb7c8370189d52710369198fa350`
- **Edition caveat (stated, not hidden):** the live DAMTP PDF
  (www.damtp.cam.ac.uk/user/tong/qft/qft.pdf) closed the connection from
  the build environment on every attempt (curl exit 52, multiple user
  agents and HTTP versions; wget likewise) on 2026-11-08, so the held
  edition is the archived 2006/2007 text of Tong's own DAMTP notes rather
  than the current DAMTP revision. The run cards THIS edition and says so
  wherever its results are reported; OCR artefacts of the djvu text exist
  and quotes are taken from this file verbatim.
- Copyright: Tong's notes are his; the worked example quotes short spans
  for audit purposes only, and any shipped package carries short quotes
  only (see the Phase D package rule).
