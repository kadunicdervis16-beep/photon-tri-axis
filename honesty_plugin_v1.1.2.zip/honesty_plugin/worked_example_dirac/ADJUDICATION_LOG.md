# ADJUDICATION LOG — Dirac worked example (Annex v1.1 §A3.3)

Scope label: **DEMONSTRATION** (Annex §A6). Adjudicator: the build
coordinator (Valkyrie), with the source texts open. This log is published
with the run, disagreements included, per §A3.3.

## Inputs (sealed before adjudication)

| Set | File | sha256 | Cards | Validator on receipt |
|---|---|---|---|---|
| Carder A | `cards/carder_A.json` | `31c61e2d6210af0b63009f0673852f44a4b8468db618a9c13c34b75c00a5fded` | 32 (16 + 16) | PASS 32/32 |
| Carder B | `cards/carder_B.json` | `5af961978b7ec9b064a9be53417b11afb9338b96934c78fd63a55c119f14d570` | 32 (16 + 16) | PASS 32/32 |
| Canonical | `cards/canonical_cards.json` | `fbfb24c8046afaffc06e34386e390bbc197b9950b1322842f097515bfdecccde` | **39 (18 Dirac + 21 Tong)** | **PASS 39/39** |

The carders worked independently (identical brief; no sight of each other's
sets). The merge is mechanical-plus-ruled: `cards/build_canonical.py` takes
one carder's card as the verbatim base for each canonical card and applies
only the field overrides enumerated there; every override traces to a
ruling below.

## Convergence

Of Dirac's claims, 13 were carded by both carders (one of them — solution
count vs rejection — split differently, see Q3); 4 canonical cards rest on
a single carder (duplexity count, the "simplest Hamiltonian" promise, the
§3 invariance conclusion, the "usual procedure" substitution). Of Tong's
claims, 11 were carded by both; 10 rest on a single carder. One card was
dropped (D1). Both carders independently refused the same two anachronisms:
neither carded a positive-probability-density requirement for Dirac 1928
(the held text states the linearity requirement instead), and neither
imported the 1930 hole theory into the 1928 paper.

## Rulings

**Declared-bridge rule (B0, governs B1–B2).** A bridge counts as *declared*
only if the text states the crossing as a premise, assumption, or
interpretive step (e.g. "we can interpret this result by saying", "can be
regarded as", "we adopt the usual procedure", "put in by hand"), or the
span itself contains the comparison that constitutes the crossing — not
merely because a crossing is performed inside one sentence.

- **B1 — opening mismatch (A-D28-01 vs B-D28-01):** A marked the
  dynamics→interpretation bridge *undeclared*; B marked it *declared*.
  Ruled for **A**: the opening sentence asserts the disagreement with
  experiment as the paper's premise and locates no comparison; the located
  comparison arrives in the duplexity sentence, carded separately (D28-02,
  bridge declared, the span being the comparison itself).
- **B2 — electric-moment doubt (A-D28-14 vs B-D28-15):** A marked the
  bridge *declared* ("declared as doubtful by the author himself"); B
  marked it *undeclared* (no bridge to a physical moment is asserted).
  Ruled for **A**, with the clarification printed on the canonical card:
  the declaration axis records textual presence — a crossing the text
  takes up in order to doubt is declared-and-doubted; the doubt itself
  lives in the claim, not in the declaration flag.
- The solution-rejection bridge (D28-14) is *undeclared* under B0 (A's
  reading over B-D28-10's): the charge assignment is performed, its
  sorting premise is not stated.

**Layer disagreements.**

- **L1 — linearity in W (A-D28-03: dynamics; B-D28-04: measure).** Ruled
  **dynamics**: the claim's subject is a required property of the wave
  equation (its form). Its ground — the possibility of the general
  transformation-theory interpretation — is cross-layer support and is
  carried in the card's premises, which is where such support belongs.
- **L2 — spin sentence (A-D28-15: interpretation; B-D28-13: dynamics).**
  Ruled **interpretation**: the carded claim is the sentence whose own
  verb is "We can interpret this result by saying…". The computed
  conservation result underneath it is dynamics and is carried in
  premises/evidence.

**Quotation disagreements.**

- **Q1 — the §1 scope sentence.** A-D28-05 quoted only the tail clause
  while its claim asserted the whole sentence's content; B-D28-12 quoted
  the full continuous sentence. Ruled for **B's span** (Annex §A2.2: a
  card may not assert more than its spans support); canonical D28-06 is
  B's card.
- **Q2 — the §4 rejection sentence's charge sign.** The held extraction
  reads "referring to the charge - e" (sources/dirac1928.txt, §4). Both
  carders quoted it verbatim and flagged the glyph as extraction-suspect
  against the §1 context (the two non-combining sets "referring
  respectively to the charge - e and the charge e"). Ruled: the quote
  stands verbatim against the held file; the canonical claim (D28-14)
  names the other charge value and carries the flag in the open. The
  printed glyph is **not** resolved from the held files and is not
  silently corrected.
- **Q3 — count and rejection: one card or two.** B combined them in one
  span (B-D28-10); A split them (A-D28-11/12). Ruled for **A's split**:
  two claims, two cards (D28-13, D28-14), each supported by its own
  continuous span.

**Freedom disagreement.**

- **F1 — variation independence (Tong).** B-TNG-09 records no freedom in
  the step from action to equation; A-TNG-08 records the treatment of the
  spinor and its adjoint as independent variables as a procedural choice.
  Ruled for **A**: the independence is exercised in the step and is
  exactly the kind of invisible-when-unrecorded choice the freedoms field
  exists to catch; canonical TNG-11 carries A's entry.

**Inclusion disagreements.**

- **I1 — "It's completely gorgeous."** B carded it as an interpretation
  claim with evidence NONE (B-TNG-10); A folded it into another card's
  evidence. Ruled for **B**: the equation-entourage rule (Annex §A2.3)
  exists so that claims made *for* an equation — evaluative ones
  included — are carded, not absorbed. Canonical TNG-12 stands with
  evidence NONE, which is itself a tally-visible fact.
- **I2 — "Dirac had predicted anti-matter."** A carded it (A-TNG-15);
  B folded the sentence into another card's evidence. Ruled for **A**
  (canonical TNG-20): it is the fidelity-critical claim of §5.3 and must
  be tally-visible, not buried.

**Drops.**

- **D1 — A-D28-02 (the paper's aim sentence, p. 610) dropped** as a
  duplicate-class card: the aim ("…such that, when removed, the whole of
  the duplexity phenomena follow without arbitrary assumptions") is
  restated as an assertion in the same introduction (canonical D28-03,
  B-D28-03's span). Carding both would double-count one self-presentation
  in the tallies. The drop and its reason are recorded here; nothing else
  was dropped.

## What adjudication did not do

No quote was altered (Q2's flag rides on the claim, not the quote). No
layer outside the frozen taxonomy was introduced. No card asserts a
comparative verdict; the claim fields were re-screened against FREEZE
v1.0 §5 after the merge, and the canonical set was validated end-to-end
(PASS 39/39) on the final files.

## Post-loop addendum (2026-11-08) — corrections and disclosures

Appended after the adversarial loop pass over Phases A–C (full
adjudication: `LOOP_ADJUDICATION_v1.1.md` in the plugin root). The body
of this log is unchanged; this addendum supersedes it at the points
named.

1. **Canonical set superseded.** The canonical hash in the Inputs
   table (`fbfb24c8…`) is the pre-loop set. Under three loop rulings
   the set was rebuilt (via `cards/build_canonical.py`, whose PLAN and
   literals are the record): **DA-9** — TNG-12's bridge entry removed
   (an aesthetic aside is not a bridge under FREEZE §1's definition;
   Tong's bridges become 7 entries, 7 declared, 0 undeclared);
   **DA-5** — TNG-17's era note corrected (it had asserted that Tong
   dates the sea to 1930 in the text; the held text announces a
   historical detour but prints no year — the replacement note says
   exactly that); **DA-21** — carder-set cross-references inside card
   text fields rewritten to canonical ids via the thematic-membership
   map, so every pointer resolves inside the set a reader holds. New
   canonical sha256:
   `0c24b3f1e942917e70e1d7137d2cf84b1b82a1b27db8d18bc71f96c3b220c3f9`,
   re-validated PASS 39/39 on the final files.
2. **Selection was brief-steered; drafting was independent (RT-2).**
   The Convergence section above says "identical brief" without
   naming what the brief contained: both carders received the same
   commissioning brief **including its coverage list** (claim topics
   to cover per source). Claim *selection* was therefore steered by
   shared context beyond Annex §A3.1's enumeration ("no shared context
   beyond this annex, the frozen criteria, and the sources manifest")
   — the log should have said so, as the report's Limit 2 does. The
   evidence for independent *drafting* stands on the files: systematic
   era-note and falsifier-boilerplate template differences, and the
   genuine disagreements ruled on above (L1, L2, B1, B2, Q1, Q3, F1,
   I1, I2 — several of them invisible if either set had been copied
   or harmonised).
3. **Seal provenance.** "Sealed before adjudication" rests on the
   coordinator's record: both sets' sha256 values were taken on
   receipt, before adjudication began, and are the values in the
   Inputs table. The card files carry no internal timestamps; the
   seal is the coordinator's attestation plus the hashes, and is
   labelled as such here rather than implied to be mechanical.
4. **PASS citations (DA-3).** FREEZE §5 bans any PASS reported
   without its five-part disclosure header in run reports and
   summaries; the Inputs table above prints bare PASS counts. The
   cure is not to edit the table retroactively but to attach the
   record: the final validation outputs, headers included, are
   printed verbatim in the report's validation record and in
   `LOOP_ADJUDICATION_v1.1.md`, and the canonical set's final run was
   made with source-manifest verification (Annex §A2.4) enabled.
