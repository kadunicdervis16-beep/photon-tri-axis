# WORKED EXAMPLE — the Dirac equation, original vs modern gloss

**Scope label: DEMONSTRATION** (FREEZE v1.1 Annex §A6). This report is a
worked example of the claim-card method on one historical case. It carries
**no M1–M5 scores**, it is not the pilot, and it may not be cited as pilot
evidence. Criteria: FREEZE v1.0 (`9abc91c9…`) + FREEZE v1.1 Annex
(`8ee2f8e9…`). Instrument: honesty_plugin v1.1, tool `validate_cards`.

## Method in brief

Two independent carders each carded both sources under the Annex (verbatim
spans, one claim per card, NONE-forms where a field is empty), without
sight of each other's work. The coordinator adjudicated disagreements with
the sources open and published the log (`ADJUDICATION_LOG.md`). The merged
canonical set (39 cards) was machine-validated end-to-end:
**PASS 39/39** — every quote found verbatim (whitespace/hyphenation
normalised) in its named source file, every card schema-complete, no
banned constructions in any claim field.

## Validation record (verbatim tool output)

The canonical set's final validation — plugin v1.1.1, with source-manifest verification (Annex §A2.4) enabled against `sources/SOURCES.sha256`. Printed in full because FREEZE §5 bans a PASS reported without its five-part disclosure header (loop charge DA-3).

````
TOOL: validate_cards
CRITERIA: comparative-honesty-audit v1.1 (FREEZE v1.0 + Annex v1.1) | ANNEX FREEZE: 8ee2f8e9c7e2 (full 8ee2f8e9c7e2f7341c78b0eb8399e953757c95a3857e0ad597ee632a0564f3a6; manifest-verified; annex frozen 2026-11-08) | INCORPORATED FREEZE v1.0: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified)
DISCLOSURE (FREEZE v1.0 §6 + Annex v1.1 §A7, five-part):
  native domain: fidelity of this card set to its named sources and the Annex A1 schema
  verified domain: schema completeness, verbatim span presence after whitespace/hyphenation normalisation, layer-taxonomy membership, duplicate-id absence, and the banned-construction tripwire over claim fields — over the named files only
  map: cards JSON -> per-card field checks + normalised substring search in the source files named by the sources manifest
  preserves: the quote-source link and card-field discipline for every accepted card
  outside: semantic support beyond lexical span presence; premise truth; layer correctness (only taxonomy membership is checked); card-set completeness for its source; era fairness of judgements

cards file: worked_example_dirac/cards/canonical_cards.json
sources dir: worked_example_dirac/sources
cards in set: 39
sources manifest: worked_example_dirac/sources/SOURCES.sha256 (verified)
SOURCE dirac1928 -> dirac1928.txt sha256 b684ec4c305193502585169226dcf847a4f5be2ba3ecee8f8b7913e43e29dd2a (42263 bytes)
SOURCE tong_qft -> tong_qft_2006_2007.txt sha256 ffc727f882bc1bc17bd8ad81c774a15579c9fb7c8370189d52710369198fa350 (269598 bytes)

  [OK] D28-01
  [OK] D28-02
  [OK] D28-03
  [OK] D28-04
  [OK] D28-05
  [OK] D28-06
  [OK] D28-07
  [OK] D28-08
  [OK] D28-09
  [OK] D28-10
  [OK] D28-11
  [OK] D28-12
  [OK] D28-13
  [OK] D28-14
  [OK] D28-15
  [OK] D28-16
  [OK] D28-17
  [OK] D28-18
  [OK] TNG-01
  [OK] TNG-02
  [OK] TNG-03
  [OK] TNG-04
  [OK] TNG-05
  [OK] TNG-06
  [OK] TNG-07
  [OK] TNG-08
  [OK] TNG-09
  [OK] TNG-10
  [OK] TNG-11
  [OK] TNG-12
  [OK] TNG-13
  [OK] TNG-14
  [OK] TNG-15
  [OK] TNG-16
  [OK] TNG-17
  [OK] TNG-18
  [OK] TNG-19
  [OK] TNG-20
  [OK] TNG-21

RESULT: PASS — 39/39 card(s) accepted, 0 rejected (detected by the Annex §A7 checks named in the disclosure)
````

*Postscript (2026-11-08): the output above is verbatim as run under
plugin v1.1.1. A later patch (v1.1.2, from the Paper 12.5 v4 build's
loop pass) adds location correctness to the disclosure's outside
list and requires NONE-form reasons to carry substance; no check
result changed — the canonical set re-validates identically (see
`LOOP_ADJUDICATION_v1.1.md`, postscript).*

## Sources (full provenance in `sources/SOURCES.md`)

- **S1 `dirac1928`** — P. A. M. Dirac, "The Quantum Theory of the
  Electron," Proc. R. Soc. A **117**:610–624 (1928). Complete paper held
  (JSTOR scan, Rutgers mirror; text extracted with `pdftotext -layout`).
  Carded file sha256 `b684ec4c…`.
- **S2 `tong_qft`** — David Tong, *Quantum Field Theory* (Cambridge DAMTP
  Part III notes), Chapter 4 "The Dirac Equation" + §5.3 "Dirac's Hole
  Interpretation". Held edition: the Michaelmas 2006/2007 text, retrieved
  as the archive.org djvu text after the live DAMTP PDF closed every
  connection attempt from the build environment (recorded in SOURCES.md).
  Carded file sha256 `ffc727f8…`. Quotes from S2 are short audit spans of
  a copyrighted teaching text.

## Demonstration tallies (over the canonical cards — not M1–M5)

The windows differ and are part of the account: Dirac was carded over
his **complete paper** (pp. 610–624); Tong was carded over a **window**
— the whole of Chapter 4 (notes pp. 81–105) plus §5.3 (p. 111) — of a
149-page book. The denominators also differ in composition (Dirac: 13
dual-carded claims, 4 single-carder, 1 split; Tong: 11 dual-carded, 10
single-carder). Counts are printed as counts, never as rates; no
cross-source rate is computed or licensed by this table, and any
citation that strips the demonstration label misrepresents it.

| Tally | Dirac 1928 (18 cards) | Tong notes (21 cards) |
|---|---|---|
| Premises recorded on the card | 18/18 | 21/21 |
| Freedoms recorded (vs NONE-form) | 9 (9 NONE) | 11 (10 NONE) |
| Falsifier / defeating condition stated | **0** (18 NONE) | **0** (21 NONE) |
| Bridge entries | 10 — 8 declared, **2 undeclared** | 7 — 7 declared, **0 undeclared** |
| Cards with evidence NONE | 1 | 1 |
| Layers | dynamics 7, state-space 5, interpretation 6 | interpretation 8, state-space 8, dynamics 5 |

Reading the tallies honestly, at demonstration scope:

- **The premise row does not discriminate** — and the reader should
  know what it measures. The schema requires a premises field on every
  card and the carders harvested premises from the text surrounding
  each claim, so a full row measures the carding discipline at least
  as much as the texts. The row is printed because the method requires
  the whole account, not because it favours either side.
- **The falsifier row is a null on both sides.** Neither text states a
  defeating condition for any carded claim. Under the era-relative
  norm (Annex §A4.2) a 1928 journal paper is judged against what 1928
  could declare — the falsifier-as-genre did not exist — while the
  2006/2007 teaching text receives no era shelter; the norm's
  differential treatment is printed here rather than applied silently.
  Two cautions ride with the row: the shelter covers the missing
  *form*, not missing content — Dirac 1928 does tie claims to
  observation (a phenomenon "which has not been observed", D28-05;
  agreement with experiment, D28-18) — and the pairing crosses genre
  as well as era (a research article against lecture notes; FREEZE
  §3's matched-strata rule would forbid this pairing in a scored
  pilot, and the demonstration pairs them because the gloss that
  teaches is, in fact, lecture notes).
- **The undeclared bridges are specific, not atmospheric.** Dirac has
  two: the opening assertion of disagreement with experiment (D28-01
  — the comparison arrives one sentence later, carded at D28-02) and
  the rejection of half the solutions by charge assignment (D28-14 —
  the sorting premise is never stated). Tong has none on the
  canonical cards: every crossing his cards record is declared —
  "we choose", "stipulate", "put in by hand". (The first version of
  this report counted one for Tong, the evaluative aside at TNG-12;
  the loop pass ruled that an aesthetic aside is not a bridge under
  FREEZE §1's definition — an inference to a claim about physical
  reality — and the card was recoded. See the loop note at the end of
  this report.) Dirac's declarations run "we can interpret this
  result by saying" and "can be regarded as". On the carded evidence,
  stated without a baseline population and therefore without any
  comparative adjective: of the bridge crossings the two texts make,
  Dirac's cards record 8 declared of 10, Tong's 7 declared of 7.
- **Sensitivity of the tallies to adjudication.** Three existence
  rulings (log I1, I2, D1) were discretionary. Under their losing
  readings the counts move: carding the "gorgeous" aside as evidence
  only (I1 losing) takes Tong to 20 cards; folding the anti-matter
  sentence into evidence (I2 losing) takes Tong to 20 cards and
  removes finding F2's card anchor; keeping Dirac's aim sentence
  (D1 losing) takes Dirac to 19 cards and the evidence-NONE row from
  parity (1–1) to 2–1 against Dirac (2–0 only under the I1 and D1
  losing readings combined — an earlier printing of this paragraph
  attached the combined figure to D1 alone; corrected 2026-11-08 on
  the Paper 12.5 v4 loop's RT4-5). Under the all-B readings of the
  bridge rulings, Dirac's bridges read 9 declared / 1 undeclared
  instead of 8 / 2. The canonical readings are the ones defended in
  the adjudication log; the alternatives are printed here because
  the tallies are one adjudication deep at exactly these points.

## Gloss-vs-original fidelity findings (Annex §A4)

Each entry names the status the original gives a claim and the status the
gloss gives it, with both quotes. Quotes are verbatim from the held
files, extraction artefacts included.

**F1 — The negative-energy problem: 1928's open flag, retold as a
solved story inside an undated "historical detour".** Dirac 1928 flags
the difficulty and leaves it open: *"One cannot do this on the quantum
theory, since in general a perturbation will cause transitions from
states with W positive to states with W negative. Such a transition
would appear experimentally as the electron suddenly changing its
charge from - e to e, a phenomenon which has not been observed."*
(D28-05) His only handling of the doubled solutions is an imposed
rejection (D28-14). Tong §5.3 presents the sequel: *"Dirac postulated
an ingenious solution to this problem: since the electrons are
fermions (a fact which is put in by hand to Dirac's theory) they obey
the Pauli-exclusion principle"* (TNG-17), and *"So we could simply
stipulate that in the true vacuum of the universe, all the negative
energy states are filled."* (TNG-18) The sea and the hole are 1930–31
material. What the gloss does and does not do, exactly: §5.3 announces
itself as a historical detour ("Let's pause our discussion to make a
small historical detour" — its opening, carded in the framing at
TNG-16), so register and period are separated; but no carded span of
the section prints a year or a paper boundary for the sea/hole
material, so a reader is given the detour's existence without its
dates. Credit where due: Tong flags the by-hand premise and the
stipulation in his own words. The finding, at its narrowest and
strongest: the machinery is declared; the chronology is marked as
history but not dated. (The first version of this entry said
"blurring the chronology"; the loop pass sustained the objection
that the phrase outran the detour frame, and the entry was narrowed
— see the loop note.)

**F2 — "Predicted anti-matter": a true sentence about Dirac, printed
without the date that locates it.** Tong: *"Dirac had predicted
anti-matter, one of the greatest achievements of theoretical physics.
It took only a couple of years before the positron was discovered
experimentally in 1932."* (TNG-20) The sentence's subject is Dirac
the person, and within §5.3's own narrative the prediction belongs to
the hole stage of his work — the 1930–31 development — not to the
1928 paper, in which no span predicts a new particle (the paper's
closing assessment is the approximation-flagged agreement at
D28-06/D28-18). So the sentence is defensible history whose
placement, at the end of an undated detour inside the chapter on the
1928 equation, lets the credit settle on the famous equation without
a marker separating the two papers. The finding is about the missing
date, not about the sentence's truth. (The first version of this
entry charged an upgrade of the 1928 text; the loop pass sustained
the objection that the sentence does not claim the 1928 paper
predicted anything, and the entry was rewritten to the residue its
quotes support.)

**F3 — Withdrawn as a fidelity finding; retained as a traceability
observation.** The first version of this entry ("the stipulation
changes costume") charged that Dirac's conditions (6) reappear in
Tong as an asserted uniqueness, the freedom having "moved". The loop
pass sustained three objections, and they are correct: the conditions
are not a stipulation on Dirac's side either (D28-09's own premises
record that they are imposed by requiring the squared linear form to
agree with the relativistic energy relation — derived constraints);
the uniqueness of the irreducible Clifford representation up to
equivalence is a theorem, not a freedom in new dress; and Tong uses
Dirac's own obligation idiom at the parallel point in §4.1 of the
held text ("we must find four matrices such that…", located in the
held text, uncarded). What survives is narrower and is a fact about
traceability, not status: where Dirac's passage derives its
constraints in the open, Tong's asserts the corresponding algebraic
facts in prose — *"…it turns out that there is a unique irreducible
representation of the Clifford algebra"* (TNG-04, whose evidence note
records: asserted, no proof displayed in the passage). A teaching
text asserting standard theorems is ordinary practice; the
observation is printed because the method records where each text's
warrants are displayed, and at this point one displays and the other
cites by cadence.

**F4 — Spin: derived-and-flagged vs front-loaded (an expository
observation; no A4.3 status shift is asserted).** Dirac marks the
interpretive step in the sentence that performs it: *"We can
interpret this result by saying that the electron has a spin angular
momentum…"* (D28-17) Tong's spin arrives in the chapter's first
sentence as what quantization *"gives rise to"* — *"fermionic spin
1/2 particles"* (TNG-01) — expressly deferred to the quantization
chapter, as the card records. The difference is one of expository
order — a destination announced at the start of lecture notes versus
a result interpreted at its point of derivation — and is recorded
because the method cards framing claims, not because either text
misstates the other's status.

**F5 — The evaluative register is the gloss's own (tone, recorded;
not an epistemic-status shift).** Tong: *"This is the Dirac equation.
It's completely gorgeous."* (TNG-12; evidence NONE) and *"The Dirac
equation is first order in derivatives, yet miraculously Lorentz
invariant."* (TNG-13) Dirac's register at the corresponding points
is a proved conclusion stated plainly (D28-11) and doubt stated
plainly (D28-16, the electric moment "doubtful"). No sentence of the
1928 paper evaluates its own equation aesthetically. The aside at
TNG-12 is carded under the equation-entourage rule (Annex §A2.3);
it is not a bridge (loop ruling, DA-9) and shifts no claim's status.

**F6 — A confirmation, printed because fidelity cuts both ways.**
Tong: *"Dirac originally viewed his equation as a relativistic version
of the Schrodinger equation, with [the spinor] interpreted as the
wavefunction for a single particle with spin."* (TNG-16) This matches
the 1928 paper's own framing (the linearity requirement exists so that
*"the general interpretation is to be possible"*, D28-04). No status
shift; the gloss is faithful here.

**F7 — Dirac's §1 approximation flag has no counterpart in the
carded window; the gloss's own restraint sits elsewhere.** Dirac,
closing §1: *"The resulting theory is therefore still only an
approximation, but it appears to be good enough to account for all
the duplexity phenomena without arbitrary assumptions."* (D28-06)
No carded span of Tong's chapter carries a counterpart approximation
flag for the equation. That is a textual fact, and three cautions
bound it. First, genre: Tong's chapter is a QFT text whose framework
supersedes the single-particle reading outright; requiring it to
reproduce a flag whose referent was a difficulty *within* the 1928
programme would be a category error, and this entry does not require
it. Second, restraint was relocated, not lost: Tong's closing lesson
is itself a severe scope restriction — *"What we really learn from
Dirac's analysis is that there is no consistent way to interpret the
Dirac equation as describing a single particle"* (TNG-21) — withdrawing
an entire interpretation where Dirac, working *inside* that reading
in 1928, flagged its wounds (F1). Third, attribution: "Dirac's
analysis" in §5.3 refers to the arc Tong has just narrated, hole
argument included, not to a conclusion of the 1928 paper — Dirac 1928
does not draw TNG-21's conclusion, and the entry records the
difference without charging the gloss with claiming he did.


## Card tables (short forms; full cards in `cards/canonical_cards.json`)

### Canonical cards — Dirac 1928

| Card | Location | Layer | Claim (short form) |
|---|---|---|---|
| D28-01 | p. 610, introduction (unnumbered opening section) | interpretation | Dirac states that the new quantum mechanics applied to the atom with point-charge electrons does not give results in agreement with experiment. |
| D28-02 | p. 610, introduction | state-space | Dirac identifies the discrepancy as duplexity: the observed number of stationary states for an atomic electron is twice the number the theory gives. |
| D28-03 | p. 610, introduction | dynamics | Dirac asserts that the simplest Hamiltonian for a point-charge electron meeting the requirements of relativity and of the general transformation th... |
| D28-04 | p. 612, §1 | dynamics | Dirac states a requirement on the relativity wave equation: it must be linear in W (equivalently in the time derivative) if the general interpretat... |
| D28-05 | p. 612, §1 | dynamics | Dirac flags, as a difficulty of the earlier relativity theory, that negative-W solutions cannot be excluded in quantum theory because a perturbatio... |
| D28-06 | p. 612, §1 | interpretation | Dirac limits the paper to removing only the first of the two difficulties he has identified, and assesses the resulting theory as still only an app... |
| D28-07 | p. 613, §2 | dynamics | Dirac states the problem as obtaining a wave equation of the form of his equation (2) that is Lorentz invariant and equivalent to the earlier relat... |
| D28-08 | p. 613, §2 | state-space | Dirac concludes that further dynamical variables beyond the electron's coordinates and momenta are obligatory, so that the new alpha-type variables... |
| D28-09 | p. 614, §2 | state-space | Dirac states that four matrices must be found satisfying conditions (6): each matrix squares to 1 and distinct matrices anticommute, these being th... |
| D28-10 | p. 614, §2 | state-space | Dirac states that the Pauli matrices cannot serve directly as three of the four new variables because no fourth could then be found, and that the m... |
| D28-11 | p. 617, §3 (end of section) | dynamics | Dirac states the conclusion of section 3: after a Lorentz transformation the wave equation can be brought back by canonical transformations to its ... |
| D28-12 | p. 618, §4 | dynamics | Dirac obtains the field Hamiltonian by adopting what he calls the usual procedure of substituting the potential-shifted quantities for p0 and p in ... |
| D28-13 | p. 618, §4 | state-space | Dirac states that, because the matrices have four rows and columns, the field wave equation (14) has four times as many solutions as the non-relati... |
| D28-14 | p. 618, §4 | interpretation | Dirac states that half the solutions of equation (14) must be rejected as referring to the other charge value, leaving the correct number to accoun... |
| D28-15 | p. 619, §4 | interpretation | Dirac states that the magnetic moment arising from the extra term in the squared equation is the same moment that the spinning electron model assumes. |
| D28-16 | p. 619, §4 | interpretation | Dirac states that it is doubtful whether the electric moment term has any physical meaning, because the starting Hamiltonian (14) is real and the i... |
| D28-17 | p. 620, §5 | interpretation | Dirac states the interpretation of his commutator result: the electron has a spin angular momentum which, added to the orbital angular momentum m, ... |
| D28-18 | p. 624, §6 | dynamics | Dirac concludes that the present theory, in the first approximation, leads to the same energy levels as Darwin's, which he states are in agreement ... |

### Canonical cards — Tong, QFT notes

| Card | Location | Layer | Claim (short form) |
|---|---|---|---|
| TNG-01 | §4 introduction (notes p. 81) | interpretation | Tong frames Chapter 4 as describing the Dirac equation, whose quantization he states gives rise to fermionic spin-1/2 particles, and motivates it b... |
| TNG-02 | §4.1 (notes p. 83) | state-space | Tong states that the spinor representation will be constructed, starting from a definition (the Clifford algebra) that at first sight has nothing t... |
| TNG-03 | §4.1 (notes p. 83) | state-space | Tong asserts that the Clifford algebra has no representations by 2x2 or 3x3 matrices and that its simplest representation uses 4x4 matrices. |
| TNG-04 | §4.1 (notes p. 83) | state-space | Tong asserts that, up to the equivalence by an invertible matrix V described just before, there is a unique irreducible representation of the Cliff... |
| TNG-05 | §4.1 (notes p. 86) | state-space | Tong states that the spinor representation S[A] is a different representation from the familiar vector representation. (The span carries the extrac... |
| TNG-06 | §4.1.1 (notes p. 85) | state-space | Tong introduces the Dirac spinor field as an object with four complex components, presented as an introduction ('we introduce'), i.e. a definition ... |
| TNG-07 | §4.1.1 (notes p. 86) | state-space | Tong states that the spinor representation is unitary for rotations but not for boosts, and asserts in general that the Lorentz group has no finite... |
| TNG-08 | §4.2 (notes p. 87) | dynamics | Tong states the method of section 4.2: the Lorentz invariant equation of motion is obtained by constructing a Lorentz invariant action. |
| TNG-09 | §4.2 (notes p. 89) | dynamics | Tong presents the Dirac action as chosen: from the three covariant bilinears he states that only the first two are needed, and the action that foll... |
| TNG-10 | §4.2 (notes p. 89) | interpretation | Tong states that after quantization the theory of the Dirac action describes particles and anti-particles of mass \|m\| and spin 1/2. |
| TNG-11 | §4.3 (notes p. 90) | dynamics | Tong states that the equation of motion follows from the action (4.50) by varying it with respect to the spinor and its adjoint independently, yiel... |
| TNG-12 | §4.3 (notes p. 90) | interpretation | Tong attaches an evaluative gloss to the derived equation, calling the Dirac equation 'completely gorgeous' — a value judgement presented alongside... |
| TNG-13 | §4.3 (notes p. 90) | dynamics | Tong states, with the evaluative gloss 'miraculously', that the Dirac equation is first order in derivatives and Lorentz invariant. |
| TNG-14 | §4.7, 'Negative Frequency Solutions' (notes p. 101 in the held text; Chapter 4 plane-wave section) | dynamics | Tong presents the second plane-wave ansatz's solutions as negative frequency solutions whose energy, computed by the formula (4.92), is negative. |
| TNG-15 | §4.4.1 (notes p. 91) | state-space | Tong states that a massive fermion requires both Weyl spinors because they couple through the mass term, whereas a massless fermion can be describe... |
| TNG-16 | §5.3 (notes p. 111) | interpretation | Tong states that Dirac originally viewed his equation as a relativistic version of the Schrodinger equation, with the spinor interpreted as the wav... |
| TNG-17 | §5.3 (notes pp. 111-112) | interpretation | Tong states that Dirac postulated his solution to the negative-energy problem, and flags that the electrons being fermions is a fact put in by hand... |
| TNG-18 | §5.3 (notes p. 111) | state-space | Tong presents the Dirac sea as a stipulation: the true vacuum is stipulated to have all negative energy states filled, leaving only positive energy... |
| TNG-19 | §5.3 (notes p. 112) | interpretation | Tong states that the hole in the filled sea would have all the properties of the electron except positive charge, and that Dirac, after considering... |
| TNG-20 | §5.3 (notes p. 112) | interpretation | Tong states that Dirac had predicted anti-matter, calls it one of the greatest achievements of theoretical physics, and states that the positron wa... |
| TNG-21 | §5.3 (notes p. 112) | interpretation | Tong states the lesson he draws from Dirac's analysis: there is no consistent way to interpret the Dirac equation as describing a single particle. |


## Limits of this demonstration (stated, not footnoted away)

1. **One example, asymmetrically windowed.** A single original/gloss
   pair, chosen by the author of the audit programme; the example was
   chosen knowing the historiography (the hole-theory folklore is a
   known soft target), so F1/F2-style findings were foreseeable in
   kind. Nothing here estimates any rate for any corpus; the pilot,
   when run, samples by criteria fixed before scoring (FREEZE v1.0
   §3). The windows are asymmetric by construction: Dirac is carded
   over his complete paper, Tong over Chapter 4 + §5.3 of his notes —
   his Chapter 5 quantization declarations (§§5.1–5.2, a few pages
   before §5.3) sit outside the window, so where the cards record
   the gloss *deferring* a declaration to quantization, the deferred
   text exists uncarded nearby. The pairing also crosses genre
   (research article vs lecture notes), which FREEZE §3's
   matched-strata rule would forbid in a scored pilot.
2. **House carders.** Both carders were agents working in the
   programme's own house, briefed with its coverage list. Dual carding
   and the published adjudication log constrain, but do not remove,
   that interest. Annex §A5's doors (opponent nomination, self-carding,
   right of reply) are the designed remedy and have not yet been
   exercised by anyone outside the house. Externality is still owed.
3. **Edition caveat.** The gloss as held is Tong's 2006/2007 text, not
   the current DAMTP revision (SOURCES.md records the failed retrieval
   attempts). Findings F1–F7 bind the held edition; the current
   revision's Chapter 4 is materially the same lineage but was not
   carded, and no finding here is asserted of it.
4. **Extraction artefacts.** Both sources are OCR/extraction products.
   Quotes validate against the held files, artefacts included; one
   glyph (the charge sign in D28-14's sentence) is flagged unresolved
   in the open rather than corrected from memory. Equation lines were
   largely unusable as spans in both sources; the card sets lean on
   prose, and both carders listed the spans they wanted and could not
   use — those lists are part of the run record.
5. **What the tallies are.** Counts over the canonical cards of what
   the cards record. They are not M1–M5 scores, not a ranking, and not
   a verdict on either text's truth or empirical standing — the
   empirical axis is not measured anywhere in this report.
6. **The ceiling.** FREEZE v1.0 §5's ceiling sentence, verbatim, is:
   "Under one published set of bookkeeping criteria, applied
   symmetrically and open to return application, the ledger's texts
   declare more of what they assume than the cited standard texts
   declare of theirs — and here is the itemised account, the
   criteria, and the machine record, so the reader can check the
   account and dispute the criteria." This demonstration does **not**
   reach that sentence and does not print it as a conclusion: it
   compares a standard original with its own gloss, not with the
   ledger, and a demonstration carries no comparative conclusion at
   all (Annex §A6, read as a bound — see the plugin README's
   house-practice note). The strongest sentence this report supports
   is pair-scoped and descriptive: on the canonical cards, Dirac's
   text leaves two bridge crossings undeclared of ten recorded, and
   Tong's leaves none of seven; where the gloss shifts the
   original's epistemic status, the shifts are itemised above with
   both quotes, so the reader can check the account and dispute the
   criteria.

## Loop-pass note (2026-11-08)

This report was read by three read-only benches (devil's advocate,
evil auditor, red team) before delivery; the full adjudication is in
the plugin root's `LOOP_ADJUDICATION_v1.1.md`. Sustained charges
repaired in this text: the baseline-less comparative "unusually
explicit" (deleted; numbers stand in its place); the ceiling
paraphrase formerly printed under the ceiling's name (item 6 above);
findings F1 and F2 (narrowed to the undated-detour residue), F3
(withdrawn as a fidelity finding, retained as a traceability
observation), F4 and F5 (relabelled as observation/tone), F7 (sting
removed, genre and attribution cautions added); the TNG-12 bridge
recode (Tong's undeclared bridges 1 → 0, tallies updated); the
premise-row inference (reworded); adjudication sensitivity and
window denominators (added to the tallies section); the window
asymmetry (Limit 1). The canonical card set changed under two
rulings (TNG-12 recode; TNG-17 era-note correction) and a pointer
repair (DA-21): its sha256 is now
`0c24b3f1e942917e70e1d7137d2cf84b1b82a1b27db8d18bc71f96c3b220c3f9`,
superseding the pre-loop hash recorded in the adjudication log,
whose addendum carries the same record.
