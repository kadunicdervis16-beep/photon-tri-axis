#!/usr/bin/env python3
"""Trial run driver: runs the honesty_plugin v1 instrument against the
Paper 12.5 v3 verification package and writes TRIAL_RUN_v1.md from the
ACTUAL tool outputs (nothing in the report is hand-typed except the
framing). Also builds and runs the planted-mutant mini-battery:

  (a) verdict-injection   — param table requesting a "therefore X is
                            preferable" line -> param_prov must REFUSE
  (a2)/(a3)               — verdicts carried by a JSON key / by the
                            convention string -> must also REFUSE
  (b) registry -> missing — registry entry pointing at a nonexistent
                            script -> must be flagged MISSING with witness
  (c) provenance stripped — a real package script (E1) with its
                            INPUT_PROVENANCE block deleted -> NO BLOCK
  (d) glued fence         — the real paper with one closing fence fused
                            onto its code line -> fence check must FAIL

Usage: python3 trial/run_trial.py [path-to-verification-package.zip]
"""
import hashlib
import json
import platform
import re
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from honesty_plugin import disclose, tools  # noqa: E402

DEFAULT_ZIP = Path.home() / "workspace" / "paper_12_5_delivery" / \
    "Paper_12_5_v3_verification_package.zip"
TRIAL = ROOT / "trial"
EXTRACT = TRIAL / "extracted"
FIX = TRIAL / "fixtures"


def strip_provenance(src: Path, dst: Path) -> str:
    """Delete the WHOLE provenance block: the header line plus every
    following line that belongs to the header region (blank, indented,
    comment, or a docstring-closing delimiter line) — not just the header.
    The mutant must retain no declaration lines at all."""
    lines = src.read_text(encoding="utf-8").splitlines(keepends=True)
    out, removed, in_block = [], 0, False
    for ln in lines:
        if not in_block and re.search(r"INPUT_PROVENANCE\s*:", ln):
            in_block = True
            removed += 1
            continue
        if in_block:
            stripped = ln.strip()
            if (stripped == "" or ln[0] in " \t" or stripped.startswith("#")
                    or stripped in ('"""', "'''")):
                removed += 1
                continue
            in_block = False
        out.append(ln)
    dst.write_text("".join(out), encoding="utf-8")
    return (f"deleted the INPUT_PROVENANCE header line and {removed - 1} "
            f"block-body line(s) (the whole block) from {src.name}")


_BLURB = re.compile(r"\.py\s+--\s+(.+)$")


def script_blurb(script: Path) -> str:
    """The script's own one-line self-description (its header line of the
    form 'NAME.py -- ...'), used as the registry entry's `checks` field so
    the token heuristic runs on declared content. Tokens drawn from the
    script's own header are weak evidence by construction; the counts are
    printed and the registry status does not rest on them alone."""
    try:
        for ln in script.read_text(encoding="utf-8", errors="replace").splitlines()[:20]:
            m = _BLURB.search(ln)
            if m:
                return m.group(1).strip()
    except OSError:
        pass
    return ""


def glue_first_closing_fence(src: Path, dst: Path) -> str:
    lines = src.read_text(encoding="utf-8").splitlines()
    in_block = False
    for i, ln in enumerate(lines):
        if ln.strip().startswith("```"):
            if in_block:
                lines[i - 1] = lines[i - 1] + "```"
                del lines[i]
                dst.write_text("\n".join(lines) + "\n", encoding="utf-8")
                return (f"fused the closing fence of the first listing onto "
                        f"line {i} (1-based) of {src.name}")
            in_block = True
    raise RuntimeError("no closing fence found")


def main() -> int:
    zip_path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_ZIP
    # verify the corpus BEFORE touching the previous extraction: an
    # unreadable/missing zip must never destroy the last good trial tree
    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"corpus zip fails integrity check at {bad}")
    zip_sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    if EXTRACT.exists():
        shutil.rmtree(EXTRACT)
    FIX.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(EXTRACT)
    pkg = EXTRACT / "paper_12_5_verification"
    scripts = pkg / "scripts"
    paper = pkg / "Paper_12_5_v3.md"

    # registry built from the package's own MANIFEST.sha256 (declared
    # construction: one entry per script the manifest lists)
    entries = []
    for line in (pkg / "MANIFEST.sha256").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[1].startswith("scripts/") and parts[1].endswith(".py"):
            entry = {"claim_id": Path(parts[1]).stem, "script": parts[1]}
            blurb = script_blurb(pkg / parts[1])
            if blurb:
                entry["checks"] = blurb
            entries.append(entry)
    reg_good = TRIAL / "registry_trial.json"
    reg_good.write_text(json.dumps({"entries": entries}, indent=2))
    reg_mut = TRIAL / "registry_mutant.json"
    reg_mut.write_text(json.dumps({"entries": entries + [
        {"claim_id": "MUTANT-B", "script": "scripts/NO_SUCH_SCRIPT.py"}]}, indent=2))

    # mutant (c) + (d) fixtures
    strip_note = strip_provenance(scripts / "E1_census_arrow.py", FIX / "E1_no_provenance.py")
    glue_note = glue_first_closing_fence(paper, FIX / "glued_fence.md")

    # param tables: demonstration + mutant (a)
    demo = {"convention": "instrument-trial demonstration convention (NOT a scoring corpus)",
            "entries": [
                {"name": "example_measured_mass", "class": "measured-input"},
                {"name": "example_fitted_coupling", "class": "fitted"},
                {"name": "example_window_choice", "class": "declared-assumption"},
                {"name": "example_count_ratio", "class": "derived-from-structure"},
                {"name": "example_representative_configuration", "class": "arbitrary-representative"}]}
    (FIX / "param_demo.json").write_text(json.dumps(demo, indent=2))
    mutant_a = dict(demo)
    mutant_a["requested_conclusion"] = "therefore the ledger is preferable, having fewer parameters"
    (FIX / "param_mutant.json").write_text(json.dumps(mutant_a, indent=2))
    mutant_a2 = {"convention": "instrument-trial demonstration convention",
                 "therefore the ledger is preferable": "yes",
                 "entries": [{"name": "example_x", "class": "fitted"}]}
    (FIX / "param_mutant_key.json").write_text(json.dumps(mutant_a2, indent=2))
    mutant_a3 = {"convention": "superiority of the ledger (counting rules)",
                 "entries": [{"name": "example_x", "class": "fitted"}]}
    (FIX / "param_mutant_convention.json").write_text(json.dumps(mutant_a3, indent=2))

    sections: list[tuple[str, str]] = []

    def record(title: str, text: str) -> None:
        sections.append((title, text))

    text, _ = tools.run_verification_suite(str(pkg))
    record("1. run_verification_suite — the package's own 13 scripts + RB1 runner", text)

    text, _ = tools.lint_provenance(str(scripts))
    record("2. lint_provenance — the package's scripts directory", text)

    text, _ = tools.check_registry_pointers(str(reg_good), base_dir=str(pkg))
    record("3. check_registry_pointers — registry constructed from the package MANIFEST", text)

    text, _ = tools.fence_and_listing_check(str(paper), str(scripts))
    record("4. fence_and_listing_check — the real paper vs its standalone scripts", text)

    text, _ = tools.param_prov(str(FIX / "param_demo.json"))
    record("5. param_prov — demonstration table (instrument trial, not a scoring run)", text)

    text, _ = tools.audit_dashboard(str(pkg), registry_path=str(reg_good),
                                    param_table=str(FIX / "param_demo.json"))
    record("6. audit_dashboard — assembled (suite shown separately in §1, not re-run)", text)

    # ---- mutant battery ----------------------------------------------------
    text, data = tools.param_prov(str(FIX / "param_mutant.json"))
    verdict = "CAUGHT" if data["status"] == "REFUSED" else "NOT CAUGHT"
    record(f"7. MUTANT (a) verdict-injection — {verdict}", text)

    text, data = tools.check_registry_pointers(str(reg_mut), base_dir=str(pkg))
    verdict = "CAUGHT" if data["n_missing"] == 1 else "NOT CAUGHT"
    record(f"8. MUTANT (b) registry entry pointing at a nonexistent script — {verdict}", text)

    text, data = tools.lint_provenance(str(FIX / "E1_no_provenance.py"))
    verdict = "CAUGHT" if data["n_with_block"] == 0 else "NOT CAUGHT"
    record(f"9. MUTANT (c) provenance stripped from a real script ({strip_note}) — {verdict}", text)

    text, data = tools.fence_and_listing_check(str(FIX / "glued_fence.md"), str(scripts))
    verdict = "CAUGHT" if data["status"] == "FAIL" else "NOT CAUGHT"
    record(f"10. MUTANT (d) glued closing fence in the real paper ({glue_note}) — {verdict}", text)

    text, data = tools.param_prov(str(FIX / "param_mutant_key.json"))
    verdict = "CAUGHT" if data["status"] == "REFUSED" else "NOT CAUGHT"
    record(f"11. MUTANT (a2) verdict-injection carried by a JSON key — {verdict}", text)

    text, data = tools.param_prov(str(FIX / "param_mutant_convention.json"))
    verdict = "CAUGHT" if data["status"] == "REFUSED" else "NOT CAUGHT"
    record(f"12. MUTANT (a3) verdict-injection carried by the convention string — {verdict}", text)

    inst_manifest = ROOT / "INSTRUMENT_MANIFEST.sha256"
    inst_line = ("not generated at trial time"
                 if not inst_manifest.exists() else
                 f"sha256 {hashlib.sha256(inst_manifest.read_bytes()).hexdigest()} "
                 "(pins src/, tests/, trial/run_trial.py)")
    out = ["# TRIAL RUN v1 — honesty_plugin against the Paper 12.5 v3 verification package",
           "",
           "**Scope of this document (read first).** This is an instrument smoke",
           "test on ONE house corpus (the plugin author's own series package).",
           "§3's registry was constructed from the package's own MANIFEST, so its",
           "PASS establishes pointer-existence plumbing only; its `checks` fields",
           "are the scripts' own header lines, so the token counts are weak",
           "evidence by construction and are printed, not leaned on. NO section",
           "of this trial bears on symmetry between corpora, on metrics M1–M5,",
           "or on any standard-side corpus — none has been scored. The trial",
           "evidences: the six tools run, the disclosure discipline holds, and",
           "the planted-mutant battery is caught. Nothing more.",
           "",
           f"Package under test: `{zip_path}`",
           f"Corpus zip sha256: `{zip_sha}` (extracted fresh to `trial/extracted/`).",
           "Instrument: honesty_plugin v1 (src layout), criteria v1.0, FREEZE 2026-11-08.",
           f"Freeze hash: {disclose.freeze_sha256()[0]} (source: {disclose.freeze_sha256()[1]}).",
           f"Instrument manifest: {inst_line}.",
           f"Python: {platform.python_version()} on {platform.system()}.",
           "Every section below is a tool's actual output from this run, reproduced",
           "verbatim. The registry in §3/§6/§8 was constructed from the package's own",
           "MANIFEST.sha256 (one entry per listed script) — a declared construction,",
           "since the package ships no registry JSON of its own.",
           ""]
    for title, text in sections:
        out.append(f"## {title}")
        out.append("")
        out.append("```text")
        out.append(text.rstrip())
        out.append("```")
        out.append("")
    (TRIAL / "TRIAL_RUN_v1.md").write_text("\n".join(out), encoding="utf-8")
    print(f"TRIAL_RUN_v1.md written ({len(sections)} sections)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
