# Paper 12.5 v3 — Verification Package

Paper 12.5: *The Ensemble Illusion — A Structural Critique of the Ensemble in
Standard Statistical Mechanics* (Dervis Kadunic, 2026 — v3 DRAFT).

## Contents
- `Paper_12_5_v3.md` / `Paper_12_5_v3.txt` — the paper (markdown source and
  the plain-strip text, produced by the series' established conversion).
- `scripts/` — the verification suite of the paper's section 0.5.4:
  thirteen instruments under the RB1 runner (fourteen files): E1–E6 exact
  censuses and exhibits (E5 quantum census, E6 updating exhibit added in
  v2; E6's per-class separation assert completed in v3), M1–M2 Monte
  Carlo audit instruments (Stage P/C: they audit the standard machinery
  on its own terms; the sampling rule is the postulate under audit),
  G1–G4 document checks (G3 premise inventory, G4 rewrite pairs added
  in v2; G1's mutant battery, pairing diagnostics, and whole-word
  falsification-presence check, and FW1's whole-word neutrino
  exemption, strengthened in v3), FW1 firewall.
- `history/HISTORY_DOSSIER.md` — the v1 fact-check dossier behind section 2
  and Appendix A; `history/HISTORY_DOSSIER_v2.md` — the v2 dossier behind
  the lineage extensions and the quantum audit's historical claims
  (verdicts and sources for every historical claim).
- `MANIFEST.sha256` — sha256 of every other file in the package.

## Run
```
python3 scripts/RB1_run_all.py Paper_12_5_v3.md
```
Expected: RB1 PASS, 13/13 scripts exit 0 (E4's exhaustive Kac-ring census takes
about a minute). Python 3, standard library only.
