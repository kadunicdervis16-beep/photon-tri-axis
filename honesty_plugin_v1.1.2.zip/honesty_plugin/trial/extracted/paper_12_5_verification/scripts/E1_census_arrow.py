#!/usr/bin/env python3
"""
E1_census_arrow.py -- Full census of binary records (Paper 12.5 / Paper 12 S8).

INPUT_PROVENANCE:
  - n range 2..16                                  [control] declared check range.
  - Binary record, entries up/down                 [paper-defined] Paper 12 S8
    binary-record census: a record of length n with k "up" entries is
    counted C(n,k) times; total records 2^n.
  - Polarized records = the two all-equal records  [paper-defined] Paper 12 S8.
  - Claim (a): non-polarized share >= (n-1)/n       [cited-paper] Paper 12 S8
    stated form, used ONLY as an oracle compared against the enumeration.
  - Claim (b): balanced share C(n,n/2)/2^n does NOT [cited-paper] Paper 12 S8
    grow (L8.4 honesty); used ONLY as an oracle.
  - No other inputs. No declared-assumption, no arbitrary-representative.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact rational census arithmetic for n = 2..16: counts by k (C(n,k)),
  polarized / non-polarized shares as Fractions, and the balanced share
  for even n, including its strict decrease over n = 2,4,...,16.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Any physical / dynamical reading of "arrow" (drift, approach, time
  evolution) is NOT checked here. This script verifies counting shares
  only; Paper 12 S8.6/9.6's open joint (no tau-monotonicity -> Omega-drift
  theorem) is untouched and remains open.
METHOD (input-equals-output ban): shares are COMPUTED from the enumerated
  counts C(n,k) summed by class; the claimed bounds/forms are compared
  afterwards as oracles. Mutants with wrong formulas are run through the
  same comparison and must be rejected with printed witnesses.
"""
import sys
from fractions import Fraction
from math import comb


def census_counts(n):
    """Enumerate the census by class: counts[k] = number of records with
    exactly k up entries. Computed by direct recurrence-free counting via
    math.comb per class AND cross-checked by an independent Pascal-row
    construction below (in main), so the class counts are not taken from
    a single source."""
    return [comb(n, k) for k in range(n + 1)]


def pascal_row(n):
    """Independent construction of the same row by repeated addition."""
    row = [1]
    for _ in range(n):
        row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
    return row


def main():
    failures = []

    print("E1 census arrow -- binary records, n = 2..16")
    balanced_seq = []  # (n, Fraction share)
    equality_cases = []

    for n in range(2, 17):
        counts = census_counts(n)
        # Independent cross-check of the enumeration itself.
        if counts != pascal_row(n):
            failures.append(f"n={n}: comb row != Pascal row: {counts}")
            continue
        total = sum(counts)
        if total != 2 ** n:
            failures.append(f"n={n}: total {total} != 2^n {2 ** n}")
            continue

        # (a) Polarized = records with k=0 or k=n: counts[0]+counts[n] = 1+1.
        polarized_count = counts[0] + counts[n]
        if polarized_count != 2:
            failures.append(f"n={n}: polarized count {polarized_count} != 2")
        polarized_share = Fraction(polarized_count, total)
        nonpol_share = Fraction(total - polarized_count, total)
        # Computed share must equal the closed form computed from counts.
        if polarized_share != Fraction(2, 2 ** n):
            failures.append(f"n={n}: polarized share {polarized_share} != 2/2^n")
        bound = Fraction(n - 1, n)
        if not (nonpol_share >= bound):
            failures.append(
                f"n={n}: non-polarized share {nonpol_share} < bound {bound}")
        if nonpol_share == bound:
            equality_cases.append(n)

        # (b) Balanced share for even n.
        if n % 2 == 0:
            balanced_share = Fraction(counts[n // 2], total)
            balanced_seq.append((n, balanced_share))

        print(f"  n={n:2d} total={total:6d} polarized_share={polarized_share} "
              f"nonpol_share={nonpol_share} (~{float(nonpol_share):.6f}) "
              f"bound_(n-1)/n={bound}")

    # Equality case for (a) must be exactly n=2 in this range.
    if equality_cases != [2]:
        failures.append(f"equality cases for (n-1)/n bound: {equality_cases}, expected [2]")

    # (b) Strict decrease of the balanced share over even n.
    print("  balanced share sequence (even n):")
    for n, s in balanced_seq:
        print(f"    n={n:2d} balanced_share={s} (~{float(s):.6f}) [float is translator only]")
    for (n1, s1), (n2, s2) in zip(balanced_seq, balanced_seq[1:]):
        if not (s2 < s1):
            failures.append(
                f"balanced share not strictly decreasing: n={n1} {s1} -> n={n2} {s2}")

    # ---- Mutant battery -------------------------------------------------
    print("  mutant battery:")
    # Mutant (i): non-polarized share = 1 - 1/2^n (only ONE polarized record).
    mutant_rejected = False
    for n in range(2, 17):
        counts = census_counts(n)
        total = sum(counts)
        true_share = Fraction(total - (counts[0] + counts[n]), total)
        mutant_share = 1 - Fraction(1, 2 ** n)
        if mutant_share != true_share:
            print(f"    MUTANT(i) REJECTED at n={n}: mutant share {mutant_share} "
                  f"vs enumerated {true_share}")
            mutant_rejected = True
            break
    if not mutant_rejected:
        failures.append("mutant (i) 1 - 1/2^n was NOT rejected")

    # Mutant (ii): claim that the balanced share INCREASES with n.
    mutant2_rejected = False
    for (n1, s1), (n2, s2) in zip(balanced_seq, balanced_seq[1:]):
        if s2 < s1:  # an increase claim fails at the first decrease
            print(f"    MUTANT(ii) REJECTED: 'balanced share increases' fails at "
                  f"n={n1}->{n2}: {s1} -> {s2} (decrease, witness pair)")
            mutant2_rejected = True
            break
    if not mutant2_rejected:
        failures.append("mutant (ii) increasing balanced share was NOT rejected")

    if failures:
        print("E1 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"E1 PASS: n=2..16 enumerated; non-polarized share >= (n-1)/n for all n, "
          f"equality only at n=2 (share 1/2); at n=16 nonpol_share={Fraction(2**16-2, 2**16)}; "
          f"balanced share strictly decreasing over even n: "
          + ", ".join(f"n={n}:{s}" for n, s in balanced_seq)
          + "; both mutants rejected with witnesses.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
