#!/usr/bin/env python3
"""
E6_bayesian_updating.py -- MaxEnt / Bayesian updating read against
the census (Paper 12.5, "The Ensemble Illusion").

FULLY EXACT: every number in this script is a fractions.Fraction
(or an integer). No float is computed anywhere; there is no
continuum content to disclose. The exhibit separates two objects
that the standard prose runs together:

  - the CENSUS: counted shares of an actual declared population of
    records (frequencies = census ratios, Paper 12's rule);
  - the UPDATING RULE's output: a distribution manufactured from a
    prior and a single counted constraint (here the counted mean)
    by the maximum-entropy recipe. The rule's output is a function
    of the constraint ALONE -- exhibit (3) shows two populations
    with the same counted mean, hence the same posterior, and
    different censuses. The rule is not the census.

INPUT_PROVENANCE:
  paper-defined:
    - Record classes: energies (0, 1, 2) [paper-defined] the three
      declared record classes of the exhibit.
    - Census ratios as the population's frequencies [cited-paper]
      Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows).
  cited-paper:
    - The MaxEnt updating recipe under audit (uniform prior, single
      mean constraint, posterior proportional to (1, r, r^2) for
      equally spaced energies 0, 1, 2): the standard Jaynes-style
      construction, audited as it is standardly stated.
  control:
    - None. No tolerances: every comparison is exact.
  declared-assumption:
    - The prior is uniform over the 3 classes (declared here and in
      the paper's exhibit; it is the recipe's own starting point,
      exhibited, not smuggled).
    - The single constraint is the counted mean of census A. The
      recipe is fed the counted number; what it returns is its own.
  arbitrary-representative:
    - Census A: 14 records, energy counts (7, 6, 1). Census B: 7
      records, energy counts (5, 0, 2). Both are declared
      representatives, chosen so the two counted means coincide
      exactly (4/7) while the censuses differ -- the separation
      the exhibit turns on -- and so that NEITHER census's ratios
      coincide with the posterior in any class. (Loop repair,
      recorded: the first build's census A, counts (4, 2, 1),
      carried the posterior's own ratios, so a checker that
      copied census A passed every check undetected; the red
      team demonstrated the copycat. Census A was re-chosen and
      mutant (c) now rejects the copycat on a printed witness.)
      The algebra (factorisation, positive root, geometric
      ratios) is checked exactly, not fitted.

Checks:
  (1) Census A's counted mean is COMPUTED from its counts: 4/7.
  (2) The updating rule: mean(r) = (r + 2r^2)/(1 + r + r^2) = 4/7
      iff 10r^2 + 3r - 4 = 0; the factorisation
      10r^2 + 3r - 4 = (2r - 1)(5r + 4) is verified coefficient-wise
      in exact arithmetic; the unique positive root r = 1/2 is
      taken (the other root, -4/5, is negative and excluded as a
      weight); the posterior is computed as (4/7, 2/7, 1/7),
      verified to sum to 1, to meet the constraint exactly, to not
      be the uniform distribution, and to have exactly geometric
      ratios.
  (3) Separation exhibit: census B's counted mean is computed
      (= 4/7, the same constraint), its census ratios are
      (5/7, 0, 2/7) != posterior. Same counted mean, same posterior,
      different census. BOTH censuses' ratios are checked to
      differ from the posterior in EVERY class, by an explicit
      per-class comparison for each census (v3 strengthening,
      recorded: the v2 instrument asserted census B's difference
      only as a whole-tuple inequality while the paper's claim
      L8.7 prints the per-class wording; the per-class assert for
      census B is now in the code, so the wording stands as
      checked, not narrowed), and the two censuses are asserted
      distinct (A != B).
  Mutants: (a) posterior-as-count checker (asserts the posterior
  equals the census ratios of every population meeting the
  constraint) must be REJECTED on census B with the witness
  printed; (b) wrong-root mutant (r = -4/5) must be rejected by
  the script's own non-negativity validation for weights, with
  the negative weight printed; (c) copycat checker (discards the
  derivation and badges census A's ratios as the posterior) must
  be REJECTED on the printed inequality of ratios.

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import sys
from fractions import Fraction

ENERGIES = (0, 1, 2)
CENSUS_A_COUNTS = (7, 6, 1)
CENSUS_B_COUNTS = (5, 0, 2)


def counted_mean(counts):
    """Counted mean energy, computed from the counts."""
    total = sum(counts)
    return Fraction(sum(e * c for e, c in zip(ENERGIES, counts)), total)


def census_ratios(counts):
    total = sum(counts)
    return tuple(Fraction(c, total) for c in counts)


def posterior_mean(post):
    return sum(Fraction(e) * p for e, p in zip(ENERGIES, post))


def weights_from_r(r):
    """Unnormalised MaxEnt weights (1, r, r^2) for a candidate r;
    returns None when r yields a negative weight (a weight must be
    a non-negative share multiplier -- a negative 'weight' is not a
    distribution ingredient). This IS the script's non-negativity
    validation, used by the main derivation and the mutant alike."""
    w = (Fraction(1), r, r * r)
    if any(x < 0 for x in w):
        return None
    return w


def normalise(w):
    s = sum(w)
    return tuple(x / s for x in w)


def main():
    failures = []
    print("E6 Bayesian updating -- fully exact (Fractions; no floats)")

    # ---- (1) Census A and its counted mean -------------------------
    mean_a = counted_mean(CENSUS_A_COUNTS)
    ratios_a = census_ratios(CENSUS_A_COUNTS)
    print(f"  (1) census A: {sum(CENSUS_A_COUNTS)} records, energy "
          f"counts {CENSUS_A_COUNTS} over energies {ENERGIES}; "
          f"counted mean = {mean_a} (computed from the counts); "
          f"census ratios = {ratios_a}")
    if mean_a != Fraction(4, 7):
        failures.append(f"census A counted mean {mean_a} != 4/7")

    # ---- (2) The updating rule -------------------------------------
    # mean(r) = (r + 2r^2)/(1 + r + r^2). Setting mean(r) = 4/7:
    #   7(r + 2r^2) = 4(1 + r + r^2)  <=>  10r^2 + 3r - 4 = 0.
    # Verify the claimed factorisation coefficient-wise, exactly:
    # (2r - 1)(5r + 4) expands to (2*5) r^2 + (2*4 - 1*5) r + (-1*4).
    a2 = 2 * 5
    a1 = 2 * 4 + (-1) * 5
    a0 = (-1) * 4
    print(f"  (2) factorisation check: (2r - 1)(5r + 4) expands to "
          f"{a2}r^2 + ({a1})r + ({a0}); target polynomial "
          f"10r^2 + 3r - 4; coefficient-wise equal: "
          f"{(a2, a1, a0) == (10, 3, -4)}")
    if (a2, a1, a0) != (10, 3, -4):
        failures.append(f"factorisation expands to {(a2, a1, a0)}, "
                        f"not (10, 3, -4)")
    # Cross-check the derivation itself: 7*(r + 2r^2) - 4*(1 + r + r^2)
    # must be the same polynomial: coefficients (14-4, 7-4, -4).
    d2, d1, d0 = 7 * 2 - 4 * 1, 7 * 1 - 4 * 1, -4 * 1
    if (d2, d1, d0) != (10, 3, -4):
        failures.append(f"mean-equation polynomial {(d2, d1, d0)} != "
                        f"(10, 3, -4)")
    roots = (Fraction(1, 2), Fraction(-4, 5))  # from the two factors
    for r in roots:
        val = 10 * r * r + 3 * r - 4
        if val != 0:
            failures.append(f"claimed root {r} does not zero the "
                            f"polynomial (value {val})")
    r = Fraction(1, 2)
    print(f"      roots of 10r^2 + 3r - 4 = 0: r = 1/2 and r = -4/5 "
          f"(both verified exactly above); r = -4/5 is negative and "
          f"excluded as a weight; unique positive root r = {r}")
    w = weights_from_r(r)
    if w is None:
        failures.append("positive root r=1/2 failed non-negativity "
                        "validation -- derivation broken")
        w = (Fraction(1), r, r * r)
    posterior = normalise(w)
    print(f"      weights (1, r, r^2) at r=1/2: {w}; posterior = "
          f"{posterior} (computed by normalising)")
    if posterior != (Fraction(4, 7), Fraction(2, 7), Fraction(1, 7)):
        failures.append(f"posterior {posterior} != (4/7, 2/7, 1/7)")
    if sum(posterior) != 1:
        failures.append(f"posterior sums to {sum(posterior)} != 1")
    pm = posterior_mean(posterior)
    print(f"      posterior sums to {sum(posterior)}; posterior mean "
          f"= {pm}; constraint (census A counted mean) = {mean_a}; "
          f"meets it exactly: {pm == mean_a}")
    if pm != mean_a:
        failures.append(f"posterior mean {pm} != counted mean {mean_a}")
    uniform = (Fraction(1, 3),) * 3
    if posterior == uniform:
        failures.append("posterior equals the uniform prior -- the "
                        "rule did no work")
    else:
        print(f"      posterior != uniform prior {uniform}: the rule "
              f"did work (it moved the distribution).")
    ratios = (posterior[1] / posterior[0], posterior[2] / posterior[1])
    print(f"      successive ratios: p1/p0 = {ratios[0]}, "
          f"p2/p1 = {ratios[1]}; geometric with ratio r = {r}: "
          f"{ratios == (r, r)}")
    if ratios != (r, r):
        failures.append(f"posterior ratios {ratios} != (r, r) = "
                        f"{(r, r)} -- not geometric")
    if not all(x != y for x, y in zip(ratios_a, posterior)):
        failures.append("census A ratios do not differ from the "
                        "posterior in every class -- the exhibit's "
                        "derivation is not cleanly distinguished "
                        "from copying census A")
    else:
        print(f"      (checked: census A's ratios {ratios_a} differ "
              f"from the posterior {posterior} in every class; the "
              f"derivation is not a copy of its feeding census.)")
    if CENSUS_A_COUNTS == CENSUS_B_COUNTS:
        failures.append("censuses A and B are identical populations "
                        "-- the separation exhibit has one census, "
                        "not two")

    # ---- (3) Separation exhibit ------------------------------------
    mean_b = counted_mean(CENSUS_B_COUNTS)
    ratios_b = census_ratios(CENSUS_B_COUNTS)
    arith = "(" + " + ".join(f"{e}*{c}" for e, c
                              in zip(ENERGIES, CENSUS_B_COUNTS)) \
            + f")/{sum(CENSUS_B_COUNTS)}"
    print(f"  (3) census B: {sum(CENSUS_B_COUNTS)} records, energy "
          f"counts {CENSUS_B_COUNTS}; counted mean = "
          f"{arith} = {mean_b} (computed -- the SAME "
          f"constraint); census ratios = {ratios_b}; posterior "
          f"(same constraint, same rule) = {posterior}; "
          f"census != posterior: {ratios_b != posterior}")
    if mean_b != mean_a:
        failures.append(f"census B counted mean {mean_b} != census A "
                        f"counted mean {mean_a}")
    if ratios_b == posterior:
        failures.append("census B ratios equal the posterior -- "
                        "separation exhibit broken")
    # v3 strengthening: per-class difference for census B, asserted
    # class by class exactly as for census A in check (2) -- the
    # paper's claim L8.7 prints "differing from the posterior in
    # every class" for census B, and the instrument now checks
    # precisely that, not merely the whole-tuple inequality above.
    if not all(x != y for x, y in zip(ratios_b, posterior)):
        failures.append("census B ratios do not differ from the "
                        "posterior in every class -- the per-class "
                        "wording of claim L8.7 is not backed")
    else:
        print(f"      (checked per class: census B's ratios "
              f"{ratios_b} differ from the posterior {posterior} "
              f"in every class -- class 0: {ratios_b[0]} != "
              f"{posterior[0]}; class 1: {ratios_b[1]} != "
              f"{posterior[1]}; class 2: {ratios_b[2]} != "
              f"{posterior[2]}.)")
    print("      Print: same counted mean, same posterior, different "
          "census -- the rule is not the census.")

    # ---- Mutant battery --------------------------------------------
    print("  mutant battery:")
    # (a) Posterior-as-count checker: asserts the posterior equals
    # the census ratios of EVERY population meeting the constraint.
    # Census B meets the constraint (mean 4/7, verified above) and
    # its ratios differ -- the checker is refuted by that witness.
    checker_claim_holds = (ratios_b == posterior)
    if not checker_claim_holds and mean_b == mean_a:
        print(f"    MUTANT(a) REJECTED: posterior-as-count checker "
              f"claims posterior == census ratios for every "
              f"population meeting the constraint; witness census B: "
              f"counts {CENSUS_B_COUNTS}, counted mean {mean_b} "
              f"(meets the constraint), census ratios {ratios_b} != "
              f"posterior {posterior}")
    else:
        failures.append("mutant (a) posterior-as-count checker was "
                        "NOT rejected")
    # (b) Wrong-root mutant: build the 'posterior' from r = -4/5.
    r_bad = Fraction(-4, 5)
    w_bad_raw = (Fraction(1), r_bad, r_bad * r_bad)
    w_bad = weights_from_r(r_bad)
    if w_bad is None:
        print(f"    MUTANT(b) REJECTED: wrong root r = {r_bad} yields "
              f"raw weights {w_bad_raw} -- the second weight is "
              f"negative ({r_bad}); non-negativity validation "
              f"rejects it (no distribution can be built from it)")
    else:
        failures.append("mutant (b) wrong-root weights passed "
                        "non-negativity validation")
    # (c) Copycat checker: discards the derivation and badges
    # census A's ratios as the posterior. Rejected on the printed
    # inequality -- census A is a population meeting the constraint
    # whose ratios are not the rule's output.
    copycat = ratios_a
    if copycat != posterior and mean_a == Fraction(4, 7):
        print(f"    MUTANT(c) REJECTED: copycat checker badges "
              f"census A's ratios {copycat} as the posterior; the "
              f"derived posterior is {posterior}; the two differ "
              f"in every class, and census A meets the constraint "
              f"(counted mean {mean_a}) -- copying the feeding "
              f"census is not deriving the rule's output")
    else:
        failures.append("mutant (c) copycat checker was NOT "
                        "rejected (census A ratios == posterior)")

    if failures:
        print("E6 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"E6 PASS: census A counted mean computed = 4/7; "
          f"factorisation 10r^2 + 3r - 4 = (2r - 1)(5r + 4) verified "
          f"coefficient-wise; unique positive root r = 1/2 (root "
          f"-4/5 excluded as a weight); posterior computed = "
          f"(4/7, 2/7, 1/7), sums to 1, meets the constraint "
          f"exactly, is not uniform, ratios exactly geometric; "
          f"census B: same counted mean 4/7, same posterior, census "
          f"ratios (5/7, 0, 2/7) differing from the posterior in "
          f"every class (asserted per class) -- the rule is not the "
          f"census; all three mutants rejected with witnesses. Fully "
          f"exact: no float computed anywhere.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
