#!/usr/bin/env python3
"""
E5_quantum_census.py -- Stage P/C audit instrument for Paper 12.5
("The Ensemble Illusion"): the density operator read as a census
object, and what its form does and does not record.

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C audit instrument, in the same class as
  the M-series (M1/M2). It audits the STANDARD quantum-statistical
  machinery on its own terms. It is NEVER a native (Stage N)
  derivation, and NOTHING native is badged on this instrument: no
  printed line here is a claim about the ledger framework's own
  populations or ontology.

WHAT IS EXACT, WHAT IS FLOAT, AND WHY (disclosure, per section
0.5.4's M-series precedent):
  - EXACT (fractions.Fraction throughout): every density matrix,
    eigenvalue, marginal, and trace distance in this script. The
    declared populations are finite counts; their census operators
    have rational entries, and the partial trace over the 4-dim
    pair space is carried out entry-by-entry in rational arithmetic.
  - FLOAT (math.log, disclosed continuum content): the von Neumann
    entropy VALUES S(rho) = -Tr(rho ln rho) only. A logarithm of a
    rational eigenvalue is generically irrational, so no exact
    rational value exists to compute; the float entropy values are
    this exhibit's disclosed continuum content, exhibited as the
    standard machinery's own output, never as census arithmetic.
    Entropy comparisons therefore use a declared tolerance
    (TOL_ENT = 1e-9) and, for the headline gap, a wide margin
    (the computed gap exceeds 0.5 nats; the tolerance is not load-
    bearing for that verdict).

INPUT_PROVENANCE:
  paper-defined:
    - The census reading of rho: for a declared population of
      two-level systems with counted preparations, rho_census is
      the diagonal operator whose entries are the counted shares
      (Paper 12 census rule applied to the preparation record).
    - Exhibit (3)'s conclusion form: two preparations with the
      same marginals and different joint entropies show that rho's
      form does not record its provenance -- the audit point this
      instrument computes.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the census operators here are
      that rule applied to the declared preparation counts.
  control:
    - TOL_ENT = 1e-9 (float entropy agreement tolerance, declared
      here, before any run).
    - GAP_MARGIN = 1/2 nat (the exhibit (1) entropy gap must exceed
      this; declared here, before any run).
  declared-assumption:
    - Basis order for the pair space is (00, 01, 10, 11); marginals
      are taken over the second system. The checked equalities are
      basis-labelling facts of this declared order only.
  arbitrary-representative:
    - Population sizes 12 (single systems) and 12 (pairs), and the
      specific counts (9, 3), (6, 6), (6 x 00, 6 x 11): declared
      representatives chosen so every share is a small rational;
      the structural conclusions (entropy attaches to the
      ascription; form does not record provenance) do not depend
      on the particular counts.

Checks:
  (1) Faulty preparer: census vs pure ascription -- eigenvalues,
      trace distance exactly 1/4, entropy gap > 1/2 nat.
  (2) Honest mixture: ascription == census, distance 0, entropies
      agree within TOL_ENT.
  (3) Provenance pair: mixture vs pure entangled ascription --
      marginal matrices identical exactly; joint entropies differ
      (ln 2 vs 0, floats).
  (4) Tomography note: the Z-basis run counts (9, 3) reconstruct
      exactly the census diagonal of exhibit (1).
  Mutants: (a) ascription-substitution checker (badges the pure
  ascription's entropy as the population's) must be REJECTED on
  exhibit (1) with its error printed; (b) a trace-5/4 rho candidate
  must be rejected by this script's own validation.

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import math
import sys
from fractions import Fraction

TOL_ENT = 1e-9
GAP_MARGIN = Fraction(1, 2)  # nats; float-compared, see header


# ---------- exact rational matrix helpers (small, dense) ----------

def mat(rows):
    return [[Fraction(x) for x in row] for row in rows]


def trace(m):
    return sum(m[i][i] for i in range(len(m)))


def diag_eigs_diag(m):
    """Eigenvalues of a DIAGONAL exact matrix: its diagonal entries.
    Used only where the matrix is diagonal by construction; the
    caller asserts diagonality first (off_diag_zero)."""
    return [m[i][i] for i in range(len(m))]


def off_diag_zero(m):
    return all(m[i][j] == 0
               for i in range(len(m)) for j in range(len(m)) if i != j)


def is_psd_exact(m):
    """Exact positive-semidefiniteness test for a symmetric matrix
    of Fractions, by LDL^T decomposition: PSD iff every pivot is
    >= 0 and every zero pivot has a zero column beneath it.
    (Loop repair: validation previously checked trace and diagonal
    entries only, and admitted non-positive candidates such as
    [[1/2, 2], [2, 1/2]] -- eigenvalue -3/2. D.1.2 prices rho >= 0
    as a headline symbol; the instrument now validates it.)"""
    n = len(m)
    a = [[Fraction(m[i][j]) for j in range(n)] for i in range(n)]
    for k in range(n):
        piv = a[k][k]
        if piv < 0:
            return False
        if piv == 0:
            if any(a[i][k] != 0 for i in range(k + 1, n)):
                return False
            continue
        for i in range(k + 1, n):
            f = a[i][k] / piv
            for j in range(k, n):
                a[i][j] -= f * a[k][j]
    return True


def validate_rho(m, label, failures):
    """A density operator candidate: square, symmetric, trace
    exactly 1, diagonal entries (populations-in-basis) in [0, 1],
    and positive semidefinite (exact test). Returns True iff
    valid; on failure appends a witness and returns False."""
    n = len(m)
    if any(len(row) != n for row in m):
        failures.append(f"{label}: not square")
        return False
    for i in range(n):
        for j in range(n):
            if m[i][j] != m[j][i]:
                failures.append(f"{label}: not symmetric at ({i},{j})")
                return False
    tr = trace(m)
    if tr != 1:
        failures.append(f"{label}: trace {tr} != 1")
        return False
    for i in range(n):
        if not (0 <= m[i][i] <= 1):
            failures.append(f"{label}: diagonal entry {m[i][i]} outside [0,1]")
            return False
    if not is_psd_exact(m):
        failures.append(f"{label}: not positive semidefinite "
                        f"(exact LDL^T test failed)")
        return False
    return True


def trace_distance_diag(p, q):
    """Trace distance between two DIAGONAL operators, exactly:
    (1/2) * sum_i |p_ii - q_ii|. Callers assert diagonality."""
    return sum(abs(p[i][i] - q[i][i]) for i in range(len(p))) / 2


def von_neumann_entropy(eigs):
    """FLOAT -- disclosed continuum content (see header). Eigenvalues
    are exact Fractions; S = -sum lambda ln lambda (0 ln 0 := 0),
    computed in floats because ln of a rational is generically
    irrational. Nats."""
    s = 0.0
    for lam in eigs:
        x = float(lam)
        if x > 0.0:
            s -= x * math.log(x)
    return s


def partial_trace_second(rho4):
    """Exact partial trace over the second system of a 4x4 operator
    in basis (00, 01, 10, 11). (Tr_B rho)_{a,a'} = sum_b rho_{ab,a'b},
    all entries Fractions."""
    out = [[Fraction(0), Fraction(0)], [Fraction(0), Fraction(0)]]
    for a in range(2):
        for ap in range(2):
            out[a][ap] = sum(rho4[2 * a + b][2 * ap + b] for b in range(2))
    return out


def census_rho(counts):
    """Census operator from counted preparations: diagonal, entries
    = counted shares, computed from the counts (never asserted)."""
    total = sum(counts)
    return mat([[Fraction(counts[0], total) if i == j == 0 else
                 Fraction(counts[1], total) if i == j == 1 else 0
                 for j in range(2)] for i in range(2)])


def main():
    failures = []
    print("E5 quantum census -- Stage P/C audit instrument "
          "(exact Fractions; float entropies disclosed)")

    # ---- (1) Faulty preparer -------------------------------------
    # Declared population: 12 two-level systems, preparation counts
    # (9 up, 3 down). The preparer ASCRIBES the pure state "all up".
    counts1 = (9, 3)
    rho_census = census_rho(counts1)
    rho_ascribed = mat([[1, 0], [0, 0]])
    if not validate_rho(rho_census, "exhibit(1) census rho", failures):
        pass  # failure already recorded; continue to print what we can
    validate_rho(rho_ascribed, "exhibit(1) ascribed rho", failures)
    if not off_diag_zero(rho_census) or not off_diag_zero(rho_ascribed):
        failures.append("exhibit(1): an operator is not diagonal")
    eigs_census = diag_eigs_diag(rho_census)
    eigs_ascribed = diag_eigs_diag(rho_ascribed)
    print(f"  (1) faulty preparer: counts={counts1} of 12; "
          f"census eigenvalues={eigs_census} (computed shares "
          f"{counts1[0]}/12, {counts1[1]}/12); ascribed pure "
          f"eigenvalues={eigs_ascribed}")
    if eigs_census != [Fraction(3, 4), Fraction(1, 4)]:
        failures.append(f"exhibit(1): census eigenvalues {eigs_census} "
                        f"!= (3/4, 1/4)")
    if eigs_ascribed != [Fraction(1), Fraction(0)]:
        failures.append(f"exhibit(1): ascribed eigenvalues {eigs_ascribed} "
                        f"!= (1, 0)")
    td1 = trace_distance_diag(rho_census, rho_ascribed)
    print(f"      trace distance census<->ascription = {td1} (exact)")
    if td1 != Fraction(1, 4):
        failures.append(f"exhibit(1): trace distance {td1} != 1/4")
    s_census = von_neumann_entropy(eigs_census)      # FLOAT, disclosed
    s_ascribed = von_neumann_entropy(eigs_ascribed)  # FLOAT, disclosed
    gap = s_census - s_ascribed
    print(f"      S(census rho) = {s_census:.6f} nats (float); "
          f"S(ascription) = {s_ascribed:.6f} nats (float); "
          f"gap = {gap:.6f} > {float(GAP_MARGIN)} required")
    if not (gap > float(GAP_MARGIN)):
        failures.append(f"exhibit(1): entropy gap {gap} does not exceed "
                        f"{float(GAP_MARGIN)} nats")
    print("      Reading: the entropy number attaches to the "
          "ASCRIPTION placed on the population, not to the counted "
          "population itself: same bench, same 12 systems, two "
          "numbers differing by more than half a nat.")

    # ---- (2) Honest mixture ---------------------------------------
    counts2 = (6, 6)
    rho_census2 = census_rho(counts2)
    rho_ascribed2 = census_rho(counts2)  # the honest ascription IS the census
    validate_rho(rho_census2, "exhibit(2) census rho", failures)
    eigs2 = diag_eigs_diag(rho_census2)
    td2 = trace_distance_diag(rho_census2, rho_ascribed2)
    s2_census = von_neumann_entropy(eigs2)
    s2_ascribed = von_neumann_entropy(diag_eigs_diag(rho_ascribed2))
    print(f"  (2) honest mixture: counts={counts2} of 12; census "
          f"eigenvalues={eigs2}; ascription == census; trace "
          f"distance = {td2} (exact); S(census)={s2_census:.6f}, "
          f"S(ascription)={s2_ascribed:.6f} (floats), "
          f"|diff|={abs(s2_census - s2_ascribed):.3e} <= tol {TOL_ENT}")
    if eigs2 != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(2): census eigenvalues {eigs2} != (1/2, 1/2)")
    if rho_ascribed2 != rho_census2 or td2 != 0:
        failures.append("exhibit(2): ascription != census or distance != 0")
    if abs(s2_census - s2_ascribed) > TOL_ENT:
        failures.append("exhibit(2): entropies disagree beyond tolerance")

    # ---- (3) Provenance pair --------------------------------------
    # Preparation census of 12 pairs: counts (6 x 00, 6 x 11).
    # Joint census operator in basis (00, 01, 10, 11), computed from
    # the counts.
    pair_counts = {(0, 0): 6, (1, 1): 6}
    total_pairs = sum(pair_counts.values())
    joint_mix = [[Fraction(0)] * 4 for _ in range(4)]
    for (a, b), c in pair_counts.items():
        joint_mix[2 * a + b][2 * a + b] = Fraction(c, total_pairs)
    validate_rho(joint_mix, "exhibit(3) mixture joint rho", failures)
    if not off_diag_zero(joint_mix):
        failures.append("exhibit(3): mixture joint rho is not diagonal")
    joint_eigs_mix = sorted(diag_eigs_diag(joint_mix), reverse=True)
    support_eigs = [e for e in joint_eigs_mix if e != 0]
    marg_mix = partial_trace_second(joint_mix)
    # Pure entangled ascription |Phi+> = (|00> + |11>)/sqrt(2):
    # |Phi+><Phi+| has entries 1/2 at the four corners (00/11 block),
    # 0 elsewhere -- exact Fractions, since amplitudes squared and
    # cross terms are (1/sqrt2)(1/sqrt2) = 1/2.
    joint_pure = [[Fraction(0)] * 4 for _ in range(4)]
    for i in (0, 3):
        for j in (0, 3):
            joint_pure[i][j] = Fraction(1, 2)
    validate_rho(joint_pure, "exhibit(3) pure joint rho", failures)
    marg_pure = partial_trace_second(joint_pure)
    print(f"  (3) provenance pair: 12 pairs, counts (6 x 00, 6 x 11); "
          f"mixture joint eigenvalues on support = {support_eigs}; "
          f"marginal (mixture) = {marg_mix}; "
          f"marginal (|Phi+>) = {marg_pure}")
    if support_eigs != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(3): mixture support eigenvalues "
                        f"{support_eigs} != [1/2, 1/2]")
    marg_eigs = diag_eigs_diag(marg_mix) if off_diag_zero(marg_mix) else None
    if marg_eigs != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(3): mixture marginal eigenvalues "
                        f"{marg_eigs} != (1/2, 1/2)")
    if marg_mix != marg_pure:
        failures.append(f"exhibit(3): marginals differ: mixture "
                        f"{marg_mix} vs pure {marg_pure}")
    # Joint entropies (FLOATS, disclosed): the pure operator is pure
    # by construction -- its spectrum is computed from its exact
    # trace and its exact purity Tr(rho^2) = 1 (a pure operator's
    # spectrum is (1, 0, 0, 0)); the mixture's spectrum is its
    # diagonal.
    purity = sum(joint_pure[i][j] * joint_pure[j][i]
                 for i in range(4) for j in range(4))
    if purity != 1 or trace(joint_pure) != 1:
        failures.append(f"exhibit(3): pure candidate purity {purity} "
                        f"/ trace {trace(joint_pure)} -- not pure")
    s_joint_mix = von_neumann_entropy(joint_eigs_mix)
    s_joint_pure = von_neumann_entropy([Fraction(1), Fraction(0),
                                        Fraction(0), Fraction(0)])
    print(f"      joint S(mixture) = {s_joint_mix:.6f} nats (float; "
          f"ln 2 = {math.log(2):.6f}); joint S(|Phi+>) = "
          f"{s_joint_pure:.6f} nats (float); marginals identical "
          f"exactly, joint entropies differ by "
          f"{s_joint_mix - s_joint_pure:.6f}")
    if abs(s_joint_mix - math.log(2)) > TOL_ENT:
        failures.append("exhibit(3): mixture joint entropy != ln 2 "
                        "within tolerance")
    if abs(s_joint_pure) > TOL_ENT:
        failures.append("exhibit(3): pure joint entropy != 0 within "
                        "tolerance")
    if not (s_joint_mix - s_joint_pure > float(GAP_MARGIN)):
        failures.append("exhibit(3): joint entropy difference does "
                        "not exceed the declared margin")
    print("      Conclusion (the exhibit's): the marginal rho's form "
          "is identical for the counted mixture and the pure "
          "ascription -- rho's form does not record its provenance.")

    # ---- (4) Tomography note --------------------------------------
    # From the declared Z-basis run counts -- the (9, 3) census of
    # exhibit (1) itself -- the reconstructed diagonal is the counted
    # shares. One line: no new machinery.
    recon = [Fraction(counts1[0], sum(counts1)),
             Fraction(counts1[1], sum(counts1))]
    census_diag = [rho_census[i][i] for i in range(2)]
    print(f"  (4) tomography note: Z-basis counts {counts1} reconstruct "
          f"diagonal {recon}; census diagonal {census_diag}; "
          f"equal exactly: {recon == census_diag}")
    if recon != census_diag:
        failures.append("exhibit(4): reconstructed diagonal != census "
                        "diagonal")

    # ---- Mutant battery -------------------------------------------
    print("  mutant battery:")
    # (a) Ascription-substitution mutant: a checker that badges the
    # claimed pure ascription's entropy as the population's entropy.
    # Run against exhibit (1): its reported value is S(ascription);
    # the population's census entropy differs by the gap.
    mutant_reported = s_ascribed
    mutant_error = abs(mutant_reported - s_census)
    if mutant_error > float(GAP_MARGIN):
        print(f"    MUTANT(a) REJECTED: ascription-substitution badges "
              f"S = {mutant_reported:.6f} nats as the population's "
              f"entropy; the census entropy is {s_census:.6f} nats; "
              f"error {mutant_error:.6f} > margin "
              f"{float(GAP_MARGIN)} (witness: exhibit (1), counts "
              f"{counts1})")
    else:
        failures.append("mutant (a) ascription-substitution was NOT "
                        "rejected")
    # (b) Trace mutant: a rho candidate with trace 5/4 must be
    # rejected by this script's own validation.
    bad = mat([[Fraction(3, 4), 0], [0, Fraction(1, 2)]])
    bad_failures = []
    ok = validate_rho(bad, "mutant(b) candidate", bad_failures)
    if not ok and any("trace" in f for f in bad_failures):
        print(f"    MUTANT(b) REJECTED: candidate diag(3/4, 1/2) has "
              f"trace {trace(bad)} != 1 -- validation witness: "
              f"{bad_failures[0]}")
    else:
        failures.append("mutant (b) trace-5/4 candidate was NOT "
                        "rejected by validation")
    # (c) Non-positive candidate: trace 1, diagonal entries in
    # [0, 1], symmetric -- but eigenvalue -3/2 (det = -15/4 < 0).
    # Must be rejected by the positivity leg of validation.
    bad3 = mat([[Fraction(1, 2), 2], [2, Fraction(1, 2)]])
    bad3_failures = []
    ok3 = validate_rho(bad3, "mutant(c) candidate", bad3_failures)
    det3 = bad3[0][0] * bad3[1][1] - bad3[0][1] * bad3[1][0]
    if not ok3 and any("positive" in f for f in bad3_failures):
        print(f"    MUTANT(c) REJECTED: candidate [[1/2, 2], [2, 1/2]] "
              f"has trace 1 and diagonal entries in [0,1] but "
              f"det = {det3} < 0 (eigenvalue -3/2) -- validation "
              f"witness: {bad3_failures[0]}")
    else:
        failures.append("mutant (c) non-positive candidate was NOT "
                        "rejected by validation")

    if failures:
        print("E5 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"E5 PASS: (1) census eigenvalues (3/4, 1/4) vs ascribed "
          f"(1, 0), trace distance exactly 1/4, entropy gap "
          f"{gap:.6f} nats > 0.5 (floats, disclosed); (2) honest "
          f"mixture distance exactly 0, entropies agree; (3) "
          f"provenance pair: marginals identical exactly "
          f"(diag(1/2, 1/2) by exact partial trace), joint entropies "
          f"ln 2 vs 0 -- rho's form does not record its provenance; "
          f"(4) Z-basis reconstruction equals the census diagonal "
          f"exactly; all three mutants rejected with witnesses. Stage P/C "
          f"instrument: nothing native is badged on it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
