#!/usr/bin/env python3
"""
G4_rewrite_pairs.py -- document check for Paper 12.5
("The Ensemble Illusion"), section 1.3.6 rewrite pairs.

PURPOSE: section 1.3.6 exhibits the paper's method in miniature:
six standard idioms, each printed as found (Account A, an exhibit,
quotation-marked) and rewritten in census form (Account B). This
check proves the assembled paper's table is complete and that
every Account B actually is a census form: it speaks of a declared
population over a declared window, carries none of the banned
micro/macro vocabulary, and uses no probability language at all
(the framework adopts no probability postulate; the rewrites are
written to satisfy this, and this script enforces it).

CHECKS:
  (1) Locate "### 1.3.6"; parse its table by the exact header
        | # | Account A — the idiom as printed (exhibit) | Account B — the census form | What changed |
      (em-dashes as printed; this header string is the spec -- if
      the assembled paper differs, assembly aligns the paper to it).
  (2) Assert exactly 6 pair rows, numbered 1-6. For each row:
      - Account A cell is non-empty and contains a double-quote
        character (the exhibit marking);
      - Account B cell contains "population" and "window"
        (case-insensitive);
      - Account B cell contains NO match of the micro/macro regex
        micro\\w*scopic|macro\\w*scopic (case-insensitive);
      - Account B cell does not contain "probabilit" at all
        (case-insensitive).

MUTANT BATTERY (built in, run on synthetic rows, not the paper):
  five planted defective rows must each be CAUGHT by the same row
  check used on the paper -- (a) a B cell without "window",
  (b) a B cell carrying a banned micro/macro token, (c) an A cell
  without quotation marks, (d) a B cell carrying probability
  language, (e) a B cell without "population" -- and one clean
  synthetic row must pass. (Header corrected in v3: the v1/v2
  header named only the first three classes after the battery was
  completed to five.)

INPUT_PROVENANCE:
  paper-defined:
    - The six rewrite pairs and their four-column shape: Paper
      12.5 section 1.3.6 as assembled (the document side of this
      check audits that text; the header string is the layout
      contract, copied exactly from the drafting spec).
    - The B-cell conditions: the paper's own census form (a
      declared population, a declared window), Paper 12's standing
      no-micro/macro correction, and the framework's no-probability-
      postulate rule (cf. FW1 ban (c)).
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the form Account B must take;
      contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      default path relative to this script.
  declared-assumption:
    - The rewrite-pairs table is the table in section 1.3.6 whose
      header row equals the exact header string above; data rows
      are the following pipe rows up to the first non-pipe line.
  arbitrary-representative:
    - The battery's synthetic rows: representatives of each
      failure class, not quotations from any source.

Exit 0 iff the battery passes AND the paper table passes.
Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

TABLE_HEADER = ("| # | Account A — the idiom as printed (exhibit) | "
                "Account B — the census form | What changed |")
MICRO_RE = re.compile(r"micro\w*scopic|macro\w*scopic", re.IGNORECASE)
N_PAIRS = 6


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def section_136_lines(lines):
    """Lines of section 1.3.6: from the '### 1.3.6' heading to the
    next heading of level <= 3 (or end of file)."""
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("### 1.3.6"):
            start = i
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if re.match(r"^#{1,3}\s", lines[j]):
            end = j
            break
    return lines[start:end]


def pairs_table_rows(sec_lines):
    """Data rows (cell lists) of the rewrite-pairs table, found by
    its exact header. None if the header is absent."""
    if sec_lines is None:
        return None
    for i, line in enumerate(sec_lines):
        if line.strip() == TABLE_HEADER:
            rows = []
            for nxt in sec_lines[i + 1:]:
                s = nxt.strip()
                if not s.startswith("|"):
                    break
                if set(s) <= set("|-: "):
                    continue  # separator row
                rows.append(split_cells(nxt))
            return rows
    return None


def check_row(cells):
    """Check (2) for one row: returns a list of violation strings.
    cells = [#, Account A, Account B, What changed]."""
    violations = []
    if len(cells) < 4:
        return [f"row has {len(cells)} cells (< 4): {cells}"]
    a_cell, b_cell = cells[1], cells[2]
    if not a_cell:
        violations.append("Account A cell is empty")
    elif '"' not in a_cell:
        violations.append("Account A cell carries no double-quote "
                          "(exhibit marking missing)")
    low_b = b_cell.lower()
    if "population" not in low_b:
        violations.append('Account B cell does not contain '
                          '"population"')
    if "window" not in low_b:
        violations.append('Account B cell does not contain "window"')
    m = MICRO_RE.search(b_cell)
    if m:
        violations.append(f"Account B cell carries the banned token "
                          f"{m.group(0)!r} (micro/macro vocabulary)")
    if "probabilit" in low_b:
        violations.append('Account B cell contains "probabilit..." '
                          "(probability language is banned in the "
                          "census form)")
    return violations


def check_table(sec_lines):
    """Checks (1)+(2) over a section's lines: returns violations."""
    violations = []
    rows = pairs_table_rows(sec_lines)
    if rows is None:
        return ["section 1.3.6 heading or rewrite-pairs table header "
                "not found"]
    if len(rows) != N_PAIRS:
        violations.append(f"rewrite-pairs table has {len(rows)} data "
                          f"rows, expected exactly {N_PAIRS}")
    for idx, cells in enumerate(rows, start=1):
        num = cells[0] if cells else ""
        if num != str(idx):
            violations.append(f"row {idx} is numbered {num!r}, "
                              f"expected {idx}")
        for v in check_row(cells):
            violations.append(f"row {idx}: {v}")
    return violations


# ---- mutant battery: synthetic rows --------------------------------

CLEAN_ROW = ["1", '"The ensemble average gives the pressure."',
             "The counted share of records in the declared "
             "population over the declared window gives the mean.",
             "Idiom replaced by a census ratio."]


def run_battery():
    failures = []
    if check_row(CLEAN_ROW):
        failures.append(f"battery control row did not pass: "
                        f"{check_row(CLEAN_ROW)}")
    mutants = [
        ("B cell without \"window\"",
         ["2", '"quoted idiom"', "The counted share of the declared "
          "population gives the mean.", "change"]),
        ("B cell with a banned token",
         ["3", '"quoted idiom"', "The macroscopic population over "
          "the declared window is counted.", "change"]),
        ("A cell without quotes",
         ["4", "The ensemble average gives the pressure.",
          "The counted share of the declared population over the "
          "declared window.", "change"]),
        ("B cell with probability language",
         ["5", '"quoted idiom"', "The probability that a record of "
          "the declared population falls in the class, over the "
          "declared window.", "change"]),
        ("B cell without \"population\"",
         ["6", '"quoted idiom"', "The counted share of records over "
          "the declared window gives the mean.", "change"]),
    ]
    for label, row in mutants:
        v = check_row(row)
        if not v:
            failures.append(f"mutant NOT caught: {label}")
        else:
            print(f"  battery: MUTANT REJECTED ({label}): {v[0]}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G4 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print("G4 battery: PASS (5 planted defective rows caught, clean "
          "row passed)")

    path = resolve_path()
    if not path.is_file():
        print(f"G4 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    sec = section_136_lines(lines)
    violations = check_table(sec)
    if violations:
        print(f"G4 VIOLATIONS ({len(violations)}) for {path}:")
        for v in violations:
            print(f"  - {v}")
        return 1
    rows = pairs_table_rows(sec)
    print(f"G4 PASS: {path}: section 1.3.6 rewrite-pairs table has "
          f"exactly {len(rows)} rows numbered 1-6; every Account A "
          f"is a quoted exhibit; every Account B names a population "
          f"and a window, carries no micro/macro token and no "
          f"probability language; battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
