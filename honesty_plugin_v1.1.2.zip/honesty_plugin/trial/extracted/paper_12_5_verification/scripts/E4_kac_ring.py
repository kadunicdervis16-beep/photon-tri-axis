#!/usr/bin/env python3
"""
E4_kac_ring.py -- Kac ring, exact and exhaustive at small size.

INPUT_PROVENANCE:
  - N range 4..10                                  [control] declared range;
    exhaustive means ALL cases in this range (count printed, formula-checked).
  - Ring of N sites, balls black/white, F flippers on edges
                                                   [paper-defined] Kac-ring
    census/dynamics as stated in the task: each step every ball moves one
    site clockwise; crossing a flipper toggles its color.
  - Encoding                                       [declared-assumption] a
    representation choice, verified equivalent by a slow list-based
    simulator on N=4..6 (cross-check inside this script): colors are a
    bitmask v (bit i = color at site i, 1 = black); a step sends
    v -> rot1(v) XOR rot1(Fmask), where rot1 moves bit i to site i+1
    (mod N) and Fmask has bit i set iff a flipper sits on edge i->i+1.
    A ball arriving at site i+1 came across edge i, so the toggle mask
    is the flipper mask rotated with the balls.
  - Balanced count(s)                              [paper-defined] for even N,
    b = N/2; for odd N, b in {floor(N/2), ceil(N/2)} (the closest counts).

WHAT THIS SCRIPT CHECKS (verified domain):
  (a) EXACT RECURRENCE, exhaustively: for every N in 4..10, every initial
  coloring (2^N) and every flipper placement (2^N placements, F=0..N),
  the coloring after 2N steps equals the initial coloring.
  (b) NON-MONOTONICITY: at least one concrete witness where the distance
  |b(t) - N/2| (exact Fraction) INCREASES from t to t+1.
  (c) TIME-SHARE: per case, the exact share (Fraction) of the 2N states
  t=0..2N-1 sitting at a balanced count; the script reports the MINIMUM
  over all cases (per N and overall).
WHAT THIS SCRIPT DOES NOT ASSERT: any monotone drift, approach, or
  equilibration theorem. Recurrence and non-monotone excursions are both
  counting facts of the same exhaustive census; nothing here supports a
  drift reading, and the script asserts none.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Larger N (checked only 4..10), stochastic/continuous Kac variants, and
  any thermodynamic reading of b(t).
MUTANT DISCLOSURE (honest limitation, stated in-script as required):
  A STATIC removal of the toggle on one edge is merely another flipper
  placement, which also recurs at 2N -- it cannot serve as a recurrence-
  breaking mutant, and this script says so rather than faking a witness.
  The mutant actually tested is the placement-persistence violation the
  instruction points at: the edge-0 flipper's rule is REMOVED after the
  first lap (it toggles during steps 1..N and is gone for steps
  N+1..2N). That dynamics must break recurrence, and a concrete witness
  is searched for exhaustively at N=4 and printed.
"""
import sys
from fractions import Fraction
from itertools import combinations
from math import comb


def rot1(v, N, mask_all):
    return ((v << 1) & mask_all) | (v >> (N - 1))


def slow_step(colors, flippers, N):
    """List-based reference step: colors[i] = color at site i; ball at
    site i moves to i+1, toggling iff flippers[i] (edge i->i+1)."""
    nxt = [None] * N
    for i in range(N):
        c = colors[i] ^ (1 if flippers[i] else 0)
        nxt[(i + 1) % N] = c
    return nxt


def main():
    failures = []
    print("E4 Kac ring -- exhaustive, N = 4..10")

    # --- Encoding cross-check: bitmask dynamics == slow simulator -------
    for N in range(4, 7):
        mask_all = (1 << N) - 1
        for v in range(1 << N):
            colors = [(v >> i) & 1 for i in range(N)]
            for fmask in range(1 << N):
                flippers = [bool((fmask >> i) & 1) for i in range(N)]
                slow = slow_step(colors, flippers, N)
                fast = rot1(v, N, mask_all) ^ rot1(fmask, N, mask_all)
                fast_colors = [(fast >> i) & 1 for i in range(N)]
                if slow != fast_colors:
                    failures.append(f"encoding mismatch N={N} v={v} fmask={fmask}")
    if failures:
        print("E4 FAIL (encoding cross-check):")
        for f in failures[:5]:
            print(f"  - {f}")
        return 1
    print("  encoding cross-check: bitmask step == list simulator for all "
          "colorings/placements, N=4..6")

    witness_b = None          # (N, fmask, v0, t, b_t, b_t1, dist_t, dist_t1)
    total_cases = 0
    global_min_share = None
    global_min_case = None

    for N in range(4, 11):
        mask_all = (1 << N) - 1
        period = 2 * N
        half = Fraction(N, 2)
        if N % 2 == 0:
            balanced = {N // 2}
        else:
            balanced = {N // 2, N // 2 + 1}
        cases_N = 0
        min_share_N = None
        # Enumerate flipper placements by F then by combination, so the
        # placement census is visibly C(N,F)-structured.
        placements = []
        for F in range(N + 1):
            for edges in combinations(range(N), F):
                fm = 0
                for e in edges:
                    fm |= (1 << e)
                placements.append(fm)
        if len(placements) != 2 ** N or len(set(placements)) != 2 ** N:
            failures.append(f"N={N}: placements {len(placements)} != 2^N")
        placement_count_check = sum(comb(N, F) for F in range(N + 1))
        if placement_count_check != len(placements):
            failures.append(f"N={N}: sum C(N,F) {placement_count_check} != placements")

        for fmask in placements:
            rf = rot1(fmask, N, mask_all)
            for v0 in range(1 << N):
                cases_N += 1
                v = v0
                balanced_steps = 0
                prev_dist = None
                b_prev = None
                # States t = 0..2N-1 for the share; run one extra step
                # bookkeeping inside the loop for (b), and finish at 2N
                # for recurrence.
                for t in range(period):
                    b = v.bit_count()
                    if b in balanced:
                        balanced_steps += 1
                    dist = abs(Fraction(b) - half)
                    if (witness_b is None and prev_dist is not None
                            and dist > prev_dist):
                        witness_b = (N, fmask, v0, t - 1, b_prev, b,
                                     prev_dist, dist)
                    prev_dist = dist
                    b_prev = b
                    v = rot1(v, N, mask_all) ^ rf
                # After the loop, v is the state at t = 2N.
                if v != v0:
                    failures.append(
                        f"recurrence failed: N={N} fmask={fmask:0{N}b} v0={v0:0{N}b} "
                        f"v(2N)={v:0{N}b}")
                    if len(failures) > 5:
                        break
                share = Fraction(balanced_steps, period)
                if min_share_N is None or share < min_share_N:
                    min_share_N = share
                if global_min_share is None or share < global_min_share:
                    global_min_share = share
                    global_min_case = (N, fmask, v0)
            if len(failures) > 5:
                break
        total_cases += cases_N
        expected = (2 ** N) * (2 ** N)
        if cases_N != expected:
            failures.append(f"N={N}: cases {cases_N} != 4^N {expected}")
        print(f"  N={N:2d} cases={cases_N} (=2^N colorings x 2^N placements, "
              f"sum_F C(N,F)={placement_count_check}) recurrence held for all; "
              f"min balanced time-share over cases = {min_share_N}")

    expected_total = sum(4 ** N for N in range(4, 11))
    if total_cases != expected_total:
        failures.append(f"total cases {total_cases} != {expected_total}")
    print(f"  TOTAL exhaustive cases checked: {total_cases} "
          f"(sum of 4^N for N=4..10 = {expected_total})")

    # (b) witness must exist and be re-verified independently.
    if witness_b is None:
        failures.append("no non-monotonicity witness found")
    else:
        N, fmask, v0, t, b_t, b_t1, d_t, d_t1 = witness_b
        # Independent re-simulation of just this case, list-based.
        colors = [(v0 >> i) & 1 for i in range(N)]
        flippers = [bool((fmask >> i) & 1) for i in range(N)]
        states = [colors]
        for _ in range(t + 1):
            states.append(slow_step(states[-1], flippers, N))
        rb_t = sum(states[t])
        rb_t1 = sum(states[t + 1])
        if (rb_t, rb_t1) != (b_t, b_t1) or not (d_t1 > d_t):
            failures.append(f"witness re-verification failed: {witness_b} vs {(rb_t, rb_t1)}")
        print(f"  (b) NON-MONOTONE WITNESS: N={N}, flipper_mask={fmask:0{N}b} "
              f"(edges {sorted(i for i in range(N) if (fmask>>i)&1)}), "
              f"initial coloring={v0:0{N}b}, at t={t}: b={b_t} |b-N/2|={d_t}; "
              f"at t={t+1}: b={b_t1} |b-N/2|={d_t1} -- distance INCREASED "
              f"(re-verified with the list simulator)")

    print(f"  (c) minimum balanced time-share over ALL cases: {global_min_share} "
          f"at case (N, fmask, v0)={global_min_case}; shares are exact Fractions "
          f"over the 2N states t=0..2N-1. No drift is asserted.")

    # --- Mutant battery ----------------------------------------------------
    print("  mutant battery:")
    print("    NOTE (honest): statically deleting one edge's toggle is just "
          "another placement and still recurs at 2N; the mutant tested is "
          "the persistence violation -- edge-0 flipper removed after lap 1.")
    mutant_witness = None
    N = 4
    mask_all = (1 << N) - 1
    for fmask in range(1 << N):
        if not (fmask & 1):
            continue  # mutant differs only if edge 0 actually has a flipper
        fmask_lap2 = fmask & ~1  # edge-0 flipper removed for the second lap
        rf1 = rot1(fmask, N, mask_all)
        rf2 = rot1(fmask_lap2, N, mask_all)
        for v0 in range(1 << N):
            v = v0
            for _ in range(N):
                v = rot1(v, N, mask_all) ^ rf1
            for _ in range(N):
                v = rot1(v, N, mask_all) ^ rf2
            if v != v0:
                mutant_witness = (N, fmask, v0, v)
                break
        if mutant_witness:
            break
    if mutant_witness is None:
        failures.append("mutant (edge-0 flipper removed after lap 1) did NOT break recurrence")
    else:
        Nw, fmw, v0w, vfw = mutant_witness
        print(f"    MUTANT REJECTED: N={Nw}, flipper_mask={fmw:0{Nw}b}, initial "
              f"coloring={v0w:0{Nw}b}: standard dynamics returns to {v0w:0{Nw}b} at "
              f"t=2N={2*Nw}, mutant returns {vfw:0{Nw}b} != initial -- recurrence broken")

    if failures:
        print("E4 FAIL:")
        for f in failures[:10]:
            print(f"  - {f}")
        return 1

    print(f"E4 PASS: recurrence at 2N verified exhaustively in {total_cases} cases "
          f"(N=4..10; per N: 4^N cases, N=10 alone 1048576); non-monotone witness "
          f"printed above and re-verified; minimum balanced time-share over all cases "
          f"= {global_min_share}; mutant (flipper persistence violation) rejected "
          f"with witness. No drift asserted.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
