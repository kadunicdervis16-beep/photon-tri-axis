#!/usr/bin/env python3
# G1_history_consistency.py -- Paper 12.5 document check: the (year,
# author) PAIRINGS of Appendix A must be exactly the pairings the body
# makes, over the declared YEARS/NAMES lists below. Pairing consistency
# only: the truth of any row's content is the history dossier's work,
# not this script's (loop repair -- the earlier wording claimed the
# record itself).
#
# v3 strengthening (recorded): the v1/v2 instrument had no mutant
# battery -- a checker that cannot fail cannot verify -- and its
# coverage limit (body year-mentions that produce no pairing under
# the rules below) was disclosed in this header but invisible in the
# run record. The v3 instrument (a) carries a built-in mutant
# battery: ten synthetic mini-papers -- two clean (one pairing by
# the citation form, one by same-sentence proximity only) and eight
# planted violations (appendix-only pairing, body-only pairing,
# yearless appendix row, missing falsification condition, the
# condition present only inside a longer label, missing
# falsification heading, an appendix row naming no listed author,
# a proximity pairing the appendix does not carry) -- each run
# through the SAME check function used on the paper, the violations
# required to be caught and the clean cases required to pass; and
# (b) LISTS every unpaired body year-mention in the run record, with
# context, for inspection -- the coverage limit is printed, not
# merely confessed in the header. (Loop repairs within v3, recorded:
# the falsification-presence check now matches the condition label
# as a whole word over fence-stripped prose -- the v1/v2 substring
# test over the raw file passed on a longer label containing the
# characters, or on the label's occurrences inside this listing
# itself; and the appendix author read is whole-word, where the
# v1/v2 substring read took "Gibbson" for Gibbs.)
#
# INPUT_PROVENANCE:
#   paper-defined:      Appendix A's declared table structure (columns:
#                       Year | Author | Work | What it establishes here) and
#                       the paper's historical claim set (sections 2, 5, 9, 10).
#                       v2 extension, declared: YEARS and NAMES below were
#                       extended for the v2 lineage additions exactly by
#                       the years and names the v2 history dossier verified
#                       (1911, 1927, 1932, 1941, 1992, 2014, 2017;
#                       Bridgman, Neumann, Rau). No other set member changed.
#   control:            the paper path (argv[1] / $PAPER_MD / default).
#   declared-assumption: the PAIRING RULE, declared here: an appendix pairing
#                       is read STRUCTURALLY from the table's Year and Author
#                       columns (one pairing per listed author the row
#                       names; every row of the shipped appendix names
#                       exactly one). A body pairing binds a
#                       listed year to a listed author name by, in order:
#                       (i) the CITATION FORM -- the nearest listed name
#                       before the year owns it when at most 3 tokens, no
#                       other listed name or year, and no sentence terminator
#                       intervene ("Loschmidt (1876)", "Boltzmann's counting
#                       (1877)"), as citation syntax declares;
#                       (ii) otherwise the NEAREST listed name in the SAME
#                       SENTENCE within 60 characters. The prose is
#                       hard-wrapped, so same-line pairing is not the text's
#                       structure; and unrestricted proximity manufactures
#                       pairings across sentence boundaries and parenthetical
#                       lists (three such artifacts were caught and
#                       adjudicated at assembly -- the rule above is the
#                       repair, recorded here, not a silent loosening: rule
#                       (i) follows citation syntax, rule (ii) cannot cross
#                       a sentence boundary). Body text excludes fenced code
#                       blocks (Appendix E listings are data, not claims)
#                       and everything from the Appendix A heading on
#                       (appendices state the record; the body makes it).
#   arbitrary-representative:
#                     - The battery's synthetic mini-papers: minimal
#                       representatives of each offence class and of
#                       the clean case, constructed for this battery;
#                       they quote no source.
#
# WHAT IS CHECKED: (a) the set of (year, author) pairings in Appendix A
# equals the set in the body, both directions; (b) every Appendix A table row
# carries a year; (c) the condition label C34 stands as a whole word in the
# paper's prose (fenced listings excluded -- a listing's copy of the label
# is data, not the paper's falsification surface) and a falsification
# heading is present; (d) the mutant battery above passes. WHAT IS PRINTED BESIDE THE CHECK:
# every body occurrence of a listed year that produced no pairing, with
# context (the diagnostics) -- listed for inspection, not adjudicated.
# WHAT STAYS OUTSIDE: whether the historical claims are TRUE (that is the
# dossier's work, classified, section 2 / Appendix A of the paper); whether
# an unpaired year-mention makes a historical claim the appendix drops
# (human-audit territory -- the diagnostics exist so that audit reads a
# list, not a haystack).
import os
import re
import sys
from pathlib import Path

YEARS = {"1876", "1877", "1890", "1896", "1902", "1907", "1911", "1927",
         "1932", "1938", "1941", "1948", "1951", "1956", "1957", "1992",
         "1997", "1999", "2014", "2017"}
NAMES = {"Loschmidt", "Boltzmann", "Poincaré", "Poincare", "Zermelo",
         "Gibbs", "Ehrenfest", "Tolman", "Shannon", "Purcell", "Ramsey",
         "Jaynes", "Jarzynski", "Crooks", "Bridgman", "Neumann", "Rau"}
CANON = {"Poincare": "Poincaré"}
WINDOW = 60


def canon(name):
    return CANON.get(name, name)


def resolve(argv):
    if len(argv) > 1:
        return Path(argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def strip_fences(lines):
    out, in_fence = [], False
    for line in lines:
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return out


def appendix_rows(lines):
    """Table data rows of Appendix A: from its heading to Appendix B's."""
    start = end = None
    for i, line in enumerate(lines):
        if line.startswith("## Appendix A"):
            start = i
        elif start is not None and line.startswith("## Appendix B"):
            end = i
            break
    if start is None:
        return None, []
    seg = lines[start:end if end is not None else len(lines)]
    rows = []
    for line in seg:
        s = line.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if cells and cells[0].lower() == "year":
                continue  # header
            if all(set(c) <= set("-: ") for c in cells):
                continue  # separator
            rows.append((line, cells))
    return seg, rows


def body_pairings(lines):
    """Body (year, author) pairings under the declared pairing rule,
    plus diagnostics: every listed-year occurrence in the body, and
    the occurrences that produced no pairing (with context)."""
    body_lines = []
    for line in lines:
        if line.startswith("## Appendix A"):
            break
        body_lines.append(line)
    body_lines = strip_fences(body_lines)
    paragraphs, cur = [], []
    for line in body_lines:
        if line.strip():
            cur.append(line.strip())
        elif cur:
            paragraphs.append(" ".join(cur))
            cur = []
    if cur:
        paragraphs.append(" ".join(cur))
    body_text = "\n".join(paragraphs)

    name_pat = re.compile(r"\b(" + "|".join(sorted(NAMES)) + r")\b")
    year_pat = re.compile(r"\b(" + "|".join(sorted(YEARS)) + r")\b")
    name_hits = [(m.start(), m.end(), canon(m.group(1)))
                 for m in name_pat.finditer(body_text)]
    # sentence spans (for rule (ii)'s same-sentence restriction)
    spans, pos = [], 0
    for chunk in re.split(r"(?<=[.!?])\s+", body_text):
        spans.append((pos, pos + len(chunk)))
        pos += len(chunk) + 1

    def sentence_of(p):
        for s0, s1 in spans:
            if s0 <= p <= s1:
                return (s0, s1)
        return (0, len(body_text))

    body_pairs = set()
    year_occurrences = 0
    unpaired = []
    for m in year_pat.finditer(body_text):
        ypos, year = m.start(), m.group(1)
        year_occurrences += 1
        owner = None
        # rule (i): citation form -- the nearest listed name BEFORE the year
        # owns it when the intervening text is at most 3 tokens with no other
        # listed name, no listed year, and no sentence terminator between
        # ("Loschmidt (1876)"; "Boltzmann's counting (1877)").
        cands = [(nend, nname) for nstart, nend, nname in name_hits if nend <= ypos]
        if cands:
            nend, nname = max(cands)
            between = body_text[nend:ypos]
            tokens = between.split()
            if (len(tokens) <= 3
                    and not any(n in between for n in NAMES)
                    and not year_pat.search(between)
                    and not re.search(r"[.!?]", between)):
                owner = nname
        if not owner:
            # rule (ii): nearest listed name in the same sentence, within WINDOW
            s0, s1 = sentence_of(ypos)
            best, bestd = None, None
            for nstart, nend, nname in name_hits:
                if s0 <= nstart <= s1:
                    dist = abs(nstart - ypos)
                    if dist <= WINDOW and (bestd is None or dist < bestd):
                        best, bestd = nname, dist
            owner = best
        if owner:
            body_pairs.add((year, owner))
        else:
            ctx = body_text[max(0, ypos - 55):ypos + 30].replace("\n", " ")
            unpaired.append((year, ctx))
    diagnostics = {"year_occurrences": year_occurrences,
                   "unpaired": unpaired}
    return body_pairs, diagnostics


def check_text(raw):
    """The full G.1 check over a paper text. Returns (violations,
    stats) where stats carries the pairing counts and diagnostics.
    This is the single function the battery and the paper run share."""
    lines = raw.split("\n")
    violations = []

    # (c) falsification presence: the label as a WHOLE WORD over
    # fence-stripped prose (v3 loop repair -- the v1/v2 substring
    # test over the raw file passed on "C340" and on the label's
    # occurrences inside Appendix E's listings, this one included)
    prose = "\n".join(strip_fences(lines))
    if not re.search(r"\bC34\b", prose):
        violations.append('paper does not contain "C34" as a whole '
                          'word in its prose')
    if not re.search(r"^## .*falsification", raw, flags=re.M | re.I):
        violations.append("no falsification section heading found")

    seg, rows = appendix_rows(lines)
    if seg is None:
        violations.append("Appendix A heading not found")
        rows = []

    # appendix pairings: structural, from Year | Author columns
    app_pairs = set()
    for line, cells in rows:
        year_m = re.search(r"\b(1[89]\d\d|20\d\d)\b", cells[0]) if cells else None
        if not year_m:
            violations.append(f"appendix row lacks a year: {line.strip()[:90]}")
            continue
        year = year_m.group(1)
        author_cell = cells[1] if len(cells) > 1 else ""
        # whole-word author read (v3 loop repair: the v1/v2
        # substring test read "Gibbson" as Gibbs)
        found = [n for n in NAMES
                 if re.search(r"\b" + re.escape(n) + r"\b", author_cell)]
        if not found:
            violations.append(f"appendix row has no listed author: {line.strip()[:90]}")
            continue
        for n in found:
            app_pairs.add((year, canon(n)))

    body_pairs, diagnostics = body_pairings(lines)

    for pair in sorted(app_pairs - body_pairs):
        violations.append(f"appendix-only pairing {pair}: in Appendix A, never in body")
    for pair in sorted(body_pairs - app_pairs):
        violations.append(f"body-only pairing {pair}: in body, missing from Appendix A")

    stats = {"app_pairs": app_pairs, "body_pairs": body_pairs,
             "n_rows": len(rows), "diagnostics": diagnostics}
    return violations, stats


# ---- mutant battery: synthetic mini-papers, never the paper ----
_BATTERY_HEAD = [
    "# Mini paper",
    "",
    "## 11 FALSIFICATION CONDITIONS",
    "",
    "Condition C34 opens the surface.",
    "",
]
_BATTERY_APP_OPEN = [
    "## Appendix A HISTORICAL SOURCES",
    "",
    "| Year | Author | Work | What it establishes here |",
    "|---|---|---|---|",
]
_BATTERY_APP_CLOSE = [
    "",
    "## Appendix B INHERITANCE",
    "",
]


def _mini(body_lines, app_row_lines):
    return "\n".join(_BATTERY_HEAD + body_lines + [""]
                     + _BATTERY_APP_OPEN + app_row_lines
                     + _BATTERY_APP_CLOSE)


BATTERY_CLEAN = _mini(
    ["Gibbs (1902) wrote the book under audit here."],
    ["| 1902 | Gibbs | Elementary Principles | A row. |"])
# Second clean case: the pairing is made by rule (ii) ALONE -- the
# name and year share a sentence at a distance the citation form
# (rule (i), at most 3 intervening tokens) cannot bind ("published
# the book in" is four tokens). The battery asserts the pairing was
# in fact produced, so a rule-(ii) regression cannot pass silently.
BATTERY_CLEAN_II = _mini(
    ["Gibbs published the book in 1902, a generation later."],
    ["| 1902 | Gibbs | Elementary Principles | A row. |"])
BATTERY_CASES = [
    ("appendix-only pairing",
     _mini(["Gibbs (1902) wrote the book under audit here."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |",
            "| 1877 | Boltzmann | A memoir | A row the body never makes. |"])),
    ("body-only pairing",
     _mini(["Gibbs (1902) wrote the book under audit here.",
            "Loschmidt (1876) raised the objection."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |"])),
    ("appendix row lacks a year",
     _mini(["Gibbs (1902) wrote the book under audit here."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |",
            "| -- | Gibbs | A dateless row | No year on this row. |"])),
    ('does not contain "C34"',
     "\n".join(["# Mini paper", "",
                "## 11 FALSIFICATION CONDITIONS", "",
                "The opening condition is not named here.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    # (v3 loop repair) the label present only inside a longer
    # label: the v1/v2 substring test passed this text.
    ('does not contain "C34"',
     "\n".join(["# Mini paper", "",
                "## 11 FALSIFICATION CONDITIONS", "",
                "Condition C340 opens the surface.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    ("no falsification section heading",
     "\n".join(["# Mini paper", "",
                "## 11 CONDITIONS", "",
                "Condition C34 opens the surface.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    ("no listed author",
     _mini(["The book under audit appeared in print."],
           ["| 1902 | Anon | A work | A row naming no listed author. |"])),
    # rule (ii) exercised in the failing direction: the body pairs
    # (1902, Gibbs) by proximity alone; the appendix carries a
    # different pairing for 1902 -- both directions must fire.
    ("body-only pairing",
     _mini(["Gibbs published the book in 1902, a generation later."],
           ["| 1902 | Boltzmann | A memoir | A mismatched row. |"])),
]


def run_battery():
    failures = []
    violations, _ = check_text(BATTERY_CLEAN)
    if violations:
        failures.append(f"clean mini-paper flagged: {violations}")
    violations, stats = check_text(BATTERY_CLEAN_II)
    if violations:
        failures.append(f"clean rule-(ii) mini-paper flagged: "
                        f"{violations}")
    elif ("1902", "Gibbs") not in stats["body_pairs"]:
        failures.append("rule-(ii) clean case produced no (1902, "
                        "Gibbs) body pairing -- rule (ii) is not "
                        "exercised by this battery")
    for expected, text in BATTERY_CASES:
        violations, _ = check_text(text)
        if not any(expected in v for v in violations):
            failures.append(f"planted violation not caught "
                            f"({expected}): violations={violations}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G1 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print(f"G1 battery: PASS (2 clean mini-papers pass -- citation "
          f"form and rule-(ii) proximity; {len(BATTERY_CASES)} "
          f"planted violations caught by the same check function)")

    paper = resolve(sys.argv)
    if not paper.exists():
        print(f"G1 FAIL: paper not found: {paper}")
        return 1
    raw = paper.read_text(encoding="utf-8")
    violations, stats = check_text(raw)
    diag = stats["diagnostics"]
    print(f"G1 diagnostics: body listed-year occurrences="
          f"{diag['year_occurrences']}; unpaired (no pairing under "
          f"the declared rule)={len(diag['unpaired'])} -- listed "
          f"for inspection, not adjudicated:")
    for year, ctx in diag["unpaired"]:
        print(f"  UNPAIRED year {year}: ...{ctx}...")
    if violations:
        print(f"G1 VIOLATIONS ({len(violations)}) for {paper}:")
        for v in violations:
            print(f"  - {v}")
        print(f"G1 counts: appendix_pairs={len(stats['app_pairs'])} "
              f"body_pairs={len(stats['body_pairs'])}")
        return 1
    print(f"G1 PASS: {paper}: appendix_pairs={len(stats['app_pairs'])} "
          f"body_pairs={len(stats['body_pairs'])} (sets equal); "
          f"appendix rows={stats['n_rows']} all carry years; C34 + "
          f"falsification present; battery green")
    return 0


if __name__ == "__main__":
    sys.exit(main())
