#!/usr/bin/env python3
"""
E3_gibbs_paradox.py -- Exact mixing counts under two counting RULES.

INPUT_PROVENANCE:
  - N range 1..8 per side                          [control] declared range.
  - Slot model                                     [declared-assumption] the
    counting arena, stated in full so the verdict's domain is exact:
    2N distinct slots, N in the left compartment and N in the right.
    A micro-assignment is a bijection from labeled units to slots.
    BEFORE: the partitioned preparation, counted as the product of the
    two compartment counts (each compartment's units assigned to that
    compartment's slots). AFTER: the combined system, all 2N units
    assigned to all 2N slots. Populations: DISTINCT = N units of type X
    (initially left) and N of type Y (initially right), with the BEFORE
    count restricting X to left slots and Y to right slots; IDENTICAL =
    2N units of one type, BEFORE counted by the same per-compartment
    product procedure (this procedural sameness is exactly what the
    paradox turns on).
  - RULE A (distinguishable units)                 [paper-defined] count every
    bijection of labeled units: a system of m labeled units in m slots
    counts m! assignments.
  - RULE B (the 1/N! rule)                         [paper-defined] divide a
    system's Rule-A count by the product, over each distinct TYPE present
    in that system, of (count of that type)! . Before mixing, each
    compartment is a system; after mixing, the combined population is
    one system (one type of 2N for IDENTICAL; two types of N for DISTINCT).
  - Bridge sentence S = k_B ln Omega               [cited-paper] Paper 12 S8.4,
    the single declared Stage-P bridge sentence. Used ONLY in the
    translator line at the end; NO verdict in this script depends on it.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact integer assignment counts and exact Fraction ratios in the slot
  model above, for N = 1..8: (a) Rule-A identical mixing factor > 1;
  Rule-B identical factor == 1 exactly; Rule-B distinct factor equals
  the Rule-A distinct factor corrected only by the rule factor;
  (b) (Rule-A factor)/(Rule-B factor) equals exactly the factorial ratio
  introduced by the rule switch, per population kind.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Entropy values, thermodynamic mixing claims, and any continuum/volume
  formulation of the Gibbs paradox are outside. In particular the exact
  factor==1 for identical populations under Rule B is a fact of THIS
  finite slot census with the per-type factorial rule as stated; in a
  V^N volume counting the same rule gives factor==1 only in the
  Stirling limit, which is a separate, un-checked statement. The script
  also does not adjudicate which rule is "correct" -- it shows exactly
  what the rule switch changes, in counts.
METHOD (input-equals-output ban): assignment counts are computed by
  explicit permutation enumeration for N = 1..3 (brute force over
  itertools.permutations) and by an incremental slot-filling count
  (product of successive free-slot numbers) for all N; the two routes
  must agree where both run, and factorial closed forms are used only
  as a third oracle. Factors are computed from the counts, then compared
  to the claimed values. A one-sided-correction mutant must fail.
"""
import sys
from fractions import Fraction
from itertools import permutations
from math import factorial


def count_by_filling(m):
    """Number of bijections of m labeled units to m distinct slots,
    computed incrementally: unit by unit, multiply by the number of
    still-free slots. Exact integer; no factorial call."""
    total = 1
    for free in range(m, 0, -1):
        total *= free
    return total


def count_by_bruteforce(m):
    """Brute-force enumeration of bijections via permutations of slots."""
    return sum(1 for _ in permutations(range(m)))


def rule_factor(species_counts, compartment_systems):
    """Product of factorials the 1/N! rule divides by. compartment_systems
    is a list of systems; each system is a list of per-type unit counts."""
    f = 1
    for system in compartment_systems:
        for c in system:
            f *= factorial(c)
    return f


def main():
    failures = []
    print("E3 Gibbs paradox -- exact mixing counts, N = 1..8 per side")

    # Brute-force validation of the filling count (independent route).
    for m in range(0, 7):  # covers systems up to 2N for N=1..3 after mixing
        b, f = count_by_bruteforce(m), count_by_filling(m)
        if b != f or f != factorial(m):
            failures.append(f"m={m}: brute {b} / filling {f} / factorial {factorial(m)} disagree")
    print("  brute-force permutation counts agree with filling counts for m=0..6")

    rows = {}
    for N in range(1, 9):
        # --- Rule A counts (from the filling enumeration) ---
        comp = count_by_filling(N)            # one compartment: N units, N slots
        before_A = comp * comp                # product of compartment counts
        after_A = count_by_filling(2 * N)     # combined: 2N units, 2N slots
        factor_A_distinct = Fraction(after_A, before_A)
        factor_A_identical = Fraction(after_A, before_A)  # same procedural counts

        # --- Rule factors (what the switch divides by) ---
        # BEFORE systems: [left: one type of N], [right: one type of N]
        rf_before = rule_factor(None, [[N], [N]])
        # AFTER identical: one system, one type of 2N. AFTER distinct: one
        # system, two types of N each.
        rf_after_ident = rule_factor(None, [[2 * N]])
        rf_after_dist = rule_factor(None, [[N, N]])

        # --- Rule B counts ---
        before_B = Fraction(before_A, rf_before)
        after_B_ident = Fraction(after_A, rf_after_ident)
        after_B_dist = Fraction(after_A, rf_after_dist)
        factor_B_ident = after_B_ident / before_B
        factor_B_dist = after_B_dist / before_B

        rows[N] = (factor_A_identical, factor_B_ident, factor_B_dist)

        # (a) checks
        if not (factor_A_identical > 1):
            failures.append(f"N={N}: Rule-A identical factor {factor_A_identical} not > 1")
        if factor_B_ident != 1:
            failures.append(f"N={N}: Rule-B identical factor {factor_B_ident} != 1")
        # Rule-B distinct = Rule-A distinct corrected ONLY by rule factor:
        corrected = factor_A_distinct * Fraction(rf_before, rf_after_dist)
        if factor_B_dist != corrected:
            failures.append(f"N={N}: Rule-B distinct factor {factor_B_dist} != "
                            f"rule-corrected Rule-A factor {corrected}")
        # (b) ratio of factors == factorial ratio introduced by the switch
        ratio_ident = factor_A_identical / factor_B_ident
        switch_ident = Fraction(rf_after_ident, rf_before)
        if ratio_ident != switch_ident:
            failures.append(f"N={N}: identical (A/B) factor ratio {ratio_ident} != "
                            f"switch factorial ratio {switch_ident}")
        ratio_dist = factor_A_distinct / factor_B_dist
        switch_dist = Fraction(rf_after_dist, rf_before)
        if ratio_dist != switch_dist:
            failures.append(f"N={N}: distinct (A/B) factor ratio {ratio_dist} != "
                            f"switch factorial ratio {switch_dist}")

        print(f"  N={N}: before_A={before_A} after_A={after_A} "
              f"factor_A(ident)=factor_A(dist)={factor_A_distinct} "
              f"factor_B(ident)={factor_B_ident} factor_B(dist)={factor_B_dist} "
              f"switch_ratio_ident={switch_ident} switch_ratio_dist={switch_dist}")

    # ---- Mutant battery ---------------------------------------------------
    print("  mutant battery:")
    mutant_rejected = False
    for N in range(1, 9):
        comp = count_by_filling(N)
        before_A = comp * comp
        after_A = count_by_filling(2 * N)
        before_B = Fraction(before_A, factorial(N) * factorial(N))  # = 1
        # MUTANT: after mixing identical populations, divide by N! only
        # (one side's factorial) instead of (2N)!.
        after_mut = Fraction(after_A, factorial(N))
        factor_mut = after_mut / before_B
        if factor_mut != 1:
            print(f"    MUTANT REJECTED at N={N}: one-sided 1/N! correction gives "
                  f"identical factor {factor_mut} != 1 (required); "
                  f"witness after_mut={after_mut}, before_B={before_B}")
            mutant_rejected = True
            break
    if not mutant_rejected:
        failures.append("one-sided-correction mutant was NOT rejected")

    # ---- Translator line (NOT part of any verdict) ------------------------
    # Paper 12 S8.4's single declared bridge sentence S = k_B ln Omega,
    # quoted here only to translate the N=8 Rule-A identical count ratio
    # into the prose's units. Float; disclosed Stage-P translator only.
    import math
    fa = rows[8][0]
    print(f"  TRANSLATOR ONLY (Stage P, Paper 12 S8.4 bridge S = k_B ln Omega; "
          f"no verdict depends on this line): at N=8, ln(factor_A_identical) "
          f"= ln({fa}) ~= {math.log(fa):.6f}, i.e. Delta S = k_B * that value "
          f"under the bridge sentence.")

    if failures:
        print("E3 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print("E3 PASS: for all N=1..8, Rule-A identical mixing factor = C(2N,N) > 1 "
          f"(N=8: {rows[8][0]}); Rule-B identical factor == 1 exactly for all N; "
          f"Rule-B distinct factor == Rule-A distinct factor (rule ratio 1 for distinct; "
          f"N=8: {rows[8][2]}); (A/B) ratio == switch factorial ratio exactly "
          f"(identical at N=8: {Fraction(factorial(16), factorial(8)*factorial(8))}); "
          "one-sided mutant rejected with witness.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
