#!/usr/bin/env python3
"""
M2_ehrenfest.py -- Ehrenfest urn audit instrument for Paper 12.5
("The Ensemble Illusion").

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C instrument. It audits the STANDARD
  Ehrenfest urn machinery on its own terms. It is NEVER a native
  (Stage N) derivation.

  WHAT IS SAMPLED: a single seeded trajectory of the urn process --
  one ball at a time, moved between two urns. There is one actual
  population of N balls and one actual sequence of moves.

  WHAT RULE DOES THE SAMPLING: at each step, pick one of the N balls
  uniformly at random (seeded RNG) and move it to the other urn.

  THE SAMPLING RULE IS THE POSTULATE UNDER AUDIT in the following
  precise sense: the textbook gloss calls the limiting frequencies
  an "equilibrium ensemble distribution". The audit point, printed
  in this script's summary, is that the stationary shares are the
  CENSUS shares C(N,k)/2^N -- a counting fact about the 2^N records --
  and the trajectory's counted time-shares converge to those same
  shares. No ensemble is consulted anywhere in the computation; the
  "ensemble average" and the counted time-share agree because both
  are the same count.

INPUT_PROVENANCE:
  paper-defined:
    - Ehrenfest urn process as stated in the standard literature and
      audited by Paper 12.5: 2 urns, N balls, uniform single-ball move.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the empirical side is that rule
      applied to the declared run window.
  control:
    - Fixed seed SEED = 20251108 (declared here, before any run).
    - Run length N_STEPS = 4000000 steps (declared window; declared
      before any run). Mutant run length MUTANT_STEPS = 500000.
    - Mutant bias factor BIAS_FACTOR = 1.5 (declared control of the
      planted mutant, stated before the run).
  declared-assumption:
    - None.
  arbitrary-representative:
    - N = 20 balls. 2^N = 1048576 records; the all-in-one-urn record
      is rare enough to exhibit recurrence, common enough to recur
      inside the declared window in expectation.

PRE-REGISTERED TOLERANCE (stated here, before the runs; not fitted):
  TOL_SHARE = 0.008  max |empirical share(k) - C(N,k)/2^N| over k.
  The biased-picker mutant must MISS by more than TOL_SHARE --
  rejection requires a printed witness residual.

Checks:
  (a) Exact side: stationary shares = census shares (exact Fractions);
      exact mean recurrence time to k=0 computed as 1/share(0),
      an exact integer equal to 2^N.
  (b) Simulation side: empirical shares vs census shares within
      TOL_SHARE; returns to k=0 counted and printed.
  (c) Mutant: biased picker must miss census shares (witness).

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import random
import sys
from fractions import Fraction
from math import comb

# ---- declared controls / representatives (see header) ----
N = 20
SEED = 20251108
N_STEPS = 4_000_000
MUTANT_SEED = 20251109
MUTANT_STEPS = 500_000
BIAS_FACTOR = 1.5
TOL_SHARE = 0.008


def census_shares():
    """Exact census shares C(N,k)/2^N as Fractions (computed)."""
    return [Fraction(comb(N, k), 2 ** N) for k in range(N + 1)]


def run_fair(seed, n_steps):
    """Seeded Ehrenfest trajectory; returns (counts, returns_to_0).

    A step picks one ball uniformly: with count k in urn A, a uniform
    draw in 0..N-1 below k picks an A-ball (k -> k-1), else a B-ball
    (k -> k+1). Counts record the state AFTER each step.
    """
    rng = random.Random(seed)
    randrange = rng.randrange
    k = N // 2
    counts = [0] * (N + 1)
    returns = 0
    for _ in range(n_steps):
        if randrange(N) < k:
            k -= 1
        else:
            k += 1
        counts[k] += 1
        if k == 0:
            returns += 1
    return counts, returns


def run_biased(seed, n_steps, factor):
    """Mutant trajectory: A-balls carry `factor` times the picking
    weight of B-balls, so P(move down | k) is proportional to
    factor*k against (N-k)."""
    rng = random.Random(seed)
    rand = rng.random
    k = N // 2
    counts = [0] * (N + 1)
    for _ in range(n_steps):
        denom = factor * k + (N - k)
        p_down = (factor * k / denom) if denom > 0 else 0.0
        if rand() < p_down:
            k -= 1
        else:
            k += 1
        counts[k] += 1
    return counts


def max_dev(counts, n_steps, exact):
    return max(abs(c / n_steps - float(e))
               for c, e in zip(counts, exact))


def main():
    failures = []

    # (a) Exact side.
    exact = census_shares()
    share0 = exact[0]
    recurrence = 1 / share0  # exact Fraction; must be the integer 2^N
    print(f"M2 exact: stationary shares are census shares C({N},k)/2^{N}; "
          f"share(k=0)={share0} (={float(share0):.6e})")
    print(f"M2 exact: mean recurrence time to k=0 = 1/share(0) = "
          f"{recurrence} steps (exact; 2^{N} = {2 ** N})")
    if recurrence != 2 ** N or recurrence.denominator != 1:
        failures.append("recurrence time is not the exact integer 2^N")
        print("M2 FAIL: recurrence computation did not return 2^N exactly")
    # Census shares must sum to exactly 1 (counting identity, computed).
    if sum(exact) != 1:
        failures.append("census shares do not sum to exactly 1")

    # (b) Simulation side.
    counts, returns = run_fair(SEED, N_STEPS)
    dev = max_dev(counts, N_STEPS, exact)
    worst_k = max(range(N + 1),
                  key=lambda kk: abs(counts[kk] / N_STEPS - float(exact[kk])))
    ok = dev <= TOL_SHARE
    if not ok:
        failures.append("fair run missed census shares")
    print(f"M2 sim: seed={SEED} steps={N_STEPS} "
          f"max_abs_dev={dev:.6f} at k={worst_k} "
          f"(empirical={counts[worst_k] / N_STEPS:.6f}, "
          f"census={float(exact[worst_k]):.6f}) tol={TOL_SHARE} "
          f"{'OK' if ok else 'FAIL'}")
    print(f"M2 sim: visits to k=0 counted = {returns} "
          f"(expected count at census share = "
          f"{N_STEPS * float(share0):.2f} over the declared window; "
          f"count reported, not fitted)")
    if returns < 1:
        failures.append("no return to k=0 observed in the declared window")

    # (c) Mutant: biased picker must miss census shares.
    m_counts = run_biased(MUTANT_SEED, MUTANT_STEPS, BIAS_FACTOR)
    m_dev = max_dev(m_counts, MUTANT_STEPS, exact)
    m_worst = max(range(N + 1),
                  key=lambda kk: abs(m_counts[kk] / MUTANT_STEPS
                                     - float(exact[kk])))
    rejected = m_dev > TOL_SHARE
    if not rejected:
        failures.append("biased mutant NOT rejected")
    print(f"M2 mutant: bias_factor={BIAS_FACTOR} seed={MUTANT_SEED} "
          f"steps={MUTANT_STEPS} max_abs_dev={m_dev:.6f} at k={m_worst} "
          f"(empirical={m_counts[m_worst] / MUTANT_STEPS:.6f}, "
          f"census={float(exact[m_worst]):.6f}) tol={TOL_SHARE} "
          f"{'REJECTED (witness dev > tol)' if rejected else 'NOT REJECTED -- FAIL'}")

    print("M2 audit point: stationarity of the empirical frequencies is "
          "convergence to CENSUS shares -- no ensemble was consulted; "
          "the 'ensemble average' and the counted time-share agree "
          "because both are the same count.")

    if failures:
        print(f"M2 FAIL: {failures}")
        return 1
    print(f"M2 PASS: empirical shares match census shares "
          f"C({N},k)/2^{N} within tol={TOL_SHARE} "
          f"(max_abs_dev={dev:.6f}); recurrence to k=0 is exactly "
          f"{2 ** N} steps by census share; biased mutant rejected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
