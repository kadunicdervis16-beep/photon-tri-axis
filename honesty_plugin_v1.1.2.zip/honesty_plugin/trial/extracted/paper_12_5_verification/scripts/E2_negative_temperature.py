#!/usr/bin/env python3
"""
E2_negative_temperature.py -- Bounded-population census (Ramsey counting form).

INPUT_PROVENANCE:
  - N range 4..24                                  [control] declared check range.
  - Two-level units, energies 0 or eps             [paper-defined] bounded
    population census as used for the negative-temperature audit row.
  - eps = 1                                        [arbitrary-representative]
    Energies enter ONLY through the count k of excited units; no checked
    value depends on eps. It is named here so no reader mistakes it for
    a derived scale.
  - Omega(k) = C(N,k)                              [paper-defined] census count
    of records with exactly k excited units; computed from enumeration
    (Pascal cross-check), never assumed monotone.
  - Unbounded ladder: N_osc = 3 units, each on levels 0,1,2,...
                                                   [declared-assumption] the
    harmonic-type ladder is the standard contrast case; the counting is
    assignments of levels to 3 labeled units summing to total energy E.
  - Ladder cutoffs CUT1 = 24, CUT2 = 48 (levels 0..CUT per unit)
                                                   [control] declared truncations;
    checked energies E = 0..12 lie far below either cutoff and the two
    cutoffs must agree exactly (see DISCLOSURE below).
  - "Negative temperature" / "hotter than infinity" prose
                                                   [cited-paper] Ramsey-style
    gloss; NOT an input and NOT checked -- see outside-domain line.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact integer comparisons Omega(k+1) vs Omega(k) for the bounded census
  (the sign of the count slope, i.e. the sign of Delta ln Omega, decided
  WITHOUT logarithms because Omega > 0 and ln is monotone), and exact
  integer counts for the truncated unbounded ladder at two cutoffs.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Temperature itself (any Stage-P bridge assigning T, including negative
  T) is not computed or verified here. The census fact is only the sign
  flip of the count slope at k = N/2 in the bounded case and its absence
  (over the checked range, at two agreeing cutoffs) in the ladder case.
  "Hotter than infinity" is gloss over that sign flip; the script takes
  no position on the gloss.
TRUNCATION DISCLOSURE: the ladder is infinite in the native claim. This
  script verifies growth only for E = 0..12 with per-unit cutoffs 24 and
  48; agreement of the two cutoffs shows the checked counts are not
  cutoff artifacts for E <= 12 (any assignment summing to E <= 12 uses
  levels <= 12 < 24). No claim is machine-checked for E beyond 12.
METHOD (input-equals-output ban): Omega values are computed by two
  independent routes (comb and Pascal row); the slope pattern is read off
  the computed values and only then compared to the claimed pattern.
  Ladder counts are computed by explicit dynamic-programming enumeration
  over level assignments, not by the stars-and-bars closed form, which
  is used afterwards only as an oracle for E in range at CUT2.
"""
import sys
from fractions import Fraction
from math import comb


def pascal_row(n):
    row = [1]
    for _ in range(n):
        row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
    return row


def ladder_counts(n_units, e_max, cutoff):
    """Exact count of assignments (level_1,...,level_n_units), each level
    in 0..cutoff, summing to E, for E = 0..e_max. DP enumeration."""
    # dp[e] = number of assignments for the units processed so far.
    dp = [0] * (e_max + 1)
    dp[0] = 1
    for _ in range(n_units):
        ndp = [0] * (e_max + 1)
        for e in range(e_max + 1):
            if dp[e] == 0:
                continue
            for lev in range(0, min(cutoff, e_max - e) + 1):
                ndp[e + lev] += dp[e]
        dp = ndp
    return dp


def main():
    failures = []
    print("E2 negative temperature -- bounded census slope, N = 4..24")

    flip_witnesses = {}
    for N in range(4, 25):
        omega = [comb(N, k) for k in range(N + 1)]
        if omega != pascal_row(N):
            failures.append(f"N={N}: comb row != Pascal row")
            continue
        # Slope pattern read off the computed values.
        # inc: Omega(k+1) > Omega(k); dec: < ; eq: ==.
        first_fall = None
        for k in range(N):
            if omega[k + 1] < omega[k] and first_fall is None:
                first_fall = k  # Omega falls from k to k+1
            if N % 2 == 0:
                if k < N // 2 and not (omega[k + 1] > omega[k]):
                    failures.append(f"N={N} (even): Omega not strictly increasing at k={k}: "
                                    f"{omega[k]} -> {omega[k + 1]}")
                if k >= N // 2 and not (omega[k + 1] < omega[k]):
                    failures.append(f"N={N} (even): Omega not strictly decreasing at k={k}: "
                                    f"{omega[k]} -> {omega[k + 1]}")
            else:
                # Odd N: strict increase up to the central pair, central
                # pair EQUAL (Omega((N-1)/2) == Omega((N+1)/2)), then
                # strict decrease. This is the honest odd-N shape.
                mid_lo = (N - 1) // 2
                if k < mid_lo and not (omega[k + 1] > omega[k]):
                    failures.append(f"N={N} (odd): Omega not strictly increasing at k={k}")
                if k == mid_lo and not (omega[k + 1] == omega[k]):
                    failures.append(f"N={N} (odd): central pair not equal at k={k}: "
                                    f"{omega[k]} vs {omega[k + 1]}")
                if k > mid_lo and not (omega[k + 1] < omega[k]):
                    failures.append(f"N={N} (odd): Omega not strictly decreasing at k={k}")
        flip_witnesses[N] = first_fall
        peak = max(omega)
        print(f"  N={N:2d} Omega_max={peak} at k={[k for k in range(N+1) if omega[k]==peak]} "
              f"first_fall_from_k={first_fall} "
              f"(k>{Fraction(N, 2)} region: adding energy decreases the record count)")

    # ---- Unbounded ladder contrast --------------------------------------
    n_osc, e_max = 3, 12
    counts_c1 = ladder_counts(n_osc, e_max, 24)
    counts_c2 = ladder_counts(n_osc, e_max, 48)
    print(f"  ladder contrast: {n_osc} units, levels 0..cutoff, E=0..{e_max}")
    print(f"    counts @cutoff24: {counts_c1}")
    print(f"    counts @cutoff48: {counts_c2}")
    if counts_c1 != counts_c2:
        failures.append(f"ladder cutoffs disagree: {counts_c1} vs {counts_c2}")
    for E in range(e_max):
        if not (counts_c2[E + 1] > counts_c2[E]):
            failures.append(f"ladder count not strictly growing at E={E}: "
                            f"{counts_c2[E]} -> {counts_c2[E + 1]}")
    # Oracle cross-check (stars and bars), used only after enumeration:
    for E in range(e_max + 1):
        oracle = comb(E + n_osc - 1, n_osc - 1)
        if counts_c2[E] != oracle:
            failures.append(f"ladder E={E}: enumerated {counts_c2[E]} != stars-bars oracle {oracle}")
    print(f"    ladder count grows strictly over E=0..{e_max} "
          f"({counts_c2[0]} -> {counts_c2[e_max]}); no sign flip in checked range.")

    # ---- Mutant battery --------------------------------------------------
    print("  mutant battery:")
    mutant_rejected = False
    for N in range(4, 25):
        omega = [comb(N, k) for k in range(N + 1)]
        for k in range(N):
            if omega[k + 1] < omega[k]:
                print(f"    MUTANT REJECTED: 'Omega monotone increasing on the whole "
                      f"bounded range' fails at N={N}, first fall k={k}: "
                      f"Omega({k})={omega[k]} > Omega({k+1})={omega[k + 1]}")
                mutant_rejected = True
                break
        if mutant_rejected:
            break
    if not mutant_rejected:
        failures.append("mutant monotone-increasing Omega was NOT rejected")

    if failures:
        print("E2 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"E2 PASS: bounded census slope flips sign at k=N/2 for every N=4..24 "
          f"(even N: strict rise then strict fall; odd N: strict rise, equal central "
          f"pair, strict fall; e.g. N=24 Omega(12)={comb(24,12)}, first fall from k=12; "
          f"N=4 Omega={ [comb(4,k) for k in range(5)] }); ladder census (3 units) grows "
          f"strictly E=0..12 ({counts_c2[0]}->{counts_c2[e_max]}), cutoffs 24 and 48 agree "
          f"exactly; monotone mutant rejected with witness.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
