#!/usr/bin/env python3
"""
M1_canonical_recipe.py -- Monte-Carlo audit instrument for Paper 12.5
("The Ensemble Illusion").

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C instrument. It audits the STANDARD canonical
  machinery on its own terms. It is NEVER a native (Stage N) derivation,
  and nothing it prints is a claim about the ledger framework's own
  populations.

  WHAT IS SAMPLED: single-unit flip trajectories of a two-level system
  of N units, each unit in state 0 (energy 0) or 1 (energy epsilon).
  A record is one full assignment; k = number of excited units.

  WHAT RULE DOES THE SAMPLING: the Metropolis acceptance rule
  min(1, exp(-beta * dE)) for a uniformly proposed single-unit flip.

  THE SAMPLING RULE IS THE POSTULATE UNDER AUDIT. The exponential weight
  exp(-beta * k) is not measured from the population and not derived
  here; it is adopted by the recipe. The decisive exhibit (Exhibit B)
  runs the IDENTICAL sampler code with the acceptance weight replaced
  by 1 (uniform -- pure counting measure) and shows it converges to the
  beta=0 census values instead: the only ingredient the "canonical
  ensemble" adds beyond counting is the adopted weight. The weight is
  a dial on the sampler, not a property of the population.

  For beta > 0 the exact side uses float arithmetic (math.exp). That
  continuum machinery is itself the exhibit under audit and is disclosed
  here, not hidden: only the beta=0 exact side is pure census arithmetic
  (exact Fractions, weights all 1).

INPUT_PROVENANCE:
  paper-defined:
    - Two-level record structure (k = 0..N excitations, C(N,k) records
      at level k): the standard textbook system the canonical recipe is
      stated on; audited as the recipe states it.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the beta=0 census side is that
      rule applied to this record set.
  control:
    - beta grid {0.0, 0.5, 1.0, 2.0}: CONTROL parameters of the recipe,
      dialled by the auditor; not properties of any population.
    - Fixed seeds: BASE_SEED = 20251107; per-run seeds are derived
      deterministically as BASE_SEED + 1000*run_index (declared here,
      before any run).
    - Run length N_STEPS = 200000 sampled steps after BURN_IN = 10000
      discarded steps, per sampler run (declared before any run).
  declared-assumption:
    - None. No premise is bridged in by declaration; the exponential
      weight is the recipe's own postulate, exhibited, not assumed
      by this script on the framework's behalf.
  arbitrary-representative:
    - N = 10 units; epsilon = 1 (energy unit). Conclusions are
      structural (weight-as-dial) and do not depend on these choices;
      they are representatives, not fitted values.

PRE-REGISTERED TOLERANCES (stated here, before the runs; not fitted):
  TOL_MEAN  = 0.20   max |sampler mean k - exact mean k|
  TOL_SHARE = 0.025  max |sampler share(k) - exact share(k)| over k
  The mutant (sign-flipped weight) must MISS the beta>0 targets by
  MORE than TOL_MEAN on the mean -- rejection requires a witness
  residual printed by the script.

Checks:
  (a) Exact side by complete enumeration over k = 0..N.
  (b) Sampler side (canonical acceptance) vs exact targets, every beta.
  (c) Exhibit B: uniform-weight sampler vs beta=0 census targets.
  (d) Mutant: sign-flipped weight must miss beta>0 targets (witness).

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import math
import random
import sys
from fractions import Fraction

# ---- declared controls / representatives (see header) ----
N = 10
EPSILON = 1  # energy unit, representative
BETA_GRID = (0.0, 0.5, 1.0, 2.0)
BASE_SEED = 20251107
N_STEPS = 200_000
BURN_IN = 10_000
TOL_MEAN = 0.20
TOL_SHARE = 0.025


def exact_targets(beta):
    """Complete enumeration over k = 0..N.

    Returns (mean_k, shares list). At beta == 0 every weight is 1 and
    the computation is exact Fraction census arithmetic. At beta > 0
    weights are exp(-beta*k) floats (disclosed continuum machinery).
    The targets are COMPUTED from the enumeration, never hardcoded.
    """
    from math import comb

    if beta == 0.0:
        total = Fraction(0)
        weighted = Fraction(0)
        shares = []
        for k in range(N + 1):
            records = comb(N, k)  # C(N,k) records at level k, weight 1
            shares.append(Fraction(records, 2 ** N))
            total += records
            weighted += records * k
        mean = weighted / total  # exact Fraction
        return mean, shares
    total = 0.0
    weighted = 0.0
    raw = []
    for k in range(N + 1):
        w = comb(N, k) * math.exp(-beta * k * EPSILON)
        raw.append(w)
        total += w
        weighted += w * k
    shares = [w / total for w in raw]
    return weighted / total, shares


def run_sampler(beta, mode, seed):
    """Metropolis single-unit flip sampler.

    mode:
      "canonical" -- acceptance min(1, exp(-beta*dE))  (the recipe)
      "uniform"   -- acceptance weight replaced by 1   (pure counting)
      "flipped"   -- acceptance min(1, exp(+beta*dE))  (mutant)

    The three modes share every line of trajectory code; only the
    single acceptance probability for an upward flip differs (a
    downward flip's probability is its mirror). That is the point of
    the exhibit: the weight is one dial in one place.
    """
    rng = random.Random(seed)
    if mode == "canonical":
        p_up = math.exp(-beta * EPSILON)
    elif mode == "uniform":
        p_up = 1.0
    elif mode == "flipped":
        p_up = 1.0  # upward flips always accepted under +beta weight
    else:
        raise ValueError(mode)
    # Downward-flip acceptance: canonical 1, uniform 1, flipped exp(-beta).
    p_down = math.exp(-beta * EPSILON) if mode == "flipped" else 1.0

    state = [0] * N
    k = 0
    counts = [0] * (N + 1)
    total_steps = BURN_IN + N_STEPS
    for step in range(total_steps):
        i = rng.randrange(N)
        if state[i] == 0:
            if rng.random() < p_up:
                state[i] = 1
                k += 1
        else:
            if rng.random() < p_down:
                state[i] = 0
                k -= 1
        if step >= BURN_IN:
            counts[k] += 1
    mean = sum(kk * c for kk, c in enumerate(counts)) / N_STEPS
    shares = [c / N_STEPS for c in counts]
    return mean, shares


def max_share_resid(shares_a, shares_b):
    return max(abs(float(a) - float(b)) for a, b in zip(shares_a, shares_b))


def main():
    failures = []

    # Exact targets, computed once per beta.
    exact = {beta: exact_targets(beta) for beta in BETA_GRID}
    census_mean, census_shares = exact[0.0]
    print(f"M1 exact: beta=0 census mean_k={census_mean} "
          f"(={float(census_mean):.6f}), shares are C({N},k)/2^{N} "
          f"as exact Fractions")
    for beta in BETA_GRID:
        if beta == 0.0:
            continue
        m, _ = exact[beta]
        print(f"M1 exact: beta={beta} enumerated mean_k={m:.6f}")

    run_index = 0

    def next_seed():
        nonlocal run_index
        seed = BASE_SEED + 1000 * run_index
        run_index += 1
        return seed

    # (b) Canonical sampler vs exact recipe targets.
    print("M1 Exhibit A: canonical sampler vs exact recipe targets")
    for beta in BETA_GRID:
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "canonical", seed)
        e_mean, e_shares = exact[beta]
        r_mean = abs(s_mean - float(e_mean))
        r_share = max_share_resid(s_shares, e_shares)
        ok = r_mean <= TOL_MEAN and r_share <= TOL_SHARE
        if not ok:
            failures.append(f"canonical beta={beta} seed={seed}")
        print(f"  beta={beta} seed={seed} sampler_mean={s_mean:.4f} "
              f"exact_mean={float(e_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} "
              f"tol_mean={TOL_MEAN} tol_share={TOL_SHARE} "
              f"{'OK' if ok else 'FAIL'}")

    # (c) Exhibit B: uniform weight -> beta=0 census values.
    print("M1 Exhibit B: uniform-weight sampler (weight=1) vs beta=0 census")
    for beta in BETA_GRID:
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "uniform", seed)
        r_mean = abs(s_mean - float(census_mean))
        r_share = max_share_resid(s_shares, census_shares)
        ok = r_mean <= TOL_MEAN and r_share <= TOL_SHARE
        if not ok:
            failures.append(f"uniform beta={beta} seed={seed}")
        print(f"  nominal_beta={beta} seed={seed} sampler_mean={s_mean:.4f} "
              f"census_mean={float(census_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} {'OK' if ok else 'FAIL'}")
    print("  Reading: with the weight set to 1 the identical code counts; "
          "the exponential weight is the recipe's only added ingredient.")

    # (d) Mutant: sign-flipped weight must MISS beta>0 targets.
    print("M1 Mutant: sign-flipped weight min(1, exp(+beta*dE))")
    for beta in BETA_GRID:
        if beta == 0.0:
            continue  # at beta=0 the flip is identical; no witness exists
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "flipped", seed)
        e_mean, e_shares = exact[beta]
        r_mean = abs(s_mean - float(e_mean))
        r_share = max_share_resid(s_shares, e_shares)
        rejected = r_mean > TOL_MEAN
        if not rejected:
            failures.append(f"mutant NOT rejected at beta={beta}")
        print(f"  beta={beta} seed={seed} mutant_mean={s_mean:.4f} "
              f"exact_mean={float(e_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} tol_mean={TOL_MEAN} "
              f"{'REJECTED (witness resid_mean > tol)' if rejected else 'NOT REJECTED -- FAIL'}")

    if failures:
        print(f"M1 FAIL: {failures}")
        return 1
    print(f"M1 PASS: canonical sampler matches enumerated recipe targets "
          f"at all {len(BETA_GRID)} beta values (tol_mean={TOL_MEAN}, "
          f"tol_share={TOL_SHARE}); uniform-weight run converges to the "
          f"beta=0 census; sign-flipped mutant rejected at every beta>0.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
