#!/usr/bin/env python3
# RB1_run_all.py -- Paper 12.5 verification suite runner.
#
# INPUT_PROVENANCE:
#   paper-defined:      the suite membership (Paper 12.5 section 0.5.4 protocol
#                       table): E1-E6, M1-M2, G1-G4, FW1.
#   control:            the paper path passed as argv[1] (or $PAPER_MD); the
#                       document scripts (G1, G2, G3, G4, FW1) audit that file.
#   declared-assumption: NONE.
#
# WHAT THIS RUNNER CHECKS: that every script in the suite exits 0 against the
# FINAL tree it is pointed at, in suite order, in one process record. It does
# not re-check any script's internal claims; each script carries its own
# provenance and domain disclosure. A green RB.1 run means: the suite as a
# whole passed on the exact paper file named in the run record -- nothing more.
#
# Usage: python3 RB1_run_all.py [path-to-Paper_12_5_v3.md]
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def resolve_paper(argv):
    if len(argv) > 1:
        return Path(argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    for cand in [
        HERE.parent / "Paper_12_5_v3.md",
        HERE.parent.parent / "Paper_12_5_v3.md",
        Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md",
    ]:
        if cand.exists():
            return cand
    return HERE.parent / "Paper_12_5_v3.md"


SUITE = [
    ("E1_census_arrow.py", False),
    ("E2_negative_temperature.py", False),
    ("E3_gibbs_paradox.py", False),
    ("E4_kac_ring.py", False),
    ("E5_quantum_census.py", False),
    ("E6_bayesian_updating.py", False),
    ("M1_canonical_recipe.py", False),
    ("M2_ehrenfest.py", False),
    ("G1_history_consistency.py", True),
    ("G2_matrix_completeness.py", True),
    ("G3_premise_inventory.py", True),
    ("G4_rewrite_pairs.py", True),
    ("FW1_firewall_125.py", True),
]


def main():
    paper = resolve_paper(sys.argv)
    print(f"RB1 run-all: paper = {paper}")
    if not paper.exists():
        print("RB1 FAIL: paper file not found")
        return 1
    failures = []
    t0 = time.time()
    for name, needs_paper in SUITE:
        script = HERE / name
        cmd = [sys.executable, str(script)]
        if needs_paper:
            cmd.append(str(paper))
        t = time.time()
        proc = subprocess.run(cmd, capture_output=True, text=True)
        dt = time.time() - t
        status = "PASS" if proc.returncode == 0 else "FAIL"
        last = ""
        for line in (proc.stdout or "").splitlines():
            if "PASS" in line or "FAIL" in line or "REJECTED" in line:
                last = line.strip()
        print(f"  [{status}] {name} ({dt:.1f}s) {last[:150]}")
        if proc.returncode != 0:
            failures.append(name)
            tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-15:])
            print(f"    --- output tail ---\n{tail}")
    total = time.time() - t0
    if failures:
        print(f"RB1 FAIL: {len(failures)} script(s) failed: {failures} ({total:.1f}s)")
        return 1
    print(f"RB1 PASS: {len(SUITE)}/{len(SUITE)} scripts exit 0 on the final tree ({total:.1f}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
