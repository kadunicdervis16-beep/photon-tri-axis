#!/usr/bin/env python3
"""
G2_matrix_completeness.py -- document check for Paper 12.5
("The Ensemble Illusion").

PURPOSE: the Section 4 audit matrix is the paper's central exhibit
(one row per audited construction, columns: what is counted / what
is postulated / what is measured / the prose claim / the equation's
actual content). This check proves the assembled paper's matrix is
complete and fully filled -- no row dropped, no cell left empty.

CHECKS:
  - Locate the Section 4 heading (a heading line for section 4),
    then the first markdown table following it.
  - The table's data rows must be EXACTLY the six required rows,
    identified by first-cell labels containing (case-insensitive):
      Microcanonical, Canonical, Grand canonical, Ergodic,
      Coarse-graining, Gibbs
    ("Canonical" must not be satisfied by the Microcanonical row:
    labels are matched most-specific first and each row counts once.)
  - Each of the six rows must have at least 5 non-empty cells.

INPUT_PROVENANCE:
  paper-defined:
    - The six audit-matrix rows: Paper 12.5 design brief's audit
      matrix (microcanonical / canonical / grand canonical /
      ergodic hypothesis / coarse-graining / Gibbs-Shannon).
    - The five-column shape (counted / postulated / measured /
      prose / equation): the paper's audit form, inherited from
      Paper 11.5's Section 3.7-style matrix.
  cited-paper:
    - Paper 11.5 audit-matrix form (see design brief, machinery
      inherited): form cited, contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      first existing of ../Paper_12_5_v3.md and
      ../../Paper_12_5_v3.md relative to this script, else the
      delivered copy under ~/workspace/paper_12_5_delivery/.
  declared-assumption:
    - The matrix is the first markdown table after the Section 4
      heading (declared here; matches the paper's layout contract).
  arbitrary-representative:
    - None.

Exit 0 on PASS, 1 on any violation. Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

# Most-specific first: "Microcanonical" before "Canonical".
REQUIRED = ["Microcanonical", "Grand canonical", "Canonical",
            "Ergodic", "Coarse-graining", "Gibbs"]
MIN_CELLS = 5


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    # Drop the empty artefacts of the leading/trailing pipe.
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def find_matrix_rows(lines):
    """Data rows (cell lists) of the first table after the S4 heading."""
    start = None
    for i, line in enumerate(lines):
        if re.match(r"^#{1,4}\s*4(\.|\s)", line) or \
                re.match(r"^#{1,4}\s*Section\s+4\b", line, re.IGNORECASE):
            start = i
            break
    if start is None:
        return None
    rows = []
    in_table = False
    for line in lines[start + 1:]:
        stripped = line.strip()
        if stripped.startswith("|"):
            if set(stripped) <= set("|-: "):
                in_table = True
                continue
            if in_table:
                rows.append(split_cells(line))
            else:
                # Header row: enters the table but is not a data row.
                in_table = "pending"
            continue
        if in_table and stripped.startswith("#"):
            break
        if in_table is True and stripped == "":
            # Allow a blank line only before the next heading/table;
            # a blank line after data rows ends this table.
            if rows:
                break
    return rows


def match_label(first_cell):
    low = first_cell.lower()
    for req in REQUIRED:
        if req.lower() in low:
            return req
    return None


def main():
    path = resolve_path()
    if not path.is_file():
        print(f"G2 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    violations = []

    rows = find_matrix_rows(lines)
    if rows is None:
        print(f"G2 VIOLATIONS for {path}: Section 4 heading not found")
        return 1
    if not rows:
        print(f"G2 VIOLATIONS for {path}: no data rows in the "
              f"Section 4 audit-matrix table")
        return 1

    matched = {}
    extras = []
    for cells in rows:
        label = match_label(cells[0]) if cells else None
        if label is None:
            extras.append(cells[0] if cells else "<empty row>")
        elif label in matched:
            extras.append(f"duplicate row for {label}: {cells[0]}")
        else:
            matched[label] = cells

    for req in REQUIRED:
        if req not in matched:
            violations.append(f"missing required matrix row: {req}")
    for e in extras:
        violations.append(f"unexpected matrix row: {e}")
    if len(rows) != len(REQUIRED):
        violations.append(
            f"matrix has {len(rows)} data rows, expected exactly "
            f"{len(REQUIRED)}")
    for req in REQUIRED:
        if req in matched:
            nonempty = sum(1 for c in matched[req] if c)
            if nonempty < MIN_CELLS:
                violations.append(
                    f"row {req!r} has {nonempty} non-empty cells "
                    f"(< {MIN_CELLS}): {matched[req]}")

    if violations:
        print(f"G2 VIOLATIONS ({len(violations)}) for {path}:")
        for v in violations:
            print(f"  - {v}")
        return 1
    print(f"G2 PASS: {path}: audit matrix has exactly {len(rows)} "
          f"rows ({', '.join(REQUIRED)}), each with >= {MIN_CELLS} "
          f"non-empty cells.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
