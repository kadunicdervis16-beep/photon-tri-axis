#!/usr/bin/env python3
"""
FW1_firewall_125.py -- own-voice firewall scan for Paper 12.5
("The Ensemble Illusion").

PURPOSE: the paper audits other people's language; its OWN voice
must not commit the offences it audits. This scan enforces three
standing bans on the paper's prose (fenced code blocks excluded --
 listings are exhibits, not the paper's voice):

  (a) MICRO/MACRO BAN: the tokens "microscopic" / "macroscopic"
      must not appear in the paper's own voice. Quotation contexts
      are exempt: a line containing a double-quote character, or a
      blockquote line (first non-space character ">"), is quoting
      or exhibiting the standard vocabulary, not using it.
  (b) NEUTRINO BAN: the framework bans neutrinos as travelling
      particles. The paper may mention the word ONLY on a line
      that also carries the ban -- the word "ban" or an inflection
      of it ("bans", "banned", "banning", "bannings") as a WHOLE
      WORD (word-boundary match, not followed by a hyphen or a
      word character, so a hyphen compound such as "ban-worthy"
      does not exempt) -- or points at the framework's treatment
      ("Paper 15"). (v3 repair, recorded: the v1/v2 exemption
      tested the substring "ban" anywhere on the line, so an
      unrelated word containing those letters -- "abandoned"
      is the printed example -- washed a neutrino line clean.
      The whole-word test closes that wash; battery violator (d)
      plants exactly that case and violator (e) the hyphen
      compound, and both must now be CAUGHT.)
  (c) NO ADOPTED PROBABILITY POSTULATE: the paper's framework
      adopts none. Lines matching
        (?i)we (adopt|assume).{0,60}probabilit
      are flagged -- the paper's own "we adopt / we assume" must
      never attach to probability language.

MUTANT BATTERY (built in, run on synthetic strings, not the paper):
  five planted violating lines must each be CAUGHT by the same scan
  function used on the paper -- one per ban group, plus violator
  (d): a neutrino line carrying "abandoned", the word whose "ban"
  substring washed such lines under the v1/v2 exemption, and
  violator (e): a neutrino line whose only ban-shaped token is the
  hyphen compound "ban-worthy" -- and three clean lines must pass,
  including a line that carries the ban in its own words. Battery
  failure = script failure.

INPUT_PROVENANCE:
  paper-defined:
    - Ban (a): Paper 12's standing correction -- no micro/macro
      split; "it's all relational" (author's ruling, binding on
      this companion critique).
    - Ban (b): the series' neutrino ban (framework record since
      the Papers 1-10 synopsis: "The Non-Existent Neutrino").
    - Ban (c): Paper 12's dissolution of the measure postulate --
      the framework has no probability postulate to adopt.
  cited-paper:
    - Paper 12 (census rule; no probability postulate) and
      Paper 15 (the ban's home treatment): cited as the bans'
      sources; contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      first existing of ../Paper_12_5_v3.md and
      ../../Paper_12_5_v3.md relative to this script, else the
      delivered copy under ~/workspace/paper_12_5_delivery/.
  declared-assumption:
    - Quotation context := line contains '"' or begins (after
      whitespace) with '>' (declared here, per the task spec).
    - Ban (b) exemption := line carries the whole word "ban",
      "bans", "banned", "banning" or "bannings", not followed by
      a hyphen or a word character (word-boundary regex,
      case-insensitive; v3 repair of the v1/v2 substring test --
      see the ban (b) note above) or "Paper 15" (literally).
  arbitrary-representative:
    - The battery's synthetic lines: representatives of each
      offence class, not quotations from any source.

Exit 0 iff the battery passes AND the paper scan finds 0 hits.
Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

MICRO_RE = re.compile(r"micro\w*scopic|macro\w*scopic", re.IGNORECASE)
NEUTRINO_RE = re.compile(r"neutrino", re.IGNORECASE)
BAN_WORD_RE = re.compile(r"\bban(?:s|ned|nings?)?\b(?![-\w])",
                         re.IGNORECASE)
ADOPT_RE = re.compile(r"we (adopt|assume).{0,60}probabilit",
                      re.IGNORECASE)


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def scan_lines(lines):
    """Scan prose lines; returns (hits, n_prose_lines, exemptions).

    hits: list of (group, line_number_1based, line_text).
    exemptions: lines where ban (a)'s token matched inside a
    quotation context -- not hits, but LISTED, so the exemption is
    inspected rather than silent (loop repair: two legitimate
    attributed-paraphrase lines previously passed by punctuation
    accident; they are now printed in the run record).
    Fenced code blocks are excluded (listings are exhibits).
    """
    hits = []
    exemptions = []
    in_fence = False
    n_prose = 0
    for idx, line in enumerate(lines, start=1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        n_prose += 1
        # (a) micro/macro outside quotation contexts
        is_quote_ctx = ('"' in line) or line.lstrip().startswith(">")
        if MICRO_RE.search(line) and is_quote_ctx:
            exemptions.append((idx, line.strip()))
        if MICRO_RE.search(line) and not is_quote_ctx:
            hits.append(("a:micro/macro", idx, line.strip()))
        # (b) neutrino without the whole word ban/bans/banned/
        # banning/bannings (not hyphen-compounded) or Paper 15 on
        # the line (v3: word-boundary match; the v1/v2 substring
        # test let "abandoned" wash the line)
        if NEUTRINO_RE.search(line):
            if not BAN_WORD_RE.search(line) and "Paper 15" not in line:
                hits.append(("b:neutrino", idx, line.strip()))
        # (c) adopted probability postulate
        if ADOPT_RE.search(line):
            hits.append(("c:adopt-probability", idx, line.strip()))
    return hits, n_prose, exemptions


# ---- mutant battery: synthetic strings, never the paper ----
BATTERY_VIOLATORS = [
    ("a:micro/macro",
     "The microscopic state of each unit fixes the outcome."),
    ("b:neutrino",
     "The neutrino travels from the source to the detector."),
    ("c:adopt-probability",
     "We adopt a probability postulate for the ledger."),
    # (d) v3: the substring-wash case. Under the v1/v2 exemption
    # this line PASSED ("ban" inside "abandoned"); under the
    # whole-word exemption it must be CAUGHT.
    ("b:neutrino",
     "The neutrino flux was abandoned by the analysis team."),
    # (e) v3 loop repair: the hyphen-compound wash. The compound
    # carries the lexeme but does not state the ban; it must be
    # CAUGHT.
    ("b:neutrino",
     "The neutrino passage is ban-worthy prose."),
]
BATTERY_CLEAN = [
    "The census counts every record in the declared window.",
    '"microscopic" is the standard term under audit in this section.',
    # v3: a line carrying the ban in its own words stays clean
    # under the whole-word test (the paper's own exemption lines
    # are of this form).
    "The framework bans the neutrino as a travelling particle.",
]


def run_battery():
    failures = []
    for expected_group, line in BATTERY_VIOLATORS:
        hits, _, _ = scan_lines([line])
        groups = {g for g, _, _ in hits}
        if expected_group not in groups:
            failures.append(
                f"violator not caught ({expected_group}): {line!r}")
    for line in BATTERY_CLEAN:
        hits, _, _ = scan_lines([line])
        if hits:
            failures.append(f"clean line flagged: {line!r} -> {hits}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("FW1 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print(f"FW1 battery: PASS ({len(BATTERY_VIOLATORS)} planted "
          f"violators caught, {len(BATTERY_CLEAN)} clean lines passed)")

    path = resolve_path()
    if not path.is_file():
        print(f"FW1 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    hits, n_prose, exemptions = scan_lines(lines)
    print(f"FW1 scan: {path}: prose_lines_scanned={n_prose} "
          f"hits={len(hits)}")
    for lineno, text in exemptions:
        print(f"  EXEMPTED (quoted context, listed for inspection) "
              f"line {lineno}: {text[:110]}")
    if hits:
        for group, lineno, text in hits:
            print(f"  HIT [{group}] line {lineno}: {text}")
        print("FW1 FAIL: own-voice firewall violations present")
        return 1
    print("FW1 PASS: 0 hits on the paper; battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
