#!/usr/bin/env python3
"""
G3_premise_inventory.py -- document + recomputation check for
Paper 12.5 ("The Ensemble Illusion"), section 7.4 premise inventory.

PURPOSE: section 7.4 names the premises a recurrence/drift claim
would have to buy, prices each against the two toy exhibits (Kac
ring, Ehrenfest urn), and closes by stating the joint is open.
This check proves (a) the assembled paper's inventory is complete
and priced, (b) the closing sentence is present, and (c) the two
load-bearing toy facts the inventory's prices rest on are TRUE,
recomputed here independently of the paper's prose.

CHECKS:
  (1) Locate "### 7.4"; within it find the premise table by its
      exact header
        | Premise | What it must supply | Kac ring | Ehrenfest urn | Price |
      Assert exactly 6 data rows, P1-P6 (P6 is the starting-record
      premise: the class of initial records over which drift is
      claimed, declared and priced), each with >= 5 cells and a
      Price cell carrying a price keyword from the inventory's
      printed price vocabulary (LEVEL / Unpriced / Owed /
      Discharged / NO BADGE / Stage / inherited / Missing / Open)
      -- a non-empty cell is not a printed price (loop repair).
  (2) Assert the exact sentence "The joint is open." occurs within
      section 7.4 (from the ### 7.4 heading to the next ## heading).
  (3) Recompute, independently of the paper:
      (i) Kac ring N=4, exhaustively over all colourings (2^4) x
          flipper placements (2^4): simulate the ring exactly and
          confirm at least one case whose |imbalance| trajectory
          over t = 0..2N is non-monotone (it both rises at some
          step and falls at some step); print one witness. Also
          confirm exact recurrence (the state at some t in 1..2N
          equals the initial state) for ALL cases at N=4.
      (ii) Ehrenfest census shares at N=20: exact Fractions
          C(20,k)/2^20; assert the unique maximum is at k=10 and
          each extreme share (k=0 and k=20) equals 1/2^20.

MUTANT BATTERY (built in, run on synthetic strings, not the paper):
  a premise table missing row P3 must FAIL check (1), and a section
  7.4 text without the closing sentence must FAIL check (2); both
  are run through the same functions used on the paper.

INPUT_PROVENANCE:
  paper-defined:
    - The premise table's header and row labels P1-P6, and the
      closing sentence: Paper 12.5 section 7.4 as assembled (the
      document side of this check audits that text; the header
      string is the layout contract, copied exactly).
    - Kac ring dynamics: N sites, balls black/white, each tick every
      ball advances one site and flips colour iff it passes a marked
      (flipper) site -- the paper's toy exhibit, restated here.
    - Ehrenfest census shares C(N,k)/2^N: the counting fact of the
      paper's second toy exhibit (see also M2's exact side).
  cited-paper:
    - Paper 12 section 8.6 / 9.6 open joint: the sentence "The joint
      is open." is this companion's restatement of that standing
      open joint for the premises inventoried here; its truth as a
      claim about the framework is the paper's, not this script's.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      default path relative to this script.
    - Kac recomputation size N=4 and Ehrenfest size N=20: declared
      check sizes (N=4 is the smallest ring exhibiting the full
      fall-and-rise trajectory; N=20 matches M2's census).
  declared-assumption:
    - Kac encoding: colours are a list per site (1 = black,
      0 = white); a flipper sits on edge i -> i+1 and toggles a
      ball crossing it; imbalance D(t) = (#black) - (#white)
      = 2*b(t) - N, and the trajectory audited is |D(t)|.
      Representation choices only -- the non-monotonicity and
      recurrence verdicts are invariant under relabelling.
    - The premise table is the table in section 7.4 whose header
      row equals the exact header string above; data rows are the
      following pipe rows up to the first non-pipe line.
  arbitrary-representative:
    - The battery's synthetic section-7.4 texts: representatives
      of the two failure classes, not quotations from any source.

Exit 0 iff the battery passes AND all paper checks pass AND the
recomputation confirms both toy facts. Python 3 stdlib only.
"""

import os
import sys
from fractions import Fraction
from math import comb
from pathlib import Path

TABLE_HEADER = ("| Premise | What it must supply | Kac ring | "
                "Ehrenfest urn | Price |")
REQUIRED_ROWS = ["P1", "P2", "P3", "P4", "P5", "P6"]
CLOSING_SENTENCE = "The joint is open."
# Loop repair: a Price cell must carry a price, not merely be
# non-empty (the red team passed a paper whose Price cells were
# all "x"). The inventory's price vocabulary is small and printed:
# badges, "Unpriced", "Owed", discharges, the joint's own name.
PRICE_KEYWORDS = ("LEVEL", "Unpriced", "Owed", "Discharged",
                  "NO BADGE", "Stage", "inherited", "Missing", "Open")
KAC_N = 4
EHRENFEST_N = 20


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def section_74_lines(lines):
    """Lines of section 7.4: from the '### 7.4' heading to the next
    '## ' heading (or end of file). None if the heading is absent."""
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("### 7.4"):
            start = i
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("## "):
            end = j
            break
    return lines[start:end]


def premise_table_rows(sec_lines):
    """Data rows (cell lists) of the premise table in section 7.4,
    found by its exact header. None if the header is absent."""
    if sec_lines is None:
        return None
    for i, line in enumerate(sec_lines):
        if line.strip() == TABLE_HEADER:
            rows = []
            for nxt in sec_lines[i + 1:]:
                s = nxt.strip()
                if not s.startswith("|"):
                    break
                if set(s) <= set("|-: "):
                    continue  # separator row
                rows.append(split_cells(nxt))
            return rows
    return None


def check_inventory(sec_lines):
    """Check (1): returns a list of violation strings."""
    violations = []
    rows = premise_table_rows(sec_lines)
    if rows is None:
        return ["section 7.4 heading or premise-table header not found"]
    if len(rows) != len(REQUIRED_ROWS):
        violations.append(
            f"premise table has {len(rows)} data rows, expected "
            f"exactly {len(REQUIRED_ROWS)} (P1-P6)")
    labels = []
    for cells in rows:
        labels.append(cells[0] if cells else "")
        if len(cells) < 5:
            violations.append(
                f"premise row {cells[0] if cells else '<empty>'} has "
                f"{len(cells)} cells (< 5)")
        elif not cells[4]:
            violations.append(
                f"premise row {cells[0]} has an empty Price cell")
        elif not any(k.lower() in cells[4].lower()
                     for k in PRICE_KEYWORDS):
            violations.append(
                f"premise row {cells[0]} has a Price cell carrying "
                f"no price keyword (one of {PRICE_KEYWORDS}) -- a "
                f"non-empty cell is not a printed price")
    for req in REQUIRED_ROWS:
        if not any(lab.startswith(req) for lab in labels):
            violations.append(f"premise table is missing row {req}")
    return violations


def check_closing(sec_lines):
    """Check (2): returns a list of violation strings."""
    if sec_lines is None:
        return ["section 7.4 heading not found"]
    if CLOSING_SENTENCE not in "\n".join(sec_lines):
        return [f'section 7.4 does not contain the exact sentence '
                f'"{CLOSING_SENTENCE}"']
    return []


# ---- (3)(i) Kac ring recomputation (exact, exhaustive at N=4) ----

def kac_step(colours, flippers, n):
    """One tick: the ball at site i moves to site i+1 (mod n),
    toggling iff flippers[i] (the edge i -> i+1 is marked)."""
    nxt = [None] * n
    for i in range(n):
        nxt[(i + 1) % n] = colours[i] ^ (1 if flippers[i] else 0)
    return nxt


def kac_recomputation():
    """Returns (failures, witness) where witness is
    (colouring, placement, |D| trajectory) for one non-monotone case."""
    failures = []
    n = KAC_N
    period = 2 * n
    witness = None
    cases = 0
    for v0 in range(1 << n):
        colouring0 = [(v0 >> i) & 1 for i in range(n)]
        for fmask in range(1 << n):
            flippers = [bool((fmask >> i) & 1) for i in range(n)]
            cases += 1
            colours = list(colouring0)
            traj = [abs(2 * sum(colours) - n)]
            returned_at = None
            for t in range(1, period + 1):
                colours = kac_step(colours, flippers, n)
                traj.append(abs(2 * sum(colours) - n))
                if colours == colouring0 and returned_at is None:
                    returned_at = t
            if returned_at is None:
                failures.append(
                    f"Kac N={n}: no recurrence at or before 2N for "
                    f"colouring {v0:0{n}b}, placement {fmask:0{n}b}")
                if len(failures) > 5:
                    return failures, witness
            if witness is None:
                diffs = [traj[i + 1] - traj[i] for i in range(period)]
                if any(d > 0 for d in diffs) and any(d < 0 for d in diffs):
                    witness = (f"{v0:0{n}b}", f"{fmask:0{n}b}", traj)
    if cases != (2 ** n) * (2 ** n):
        failures.append(f"Kac cases {cases} != {2 ** n}x{2 ** n}")
    if witness is None:
        failures.append("Kac N=4: no non-monotone |imbalance| case "
                        "found in the exhaustive census")
    return failures, witness


def ehrenfest_recomputation():
    """(3)(ii): exact census shares at N=20. Returns failures."""
    failures = []
    n = EHRENFEST_N
    shares = [Fraction(comb(n, k), 2 ** n) for k in range(n + 1)]
    if sum(shares) != 1:
        failures.append("Ehrenfest shares do not sum to exactly 1")
    top = max(shares)
    argmax = [k for k in range(n + 1) if shares[k] == top]
    if argmax != [10]:
        failures.append(f"Ehrenfest N=20: argmax {argmax} != [10] "
                        f"(unique maximum required)")
    for k in (0, n):
        if shares[k] != Fraction(1, 2 ** n):
            failures.append(f"Ehrenfest N=20: extreme share at k={k} "
                            f"is {shares[k]} != 1/2^20")
    return failures


# ---- mutant battery: synthetic section-7.4 texts -------------------

def _synthetic_section(rows, closing):
    lines = ["### 7.4 The premise inventory", "", TABLE_HEADER,
             "|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {r} | supply | kac | urn | Priced [LEVEL A: AUTHOR] |")
    lines.append("")
    if closing:
        lines.append("The joint is open.")
    lines.append("")
    lines.append("## 8 Next section")
    return lines


def run_battery():
    failures = []
    good = _synthetic_section(REQUIRED_ROWS, True)
    if check_inventory(good) or check_closing(good):
        failures.append("battery control (complete synthetic section) "
                        "did not pass its own checks")
    missing_p3 = _synthetic_section(
        [r for r in REQUIRED_ROWS if r != "P3"], True)
    v = check_inventory(missing_p3)
    if not v:
        failures.append("mutant table missing P3 was NOT caught by "
                        "check (1)")
    else:
        print(f"  battery: MUTANT REJECTED (missing P3): check (1) "
              f"reports: {v[0]}")
    missing_p6 = _synthetic_section(
        [r for r in REQUIRED_ROWS if r != "P6"], True)
    v6 = check_inventory(missing_p6)
    if not v6:
        failures.append("mutant table missing P6 was NOT caught by "
                        "check (1)")
    else:
        print(f"  battery: MUTANT REJECTED (missing P6): check (1) "
              f"reports: {v6[0]}")
    no_closing = _synthetic_section(REQUIRED_ROWS, False)
    v2 = check_closing(no_closing)
    if not v2:
        failures.append("mutant section without the closing sentence "
                        "was NOT caught by check (2)")
    else:
        print(f"  battery: MUTANT REJECTED (no closing sentence): "
              f"check (2) reports: {v2[0]}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G3 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print("G3 battery: PASS (missing-P3 and missing-P6 tables caught; "
          "closing-sentence omission caught; control passes)")

    # Recomputation side runs regardless of the paper's state: the
    # toy facts are this script's own verified domain.
    kac_failures, witness = kac_recomputation()
    ehr_failures = ehrenfest_recomputation()
    if witness is not None:
        print(f"  recompute Kac N={KAC_N}: exhaustive "
              f"{(2 ** KAC_N) * (2 ** KAC_N)} cases; recurrence at or "
              f"before 2N={2 * KAC_N} for all cases; non-monotone "
              f"witness: colouring={witness[0]}, placement="
              f"{witness[1]}, |D| trajectory t=0..{2 * KAC_N}: "
              f"{witness[2]}")
    print(f"  recompute Ehrenfest N={EHRENFEST_N}: shares "
          f"C(20,k)/2^20 exact; unique maximum at k=10 "
          f"(share {Fraction(comb(20, 10), 2 ** 20)}); extreme "
          f"shares = 1/2^20 = {Fraction(1, 2 ** 20)}")
    failures = kac_failures + ehr_failures

    path = resolve_path()
    if not path.is_file():
        print(f"G3 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    sec = section_74_lines(lines)
    failures += check_inventory(sec)
    failures += check_closing(sec)

    if failures:
        print(f"G3 VIOLATIONS ({len(failures)}) for {path}:")
        for f in failures:
            print(f"  - {f}")
        return 1
    rows = premise_table_rows(sec)
    print(f"G3 PASS: {path}: section 7.4 premise table has exactly "
          f"{len(rows)} rows (P1-P6), each >= 5 cells with a "
          f"Price cell carrying a price keyword; \"{CLOSING_SENTENCE}\" present in "
          f"section 7.4; Kac N=4 recomputation exhaustive (recurrence "
          f"for all cases, non-monotone witness printed); Ehrenfest "
          f"N=20 shares verified exactly (unique max at k=10, "
          f"extremes 1/2^20); battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
