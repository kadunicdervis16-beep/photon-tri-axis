# History Dossier — Paper 12.5 "The Ensemble Illusion"

Historical fact-check, compiled 2026-11-07. Method: web search against encyclopedias, publisher / journal records, the Stanford Encyclopedia of Philosophy (SEP), and scholarly histories. Conservative standard throughout: where sources disagree or the record is layered, the disagreement is stated rather than smoothed over. Each section gives a VERDICT, the conservative citable sentence(s) — the only prose intended for reuse — and the sources relied on.

Verdict key: **confirmed** = year, author, title and content as commonly stated check out. **confirmed-with-nuance** = core claim correct, but the popular form needs a qualifier. **corrected** = a detail in the item as posed (or in the common retelling) is wrong and is fixed here.

---

## 1. Boltzmann 1877 and S = k ln W

**VERDICT: confirmed-with-nuance — the famous formula is Planck's form of Boltzmann's result, not Boltzmann's own writing.**

Citable: In his 1877 memoir "Über die Beziehung zwischen dem zweiten Hauptsatze der mechanischen Wärmetheorie und der Wahrscheinlichkeitsrechnung respektive den Sätzen über das Wärmegleichgewicht" (Sitzungsberichte der Kaiserlichen Akademie der Wissenschaften, Wien, 76: 373–435), Ludwig Boltzmann showed that the entropy of a gas is proportional to the logarithm of the number of complexions / permutations (his Permutabilität, P) compatible with its state — in modern notation, S ∝ log P. Boltzmann did not write S = k_B ln W, did not use the symbol W for that count, and did not introduce the constant k. The exact form S = k log W, with W for Wahrscheinlichkeit and k as a new universal constant given a numerical value, is Max Planck's, introduced in Planck's black-body work of 1900 and stated in definitive form in 1901 (Annalen der Physik 4: 553). Planck himself later noted that Boltzmann had never introduced the constant named after him. The formula on Boltzmann's tombstone is therefore Planck's inscription of Boltzmann's idea.

Flag: Any sentence of the form "Boltzmann wrote S = k ln W in 1877" is a myth in its literal form. The conceptual priority (entropy ∝ log of a count of micro-arrangements) is Boltzmann's 1877; the equation, symbol, and constant are Planck's 1900/1901.

Sources: Cohen, "Entropy, Probability and Dynamics" (arXiv:0807.1268) — Boltzmann's S = log P + const. vs Planck's S = k log W + c; Sharp & Matschinsky translation of Boltzmann 1877, Entropy 2015, 17: 1971–2009; Planck's 1920 Nobel lecture as quoted in standard histories of the Boltzmann constant.

## 2. Loschmidt's reversibility objection (Umkehreinwand)

**VERDICT: confirmed.**

Citable: Josef Loschmidt raised the reversibility objection in 1876 (Sitzungsberichte der Kaiserlichen Akademie der Wissenschaften, Wien, Math.-Naturwiss. Classe 73: 128–142), directed against Boltzmann's 1872 H-theorem. Loschmidt pointed out that the underlying mechanics is time-reversal invariant: for any molecular motion in which H decreases (entropy increases), reversing every velocity at an intermediate instant yields an equally lawful motion in which H increases — so a purely mechanical, exceptionless proof of monotonic entropy increase cannot go through, and Boltzmann's Stosszahlansatz (molecular chaos) assumption does not itself follow from Newtonian dynamics. A precursor of the same point by William Thomson (1874) is documented, but the objection is conventionally and fairly attached to Loschmidt's 1876 paper.

Sources: Wikipedia, "Loschmidt's paradox" (bibliographic details and origin section); Dictionary of the History of Ideas, entropy entry (University of Virginia Library) — Loschmidt 1876 as response prompting Boltzmann 1877.

## 3. Poincaré recurrence theorem

**VERDICT: confirmed.**

Citable: Henri Poincaré proved the recurrence theorem in his prize memoir on the three-body problem: the prize (King Oscar II of Sweden) was awarded in 1889, and the revised memoir, "Sur le problème des trois corps et les équations de la dynamique," was published in Acta Mathematica 13 (1890): 1–270. The theorem states that a measure-preserving dynamical system confined to a finite volume of phase space returns, for almost all initial conditions, arbitrarily close to its initial state, and does so infinitely often.

Flag: Dating nuance only — "1890" is the publication year of the Acta Mathematica version; the prize itself and the original (subsequently corrected) memoir belong to 1888–89. Citing "Poincaré 1890, Acta Mathematica 13" is the safe form.

Sources: Mazliak, "Poincaré's Odds," Séminaire Poincaré XVI (2012) — prize 1889, probabilistic extension added for the 1890 Acta version; Barrow-Green / homoclinic-points literature — final form in Acta Mathematica 13, December 1890; Zermelo's own citation of Poincaré, Acta Mathematica 13: 1–270 (1890).

## 4. Zermelo's recurrence objection (Wiederkehreinwand) and Boltzmann's reply

**VERDICT: confirmed.**

Citable: Ernst Zermelo, then Planck's assistant, pressed the recurrence objection in 1896 — "Über einen Satz der Dynamik und die mechanische Wärmetheorie," Annalen der Physik 57: 485–494, with a follow-up in vol. 59 (1896) — arguing that Poincaré recurrence is incompatible with a monotonic H-theorem and with any purely mechanical derivation of irreversible entropy increase. Boltzmann replied in Annalen der Physik 57: 773–784 (1896) and again in vol. 60: 392–398 (1897), after Zermelo's rejoinder. Boltzmann conceded the mathematical correctness of Poincaré's theorem and of the recurrence conclusion, and denied its physical significance: for a macroscopic gas the recurrence time is inconceivably long — vastly beyond any observational timescale — and the H-curve is to be read statistically, with entropy decrease not impossible but overwhelmingly improbable except over such times. In the 1897 reply he added the fluctuation picture in which the direction of time for observers is defined by the local slope of entropy increase.

Flag: The exchange is sometimes compressed to "1896–97" — accurate, but note both of Zermelo's main papers are 1896; the 1897 paper is Boltzmann's second reply. Boltzmann's numerical colour (e.g., remarks about how much would happen in one recurrence time) should be quoted from Brush's translations, not paraphrased from secondary retellings.

Sources: Brush translations reprinted in Kinetic Theory vol. 2 (Zermelo 1896, Annalen 57: 485–94; Boltzmann reply, Annalen 57: 773–84; Boltzmann 1897, Annalen 60: 392–98); Darrigol, From c-Numbers to q-Numbers (1992), ch. I; Brown et al., Stud. Hist. Phil. Mod. Phys. 40 (2009): 174–191.

## 5. Gibbs, "On the Equilibrium of Heterogeneous Substances" (1875–78), and the Gibbs paradox

**VERDICT: confirmed-with-nuance — the "paradox" has two distinct Gibbs loci, and conflating them is the standard error.**

Citable: Josiah Willard Gibbs, "On the Equilibrium of Heterogeneous Substances," Transactions of the Connecticut Academy of Arts and Sciences 3 (1875–78; the mixing discussion is in the 1876 portion), derived the entropy of mixing for ideal gases and stated the discontinuity that now bears his name: mixing two different gases at the same temperature and pressure raises the entropy by a fixed amount independent of how similar the gases are, while mixing two portions of the same gas raises it not at all. Gibbs's own treatment was thermodynamic and unembarrassed: if the gases are identical there is no experimentally distinguishable change of state on removing the partition, so no entropy change is assigned; the entropy depends on the (macroscopically) sensible properties of the state. The second, statistical-mechanical locus is Gibbs's 1902 Elementary Principles, in the closing chapter on generic and specific phases (ch. XV): counting in generic phases — phase points differing only by permutation of similar particles identified — rather than specific phases recovers the thermodynamic result, including zero entropy of mixing for identical gases; the division by N! in counting belongs to this 1902 discussion, not to the 1875–78 memoir. The label "paradox" itself is later — first raised as a paradox by Carl Neumann (1891) and Pierre Duhem (1892).

Flag: Three cautions. (1) Gibbs did not present the 1876 discontinuity as a paradox or a defect to be repaired; the paradox framing is Neumann's, Duhem's, and later authors'. (2) Saying "Gibbs solved the paradox by dividing by N!" reverses the 1902 logic as some historians read it: the generic-phase counting reproduces thermodynamics, discontinuity included. (3) The textbook "Gibbs paradox" about non-extensive entropy of a single ideal gas is a related but distinct descendant of the same material.

Sources: den Boer / van Lith literature summarised in Saunders et al. tradition; Dieks & Lubberdink line via "The Gibbs Paradox: Early History and Solutions," Entropy 20 (2018): 443 — Neumann 1891 / Duhem 1892 naming, Gibbs 1876 memoir discussion, Gibbs 1902 pp. 206–207 generic-phase passage; Gibbs (1875–78), Trans. Connecticut Acad. 3: 108–248, 343–524.

## 6. Gibbs, "Elementary Principles in Statistical Mechanics" (1902) — terminology and the status of ensembles

**VERDICT: corrected on one point (the date of "statistical mechanics"), confirmed-with-nuance on the rest.**

Citable: Josiah Willard Gibbs, Elementary Principles in Statistical Mechanics: Developed with Especial Reference to the Rational Foundation of Thermodynamics (New York: Charles Scribner's Sons; New Haven: Yale University Press, 1902). The term "statistical mechanics" is Gibbs's coinage, but from 1884, not 1902 — it appears in his 1884 address "On the Fundamental Formula of Statistical Mechanics, with Applications to Astronomy and Thermodynamics" (Proc. AAAS 33: 57–58). In the 1902 book Gibbs built the theory on ensembles of systems and named the canonical and grand canonical distributions; the now-standard label "microcanonical" for the isolated-system ensemble is conventionally credited to Gibbs's framework, but the tidy three-name taxonomy was systematised by later expositions (notably the Ehrenfests' 1911/12 encyclopedia article and Tolman), and Boltzmann had introduced closely related ensemble concepts under his own names (Ergode, Holode, Monode) in 1884 — a priority Gibbs's preface acknowledges in general terms. On the status of ensembles Gibbs's own framing is explicitly imaginative, not populational: "We may imagine a great number of systems of the same nature, but differing in the configurations and velocities which they have at a given instant…" (1902, Preface). The ensemble is a collection of imagined, non-interacting copies of the one system, distributed over its possible states; nothing in Gibbs's text treats it as a physical population of coexisting systems. Schrödinger's later gloss — "mental copies of the one system under consideration" — is faithful to Gibbs's presentation.

Flag: Claims of the form "Gibbs coined 'statistical mechanics' in his 1902 book" are wrong by 18 years. Claims that Gibbs "invented the ensemble ex nihilo in 1902" overstate: the systematic Gibbsian form is his, the ensemble idea has a documented Boltzmannian prehistory (1884).

Sources: Gibbs (1884), Proc. AAAS 33, reprinted in Scientific Papers vol. II (1906); Gibbs (1902), Preface ("We may imagine a great number of systems..."); ch. I carries a parallel "Let us imagine a great number of independent systems" sentence (p. 5) -- the two must not be conflated; SEP, "Philosophy of Statistical Mechanics" (Fall 2024 ed.), §6.1 — ensemble as infinite collection of copies, Schrödinger's "mental copies"; Balescu / Cercignani literature on Boltzmann's 1884 Monode/Ergode/Holode terminology.

## 7. The Ehrenfest urn model

**VERDICT: confirmed.**

Citable: Paul Ehrenfest and Tatiana Ehrenfest (Ehrenfest-Afanassjewa), "Über zwei bekannte Einwände gegen das Boltzmannsche H-Theorem," Physikalische Zeitschrift 8 (1907): 311–314. The paper introduces the urn model — N numbered balls distributed between two urns, one randomly chosen ball transferred at each step — expressly to discuss the two known objections to the H-theorem, Loschmidt's reversibility objection and Zermelo's recurrence objection. The model shows in miniature how an H-like quantity drifts toward its equilibrium (most probable) value with fluctuations, while recurrence to the initial state remains certain but takes a time growing exponentially in N — making Boltzmann's statistical reading concrete rather than merely asserted. The companion popular name "dog–flea model" is a later re-dressing of the same model (Kac, 1947), not the Ehrenfests' 1907 presentation.

Flag: Minor — volume is sometimes misprinted as 9; the correct citation is Physikalische Zeitschrift 8 (1907), 311–314. A related Ehrenfest note on a probability problem connected with entropy increase appeared in 1906; the H-theorem paper is the 1907 one.

Sources: Ehrenfest & Ehrenfest 1907 bibliographic record as reproduced in Wikipedia, "Ehrenfest model," and in Klein's Ehrenfest biography (paper presented Nov. 1906, published 1907, p. 311); Giulini, "A Reminder on the Ehrenfests' Urn Model" (arXiv:physics/0509220).

## 8. The Kac ring model

**VERDICT: confirmed-with-nuance — three dates are in play and all three are verifiable; citing only "1959" hides the 1956 origin.**

Citable: Mark Kac introduced the ring model in print in 1956 — "Some remarks on the use of probability in classical statistical mechanics," Bulletin de l'Académie Royale de Belgique 42 (1956): 356–361, the same year as his Magnolia Petroleum colloquium lectures, Some Stochastic Problems in Physics and Mathematics (1956) — and gave the model its canonical textbook exposition in Probability and Related Topics in Physical Sciences (Lectures in Applied Mathematics vol. 1; New York: Interscience / American Mathematical Society, 1959), based on his 1957 Boulder lectures. The model — balls circulating on a ring, flipping colour at marked sites — is deterministic, exactly time-reversible, and exactly recurrent (every ball returns to its initial colour after at most 2N steps), yet its macroscopic colour imbalance decays exponentially exactly as a Boltzmann-type equation predicts, provided a Stosszahlansatz-like assumption (statistical independence of successive scatterer encounters) is imposed. Kac's stated purpose was to price that assumption: the model shows precisely where the probabilistic step enters, since the exact dynamics violates the assumption (correlations build up and produce the recurrence) while the assumption nevertheless gives the correct macroscopic behaviour for most times and most initial conditions.

Flag: Sources variously date the ring "1956," "1957" (lectures), and "1959" (book). All are defensible with the right referent; "Kac 1959" alone, presented as the introduction date, is incomplete. The common gloss "the Kac ring proves irreversibility" overstates Kac: the model displays the compatibility of reversibility, recurrence, and apparent irreversibility, and isolates the extra assumption the Boltzmann equation needs.

Sources: Kac (1956), Bull. Acad. Roy. Belg. 42: 356–361; Kac (1959), Probability and Related Topics in Physical Sciences — ring at §III.14 / pp. 73, 99 as cited in Lebowitz & Montroll tradition; "The Kac Ring or the Art of Making Idealisations," Foundations of Physics 50 (2020): 1152–1170 — bibliography listing both Kac 1956 (Magnolia lectures) and Kac 1959; Luczak, Stud. Hist. Phil. Mod. Phys. 57 (2017): 1–7.

## 9. Negative absolute temperature: Purcell & Pound 1951; Ramsey 1956

**VERDICT: corrected — Ramsey's paper is in Physical Review, not Proceedings of the Royal Society A; otherwise confirmed, with a live modern controversy to flag.**

Citable: The first realisation was Edward M. Purcell and Robert V. Pound, "A Nuclear Spin System at Negative Temperature," Physical Review 81 (1951): 279–280: by rapidly reversing the magnetic field on the nuclear spins in a lithium fluoride (LiF) crystal — on a timescale short compared with spin–spin relaxation but with the spin system effectively isolated from the lattice (spin–lattice relaxation of minutes) — they produced a population-inverted spin state they described as a negative spin temperature, a state that is "not cold, but very hot," giving up energy to any positive-temperature system and relaxing back through infinite temperature. The systematic theory is Norman F. Ramsey, "Thermodynamics and Statistical Mechanics at Negative Absolute Temperatures," Physical Review 103 (1956): 20–28 (not Proc. R. Soc. Lond. A). Ramsey's conditions for a negative absolute temperature are that the system (i) be in internal thermodynamic equilibrium, (ii) be essentially isolated from other systems, and (iii) have an upper bound to its allowed energies (a bounded spectrum), so that entropy S decreases with internal energy U and 1/T = (∂S/∂U) is negative. On ordering: negative temperatures are hotter than all positive temperatures — heat flows from a negative-temperature system to any positive-temperature system — and the temperature order runs +0 K … +∞ K = −∞ K … −0 K, so a negative temperature is properly described as hotter than +∞, with ±∞ a single shared point.

Flag: (1) Venue correction as above — "Ramsey 1956, Proc. R. Soc. Lond. A" is a recurrent miscitation; the paper is Phys. Rev. 103, 20–28. (2) The possibility had been anticipated by Onsager (1949) in the context of two-dimensional vortex dynamics — credit for the concept is not Purcell–Pound's alone. (3) The interpretation remains contested: Dunkel & Hilbert (Nature Physics 10, 2014: 67–72) argue that with the Gibbs (volume) entropy, absolute temperature is always positive and negative temperatures are artefacts of the Boltzmann (surface) entropy; defenders of Ramsey reply that the Gibbs-entropy reading contradicts the Purcell–Pound experimental record (Abraham & Penrose, Phys. Rev. E 95, 2017: 012125). A citable sentence should present Ramsey's framework as the standard one, not as uncontested.

Sources: Purcell & Pound, Phys. Rev. 81 (1951): 279–280 (original paper text); Ramsey, Phys. Rev. 103 (1956): 20–28 — abstract states the three conditions and "Negative temperatures are hotter than positive temperatures"; Ramsey bibliography, Proc. Amer. Philos. Soc. 160 (2016) and NobelPrize.org biographical bibliography — both list Phys. Rev. 103: 20 (1956); Sokolov, Nature Physics 10 (2014): 7 — Dunkel–Hilbert controversy summary, citing Purcell & Pound 1951 and Ramsey 1956.

## 10. Shannon 1948

**VERDICT: confirmed.**

Citable: Claude E. Shannon, "A Mathematical Theory of Communication," Bell System Technical Journal 27 (1948): 379–423 and 623–656 (July and October instalments). Shannon defined H = −K Σ p_i log p_i (the constant K fixing the unit) as the measure of "information, choice and uncertainty," proved it is the unique form satisfying his three stated desiderata (continuity; monotonic increase with the number of equally likely choices; additivity under decomposition of a choice), and noted explicitly that the form "will be recognized as that of entropy as defined in certain formulations of statistical mechanics," naming Boltzmann's H-theorem as the instance. Shannon claimed formal identity of functional form; he did not claim that Shannon entropy is physical (thermodynamic) entropy, and the 1948 paper contains no derivation of any thermodynamic result. The further identification of information entropy with thermodynamic entropy is later work by others (notably Jaynes, item 11).

Flag: The anecdote that von Neumann advised Shannon to call H "entropy" because "nobody knows what entropy really is" comes from a later recollection (reported by Tribus) and should be flagged as anecdotal if used at all; it is not in the 1948 paper.

Sources: Shannon (1948), original text (reprint) — Theorem 2 and the passage "Quantities of the form H = −Σ p_i log p_i … play a central role in information theory as measures of information, choice and uncertainty. The form of H will be recognized as that of entropy as defined in certain formulations of statistical mechanics"; bibliographic record, Bell Syst. Tech. J. 27(3): 379–423, 27(4): 623–656.

## 11. Jaynes 1957 and MaxEnt

**VERDICT: confirmed.**

Citable: Edwin T. Jaynes, "Information Theory and Statistical Mechanics," Physical Review 106 (1957): 620–630, and "Information Theory and Statistical Mechanics II," Physical Review 108 (1957): 171–190. Jaynes proposed that equilibrium statistical mechanics be reconstructed as statistical inference: maximising the Shannon information entropy −Σ p_i log p_i subject to the constraints supplied by known macroscopic expectation values (the MaxEnt principle) yields the canonical distribution when mean energy is the constraint, and the Gibbs ensemble formalism generally. Jaynes's framing is explicitly epistemic: the probability distribution "represents our knowledge" of the system; maximising entropy is the "least biased estimate possible on the given information… maximally noncommittal with regard to missing information." The distributions are thus rules of inference from partial knowledge, not hypotheses about physical populations of systems — a deliberate inversion of the Gibbsian ensemble picture (item 6).

Flag: It is two papers, both 1957 — citing only the first omits the paper (II) containing the applications to irreversibility and the fluctuation discussion. Jaynes himself argued the approach was "already implicit" in Gibbs; that is Jaynes's interpretive claim, not a consensus historical verdict, and should be attributed to him if repeated.

Sources: Jaynes, Phys. Rev. 106 (1957): 620–630; Phys. Rev. 108 (1957): 171–190 — bibliographic records via APS / MIT OCW readings list; the "least biased estimate" passage as quoted in standard MaxEnt literature from Jaynes 1957 I.

## 12. Jarzynski 1997 and Crooks 1999

**VERDICT: confirmed — both titles, years, and venues exactly as posed.**

Citable: Christopher Jarzynski, "Nonequilibrium Equality for Free Energy Differences," Physical Review Letters 78 (1997): 2690–2693, proved ⟨e^(−βW)⟩ = e^(−βΔF): the equilibrium free-energy difference ΔF between two states equals a quantity obtained by exponentiating the work W performed along nonequilibrium trajectories connecting them and averaging over an ensemble of such trajectories (repeated realisations of the same protocol, initially sampled from equilibrium). Gavin E. Crooks, "Entropy Production Fluctuation Theorem and the Nonequilibrium Work Relation for Free Energy Differences," Physical Review E 60 (1999): 2721–2726, proved the stronger ratio relation P_F(W) / P_R(−W) = e^(β(W−ΔF)) between the work distributions of a forward protocol and its time-reversed counterpart — again a statement about probability distributions over ensembles of trajectories, from which Jarzynski's equality follows as a corollary. Neither result is a statement about any single trajectory; both presuppose an ensemble of repetitions and equilibrium initial sampling.

Sources: APS records — Jarzynski, Phys. Rev. Lett. 78(14): 2690–2693, DOI 10.1103/PhysRevLett.78.2690; Crooks, Phys. Rev. E 60(3): 2721–2726, DOI 10.1103/PhysRevE.60.2721; Université Paris-Saclay lecture notes (Trizac) — derivation explicitly "over a large number of realizations of the same experiment."

## 13. Tolman, "The Principles of Statistical Mechanics" (1938)

**VERDICT: confirmed.**

Citable: Richard C. Tolman, The Principles of Statistical Mechanics (Oxford: Clarendon Press / Oxford University Press, 1938; Dover reprint 1979). Tolman presents the hypothesis of equal a priori probabilities — equal probability for equal extensions (volumes) of phase space compatible with the system's macroscopic specification — as the fundamental postulate of the theory, and is explicit about its status: although he endeavours "to show the reasonable character of this hypothesis, it must nevertheless be regarded as a postulate which can be ultimately justified only by the correspondence between conclusions which it permits and the regularities in the behaviour of actual systems which are empirically found" (Tolman 1938, p. 59 in the Dover edition; the postulate is developed in pp. 58–65, including the claim that in the absence of knowledge beyond the laws of mechanics any other assumption would be arbitrary, pp. 64–65).

Flag: Page numbers differ between the 1938 Clarendon printing and the 1979 Dover reprint pagination commonly cited; cite by chapter/section as well as page if the edition matters. Note also that presenting equal a priori probabilities as Gibbs's own foundation is a Tolman-era textbook move that historians (e.g., the "Readings and Misreadings of Gibbs" literature) dispute — Gibbs's canonical ensemble does not rest on it in Tolman's form.

Sources: Tolman (1938), Clarendon Press, Oxford — bibliographic record in arXiv:1706.01500 ("Readings and Misreadings of J. Willard Gibbs' Elementary Principles"), ref. 6; Tolman p. 59 postulate passage as quoted in Evans-group lecture literature; Tolman pp. 60–65 discussion in arXiv:1706.01500 §III.

## 14. Landau & Lifshitz, "Statistical Physics"

**VERDICT: corrected — the bibliographic history has three steps, and "1938 Russian / 1951 English" conflates two of them.**

Citable: The work began as a single-author book: L. D. Landau, Statistical Physics, first published in Russian in 1938, with an English translation by David Shoenberg appearing the same year (Oxford: Clarendon Press, 1938). Recast as Volume 5 of Landau and Lifshitz's Course of Theoretical Physics (Landau & Lifshitz, Statisticheskaya Fizika), its first edition in that form is Russian, 1951 (Moscow: Fizmatgiz / GITTL), and the corresponding English edition is Pergamon Press, 1958 (translated by J. B. Sykes and M. J. Kearsley) — not 1951. Later editions: 2nd ed. 1968; 3rd ed. (Butterworth-Heinemann, 1980), split with Part 2 becoming Course Volume 9 (1980).

Flag: "Landau & Lifshitz 1951" is a Russian-edition citation; citing it as an English 1951 edition is an error. Conversely, calling the 1938 book "Landau & Lifshitz" is anachronistic in title-page terms — Lifshitz's co-authorship belongs to the Course version — though the 1938 text already grew out of their collaboration. The conservative all-purpose citation for the mature text is Landau & Lifshitz, Statistical Physics (Course of Theoretical Physics, Vol. 5), 3rd ed., Butterworth-Heinemann, 1980.

Sources: Course of Theoretical Physics bibliography (Wikipedia, "Course of Theoretical Physics," Vol. 5 entry) — "Early version: Landau (1938), Statistical Physics, Clarendon Press"; WorldCat record — Landau & Lifshitz, Statistical Physics, trans. Shoenberg, Clarendon Press, Oxford, 1938 (English); arXiv:1703.04234 notes — Landau & Lifshitz (1951), Statisticheskaya Fizika, Fizmatgiz; English edition (1958), Pergamon.

## 15. Boltzmann's reply to Loschmidt — documented content vs the famous retort

**VERDICT: confirmed-with-nuance — the documented reply is statistical; the famous one-liner is second-hand and should be flagged as anecdotal.**

Citable (documented): Boltzmann's published response to Loschmidt, developed in the 1877 memoir (item 1) and his subsequent writings, concedes that velocity-reversed, entropy-decreasing motions are perfectly lawful: mechanics allows them, and the H-theorem cannot be an exceptionless mechanical theorem. His claim is statistical — states are to be weighted by their number of complexions, the overwhelming majority of microstates compatible with a non-equilibrium macrostate evolve toward equilibrium, and the initial state of an observed entropy-increasing process is itself an exceedingly improbable one; entropy decrease is therefore not impossible but improbable to a degree that removes the objection's force against a probabilistic second law. (The companion documented reply to Zermelo is item 4.)

The retort: Boltzmann is widely reported to have answered Loschmidt with words to the effect of "Go ahead, reverse them!" The line is not documented in Boltzmann's published papers or surviving correspondence in that form; its traceable source in the modern literature is Mark Kac's retelling (Kac 1959, Probability and Related Topics in Physical Sciences, as cited in the Kac-ring literature: "According to Kac, Boltzmann replied to Loschmidt's objection: 'go ahead, reverse them!'"). Later physics writing itself flags it as "rumoured" / "reported (possibly apocryphal)". It may be used only as an attributed anecdote — "as Kac retold it" — never as a Boltzmann quotation.

Sources: Boltzmann (1877), Wien. Ber. 76 — the statistical reformulation answering Loschmidt; "The Kac Ring or the Art of Making Idealisations," Found. Phys. 50 (2020) — "According to Kac [27], Boltzmann replied… 'go ahead, reverse them!'"; Garner & Vedral, arXiv:1604.03208 — "Boltzmann is rumoured to have replied, 'Go ahead and reverse them'"; Zurek, Cucchietti & Paz, arXiv:quant-ph/0611200 — "Boltzmann's reported (possibly apocryphal) reply."

---

## Cross-cutting flags for the drafting table

1. The two most quotable "facts" in this history are the two least literal: S = k ln W is Planck's formula for Boltzmann's idea (item 1), and "go ahead, reverse them" is Kac's anecdote for Boltzmann's argument (item 15). Both are usable — attributed.
2. Two venue/date traps recur in the secondary literature and are corrected above: Ramsey 1956 is Physical Review, not Proc. R. Soc. (item 9); Landau & Lifshitz Vol. 5 is Russian 1951 / English 1958, with a separate Landau-only 1938 book in both Russian and English (item 14).
3. "Statistical mechanics" is Gibbs 1884, the book is Gibbs 1902 (item 6); the Gibbs paradox is Gibbs 1876 (thermodynamic) plus Gibbs 1902 (generic/specific phases), raised as a paradox by Neumann (1891) and Duhem (1892) (item 5). Collapsing either pair is the standard textbook compression.
4. Live controversy, flagged not settled: negative absolute temperature (item 9) — Ramsey's reading is standard, Dunkel & Hilbert's Gibbs-entropy objection (2014) is on the record and disputed in turn.
