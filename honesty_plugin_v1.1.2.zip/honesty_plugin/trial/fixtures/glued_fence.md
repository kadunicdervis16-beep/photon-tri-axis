# DEPARTURE FROM THE PHOTON BASELINE SERIES

## Paper 12.5: The Ensemble Illusion — A Structural Critique of the Ensemble in Standard Statistical Mechanics

**By Dervis Kadunic**

2026 — v3 DRAFT (2026-11-08)

---

## ABSTRACT

Standard statistical mechanics describes a single system by a population
that does not exist: the **ensemble**. A gas in a box *is in* the canonical
ensemble; its energy *is* an average over the ensemble; nature *samples*
the canonical distribution. The grammar is possessive and locative; the
ontology is substantive. The ensemble is treated as a physical population
— a collection of copies of the system, distributed according to weights
that nature is said to use — although no procedure ever counts a copy,
weighs a copy, or meets a copy. What is counted, in every laboratory
procedure the formalism serves, is one system, over time, in records.

Paper 12 proved the **census result**: every frequency the aggregated
ledger needs is a ratio of actual counts over a declared population and a
declared window, and the sampling-measure postulate the programme had
expected to need was never needed — it was dissolved, not adopted
(Paper 12 §§3, 5). This paper turns that result outward as a critique.
If every quantity any procedure actually returns is already a census
quantity, then the standard account's ensemble ontology is either false
or untestable — and we audit which.

**Method.** The canonical ensembles are examined in an audit matrix
(§4): for each construction — microcanonical, canonical, grand canonical,
and the ergodic bridge that is asked to connect all three to a single
system — the matrix records what is counted, what is postulated, what is
measured, and what the prose claims against what the equation contains.
Before the matrix, two canonical equations are priced symbol-by-symbol
in §3: the canonical weight, and the ergodic identity that equates an
ensemble average with a time average. In both cases the weight enters as
an adopted rule and the population enters as prose; neither enters as a
count. The word "ensemble" does no counting work in any derivation; it
enters only in the gloss.

**Historical context.** This is not a new objection, and it was not met
with derivation. The reversibility objection (Loschmidt, 1876) and the
recurrence objection (Zermelo, 1896) showed, on the standard account's
own mechanical premises, that the statistical reading of the second law
could not be a theorem of the dynamics alone. The objections were
answered by postulation: equal a priori probability was assumed where a
derivation was required, and the assumption was then inherited as if it
had been proved. §2 documents the exchange and the inheritance — an
objection answered by a postulate is not an objection answered.

**Scope.** This paper critiques the *ontological gloss* — the
ensemble-realist idiom — not the standard formalism's predictive
apparatus. No partition function value, no equation of state, and no
measured heat capacity is in dispute. The canonical recipe computes, and
computes well. What is in dispute is whether "the system is in the canonical ensemble" describes a population the system belongs to, or a weighting rule the calculator applies. The audit finds: always the latter, claimed as the former. The constructions audited in the core (§§2–10) are the classical canonical ones; the quantum form of the same idiom — the density operator read as a population-free possession of a single system — is audited under the same standard in Appendix D.1, at Stage C/P only: its gloss is priced there, and no native quantum claim is made there or anywhere in this paper.

**Verdict.** "Ensemble," read as a physical population whose weights
nature uses, is a category mistake institutionalized as ontology. Nothing
measured is ever measured over copies; everything measured is measured
over records of one system, or over a declared population of actual
systems, in a declared window. The verdicts of §4 are the author's audit
classifications, printed for inspection in the form §0.5.5 requires:
where a script computes, the computation is machine-checked; where the
audit classifies prose against equations, the classification is the
author's, machine-recorded, and labeled as such. No classification in
this paper wears a machine badge it did not earn.

**What this paper adds to Papers 9.5 and 11.5.** Paper 9.5 supplied the
audit standard this paper enforces (§0.5.3): a thermal variable counts as
derived only if it is obtained without temperature, equilibrium
assumptions, or ensemble distributions as primitives — and 9.5 applied
that standard to temperature. Paper 11.5 supplied the audit form: the
standard formalism's *equations* placed beside the standard formalism's
*prose*, the disagreement exhibited property by property. This paper
applies 9.5's standard to ensembles and 11.5's form to populations. Its
contribution is not a new formalism. Paper 12 already built the positive
account — census, dissolution, population temperature, exact-counting
arrow, constructed equilibrium — and this paper does not rebuild it. The
contribution is the outward audit: the standard account measured against
the standard 9.5 set for it, in the form 11.5 established, with Paper 12's
results as the native vocabulary for stating what the standard equations
already imply but do not say.

**Reading guide.** §1 states the charge. §2 documents the historical
record — the objections, the postulates that answered them, the
inheritance that followed, and the critical tradition that resisted
it. §3 prices two canonical equations
symbol-by-symbol: the canonical weight (§3.1) and the ergodic identity
(§3.2) — and prices the inference bridge (§3.4). §4 runs the audit matrix over the canonical ensembles and records
the denial of the blanket thesis in full. §5 applies the audit standard
to temperature. §6 is the bridge ledger for entropy — one name, four
counting rules. §7 audits the arrow and states the costed
programme the open joint defines (§7.4). §8 records the machine
verification. §9 answers steelmanned objections. §10 is the
convergence audit: where current practice already computes census
ratios under probability language. §11 states the falsification
conditions (continuing the series numbering at C34). Appendices carry the verified historical sources (A), the
Paper 12 inheritance lines (B), figure plans (C), the quantum audit,
the parking lot, and the revision history (D), and the script
listings (E).

---

## 0.5 &nbsp; EPISTEMIC ARCHITECTURE

This paper applies Paper 11's verification discipline, in the audit form
Paper 11.5 established, to standard statistical mechanics' "ensemble"
claims. This section defines the machinery — badges, dependency labels,
the audit standard, firewall rules, and the script protocol — so the
audit's verdicts are mechanically checkable where they are computed, and
honestly labeled where they are classified, not rhetorically asserted in
either case.

### 0.5.1 Badge definitions

Every claim in this paper carries an epistemic badge:

- **[LEVEL A]**: Machine-checked (script exits 0), or inherited from a cited source paper's Level A result with lineage cited (Appendix B), or prose-proved with no gaps. The strongest
  claim this paper makes.
- **[LEVEL B]**: Illustration, conditional reading, or author-authorized
  declaration. Honest but weaker — the dependence is stated.
- **[LEVEL C]**: Deferred to a later paper. Not claimed here.
- **[NO BADGE]**: Cannot be derived, not declared as assumption. Under Paper 11's
  D.2 rule: conjecture — do not cite as established.
- **[LEVEL A, author-authorized]**: the declared-axiom subtype of Level A —
  declaration-backed, not derivation-backed. It guarantees exactly three things:
  (1) the declaration was made, by the author, in the open — its content, date,
  and location are recorded; (2) the declaration is *traceable* — the inheritance
  line (§0.5.6) names the source paper, the section, and the registry row where
  the declaration is recorded; (3) the declaration is *stable* — downstream
  claims carry the subtype with it, so the declared character cannot be laundered
  into "proved" by distance. It does NOT guarantee independent derivation, a
  machine check, or that the declaration could not be otherwise. A claim wearing
  this badge is an honestly labeled declared axiom — citable, checkable, and never
  to be called a proved fact. It outranks [LEVEL B] (conditional, illustrative, or
  otherwise unstaked) and is outranked by plain [LEVEL A] (derived or machine-checked).
  Every [LEVEL A, author-authorized] badge states its falsifiers — concrete,
  checkable conditions under which the declaration fails, stated where the claim is
  badged or cited at the badge site. A declaration with no stated failure condition
  is an assertion, not a badged claim. Where no genuine falsifier can be stated,
  the limit is stated explicitly instead — never invented.

**Denied [Level A]** is a verdict returned at Level-A rigor — not a weaker grade of endorsement. It marks a claim put through Level A treatment (machine check, inherited Level A result, or gapless prose proof attempted) whose examination returned a negative verdict, and which is entered in the register below under the registration condition stated in this same paragraph: the bracketed **[Level A]** names the rigor of the examination, and **Denied** is the verdict. It is not Level B or C — those are grades of endorsement, weaker or deferred; a denial is not an endorsement at any strength, and rebadging it B or C would misrepresent denial as a dimmer endorsement. The phrasing is deliberate and author-authorized: the badge refuses to let a denial be misread as a weak claim. Registration carries one further condition, stated here inside the definition so the rule is complete in itself: a denial is entered in this register only where a Level A positive account of the audited quantity stands in the series for the denial to stand on — Paper 12's census account stands under items (1)–(4) below; where no such account stands, the examination's verdict is recorded at its own site and the slot is printed *not registered*, as slot (5) is. In this paper four claims wear it, and the register is stated here in one place so the paper's Denied surface cannot be misread: (1) the blanket thesis "The ensemble is a physical population whose weights nature uses," charged in §1.4 and denied in §4 on the strength of the §3 pricing and the §4 audit-matrix treatment — the pricing shows the weight entering both canonical equations as an adopted rule, never as a count; the matrix records, ensemble by ensemble, that no construction counts the copies its prose populates; and the Paper 12 census results inherited at Level A (Appendix B) show every quantity the procedures return already accounted for without the population; together they leave the blanket thesis with no route. (2) Temperature as a possessed scalar, derived from the zeroth law (§5.1). (3) "Temperature jumps from +∞ to −∞" as a statement about a system (§5.3). (4) The Gibbs paradox as a discontinuity in nature (§6, claim L6.4-P12.5). (5) — *not registered.* The quantum blanket thesis of Appendix
D.1 was examined at the same sites as items (1)–(4), and its
author's verdict is recorded at D.1.5 as [CLASSIFIED]: the
thesis earns NO BADGE. It is not entered here, for the reason
D.1.5 states: the register's denials stand where a Level A
positive account of the audited quantity exists in the series
(Paper 12's census account), and no paper of the series has
yet priced the quantum formalism positively. The empty slot
is printed so the absence is a record, not an oversight. Each was put through Level A treatment in its own section — machine check where the claim is computable, inherited Level A results, gapless prose examination — and each returned the negative verdict at its site, marked [CLASSIFIED] there as the author's verdict. Paper 11.5, the template, records exactly one Denied claim; this paper records four, because its audit examines four claims at that rigor, and the register follows the audit, not the template. The denials are the audit's verdicts — the author's verdicts, recorded as such — not machine outputs. This stands alongside the record below: the standard account's individual ensemble claims earn **NO BADGE** where they are un-derived and un-declared, and earn the classification labels of §0.5.5 where this paper's audit examines them; the four claims above are the distinct claims examined at Level A, and denied.

Hybrid claims — partly machine-checked, partly declared — are marked by listing both badge components explicitly: **[LEVEL A: MACHINE / AUTHOR]** (alternative form [LEVEL A-M / LEVEL A-A]). The marking keeps the claim's overall Level A status and tells the reader at a glance which half is which: the computational content was script-verified (**MACHINE**), while the foundational premise — or the identification that gives the computation its label — was author-declared (**AUTHOR**). The halves do not cover each other. The MACHINE half carries the script-validation discipline (§0.5.5): the badge is exactly as wide as its validation artifact, and the machine result is never read as proving the declared identification. The AUTHOR half carries the declared-axiom discipline (§0.5.1 subtype rule): stated falsifiers where genuine ones exist, stated limits otherwise — never invented — and the identification never extends the machine content. Status versus coverage: "overall Level A status" is rank — the claim is not demoted to [LEVEL B] for its declared half. Coverage is narrower: per §0.5.6 rule 2, the [LEVEL A] covers exactly the machine-checked content; the AUTHOR half is carried under the declared-axiom discipline, never under the machine badge. The mark splits; it does not average.

Two further forms complete the taxonomy, both carried from Paper 12 (its §0.2/§0.5.1 discipline) and used in this paper's inheritance lines and §11. **[LEVEL A: AUTHOR]** is the short form of the author-authorized family: the claim is a declared axiom or declared construction of its home paper, guaranteed as the subtype rule above guarantees — declared in the open, traceable, stable downstream — with its falsifiers stated at its site, and with no derivation or machine content claimed. Where this paper carries a Paper 12 claim badged [LEVEL A: AUTHOR] at home (the spine exhibits' temperature identification among them), the short form is what the inheritance line prints, and it means exactly what the long form means. **Three-component splits [LEVEL A: MACHINE / PROOF / AUTHOR]**: Paper 12's round-11 discipline lets a split name a third component, PROOF — content carried by a gapless prose proof rather than by a script. Under such a split, [LEVEL A] covers exactly the MACHINE and PROOF content; the declared content stands under the AUTHOR discipline; the components are never averaged, and an inheritance line carrying the three-component form names all three, as Appendix B's lines do.

**Rule (author-authorized 2026-10-18 — framework-wide, from now on, in every paper):** wherever the paper presents an approximation, a rounding, or a translator *as its number* for a badged claim, it is [LEVEL B] — honestly labeled with why it was made — and the real number is specifically badged right beside it. Nothing the paper badges is rounded silently; the approximation never stands in for the number, and the number never hides behind the approximation. A translator earns its keep only beside the real thing. (Incidental '≈' in expository prose is notation, not the paper's badged number, and is out of scope.)

**Precision convention.** Badged numbers print at fixed decimals (−1.9886 at 4dp); the machine's full computed value is stated where the rounding is load-bearing. The convention's standing example is inherited, not re-derived: Paper 11.5's MC.1 headline −1.9886 [LEVEL A: MACHINE / AUTHOR], whose machine value is −1.9885612518827713 (Paper 11.5 §11.4; inheritance line, Appendix B). The printed form is presentation, not a second approximation of the claim. This paper's own badged numbers are, in the main, exact — integers and rational ratios of counts, in Paper 12's arithmetic — and where a Stage P/C audit instrument returns a decimal (§0.5.4, M-series), the rule above governs it in full.

The audit's central record is that the standard account's ensemble claims
earn **NO BADGE** under this discipline where they assert physical
populations (§4), while Paper 12's counterparts earn **LEVEL A** at home
and are carried here at that standing (Appendix B). The §4 matrix is not
a second independent machine verdict — it is the audit *record* of where
each construction's derivation chain bottoms out (§0.5.5). Where the task
is a derivation the standard account never attempted in census terms, the
record is a published null in Paper 11's F.57 sense: expected, stated,
and valuable as a record, not presented as a surprise.

### 0.5.2 Dependency labels

Each Level A claim lists its dependencies as bracketed labels:

- **[L1]**: The standard formalism's equations — taken as given for the audit's purposes. The critique does not dispute them. In this paper: the canonical weight and partition function, the ergodic identity (ensemble average = time average), and the four entropy formulas (Boltzmann, Gibbs, Shannon, von Neumann), each cited at its audit site.
- **[L2]**: Paper 12 (v4) Level A results — inherited with lineage (Appendix B): the census rule (§3), the dissolution of the sampling-measure postulate (§5), population temperature D(P,W) (§7), the exact-counting arrow results (§8), constructed equilibrium (§9), and the open joint (§§8.6/9.6) — carried here as open, at exactly its home standing; this paper points at it and does not close it.
- **[L3]**: Paper 11.5 v26 and Paper 11 v69 — the audit form itself (prose-beside-equations, badge discipline, firewall discipline), and Paper 11's relational role theorem, inherited with lineage (Appendix B).
- **[L4]**: Historical sources — Loschmidt (1876), Zermelo (1896), and the surrounding record, verified per Appendix A. A historical claim in this paper stands on its Appendix A entry, not on the prose's memory of it.
- **[L5]**: Textbook sources — Gibbs (1902), Tolman (1938), Landau & Lifshitz, Pathria — the critiqued prose, cited conservatively. This paper does not fabricate verbatim quotations: a textbook position is quoted only where Appendix A records a verified text; everywhere else it is paraphrased, and the paraphrase is marked as paraphrase at the site.
- **[L6-12.5]**: This paper's own definitions (the audit matrix's columns, the reading taxonomy of §1.5, the four-question pricing method of §3.3).

Bridge rule (from Paper 10.5): L_claim ≤ min(L_i) — a claim cannot outrank its
weakest dependency.

### 0.5.3 The audit standard and the firewall (FW.1-12.5)

The centerpiece of this paper's architecture is not a badge but a
standard — the standard the audited constructions are measured against,
stated here, in advance, so no verdict in §4 can be charged with moving
it. The standard is Paper 9.5's, inherited [L3] and stated in Paper 12's
architecture in the same words:

> **The audit standard (Paper 9.5).** A thermal variable counts as
> DERIVED only if it is obtained without temperature, equilibrium
> assumptions, or ensemble distributions as primitives.

The standard is a test of provenance, not of output. A construction that
begins by assuming a temperature, an equilibrium, or a distribution over
an ensemble, and ends by recovering that temperature, that equilibrium,
or that distribution's averages, has computed consistently — and derived
nothing. The standard asks one question of every ensemble construction in
§4: *where does the weight come from?* Three answers are possible. The
weight is counted — obtained from actual records, with no thermal
primitive assumed: DERIVED, by the standard. The weight is declared —
adopted openly as a postulate, with its status stated: honest, and
badged as declared, never as derived. The weight is inherited in silence
— present in the equations, absent from the prose's account of itself:
that is the failure this paper audits. A construction may still be
excellent physics with a declared or even an inherited weight — the
recipe's record is not in dispute (§1.2). What it may not do, under the
standard, is call the weight derived, or call the population it weights
physical, without paying for either word.

Paper 11's F.42 enforces Stage-N vocabulary discipline; Paper 11.5's
FW.1 enforces the audited paper's own-voice discipline; this paper's
**FW.1-12.5** enforces two analogous disciplines on this paper's own
text, against the two vocabularies this audit forbids itself:

- **Group A**: No two-level vocabulary in the paper's own voice. The
  paired level-words the single-regime rule excludes — the fine level
  that is counted and the coarse level that is said to summarize it —
  do not occur as this paper's description of anything. Paper 12's
  replacement vocabulary is used instead: *ledger record* for a body's
  actual per-tick data, *count-class* for a class of the census,
  *population* and *window* in their inherited senses (§1.3). The
  standard ensemble names are not this vocabulary: a standard
  construction's received name, where it contains a level-word as a
  prefix, is the *name of the audited object* — mention, at Stage C,
  under the exemption below — never this paper's own description.
- **Group B**: No positive ascription, in the paper's own voice, of
  either audited gloss: no temperature ascribed as an intrinsic
  possession of a system or a population, and no ensemble weight
  ascribed as physically real — as nature's sampling rule, as a
  population the system inhabits, or as a distribution the system
  obeys. The paper audits both ascriptions; it must not commit either.

**Exemption breadth — a design decision with rationale.** FW.1-12.5
exempts *mention* of banned language from *use* of it; the exemptions
are structural (where the text is, not what it says), fail-closed where
a violation is still possible. (i) *Quoted-context exemptions* (Groups
A, B): blockquote lines, textbook-paraphrase spans marked as paraphrase,
and passages explicitly staged as the standard account's statement of
itself are the claim being critiqued, not the paper's voice — policing
them would forbid exhibiting the target. (ii) *Critical-window tokens*
(Group B): a window around a hit containing critical tokens ("not",
"never", "refut", "audit", "versus", and their kin) exempts it as
negative or critical use — the thesis *requires* negative uses; a wider
window would let distant negation wash a positive ascription. The
residual risk — a genuinely positive ascription adjacent to critique
prose — is human-audit territory, stated here rather than hidden.
(iii) *The received-name exemption* (Group A): a level-word occurring
only inside a standard construction's received name is mention of the
audited object. Residual risk, stated: a two-level description smuggled
inside a sentence that also carries a received name would pass on the
name's exemption — zero live instances at v1 drafting, human-audit
territory. (iv) *The changelog exemption is fail-closed*, as in Paper
11.5: a changelog line is exempt only if it is an Appendix D entry *and*
the matched pattern is quoted on that line.

FW.1-12.5 scans the paper's full text at build. Zero breaches = the
paper practices what it preaches. **Coverage, stated exactly:** the
script's machine coverage is narrower than this discipline. It scans
for the two level word-forms (Group A's core tokens), the neutrino ban
(Paper 15 owns the topic), the adopt-a-probability pattern, and
it *lists* its
quotation-context exemptions in the run record for inspection;
Group B's ascription discipline and the remainder of Group A's
vocabulary are policed by the author's classification and human
audit, not by the script. §8.7's record states the coverage in
those terms; no sentence in this paper claims a wider scan.

### 0.5.4 Script protocol

The verification suite for this paper is deliberately smaller than
Paper 11.5's: exact censuses and exhibits, two instruments that run the standard
machinery on its own terms, and document hygiene — nothing else is
mechanized, and nothing mechanized is oversold.

| Series | Scripts | Function | Standing |
|--------|---------|----------|----------|
| E.1–E.6 | Exact censuses and exhibits | E.1: the arrow census — binary records enumerated exactly (non-polarized share against its floor; the balanced share's fall). E.2: the bounded-population census behind negative-temperature prose — the record count's slope computed exactly on both sides of its maximum. E.3: the Gibbs-paradox counts under two counting rules, the rule switch priced exactly. E.4: the Kac ring exhaustively — recurrence and non-monotonicity over every colouring and flipper placement of the declared rings. E.5: the quantum provenance exhibits — preparation censuses against their ascriptions (exact eigenvalues and trace distances; von Neumann entropies in disclosed floats), and the provenance pair whose marginals coincide. E.6: the updating exhibit — the MaxEnt posterior from a counted mean, exactly, against a second census of the same mean. | COMPUTED |
| M.1–M.2 | Monte Carlo audit instruments | Stage P/C instruments. They audit the standard machinery on its own terms: a sampler is run under the standard recipe's own acceptance rule, and its output is compared against targets the enumeration computes. **The sampling rule is the postulate under audit** — it is adopted here as the recipe states it, exhibited, and never claimed as a native derivation. M.1: the canonical recipe (weight as dial; uniform-weight control; sign-flipped mutant rejected with a printed witness). M.2: the Ehrenfest urn — simulated frequencies against the exact census shares of the same model (the time-average cashed as a census). Continuum machinery inside the samplers (floating-point exponentials) is the exhibit, disclosed in-script, not scaffolding. | COMPUTED — as audit exhibits; the recipe's postulate is the object, not a premise of this paper |
| G.1–G.4 | Document hygiene | G.1: historical consistency — Appendix A's (year, author) pairings checked against the body's, in both directions, under the pairing rule declared in-script. G.2: audit-matrix completeness — §4's matrix carries exactly its six required rows, each fully filled. G.3: premise-inventory completeness — §7.4's table carries its six premises, each priced, the closing open-status sentence present, and the inventory's two toy facts recomputed at small size. G.4: rewrite-pair form — §1.3.6's six pairs, each B-form carrying a declared population and window, firewall-clean. | CLASSIFIED inputs, machine-checked consistency |
| FW.1-12.5 | Firewall | The machine-scanned subset of the §0.5.3 disciplines (level word-forms, the neutrino ban (Paper 15), adopt-a-probability pattern; quotation exemptions listed for inspection) over this paper's full text; the remainder of the discipline is author-policed, as §0.5.3 states. | CLASSIFIED voice judgments, machine-scanned (§0.5.5) |
| RB.1 | Runner | Runs the suite on the final tree and reports every exit code; a green suite is claimed only for the exact tree built (the series' final-tree rule). | — |

All scripts exit 0 on success. A null result, where a census or an
instrument returns one, is published per Paper 11's F.57 precedent.
All scripts are embedded as listings in Appendix E; their outputs are
published with the audit record. Every script carries the series'
INPUT_PROVENANCE block: each input is classed paper-defined,
cited-paper, control, declared-assumption, or
arbitrary-representative, with its source named — a script that cannot
say where its inputs came from backs no badge.

### 0.5.5 What "machine-checked" means here — and what it doesn't

"Machine-checked" does not mean "proved by computer" in the Coq/Lean sense.
This paper's scripts fall in **two columns**, and the audit record is organized by them.
**COMPUTED**: the claim's logical structure is implemented as executable code, the code
runs without error, and the output matches the paper's stated verdict — E.1–E.6
(the censuses, the weight-against-count separation, the finite ergodic pricing, the
four-formula evaluation, the quantum provenance exhibits of E.5, and the updating
exhibit of E.6, all in exact integer or rational arithmetic wherever the
audited side permits it — E.5's entropies are the declared float exception,
disclosed in the script and at §8.9), and M.1–M.2 *as exhibits* (the sampler's convergence to the
recipe's own enumerated targets is calculated, not quoted; the uniform-weight control's
convergence to the census values is calculated, not quoted). For M.1: the weight's
status as a dial is shown by running identical trajectory code under three acceptance
rules — the exhibit is the code's behaviour, computed on the run.
**CLASSIFIED**: the G-series, FW.1-12.5's voice judgments, and the §4 audit matrix
itself — the author's analytical classifications as inputs, printed by the script.
For FW.1-12.5: the paper's lines are scanned, not eyeballed — but the voice judgments
(quoted standard claim vs. the paper's own voice; received name vs. two-level
description) are the author's classification. The machine replaces hand-waving where it computes; where it classifies, it publishes
the judgment for inspection, and replaces nothing.

**Open disclosure (honesty requirement).** The §4 matrix's verdicts —
DERIVED, DECLARED, INHERITED IN SILENCE, and the per-construction
bottoming-out records — are author-written, then printed. The matrix is
therefore an honest *record* of the author's audit, in F.57-style null
publication where a derivation is absent, not an independent machine
proof of the audit's verdicts. What the machine *does* independently
verify: every number the audit leans on (E.1–E.6's censuses and
separations are computed from declared record sets, never hardcoded);
the M-series exhibits' behaviour under their stated tolerances, with
mutants rejected on printed witnesses; G.1's citation record against
Appendix A; and FW.1-12.5's mutant battery, which must catch genuine
planted violations before its zero-breach report is credited. The
reader is told exactly which parts are computed and which are
classified — no more, no less. Audit verdicts about standard claims are the author's classifications (§8.8 states the boundary globally); the four Denied verdicts of §0.5.1's register carry a **[CLASSIFIED]** mark at their sites in §§4–6, so the paper's most badge-shaped verdicts cannot be misread as machine results.

### 0.5.6 The badge inheritance rule — no silent Level A by distance

An inherited claim may not outrank its source. Every claim this paper inherits at
Level A — from Paper 12, Paper 11, or anywhere else — carries an **inheritance line**
in Appendix B:

**Inheritance:** Source: Paper 12 v4 §X.Y — badge carried at source: [LEVEL A] or
[LEVEL A, author-authorized] — validation: the source's registry row (script id, or prose
section, or author-authorized definition with date, as recorded there) — 12.5 reliance: <what
this paper uses it for>.

The line is the traced, checkable validation path. The reader can open the cited source
at the cited section and find the same badge with the same backing — no trust in the
chain is required, only in the named registry rows.

Three hard rules govern the line:

1. **The subtype propagates — the bridge rule.** If the source's own registry records
   the claim as an author-authorized declaration, the claim is carried here as
   [LEVEL A, author-authorized] with its stated falsifiers, never as bare [LEVEL A].
   Inheritors cap at the declared level: distance does not convert a declared axiom
   into a proved fact, and no downstream module may silently upgrade it. The rule
   covers limitations as well as subtypes: Paper 12's open joint (§§8.6/9.6) is
   inherited here *as open* [L2] — a stated limitation at home is a stated limitation
   here, and no passage of this paper rests a verdict on closing it.

2. **Hybrids are split, not averaged.** Where a claim's content is partly machine-checked
   and partly declared, [LEVEL A] covers exactly the machine-checked content, and the declared identification
   is disclosed in the line. The badge never covers more than its validation artifact.

3. **Inline cites point to Appendix B; Appendix B carries the line.** Every inherited-claim
   cite in §§1–11 names its Appendix B entry; the entry carries the full
   inheritance line. Nothing inherits Level A from an inline cite alone.

---

## 1 &nbsp; THE INDICTMENT

### 1.1 What this paper does

This paper performs a structural audit of one word — **ensemble** — as
used in standard statistical mechanics. It examines the canonical
ensemble constructions, documents what each one counts, what each one
postulates, and what each procedure that uses them actually measures,
and shows that in every case the determinacy of the result depends on
counts over actual records that the "ensemble" idiom elides — while the
population the idiom populates is counted by no one, at no step.

It then contrasts the ensemble account against Paper 12's census
account (§1.3), prices the two equations on which the ensemble's claim
to physicality rests (§3), runs the full audit matrix (§4), and states
the falsification condition that would vindicate the ensemble as a
physical population (§11).

### 1.2 What this paper does not do

It does not dispute any partition function value, any equation of
state, or any measured heat capacity. The numbers are not in question.
It does not propose an alternative statistical mechanics — Paper 12
already stated the framework's account, and §1.3 receives it. It does
not claim the standard account fails predictively — the canonical
recipe computes, and computes well, and the audit's instruments
(M.1–M.2) verify that on the recipe's own terms before auditing
anything. It claims the standard account's *ontology of populations*
fails descriptively, in a specific and auditable way: the formalism's
working objects are counts and adopted weights, and its prose
describes populations and nature's sampling, and the two descriptions
are not the same description. One boundary is declared here rather than discovered later: the audit's core (§§2–10) prices the classical ensemble idiom, and nothing in §§3–10 should be read as having priced its quantum form. The density-operator form of statistical mechanics wears the same gloss — a state ascription read as a population-free possession of a single system — and Appendix D.1 audits that form under the same standard, at Stage C/P only: it prices the gloss, states no native quantum claim, and introduces no primitive. The positive quantum-adjacent work of the series belongs to the later papers that own those targets (Papers 13 and 15), and Appendix D.1 does not pre-empt them.

### 1.3 Two accounts

The dispute is between two complete accounts of what an ensemble
average is.

**Account A (ensemble realism).** The ensemble is a physical
population. A system in thermal contact with a reservoir *is in* the
canonical ensemble — membership in the population is a fact about the
system. The weights are nature's: the canonical weight gives the
fraction of the population in each state, and that fraction is a
physical distribution, not a calculator's choice. An ensemble average
is what measurement reveals, because measurement samples the
population: the system, over time or over repetitions, presents the
population's distribution, and the average over the uncounted copies is
the value the counted system discloses. The copies are there, weighted,
waiting to be averaged.

**Account B (census).** Every quantity any procedure actually returns
is a count, or a ratio of counts, over actual records. A time average
is a ratio over the records of *one* system across a declared window
of ticks. A population average is a ratio over the records of a
*declared population* of actual systems — laboratories do prepare such
populations, and counting them is ordinary census work. A frequency is
a census ratio in Paper 12's sense (§3, inherited [L2]; Appendix B):
actual class-members divided by actual records, over a declared
window. Weights enter only as adopted rules for weighting counts: the
canonical weight is a rule the calculator applies to a count set, and
its exponential form and its β are adopted — dialled, derived from a
bath construction under stated assumptions, or fitted — never counted
off a population of copies. Nothing physical corresponds to the
uncounted copies: no record is a record of a copy, no count enumerates
them, and removing them from the prose changes no number any procedure
returns. On this view, "the mean energy is the ensemble average" is
shorthand for "the mean energy is the weighted count the recipe
prescribes" — true as a recipe, and as a population claim, without a
referent.

The audit of §§3–4 shows: every equation in the standard formalism is
written in Account B. The weight is a function applied to states; the
partition function is a sum the calculator performs; the time average
is a census ratio
over one trajectory's records. Every textbook sentence of the gloss is
written in Account A. The two accounts are empirically equivalent in
every case this paper examines — the numbers are the same; only the
account of the numbers differs — which means the choice between them
is decided not by experiment but by honesty: which account *says what
the equations and the procedures say*? Account B. Account A is the
equations plus one unearned promotion — a weighting rule promoted to a
population, an adopted weight promoted to nature's distribution —
repeated across the canonical constructions and taught as fact.

Paper 12's contribution is to state Account B natively — in the
ledger's own terms (populations, windows, count-classes, census
ratios) rather than as a commentary on the standard formalism. The
census rule and the dissolution of the sampling-measure postulate are
Account B as proved instances, machine-checked at home [LEVEL A —
inherited; Appendix B], not philosophical preferences. This paper's
contribution is to show that the standard formalism was already
Account B all along — its derivations never leave counts and adopted
weights — and that Account A survives only in the prose *about* the
derivations.

**Scope declaration — "ensemble", "population", "window", declared
for the audit.** The critiqued term is "ensemble" in the sense of
Account A: a population of copies of one system, weighted by a
distribution asserted to be physical. The paper's positive terms are
inherited, not redefined: "population" carries Paper 12 §3's declared
sense — the actual finite family of bodies under count, every member
of which stands at a tick with its own ledger record — and "window"
carries Paper 12 §7's declared sense — the declared tick interval over
which a census ratio is taken, as in D(P,W) [L2]. Both are used here
at their home standing (Appendix B) and neither is extended. No new
primitive is introduced by this paper; its own definitions are
confined to the audit's machinery [L6-12.5].

### 1.3.5 Cash value: what changes in the next paper

A reader can agree with every step of the audit and still ask: *so
what?* Here is the cash value — what a working physicist would
actually change in the next paper they write, if they accepted the
audit.

**Language.** Stop writing "we sampled the canonical distribution"
as if a distribution were a place samples are drawn from, and write
what the code does: "we ran a Markov chain under the Metropolis
acceptance rule min(1, exp(−βΔE)); the chain's stationary frequencies
are the recipe's weighted counts." The sampling rule is the recipe;
naming it as the recipe costs no number and removes one population.
Stop writing "the system is in the canonical ensemble" and write the
contact condition that is actually meant — the reservoir, the coupling,
the quantity held fixed — because the ensemble adds no content beyond
the condition, and the condition is checkable while membership is not.

**Claims.** A thermal claim must now carry its provenance, the way a
census already does. Name β's provenance every time: measured against
what reservoir, derived under what bath assumptions, or fitted to what
data — β is the audit's standing example of a primitive wearing a
derived variable's clothes (§0.5.3), and an unnamed provenance is the
inheritance in silence, continued. Declare windows: a time average
without its window, and a population average without its declared
population, are ensemble sentences — averages over an unspecified
collection, priced by no one. The declaration costs one clause; every
standard quantity survives it, because every standard quantity was
always computed over some window and some count set.

**Research programs.** Stop writing "the system explores all
available phase space" — a single system follows one trajectory, and
the exploration idiom ascribes the population's itinerary to the one
system that never performs it; write the trajectory, the window, and
the counted fraction instead. A simulation proposal that budgets
"sampling the equilibrium ensemble" must now state the acceptance
rule, the run length, and the discarded transient — the recipe it
will actually execute. Nothing is lost: every number stays. What
changes is that the number is no longer presented as a reading taken
off a population that was never counted.

That is the practical consequence. Not new equations — the equations
already say all of this. New honesty about what the equations say.

---

### 1.3.6 Textbook reform: a style guide for authors

Section 1.3 set the two accounts side by side. Account A writes in the possessive and locative
grammar of a population the system belongs to, whose weights nature is said to use; Account B
writes in census form — counts, and ratios of counts, over a declared population and a declared
window, with weights entering only as rules the calculator applies to a tally. The textbook
sentence is almost always Account A; the computation it glosses is almost always Account B. This
guide closes that gap at the level of the sentence. The A-lines below are FORMULATION EXHIBITS —
composite statements of the idiom as printed across the canonical corpus, NOT verbatim
quotations — assembled so that the idiom can be exhibited and rewritten without fabricating a
source text for it. Each B-line states the census form of the same working situation;
where the census form changes what the sentence can honestly claim,
the row's fourth column prints the change — pairs 2 and 5 print the
largest changes, and say so in their cells. The guide is for authors: keep the
computation; rewrite the sentence that presents it.

| # | Account A — the idiom as printed (exhibit) | Account B — the census form | What changed |
|---|---|---|---|
| 1 | "The system explores the microcanonical ensemble." | One system follows one trajectory; its time average over the window of the single run record is matched against the census ratio over the population of records lying in the declared energy shell. | The population's itinerary is returned to the one system that performs it: two tallies, one trajectory, no exploration by a collection. Idiom: the ergodic exploration idiom of the teaching tradition (§3.2's target; §4's ergodic row), riding on Gibbs 1902's imagined collection. The matching of a time average against a shell census is a *check* the author performs, not an identity the sentence asserts: §3.2 prices the identity itself, at NO BADGE as a universal claim. |
| 2 | "The gas is in the canonical ensemble at temperature T." | For the population of vessels prepared in contact with the stated reservoir and the window of the contact interval recorded for each vessel, the temperature line is D(P, W) — the reconcile count for that population and that window, divided by the count of body-ticks in them — and the canonical name marks the weighting rule the calculator applies to that census. | Membership in a population is replaced by a contact condition, a declared population and window, and a (population, window) reading in the form of §5.5; the ensemble name survives only as the name of a rule. Idiom drawn from the canonical/textbook locative grammar generally. |
| 3 | "Nature samples the Boltzmann distribution." | What is counted is the population of repetitions of the preparation, tallied over the window of the repetition record; the Boltzmann weight is the adopted rule, priced in §3.1, that the calculator applies to that tally. | The sampling agent is removed: repetitions are counted, and the weight is named as a rule with a price, not as an act of nature. Idiom: the sampling idiom of the recipe tradition; §2.6's confessed postulate (Tolman 1938) is its honest form. |
| 4 | "The ensemble average gives the measured value." | A measured value is the census over the population of readings returned by the instrument in its stated runs and the window of the observation interval for those runs; the weighted sum is a prediction of that census, carrying the bridge price of §3.2. | The direction of the claim is reversed: the census is what is measured, and the weighted sum predicts it, at the bridge's stated price. Idiom drawn from the canonical/textbook locative grammar generally. |
| 5 | "At equilibrium, all accessible states are occupied with equal probability." | Equilibrium, in the constructed sense, is a stationary census with the maximal assignment count among the census records for the population of assignments realised for the declared preparation, checked over the window of the stationarity check; each counted record enters the tally once, and that once-each entry is the whole of the equal weight. | A state of occupation is replaced by Paper 12's constructed equilibrium — stationary census plus maximal assignment count — and the equal weight is stated as the tally's arithmetic, in the concession form of §9.5. Idiom drawn from Tolman 1938's postulate prose. |
| 6 | "The entropy of the ensemble measures the disorder of the system." | For the population of constituents under the declared classification and the window of the counting record, entropy is reported with its counting rule named — which arrangements were counted, and under which rule, per §6 — and no quantity called disorder is asserted. | The name is made to carry its counting rule and its bridge, per §6, instead of a population's property; "disorder" is discharged as unpriced prose, named in no count. Idiom drawn from the canonical/textbook locative grammar generally. |

**The rules.**

1. **Declare the population.** Every average, frequency, and temperature line names the
   population it is taken over — the actual bodies, records, repetitions, or readings counted.
   An average over an unnamed collection is an ensemble sentence, whatever its symbols say.
2. **Declare the window.** Every census names the window it is taken over — the run, the
   interval, the record — in the sentence or in the quantity's own notation. A result that
   changes when the window changes must not be printed as if no window had been chosen.
3. **Weights are rules — name their provenance and price.** A non-uniform weight is a rule
   the calculator applies, not a distribution nature keeps. Name where the rule came from,
   what was taken as primitive to obtain it, and what its bridge to a census costs, in the
   pricing form of §§3.1–3.2. An unnamed provenance is the inheritance in silence, continued.
4. **Temperature is a (population, window) reading, never a possession.** Write the reading
   in the form of §5.5 — D(P, W), a ratio of counts indexed by the population and the window
   it was taken over — and write the contact condition that was actually imposed. No system
   has a temperature the way it has a mass; a declared procedure returns a reading.
5. **Entropy names its counting rule and the bridge it crosses.** Every use of the name
   states which of the counting rules of §6 is in force — what was counted, on what domain,
   under which classification — and, where the name crosses to thermodynamics, names that
   crossing as a bridge with its price, in the confined form of §6.4.

The guide does not ask authors to stop computing with the recipe. The partition function, the
weighted sum, and the sampler all stand, with every number they return unchanged. It asks only
that the prose say what the computation is: a rule applied to a tally over a declared population
and a declared window, predicting a census that a declared procedure can take. Sentences that
already say that need no reform, and computations need none at all; only the gloss is rewritten.
This exhibit set is the author's [CLASSIFIED] exhibit set, machine-checked for form by G.4.

---

### 1.4 The charge, stated plainly

When a physicist says "the system is in the canonical ensemble," the
sentence asserts: there is a population, the system belongs to it, and
the population's weights are the system's physics. The audit of §§3–4
shows this assertion is never cashed out — every determination of a
canonical average runs through a count: a trajectory's records over a
window, a prepared population's census, or a sampler's tally under an
adopted acceptance rule. Remove the population and there is no
canonical average missing — not even in principle: "the average over
the copies," with the copies uncounted and uncountable by any
procedure the formalism names, is not a physical quantity but a
grammatical one.

The pattern repeats across the constructions. **The population is
always claimed; counts and adopted weights are always what is
computed.** The gap between the two is the subject of this paper.

**The denial record.** The blanket thesis — *"The ensemble is a
physical population whose weights nature uses"* — is the claim this
paper examines at Level A, and the verdict is recorded here, at the
charge, and in full in §4:

> **Denied [Level A]** — the blanket thesis above, denied on the
> §3 pricing (the weight enters both priced equations as an adopted
> rule, never as a count [CLASSIFIED — §0.5.5]) and the §4 audit
> matrix (no canonical construction counts the copies its prose
> populates [CLASSIFIED — §0.5.5]), against the inherited Paper 12
> census results (every returned quantity is a census ratio over
> actual records [LEVEL A — inherited, L2; Appendix B]). The denial
> is the author's verdict at Level-A rigor (§0.5.1), not a machine
> output. **What would overturn it:** a derivation, meeting the
> §0.5.3 standard, of the canonical weight from census counts over
> actual records with no thermal primitive assumed — or a procedure
> whose returned quantity an Account B restatement cannot reproduce
> from counts and declared adopted weights. Either, exhibited, reopens
> the record; §11 states the corresponding falsification conditions
> (C34 onward).

**Roadmap note.** The paper's arc runs critique → accounting: §3
prices, §4 matrices, §§5–7 audit the three quantities the ensemble
idiom carries (temperature, entropy, the arrow), and **§10
(convergence audit) is the capstone** — for the *negative* thesis:
current practice already computes in Account B wherever it computes
at all (§10). Read §10 as the destination of that thesis, not an
appendix. The positive account stands in Paper 12, inherited; the
open joint (Paper 12 §§8.6/9.6) remains open on both sides of the
comparison, and is recorded as such in §7.

### 1.5 Four readings of "ensemble" — and which one is on trial

The entire audit hinges on a specific reading of "ensemble." But the
word admits at least four defensible readings in the literature, and a
defender can always try to escape by sliding between them. This
section fixes the readings, states which one the paper targets, and
shows that the targeted reading is the operative one in pedagogy and
research.

**Reading (i): Gibbs's imagined collection.** "Ensemble" names a
collection the theorist *imagines* — copies assembled in thought so
that averages can be formed — with the imagining declared. On the
record this paper audits [L5], Gibbs's own presentation of the
construction is of this kind (paraphrase, marked as such: the
collection is introduced as a device of the theory, an assembly
considered by the calculator, not a population asserted of the world;
Appendix A records the verified textual basis). This reading is
*honest in Gibbs*: the fiction is labeled as a fiction at its source.
It becomes dishonest in the inheritance, where the label is dropped
and the device is handed down as a description. The audit has no
quarrel with reading (i) as Gibbs stated it; its charge against the
inheritance is precisely that the inheritance does not state it.

**Reading (ii): The physical population.** "Ensemble" names a real
population: the copies, or their distribution, are physically there;
the weights are nature's; the system *is in* its ensemble the way a
body is in a place. This is Account A of §1.3, stated as a reading.
**This is the reading on trial.**

**Reading (iii): The pure recipe.** "Ensemble" names nothing but a
weighting rule: "canonical ensemble" is shorthand for "weight counts
by exp(−βE) and normalize," and "ensemble average" for the resulting
weighted ratio. On this reading the word is a label on a procedure,
and no population is asserted anywhere. The paper has no quarrel with
reading (iii) — it *is* Account B under the standard vocabulary, and a
defender who retreats to it has conceded the audit: the recipe reading
licenses none of the population prose (membership, sampling by
nature, exploration of phase space) that the textbooks print and the
proposals budget.

**Reading (iv): The ergodic bridge.** "Ensemble" names whatever makes
the ergodic identity true: the ensemble average equals the time
average, so the population is cashed out by the single system's
history. This reading is (ii)'s load-bearing bridge — it is the only
one of the four that offers a mechanism by which an average over
copies could be a property of one system — and it is therefore tried
with (ii), on its own pricing: §3.2 prices the identity symbol by
symbol, and §8's finite exhibits (E.4's exhaustive ring census,
M.2's urn run) show both of its sides as counts where a finite
dynamics lets them be counted.

**The paper targets reading (ii), and reading (iv) as its bridge.**
Three reasons this is the operative reading:

*First, the textbooks assert it.* The standard pedagogy introduces the
ensemble as a collection of systems and then proceeds as if the
collection's distribution were the single system's physics — the
membership idiom ("a system in the canonical ensemble"), the sampling
idiom ("nature samples", "the distribution is sampled in simulation"),
and the exploration idiom ("the system explores phase space") are
reading (ii)'s grammar, not reading (iii)'s; a recipe has no members,
is not sampled by nature, and is not explored. The textual exhibits
are documented in §4's matrix, conservatively, with paraphrase marked
as paraphrase [L5].

*Second, the research programs presuppose it.* Simulation and
experiment proposals budget the sampling of ensembles and the
preparation of systems "in" ensembles — not the execution of weighting
rules but the interrogation of populations. If the community meant
(iii), the proposals would say so; the recipe is what they execute,
and the population is what they describe.

*Third, readings (i) and (iii) are compatible with the paper's
thesis.* Reading (i), honestly labeled, is a declared fiction — the
audit's own standard (§0.5.3) honors declarations and audits only
silence. Reading (iii) *is* the census position under another name:
a weighting rule applied to counts, with the counts doing the work.
A defender who slides to (i) or (iii) has conceded the audit: neither
licenses the population idiom of the textbooks, and (iii) is Account
B verbatim. Reading (iv), the only remaining shelter, is not a
separate reading but (ii)'s bridge — and it is priced, in §3.2, at
exactly the postulate it was meant to avoid.

**The trap for the slider:** ask which reading the *textbook* uses
when it introduces the ensemble as a collection and derives the
system's properties from the collection's distribution, and which
reading the *proposal* uses when it budgets sampling that ensemble.
If the answer is (iii), then the introduction should present a rule
and the budget should name an acceptance rule — in the audited prose,
they present a population and budget its interrogation. The operative
reading is (ii). That is the one on trial: §3 prices its two
load-bearing equations, and §4 records, construction by construction,
where each derivation chain bottoms out — at a count, at a declared
postulate, or at a weight inherited in silence.

---

## 2 &nbsp; THE HISTORICAL RECORD

The objections this paper presses are not new, and neither is the pattern of their reception. What the record
shows, read in order, is a sequence with a fixed shape: an exact objection is raised against the statistical
reading of the second law; the objection is answered, not by a derivation, but by a statistical re-reading
whose central step is adopted; the adoption is then inherited by the textbooks as if it had been discharged.
The founders, to a degree the inheritance does not preserve, were honest about which step they were taking:
some declared the device, some built small models to exhibit the tension and priced its assumption, one stated
the postulate as a postulate and named its only justification. The realism — the ensemble as a physical
population, its weights as nature's own — is not in the founding documents at that strength. It crept in
afterward, in the prose inheritance.

This section documents the record in that order. It indicts the gloss, as everywhere in this paper; it does
not indict the apparatus, and it disputes no number any of these authors computed. Where a famous sentence is
a later retelling rather than its author's text, the section says so and uses it only as flagged.

### 2.1 Counting first — and what was added to the count

Boltzmann (1877) showed that the entropy of a gas stands in a fixed relation to a count: entropy is
proportional to the logarithm of the number of permutations — the complexions, in the memoir's own vocabulary
of permutability — compatible with the gas's state. The memoir appeared in the Vienna Academy's proceedings
(Wien. Ber. 76:373–435). The content is a counting result: arrangements of actual constituents, counted;
the logarithm taken of an integer tally; the proportionality is the claim.

Two things the memoir does not contain are habitually credited to it, and the audit restores them to their
author because the restoration is this paper's whole method in miniature. The exact form S = k ln W was not
written there. Neither was the constant k_B. Both are Planck's: Planck (1900) introduced the constant, with a
numerical value, in the black-body work, and stated the exact form in definitive shape the following year
(Ann. Phys., 1901). The formula on the tombstone is therefore Planck's inscription of the earlier idea —
Planck's form, the earlier author's count. Printing the exact equation under the count's name alone drops the
provenance in transit: the name travels, the record of what was established, by whom, in what form, does not.
The point is small; every later section of this paper is the same point at larger scale.

### 2.2 The reversibility objection

Loschmidt (1876) raised the objection in the Vienna Academy's proceedings (Wien 73:128–142), against the
H-theorem of a few years earlier. The objection is exact, and it is worth stating at its full strength,
because the reply it received set the pattern §2.3 will meet again. The underlying mechanics is invariant
under reversal of every velocity. Take, then, any molecular motion along which H decreases — the theorem's
entropy-increasing direction. Reverse every velocity at an intermediate instant. The reversed motion is
equally lawful under the same mechanics, and along it H increases. A purely mechanical, exceptionless proof of
one-directional H-behaviour therefore cannot go through: the dynamics, unaided, licences both directions, and
any assumption that breaks the symmetry — the molecular-chaos assumption among them — is an addition to the
dynamics, not a consequence of it.

The documented reply is statistical, and the audit states it in its documented form. The reversed motions are
conceded to be lawful. What is claimed is a matter of number: the non-equilibrium macrostates are
overwhelmingly outnumbered by the equilibrium ones among the complexions compatible with a macrostate's
neighbourhood, so lawful reversed motions begin from states of vanishing census share, and the theorem
survives — read statistically. The objection's logical point is not met; it is priced, and the price is a
weight: states are to be counted, and the counting is asked to carry a conclusion about which motions a system
will display. Whether counting alone supplies that weight is the question §§3–4 of this paper price in the
canonical formalism itself.

One famous sentence is not part of this record and is used nowhere here as a quotation. Boltzmann is widely
reported to have answered with words to the effect of "go ahead, reverse them." The line is not in the
published papers in that form; its traceable source is Kac's retelling (Kac, 1959) — usable, if at all, only
flagged as a retelling. A history that audits provenance does not quote anecdotes as text.

The objection's spirit should be recorded as carefully as its
logic. Loschmidt was Boltzmann's own teacher and Vienna
colleague, and the objection was not a campaign: it appears
inside a paper on thermal equilibrium, as a demand on what kind
of theorem the H-theorem may claim to be — no exceptionless
mechanical proof, and molecular chaos named as an added
assumption rather than a consequence of the dynamics.
Boltzmann met the demand in the only way it could be met: by
making the theory statistical (1877). The audit counts that as
the record's first honest transaction — an objection stated as
a price, and the price paid in the open. The objection of §2.3
was pressed in a different spirit, and it matters to the record
that the two not be flattened into one.

### 2.3 Recurrence: the theorem, the objection, the replies

Poincaré (1890) proved the recurrence theorem in the prize memoir on the three-body problem (Acta Math. 13).
The prize itself belongs to the year before; the memoir in its revised, citable form is the Acta Mathematica
publication. The theorem states that a measure-preserving dynamical system confined to a finite volume
returns, for almost all initial conditions, arbitrarily close to its initial state, and does so infinitely
often. Read against any monotonic reading of the second law, the consequence is immediate: whatever entropy
does along a trajectory, it cannot increase forever; the system returns, and returns again, to neighbourhoods
of states it has already occupied.

Zermelo (1896) pressed exactly that consequence, in two papers in Annalen der Physik (vols. 57 and 59). A
monotonic H-theorem, the objection runs, is incompatible with recurrence; a purely mechanical derivation of
irreversible entropy increase is therefore unavailable, whatever the H-curve's behaviour over accessible
times.

The replies concede the theorem and deny its physical significance, in two instalments — the first the same
year (Ann. Phys. 57:773–784), the second the year following (Ann. Phys. 60:392–398). Recurrence times for a
gas of any realistic size are inconceivably long, beyond any observational timescale; the H-curve is to be
read statistically, with entropy decrease not impossible but confined, in practice, to times no observer will
see; and the later reply adds the fluctuation picture, in which the direction of time for an observer is fixed
by the local slope of the entropy curve at the observer's position on it. The audit records the replies at
full value: as practical physics they are persuasive, and nothing in this paper disputes a recurrence time.
What the audit prices is their logical shape. An exact objection — recurrence is a theorem — has been absorbed
by a statistical re-reading: H survives, but as a statement about what overwhelmingly happens, resting on the
same count-to-weight step the reversibility objection had already exposed. The postulate doing the work is not
discharged by the reply; it is not mentioned by the reply. It is carried forward, in silence, as the price of
the absorption.

Zermelo's spirit was not Loschmidt's. The recurrence attack was
pressed programmatically — two papers and a rejoinder, from
Planck's Berlin institute, where the second law was then held
to be strictly and completely general — and its conclusion, in
the historians' paraphrase, was not that a paradox needed
absorbing but that kinetic theory, being incompatible with a
strictly valid second law, would have to be abandoned. The
replies printed above absorbed the theorem and declined the
conclusion; the postulate that did the absorbing was carried
forward unpriced. Zermelo himself never withdrew the objection
on the documented record: he left the field — Göttingen, then
set theory — and the objection stands in the literature where
he left it, answered by absorption rather than by discharge.

That is the pattern, and it is established by 1897 at the latest: an exact objection, a statistical
absorption, a postulate absorbed with it and never separately priced. The rest of §2 is the pattern's career.

### 2.4 The declared fiction

Gibbs (1902) gave the theory its enduring architecture in Elementary Principles in Statistical Mechanics
(Scribner's / Yale). The canonical and grand canonical constructions are named there; the ensemble itself is
the book's organising device. Two dating corrections belong here, because the compressions are standard: the
term "statistical mechanics" was coined by Gibbs in 1884 — eighteen years before the book, not in it — and the
now-tidy third label of the standard taxonomy was systematised later, in the following generation's
encyclopaedic expositions; the 1884 terminology for closely related constructions (Ergode, Holode) belongs to
the Viennese line of the subject.

The keystone of this paper's historical case is the book's own declaration of what an ensemble is. It is a
verified quotation, and it is short:

> "We may imagine a great number of systems of the same
> nature…"

The sentence continues: the imagined systems differ in the configurations and velocities they have at a given
instant. The ensemble is introduced as a collection the theorist imagines — copies assembled in thought, so
that averages over them can be formed. Nothing in the presentation treats it as a physical population of
coexisting systems, and later glosses in the same spirit — Schrödinger's "mental copies of the one system
under consideration" — are faithful to it. The fiction was declared at its source. §1.5 records the
consequence: the audit has no quarrel with the declared reading; its charge is precisely that the inheritance
dropped the declaration and handed the device down as a description of the world.

The mixing material belongs to the same section of the record, and it is the second place where the standard
retelling reverses the founder's logic. The early memoir — On the Equilibrium of Heterogeneous Substances,
published in parts across 1875–78, the mixing discussion sitting in the portion dated 1876 — treats the mixing
of different gases with a fixed entropy jump, independent of how similar the gases are, and the mixing of
identical gases with none. The treatment is thermodynamic and unembarrassed: where no distinguishable change
of state occurs, no entropy change is assigned. The label under which the discontinuity now travels is not the
memoir's: it was raised as a paradox by Neumann (1891) and Duhem (1892), a generation later. In the 1902 book's closing chapter (ch. XV),
the two kinds of phase — generic and specific — are separated, and counting in generic phases, where
arrangements differing only by permutation of similar particles are identified, carries the divisor N! with it
and reproduces the thermodynamic result, discontinuity included.

The popular sentence — the paradox was solved by dividing by N! — reverses that logic, and the audit says so
fairly, in the founder's defence. The generic counting was not a patch applied to a count nature had got
wrong; it was a choice of what the count counts, taken at the level of the phase concept itself, reproducing
the earlier memoir's thermodynamics rather than repairing it. §6.3 dissolves the modern form of the puzzle on
exactly that basis: two counting rules, two counts, and a scandal only where the rule is switched in silence.

### 2.5 The honest counters

Two constructions in the record were built for the opposite purpose from the textbooks': not to absorb the
objections, but to exhibit them — small, exact, and priced by their builders.

Paul and Tatiana Ehrenfest (1907) introduced the urn model in Physikalische Zeitschrift 8:311–314. Numbered
balls are distributed between two urns; at each step one ball, chosen by lot, changes urns. The paper's stated
business is the two known objections — the reversibility objection and the recurrence objection are both named
in its title's concern — and the model discharges that business completely. An H-like quantity drifts toward
its balanced value and fluctuates around it; recurrence to the initial state is certain, and its expected
waiting time grows exponentially in the number of balls. Approach and return, drift and fluctuation, are all
present in one finite mechanism any reader can enumerate. The later popular name — the "dog–flea model" — is
not the builders' (Kac, 1947); the audit keeps the builders' presentation: a counting machine, exhibited so
that the statistical reading's content and its limits could be seen at once.

The same builders turned the same method on the theory's
foundation. In their Encyklopädie article (Ehrenfest &
Ehrenfest-Afanassjewa, 1911) they took Boltzmann's ergodic
hypothesis in its literal form — a trajectory passing through
every point of the energy surface — showed that nothing weaker
would do the work the hypothesis was asked to do, and proposed
the weaker quasi-ergodic form (approach arbitrarily close to
every point) precisely while denying that it suffices to trade
time averages for phase averages. Their characteristic
instrument, there as in the urn, was the finite, fully
countable toy: the state space divided into finitely many
cells, a particle with only four possible velocities — small
systems in which exactly where the probabilistic assumption
enters can be exhibited rather than asserted.

The ring model carries the same honesty one step further — it prices the exact assumption the drift requires.
Kac introduced the model in print (Bull. Acad. Roy. Belg. 42:356–361) in 1956, and gave it its canonical
exposition in the 1959 book Probability and Related Topics in Physical Sciences. Balls circulate on a ring of
sites; at marked sites a ball's colour flips. The dynamics is deterministic and reversible, and it is exactly
recurrent: every colouring returns to itself within 2N steps, no exceptions, as §8 of this paper verifies
exhaustively at small N (instrument E.4). Yet the colour imbalance, watched at the population level, decays in
the manner of a Boltzmann-type equation — provided an independence assumption of the molecular-chaos kind is
imposed, treating successive encounters with the marked sites as statistically independent. The exact dynamics
violates that assumption: correlations accumulate, and the recurrence is their invoice. The builder's purpose
was to price the assumption — to exhibit, in a system small enough to be beyond argument, exactly which step
of the standard derivation is dynamics and which step is adoption. That is the audit's own question, asked by
the record itself.

The operationalist tradition reached the same site from outside
statistical mechanics. Bridgman's operational doctrine of
1927 — a concept is synonymous with the corresponding set of
operations — asks of every physical term the question this
paper asks of the ensemble: which operations, performed and
counted, fix its meaning? Bridgman (1941) turned the doctrine
on the ensemble itself in *The Nature of Thermodynamics*, in a
section titled, without euphemism, "The ensemble and
epistemology": statistical treatment, he argued, is something
superposed on a system by our paper-and-pencil procedures, not
a fuzziness residing in the system, and he resisted the
epistemology — then current in wave mechanics — that would
make the ensemble the only proper object of physical
knowledge, on the ground that experience consists of
individual events, each with its own identity. The audit does
not recruit him further than that point: his scepticism was
operational, not this paper's census, and his target was the
ensemble's epistemological elevation, not its use as a
calculating device, whose numbers he did not dispute. At that
point, though, the record is plain: the question "which
operations fix this term?" was asked of the ensemble, in
print, by a founder-grade physicist, and the inheritance
proceeded as if it had not been.

### 2.6 The postulate confessed

Tolman (1938) states the foundation of the theory in The Principles of Statistical Mechanics (Clarendon) with
a candour the inheritance again declined to preserve. Equal a priori probability — equal weight for equal
extensions of phase space compatible with the system's specification — is presented as the theory's
fundamental postulate. It is not presented as a theorem. The justification offered for it (paraphrase, marked
as such, of the Dover reprint, p. 59) is that the postulate, for all the endeavour spent showing its
reasonable character, can be justified ultimately only by the correspondence between the conclusions it
permits and the regularities actually found in the behaviour of real systems.

Price that sentence by Paper 1's criterion, which this series applies to its own adoptions without exception:
an adoption is legitimate when it is declared as an adoption, and what is then derived from it is derived
honestly; the adoption itself earns no derivation badge. By that criterion the 1938 statement is exemplary —
the postulate is confessed as a postulate, and its warrant is named as its fruits. The audit's complaint is
not with the confession. It is with what the textbooks did to the confession on its way down: the postulate
retained, the confession dropped, and the fruits re-narrated as the postulate's proof. A justification by
correspondence with empirical regularities is a justification of a recipe. Presented, two generations later,
as the derivation of a physical distribution, it is Paper 1's pattern in the field's own words: adoption
first, derivation claimed afterward, the interval between the two nowhere priced.

A bibliographic caution of the same kind: the other canonical textbook line is cited in this paper
conservatively, throughout, as Landau & Lifshitz, Statistical Physics (Course Vol. 5) — because a
single-author book of that title appeared in 1938, in Russian and in English in the same year, and the Course
volume under both names is later (Russian in the early 1950s, English later still). Citing either date as the
other's is a provenance error of exactly the species this section exists to catch.

### 2.7 The information import

The last founding import arrived from outside physics, and its founders were as careful about its status as
the physicists of §§2.4–2.6 were about theirs.

Shannon (1948) defined the quantity H in A Mathematical Theory of Communication (Bell Syst. Tech. J. 27) as a
measure of choice, or of uncertainty: H = −K Σ p_i log p_i, with the constant fixing the unit, proved to be
the unique form satisfying the stated desiderata for such a measure. The 1948 text notes the form's identity
with a form already familiar from the H-theorem literature — the Boltzmann H-function's shape — and claims
exactly that: identity of form. No thermodynamic identity is claimed, no physical entropy is derived, and the
engineering problem the quantity was built for — transmission over a channel — carries its own populations
throughout: sources, alphabets, message streams, whose frequencies can in principle be tallied. The founder
claimed a formula. The further claim, that the formula's recurrence makes the two entropies one physical
quantity, is not in the 1948 text.

Jaynes (1957) built the bridge the textbooks now walk across, in two papers (Phys. Rev. 106:620–630; Phys.
Rev. 108:171–190). Maximise the imported functional subject to the constraints the known expectation values
supply, and the canonical weights follow: statistical mechanics reconstructed as statistical inference. The
framing is explicit, and §3.1 of this paper prices the construction at its full strength as the strongest
standard derivation of the weight. For the historical record, what matters is the framing's own terms: the
distribution represents the reasoner's knowledge; the maximum-entropy assignment is, in the programme's stated
phrase, "maximally noncommittal with regard to missing information." Inference, in the first person of the
reasoner, from declared information. No physical population is asserted; no weight is claimed as nature's.

Jaynes (1992) held the same line twenty-five years on, in "The
Gibbs Paradox": entropy attaches to the macroscopic
description — to what the description distinguishes and what
operations can separate — and the mixing discontinuity appears
only for a reader who supposes entropy a property of the
microstate. The ally is therefore not a youthful framing
Jaynes later dropped; it is the position of his whole career,
and the inheritance dropped it anyway.

The quantum formalism's founder belongs in this section's
record too, because his case is the import's mirror image.
Von Neumann (1927) introduced the statistical operator as the
descriptor of an ensemble of systems — his *Gesamtheiten* —
not necessarily in the same state, and derived the entropy of
such an ensemble in the same year; von Neumann (1932) carried
the construction into his book, where the mixed state is the
case in which we do not know which state is present, only its
weights. Whatever the inheritance later made of ρ (Appendix
D.1 prices that), at its source the operator is an ensemble
descriptor: the population is in the founding text, as it was
in Gibbs. The census questions of §§3–4 therefore have a
quantum address from 1927, not by this paper's extension but
by the founder's own construction.

The audit's historical point is therefore narrow and, on this record, unavoidable. The physical identity claim
— thermodynamic entropy is information; the ensemble's weights are the system's own distribution — is the
inheritance's addition. It is in neither founder. The engineer claimed a form; the inference theorist claimed
a rule for reasoning under ignorance; the textbooks promoted the pair into an ontology. §6 prices the
crossings the promotion requires, one by one.

### 2.8 What the record establishes

Read in sequence, the record establishes a single conclusion with five independent supports.

Every founder in this history did one of three honest things. The device was declared: the ensemble introduced
as an imagined collection; the inference programme framed as inference; the communication quantity claimed as
form only. Or the assumption was priced: two small models, built to exhibit the reversibility and recurrence
tension in miniature, with the independence step that drift requires isolated as the price. Or the postulate
was confessed: equal a priori probability named as the fundamental postulate, justified by its fruits alone.

The realism — the ensemble as a population in the world, its weights as nature's sampling rule, its
temperature as a possession of the system, its entropy as one quantity across four counting rules — appears in
none of those founding acts at the strength the modern prose asserts. It entered afterward: in the
inheritance, where a declared fiction lost its declaration, a priced assumption lost its price, and a
confessed postulate lost its confession, and the three were handed down together as the theory's established
ontology.

The audit's target is thereby located with historical precision, and it is the same target as everywhere else
in this paper: not the apparatus, which the founders built well; not the founders, who handled their own
devices more honestly than their inheritors did; but the prose inheritance itself — the layer in which devices
become populations, and populations become physics.

**Who was listening.** The record's last fact is about its
audience. The objections were answered in the journals and
absorbed without their price; the operational question was
asked in 1941 and the textbooks' grammar did not change; the
inference boundary was drawn in 1957 and 1992 and the
inheritance walked across it in both directions. The critical
tradition this section documents was not refuted — it was
routed around, treated as foundations-seminar material while
the recipe, wrapped in the realist prose the founders had
declined to use, was taught as the theory. That is why a
critique in 2026 must be a machine-checked audit rather than
another essay in that tradition: the tradition's arguments
were already sufficient, and they were already ignored. What
had not been tried is pricing the prose against the equations,
claim by claim, in a form whose verdicts can be re-run.

**Badge for this section.** The historical claims above are CLASSIFIED source work in the sense of §0.5.5:
verified citations, consolidated in the historical appendix (App. A), checked for pairing consistency by
instrument G.1 at assembly. The section's verdict — that the realism is the inheritance's addition, not the
founders' claim — is the author's historical reading of that record, printed for inspection, and badged as
such. No part of the verdict wears a machine badge; the machine's part is confined to the citation record's
consistency, and §8 reports it in those terms and no stronger.

---

---

## 3 &nbsp; THE EQUATIONS UNDER THE ARCHITECTURE

Sections 1 and 2 indicted a word and traced its history. This section does the slower work: it takes the
canonical equations themselves — the formulae every statistical mechanics course writes on the board in its
first weeks — and prices them, symbol by symbol, through the same claim-graph and badge machinery the series
applies to its own claims.

The method needs stating once, plainly, because everything in this section depends on not misunderstanding
it.

**No number in this section is disputed.** The canonical recipe predicts mean energies, heat capacities,
magnetisations, and equation-of-state corrections to the accuracy its users claim for it, in the regimes
where it is used. That predictive success is not the audit's target, and nothing in the pricing below
touches it. A recipe can predict perfectly and still be misdescribed by the prose that presents it. The
audit's question is never "does the recipe work?" It is: **what, exactly, has been counted, what has been
postulated, what has been measured, and what has the prose added that none of those three supplied?**

That is the Paper 9.5 audit standard, applied at equation level. Under that standard, a thermal quantity
counts as *derived* only if it is obtained without taking temperature, equilibrium, or an ensemble
distribution as a primitive input. A quantity obtained *with* such an input may still be entirely legitimate
— as a recipe, as a control parameter, as a declared adoption — but it may not carry the badge of a
derivation of the very thing it assumed. The distinction is not pedantry. It is the difference between a
foundation and a parametrisation, and the textbooks' prose systematically presents the second in the grammar
of the first.

Paper 12 built the alternative bookkeeping: frequencies are census ratios of actual counts over declared
windows (§5, where the sampling-measure postulate is dissolved, not replaced); population temperature is a
census quantity, D(P, W) = R/(|P|·|W|) ∈ ℚ (§7), computed from records, never imported; the arrow is exact
finite counting (§8); equilibrium is a constructed property of census records (§9). This section does not
re-derive any of that. It cites it at its home standing, and uses it for one purpose only: as the pricing
standard against which the canonical machinery's symbols can be asked, one at a time, where their values
come from.

The form of each audit below follows Paper 11.5 §3: **(a)** the recipe as stated, **(b)** the
symbol-by-symbol pricing, **(c)** the inference chain — what is counted versus what is inferred, separated
honestly — and **(d)** the verdict block: what badge the priced item can honestly carry, set against the
certainty its textbook prose performs.

---

### 3.1 The canonical weight, priced

**(a) The recipe as stated.**

The canonical ensemble, in its standard compact form, is three lines:

    p_i ∝ e^{−βE_i}
    Z = Σ_i e^{−βE_i}
    ⟨A⟩ = Σ_i A_i e^{−βE_i} / Z

Read as a procedure, the three lines say: assign to each state *i* of a declared state list a weight
e^{−βE_i}; sum the weights to form the partition function Z; form every prediction as the weight-averaged
sum of the quantity of interest over the same list, divided by Z. As a procedure, this is clear, finite (for
a finite list), and reproducible. Two competent users given the same state list, the same energies, and the
same β will compute the same ⟨A⟩ to the same digit. The audit grants all of that without reservation.

What the three lines do *not* say — and what the surrounding prose routinely says on their behalf — is where
the weight came from, what β is, or why the weighted sum should coincide with anything a laboratory
measures. Those are three separate claims, carried by three separate parts of the notation, and they price
very differently. That is why the pricing must be symbol by symbol: priced as a block, the recipe borrows
the honesty of its most honest symbol to cover its least honest one.

**(b) Symbol-by-symbol pricing.**

| Symbol | What it is | How its value is obtained | Price under the 9.5 audit standard |
|--------|------------|---------------------------|------------------------------------|
| E_i | The energy assigned to state *i* of the declared list | Counted / enumerated: from a Hamiltonian evaluated on the list, from a spectrum, or from a declared model of the system's levels | **Legitimate counting content.** An energy assignment can be wrong as physics, but its provenance is inspectable: the Hamiltonian, the list, and the evaluation can each be exhibited. No unearned step hides here. |
| Σ_i (the sum over *i*) | A sum over the declared state list | By enumeration of the list the recipe itself declares | **Legitimate as counting.** The sum's domain is the honest part of the recipe: a finite, exhibitable list, summed completely. Where the list is infinite, the convergence is a stated analytic matter, not a population claim. Counting a declared list is exactly what counting is. |
| β = 1/(k_B T) | The inverse-temperature parameter setting the weight's steepness | Imported: T is supplied from outside the recipe — from a thermometer, from a bath specification, from a fit | **Circular as a foundation for temperature; legitimate as a declared control knob.** Under the 9.5 standard a derivation of temperature may not take temperature as a primitive. The recipe takes it as one. As a derivation of temperature, therefore: no standing. As a recipe parameter — a dial the user sets and declares — it is priced exactly that way, and no complaint attaches to the dial, only to its presentation as a derived quantity. |
| e^{−βE_i} (the exponential weight itself) | The non-uniform weight assigned to state *i* | Adopted: not obtained by counting the states on the list | **ADOPTED, not derived from counting.** The tally counting performs supplies exactly one weight: equal weight per counted record (Paper 12 §5) — itself this framework's declared rule (§9.5 states the concession in full), whose whole content is the count. Every non-uniform weight is a further act, beyond the count. Under Paper 1's adoption-then-derivation criterion an adoption is legitimate when it is declared as an adoption and its consequences are then derived honestly; it earns no derivation badge for the adopted step itself. |
| Z = Σ_i e^{−βE_i} | The normalising sum of the weights | By arithmetic on the quantities above | **Innocent.** Z introduces no new content. It is the adopted weights, added up. Its derivatives are a powerful computational device — the audit prices devices by their inputs, and Z's inputs have been priced above. Normalisation is arithmetic, not ontology. |
| ⟨A⟩ (identified with the measured value of *A*) | The weighted sum, presented as the value measurement will find | By the bridge claim: that the weighted sum over the list coincides with the census of an actual system over an actual window | **The bridge claim — priced separately in §3.2.** Measured values are time/population censuses: ratios of actual counts over declared windows. The identity of the weighted sum with the census is not arithmetic and not counting; it is the ergodic bridge, and it carries the bridge's price, not the sum's. |

Six symbols, four different prices. The table is the section's central exhibit, and its pattern deserves one
paragraph of unhurried reading.

The counting content of the canonical recipe is real, and it is exactly two symbols deep: the energies
*E_i*, obtained by evaluating a declared Hamiltonian on a declared list, and the sum over *i*, which
enumerates that list completely. Everything the recipe *counts*, it counts honestly. The difficulty begins
with the two symbols that do the recipe's characteristic work. β enters from outside, carrying temperature
with it as a primitive — the very quantity a foundation for thermal physics is supposed to deliver. And the
exponential weight, the recipe's signature, is not a count at all: it is a rule for *discounting* counts,
adopted whole. A population in which high-energy records occur less often is a population whose census
could, in principle, be taken; the exponential weight is not that census. It is a formula that predicts what
the census ratio would be, and the prediction's warrant is the recipe's empirical success, not a derivation
of the weight from the counting the recipe itself performs. Instrument M1 in this paper's verification
package exhibits the point mechanically: one sampler, one trajectory rule, and the exponential weight
appearing in exactly one place — the acceptance dial. Set the dial to the exponential and the sampler
reproduces the canonical targets; set the same dial to 1 and the identical code, line for line, converges to
the β = 0 census values instead. The only ingredient the canonical machinery adds beyond counting is the
adopted weight, and in the code — as in the equations — it sits in one declared place, doing all of the
non-counting work.

**(c) Inference chain.**

- COUNTED: the state list; the energies on it; the complete
enumeration inside Z.
- POSTULATED: the exponential form of the weight; β as a
primitive thermal input; (behind both, in the usual physical telling) a heat bath — a second, vastly larger
population whose records are never enumerated at all. The bath does the weight's justificatory work in the
prose ("the system exchanges energy with a reservoir") while appearing in the equations only as the single
letter β. An uncounted population, priced at one symbol.
- MEASURED: censuses — a real system, watched over a real
window, its records tallied. No laboratory has ever measured a weighted sum over an ensemble; laboratories
measure the one system they have, repeatedly or over time.
- INFERRED: that the postulated weight describes a population
nature maintains; that β names a property the system *has*; that the weighted sum *is* the measured value,
rather than a prediction of it whose connecting bridge requires its own pricing (§3.2).

The inference is invisible in practice because it is so old and so successful. Success, however, prices the
prediction, not the inference. The recipe's predictions are excellent; the inference that nature keeps the
recipe's population, weighted as the recipe weights it, is an additional claim, and it is the additional
claim — only it — that the audit prices.

**(d) Verdict block.**

> **The canonical distribution as a recipe:** a declared rule
> for assigning weights to a declared state list, computing a
> normalisation, and forming weighted sums. Declared as what it
> is — an adopted weight, a control parameter β, a computational
> device of demonstrated predictive power — it is legitimate,
> and its honesty is of the [LEVEL A, author-authorized] shape
> the series recognises elsewhere: a bookkeeping rule stated in
> the open, whose consequences are then derived without further
> smuggling. Nothing in this verdict is grudging. The recipe,
> declared, is good machinery.
>
> **The canonical distribution as a derivation:** in standard
> practice the recipe is usually *not* declared in that form.
> It is presented instead as derived — the weight as a
> consequence, β as a property, the ensemble as a population
> the theory has shown to exist. For the derivation claim so
> presented, the verdict is precise and narrow: **the derivation
> claim earns NO BADGE.** The weight step is an adoption; the
> temperature step is circular under the 9.5 standard; an
> adoption and a circle, however productive, do not sum to a
> derivation. (The language is deliberately "NO BADGE," not the
> Denied form: Denied [Level A] is reserved, per §0.5.1, for a
> claim examined at Level-A rigor with a negative verdict on the
> claim itself. §4.3 records the first of this paper's four such
> verdicts, for the blanket thesis (the register of all four
> stands at §0.5.1). The derivation claim here is
> weaker than false — it is *unearned* — and the badge language
> says exactly that and no more.)

Set the verdict against the certainty the textbook prose performs. The standard sentence runs, in substance:
"*the probability that the system is in state i is* e^{−βE_i}/Z" — probability in the indicative mood, the
system as its subject, the weight as a fact about the system. Every qualifier the pricing table earned —
adopted, imported, bridged — is absent from the sentence. The sentence is not a summary of the three lines
in (a); it is a claim about nature that the three lines do not contain. The equations are this audit's
witnesses. The sentence is its defendant.

**The reservoir route, priced as a derivation.** The pricing table's bath deserves its paragraph, because the standard pedagogy does not merely posit the bath — it *derives* the weight from it, and the derivation is a counting argument of a kind this audit honours. Count the total system — small system plus bath — in the microcanonical manner: the number of total records in which the small system sits in state *i* is the bath's record count at the remaining energy, Ω_B(E_T − E_i), and the canonical weight is read off as that count's ratio, with Ω_B's logarithm expanded for a large bath to give the exponential. The counting is real: Ω_B is a count of bath records of exactly the same type as the system's count in §3.1's first rows, and this audit does not dismiss it as uncounted — nobody enumerates either shell by hand, and both are computed from densities of states. What the route *inherits*, priced openly, is threefold. (i) The microcanonical postulate for the TOTAL system: that the total records are weighted equally *for the system* — the count→weight step of §4's first row, taken one level up, where it is less visible, not less taken. (ii) The large-bath expansion: the exponential is the limit form of the count ratio, reached through a Stage P limit whose declaration the textbooks seldom print. (iii) β's identification: the expansion's coefficient is the bath's inverse temperature — the imported primitive of the table's β row, now arriving with a derivation-shaped escort. The route is therefore a *conditional* derivation: a derivation of the weight **from** the total-system adoption plus the limit, not from counting alone. Relative to its axioms it derives; under the audit standard (§0.5.3), which prices axioms as adoptions, it stands one adoption deep — deeper than the bare recipe's confession, shallower than a derivation from counting, and priced exactly there. The audit standard does that demotion in the open, here, rather than by pretending the counting does not exist.

**The honest counterpoint: Jaynes (1957).**

Fairness requires pricing the strongest standard derivation of the weight, not the weakest textbook
presentation of it — and the strongest is Jaynes's. Jaynes (1957) *derives* the canonical weight: maximise
the entropy functional −Σ_i p_i ln p_i subject to normalisation and a fixed mean energy ⟨E⟩, and the
exponential weight follows, with β appearing as the Lagrange multiplier of the energy constraint. No bath is
invoked. No ergodic claim is made. As a piece of derivation, this is genuinely stronger than the reservoir
telling, and the audit says so in the open.

Price it, then, with the same table.

What MaxEnt derives is the weight *given* two inputs: the entropy functional, and the constraint means. The
derivation from those inputs to e^{−βE_i} is sound constrained optimisation, and the audit disputes none of
it. But the two inputs carry the price the derivation cannot pay for them. The constraint mean ⟨E⟩ is, in
application, the measured or imposed mean — a census quantity or a control setting — and β emerges still
tied to it, a multiplier in search of a temperature, not a derivation of temperature from counting. And the
entropy functional itself is the adopted item: −Σ p ln p enters MaxEnt as a premise, chosen (Jaynes argues)
for its consistency properties as a measure of uncertainty — an epistemic argument about inference,
conducted in the first person of the reasoner. Under §6's ledger in this paper, that functional is one
counting rule among four historically wearing the single name "entropy"; adopting it is adopting one rule of
the four, and the adoption is not made smaller by being made well.

The decisive point, however, is Jaynes's own. His framing is explicitly epistemic: the distribution codifies
*inference* from stated information; it is not asserted to be a physical population that nature maintains.
That framing concedes — honestly, and in advance — exactly the ontological half of this audit. Where the
textbooks present the ensemble as the system's population, Jaynes presents it as the reasoner's state of
knowledge, and on that presentation much of §3.1's indictment simply does not arise, because the gloss it
targets was never asserted. What remains priced, even for Jaynes, is the pair of adoptions the derivation
stands on: the functional, and the passage from a multiplier on a constraint to the temperature of a body.
One strengthening of Jaynes must be priced before the verdict, because it answers this paragraph's exact objection. Shore and Johnson (1980) argued that the functional is not merely chosen: any inference procedure satisfying their five consistency axioms — uniqueness, permutation invariance, subset independence, system independence, maximality — must maximise the Shannon functional (up to monotone equivalence). If the theorem stood at full strength, the adoption charged above would shrink to the axioms. Price the axioms, then: they are declared consistency desiderata for *inference* — statements about how a reasoner's estimates should cohere — not counts of anything, and adopting them is Paper 1's adoption pattern in its most respectable dress. And the theorem's own literature records that the forcing is not clean even on its own terms: the proof requires system independence in a strong form, and under the weaker stated axiom a one-parameter family of functionals (the Uffink class) satisfies the axioms, with Shannon's as one member. The functional is therefore not uniquely forced by consistency alone; it is selected — by axioms that are themselves adopted, for a purpose (inference) that Jaynes, to his credit, never confused with a population. The price of §3.1 stands, with the strongest available strengthening named and priced beside it.

Steelmanning the standard account does not rescue its prose. It locates the one standard author whose prose
largely declined to overclaim — and thereby shows, by contrast, how much overclaiming the ordinary prose
performs.

---

### 3.2 The ergodic identity, priced

**(a) The identity as stated.**

    ⟨A⟩_time = ⟨A⟩_ensemble

Two averages, one equals sign. State each side as the procedure it actually names, because the pricing lives
entirely in the difference between the procedures.

*Left side — a census.* Take one system. Watch it over a declared window. Record the value of *A* at each
record in the window. Average the records. Every element of this procedure is exhibitable: the system is the
one in the laboratory; the window can be declared; the records can be tallied and the tally re-done by a
second observer. In Paper 12's form (§5), the left side is a census ratio — a count divided by a count, over
a window the counter names. It is computable in the strict sense: given the records, the number follows by
arithmetic, and given a dispute, the records settle it.

*Right side — a weighted sum.* Take the state list of §3.1. Weight each state by the adopted exponential
weight. Sum *A_i* against those weights and divide by Z. No system is watched; no window is declared; no
records are tallied. The copies summed over — the "ensemble" — are not counted anywhere, because they do not
exist anywhere to be counted. The right side is a computation over a fiction, in the neutral, technical
sense of that word: a constructed collection whose usefulness is not in question and whose existence is not
asserted by anyone who has priced it carefully.

The identity asserts that the census of the one real system equals the weighted sum over the uncounted
copies. If true for a given system, it is the entire warrant for using §3.1's recipe to predict §3.2's
measurements. It is, in other words, the load-bearing bridge of the whole canonical architecture: remove it,
and the recipe remains a beautiful computation in search of a reason to agree with a thermometer.

**(b) Pricing.**

The identity is a **theorem for almost no systems of interest** — and the conservative statement of the
positive result matters, so it is given conservatively. Birkhoff (1931) proved that for a measure-preserving
flow, time averages exist for almost every starting point. That is a real theorem, and the audit honours it
at exactly its stated strength: existence of the limit, almost everywhere, for flows preserving a measure.
What it does not deliver is equality of that limit with the canonical weighted sum of §3.1 for the physical
systems the textbooks apply the recipe to: the theorem supplies no canonical weight, assumes the measure it
is handed, and its almost-everywhere clause is silent about the one starting point any actual system
occupies. Between "time averages exist a.e." and "this system's census equals e^{−βE}/Z" lies the whole
content of the ergodic programme, and it is not closed by the 1931 result.

The obstruction, also stated conservatively: for near-integrable Hamiltonian systems, invariant tori of the kind identified by the KAM results persist and partition the phase space, so a trajectory remains confined to its torus and its time census samples that torus — not the full state list the ensemble sum ranges over. Ergodicity in the strong form the identity needs is therefore not a generic gift of Hamiltonian dynamics; it is the exception, available to some systems, provable for fewer, and assumed for nearly all. No percentages are
offered here, because none are needed: the audit's point is structural, and a structural point made with
invented proportions would commit the offence it exists to price.

In textbook practice, then, the identity functions as an **adopted bridge**: stated early, used everywhere,
proved almost nowhere it is used. Individual systems and narrow classes have their own rigorous results, and
where a system-specific proof exists, the identity for that system is inherited at that proof's standing —
the discipline of ergodic theory owns those proofs, and this audit neither fabricates instances of them nor discounts them. The exemplary case is named so the concession is a record, not a gesture: the Boltzmann–Sinai ergodic hypothesis for hard-ball gases — Sinai's proof for the two-ball case (1970), completed for general N by Simányi and collaborators — is a per-class proof of exactly the kind condition C35 (§11) is written to receive; for that class the identity is inherited at the proof's standing, and §7.1's arrow inherits it there too. A neighbouring programme is noted for the same reason: the typicality literature largely *bypasses* the bridge rather than crossing it, deriving the arrow's statistics from concentration over initial conditions — a different bridge, carrying its own adopted measure over those conditions, priced by the same standard wherever it is used. The audit's target is the unexamined universal bridge of the pedagogy, not the existence of examined ones. The price attaches to the *universal* use: one bridge, asserted for every system the recipe
touches, on the strength of existence theorems that do not carry its weight.

**(c) Inference chain.**

- COUNTED: the left side only — one system's records over one
declared window.
- POSTULATED: that the right side names anything the left side
could be equal *to*, beyond a computation; that the adopted weight of §3.1 is the measure the system's
trajectory respects; that almost-everywhere existence settles the single case at hand.
- MEASURED: time censuses, exclusively. Every experimental
confirmation ever offered for the identity is a left-side measurement compared against a right-side
computation. The ensemble side has never been measured, because there is nothing on that side to measure.
- INFERRED: from the agreement — where it holds, often to many
digits — the identity itself, as a standing fact about systems in general. Agreement in the cases checked is
real evidence for the recipe's reach. It is not a proof of the bridge, and the prose that calls the identity
"the ergodic hypothesis" in one chapter and uses it as an established equality in the next has priced it two
different ways without recording either price.

**(d) Verdict block.**

> **The ergodic identity as a universal bridge claim earns
> NO BADGE.** It is not thereby declared false: for particular
> systems it may hold, for some it is proved, and for the
> chaotic systems where it holds best it holds for reasons
> (mixing, instability) that are themselves system-specific
> physics, not a universal postulate. A claim that is proved
> case by case where it is provable, adopted silently where it
> is not, and asserted universally in the prose, is priced by
> its weakest universal use — and the universal use is an
> adoption wearing a theorem's clothes.
>
> **Where a system-specific proof exists,** the identity is
> inherited at that proof's standing, for that system, with
> that proof's hypotheses attached. The audit's complaint has
> never been with ergodic theory, which prices its own claims
> more carefully than the textbooks that borrow its central
> equality. The complaint is with the borrowing.

**The honest mirror.**

Paper 12 does not need this bridge, and the reason is construction, not luck. In the ledger, a frequency
*is* a census ratio: the left side of the identity is the only side the framework ever defines, and every
thermal quantity in the paper — D(P, W) included — is built from census ratios over declared windows by
construction (§§5, 7). There is no second, weighted side for a bridge to reach, and therefore no bridge to
adopt, prove, or fail. Where the standard architecture must postulate that its fiction agrees with the
record, the ledger never leaves the record.

The mirror has a second face, and this paper shows it rather than turning away. Paper 12 has its own
disclosed gap: the open joint of §§8.6/9.6 — no theorem in Paper 12 connects the monotonicity of its
per-tick tension accounting to the drift of its census maxima; closed populations in the paper end at fixed
points, and the joint where a dynamics-to-maximum drift theorem would sit is named in the paper as open.
That gap is *ours*, it is not closed anywhere in this critique, and §7 of this paper will set it beside the
standard account's matching hole — no dynamics-to-Ω-drift theorem on their side either — where the
difference is not the hole but the disclosure. The ergodic bridge and the open joint are the same shape of
absence. One tradition papers over its absence with an identity asserted as fact. The other prints its
absence in its own section numbering. That difference in bookkeeping — not a difference in completeness,
which neither side may claim — is the whole of the mirror's lesson, and §3.3 now states the method it
exemplifies in its general form.

---

### 3.3 The pricing method, generalized

Nothing in §§3.1–3.2 is specific to the canonical ensemble except the answers. The questions are portable,
and this short subsection states them once, as the standing instrument the rest of the paper — and any
reader — can apply to any standard equation submitted to the architecture.

For any equation, ask four questions, in this order:

1. **What is counted?** Name the list, the records, the enumeration. If a sum, integral, or average appears,
name its domain and say whether the domain is exhibitable. What passes this question is the equation's
counting content, and it is priced as counting: as strong as the enumeration is complete.
2. **What is
postulated?** Name every weight, measure, distribution, primitive parameter, and uncounted auxiliary
population the equation uses without enumerating. Each is an adoption. Adoptions are priced by Paper 1's
criterion: legitimate when declared, derivational of nothing by themselves.
3. **What is measured?** Name
the laboratory procedure the equation's output is identified with, and state that procedure as a census:
what is tallied, over what window. If the identification of computed output with measured census requires a
bridge claim, the bridge is a fifth item and is priced on its own, never folded into the arithmetic.
4. **What does the prose add?** Set the textbook sentence beside the priced equation and mark every noun the
sentence asserts that no symbol carries: populations nature maintains, properties systems possess,
probabilities states have. Whatever is marked is the gloss. The gloss is priced at NO BADGE unless a
derivation of it, separate from the equation, is exhibited.

Four questions, and a discipline for their order: counting first, because it is the ground everything else
is checked against; postulation second, because it is where unearned certainty enters; measurement third,
because it is where bridge claims hide; the prose last, because it can only be priced once the equation
beneath it has been. An equation that survives the four questions with its prose intact has earned its
presentation, and the audit has no quarrel with it — §3.1's recipe, *declared*, is such an object, as is
every system- specific ergodic proof within its hypotheses. The quarrel, in every case examined so far and
every case in §4's matrix, is with prose that bills the reader for goods the equation never delivered.

This is the whole method. Section 4 applies it six times, in tabular form, to the full canonical
architecture — the three ensembles, the bridge between them and time, and the two further practices
(coarse-graining, and the Gibbs–Shannon crossing) through which the architecture's gloss propagates into the
rest of thermal physics.


---

### 3.4 The inference bridge, priced

§3.1 priced the canonical weight as adopted, and it did not price the
weight's strongest defence cheaply. Named there, at full strength, was
the inference route: Jaynes's derivation of the weight from a functional
and constraint means, strengthened by Shore and Johnson's axioms for
any rule of that kind (§3.1). On that route the weight is not a
population's distribution at all. It is the output of a rule for
reasoning from stated information — and a defender who takes the route
has, on its face, stepped off the ground §3.1 audited. This section
prices the route as what, in this paper's architecture, it is: a
**bridge** — Stage P material, carrying traffic between the census
side, where this framework's claims live, and the standard formalism's
weighted sums. A bridge is priced by what crosses it and what does
not, at no more than the strength of its weakest pier (§0.5.2: a claim
cannot outrank its weakest dependency). Priced that way, the bridge's
positive content carries **[LEVEL B]** at best. Nothing on the route
is imported into any native claim of this paper or of Paper 12, and —
as everywhere in this audit — the target is the gloss the route
acquires in transit, never the predictive apparatus it serves: the
updating rule computes, and computes well, exactly as the recipe of
§3.1 does.

**The updating reading.** Stated in its own terms, the route runs as
follows. Declare a record set — the state list of §3.1 serves. Place
over it a starting assignment, the prior: a weighting of the records
before the constraint is applied. State the known information as
constraints, and state them in the form the programme itself requires:
as means — a mean energy, in the canonical case, fixed at a stated
value. Then update: of all weightings of the record set that satisfy
the constraints, the rule selects the one the adopted functional of
§3.1 extremises, and that selected weighting — the posterior — has,
for an energy constraint, exactly the canonical form: ratios between
records geometric in the energy, the exponential weight of §3.1 with
its multiplier set by the constraint. The derivation from the rule's
inputs to that form is sound, and §3.1 has already said so. What this
section prices is the inputs.

One input, honestly sourced, is census content, and it is the
bridge's one solid pier. A constraint in this programme is an
expectation value, and an expectation value honestly obtained — not
fitted, not imported as a primitive — is a counted mean: a tally of
actual records over a declared population and a declared window,
divided by the count of those records. That is a census ratio in
Paper 12's sense, and the identification is Jaynes's own before it is
this paper's: his constraints enter as expectation values supplied to
the reasoner, and the only expectation values any procedure priced in
this paper has ever supplied are tallies of records actually
taken — in every derivation audited here, constraint means
enter as counted means; where one enters otherwise, as a
fitted control or as a quantity computed inside an adopted
model, the price table below prices it as what it is, and the
identification claimed here is for the counted kind, which
is the kind Jaynes's own examples use. (Inheritance: Paper
12 §§3, 5 via Appendix B — the census rule and the dissolution of the
sampling-measure postulate, under which every frequency the ledger
needs is such a ratio; claim L3.4.2 below carries the pier at
[LEVEL A — inherited], with its reliance stated in the claim text.)
Where a constraint mean arrives by that road, it crosses the bridge
at full census strength. Where it arrives as a control setting or a
fit, it crosses as what it is — a declared input — and the pier
carries nothing for it. The pier is real. It is also narrow: it
carries the constraint, and nothing else on the route.

**What does not cross.** First, β. In inference dress β is the
Lagrange multiplier of the adopted energy constraint — the number the
extremisation returns, fixed by the constraint mean and the
functional. Its identification with 1/(k_B T) is not a step of the
updating derivation; it is the same import §3.1 priced in the table's
β row, arriving by a second road and priced at the same toll. A
multiplier on a constraint is a property of the rule and its inputs.
A temperature, on any account that must pass the §0.5.3 standard, is
a quantity to be obtained without itself among the primitives — and
nothing in the updating derivation obtains it: the multiplier is tied
to the constraint, and the constraint, where it is a measured mean,
was measured on a population the multiplier does not describe.

Second — and this is the section's central pricing — the posterior
itself does not cross as a population. The posterior is a property
of the rule and the declared inputs: this functional, this prior,
this constraint mean, this record set. It is not a population the
system belongs to, and it is not the census of any population,
including a population whose counted mean is the very constraint the
rule was fed. Two declared populations can share a counted mean
exactly and carry different censuses — different tallies in every
class but the mean they agree on — and the rule, which sees the mean
and nothing else, returns the same posterior for both. Exhibit E.6
(§8) computes one such pair exactly, in rational arithmetic: same
counted mean, two censuses, one posterior. The sentence the exhibit
earns is stated here in its full form, because the whole section
stands on it: **the rule is not the census.** A posterior read as a
population's distribution — as the fraction of copies, or of records,
that nature or the system maintains in each class — has taken the
bridge's output for the pier's content, and that reading earns
**NO BADGE**, at exactly the place §3.1's gloss earned it.

**The rule-space geometry, priced as Stage C.** The inference
literature builds one further storey on the route, and it is priced
separately so that its vocabulary cannot be spent below at a strength
it never earned. The exponential families — the posteriors of the
updating rule, across all its constraint values — form themselves a
geometric space: a space whose points are updating rules, carrying
the Fisher–Rao metric and its dual coordinate systems, in which a
change of constraint is a motion and an updating step has a geometry
of its own. As mathematics this is exact, and the audit disputes none
of it. Its domain, however, is the rule-space: the geometry is a
geometry **of the rules** — of assignments a reasoner might make —
exhibited in the literature as mathematics of inference. No
determination in the record measures that geometry on a single
physical system: no procedure returns a Fisher–Rao distance as a
property of a body, and no census is a coordinate chart of anything.
The storey is therefore priced as Stage C commentary on the
rule-space — elegant, internally sound, and physically silent. One
prose discipline attaches to the pricing, and it is this paper's
standing discipline applied at a new site: the geometry's received
vocabulary speaks of a manifold of states, and that phrase, spent
in physical prose, re-imports the population gloss through the back
door — a space of rules re-narrated as a space the system inhabits.
The target of that sentence is the prose, as everywhere in this
paper; the mathematics is not its target, and no claim here touches
it. Claim L3.4.3 records the pricing, and condition C43 (§11) states
what would overturn it. **Scope of the section's name:** the rule
priced here is the maximum-entropy rule — Jaynes's updating rule,
the one §3.1 priced under Shore–Johnson. Bayesian updating proper
(likelihoods over hypotheses; posteriors over models) is a
different instrument; this section does not price it, and
"updating" throughout names the MaxEnt assignment. E.6 (§8.10)
computes the MaxEnt case exactly.

**The boundary Jaynes kept.** None of the pricing above is a charge
against the route's founder, and §2.7 has already placed the reason
on the record: Jaynes framed the distribution as the reasoner's
assignment, made from declared information — inference, in the first
person, with no physical population asserted. This section does not
re-argue that record; it cross-refers to it. The slide this paper
audits — from "the reasoner's assignment" to "the system's
distribution," from a rule for reasoning under ignorance to a
population the system is in — is the inheritance §2.8 indicted,
replayed inside the inference programme itself: the programme's
founding framing kept the boundary its textbook inheritance then
dropped. Shore and Johnson stand where §3.1 priced them, and are
cross-referred, not re-argued: their axioms discipline the rule —
they say how a reasoner's assignments must cohere — and axioms of
that kind, however well they discipline, do not people a population.
What crosses the inference bridge, in sum, is a rule, one census-grade
input where the input is honestly sourced, and a multiplier. What
does not cross is a population, a temperature, and a geometry of
anything physical. The bridge, priced whole, is good Stage P
machinery for reasoning from stated information. Read as an ontology
of the system it reasons about, it is the ensemble illusion in its
most respectable dress — respectable enough that the dress, and not
the wearer, is what this section has priced.

**Price table.**

| Item on the bridge | What it is | Price |
|---|---|---|
| The updating rule (form) | The selected weighting, given the functional, the prior, and the constraints: canonical (geometric / exponential) ratios for an energy constraint | **[LEVEL B]** as a bridge — a declared rule of inference, its form derived from adopted inputs (§3.1: the functional; Shore–Johnson priced there). Legitimate as a rule; derivational of no population |
| The constraint means | The rule's stated information: expectation values supplied to it | **The solid pier.** Honestly obtained — tallied over a declared population and window — a counted mean is a census ratio, [LEVEL A — inherited] (claim L3.4.2). As a control setting or a fit: a declared input, carrying no census strength |
| β as multiplier | The Lagrange multiplier of the energy constraint, returned by the extremisation | **The imported dial, in inference dress.** Its identification with 1/(k_B T) is §3.1's import at the same price: legitimate as a declared control, **NO BADGE** as a derivation of temperature |
| The posterior-as-population reading | The posterior spent as a population's distribution — the system's own weights, maintained in nature | **NO BADGE.** The posterior is a property of the rule and its declared inputs; two populations with one counted mean and different censuses receive the same posterior (E.6, §8, computed). The rule is not the census |
| The rule-space geometry | The exponential families as a geometric space (Fisher–Rao metric; dual coordinates) | **Stage C commentary** [CLASSIFIED — claim L3.4.3]: exact mathematics of the space of rules; no determination in the record measures it on a single physical system; physically silent — *limit, repeated from claim L3.4.3 so the table does not overstate the claim: "the record" is the literature this paper's corpus names (§0.5.2); the neighbouring geometries (Ruppeiner's metric; quantum Fisher information) are placed at the claim, not ignored — and neither measures which updating functional a system obeys, the only determination the claim denies* |

The bridge rule of §0.5.2 sets the section's ceiling: the bridge's
positive content is priced by its weakest dependency — the adopted
functional of §3.1 — and therefore at **[LEVEL B]**, however strong
its one pier is. The pier's strength is the census's, inherited; it
raises the constraint's crossing, and it does not raise the bridge.

### §3.4 claims

- **L3.4.1** — The inference bridge, priced whole: the updating route
  of §3.1, read as a bridge between census quantities and the
  canonical weighted sums, carries **[LEVEL B]** at best for its
  positive content, by the bridge rule (§0.5.2): its weakest
  dependency is the adopted functional priced in §3.1, and no
  component of the route — rule, multiplier, or posterior — is
  imported into any native claim of this paper or of Paper 12.
  *Limit, stated:* the price is a price on provenance, not on
  predictive reach; the rule's computations stand where §3.1 left
  the recipe's. *Falsifier:* condition C43 (§11) — counting alone
  forcing a non-uniform posterior with no adopted functional would
  remove the dependency the price rests on and reopen this claim.
- **L3.4.2** — The constraint-means pier: a constraint mean honestly
  obtained — tallied from actual records over a declared population
  and a declared window — is a census ratio, and in that form, and
  that form only, it crosses the inference bridge at census strength.
  **[LEVEL A — inherited, Appendix B.1.]** *Reliance, stated as
  §0.5.6 requires:* this paper relies on Appendix B.1's inheritance
  line — Source: Paper 12 §3, badge carried at source [LEVEL A],
  validation by Paper 12's §3 claim list and claim registry — for
  the census rule under which a counted mean over a declared
  population and window is a census ratio; Paper 12 §5's dissolution
  of the sampling-measure postulate, carried in Appendix B beside
  that line, is the result under which no further measure is needed
  to state the ratio. *Limit, stated:* the inheritance covers
  counted means so obtained and nothing else; a constraint mean
  supplied as a control setting, a fit, or a primitive carries no
  part of this badge, and the badge covers the pier only — it does
  not extend, by the bridge rule, to the rule, the multiplier, or
  the posterior the pier feeds.
- **L3.4.3** — The rule-space geometry, priced: the geometric
  structure of the exponential families (Fisher–Rao metric; dual
  coordinates) is a geometry of the updating rules themselves,
  exhibited in the literature as mathematics of inference; no
  determination in the record measures that geometry on a single
  physical system, and it is carried here as Stage C commentary on
  the rule-space — elegant and physically silent — never as a
  property of a system or a population. *Limit, stated:* "the
  record" is the literature this paper's corpus names (§0.5.2).
  Two neighbouring geometries are placed, not ignored: Ruppeiner's
  metric lives on the space of macrostates and is computed from
  counted fluctuation data — a geometry of descriptions, fed by
  censuses — and quantum Fisher information is estimated from
  measurement counts over runs and prices a preparation's
  estimation precision; neither measures which updating functional
  a *system* obeys, which is the only determination this claim
  denies. **[CLASSIFIED]** — the author's pricing, §0.5.5, printed
  for inspection.
  *Falsifier:* condition C43 (§11) — a physical determination of
  the rule-space geometry on a single system, exhibited, fires it.

---

---

## 4 &nbsp; THE AUDIT MATRIX

Section 3 priced the canonical equations in prose. This section renders the same audit in the form Paper
11.5 §3.7 established: a single matrix in which each row must answer the four questions of §3.3 in the open,
where a reader can compare rows without turning pages. The matrix covers the three ensembles, the bridge
that connects all of them to measurement, and the two practices through which the ensembles' assumptions
reach beyond themselves.

A note on what the matrix is not. It is not a ranking of usefulness. The canonical row's recipe is the most
productive computational device in thermal physics, and it sits in the table beside the microcanonical row's
near-trivial counting without apology in either direction: the matrix prices *provenance*, not power. A row
can be computationally supreme and provenancially adopted; a row can be computationally modest and
provenancially sound. Confusing those two axes is the original error the paper audits, and the table is
built so that the confusion has nowhere to sit.

### 4.1 The matrix

| Ensemble / bridge | What is counted | What is postulated | What is measured | Prose claim | Equation's actual content | Verdict |
|---|---|---|---|---|---|---|
| **Microcanonical** | Records at fixed (E, V, N): the declared list of states in the energy shell — the honest core of the whole architecture, a complete enumeration of a declared domain | Equal weights over those records: the count→weight step in its purest form — counting supplies the records; it does not supply the rule that each record weighs the same *for the system*, as distinct from in the tally | Time spent / census ratios: the one system's records over a window, tallied by energy | "All accessible microstates are equally likely" — stated as nature's rule for the isolated system | A counting measure, adopted: the enumeration is the paper's own §5 form; the step from "we count each record once" to "nature weights each record equally" is an adoption laid over the count | Counting: **[inherited Level A form via Paper 12 §5]**. The weight step: **NO BADGE as derivation** — declared, it is an adoption, and the microcanonical ensemble is the one case where the adoption is thinnest, because the tally's equal weight is the one weight that asserts nothing beyond the count itself — the tally rule is this framework's declared rule, and §9.5 states that concession in full; the adoption consists in asserting that the system's census obeys it |
| **Canonical** | The small system's records: its declared state list and energies, enumerated exactly as in §3.1 | The bath (an uncounted population, present only as its effect); β as a primitive thermal input; the exponential weight (§3.1) | Censuses of the small system: the one system's values over declared windows | "The system is in thermal equilibrium with a reservoir at temperature T" — temperature as a possessed, standing property of the arrangement | A recipe with two imported primitives: an adopted weight (§3.1) and an imported temperature, applied to an honestly enumerated list | Recipe legitimate **when declared**; derivation claims **NO BADGE**; temperature-as-primitive **fails the 9.5 standard** — a derivation of temperature may not begin from T, and this row begins from nothing else |
| **Grand canonical** | The small system's records, now over lists varying in particle number as well as energy | Everything in the canonical row, plus μ (chemical potential) as a second imported primitive, and a particle reservoir — a second uncounted population, exchanging particles as the bath exchanges energy | Censuses of the small system: its energies and particle counts over declared windows | "The system is in equilibrium with a reservoir at temperature T and chemical potential μ" — two possessed properties, jointly maintained by an unobserved population | The canonical recipe with one further adoption: a second primitive, a second reservoir, a second weight factor, on the same enumerated-list core | **As canonical, one more adoption.** Recipe legitimate when declared; derivation claims **NO BADGE**; each imported primitive fails the 9.5 standard separately, and the second uncounted population doubles the provenance debt without doubling the scrutiny it usually receives |
| **Ergodic hypothesis** | Nothing — it is the bridge, not an ensemble; it enumerates no list of its own (§3.2) | The time = ensemble identity itself: that one system's time census equals the weighted sum over uncounted copies, for the systems the recipe is applied to | Time censuses only: the left side of the identity is the only side ever measured | "Time averages equal ensemble averages" — stated, after its introductory chapter, as an established equality available for use | An adopted bridge between a computable fiction and a measurable census, resting on existence theorems (Birkhoff 1931) that do not deliver the equality for physical systems, and obstructed, for near-integrable systems, by invariant tori | **NO BADGE as a universal claim** (§3.2). Where a system-specific proof exists, inherited at that proof's standing, for that system only |
| **Coarse-graining** | Records within chosen cells: the system's records, tallied per cell of a partition of its state space | The cells: a partition — a window in state space — chosen by the describer and, in standard practice, never declared as a choice with alternatives | Cell censuses: counts per cell over the window the cells define | "Entropy increases" — stated as a physical process undergone by the system | A declared-window census in disguise — the one standard practice that is secretly Paper 12-shaped: counts over a window, with the window's declaration suppressed | The practice is sound **exactly where the window is declared**; undeclared, its entropy is describer-relative while its prose is absolute. Priced as a census, it inherits the census standing of Paper 12 §5 — conditional on the declaration the prose omits |
| **Gibbs ↔ Shannon crossing** | Gibbs side: phase-space cells, weighted by a distribution. Shannon side: message symbols, weighted by source statistics. Two different domains, two different tallies | That one functional — −Σ p ln p — is *one quantity* across the two domains; that the shared formula licenses a shared name and a shared ontology | Neither directly: phase-space densities are not censused, and message statistics, where they are censused, are censuses of symbol streams, not of physical populations | "Entropy is information" — the functional's unity promoted to the quantity's identity | Two counting rules, one name (full ledger: §6). A common formula is a fact about the formula; its promotion to a common physical quantity is a bridge no enumeration performs | The crossing is an undeclared bridge — priced **[LEVEL B] as analogy**, Denied nothing; **as identity, NO BADGE**. Analogy between counting rules is legitimate and often fertile; identity between the quantities the rules tally is a further claim, and it has never been derived |

**Result, read off the matrix: the counting column is honest in every row where counting occurs at all.**
Lists are declared, enumerations are complete, censuses are what laboratories do. The provenance failures
concentrate, with complete regularity, in the second column — postulation — and in the fifth, where the
prose claim outruns the sixth, the equation's actual content. That regularity is the paper's finding in
tabular form: the standard architecture's weakness is not distributed through its machinery. It sits in
exactly two places — the weights and populations it postulates without counting, and the sentences it writes
about them afterwards. Boltzmann's counting (1877) and Gibbs's architecture (1902) built machinery whose
enumerative core this audit nowhere faults. The fault is the gloss the machinery acquired: adopted weights
presented as derived, imported primitives presented as properties, bridges presented as theorems, analogies
presented as identities. The equations, again, are the witnesses.

Two rows reward a second look before the contrast is drawn.

The microcanonical row is the architecture at its most honest, and the audit says why precisely: its
adoption is the thinnest possible, because equal weighting is the *unique* weight that counting alone
supplies (Paper 12 §5). To count records at all is already to weight each record once in the tally. The
microcanonical adoption is therefore not the weight's form but its jurisdiction: the assertion that the
*system's* census — the tally nature keeps, over the window the system actually lives — obeys the equal
weighting the counter's tally uses. Even here, at the minimum, a step exists, and the row records it. It is
the only ensemble row where the step is a single, nameable sentence. The canonical and grand canonical rows
each add primitives the microcanonical row does not need, and the matrix makes the additions visible as what
they are: purchases, made with postulation, of computational reach.

The coarse-graining row is the matrix's surprise, and the audit records it without trimming.
Coarse-graining, stripped of its prose, *is* the ledger's own practice: partition the records by a chosen
window, tally per cell, compute ratios. It is Paper 12-shaped. Its defect is the mirror of the other rows'
defect: where they declare too little of what they postulate, coarse-graining declares too little of what it
*chooses* — the cells are a window, the window is the describer's, and an entropy computed through an
undeclared window is a describer-relative number carrying absolute prose. Declare the window and the row is
sound, standing where Paper 12's censuses stand. The standard practice was never wrong to coarse-grain. It
was wrong — in this paper's narrow, provenancial sense — to coarse-grain silently.

---

### 4.2 Their derivation vs. our derivation

Paper 9.5's method, which Paper 11.5 §4.2 applied to the intrinsic idiom, is applied here to one worked
quantity: the mean energy of a two-level population — the smallest system on which both accounts can be made
to show every step. Count the unearned steps on each side. A step is unearned if it is neither declared as
an adoption nor derived from steps before it. Declared adoptions are not unearned; they are *priced*. The
sin this paper audits is never adoption. It is adoption billed as derivation.

**Mean energy, standard route:**

1. Declare the two levels, energies 0 and ε (counting — legitimate; the list and its energies are
exhibitable).
2. Postulate the canonical ensemble: embed the system in a heat bath (postulated — the bath is
an uncounted population, introduced by sentence, enumerated by no one).
3. Assign the exponential weight
e^{−βE} (adopted — §3.1; in the standard presentation this step is performed as if it followed from step 2,
but no enumeration of the bath's records is carried out from which the weight is counted).
4. Import β =
1/(k_B T) (imported primitive — temperature enters as an input; under the 9.5 standard this step alone
disqualifies the route as a *derivation* of any thermal quantity, though not as a recipe).
5. Form Z = 1 +
e^{−βε} and differentiate: ⟨E⟩ = −∂ ln Z/∂β = ε/(e^{βε} + 1) (derived — clean calculus on the adopted
inputs; the audit disputes no step of it).
6. **Gloss:** "the mean energy of the system at temperature T"
(inferred — the computed weighted sum is identified with the measured census of a real population, via the
ergodic bridge of §3.2, which appears in this route as no step at all: it is used, silently, exactly where
step 6 needs it).

Unearned steps: three, of three different kinds — step 3, an adoption presented as a consequence; step 4, a
primitive presented as a property; step 6, a bridge presented as an identity of meaning. The arithmetic
(step 5) is flawless, and the final number agrees with measurement wherever the recipe applies. Neither fact
pays for steps 3, 4, or 6. Instrument M1 reproduces the route mechanically and confirms the diagnosis from
inside the machinery: the sampler reaches the canonical mean only while its acceptance dial carries the
adopted weight; the bath of step 2 appears in the code nowhere at all — it is a prose entity, and the
computation neither needs it nor notices its absence.

**Mean energy and temperature, ledger route (Paper 12):**

1. Declare the population P and the window W (declared — the census rule, Paper 12 §3; the declaration is a
step, taken in the open, where a reader can refuse it).
2. Run the population's dynamics over W and census
the records: for a two-level population, tally each member's records and each record's bookings (counted —
complete enumeration of actual records; no copies, no bath, no weights).
3. Compute the mean energy as a
census ratio: total booked energy over the records tallied, divided by the number of records (derived —
arithmetic on the census of step 2).
4. Compute the population temperature from the same census: D(P, W) =
R/(|P|·|W|) ∈ ℚ, where R is the total of the records' resolution bookings over the window (derived — Paper
12 §7; temperature is an *output* of the census, not an input to it, so the 9.5 standard is met by
construction).
5. No gloss step. The derivation ends where the census ends: the mean energy is the mean of
the records counted, the temperature is a ratio of the counts taken, and both statements mean exactly what
their computations did.

The worked instance, at its printed values: Paper 12's Appendix F exhibit E-SMALL carries its
two-level-style census through in full — three bodies over a three-tick window, total bookings R = 5 over
|P|·|W| = 9 body-ticks, giving the population temperature in its ledger form,

    D(P, W) = 5/9,

an exact rational, recomputed from the paper's declarations alone by independent reproduction. Set it beside
the standard route's output for its own worked system, ε/(e^{βε} + 1): a transcendental function of an
imported primitive. The ledger's number is smaller machinery producing a plainer object — a ratio of two
counts — and the plainness is the point. Nothing was embedded, weighted, bridged, or glossed to obtain it.

Count the unearned steps: standard, three (an adoption, a primitive, a bridge — each presented as something
better than it is). Ledger, zero — every step is either a declaration (step 1, honestly labelled) or
arithmetic on records actually counted (steps 2–4). The pattern is the one Paper 11.5 §4.2 found across the
intrinsic idiom, and it is uniform for the same reason: the standard derivation is census-shaped through its
honest steps and then takes its unearned steps at exactly the places where a population, a temperature, or a
bridge must be conjured to connect the computation to the world. The ledger stops where its counting stops,
and declines the conjuring. That refusal is not modesty. It is accuracy.

A fairness clause, because the contrast invites a misreading: the standard route computes something the
ledger route, on a two-level toy, does not attempt — a prediction for systems whose censuses nobody has
taken, at temperatures nobody has censused, from a formula of great reach. Predictive reach is a genuine
good, and the recipe's reach is the reason its adoptions were worth making. The audit's claim is confined to
provenance: reach purchased by adoption must be *billed* as adoption. Billed honestly — as Jaynes largely
billed it (§3.1) — the standard route is a declared recipe of the first rank. Billed as derivation, it is
the ensemble illusion in its working clothes.

---

### 4.3 What is inferred vs. what is proven — the ledger

| Claim | Status in standard account | Status in Paper 12 / this audit |
|-------|---------------------------|---------------------------------|
| "Frequencies are census ratios over declared windows" | Assumed in practice (every measurement is one) but displaced in theory by weighted sums over ensembles | **Proven by construction** (Paper 12 §5): the census rule is the definition of frequency in the ledger; no measure postulate survives §5's dissolution |
| "Equal weighting is innocent — arithmetic, not assumption" | Nowhere stated; the microcanonical postulate is presented as a physical assumption about systems | **Tally vs jurisdiction** (Paper 12 §5, cited here): the equal weight is the tally's own arithmetic — declared as the ledger's rule, asserting nothing beyond the count; any non-uniform weight is additional structure beyond the count, and any weight's *jurisdiction* over a system's behaviour is an additional assertion beyond the tally — exhibited mechanically by M1's dial: weight 1 counts, every other setting adopts, and jurisdiction is asserted by neither |
| "Population temperature is computable from records alone" | Not attempted: T enters as primitive (β) or as bath specification in every canonical treatment | **Proven by construction** (Paper 12 §7): D(P, W) = R/(|P|·|W|) ∈ ℚ is a ratio of census counts; worked instance E-SMALL, D = 5/9, reproduced from declarations |
| "The exponential weight follows from counting" | Presented as derived (via the bath, via entropy maximisation, via the thermodynamic limit) in successive textbook tellings | **Inferred in every telling, derived in none.** Jaynes (1957) derives it from an adopted functional plus constraint means (§3.1) — the strongest route, and an adoption still |
| "Time averages equal ensemble averages" | The ergodic hypothesis: assumed universally, proved system-by-system where provable (§3.2) | **Not needed.** The ledger defines one side only; the identity has no ledger statement, because there is no second side |
| "Entropy increases as a physical process" | Inferred from coarse-grained counting whose window is undeclared (§4.1, row 5) | **Priced, not asserted:** cell-census ratios are exact where the window is declared (Paper 12 §8's arrow is exact finite counting with its window in the open); the physical-process prose is the describer's window, reified |
| "The ensemble is a physical population whose weights nature uses" | **Inferred, never derived** — the blanket thesis under which every row of §4.1's matrix does its prose work | **Denied [Level A]** [CLASSIFIED — author's verdict, §0.5.1] — see the record below |

The left column's honest entries deserve the emphasis Paper 11.5 gave its own: in practice, working
statistical mechanics already *does* census — every calibration, every error bar, every comparison of recipe
against bench is a tally of actual records over an actual window. The critique's originality is not in
discovering the census. It is in refusing to look away from the distance between the census the practice
performs and the population the prose asserts. Every "inferred" in the left column is followed, in the
textbooks, by silence: the formalism adopts, imports, and bridges, the prose asserts, and the two are never
reconciled. Paper 12 is what the reconciliation looks like from the counting side; this paper is the
reconciliation's audit trail.

**The Denied record.**

One claim in this paper is carried past NO BADGE to the stronger verdict, and §0.5.1's definition governs it
exactly: a claim is Denied [Level A] when it has been examined at Level-A rigor — priced symbol by symbol,
row by row, against the formalism's own equations, with its strongest standard defence (here, Jaynes's,
§3.1) steelmanned and priced in the open — and the verdict on *the claim itself*, not merely on its
presentation, is negative.

> **Denied [Level A]** [CLASSIFIED — author's verdict, §0.5.1]: *"The ensemble is a physical
> population whose weights nature uses."*
>
> Examined: §3.1 (the weight is adopted, not counted; the
> population summed over is enumerated by no one and exists
> nowhere to be counted), §3.2 (the bridge from the weighted
> sum to any actual census is adopted, not proven, in its
> universal form), §4.1 (all six rows: in no row does a
> counted population carry the prose's weights; in every row
> the weights enter by postulation and the population by
> grammar), §4.2 (the worked quantity is obtainable from
> census alone, with zero unearned steps — the population is
> not merely unproven but *unneeded* at the only point where
> need could have excused it), and the H-analogue audit
> apparatus of this paper's appendix, applying the claim-graph
> pricing of §0.5 to the thesis as a whole.
>
> Verdict: **negative.** What nature uses — what every
> measurement in the discipline's history has ever tallied —
> is the census of the one system at hand. The ensemble is a
> computational device of the first rank, and as a device it
> stands. As a population — a thing in the world, weighted as
> the recipe weights it, maintaining the frequencies the
> laboratory finds — it has been examined at the rigor this
> series reserves for its own strongest claims, and it is
> **Denied [Level A]**.

The record is stated once, in the form the series keeps such records, and the paper does not return to it
informally. In particular, nothing in the Denied verdict touches the recipe: a Denied population and an
honoured device are the same equations, priced honestly at last. The illusion was never that the ensemble
computes. It was that something, somewhere, *is* the ensemble — a population behind the population, keeping
nature's tallies in exponential weights. There is only the one population, the system in front of the
counter, and its census. The rest is bookkeeping — excellent bookkeeping, priced in §3 and §4 at exactly
what it cost.

---

## 5 &nbsp; TEMPERATURE IS NOT A PROPERTY

Sections 3 and 4 audited the ensemble: a space of unrealized systems, weighted
by a rule, standing in the prose where a population should be. This section
audits the quantity the canonical ensemble imports first and examines least:
temperature. The audit's form is the one this paper inherits from Paper 11.5
(§3 there): for each exhibit, **(a)** the standard statement as the prose
gives it, **(b)** what the formalism actually contains, **(c)** the inference
chain — OBSERVED separated from INFERRED — and **(d)** the verdict, with the
ledger counterpart where one exists.

The indictment is narrow, and is stated once, here. Nothing in this section
disputes a thermometer reading, a phase diagram, or any number the standard
apparatus produces; the apparatus is not on trial. What is on trial is one
grammatical promotion, repeated until invisible: the output of a *procedure* —
bring into contact, wait, read — is rewritten as a *possession* — a scalar the
body is said to carry, as Paper 11.5's exhibits showed charge, spin, and mass
rewritten as possessions the particle is said to carry. The promotion is the
reification. Price it, and the rest is bookkeeping.

### 5.1 The zeroth-law audit

**(a) The standard statement.** Two bodies in thermal equilibrium with a third
are in thermal equilibrium with each other; therefore a single-valued state
function, temperature, exists, and each body *is at* a temperature. The law is
presented as the foundation stone: it licenses the thermometer, the scale, and
the sentence "the body is at temperature *T*" that every later chapter uses
without comment.

**(b) What the law actually contains.** Read as mathematics, the zeroth law is
a statement about a relation. Define the relation operationally, the only way
the law ever cashes it out:

> *A* ~ *B* iff, when *A* and *B* are placed in thermal contact and
> left for a sufficient interval, no net change is subsequently
> observed in either — the pair is at rest under the contact
> procedure.

The law asserts that this relation is transitive (reflexivity and symmetry
being definitional courtesies of the procedure). A transitive, reflexive,
symmetric relation is an equivalence relation, and an equivalence relation
partitions its domain into classes. That is the entire formal content: **a
partition, induced by a procedure.** An equivalence class is not a scalar. To
pass from the partition to a number one must additionally choose a labelling
of the classes — and that labelling step, with its conventions (§5.2), is
where "temperature" is manufactured. The law supplies the classes; it does not
supply the number, and it does not supply the grammar of possession.

**(c) Inference chain.**

- OBSERVED: pairs of bodies, subjected to the contact procedure,
  settle or do not settle; the settling relation is found, in
  practice, to be transitive — a measured fact about the procedure's
  outcomes, reproducible and undisputed.
- INFERRED: that each body *possesses* a scalar, its temperature,
  which the procedure merely reveals; that two bodies settle
  *because* their possessed scalars are equal.

The inference is the reification, and it can be priced exactly. Transitivity
is a property of the procedure's outcomes; it is measured. The possessed
scalar is a property attributed to the body in isolation, between procedures,
at instants when no procedure is running; it is inferred, and the inference
adds content the measurement does not contain — a standing value, carried
through time, owned by the body alone. Strip the inference and nothing
empirical is lost: every zeroth-law prediction is a prediction about what the
contact procedure will do, and survives verbatim in the relational form. What
is lost is only the noun. Note what the relational form keeps visible that the
possessive form hides: the procedure's own parameters. "Thermal contact" names
an interaction channel; "a sufficient interval" names a window; "no net change
observed" names a reading, taken by something. The classes are indexed — by
channel, window, and instrument — as §§3–4 showed the ensemble's outputs to be
indexed by undeclared choices. The possessive scalar erases the index. That
erasure, not the law, is the defect.

**(d) Verdict, under the inherited audit standard.** Paper 9.5 fixed the
standard this series applies to thermal variables, and §2 adopted it for this
paper: a thermal variable counts as *derived* only if obtained without
temperature, equilibrium, or ensemble distributions entering as primitives.
The zeroth-law route fails that standard at its first step, openly: the
procedure defining the relation takes *equilibrium* — settling under contact —
as its primitive input. The law organizes equilibrium; it does not produce it
from anything more basic. This is not a complaint about the law's truth but
about its billing: presented as the *foundation* of temperature, it is a
partition theorem about a procedure whose central notion is assumed.
**Temperature as a possessed scalar, derived from the zeroth law: Denied [Level A]** [CLASSIFIED — author's verdict, §0.5.1] — the denial attaching to the derivation claim and the possessive
grammar, not to the law, whose procedural content stands exactly as measured.

### 5.2 The thermometer circle

The zeroth law gives classes. A scale must still be built, and the way scales
are in fact built is the audit's second exhibit — because the building method
is, on inspection, a second and independent pricing of the same promotion.

Every working thermometer is calibrated the same way. Certain reproducible
physical situations are adopted as *fixed points* and assigned numbers by
stipulation. Between and beyond the fixed points, the reading of a chosen
instrument — a liquid's expansion, a wire's resistance, a gas's pressure at
constant volume — is converted into a temperature by an *interpolation rule*:
a prescribed functional form, adopted so that different instruments can be
brought into agreement. The international temperature scales that codify this
practice are, by their own construction, *defined* by a list of fixed points
together with prescribed interpolation formulas and prescribed instruments for
the intervals between them. The scale is a rule for making readings agree —
adopted, and revised when a better rule is wanted, each revision changing
assigned values in some ranges while the bodies being measured did nothing at
all.

None of this is scandalous, and the audit does not present it as scandal:
metrology is honest about what it does, and its definitions, fixed points, and
interpolation formulas are published. The circle appears only in the prose
downstream physics wraps around the metrology. The textbook sentence runs: the
thermometer *measures the temperature of* the body. Unpacked, it says: an
instrument adjusted to reproduce an adopted rule at adopted fixed points
produces a reading, and the reading is attributed to the body as its possessed
scalar. The rule's conventionality — real, documented, and nobody's fault — is
laundered in transit: what arrives in the thermodynamics chapter is "the
temperature," wearing the prose of a discovered quantity; what left the
laboratory was a convention for coordinating instruments.

The pricing is therefore precise. A temperature *reading* is a procedure
output: instrument, fixed-point table, interpolation rule, and body, jointly.
The possessive prose keeps the body and drops the other three indices. Restore
them and the circle dissolves into what it always was — a well-run,
extraordinarily useful convention whose outputs are relational facts about a
measurement arrangement. The audit asks for nothing to be recalibrated; it
asks that the prose stop spending a convention as a discovery.

### 5.3 Negative temperatures: the paradox is the parameterization

**(a) The standard statement and its scandal.** For systems whose energy
spectrum is bounded above, the standard formalism assigns temperatures that
are negative, and the textbooks narrate the consequences in the language of
paradox: a negative-temperature body is *hotter than any positive-temperature
body*, hotter indeed than positive infinity; as energy increases, temperature
rises toward +∞, then *jumps* to −∞, then rises toward zero from below. The
ordering of hotness runs +0, …, +∞, −∞, …, −0. Generations of students have been invited to marvel at this. The marvel is the exhibit. (The better textbooks defuse the marvel on the spot, by retreating to β = 1/T, in which the ordering runs continuously through the point the T-scale splits. The audit records the defusing gladly, because it concedes the audit's point: the paradox lives in the T-first presentation, and the β retelling survives only by abandoning the possessed-scalar grammar the T narration taught. The charge is against the T-first presentation and its inheritance, not against the defusers.)

**(b) The conditions, stated plainly.** The construction is Ramsey's (1956),
and it is careful work. Negative temperature is assigned only where three
conditions jointly hold: (i) the energy spectrum is bounded above — there is a
maximum energy the system can take; (ii) the system is in internal
equilibrium, so that a temperature-like parameter describes it at all; (iii)
the system is sufficiently isolated from degrees of freedom with unbounded
spectra — ordinary translational motion, above all — which would otherwise
absorb the inversion. The first realization predates the theory's clean
statement: Purcell and Pound (1951) prepared an inverted population among the
nuclear spins in lithium fluoride, a subsystem satisfying the three conditions
for long enough to be read. The phenomenon is real and no number in this
literature is disputed here.

**(c) The census reading.** Now count, in the manner of Paper 12 §8. Take a
bounded population: *n* named units, each standing in one of two classes, with
the record (k, n − k) carrying energy increasing in k. The assignment count of
the record is the exact integer

  Ω(k; n) = C(n, k),        (Paper 12, eq. 8.1)

and Paper 12 §8.3 proved, by exact finite counting, how this count behaves: it
strictly increases toward the balanced record and strictly decreases after it,
the successive ratio being

  Ω(k+1; n) / Ω(k; n) = (n − k) / (k + 1)        (Paper 12, eq. 8.3)

— greater than 1 below balance, less than 1 above it. The exhibited case n =
6: the counts run 1, 6, 15, 20, 15, 6, 1, with successive ratios 6, 5/2, 4/3,
then 3/4, 2/5, 1/6. The count rises, peaks, and falls. That rise-and-fall is
the whole phenomenon.

The thermodynamic temperature enters through the slope of the count: 1/T is
defined proportional to the rate of change of ln Ω with energy. On the rising
side the slope is positive and T is positive. At the maximum the slope is
zero. On the falling side the slope is negative — and the reciprocal of a
negative slope is a negative number, which the prose then names "negative
temperature." The exact instrument of Appendix E (E.2) computes this on a
bounded census in rational arithmetic: the finite-difference slope ln Ω(k+1) −
ln Ω(k) = ln((n − k)/(k + 1)) changes sign at exactly the record where the
count peaks, and at no other record; the sign flip is a computed property of
the count table, not an observed discontinuity in any system.

So price the paradox. Ω(E) is a finite table of integers. As E increases
through the table, Ω moves by exact integer steps — up, then down — and
*nothing in the table jumps, diverges, or changes character at the peak.* The
infinities and the jump from +∞ to −∞ live entirely in the coordinate 1/T,
evaluated at the one record where the slope passes through zero: a reciprocal,
taken at its own singularity, and then narrated as a property of the body. A
coordinate artifact has been promoted to a paradox of nature. The census
reading needs no marvel: on the falling side of a bounded count, the slope is
negative. Full stop. "Negative temperature" is the prose name for the falling
side of a count.

**(d) What the ledger's quantity does differently — stated carefully.** Paper
12's population temperature, D(P, W) (§5.5 below), is a ratio of two counts —
reconcile events over body-ticks. It is not formed by dividing by a slope, so
the reciprocal singularity that manufactures the paradox cannot occur in it:
the same definition, unmodified, evaluates on both sides of a count maximum,
because it never asks which side it is on. The claim made here is exactly that
claim and no larger. D(P, W) is a *different quantity* from thermodynamic
temperature — a reconcile density, not a slope reciprocal — and this paper
does not propose it as a replacement thermometer or a repair of the
negative-temperature formalism, which needs no repair: Ramsey's construction
is internally consistent and experimentally sound. The exhibit's force is
comparative and structural: a population quantity *can* be built from counting
so that the bounded-spectrum case presents no anomaly, no infinity, and no
jump — because the anomaly was never in the population. It was in the
parameterization, and the parameterization was mistaken for a possession.
**The phenomenon: real, undisputed. The paradox: prose. Verdict on "temperature jumps from +∞ to −∞" as a statement about a system: Denied [Level A].** [CLASSIFIED — author's verdict, §0.5.1]

**The live dispute, mapped.** One objection to this section's census reading is on the recent record, and it is mapped here rather than parked unnamed. Dunkel and Hilbert (2014) argue that negative temperatures are artefacts of the surface count — the count E.2 enumerates, Ω(k) = C(N, k). The surface count is the Boltzmann count. The Gibbs (volume) count, which tallies all records at or below an energy, is in their argument the consistent entropy: under it the count never falls, and temperature is never negative. Abraham and Penrose (2017) defend the standard (surface-count) reading. In this paper's vocabulary the dispute is §6's dispute replayed inside §5: two counting rules over the same bounded population, two slopes, two temperature stories — a rule choice, contested as if it were a fact about the population. The audit takes no side in which rule a thermodynamic formalism should adopt, and §5.3's verdict does not need it to: under the surface count, the reciprocal parameterization manufactures the jump from a count that rises once and falls once; under the volume count, no negative branch exists to jump to. On neither branch does any count jump. The discontinuity is in the parameterization on one rule and absent on the other; in neither is it in the population. E.2 computes the surface count because the standard narration — the prose under audit — is built on it; the mapping in this paragraph, not a side in the dispute, is the paper's whole position on it (see also §9.6, Appendix D.2).

### 5.4 The temperature of a single particle

The promotion audited in §5.1 reaches its limit case in a locution now routine
in the cold-atom and single-ion literature: *the temperature of a single
molecule*, *a single atom at a temperature of —*, a lone trapped particle said
to be hot or cold in itself. If temperature is a possessed scalar, the
locution is unremarkable — possessions scale down to one owner without strain.
If temperature is what the zeroth law delivers — a class label under a contact
procedure — the locution should be impossible. It is therefore the cleanest
test of which reading the practice itself obeys.

Examine what is measured in the experiments behind such sentences. The
measured content is never a property read off the individual at an instant; it
is one of two things. Either it is a *distribution over repeated
preparations*: the particle is prepared, interrogated, and discarded or reset,
many times, and the scatter of outcomes across the preparation census is
fitted to a thermal form — the population is the set of preparations. Or it is
a *time census of one trapped system*: the ion or atom is observed over an
interval, its states tallied across that window, and the tally fitted — the
population is the sequence of the system's own states over the declared, or
more often undeclared, window. In both cases there is a population and a
window, because there cannot fail to be: a distribution is a count over
instances, and one instance at one instant is not a distribution. The practice
is, without exception the audit can find, a census in disguise. Only the prose
assigns the resulting scalar to the individual, as its temperature, at a
moment.

The steelman must be given its full weight, because it is largely sound.
Sophisticated authors in these fields know what they have measured, and many
write "effective temperature" — flagging that the number is a fit parameter of
a distribution, relativized to the preparation protocol or the observation
window, not a thermodynamic temperature in the zeroth-law sense. The audit
concedes the point and turns it: where "effective" is printed, the audit is
conceded in miniature — the qualifier is the admission that the unqualified
noun would overclaim. What remains under audit is the unqualified usage: the
abstract that drops the qualifier the methods section kept, the textbook that
inherits the number without the protocol. The reification does its work at
those hand-offs, where the index (preparations, window, fit form) falls off
the number and the number attaches itself to the particle.

Paper 12's discipline states the correction without polemic: a
temperature-like quantity is defined on a (population, window) pair or it is
not defined at all (§5.5). The single-particle case is not an embarrassment
for that discipline; it is an instance of it. The population is the
preparation census, or the window is the trapping interval — declare which,
and the quantity is honest. Decline to declare either, and "the temperature of
a single atom" names a distribution with its population redacted.

### 5.5 What the ledger puts in its place

Paper 12 constructed its temperature-like quantity from counting alone, and
this paper inherits the construction at its home standing without
re-derivation. The construction, in brief (Paper 12 §7): for a declared
population P and a declared window W of consecutive ticks, each body books an
exact integer count of reconcile events at each tick; the population reconcile
count R(P, W) is the sum of those actual counts over the population and the
window; and the **population reconcile density** — Paper 12's earned term is
*population temperature* — is the exact rational

  D(P, W) = R(P, W) / (|P| · |W|) ∈ ℚ,   D ≥ 0,        (Paper 12, eq. 7.3)

formed only on its domain, |P| ≥ 1 and |W| ≥ 1: an empty population or an
empty window carries no value, and the construction refuses the case rather
than dividing by zero. Its one-body reduction is Paper 9's §4 definition of
temperature as rewrite-event density, recovered at |P| = 1 by the author's
identification graded at home; over a shared window it is exactly the mean of
the local densities (Paper 12, eq. 7.4). The quantity's Stage P contact is
confined to the single bridge sentence of Paper 12 §7.4. [LEVEL A — inherited:
Paper 12 §7, claims L7.1–L7.3-P12; the one-body identification carried at its
home grade, [LEVEL A: MACHINE / PROOF / AUTHOR], its AUTHOR component being
the identification itself.]

The construction is exhibited end to end, at three scales, in Paper 12's
Appendix F — three declared populations carried through every station of that
paper, every printed number recomputed from the declarations alone by two
independent implementations (script A.15). The temperature station of the
three exhibits:

| exhibit | population | window | R(P, W) | D(P, W) |
|---|---|---|---|---|
| E-SMALL | 3 bodies | 3 ticks | 5 | **5/9** |
| E-MID | 6 bodies | 3 ticks | 61 | **61/18** |
| E-LARGE | 12 bodies | 3 ticks | 1011 | **337/12** |

Each entry is an exact fraction: a count of actual booked events over a count
of actual body-ticks. There is no scale constant, no fixed point, no
interpolation rule, and no equilibrium primitive anywhere in the formation of
the number. Under Paper 9.5's audit standard — derived only if obtained
without temperature, equilibrium, or ensemble primitives — D(P, W) is the
shape a passing answer takes, and its form is the section's whole argument in
one line: **the quantity is (population, window)-indexed by construction. The
index is not hidden, because the index is in the name of the arguments.**
Where the standard scalar writes T and forgets the procedure, the ledger
writes D(P, W) and cannot forget: remove P or W and the expression does not
become approximate, it becomes undefined.

The honest limit is part of the exhibit and is stated at home (Paper 12 §7.6);
this paper repeats it rather than letting the contrast overclaim. D(P, W) is
not a thermometer reading: it does not reproduce the values of the
international temperature scales, does not claim to, and offers no conversion
to them beyond Paper 12 §7.4's single declared bridge sentence, which attaches
any numerical scale at Stage P only. A different window over the same bodies
gives, in general, a different rational — the construction treats that
window-relativity as the quantity's relational content, not a defect awaiting
repair, and defines no window-free density. What §5.5 claims is therefore
about *kind*, not metrology: when a temperature-like quantity is built from
counting, what it can be is a ratio of counts over a declared population and a
declared window — possessed by neither, indexed by both. The standard
quantity's claim to be a property of a body is the one thing this form cannot
express. That inexpressibility is the audit's positive result.

### §5 claims

- **L5.1-P12.5** — The zeroth law's formal content is an equivalence
  relation over the outcomes of a contact procedure; the possessed
  scalar is an inference beyond that content, and the route takes
  equilibrium as primitive at its first step, failing Paper 9.5's
  derivation standard. [Audit verdict — Denied [Level A] for
  temperature-as-possession derived from the zeroth law; the law's
  procedural content is not denied.]
- **L5.2-P12.5** — Working temperature scales are defined by adopted
  fixed points and prescribed interpolation rules; a reading is an
  output of (instrument, fixed-point table, rule, body) jointly.
  [LEVEL B — metrological record, stated generally.]
- **L5.3-P12.5** — In a bounded two-class census, Ω(k; n) = C(n, k)
  rises then falls with exact successive ratio (n − k)/(k + 1)
  (Paper 12, eqs. 8.1, 8.3 [LEVEL A] at home); the slope's sign change
  at the maximum is exact, and the +∞/−∞ jump is a property of the
  1/T parameterization at the slope's zero, not of the count or the
  population. [LEVEL A for the counting, inherited; the verdict on
  the prose is this paper's audit conclusion.]
- **L5.4-P12.5** — Single-particle temperature statements cash out,
  in their measured content, to a distribution over a preparation
  census or a time census over a window; the scalar assigned to the
  individual is the residue after the population index is dropped.
  [Audit finding — this paper; the "effective temperature" qualifier,
  where printed, is recorded as a partial concession.]
- **L5.5-P12.5** — D(P, W) = R(P, W)/(|P| · |W|) ∈ ℚ is defined on
  declared (population, window) pairs only, with spine exhibits
  D = 5/9, 61/18, 337/12. [LEVEL A — inherited: Paper 12 §7 and
  Appendix F, script A.15.] Scope: not a thermometer reading; no
  reproduction of scale values claimed.

---

## 6 &nbsp; ONE NAME, FOUR COUNTING RULES: THE ENTROPY BRIDGE LEDGER

Section 5 priced a promotion: a procedure's output spent as a possession. This
section prices a second, quieter operation: a *name* spent across four
different counting rules, as if the name itself guaranteed that the four
counts are one quantity. The word is "entropy." The method is the ledger
method of §§3–4: lay the four constructions side by side, record for each what
is counted, what the weights are, what domain the count lives on, and what
must be adopted before it can be used at all — then price, separately, each
crossing the single name is asked to bear between them. No formula here is
disputed; each construction is legitimate mathematics doing exact work on its
domain. The defect is not in any row of the ledger. It is in the unpriced
travel between rows.

### 6.1 The ledger

| # | Name and form | What is counted | What the W / the p's are | Domain | What must be adopted to use it | Crossings it is asked to bear |
|---|---|---|---|---|---|---|
| 1 | **Boltzmann** — S = k_B ln W | Permutations / assignments of actual constituents realizing a macrostate | W: an integer count of micro-arrangements compatible with the macrostate | A declared population of constituents and a declared macrostate classification | A classification of arrangements into macrostates; the counting rule for arrangements (distinguishable or not — §6.3) | To Gibbs (reduction, §6.2); to thermodynamics (the bridge Paper 12 confines, §6.4) |
| 2 | **Gibbs** — S = −k_B Σᵢ pᵢ ln pᵢ | Nothing is counted; a weighted sum is taken over an ensemble | pᵢ: weights assigned to the members of a hypothetical ensemble of systems | The ensemble — a space of imagined copies, §§3–4's audited object | The ensemble itself, and a rule assigning its weights (the canonical rule imports temperature, §3) | To Boltzmann (at uniform weights); to Shannon (shared functional form); to thermodynamics (as *the* entropy of a single system) |
| 3 | **Shannon** — H = −Σ p log p | Nothing is counted in the formula; its empirical cash value is symbol frequencies in message streams | p: probabilities of symbols from a source — in practice, relative frequencies over a corpus of messages | Communication: a source, an alphabet, an ensemble of possible messages | A source model; the identification of probabilities with long-run frequencies; a log base (the unit is a convention) | To Gibbs (Jaynes's import, §6.2); to thermodynamics ("entropy is information") |
| 4 | **von Neumann** — S = −k_B Tr(ρ ln ρ) | Nothing is counted; a trace is taken over an operator | ρ: a density operator; the weights are its eigenvalues, fixed by the quantum state ascription | Quantum state space | The density operator itself — a state ascription, not a census; the measurement context in which ρ is assigned | To Gibbs (formal analogy); to thermodynamics (as the quantum entropy of a system) |

A note on row 1's attribution, because the ledger prices provenance as
carefully as content. Boltzmann's own result (1877) is a *proportionality*:
entropy proportional to the logarithm of the count of permutations — the
"permutability measure" — of the state. The exact equality S = k_B ln W, with
the constant that now bears Boltzmann's name, is Planck's form of it
(1900/1901). Printing the Planck formula under the Boltzmann name alone is a
small instance of this section's large point: the name travels, and the
provenance — what was established, by whom, in what form — is dropped in
transit. The ledger restores it because the restoration is cheap; it is the
travel without the restoration that costs.

Read the table by its second column, which is the audit column. Only row 1
counts anything. Rows 2–4 evaluate a functional of the same *shape* — a
weighted logarithm sum — over objects that are not counts: ensemble weights
(assigned by a rule), source probabilities (cashed as frequencies of symbols,
a different population from any gas), operator eigenvalues (fixed by a state
ascription). The shared shape is real, and §6.2 prices what it does and does
not buy. But a shared functional shape is not a shared subject matter. Four
rules, four domains, four different things the symbols stand for — and one
noun, "entropy," declined through all four as though grammar were evidence.

### 6.2 The crossings, priced

A crossing is a use of one row's result in another row's domain, under cover
of the shared name. The ledger recognizes one honest crossing, two priced
imports, and one analogy since opened (Appendix D.1) — not the same kind of object, however
uniformly the prose treats them.

**Boltzmann ↔ Gibbs — the honest crossing, and the exception that proves the
ledger's point.** Set the Gibbs weights uniform over the W arrangements of row
1: pᵢ = 1/W for each of the W microstates. Then

  −k_B Σᵢ pᵢ ln pᵢ = −k_B · W · (1/W) · ln(1/W) = k_B ln W,

exactly, in one line of arithmetic. This crossing is a *theorem*, and the
ledger says why: both sides count the same records under the same rule. At
uniform weights the ensemble's members are precisely the counted arrangements
and the weights precisely the count's own uniformity; nothing crosses a domain
boundary. This is the standard the other crossings are measured against: a
crossing earns theorem standing when the two sides count the same records with
the same rule, and not before. It is the exception in this ledger — of the
instructive kind, because its proof displays the condition the other crossings
fail.

**Gibbs ↔ Shannon — the import.** The two functionals are the same formula up
to the constant k_B and the log base. In 1957 Jaynes built on that identity of
form a programme: statistical mechanics as inference — the canonical weights
recovered by maximizing the Shannon quantity subject to constraints, the
ensemble reinterpreted as the least-committal assignment of probabilities
consistent with what is known. The ledger prices this crossing in two parts,
and the parts must not be merged. *As inference discipline*, the import is
legitimate and fruitful: the maximum-entropy assignment is a defensible rule
for assigning weights under ignorance, and Jaynes's programme is honest about
being a theory of inference. Priced as such: **[LEVEL B]** — a declared
methodological programme. *As physical identity* — the further claim,
ubiquitous in the prose the programme licensed, that thermodynamic entropy
*is* information and the Gibbs quantity therefore a measure of a system's
missing information — the crossing has **no badge**. Shannon's quantity was
framed by Shannon (1948) as communication-theoretic: a property of a source
and its symbol statistics, defined for the engineering problem of
transmission. Its p's are cashed by frequencies over messages sent; the Gibbs
p's are assigned by a recipe over systems imagined. The identity of the two
formulas is a fact about a functional; the identity of the two entropies is a
further claim, about domains, and no theorem of either field proves it. The
prose asserts it by declining one noun through both.

**Shannon ↔ thermodynamic — the prose crossing.** Downstream of the import
sits a body of prose looser than Jaynes's own: "entropy is information,"
"information is physical," and the family of discussions assigning the erasure
or acquisition of information a thermodynamic cost in entropy's currency (the
Landauer-cost literature, named here generically). The pricing is brief.
Whatever the merits of particular results in that literature — several are
careful experiments on declared systems, and no number of theirs is disputed
here — the *crossing* as used in the prose is unpriced: a result about a
declared device's energy budget is spent as a revelation about the identity of
two quantities defined on unlike domains. Each such spending is an un-declared
bridge; declared, device by device and domain by domain, the same work would
be unobjectionable — which is §6.4's demand, applied early.

**von Neumann ↔ Gibbs — the analogy, opened in Appendix
D.1.** The von Neumann functional takes the Gibbs
functional's shape when ρ is diagonal in the energy basis
with eigenvalues read as weights, and the resemblance is
constantly spent as kinship. The ledger records the
disanalogy in one sentence and refers the rest to Appendix
D.1, where the quantum case is audited in full: the
eigenvalues of a density operator are not a census of
anything — no population was counted to obtain them, no
window declared, no assignments enumerated; ρ is an
ascription, its weights fixed by the formalism's rules for
ascription, not by counting actual instances of anything.
A functional evaluated on an ascription and the same
functional evaluated on a count share a shape and nothing
else. Appendix D.1 prices the ascription symbol by symbol
(D.1.2), its provenance in practice (D.1.3), and the
provenance its form does not record (D.1.4); the verdict
on the quantum blanket thesis stands at D.1.5.

### 6.3 The Gibbs paradox, dissolved

**(a) The standard exhibit.** Two identical portions of gas, equal volumes,
equal temperatures, separated by a partition. Remove the partition. If the
constituents are counted as distinguishable — each molecule a named
individual, exchanges of individuals counted as different arrangements — the
counting yields an entropy of mixing for the combined system: entropy
increases by a definite amount, although nothing thermodynamic has happened
and replacing the partition unmixes nothing. Count instead with the divisor
1/N! applied to each portion's arrangement count, and the mixing entropy for
identical gases vanishes, as extensivity is said to require. The standard
prose narrates this as a paradox *in nature*, resolved by a correction the
counting supposedly needed — in many textbook tellings, one classical physics
could not justify and quantum mechanics, with its indistinguishable particles,
finally forced.

**(b) The ledger reading.** There are two counting rules. Rule D counts
arrangements of distinct individuals. Rule C counts the same arrangements
modulo permutation of individuals — equivalently, divides Rule D's count by
the factorials of the portion sizes. Each rule, applied consistently, gives a
complete and consistent set of counts. The "entropy of mixing of identical
gases" is a number produced by switching the effective rule between the
separated and combined descriptions. The exact instrument of Appendix E (E.3) computes the switch at small N, where nothing can hide in a limit. The claim's domain is stated here, in the section that makes it, and not only in §8.3's run record: the counts are the finite slot census E.3 enumerates — two portions as declared sets of named bodies in declared slots, mixed by removing the partition between them. In a volume-framed counting, the Rule C factor for identical portions reaches 1 only in the Stirling limit; the dissolution claim — the jump is the rule switch, exactly, with no remainder — is asserted over the census the instrument checks, and the volume framing inherits it only through that limit, declared as such. For two
portions of N named bodies each, the factor by which the two rules' combined
counts differ at the mixing step is exactly

  (2N)! / (N! · N!) = C(2N, N):

N = 1: 2. N = 2: 6. N = 3: 20. N = 4: 70. The jump in ln Ω at the rule switch
is ln C(2N, N) — the *whole* of the spurious mixing entropy, at these sizes,
with no remainder: subtract the factorial ratio the switch introduces and
nothing is left to explain. Two counting rules give two counts; nothing in the
gas changed when the rule changed, and the gas was not consulted about the
rule. The paradox exists only under the reification audited throughout: if
"the entropy" is a substance the gas *possesses*, a change of counting rule
that changes the number presents as a scandal in nature, and the number's
behaviour under rule changes it was never defined across becomes a constraint
the substance must satisfy. Drop the reification — entropy, in row 1 of the
ledger, is the logarithm of a count, and a count is relative to its counting
rule — and the paradox dissolves into the dull exact truth: the rule must be
declared, and held fixed across the descriptions compared. Declared and held
fixed, either rule gives consistent books. The scandal was the undeclared
switch.

**(c) The steelman, and what remains unpriced.** The field half-knows this,
and the audit records the half it knows at full value. The modern resolution —
distinguishability is operational: constituents are indistinguishable *for a
process* when no operation available to that process can track the exchange —
states the relational truth plainly, and Jaynes's resolution runs along the
same line: the entropy assigned depends on the operations and distinctions the
description is built for, and two descriptions answering different operational
questions may honestly carry different counts. Under that resolution, which
this paper endorses as far as it goes, the paradox is already dissolved in
principle. What remains unpriced is the textbook inheritance: the 1/N! still
enters most first presentations as a *correction* — a patch applied to a count
nature found wanting, frequently credited to quantum indistinguishability as
its only possible warrant — rather than as what it is in the ledger: a
counting-rule declaration, a choice of what the count shall count, available
to classical counting since Gibbs's own practice and requiring no quantum
licence. The two presentations teach different ontologies. "Correction"
teaches that there is a true count, possessed by the gas, which the naive rule
got wrong; "declaration" teaches that there are rules, counts under rules, and
an obligation to say which rule is in force. The first lesson manufactures the
next paradox; the second makes paradoxes of this species impossible, at the
cost of one sentence per textbook. The audit's demand is the sentence.

### 6.4 Paper 12's confinement as the discipline's model

Against the four-row sprawl of §6.1, set the practice this paper inherits. In
Paper 12, the word "entropy" is admitted to the native ledger *nowhere*. The
native quantities are the census record and its assignment count Ω — an
integer, computed from the actual bodies by the counting of Paper 12 §8.2. The
word enters in exactly one place: the single Stage P bridge sentence of Paper
12 §8.4,

> [BRIDGE — Stage P] … at Stage P only, the assignment count Ω of a
> census record is read as entropy through S = k_B ln Ω — a
> reconstruction reading of the record, carrying a Stage P scale
> token, which no native claim in this paper uses, needs, or
> restates.

— together with its declared restatements, each flagged at its site: the
attributed recognition at Paper 12 §8.7, where the count is identified, under
the bridge and as a recognition only, with the textbook two-state
multiplicity; and the bridge values ln Ω printed as bridge values in Appendix
F's exhibits. One crossing — from an exact count of actual bodies to the
Boltzmann row of §6.1's ledger, the one row that also counts — declared in one
sentence, priced at its components' strength, and fenced so no native result
leans on it. Paper 12's equilibrium predicate (§9 there) is stated over
Ω-maximality among census records, not over entropy; its arrow (§8 there) is
assembled from counts and an inherited boundary condition, not from an entropy
increase. The locked word does no native work. That is confinement done by
construction rather than by apology.

This paper's demand of the standard account is the symmetrical one, and it is
deliberately modest. It is not that the standard account abandon its four
entropies — each does exact work on its own domain, and §6.1's ledger is a
catalogue of legitimate instruments, not a charge sheet — nor that crossings
be forbidden: §6.2 exhibits one crossing that is a theorem and prices one
import that is a fruitful programme. The demand is that crossings be
*declared* the way Paper 12 declares its one — at the site, in so many words,
with the domains named on both sides and the claim priced at no more than the
weaker side can carry. A literature that printed, at each use of the shared
noun, which counting rule was in force and which bridge was being crossed,
would lose no theorem, no experiment, and no number. It would lose the
paradoxes of §§5.3 and 6.3 — which is to say, only the interest it has been
collecting on undeclared travel. The ensemble illusion, in its entropy
chapter, is exactly that interest, compounded over a century of unpriced
crossings. Declare the rule, declare the bridge, and the illusion has nowhere
left to live.

### §6 claims

- **L6.1-P12.5** — Of the four constructions travelling under the
  name "entropy," only the Boltzmann row is a count of arrangements
  of actual constituents; the Gibbs, Shannon, and von Neumann rows
  evaluate the same functional shape over ensemble weights, source
  probabilities, and operator eigenvalues respectively. [Audit
  finding — this paper, §6.1's ledger; historical components at
  LEVEL B, itemized in the accompanying fact-check list.]
- **L6.2-P12.5** — The Boltzmann ↔ Gibbs crossing at uniform weights
  is an exact reduction, k_B ln W = −k_B Σ (1/W) ln(1/W), a theorem
  because both sides count the same records under the same rule.
  [LEVEL A — arithmetic shown in §6.2.]
- **L6.3-P12.5** — The Gibbs ↔ Shannon crossing is priced as an
  import: [LEVEL B] as inference discipline (Jaynes's programme, on
  its stated rationale); **no badge** as physical identity of the
  two quantities. The von Neumann ↔ Gibbs crossing is recorded as
  formal analogy over unlike domains; its full audit is given in
  Appendix D.1 (claims LD.1–LD.4).
- **L6.4-P12.5** — The Gibbs-paradox jump at small N equals exactly
  the factorial ratio C(2N, N) introduced by the counting-rule
  switch (N = 1…4: 2, 6, 20, 70), with no remainder. [LEVEL A —
  exact finite counting, Appendix E instrument E.3.] Verdict on the paradox as a discontinuity in nature: **Denied [Level A]** [CLASSIFIED — author's verdict, §0.5.1] — the discontinuity is in the rule, not the population.
- **L6.5-P12.5** — Paper 12 admits "entropy" only in the single
  Stage P bridge sentence of its §8.4 (S = k_B ln Ω) and declared
  restatements; no native claim there uses it. [Inherited record —
  Paper 12 §8.4, claims L8.5-P12.]

---

## 7 &nbsp; THE ARROW AUDIT

Sections 3–6 priced the ensemble, its temperature, and its entropy. This section prices the remaining load the
idiom is asked to carry: the direction of time. The standard account's arrow — entropy increases; equilibrium
is approached; the past was lower-entropy than the future — is narrated as explained: given the dynamics, the
counting, and an initial condition, the direction follows. The audit asks the §3.3 questions of that
narration, and the answer, assembled in §7.1, is that the arrow rests on three supports, each priced elsewhere
in this paper, none of them a theorem connecting a real system's dynamics to the drift of its assignment
counts. §7.2 exhibits two small models in which enumeration settles the whole question — and in which counting
gives approach and return together, and no monotone drift. §7.3 states the audit's fairness obligation: the
matching gap in this framework's own account, and the bibliographic — not physical — difference between the
two gaps.

### 7.1 The three crutches, priced

**First crutch: ergodicity.** The arrow's counting step requires that a single system's history sample the
state list the way the ensemble's weights prescribe — otherwise the count of assignments says nothing about
the trajectory the one system follows. That requirement is the ergodic bridge, priced in §3.2 and imported
here at its §3.2 verdict: as a universal claim it earns NO BADGE — proved case by case where it is provable,
adopted silently where it is not, and obstructed, for near-integrable systems, by invariant structures no trajectory crosses. An arrow that needs the bridge inherits the bridge's price: where a system-specific result
exists, that system's arrow inherits its standing, hypotheses attached; the textbooks' universal arrow
inherits the universal verdict.

**Second crutch: coarse-graining.** The arrow's entropy is not computed on the system's records directly; it
is computed on cells — a partition of the state space, chosen by the describer, within which records are
tallied as equivalent. §4's matrix priced this practice (row 5) and the price is imported here entire:
coarse-graining is a declared-window census in disguise, and the practice is sound exactly where the window is
declared. The arrow's prose does not declare it. An entropy defined through an undeclared partition is a
describer-relative number; narrated as a physical process the system undergoes, it spends the describer's
choice as the system's property — the reification of §§5–6, applied to time. Declared, the same computation is
a census over a named window and stands where Paper 12's censuses stand. The crutch is not that the practice
exists; it is that its one load-bearing choice is the one its prose never mentions.

**Third crutch: the Past Hypothesis.** Whatever the counting shows about shares, a trajectory that begins at
the balanced record has nowhere to drift to; the observed arrow requires the universe — or the system, or the
declared population — to have begun in a record of very small assignment share. The standard account supplies
this as an initial condition: a low-entropy past, adopted. Price it by Paper 1's criterion, as §2.6 priced the
equal-weight postulate: adoption is legitimate when declared, and this adoption, in the careful literature,
often is. What the textbook prose then does is the audit's charge. The arrow is narrated as EXPLAINED — the
dynamics plus the counting are presented as the explanation, and the adopted initial condition, without which
the explanation predicts approach from every starting point and therefore from none in particular, is carried
in a subordinate clause or a footnote. Adoption-then-derivation, in Paper 1's exact pattern: the adoption is
never priced in the prose that spends its consequences. Paper 12's own arrow carries its boundary condition
the other way — inherited openly from Paper 9, flagged at its claim site (§8 there; Appendix B here). Both
sides have a boundary condition. The contrast is where it is printed.

Assembled: the standard arrow = an adopted bridge (§3.2's price), an undeclared window (§4 row 5's price), and
an adopted initial condition (Paper 1's pattern), narrated as a derivation. Each component, declared, is
legitimate. The narration is the defect. [CLASSIFIED — the audit's pricing, §0.5.5.]

### 7.2 The exhibits: approach and return, from counting alone

Two of the record's own models (§2.5) let the arrow question be asked in a form enumeration can settle
completely. Both were built by their authors to exhibit the reversibility and recurrence tension; both are
used here for exactly the purpose their builders stated, and for no other.

The urn model first. A finite population of numbered balls, two urns, one transfer per step: the balanced
record's census share dominates the assignment count, the H-like quantity drifts toward balance and fluctuates
there, and recurrence to the initial record is certain with an exponentially long expected wait. Nothing in
the model prefers a direction: the same counting that concentrates the shares near balance assigns the initial
record its small, exact, non-zero share, and the dynamics visits records in proportion to no arrow but the
tally. Instrument M.2 (§8) runs this model as an exhibit and verifies its stationary shares against the exact
census; the lesson is the model's own: drift-toward-balance and certain-return are both counting facts, and a
narration that reports the first as the model's message and the second as a curiosity has selected its arrow,
not derived it.

The ring model is sharper, because its dynamics is deterministic: no lot is drawn at any step, so no appeal to
chance can blur what the counting says. Instrument E.4 (§8) enumerates the model exhaustively at small sizes —
every colouring against every placement of the marked sites, 1,398,016 cases in all — and verifies exact
recurrence within 2N steps in every case. Within that exhaustively checked census sits the witness this
subsection exists to report. At N = 4, with flipper mask 0001 and colouring 0000, the black-count's distance
from balance does not decay monotonically: from step t = 2 to step t = 3 the count moves away from balance, b:
2 → 3, inside a fully recurrent, deterministic trajectory that returns exactly to its start. The witness is
one trajectory among the enumerated cases, and the audit states its weight exactly: it does not show that
decay fails in general — decay, as a census tendency, is §8's exact counting and is not in dispute. It shows
that counting gives approach and return both, and no monotone drift theorem: any narration in which the
population's imbalance must fall at every step is refuted by a four-site ring, and any narration in which it
falls only as a census tendency is the statistical re-reading of §2.3 — legitimate, declared, and resting on
the weight step §§3–4 priced.

That is the exhibits' joint verdict, and it is our instruments' honest output, stated as such: exact finite
counting supports an arrow of shares. It does not support an arrow of trajectories. The distance between
those two arrows is the distance the three crutches of §7.1 are hired to cross.

### 7.3 The shared hole, stated fairly

This subsection is the paper's credibility anchor, written to be quoted against it if it is ever over-read.

The standard account has no theorem connecting its dynamics to the drift of assignment counts — the quantity this paper writes Ω — for a generic class of real systems. (Per-class theorems exist and are honoured where they exist — §3.2's pricing, with the hard-ball class of §3.2 as the standing example; this subsection's claim is scoped exactly as its falsifier, C38, is scoped.) Its arrow is assembled, per §7.1, from a bridge adopted in universal
form, a window seldom declared, and an initial condition adopted and then under-priced in the narration. That
is the audit's finding against the standard account, and §§3–7 stand on it.

Paper 12 has the same-shaped gap. No theorem in Paper 12 connects the monotonicity of its per-tick accounting
to the drift of its census maxima; closed populations in the ledger end at fixed points, and the joint where a
dynamics-to-maximum drift theorem would sit is named, in Paper 12's own section numbering, as open (Paper 12
§§8.6 and 9.6, the scope subsections titled, in both places, "where it bottoms out, stated"). The joint is
inherited by this paper as open (Appendix B), it is not closed anywhere in this critique, and no verdict in
§§3–7 rests on closing it. A reader who stopped here would have the comparison exactly right: two accounts,
each with a hole of the same shape at the same joint of the argument.

The difference is disclosure, not possession. Paper 12's gap is in its own index: stated at §8.6, restated at
§9.6, carried in its claim list as a conjecture with its underivability consequences spelled out, and fenced
by a falsification condition that names the joint's shape. The standard account's matching gap is not
mentioned in the prose that narrates the arrow as explained: the bridge is asserted, the window is silent, the
adoption is footnoted, and a student who learned the subject from the textbooks would not learn that a theorem
is missing. The verdict of this subsection is therefore a claim about the printed record — the sources this audit examined ([L4], [L5], Appendix A) — and stated as nothing more: one gap is in the index, and the other is not mentioned in the prose that narrates the arrow as explained. Neither side is credited with a theorem it does not have. If the standard account prints its joint tomorrow — names it, scopes
it, fences it — this subsection's charge lapses, and §11 (condition C38) states the stronger development that
would falsify the comparison outright. Disclosure is not a small thing in a discipline whose product is
derivations; the audit prices it at exactly its weight, and at no more.

---

### 7.4 What a drift theorem would have to supply: a costed programme

Section 7.3 left two accounts with the same-shaped hole and a difference
of disclosure. The standard account's arrow is narrated as explained,
with no theorem connecting its dynamics to the drift of assignment
counts; Paper 12's joint — no theorem connecting its per-tick accounting
to the drift of its census maxima — is printed in its own index, at
§§8.6 and 9.6 there, as open. Section 7.3 priced the disclosure
difference. This section does the constructive half of disclosure: it
itemizes what a closure would cost, premise by premise, so that the
joint's openness is a priced inventory, not a gesture. Nothing in this
section supplies the missing theorem, and nothing in it should be read
as supplying it. The section states the shape a closure would have to
take, what each of its premises would have to deliver, and what the two
exhibits of §2.5 and §7.2 already show about each premise's price. A
programme is not a result. It is the bill for one, printed in advance,
so that whoever pays it — on either side of the comparison — can be
checked against the bill, and so that no later prose can present a
partial payment as the whole.

The inventory has six premises. A drift theorem for the ledger — a
theorem connecting a dynamics on ledger records to the drift of the
census maxima, the assignment-count maxima this paper writes as the
maxima of Ω — must supply each of them, or discharge it explicitly and
say what the discharge costs. A proof that supplies four and is silent
on the fifth has not closed the joint; it has moved the hole to the
premise it skipped, and the inventory exists so that the move can be
seen.

| Premise | What it must supply | Kac ring | Ehrenfest urn | Price |
|---|---|---|---|---|
| P1 — a dynamics on records | A declared per-tick rule transforming ledger records, native to the framework, in which each tick's successor record follows from the rule and the present record | Supplied: an exact deterministic reversible rule on records — colour flips at marked sites, no lot drawn at any step | Supplied only as a declared sampling rule: one ball chosen by lot changes urns at each step — a census process, not a mechanics, and priced as such | P1 is suppliable, and both toys supply a form of it; the ledger's own form is owed — a native per-tick rule, stated before any drift claim is priced |
| P2 — an Ω functional on records | The assignment-count of a record — Paper 12's Ω — defined on the same records the dynamics moves, so that dynamics and count speak about one object | Supplied: imbalance and assignment counts are defined on the ring's colourings, the very records its rule moves | Supplied: the assignment counts C(N, k) are defined on the urn's records, the very records its rule moves | Supplied in both toys and inherited for the ledger [L2]: Paper 12's Ω is defined on its records; no new cost — the premise is cheap exactly because counting is cheap |
| P3 — a monotonicity mechanism | A reason, from the dynamics itself, why Ω should drift toward its maxima — the theorem-shaped premise | Refuted for this class: E.4's exhaustive run exhibits non-monotone trajectories (§8.4); the ring is a standing counterexample to free monotonicity | Not supplied: what concentrates is the census share across trajectories, a fact about the distribution of trajectories; single trajectories fluctuate and recur, and M.2's exhibit (§8.6) shows shares, not a trajectory theorem | Missing — the joint itself; no exhibit supplies it, one exhibit refutes its free form, and no price short of a proof discharges it |
| P4 — a recurrence/window discipline | A drift statement that survives recurrence: either recurrence is excluded for the named class, or the window is carried inside the claim as part of the result | Exhibited as obstruction: exact recurrence within 2N steps, in every one of E.4's 1,398,016 cases (§8.4) | Exhibited as obstruction: recurrence is certain, and the expected wait is exponential in N — at N = 20 the extreme record's mean recurrence time is exactly 1,048,576 steps (§8.6) | Obstruction priced, discipline owed: recurrence is not a remote caveat but an exact output of both exhibits; the window discipline that answers it has not been stated for the ledger |
| P5 — a bridge | A priced passage from record-level drift to the bulk arrow claim, with the bridge priced under L_claim ≤ min(L_i) (§0.5.2) | Not addressed: no bulk claim is made for the ring, and none is priced | Not addressed: no bulk claim is made for the urn, and none is priced | Unpriced until P3 exists for a named class: a bridge over a drift nobody has proved carries no load, and its price cannot be known before the drift it would carry |
| P6 — a starting-record premise | The class of initial records over which drift is claimed, declared and priced — records already at a census maximum, or at a fixed point of the dynamics, excluded by statement, not by silence | Discharged by enumeration: E.4 runs every starting colouring, so no start is privileged in silence | Discharged by declaration: M.2's run starts from a named extreme record, printed at the exhibit's head | Owed by any future proof: the ledger's form of the standard arrow's third crutch (§7.1) — an adoption if silent, a premise if printed |

#### The premises, one by one

**The inventory's scope, stated before its claims.** The inventory
prices *record-level* drift theorems: theorems whose conclusion is
about individual ledger records' census trajectories — the only
kind that could close Paper 12's joint as Paper 12 states it,
since the joint is about records (Ω is a count of records; Paper
12 §§8.6/9.6). A neighbouring family of genuine theorems is named
here so it cannot be mistaken for a counterexample or smuggled as
a closure: *distributional* drift results — the Markov ergodic
theorem (the Ehrenfest urn's distribution converges to the
binomial census law; expected imbalance decays geometrically),
relative-entropy monotonicity under stochastic kernels, and
typicality arguments over a measure on initial records. Those
theorems are true, and they live one level up, on distributions
over records. In this framework a distribution over records is a
Stage P import (§7.1's pricing; Paper 12 §5's dissolution removed
the sampling measure such results take as primitive), so a
distributional closure would not close the joint — it would
change the claim's subject from records to a measure over them,
the move §§3–4 audit wherever the standard account makes it. The
urn's distributional theorem is therefore read in P3's cell as
exactly what it is: drift supplied at distribution level, absent
at record level. The completeness claim (L7.4.1) is scoped to the
record-level kind, and the inventory's premise readings are the
fine ones printed below — fixed in advance, so that C44's
adjudication appeals to a text, not to a defender's improvisation.

**P1 — a dynamics on records.** The first premise looks administrative
and is not. A drift claim is a claim about what a rule does to records
over ticks, so the rule must exist, in the open, before the claim can
even be stated: a declared per-tick transformation, native to the
framework, taking each ledger record to its successor — one rule,
unchanged, for the whole of the window the claim covers (a rule
swapped mid-window is a second dynamics, and E.4's persistence
mutant is the standing exhibit of the difference). The word
"native" carries the premise's whole price. The ledger's records are
per-tick accounting records (Paper 12 [L2]); a rule imported from
outside the framework — a lottery over records, a reshuffling, a fresh
draw at each tick — would move different objects than the ledger keeps,
and a theorem about those objects would be a theorem about the import,
not about the ledger. Both toys meet P1 in a form, and the difference
between their forms is itself part of the inventory. The ring meets it
exactly: a deterministic, reversible rule, stated in full, with no
hidden step. The urn meets it only in the declared sampling form: its
per-step rule chooses a ball by lot, so what it supplies is a census
process — records generated under a stated drawing rule — and not a
mechanics of the records themselves. Priced honestly, the urn's P1 is
a weaker object than the ring's, and a ledger dynamics modelled on the
urn's form would inherit that weakness at the first premise, before
any question of drift arises.

**P2 — an Ω functional on records.** The second premise is the
inventory's one cheap line, and its cheapness is instructive. Ω — the
assignment-count of a record, Paper 12's census maximum's underlying
count — must be defined on the same records P1's dynamics moves. If
the dynamics moves one kind of object and the count tallies another,
"drift of Ω" is a sentence about nothing. In both toys the premise is
met without strain: the ring's imbalance counts are counts of its
colourings; the urn's C(N, k) are counts of its distributions of balls.
For the ledger the premise is inherited, not built here: Paper 12
defines Ω on its records [L2], and this paper adds nothing to that
definition. The lesson the cheapness teaches is where the joint is
not. Counting was never the hard part — §§7.2 and 8 exhibit counts
settled exactly, by enumeration, in every case checked. The hole
opens at the next premise, where a count must be connected to a
dynamics.

**P3 — a monotonicity mechanism.** This premise is the joint itself,
stated as a line item. What is owed is not the observation that
balanced records carry the largest assignment counts — that is P2's
counting, and it is exact — and not the observation that census shares
concentrate near the maxima — that is §8.1's census, and it too is
exact. What is owed is a mechanism: a reason, derived from P1's
dynamics, why a record's Ω should move toward the maxima as the ticks
run — a reason that holds for the trajectories the dynamics actually
generates, in a named class, with its hypotheses printed. Nobody has
it, on either side of §7.3's comparison, and the exhibits show that
the gap cannot be closed by optimism. For the ring's class the free
form of the premise is not merely unproved but refuted: E.4's
exhaustive run (§8.4) contains trajectories in which the black-count's
distance from balance grows from one tick to the next — at N = 4,
flipper mask 0001, colouring 0000, from t = 2 to t = 3 the count moves
away from balance, b: 2 → 3 — inside a trajectory that recurs exactly.
One such trajectory is enough to kill any claim that this dynamics
carries monotonicity for free; monotonicity, if it exists anywhere,
will exist as a theorem with hypotheses that exclude the witness, and
stating those hypotheses is part of the premise's price. For the urn,
the premise is not refuted but mislocated in the usual telling: what
M.2 exhibits (§8.6) is the concentration of census shares across
trajectories — the stationary shares match the exact census shares to
a maximum deviation of 0.000402 over 4,000,000 steps — and a share
across trajectories is not a property of any one trajectory, each of
which fluctuates and, in finite time, returns. A mechanism that speaks
only about shares has supplied a census fact, not P3. P3 remains what
Paper 12 printed it as: missing.

**P4 — a recurrence/window discipline.** Suppose, for the sake of the
inventory, that a P3 mechanism were produced tomorrow for some class.
P4 is where it would meet its second test. Finite exact systems
recur: the ring returns every colouring to itself within 2N steps, in
every case E.4 enumerated; the urn returns to its initial record with
certainty, on an expected wait that grows exponentially in N. A drift
statement that ignores recurrence is therefore false as stated over a
long enough run, however accurate it is over a short one — and "long
enough" cannot simply be waited out, because the same finiteness that
makes the census exact makes the return certain. The premise demands
that the drift claim carry its own survival terms: either the named
class is shown to exclude recurrence — a proof obligation of its own,
and one neither toy's class can meet — or the window is carried inside
the claim as part of the result, so that the claim reads, in full,
"drift of this kind, over this window, with recurrence priced beyond
it." A window carried inside the claim is not a weakening smuggled in
afterwards; it is the claim's honest shape, of the same kind as the
declared windows of Paper 12's census ratios [L2]. What is owed is
the discipline stated in advance: which windows, for which classes,
at what price in claim-strength. Neither toy states it — both exhibit
the obstruction instead — and the ledger has not stated it either.
P4's price is therefore double: the obstruction is already paid for,
in exact numbers, by the exhibits; the discipline that answers it is
still owed.

**P5 — a bridge.** The last premise is where a proved drift could
still die. Suppose P1–P4 were all supplied for a named class: a native
dynamics, Ω on its records, a mechanism with printed hypotheses, and a
window discipline that prices recurrence. What would exist is a
record-level result — a statement about records, counts, and windows.
The bulk arrow claim — the claim the arrow's narration actually makes,
about populations and the direction of their change — is one step
further on, and the step is a bridge, priced by this paper's standing
rule: L_claim ≤ min(L_i) (§0.5.2). A bridge is not a paragraph of
connective prose. It is a priced passage in which every dependency the
bulk claim inherits — the class restriction, the window, the
hypotheses of the mechanism — is carried across and printed on the far
side, so that the bulk claim wears the weakest standing of anything it
rests on. A drift proved for a narrow class, bridged in prose to a
generic arrow, would repeat, inside this framework, exactly the
operation §§3–4 audited in the standard account: a result earned in
one place, spent in another, at a higher denomination. Neither toy
attempts the bridge — no bulk claim is made for either, and the
the inventory records the absence without criticism, because the absence
is correct: with P3 missing, a bridge would have nothing sound to
carry. P5's price is set after P3's, because it can only be priced after P3
exists for a class; until then its entry in the table is the honest
one — unpriced, because unbuilt.

**P6 — a starting-record premise.** The last premise is the one
§7.1 already priced in the standard account's column, and
symmetry forbids omitting it from ours. A drift claim is
vacuous for records that have nowhere to drift to: a record
already at a census maximum, or sitting at a fixed point of
P1's dynamics, does not move toward the maxima in any sense a
theorem could state. A proof that quietly restricts its class
to records far from the maxima and far from fixed points has
adopted its starting condition exactly as the standard arrow
adopts its Past Hypothesis — inside the hypotheses, where the
narration does not price it. The premise therefore demands
that the starting class be declared as part of the claim:
which records the drift is claimed *from*, with records at a
maximum and records at fixed points excluded by statement,
not by silence. The toys discharge the premise in the only
two honest ways available to exhibits: the ring by
enumeration — E.4 runs every starting colouring, so no start
is privileged in silence — and the urn by declaration —
M.2's start is a named extreme record, printed at the
exhibit's head. A ledger proof owes the same discharge in
theorem form: the class named, the exclusions stated, the
price in claim-strength printed.

#### The toys as boundary exhibits

The table's two exhibit columns deserve one paragraph of their own,
because their role in the programme is easily misread. The ring and
the urn are not failed attempts at a drift theorem, and this paper
does not present them as attempts at all. They are the programme's
calibration instruments: small, exact systems in which each premise
can be checked by enumeration rather than argued about, so that the
inventory's prices rest on exhibits and not on intuition. Each toy
supplies exactly the premises it supplies — the ring, an exact
dynamics and its counts; the urn, a declared sampling dynamics and
its counts — and each fails exactly where the table says it fails:
the ring refutes free monotonicity and exhibits recurrence in every
case; the urn locates its concentration in shares across trajectories
and exhibits recurrence as certainty on an exponential wait. Those
failures are data, not embarrassments. They are the reason the
inventory can price P3 as missing rather than merely unattempted, and
P4 as an obstruction rather than a caveat: in the only systems where
every premise can be settled completely, monotonicity is either
refuted or absent, and recurrence is either exhaustive or certain.
A programme calibrated on larger, vaguer systems could mistake its
own vagueness for room. Calibrated on these two, it cannot.

#### Milestones

A priced inventory becomes a programme when it states, in advance,
what would count as progress and what would count as failure. Three
milestones follow. Each is stated so that it can be completed, and
each carries its completion test in its own text; a milestone that
nothing could complete, or nothing could fail, would be decoration of
the kind §11 exists to refuse.

**MA — a decision for one named class.** Exhibit one named, finite
class of record-dynamics — a declared P1 rule over declared records,
with Ω defined on those records — in which record-Ω monotonicity is
either proved, with hypotheses printed, or refuted, by an exhibited
trajectory or an exhaustive run. *Completion test:* the proof or the
refuting exhibit is produced, in full, for the named class, and can
be checked line by line or case by case. Either outcome completes MA:
the milestone is the decision, not the direction. A proof would give
the programme its first supplied P3, for that class, at that proof's
standing; a refutation would extend the ring's lesson to a second
class and narrow the space in which a mechanism could live. What
does not complete MA is a share-concentration result, a simulation
without an exact target, or a proof for a class whose dynamics is not
the declared one — each of those is a result about something else,
and the inventory has already priced the difference.

**Status at v2 (unchanged at v3):** MA is met, in its refutation branch, for the Kac
ring class — E.4's exhaustive run and §7.2's witness are exactly
this milestone's refutation instrument, and the programme records
the meeting rather than leaving the milestone falsely open. MA
stands open for every other named class, and for its proof branch.

**MB — the recurrence discipline at theorem grade.** State the conditions under which a
drift claim can be formulated with its window inside the claim and
recurrence priced: for a named class, the window's definition, the
claim's exact form inside the window, and the recurrence fact the
claim defers to beyond it. *Completion test:* the discipline is
stated in full and then checked against both exhibits — applied to
the ring, it must return a claim the exhaustive run verifies, with
the 2N recurrence printed as the claim's boundary; applied to the
urn, it must return a claim the exact census shares verify, with the
exponential recurrence wait printed likewise. A discipline that
returns, for either exhibit, a claim its own enumeration refutes has
failed its test and does not complete MB, however elegant its form.
A discipline that survives both exhibits completes MB for those
classes and states, by its own conditions, what extending it to a
further class would require.

**MC — one bridge, priced end to end.** If MA yields a proved class,
price a P5 bridge for that class end to end: from the record-level
drift result to the strongest bulk statement the bridge can honestly
carry, with every dependency — class, window, hypothesis — printed on
the bulk side, and the bulk claim badged at no more than the minimum
standing of its dependencies, L_claim ≤ min(L_i). *Completion test:*
the priced bridge is exhibited with its dependency list complete
enough for a reader to verify the minimum by inspection; a bulk claim
whose printed dependencies omit the window, the class restriction, or
the mechanism's hypotheses fails the test, whatever its badge says.
If MA yields only refutations, MC does not lapse silently: it is
recorded as uncompletable on present results, with the refutations as
its record — a published null, in Paper 11's F.57 sense, of the same
kind this paper's §0.5.1 discipline requires wherever a route bottoms
out. MC's conditional form is part of its honesty: a bridge milestone
that presupposed its own drift theorem would beg the joint it exists
to price. One discipline on the null, stated so it cannot soften the
test: the published null is a *result*, not a completion — on the
refutations-only branch MC has failed, and the programme prints the
failure as a failure.

### §7.4 claims

- **L7.4.1-P12.5** — The inventory P1–P6 is complete *for the
  theorem-kind §7.4 scopes*: any record-level proof of a drift
  theorem for the ledger — a theorem connecting a dynamics on
  ledger records to the drift, record by record, of the census
  maxima, and spent as the bulk arrow — must supply each premise
  P1–P6 above, or discharge it explicitly at a stated price (P5
  is owed by the spending, as the inventory states: a record-level
  result not spent in bulk owes P1–P4 and P6); a proof silent on a
  premise has moved the joint to that premise, not closed it.
  [LEVEL A: AUTHOR — the author's declared inventory, stated here
  in full for inspection; no machine content is claimed.
  *Falsifier:* an exhibited proof of the scoped kind that closes
  the joint while carrying a load-bearing premise of its drift
  step outside the inventory. This falsifier is stated as §11's
  condition C44; §11 carries the condition in the series' form.]
- **L7.4.2-P12.5** — The programme statement: milestones MA, MB, and
  MC, as stated above, are the programme this section declares — MA,
  a decision on record-Ω monotonicity for one named finite class of
  record-dynamics, completable by proof or by refutation; MB, a
  window discipline surviving both exhibits with recurrence priced
  inside the claim; MC, one P5 bridge priced end to end for a proved
  class if MA yields one, and recorded as a published null if it does
  not. [LEVEL A: AUTHOR — declared programme, with each milestone's
  completion test stated in its own text above. *Limit, stated
  instead of a falsifier, per §0.5.1:* a programme is a declaration of
  intent and of completion terms, not a prediction; no outcome of
  MA, MB, or MC is claimed in advance, and the declaration is not
  falsified by the milestones remaining uncompleted — it is falsified
  only in the weaker, checkable sense that a milestone's stated test,
  exhibited as met, must be honoured as met, and a milestone's stated
  test, exhibited as failed, must be recorded as failed.]

One gap is in the index, and the other is not mentioned in the prose
that narrates the arrow as explained: that was §7.3's verdict, and
this section has not moved it by a word. What this section adds is the
repair's price, printed on the framework's own side of the comparison
— six premises, three milestones, and the exhibits that calibrate
both — so that the standard account's hole and ours, same-shaped as
they are, can now be compared a second way: not only by who discloses,
but by who has stated what a closure would cost. The joint is open.
It stays open in this paper, on the record, at the price this section
prints — for whoever does the work of closing it, on either side.

---

## 8 &nbsp; MACHINE VERIFICATION

This section publishes the verification suite's outputs, in the two columns §0.5.5 requires. **COMPUTED**: the
claim's structure is implemented as executable code over declared inputs; the code ran; the output matches the
stated verdict; mutants — genuine violations of the specification, planted against each instrument — were
rejected with printed witnesses. **CLASSIFIED**: the author's analytical classifications, entered as inputs
and printed by the script; the machine records them for inspection and replaces nothing. The E-series and
M-series are COMPUTED, the M-series as Stage P/C exhibits (§0.5.4): instruments running the standard machinery
on its own terms, whose sampling rules are the postulates under audit, adopted as exhibits and never claimed
as native derivations. The G-series and the firewall are document checks: their consistency content is
computed, the judgments they encode are CLASSIFIED. Listings are embedded in Appendix E at assembly; every
script carries the series' INPUT_PROVENANCE block.

### 8.1 E.1 — The census arrow, computed

**[COMPUTED]** E.1 enumerates the two-class census of Paper 12 §8 exactly, for population sizes n = 2..16, in
integer arithmetic: the assignment count of every record, the polarized records' share, the non-polarized
share, and the balanced record's own share.

Results. The non-polarized share satisfies the bound ≥ (n−1)/n at every n enumerated, with equality only at n
= 2 — the bound is met, never merely approached, and the single equality case is the smallest population in
the run. At n = 16 the non-polarized share is 32767/32768. The balanced record's own share, over the even
sizes, falls strictly at every step:

    n = 2, 4, 6, 8, 10, 12, 14, 16:
    1/2, 3/8, 5/16, 35/128, 63/256, 231/1024, 429/2048, 6435/32768

— concentration of the assignment count in the non-polarized records, with the balanced record's own share
falling throughout: the two facts Paper 12 §8 prints (L8.3-P12 and the honesty entry L8.4-P12; Appendix B),
recomputed here from enumeration, not from the closed forms.

Mutants, rejected with witnesses. (i) A mutant bound of the form 1 − 1/2^n for the non-polarized share returns
3/4 at n = 2 against the enumerated 1/2 — rejected at the smallest case in the run. (ii) A "balanced share
increases" mutant fails at its first comparison, 1/2 → 3/8. Both mutants are genuine specification violations
of the printed claims, not strawmen; each rejection prints the disagreeing case.

### 8.2 E.2 — The bounded census and the sign of the slope

**[COMPUTED]** E.2 enumerates the bounded two-class census of §5.3 — a population of N units, record indexed
by the count k in the upper class, assignment count Ω(k) = C(N, k) — and computes the successive ratio and the
slope sign exactly, for N = 4..24.

Results. The count's slope flips at k = N/2 for every N in the run: the successive ratio passes through 1
exactly at balance, the count rising strictly before it and falling strictly after it. At N = 24 the maximum
is Ω(12) = 2,704,156, and the first fall is from k = 12. The smallest table is printed entire: at N = 4, Ω =
[1, 4, 6, 4, 1]. For odd N the maximum is shared by an equal central pair, and the prose of §5.3 is required
to say so: at N = 5 the maximum count is 10, attained at both k = 2 and k = 3 — the instrument does not return
a unique maximum for odd N, and no sentence in this paper claims one. The exhibit's second panel is the
contrast case, and it prices the parameterization by comparison: a ladder census — 3 units over levels
0..cutoff, tallied over E = 0..12 — whose counts grow strictly from 1 to 91 (1, 3, 6, 10, …, 91), with no sign
flip anywhere in the checked range, and with the values unchanged when the cutoff is doubled from 24 to 48.
The unbounded ladder's count never turns; the bounded census's count turns exactly once, at its maximum. The
sign change the reciprocal reading narrates is therefore a property of boundedness — of the count's having a
maximum — and of nothing else in either table.

Mutant, rejected with witness. A monotone-count mutant — Ω non-decreasing across the whole bounded range — is
rejected at N = 4: Ω(2) = 6 > Ω(3) = 4. The falling side of the bounded count is not an interpretation; it is
in the smallest table the instrument prints.

### 8.3 E.3 — Two counting rules, one population

**[COMPUTED]** E.3 computes the mixing factors of §6.3 under the section's two counting rules, exactly, for
portions of N = 1..8 named bodies per side. Rule A counts arrangements of distinct individuals; Rule B counts
the same arrangements modulo permutation of individuals — the generic counting of §2.4, with its factorial
divisor.

Results. For identical gases, the Rule-A mixing factor is C(2N, N) > 1 at every N in the run; at N = 8 the
factor is 12870. The Rule-B mixing factor for identical gases is exactly 1 at every N in the run — not
approximately, and not in a limit. The ratio of the two rules' results equals, exactly, the factorial ratio
the rule switch introduces: for identical gases the (A/B) ratio is C(2N, N) itself (N = 8: 12870); for
distinct gases, where both rules count the mixing the same way, the (A/B) ratio is 1 exactly. The whole of the
small-N "mixing entropy" jump sits in the factorial ratio, with no remainder, confirming §6.3's dissolution at
census sizes.

Mutant, rejected with witness. A one-sided-correction mutant — the factorial divisor applied to one portion
only — is rejected at N = 1, returning a factor of 2 against the required 1.

**Disclosure, part of the result.** The finite slot census the instrument enumerates makes the Rule-B
identical-gas factor exactly 1. A counting framed instead in volumes — portions weighted by V^N rather than by
slots — reaches the factor 1 only in the Stirling limit, as N grows. The script checks the slot census; it
does not check the volume framing; and the paper's §6.3 claim is stated over the census the script checks. The
disclosure is printed here, with the result, because a verification record that hides which counting it
verified would commit the offence §6.3 exists to price.

### 8.4 E.4 — The ring, exhaustively

**[COMPUTED]** E.4 enumerates the ring model of §2.5 exactly: deterministic colour-flipping at marked sites,
no sampling anywhere in the instrument. The recurrence claim — every colouring returns to itself within 2N
steps — is verified exhaustively for N = 4..10, over all colourings crossed with all placements of the marked
sites: 1,398,016 cases, every one checked, no sampling, no exceptions.

The non-monotone witness of §7.2 is this instrument's exhibit and is cross-referenced there, not duplicated
here: N = 4, flipper mask 0001, colouring 0000, the black-count's distance from balance increasing from t = 2
to t = 3 (b: 2 → 3) inside the exactly recurrent census.

One further output is reported in the form this paper's honesty discipline requires. The balanced time-share —
the share of a trajectory's steps spent at the balanced record, minimised over the exhaustive case set — has
minimum 0, attained trivially: a monochromatic colouring with zero flippers never moves, and spends no time at
balance. The audit reports it as the trivial case it is: not a finding, and no sentence in §§7–8 leans on it.
E.4's load-bearing results are the exhaustive recurrence and the witness, and they are the only results of E.4
this paper cites.

The mutant is a persistence violation, and its shape is stated with care because an earlier, careless shape
would have proved nothing. Removing the flipper rule statically — declaring a placement with fewer flippers —
is just another placement, and it still recurs; such a mutant would be a strawman. The planted mutant instead
removes the flipper rule after the first lap: the dynamics runs under one rule for its first circuit and under
a different rule thereafter, violating the persistence of the dynamics the recurrence claim quantifies over.
Witness: N = 4, mask 0001, colouring 0000 — under the standard rule the trajectory returns to 0000 at t = 8;
under the mutant it returns 1111. Rejected, with the witness printed. §8 is where this correction lives: the
paper states, in its verification record, that only the persistence-violating mutant tests the claim, and says
why.

### 8.5 M.1 — The canonical recipe, run as an exhibit

**[COMPUTED — as Stage P/C exhibit]** M.1 runs the canonical recipe of §3.1 as the recipe prescribes it: a
sampler under the exponential acceptance rule, against targets the enumeration computes exactly. The
enumerated means of the exhibit's declared state list are:

    β = 0:   5 (exact — the census value, a rational count)
    β = 0.5: 3.775407
    β = 1:   2.689414
    β = 2:   1.192029

The sampler's agreement with its own recipe's targets is within tolerance at every setting: residuals on the
mean ≤ 0.0192 against a tolerance of 0.20; residuals on the state shares ≤ 0.0048 against a tolerance of
0.025. The recipe works, on its own terms, in this paper's own instrument — verified before it is audited, per
§1.2.

The control is the section's point. The identical sampler, line for line, with the acceptance weight set to 1
— the uniform-weight control — converges to the β = 0 census values at every nominal β (residuals ≤ 0.0135).
Nothing else in the code changes. The weight is a dial: one declared place in the machinery carries the whole
difference between the canonical targets and the census, exactly as §3.1's pricing table found one adopted
symbol carrying it in the equations. The sign-flipped mutant — the dial's exponent reversed — is rejected with
residuals 2.4479 / 4.6274 / 7.6113 across the audited settings, orders of magnitude outside tolerance. The
exhibit computes the recipe's behaviour; the classification of what that behaviour shows — adoption, not
derivation — is §3.1's, and is CLASSIFIED there, not computed here.

### 8.6 M.2 — The urn, run as an exhibit

**[COMPUTED — as Stage P/C exhibit]** M.2 runs the urn model of §2.5 as a sampler and checks it against the
exact census, in the same exhibit discipline as M.1. At population 20, the exact stationary shares are the
census shares C(20, k)/2^20 — the assignment counts of §8.1's census, normalised — with the extreme record's
share share(k = 0) = 1/1048576, and its mean recurrence time exactly 1048576 steps: the census's own numbers,
computed by enumeration, before any sampling is run.

The simulation ran 4,000,000 steps. Its stationary shares match the exact census shares with maximum absolute
deviation 0.000402, against a tolerance of 0.008. Visits to k = 0 were counted: 3, against an expectation of
3.81 under the exact share and the run length. The count is reported, not fitted: the share check is the
load-bearing verification — it is exact, it is pre-registered against the census, and it passed — and the
visit count is an existence check, printed because the run produced it. A biased-picker mutant, in which the
transfer step's choice is skewed, is rejected with a printed deviation of 0.089841 — more than two hundred
times the honest run's deviation, and eleven times the tolerance. The model drifts, fluctuates, and recurs, in
the instrument exactly as its builders described it in prose; the instrument adds the numbers, and the numbers
are the census's.

### 8.7 G.1, G.2, FW.1 — The document checks

**[CLASSIFIED inputs, machine-checked consistency]** Three instruments police this paper's own text, in the
§0.5.4 protocol. Their verdicts on the assembled paper are filled in at assembly, where the final tree exists
to be checked; the tokens below mark the three places, and the final-tree rule forbids printing a green
result for any other tree than the one built.

**G.1 — citation-pairing integrity.** The historical appendix's (year, author) pairings must equal the body's, in both
directions: no pairing in the appendix the body never makes, no listed pairing in the body the appendix
drops; every appendix row carries its year on its row's line; the falsification section and its opening
condition (C34) are present. Its checks are formal — the pairings, each row's year, and the falsification
surface's presence — never the rows' contents, which stand on the source
record. Since v3 the instrument carries a mutant battery — two clean synthetic mini-papers that must pass (one
pairing by the citation form, one by same-sentence proximity alone) and
eight planted violations (an appendix-only pairing, a body-only pairing, a yearless row, a missing opening
condition, the opening condition present only inside a longer label, a missing falsification heading, a row
naming no listed author, a proximity pairing the appendix does not carry) that the same check function must catch — and its run record lists every body year-mention that
produced no pairing, with context, for inspection: on this tree, 56 listed-year occurrences, 16 unpaired,
each a mention the pairing rule does not bind (a year spent without its author's name, or an author outside
the declared set), printed in the run record rather than silently passed. Result on the assembled paper: **PASS** — appendix pairings = body pairings = 21, the sets equal; 21 appendix rows, all carrying years; C34 and the falsification section present; battery green (G.1, run on this tree).

**G.2 — matrix completeness.** The §4 audit matrix must carry exactly its six required rows, each
fully filled. (§11's falsification completeness claim hangs on no script: it is the author's declaration,
with its mapping printed at the claim site for inspection — §11, L11.1-P12.5.) Result on the assembled paper: **PASS** — exactly six rows (Microcanonical, Canonical, Grand canonical, Ergodic, Coarse-graining, Gibbs), each with at least five non-empty cells (G.2, run on this tree).

**FW.1 — the own-voice firewall.** The machine-scanned subset of the §0.5.3 disciplines, over the paper's
full text: the two level word-forms, the neutrino ban (Paper 15), and the adopt-a-probability pattern, with
quotation-context exemptions *listed in the run record for inspection* (two lines on this tree, both
attributed paraphrase of Jaynes) rather than silently passed, and a mutant battery that must catch planted
violations before any zero-breach report is credited. Since v3 the neutrino exemption (the ban, Paper 15) is a whole-word
match (the word *ban* or an inflection of it, not hyphen-compounded): the v1/v2 substring test let an unrelated word containing
those letters — *abandoned* is the standing example — wash a line past the ban, and the battery now
plants exactly that case, and a hyphen-compound case beside it, as violators that must be caught. The
exemption remains line-scoped, as §0.5.3's catalogue states of its exemptions generally: a ban carried
anywhere on a line exempts that line, and the residual is stated here rather than hidden. Group B's ascription discipline and the rest of
Group A's vocabulary are not scanned by any code; they are policed by the author's classification and the
loop's human audit, which read the paper's sections entire and found the paper's own voice clean — the
certificate here is the scan's, and it covers what the scan covers. Result on the assembled paper:
**PASS** — 4,350 prose lines scanned, 0 hits, 2 exempted lines listed; the mutant battery green (5 planted
violators caught, 3 clean lines passed) (FW.1, run on this tree).

### 8.8 What the machines did not do

The record above is complete, and its boundary is stated here so it cannot be over-read. No script in this
suite derives an ontology. The E-series computes censuses — counts, shares, ratios, recurrences, exact over
declared finite inputs, mutants rejected on witnesses; the M-series computes the standard machinery's
behaviour under its own rules, as exhibits; the G-series and the firewall check this paper's consistency with
its own declarations. The audit's classifications — the verdicts of §§3–6 and Appendix D.1, the pricing of §7.1,
the premise inventory of §7.4, the reading of §2.8 — are the author's, entered as CLASSIFIED inputs where a script prints them, and nothing in this section
upgrades them: a classification the machine records is a classification the author made. Where the machines
compute, the paper's claims are exact. Where they classify, the paper says so. The suite's silence on ontology
is its honesty, and it matches the paper's thesis: counting is what machines, and censuses, do.

### §8 claims

- **L8.1-P12.5** — E.1's census outputs: non-polarized share ≥ (n−1)/n for n = 2..16 (equality only at n = 2);
n = 16 share 32767/32768; balanced share strictly falling over the even sizes as listed at §8.1. [LEVEL A:
MACHINE — E.1, mutants rejected as printed.] - **L8.2-P12.5** — E.2's bounded-census outputs: slope flip at k
= N/2 for N = 4..24; N = 24 maximum 2,704,156 at k = 12; odd-N maxima shared by the central pair. [LEVEL A:
MACHINE — E.2.] - **L8.3-P12.5** — E.3's two-rule outputs: Rule-A identical factor C(2N, N) (N = 8: 12870);
Rule-B identical factor exactly 1 on the slot census, with §8.3's volume-framing disclosure carried as part of
the claim. [LEVEL A: MACHINE — E.3.] - **L8.4-P12.5** — E.4's ring outputs: exact recurrence within 2N steps,
exhaustive over 1,398,016 cases (N = 4..10); the §7.2 non-monotone witness; the persistence mutant rejected as
printed at §8.4. [LEVEL A: MACHINE — E.4.] - **L8.5-P12.5** — M.1/M.2's exhibit outputs: the recipe converges
to its enumerated targets within the printed tolerances; the uniform-weight control converges to the census;
the urn's simulated shares match the exact census shares within the printed deviation. [LEVEL A: MACHINE — as
Stage P/C exhibits, §0.5.4; the recipe's postulate is the object exhibited, never a premise here.] - **L8.6-P12.5** — E.5's provenance outputs: the (9 up, 3 down) census operator diag(3/4, 1/4),
eigenvalues exactly 3/4 and 1/4; trace distance to the pure all-up ascription exactly 1/4; the (6, 6)
census, where the ascription and the census coincide exactly; the correlated census (6×00, 6×11) and the
|Φ+⟩ marginals identical at diag(1/2, 1/2); the von Neumann entropies evaluated in floats and disclosed
as Stage P instrument values, attaching to the ascriptions written down. [LEVEL A: MACHINE — E.5,
mutants rejected as printed at §8.9.] - **L8.7-P12.5** — E.6's updating outputs: the counted means of
both declared censuses exactly 4/7, computed from their counts; the factorisation 10r² + 3r − 4 =
(2r − 1)(5r + 4) verified coefficient-wise; the posterior (4/7, 2/7, 1/7) exact, summing to 1 and
meeting the constraint exactly; census B's ratios (5/7, 0, 2/7) differing from the posterior in every
class — each class checked separately by the instrument; all three mutants rejected as printed at §8.10. [LEVEL A: MACHINE — E.6.]

---

### 8.9 E.5 — The provenance exhibits, computed

**[COMPUTED]** E.5 computes the provenance exhibits of Appendix
D.1.4 over declared finite populations, in exact rational
arithmetic wherever the audited side permits it. A declared run
census of 12 preparations, measured in the up/down basis,
returns 9 up and 3 down; its census operator is diag(3/4, 1/4),
with eigenvalues exactly 3/4 and 1/4. Set against the pure
all-up ascription diag(1, 0), the trace distance — half the sum
of the absolute eigenvalues of the difference — is exactly 1/4:
the census operator and the pure ascription are different
operators at a computed distance, and substituting either for
the other is a detectable act, not a reading. The honest
mixture is the control: a census of 6 up and 6 down returns
diag(1/2, 1/2), and there the ascription and the census coincide
exactly — the instrument records agreement where agreement
holds, so its separations cannot be charged to the instrument.
The two-qubit case is the exhibit's point. A correlated
preparation census — 6 runs returning 00 and 6 runs returning
11, over 12 declared runs — has single-part marginals
(1/2, 1/2) on each part. The pure entangled ascription
|Φ+⟩ = (|00⟩ + |11⟩)/√2, computed exactly, has the same
marginals, (1/2, 1/2) on each part, and the marginal operators
are identical: diag(1/2, 1/2) in both provenances. Only one of
the two has a preparation census behind its marginal. In the
census case the marginal summarises counted outcomes of joint
preparation runs actually performed; in the |Φ+⟩ case the
marginal is obtained by partial trace of a joint ascription,
with no preparation population of the part at any step. The
joints differ — the census joint is diag(1/2, 0, 0, 1/2); the
|Φ+⟩ joint carries its off-diagonal terms — and the marginals
do not: what the subsystem ascription records is the marginal,
and what it does not record is which of the two provenances
produced it. Von Neumann entropies are evaluated for each
ascription in floating point — for the first exhibit's census
operator the value is 0.562335 nats, against the pure
ascription's 0 — and are disclosed, in the script and in this
record, as Stage P instrument values: the entropy
attaches to the ascription written down — the census operator,
the pure ascription, the marginal — and the float is the
instrument's reading of that ascription, never a count.

Mutants, rejected with witnesses. (i) An ascription-substitution
mutant — a checker that badges the pure ascription's entropy as
the (9, 3) population's entropy — is rejected on the computed
values: it reports 0.000000 nats where the census operator's
entropy is 0.562335 nats, an error of 0.562335 against the
exhibit's declared separation. (ii) A trace-violation mutant —
an operator of trace 5/4 offered as an ascription — is rejected
on its printed trace. (iii) A non-positive candidate —
[[1/2, 2], [2, 1/2]], trace 1, diagonal entries in [0, 1], but
determinant −15/4 (eigenvalue −3/2) — is rejected by the
instrument's exact positivity validation, which D.1.2's pricing
of ρ ≥ 0 requires and the first build's validation lacked (loop
repair). All three mutants are genuine violations of the
printed claims, not strawmen; each rejection prints the
disagreeing quantity. Two exhibits are controls, and are
labelled as such here so their weight is not overspent: exhibit
(2)'s coincidence is by construction (the honest ascription in
that exhibit *is* the census operator — the exhibit shows the
instrument records agreement where the ascription is honestly
taken from a census, and its separations elsewhere are not an
artefact of the instrument's construction), and exhibit (4)
reconstructs a diagonal in one basis from the same counts the
census tallies — the general tomographic inversion is the
literature's (D.1.3), not computed here.

### 8.10 E.6 — The updating exhibit, computed

**[COMPUTED]** E.6 computes the separation §3.4 prices, exactly, in
rational arithmetic. The record classes carry energies (0, 1, 2). A
declared census of 14 records — class counts (7, 6, 1) over the
three classes — has counted mean exactly 4/7, computed from the
counts. Neither declared census's ratios
coincide with the posterior in any class: the exhibit's first
build fed the rule a census carrying the posterior's own
ratios, under which a checker copying the census passed
undetected; the red team demonstrated the copycat, census A
was re-chosen, and the instrument now rejects the copycat as
mutant (c), on the printed ratios. The
maximum-entropy updating rule over the three classes, under that
single constraint, returns posterior ratios (4/7, 2/7, 1/7): the
weight multiplier r = 1/2 is verified exactly, from
10r² + 3r − 4 = (2r − 1)(5r + 4) — the factorisation verified
coefficient-wise (10, 8 − 5 = 3, −4) — the admissible root giving
weights (1, 1/2, 1/4), normalised by their sum 7/4. The exhibit's
second half is the separation itself, computed: a second declared
population, of 7 records with class counts (5, 0, 2) — census ratios
(5/7, 0, 2/7) — has the same counted mean, (0·5 + 1·0 + 2·2)/7 = 4/7,
and receives from the rule the same posterior (4/7, 2/7, 1/7), which
is not its census. The rule is not the census, computed. Mutant
(a), rejected with witness: a posterior-as-count checker, claiming the
posterior equals the census ratios of every population satisfying
the constraint, is rejected by the (5, 0, 2) witness — posterior
(4/7, 2/7, 1/7) against census (5/7, 0, 2/7), differing in every
class (the instrument asserts the difference class by class, for
both censuses). Mutant (b) — the wrong root r = −4/5, yielding
weights (1, −4/5, 16/25) — is rejected by the instrument's
non-negativity validation, with the weights printed. All three
mutants — (a), (b), and the copycat (c) rejected on the printed
ratios above — stand rejected with their witnesses.

### 8.11 G.3, G.4 — The document checks added in v2

**[CLASSIFIED inputs, machine-checked consistency]** Two further instruments police the v2 additions'
declared forms. **G.3 — premise-inventory completeness.** §7.4's inventory table must carry exactly its
six premises P1–P6, each with its price printed; the section's closing sentence — the joint's open
status — must stand in the section; and the inventory's two load-bearing toy facts are recomputed
independently at small size: the ring at N = 4, exhaustively (256 colouring-and-placement cases;
recurrence at or before 2N in every case; a non-monotone witness printed — colouring 0000, placement
0001, |D| running 4, 2, 0, 2, 4, 2, 0, 2, 4), and the urn's exact shares at N = 20 (unique maximum at
k = 10; each extreme share exactly 1/2²⁰). Result on the assembled paper: **PASS** (G.3, run on this tree). G.3 certifies the table's *form* — six rows,
price cells carrying the inventory's printed price vocabulary, the closing sentence present — and
recomputes the two toy facts; the inventory's completeness is claim L7.4.1, the author's, and no machine
content is claimed for it.

**G.4 — rewrite-pair form.** §1.3.6's table must carry exactly its six pairs; every A cell an exhibited,
quoted idiom; every B cell carrying its declared population and its declared window, free of the
firewall's banned tokens and of unpriced probability language. A mutant battery — pairs planted with a
missing window, a banned token, an unquoted A cell, probability language in a B cell, a B cell without
its population — must be caught before any pass is credited. Result
on the assembled paper: **PASS** (G.4, run on this tree). G.4 certifies the pairs' *form*; whether each
pair's two accounts say the same thing is the author's classification, printed in each pair's fourth
column, and is not machine content.

---

## 9 &nbsp; OBJECTIONS AND REPLIES

The critique anticipates its strongest counterarguments. Each objection is stated at full strength —
steelmanned, not strawmanned — then answered. The replies concede whatever the objection gets right, in the
open, before they answer it.

---

### 9.1 "The recipe works, so the ensemble is real"

**Objection.** The canonical recipe predicts mean energies, heat capacities, equations of state, and
fluctuation spectra to the accuracy its users claim, across a century of laboratory practice. A fiction does
not do that. Whatever the ensemble is made of — copies, weights, populations — it must be latching onto
something real, and the natural candidate is the thing the prose names: a population nature maintains,
distributed as the recipe weights it.

**Reply.** Predictive success latches onto the equations, not the gloss — the 11.5 §7.1 pattern, in this
paper's subject. Every successful prediction cited runs through the parts of the formalism the audit prices as
counting and declared adoption: a declared state list, energies evaluated on it, an adopted weight applied, a
sum performed. Remove the population from the prose and every number survives, unchanged — §8.5's instrument
demonstrates the point mechanically, converging to the canonical targets under a rule that names no population
at all. What has never been tested is the extra claim, because it adds no predictive content: the copies are
not counted in any prediction, and a prediction cannot confirm a component it never uses. Ptolemaic astronomy
predicted eclipses. The recipe's record is honoured throughout this paper — §1.2, §3.1's verdict block, §8.5 —
and it prices the recipe, not the inference from the recipe to the population.

### 9.2 "Nobody literally believes in copies"

**Objection.** Working physicists know the ensemble is a device. "The system is in the canonical ensemble" is
shorthand, understood as such by everyone who uses it, for a contact condition and a weighting rule. The
critique attacks a literalism nobody holds — a straw population.

**Reply.** Then the prose is the problem, and the objection concedes the audit's charge while disputing only
its address — the 11.5 §7.2 pattern. Three responses. First, the critiqued statements are the standard
pedagogy's own: the ensemble is introduced as a collection of systems, and the single system's properties are
derived from the collection's distribution (§4's matrix documents the idiom, with paraphrase marked as
paraphrase). A shorthand that appears in the textbooks' derivations is not private slang; it is the taught
ontology. Second, the shorthand does work the rule alone would not license: membership grammar ("in the
ensemble"), sampling grammar ("nature samples"), exploration grammar ("the system explores phase space") —
§1.3.5's cash-value list — appear in proposals and papers, budgeting real resources against the population the
shorthand supposedly never asserted. Third, the next generation learns the gloss as ontology, because the
gloss is what is printed. If the experts all know it is shorthand, the pedagogy should say so — the way the
founder said so (§2.4).

### 9.3 "Jaynes derived it"

**Objection.** Whatever the bath construction's status, the canonical weight has been derived — by maximising
the entropy functional subject to normalisation and a fixed mean energy. The exponential follows by calculus.
A derivation with a variational principle, a unique solution, and a multiplier identified with inverse
temperature is not an adoption, and §3.1's NO BADGE verdict ignores the strongest route.

**Reply.** §3.1 does not ignore it; §3.1 prices it first, at full strength, before the textbook presentation.
The derivation from its inputs is sound constrained optimisation, and the audit disputes none of it. The price
sits in the two inputs the derivation cannot pay for. The entropy functional enters as a premise — chosen, on
its author's own argument, for its consistency properties as a measure of uncertainty: an epistemic argument,
conducted in the reasoner's first person (§2.7). And the constraint mean is, in application, the measured or
imposed mean — a census quantity or a control setting — with the multiplier still tied to it: a multiplier in
search of a temperature, not a derivation of temperature from counting. Finally, the objection's own author
declines its conclusion: the programme's framing is explicitly epistemic, so the derivation, on its author's
terms, derives a rule of reasoning — and the population the objection wants it to deliver is the one thing its
author did not claim.

### 9.4 "The thermodynamic limit makes it exact"

**Objection.** Finite-N scruples miss the theory's actual setting. In the limit of many constituents the
ensembles become equivalent, the fluctuations vanish relative to the means, and the weighted sums become the
system's exact properties. The audit's census pedantry — exact at small N, where nothing thermodynamic happens
— audits a regime the theory never claimed.

**Reply.** A limit is a Stage P bridge, declared or not — and the objection, stated plainly, declares it,
which is already a concession: the exactness lives on the far side of a passage the prose usually omits. Price
the passage. The census statements this paper inherits and computes are finite and exact at every N
(§8.1–§8.3): they need no limit, because they claim ratios of counts, and a ratio of counts is what it is at N
= 4 and at N = 10^23 alike. The limit's work is different: it converts a weighted sum's agreement with a
census from a checked, finite comparison into an asymptotic identity — and in the conversion, the adoption the
weight represents is carried across the bridge and set down, on the far side, as exactness. What vanished in
the limit was not only the fluctuations; it was the weight's provenance. The audit's demand is the
declaration: state the bridge, name what it carries, and the limit is legitimate machinery. Undeclared, "the
limit makes it exact" is the inheritance's characteristic sentence — an adoption arriving, by passage, as a
theorem. (The limit formalism as mathematics is parked, as such, in App. D.2; what is audited is the prose that
spends it.)

### 9.5 "Your census is just the microcanonical ensemble renamed"

**Objection.** The strongest available, and it deserves its length. Strip the rhetoric and Paper 12's census
is the oldest ensemble in the subject: count the states in the shell, weight them equally, compute ratios. The
ledger has not abolished the ensemble; it has renamed the microcanonical one, kept its postulate — equal
weight — and indicted the canonical constructions for adoptions of exactly the same kind it performs itself.
If equal a priori probability is a confession when the textbook makes it, it is a confession when the ledger
makes it, and the audit's asymmetry is branding.

**Reply.** The objection is right about the kinship, and the paper concedes it before answering: §4's matrix
records the microcanonical row as the architecture at its most honest, precisely because its adoption is the thinnest. A concession first, so the asymmetry cannot be misread: the tally's equal weight is itself a rule, and this framework declares it as one — §6's ledger is built on counting rules being declarations, and the census's rule is not exempted from its own doctrine. What the tally rule does not do is assert anything beyond the tally: it is the arithmetic of counting the records in front of the counter, each once. Every other weight asserts more — a distribution over records not counted, or jurisdiction over a system's behaviour — and it is the assertion beyond the tally, not the choice of a rule, that the audit prices. The disagreement is over what the census adopts, and where. State the two steps separately, because the objection's force depends on merging
them.

Step one: to count records at all is to weight each counted record once in the tally. That is not a postulate
about nature; it is what a tally is. Paper 12's census rule (§3 there) defines its frequencies as ratios of
those tallies over a declared population and a declared window. The equal weight, in the census, never leaves
the counter's side of the page: it is the arithmetic of the count itself.

Step two — the standard construction's additional step — asserts jurisdiction: that the system's own
behaviour, over the window it actually lives, obeys the tally's weighting; that the equal weight is a law for
the system and not only the counter's arithmetic. That step is the adoption: the step §2.6's confession names,
the step §3.2's bridge must carry to connect any ensemble average to any measured census. The ledger does not
take it, because the ledger never leaves the tally: its frequencies are ratios over records the dynamics
actually produced, in windows it declares.

The asymmetry the objection charges is therefore real, and it is the opposite of branding. Where the standard
practice declares the step — as a postulate, confessed — the audit concedes the practice entirely: §2.6
honours the confession, and §4's microcanonical verdict is an adoption verdict, not a denial. The audit's
charge is confined to the un-declared weight step and to the possessed temperature: the places where the step
is taken in silence and its product is presented as derived, or as a property the system carries. Counting
itself is not charged, on either side. A renamed microcanonical ensemble would still contain the word's
referent — a population of copies, weighted, that the one system is said to inhabit. The census contains no
copies: its population is the declared set of actual bodies, its window is printed in its quantities' names
(D(P, W), §5.5), and its equal weight is the tally's arithmetic, asserted of nothing beyond the tally. The objection, at full strength, establishes that honest counting and honest ensemble practice converge at exactly one row of the matrix. The paper's thesis is about the other rows, and about the prose of all of them. One boundary of the concession is stated plainly: the census does not replace the recipe's *predictive* function — a canonical computation predicts a census nobody has yet taken, and the ledger, which reports counts, does not pretend otherwise. What the census replaces is the recipe's *ontology*: what the prediction is about. Provenance is not reach, and the audit claims the first, not the second.

### 9.6 "Negative temperature is settled physics"

**Objection.** The purified-spin experiments are seventy years old, the theory is textbook material, heat
flows from negative-temperature systems to all positive ones exactly as the formalism says, and the "paradox"
framing of §5.3 attacks a pedagogical flourish, not a result. Settled phenomena do not need a census
retelling.

**Reply.** The phenomenon, yes; the prose paradox, no — and §5.3's verdict is confined to exactly that split.
No number in the negative-temperature literature is disputed in this paper: the conditions are stated at §5.3
from the theory's own careful statement (internal equilibrium, essential isolation, bounded spectrum), and the
formalism is called internally consistent and experimentally sound. The record's own landmarks are §5.3's.

Purcell (1951) made the first realisation, the inverted spin population in LiF.
Ramsey (1956) gave it the systematic theory whose conditions §5.3 states.

What the audit prices is the narration built on top of the settled
phenomenon — temperature "jumping" from +∞ to −∞, a body "hotter than infinity" — which §5.3 shows to be a
property of the reciprocal parameterization at its own singularity, not of any count or any body: the bounded
census rises once and falls once, and nothing in it jumps. That the gloss is still load-bearing, and not a
dead flourish, is shown by the live dispute on the record: the objection of Dunkel and Hilbert (2014) holds that the negative temperatures are artefacts of the surface count. The surface count here is the Boltzmann count of §6's ledger. The reply of Abraham and Penrose (2017) defends the standard reading against it — a dispute that could not exist, in that form, if the community's prose had settled what its quantities are. This paper takes no side in that dispute: §5.3 maps it onto the paper's two counting rules and shows the verdict standing on both branches (App. D.2 records it, unadjudicated). It claims only that a paradox
manufactured by a coordinate is a finding about the coordinate, and that the census — which has no reciprocal
in it — was never confused.

### 9.7 "This is philosophy, not physics"

**Objection.** The audit offers no new prediction, no new cross-section, no new material. It offers readings —
of prose, of history, of what derivations "really" show. Conceptual hygiene of that kind may be valuable, but
its venue is the philosophy journal, and its verdicts are not physics results.

**Reply.** The 11.5 §7.6 pattern, in this paper's subject: the audit changes what a derivation must show, and
that is a physics criterion. The 9.5 standard (§0.5.3) is not a taste in exposition; it is a test of
provenance that derivations pass or fail — was the thermal quantity obtained without temperature, equilibrium,
or an ensemble distribution among its primitives? — and its verdicts are checkable against the formalism's own
equations, symbol by symbol (§3), in a matrix a reader can re-run by hand (§4), against numbers a machine
recomputes (§8). A criterion that sorts the field's central derivations into derived, declared, and
inherited-in-silence is doing the work Bell's criterion did for hidden variables: conceptual, yes, and with
consequences for what may be claimed, in print, as shown. Moreover this paper's falsification conditions (§11)
are physics conditions in their empirical route: exhibit the derivation, the system, the measurement the
conditions name, and the audit falls. What cannot overturn the audit is more prose — including the prose that
calls the audit philosophy. The founders of §2 were doing this work when they declared, priced, and confessed;
the discipline honoured them as physicists for it, and does not get to reclassify the same work when it is
done to the inheritance.

---

## 10 &nbsp; THE CONVERGENCE AUDIT

The preceding sections audited the classical architecture: its ensembles, its temperature, its entropy, its
arrow. This closing section turns to the field's most active current practice — stochastic thermodynamics —
and reports a different finding. Here the audit does not indict. It recognises. The living programme already
computes the way Paper 12 counts: its central results are statements about trajectory populations, its
simulations tally finite runs under declared rules, and its computed frequencies are tallies over declared repetitions — census ratios in substance. The probability language in which those results are stated is the inheritance's last
uniform. The convergence is the paper's closing evidence, offered as an invitation, not a verdict: the
practice has already arrived where the ledger stands; the ask is that the prose catch up.

### 10.1 The equalities are trajectory-population statements — and their computed content is a tally

Jarzynski (1997) proved the equality ⟨e^{−βW}⟩ = e^{−βΔF} (Phys. Rev. Lett. 78:2690–2693): the equilibrium
free-energy difference between two states is recovered from the exponentially weighted work values of
nonequilibrium trajectories run between them. State the result's own conditions, as its author states them:
the average is over an ensemble of trajectories — repetitions of the same protocol — and the repetitions are
initially sampled from equilibrium. Neither condition is a detail. Remove the repetitions and there is no
average; remove the equilibrium initial sampling and the equality's left side is not the quantity the right
side names. The equality is not a statement about any single trajectory, and its author does not present it as
one.

Crooks (1999) proved the stronger ratio relation (Phys. Rev. E 60:2721–2726): the work distribution of a
forward protocol against the work distribution of its time-reversed counterpart, their ratio fixed by the work
and the free-energy difference. Again the objects are two trajectory populations — a forward census and a
reverse census — and the theorem is a relation between their tallies. The equality of the previous paragraph
follows from the ratio as a corollary: the programme's results stand in a derivation order, and every step of
it quantifies over repetitions.

Read those statements with §3.3's four questions. What is counted: trajectories — actual runs of an actual
protocol, in the experiments that test these results by the thousands and in the simulations that use them by
the millions. What is postulated: the initial equilibrium sampling, carried here exactly as §3 prices it
wherever it appears — as the recipe's declared starting rule, legitimate where declared. What is measured: the
tallies themselves — work values, run by run, histogrammed. What the prose adds: the word "ensemble," worn now
by the repetitions, and the word "probability," worn by their ratios. But the computed content of those statements — what any experiment or simulation actually evaluates — is a ratio of counts over declared repetitions: a census ratio in Paper 12's sense (§1.3), whatever it is called. The repetitions are a declared population — of runs — and the protocol's duration is a declared window. The theorems themselves are expectation statements over an equilibrium-sampled trajectory ensemble, and §3 prices that sampling where it appears; their practice is census-shaped at every joint. Its vocabulary is the only part still living in §1.3's Account A.

### 10.2 Simulation practice: tallies called averages

The same convergence runs through the whole field's computational practice, at the scale §8.5–§8.6 exhibited
in miniature. A modern simulation executes a finite chain under a declared acceptance rule, discards a
declared transient, and tallies the records it kept: the reported "ensemble average" is that tally, over that
run, in that window. Nothing in the practice consults a population of copies; the copies would have nothing to
do if they existed. What the practice calls sampling an ensemble, its own methods sections describe —
accurately, read literally — as running a rule and counting outcomes. The audit's proposal is §1.3.5's
cash-value list and nothing more: name the rule, the run, and the window in the claim sentences as they are
already named in the methods sections, and the population disappears from the prose at no cost to a single
digit.

The modern counting-based practice has a named representative
the audit can cite without recruiting. Rau (2014), in *Physical
Review A* 90, 062114, justifies the Gibbs state itself from
tomographic data — the state an experimenter writes down is
defended there as the ascription consistent with counted data,
constructed, in the paper's own framing, without recourse to
infinite ensembles, environments, information, or dynamics,
and offered as a relevance hypothesis an experiment can test.
Rau (2017), in *Statistical Physics and Thermodynamics* (Oxford
University Press), builds the subject from the measurement side
outward: its third chapter constructs the state from the data it must
reproduce, its presentation treats entropy as a measure of the
observer's ignorance, and it carries the maximum-entropy
construction as a working tool — the surface the book's contents
and abstract support, which is the surface this paper cites.
The audit's claim about Rau is exactly the surface one and no
more: a working physicist of standing teaches and publishes
statistical mechanics in the ascription-from-counts form —
evidence for §10.1's thesis that practice computes census
quantities under other names. What Rau's own philosophical
commitments are, beyond what those texts print, this paper does
not assert; the convergence audit needs the practice, not the
man.

### 10.3 What the ledger adds

If the practice is already census-shaped, what — the invitation must answer — does the ledger's vocabulary
add? Three things, each a property of the prose, not of the numbers.

**Exactness.** A census ratio is an exact rational at every finite population and every finite window
(§8.1–§8.3): it does not approach its value as repetitions accumulate, it is its value, at N = 4 as at the
largest run performed. The probability idiom understates this: ratios printed as estimates of a distribution's
mean are, in the practice that produced them, exact tallies of the runs performed. The ledger's language
claims the exactness the tally already has.

**No measure.** Every frequency in the ledger is a ratio of counts; no sampling measure is postulated anywhere
in its formation (Paper 12 §5's dissolution; Appendix B). The convergence matter here is that stochastic
thermodynamics, read literally, is already in that position wherever it computes: its weights enter as
declared rules — a protocol, an acceptance rule, an initial sampling declared as step one of the method — and
its frequencies exit as tallies. The measure the prose posits between the rules and the tallies is the one
component no procedure exhibits.

**Declared windows.** In the ledger, every frequency carries its (population, window) index in its statement —
D(P, W) cannot be written without its arguments (§5.5). The convergence practice carries the same indices in
fact — this protocol, these repetitions, this duration — and drops them in the claim sentences, where "the
average work" floats free of the run census that produced it. Declaring the indices costs one clause per
claim. It buys immunity to the whole species of dispute — visible in §9.6's live controversy — in which two
tallies over different populations are spent as two readings of one possessed quantity.

### 10.4 Closing

The founders declared their devices. The ensemble entered physics inside a sentence that begins "We may
imagine" — and the imagining was the honesty: a collection assembled in thought, for the forming of averages.
The field's best current practice has, without announcement, returned to the founder's position: it computes
finite counts over declared repetitions under declared rules,
and its deepest results are relations between those counts. What has not returned is the declaration. The
prose still speaks of populations nature keeps and distributions systems obey, in the sentences that
introduce, motivate, and headline the work whose methods sections count.

This paper asks only that the prose catch up with the practice. It is the same ask its companion made one
level down: properties weren't intrinsic — no encounter, no value — and populations aren't ensembles: no
census, no average. Declare the population. Declare the window. Name the weight as the rule it is. The
numbers, every one of them, are already home.

---

## 11 &nbsp; FALSIFICATION

This section states the conditions under which this paper's verdicts fall. The series' numbering is
continuous: Paper 12's conditions ran **C23–C33**, and this paper's open at **C34**. Each condition
is stated in the form the series keeps: the claim at risk, the killer — the observation, derivation, or
exhibit that would fire it — and what the condition hangs on. A condition is stated so that it can, in
principle, be met; a condition nothing could meet would be decoration.

**The two-route discipline (inherited).** Paper 11.5's falsification section distinguishes two logical forms,
and this paper keeps the distinction explicit, because its conditions operate in both. *Route (i) — the
conceptual boundary:* some conditions name a determination whose very form the audit argues is unavailable — a
possessed quantity with no population and no window (C36 below, and C42 for the density operator). For those, the condition operates as a proof
by contradiction: it shows what test the audited claim would face, and the test's unavailability is itself the
finding; the paper's "falsifiable" language for such a condition refers to the contradiction's strict
conditional — exhibit the determination, and the thesis falls. *Route (ii) — the empirical and derivational
programme:* the remaining conditions name derivations, proofs, and exhibits that are straightforwardly open to
be produced — a derivation of the weight from counting (C34), a per-class ergodic proof (C35), a measured discontinuity (C37), a dynamics theorem (C38), an unrestatable trajectory result (C39), an entropy-identity derivation (C40), a counting-only arrow derivation (C41), a premise-escaping drift proof (C44). C43 is mixed — route (i) in its first killer, route (ii) in its second, as its text marks. For the route-(ii) conditions, the routes
are open in the ordinary sense, and the paper invites them in the ordinary sense. Conflating the two routes —
reading a route-(i) condition as a failed hypothesis test, or a route-(ii) condition as rhetoric — misstates
both, and the conditions below mark their route where it is not obvious.

**C34 — The weight derived from counting alone.** *Claim at risk:* §3.1's verdict — the derivation claim for
the canonical weight earns NO BADGE; the weight step is an adoption, and no route from counting alone reaches
the exponential form. *Killer:* a derivation of the canonical weight from census counts over actual records,
meeting the 9.5 standard of §0.5.3 — no temperature, equilibrium assumption, or ensemble distribution among
its primitives — exhibited in full, with its premises priced as §3.3 prices. A derivation carrying an adopted
functional, a constraint mean imported as a primitive, or a bath enumerated by no one does not fire this
condition; it re-prices §3.1's strongest-route analysis, which already covers it. *Hangs on:* §3.1's pricing;
the §0.5.3 standard; Paper 1's adoption criterion (Appendix B).

**C35 — An ergodic proof for a class.** *Claim at risk:* §3.2's verdict — the ergodic identity as a universal
bridge claim earns NO BADGE. *Killer:* for a named class of systems of physical interest, a proof — not an
existence theorem for time averages in general — that the canonical weight is the measure the class's
trajectories respect, so the identity holds for that class with the canonical weight in it. The condition is
stated per-class by design: firing it falsifies the universal verdict for that class, re-badges the identity
there at the proof's standing, and leaves the verdict standing where no proof has been exhibited. A proof for
one class is not a proof of the universal claim, and is not required to be. *Hangs on:* §3.2's pricing; the §4
matrix's ergodic row.

**C36 — Temperature with no population and no window.** *Claim at risk:* §5's thesis — temperature-like
quantities are (population, window)-indexed by construction, and the possessed scalar is an inference beyond
the procedural content that delivers it. *Killer:* a temperature determination with no population and no
window: a possessed scalar, measured on a single system at a single instant, by a procedure whose statement
involves no census over preparations, no interval of observation, and no contact history — returning the
textbook value. *Route (i) disclosure:* this condition operates in the proof-by-contradiction form. Every
determination the record contains cashes out, on inspection, to a census over a preparation population or an
interval (§5.4) — because a determination is a procedure, and procedures take time and instances. If that
analysis is right, the killer cannot be produced, and its unproducibility is the finding: the possessed scalar
is not an empirical claim but a grammatical one. If the analysis is wrong, the killer is the exhibit that
shows it, and this paper invites it in exactly that form. *Hangs on:* §5 entire; the §0.5.3 standard; D(P,
W)'s construction at home (Appendix B).

**C37 — A discontinuity at the identical-gas boundary.** *Claim at risk:* §6.3's dissolution — the mixing
discontinuity for identical gases is a counting-rule artifact, exactly the factorial ratio of the switch (E.3,
§8.3), with no remainder and no correlate in the gas. *Killer:* an exhibited physical discontinuity at the
identical-gas mixing boundary: a measured quantity that jumps when the counting rule changes — a quantity
defined and measured without reference to the rule, whose value nevertheless tracks the rule switch. A
quantity computed from the count itself does not fire this condition; the jump of ln Ω at the switch is the
dissolution's own prediction, not its refutation. What fires it is a jump in something the gas does, exhibited
independently of how the gas is counted. *Hangs on:* §6.3; E.3's exact outputs (L8.3-P12.5).

**C38 — A dynamics-to-Ω theorem on the standard side.** *Claim at risk:* §7.3's bibliographic claim — the
standard account has no theorem connecting its dynamics to Ω-drift for real systems, and its gap, unlike Paper
12's, is not in its index. *Killer:* a standard-account theorem connecting Hamiltonian dynamics to the drift
of assignment counts for a generic class of real systems — stated, proved, and resting on premises priced as
§3.3 prices. *Scope, stated plainly:* this condition targets the comparison, not Paper 12's joint. Paper 12's
open joint (§§8.6/9.6 there) stays open regardless of whether C38 fires: a theorem on the standard side would
falsify §7.3's comparative claim and leave the ledger's own gap exactly where Paper 12 printed it. The
condition is included so the comparison itself — this paper's credibility anchor — is as falsifiable as the
verdicts it frames. *Hangs on:* §7.3; the open joint's inheritance (Appendix B).

**C39 — A trajectory result that no census restates.** *Claim at risk:* §10's convergence claim — the computed content of stochastic thermodynamics' results is, in substance, census ratios over declared (population, window) pairs, stated in probability language. *Killer:* a trajectory-ensemble result in stochastic thermodynamics that provably
cannot be restated as a census ratio over a declared population and window — a result whose content
essentially requires the measure its prose posits, so that the census restatement loses content the original
carries. A result merely stated in probability language does not fire this condition; §10's claim is that the
language is a uniform over census-shaped content, and the killer must exhibit content the uniform is
load-bearing for. *Hangs on:* §10 entire; Paper 12 §5's dissolution (Appendix B).

**C40 — An entropy crossing derived as an identity.** *Claim at risk:* §6.1–§6.2's pricing of the crossings — the four entropy functionals are four counting rules under one name, their crossings analogies or imports, not identities of one physical quantity. *Killer:* a derivation that two of the four functionals compute the *same physical quantity on the same records* — not the same formula on different domains, but an identity of the quantities, exhibited on a declared population whose counts both sides tally. The Boltzmann ↔ Gibbs reduction at uniform weights is already recorded as the one honest crossing (§6.2) and does not fire this condition; the killer must derive a crossing §6.2 prices as undeclared — Gibbs ↔ Shannon as physical identity, or von Neumann ↔ Gibbs beyond formal analogy. *Hangs on:* §6.1–§6.2; §3.1's pricing of the functional (Jaynes; Shore–Johnson).

**C41 — The arrow from counting alone, in the standard account.** *Claim at risk:* §7.1–§7.2's pricing of the arrow's supports — that the standard arrow, as standardly told, rests on the ergodic bridge, an undeclared window, and an adopted initial condition. *Killer:* a standard-account derivation of the arrow for a generic class of real systems that (a) declares its window as part of the result, (b) adopts no initial condition beyond the dynamics and the counting, and (c) uses no ergodic bridge — the arrow obtained by counting alone, in the standard formalism's own terms. A derivation for one named system class does not fire it (those are inherited at their standing, §3.2); a derivation that declares its window and prices its initial condition does not fire it either — it *joins* the discipline this paper asks for, and §7.1's charge is against the undeclared forms. *Hangs on:* §7.1–§7.2; Paper 12 §8 (Appendix B).

**C42 — The density operator determined without a census.** *Claim at risk:* Appendix D.1's provenance
verdict (claims LD.1–LD.4) — that the density operator's weights, where they are knowable at all, are
knowable only through preparation populations and counted runs, and that the population-free reading is an
ascription the formalism's form does not record. This condition is route (i), like C36: it names a
determination whose form the audit argues is unavailable. *Killer:* an exhibited determination of ρ for a
single system at an instant — a measurement, or a derivation from the system's own stated properties — in
which the operator's weights are fixed without any preparation population, any repetition, and any
tomographic census over runs. *Hangs on:* Appendix D.1; exhibit E.5; Paper 12's census rule (Appendix B.1)
as the standard of what a count is. A derivation that takes a state ascription as primitive — a
Hamiltonian's ground state, a specified field's spin state — does not fire this condition: it derives
one ascription from another, and the audit's finding concerns the chain's end, not its links. The
killer's determination must consult no census *and* take no ascription as primitive, anywhere in its
provenance chain. D.1.5's overturn text is this condition's text; the two are one condition, stated once.

**C43 — The bridge measured, or the rule forced by counting alone.** *Claim at risk:* §3.4's priced bridge
(claims L3.4.1–L3.4.3) — that the canonical weight, read as an updating rule over ledger records, is a
Stage P bridge priced [LEVEL B] under the bridge rule, not a census result and not a native claim.
*Killer (route i):* a physical determination of the rule-space geometry on a single system — an exhibited
measurement whose outcome fixes which updating functional a system obeys, as a property of that system.
This killer is route (i), like C36's and C42's: it names a determination whose form the audit argues is
unavailable, and the unavailability is the finding. *Killer (route ii):* a derivation in which the
posterior's non-uniformity over a declared census is forced by census facts and stated symmetry
requirements alone — the updating functional itself derived, not adopted — exhibited in full.
*Hangs on:* §3.4; §3.1's pricing of the weight step.

**C44 — A drift proof on unlisted or violated premises.** *Claim at risk:* §7.4's premise inventory
(claims L7.4.1–L7.4.2) — that any record-level dynamics-to-drift theorem for ledger records, of the kind
§7.4 scopes, must supply premises P1–P6, each as listed and priced. *Killer:* an exhibited proof of that
kind that closes the joint while carrying a load-bearing premise of its drift step outside the inventory,
and stands. A proof supplying all six premises does not fire this
condition: it closes the joint, which is the outcome §7.4's programme exists to invite — the inventory's
claim is about the shape of any such proof, and a complete one confirms the shape by satisfying it.
*Hangs on:* §7.4; Paper 12 §§8.6/9.6, for the joint the proof would close.

**Completeness.** The conditions above are stated, in Paper 12 §12.1's style, as the complete falsification surface of this paper's audited verdicts: each audited verdict of §§3–7, §10, and Appendix D.1 is the named target of at least one condition, as named in each condition's own text — §3.1 by C34, §3.2 by C35, §5 by C36, §6.3 by C37, §7.3 by C38, §10 by C39, §6.1–§6.2 by C40, §7.1–§7.2 by C41, §3.4 by C43, §7.4 by C44, Appendix D.1 by C42 — and the §4 blanket denial stands behind C34 and C35 jointly, since a derivation of the weight or a per-class proof of its bridge would reopen the record §4 closed.

> **L11.1-P12.5 [LEVEL A: AUTHOR]** — Conditions C34–C44 are the complete
> falsification surface of Paper 12.5's audited verdicts: each audited verdict of §§3–7, §10, and
> Appendix D.1 is the named target of at least one condition, as named in each condition's own text,
> with the mapping printed in the paragraph above. *Falsifier:* an audited verdict of §§3–7 or §10,
> or of Appendix D.1, standing in the paper, for which no condition in C34–C44 is its named target —
> exhibitable by inspection of this section against §§3–10 and Appendix D. The claim is the author's declaration, checkable by
> that inspection; no script in this suite checks it, and the badge claims no machine content.
> (§2's historical verdict is policed separately: its year–author pairings, in the body and in Appendix A, by G.1's discipline — a discipline of pairings, not of contents, whose run record now lists every unpaired year-mention for inspection; the verdict's contents stand on the source record, as Appendix A's headnote states.)

What would change the verdicts is therefore on the record, condition by condition, in the two routes the
discipline keeps separate. What cannot meet any condition is more prose. Only derivations, proofs, and
exhibits count; the paper has stated, for each verdict, exactly which one it is waiting for.

---

## Appendix A &nbsp; HISTORICAL SOURCES

Consolidated record for §2. One row per work: the year, the author, the work as cited in this paper, and what
the work establishes here. The pairing discipline of instrument G.1 (§8.7) governs this table: each row pairs
its year and its author on the row's own line, and the set of (year, author) pairings in this appendix is the set of pairings
in the body — no pairing here the body never makes, and none dropped.
The rows' *contents* are the author's historical claims: they stand on
the source record (for the v2 additions, the verified history dossier),
not on G.1, whose checks are of pairings and presence, never of contents. Conservative citations throughout: where
the popular form of a claim needs a qualifier, the qualifier is the row's content, not a footnote to it.

| Year | Author | Work | What it establishes here |
|---|---|---|---|
| 1876 | Loschmidt | Wien 73:128–142 | The reversibility objection: velocity reversal yields a lawful H-increasing motion, so no exceptionless mechanical H-theorem is available. |
| 1877 | Boltzmann | Wien. Ber. 76:373–435 | Entropy proportional to the logarithm of the permutation count of a state; the exact S = k ln W form is a later inscription, not this memoir's text (§2.1). |
| 1890 | Poincaré | Prize memoir, Acta Math. 13 | The recurrence theorem: a measure-preserving system in finite volume returns arbitrarily close to its initial state, infinitely often. |
| 1896 | Zermelo | Ann. Phys. 57; 59 | The recurrence objection: recurrence is incompatible with a monotonic, purely mechanical derivation of entropy increase. |
| 1902 | Gibbs | Elementary Principles in Statistical Mechanics (Scribner's / Yale) | The ensembles as explicitly imagined collections ("We may imagine a great number of systems…"); canonical and grand canonical named; generic-phase counting at ch. XV; the subject's name itself dates to 1884. |
| 1907 | Ehrenfest | Phys. Z. 8:311–314 | The urn model of Paul and Tatiana, built to address both the reversibility and the recurrence objections in miniature, with drift, fluctuation, and certain recurrence in one finite mechanism. |
| 1911 | Ehrenfest | Encyklopädie der mathematischen Wissenschaften IV.32 (with Tatiana Ehrenfest-Afanassjewa) | The conceptual foundations audited in the founders' own genre: the ergodic hypothesis taken literally (a trajectory through every point of the energy surface), the weaker quasi-ergodic form proposed in its place and expressly denied sufficiency for trading time averages against phase averages, and the analysis conducted on finite, fully countable toy models (finite cell partitions; the four-velocity wind-tree). Bears on §2.5 and §7.4: the finite, countable toy is the Ehrenfests' own instrument, there as in the urn — recorded here as their practice, not named as their doctrine. |
| 1927 | Bridgman | The Logic of Modern Physics (Macmillan) | The operational doctrine stated: the concept of length is synonymous with the set of operations by which length is determined — the general form of the question this paper puts to the ensemble term. No ensemble critique is made in this book; the row records the doctrine's source, and the application to ensembles is the 1941 row's. Bears on §2.5. |
| 1927 | von Neumann | Gött. Nachr. 1927:245–272; 273–291 | The statistical operator introduced as the descriptor of an ensemble of systems (Gesamtheiten) not necessarily in the same state; the entropy of an ensemble of N such systems derived as S = −Nk Tr(U ln U). The quantum case enters this paper's audit (§2.7, App. D.1) with its population in the founding text. |
| 1932 | von Neumann | Mathematische Grundlagen der Quantenmechanik (Springer), ch. V §2 | The operator construction carried into book form: the mixed state is the case in which we do not know which state is actually present, only the weights w₁, w₂, … with which the several states enter — the weights an ascription, by the founder's own account of them. Bears on §2.7 and App. D.1. |
| 1938 | Tolman | The Principles of Statistical Mechanics (Clarendon) | Equal a priori probability stated as the theory's fundamental postulate, justified ultimately only by correspondence with empirical regularities (Dover p. 59, paraphrased at §2.6). |
| 1941 | Bridgman | The Nature of Thermodynamics (Harvard), ch. II | The operational doctrine turned on the ensemble itself: the chapter section "The ensemble and epistemology" argues that statistical treatment is superposed on a system by our paper-and-pencil procedures — that probability is a characteristic of our treatment of a system, not a fuzziness residing in it — and resists the epistemology that would make the ensemble the only proper object of physical knowledge, on the ground that experience consists of individual events, each with its own identity. The operationalist critique the inheritance did not answer. Bears on §2.5. |
| 1948 | Shannon | Bell Syst. Tech. J. 27 | H defined as a measure of choice and uncertainty for a source; identity of functional form with the statistical-mechanical H-form claimed, and no thermodynamic identity. |
| 1951 | Purcell | Phys. Rev. 81:279–280 (with Pound) | First realisation of a negative spin temperature, in LiF nuclear spins: a state "not cold, but very hot," under effective isolation from the lattice. |
| 1956 | Ramsey | Phys. Rev. 103:20–28 | The systematic theory of negative absolute temperature: internal equilibrium, essential isolation, bounded spectrum; negative temperatures hotter than all positive ones, the order running through ±∞. |
| 1957 | Jaynes | Phys. Rev. 106:620–630; 108:171–190 | Statistical mechanics reconstructed as inference in two papers: the MaxEnt assignment, framed as "maximally noncommittal with regard to missing information." |
| 1992 | Jaynes | "The Gibbs Paradox," in Maximum Entropy and Bayesian Methods (Kluwer), pp. 1–22 | The ally's position held to the end of his career: entropy attaches to the macroscopic description — to what it distinguishes and what operations can separate — and the mixing discontinuity is an artefact of reading entropy as a property of the microstate. The boundary between inference and ontology, kept in print a second time, thirty-five years after 1957. Bears on §2.7 and §6. |
| 1997 | Jarzynski | Phys. Rev. Lett. 78:2690–2693 | ⟨e^{−βW}⟩ = e^{−βΔF}: an equality over repetitions of a protocol, with equilibrium initial sampling; no single-trajectory statement. |
| 1999 | Crooks | Phys. Rev. E 60:2721–2726 | The ratio relation between forward and reverse trajectory populations; an ensemble-of-trajectories statement, from which the earlier equality follows. |
| 2014 | Rau | Phys. Rev. A 90:062114 | The Gibbs state justified from tomographic data: the ascription an experimenter writes down defended as consistent with counted data, constructed without recourse to infinite ensembles, environments, information, or dynamics, and offered as a relevance hypothesis an experiment can test. The state-ascription priced as an instrument's output, in a working journal, by a working physicist. Bears on §10.2. |
| 2017 | Rau | Statistical Physics and Thermodynamics (Oxford University Press) | The subject presented from the measurement side, on the evidence of its contents: the state constructed from the data it must reproduce (ch. 3, "Constructing the State"), entropy presented as a measure of the observer's ignorance, and the maximum-entropy construction carried as the working method. The convergence of §10 at textbook scale. Bears on §10.2. |

Two venue-and-form cautions are part of this record. The negative-temperature theory's venue is the journal
named in its row — a different venue circulates in the secondary literature and is wrong. And the Course
textbook line is used only in the conservative form given at §2.6, its predecessor and editions kept distinct.

---

## Appendix B &nbsp; INHERITED-CLAIMS MAP

Every claim this paper inherits at Level A carries its inheritance line here, under the rule of §0.5.6: the
subtype propagates, hybrids are split not averaged, and no inline cite inherits anything on its own.
Limitations inherit with the claims they limit — the open joint below is carried as open, at exactly its home
standing.

**B.1 — The census rule.** **Inheritance:** Source: Paper 12 §3 — badge carried at source: [LEVEL A] —
validation: Paper 12's §3 claim list and claim registry, where the census and its identities are recorded —
12.5 reliance: the positive account of §1.3 (Account B); the tally-arithmetic step of §9.5's reply; every
census ratio §§7–8 treat as the honest form of a frequency; §3.4's constraint-means pier (claim L3.4.2),
for which a counted mean over a declared population and window is a census ratio under this line.

**B.2 — The dissolution result.** **Inheritance:** Source: Paper 12 §5 — badge carried at source: [LEVEL A]
(claim L5.4-P12 there) — validation: Paper 12's §5 claim list and registry — 12.5 reliance: §5's dissolution
result is used, in that form and under that name, wherever this paper states that no sampling measure is
needed: §1.3, §4's microcanonical row, §10.3's "no measure" clause, and condition C39's hanging; and §3.4,
whose bridge is stated over census quantities precisely because no sampling measure is needed to state them.

**B.3 — Population temperature and the spine exhibits.** **Inheritance:** Source: Paper 12 §7 — badge carried
at source: [LEVEL A], with the one-body identification at its home hybrid grade [LEVEL A: MACHINE / PROOF /
AUTHOR] (claims L7.1–L7.3-P12 there) — validation: the spine exhibits there (Appendix F), recomputed from the
declarations alone by script A.15 — 12.5 reliance: D(P, W) = R/(|P|·|W|) ∈ ℚ as §5.5's counterpart quantity;
the (population, window) indexing §§9.5, 10.3 and C36 argue from; worked values D = 5/9, 61/18, 337/12 as
printed at §5.5.

**B.4 — The arrow counts.** **Inheritance:** Source: Paper 12 §8 — badge carried at source: [LEVEL A] (the
counting claims there, including the honesty entry L8.4-P12) — validation: Paper 12's §8 claim list and
registry; recomputed independently here by instrument E.1 (§8.1) — 12.5 reliance: the non-polarized share ≥
(n−1)/n and the balanced record's falling share, as §7's counting background and §8.1's verified outputs; the
arrow's assembly from its three badged ingredients is cited at home standing and not re-assembled here.

**B.5 — The equilibrium predicate.** **Inheritance:** Source: Paper 12 §9 — badge carried at source: [LEVEL A]
— validation: Paper 12's §9 claim list and registry — 12.5 reliance: equilibrium as a constructed property of
census records — stationary census plus Ω-maximality among all census records of the declared population —
wherever §§4, 7 contrast a constructed predicate with an assumed state; the predicate's clauses are used, not
re-proved.

**B.6 — The open joint, carried as open.** **Inheritance:** Source: Paper 12 §§8.6 and 9.6 — badge carried at
source: scope statements, with the joint's proof-target carried as a [LEVEL B] conjecture there — validation:
the scope subsections themselves, printed in Paper 12's own numbering — 12.5 reliance: §7.3's shared hole and
condition C38; and §7.4, whose whole programme is a reliance on
the joint's open status — the inventory prices what closing it
would cost, and its closing sentence performs the carrying. The limitation propagates under §0.5.6 rule 1: this paper points at the joint, compares
its disclosure with the standard account's, and rests no verdict on closing it.

**B.7 — The audit form and the Denied rule.** **Inheritance:** Source: Paper 11.5 — badge carried at source:
the audit form (prose beside equations; §2's historical-dissent form; §7's objections form; §6's two-route
falsification discipline) as method, and the Denied [Level A] rule of §0.5.1 there as an author-authorized
ruling of 2026-10-18 — validation: Paper 11.5 §0.5.1's text and the forms of its §§2, 6, 7 — 12.5 reliance:
this paper's §2, §9, and §11 forms; the Denied verdict of §4 (one of this paper's four Denied verdicts; the register stands at §0.5.1); the route disclosure of C36. The register's gating condition as printed inside §0.5.1's definition — registration only where a Level A positive account of the audited quantity stands in the series — is this paper's own articulation of its register discipline (v2, on its loop record), stated in the definition in full; it is not part of what this line carries from Paper 11.5.

**B.8 — The relational role theorem.** **Inheritance:** Source: Paper 11, via Paper 11.5 App. E.1 — badge
carried at source: [LEVEL A] — validation: the inheritance line at that entry, traced to Paper 11's registry —
12.5 reliance: the framework's standing result that roles are relational, never intrinsic, as the diptych's
lower panel (§§1, 10.4): properties weren't intrinsic; this paper's upper panel is built to its form.

**B.9 — The audit standard.** **Inheritance:** Source: Paper 9.5 — badge carried at source: the standard as
stated and applied there — validation: Paper 9.5's statement of the standard, received in Paper 12's
architecture and restated at §0.5.3 here — 12.5 reliance: the test every pricing in §§3–5 applies and
conditions C34–C36 hang on: a thermal variable counts as derived only if obtained without temperature,
equilibrium assumptions, or ensemble distributions as primitives.

**B.10 — The adoption criterion.** **Inheritance:** Source: Paper 1 — badge carried at source: the
adoption-then-derivation criterion as the series' founding discipline — validation: Paper 1's statement of the
criterion, applied at home throughout the series — 12.5 reliance: the pricing of every adoption this paper
names — the weight step (§3.1), the confessed postulate (§2.6), the Past Hypothesis (§7.1) — and the form of
condition C34's killer.

**B.11 — The quantum audit's basis.** **Inheritance:** the census
standard and the audit form only. Appendix D.1's audit prices ρ
against B.1's census rule — what a count is — and works in B.7's
audit form; to that extent the inherited Level A lines DO carry
into the quantum audit, as the standard and the form. What is
not inherited is any series result *about quantum systems*: no
paper of the series has yet priced the quantum formalism, so no
Level A line about ρ exists to carry in, and Appendix D.1's
verdicts rest on the formalism's own texts — the founder's
construction (1927/1932, App. A) and the standard tomography
literature — priced in place as classified source work, and on
exhibit E.5, whose computed content is this paper's own.
Consequence, printed at D.1.5: the quantum blanket thesis earns
NO BADGE and the author's verdict on it is [CLASSIFIED]; it is
not a Denied [Level A] register entry, the register's denials
standing where a Level A positive account of the audited
quantity exists in the series. The framework's positive
quantum-adjacent work is not this paper's to inherit or to
build: it belongs to the later papers that own those targets,
and D.1.5's fence says so.

---

## Appendix C &nbsp; FIGURE PLANS

Figures are presented here as plans, in the companion critique's established form: each plan states what is
plotted, from which verified source, and what the reader is to see in it. No figure is drawn for this draft;
the plans are the deliverable, and each is buildable from the named instrument's printed outputs alone.

**Fig. 1 — The weight dial (M.1, §8.5).** One panel: the exhibit state list's mean against nominal β, three
series on one axis set — the enumerated canonical targets (5, 3.775407, 2.689414, 1.192029), the
exponential-rule run tracking them within its residuals, and the uniform-weight control flat at the β = 0
census value across all nominal β. What the reader sees: one dial, two outcomes.

**Fig. 2 — The bounded count's two sides (E.2, §8.2).** Two stacked panels sharing the k axis at N = 24.
Upper: the count Ω(k) itself, rising to 2,704,156 at k = 12 and falling thereafter — one hump, no feature at
the peak but the peak. Lower: the reciprocal-slope reading of the same table, diverging at the peak and
changing sign across it. What the reader sees: the drama is in the lower panel only; the upper panel, which is
the census, contains no event at the place the lower panel diverges.

**Fig. 3 — Two counting rules, one population (E.3, §8.3).** Grouped bars at N = 1..8: the Rule-A
identical-gas mixing factor C(2N, N) rising to 12870, beside the Rule-B factor flat at exactly 1, with the
(A/B) ratio annotated as the factorial ratio of the switch. What the reader sees: the "paradox" as a staircase
in one rule and a flat line in the other, over the same populations — the difference located entirely in the
counting.

**Fig. 4 — Recurrence and the witness (E.4, §8.4).** The witness trajectory plotted entire: black-count b(t)
for N = 4, mask 0001, colouring 0000, t = 0..8, showing the step t = 2 → 3 rising away from balance (b: 2 → 3)
and the exact return to 0000 at t = 8, closing the circuit. An inset states the exhaustive frame: 1,398,016
cases, recurrence verified in all. What the reader sees: approach and return in one eight-step line, and the
non-monotone step marked where it occurs.

**Fig. 5 — The audit matrix (§4).** The matrix of §4.1 rendered as a plate: six rows, the counted / postulated
/ measured columns shaded by verdict, the prose-claim column set against the equation-content column with the
gaps between them left visible as white space. What the reader sees: the paper's finding as a shape —
provenance failures concentrated in two columns, counting honest in every row where counting occurs.

**Fig. 6 — Timeline (§2, App. A).** A single horizontal axis, 1876–2017, with the twenty-one appendix
entries placed at their years: objections and the counter-tradition in one register (1876, 1896, 1911,
1927, 1941), constructions in a second (1877, 1890, 1902, 1907, 1927, 1932), the confession and the
imports in a third (1938, 1948, 1951, 1956, 1957), the ally's restatement in a fourth (1992), and the
trajectory equalities and the modern counting demand closing the axis (1997, 1999, 2014, 2017). What the
reader sees: the pattern of §2.8 as a picture — declarations and pricings at the founding points, the
counter-tradition present at every era, and the long inheritance between them left blank.

**Fig. 7 — The premise inventory (§7.4).** §7.4's table rendered as a plate: six rows (P1–P6), the two
toy columns shaded by discharge mode — enumeration, declaration, exhibition, absence — and the price
column set in full. Beneath the plate, the section's closing sentence set as the plate's caption, so
that the programme and its open status are one picture: *The joint is open.* What the reader sees: a
research programme drawn as a parts list with prices, not a promise.

**Fig. 8 — The provenance pair (E.5, App. D.1).** Two panels over the same nine-and-three population.
Left: the census operator diag(3/4, 1/4) with its counted provenance printed beneath it — 12 systems,
9 up, 3 down — and its entropy, 0.562335 nats. Right: the pure ascription diag(1, 0), provenance line
blank, entropy 0. The trace distance between the panels, exactly 1/4, set between them as the plate's
only connecting mark. What the reader sees: the whole quantum audit in one comparison — an operator
with a census underneath it, and an operator without one.

---

## Appendix D &nbsp; THE QUANTUM CASE, THE PARKING LOT, AND REVISION HISTORY

### D.1 The quantum case: the density operator under the architecture

Sections 2–10 audit the classical ensemble idiom. This appendix
audits its quantum form, under the same standard (§0.5.3), by the
same method (§3's pricing, §6's ledger): the standard formalism's
equations placed beside the standard formalism's prose, and the
disagreement priced symbol by symbol. The audit is Stage C/P
throughout. It examines the quantum formalism's prose and its
laboratory procedures [L1]; it states no native quantum claim,
introduces no primitive, and disputes no number the formalism
returns — no eigenvalue, no trace, no entropy value, no expectation
value is in dispute here, exactly as no partition function value
was in dispute in §§2–10 (§1.2). What is in dispute is one gloss,
stated at D.1.1, priced at D.1.2–D.1.4, and returned at D.1.5.
Nothing in this appendix rests on closing Paper 12's open joint:
the joint is carried as open (Appendix B.6), here as everywhere in
this paper.

#### D.1.1 The same gloss, one level down

The classical gloss, as §§1–5 audit it, is a possession claim. "The
system is in the canonical ensemble" (§1.4) ascribes membership in
a population to one system; "the system has temperature T" (§5)
ascribes a possessed scalar to one body. The quantum gloss has the
same grammar, one level down. Its standard sentences run, in
substance: "the system is in the state ρ"; "the state of the
system is ρ"; "the system has entropy S(ρ)". The subject of each
sentence is a single system. The predicate is the density
operator, ρ, read as the actual physical state of that single
system — what the system *is*, settled by the ascription — and the
entropy functional read as a quantity the system thereby has.

The formalism's own content is granted in full, as it was in §3.1.
ρ is the formalism's state ascription: a positive operator of unit
trace, from which the expectation rule Tr(ρA) returns the
formalism's value for each observable A, and from which every
other quantity this appendix prices is computed. As machinery,
that is complete and exact, and the audit grants it without
reservation. The gloss is the further sentence the machinery does
not contain: that the ascription is the single system's own state,
a possession of the system, so that to write ρ down is to state
what the one system is. The population has been removed from the
sentence; the possession grammar has not. Where the classical
idiom promoted a weighting rule to a population the system
inhabits (§1.3), the quantum idiom promotes an ascription to a
state the system is — the same unearned promotion, performed on a
single operator instead of on a collection of copies, and
therefore harder to see: there are no copies left in the prose to
ask after. The census questions of §§3–4 are asked of it in the
same form. What was counted to obtain ρ? Over what declared
population, in what declared window? And where the answer is that
nothing was counted, what carries the possession claim?

#### D.1.2 ρ priced symbol-by-symbol

**(a) The ascription as stated.** In its standard compact form,
the quantum state ascription is three commitments:

    ρ ≥ 0,   Tr ρ = 1,   ⟨A⟩ = Tr(ρA)

Read as a procedure, the three say: write down an operator of the
stated kind; take its expectations by the trace rule. Two competent
users given the same ρ will compute the same ⟨A⟩ to the same
digit. The audit grants all of that. What the three commitments do
not say is where ρ came from, or what entitles the prose to call
it the single system's own state. Those are separate claims,
carried by separate parts of the notation, and they price very
differently — as in §3.1, priced as a block, the ascription would
borrow the honesty of its most honest symbol to cover its least
honest one.

**(b) Symbol-by-symbol pricing.**

| Symbol | What it is | How its value is obtained | Price under the 9.5 audit standard |
|--------|------------|---------------------------|------------------------------------|
| ρ (the density operator itself) | The formalism's complete state ascription: a positive operator of unit trace on the system's state space | By ascription: written down from a preparation specification under the formalism's rules for ascription, or reconstructed from run records (D.1.3) | **An ascription, not a count.** Legitimate as the formalism's bookkeeping object when it is declared as an ascription. The further gloss — that the ascription is the single system's own possessed state, settling what the system is — is not contained in the symbol and is priced at D.1.5. |
| Tr (the trace) | The basis-independent sum of an operator's diagonal entries; the device that turns operators into numbers (normalisation Tr ρ = 1; expectations Tr(ρA)) | By arithmetic on ρ exactly as written | **Innocent.** Tr introduces no new content. It is the ascription, summed. Like Z in §3.1's table, it is a normalising and evaluating device, and the audit prices devices by their inputs — ρ's input has been priced above. |
| ln ρ / the entropy functional S = −k_B Tr(ρ ln ρ) | The von Neumann functional of §6.1 (row 4): −k_B Σᵢ λᵢ ln λᵢ over ρ's eigenvalues λᵢ | By arithmetic on ρ's spectrum, once ρ is ascribed; computed in practice in floating point (instrument E.5, §8) | **A functional of the ascription.** It shares the Gibbs functional's shape and nothing else (§6.2): its value attaches to the ascription written down, not to a count taken of anything. Printed as the system's possessed entropy, it spends an ascription's arithmetic as a system's property — the promotion of D.1.1, at the functional. |
| The preparation claim ("procedure P prepares ρ") | The sentence linking a laboratory procedure to the operator: the claim that runs of P are runs to which ρ is ascribed | Cashed, where it is cashed at all, over runs: calibration records and reconstruction counts over a declared population of runs of P (D.1.3) | **Census-backed where the run population is declared; unbacked as a single-system claim.** No procedure returns ρ for one system at one instant (D.1.3). As a claim about a declared preparation census, it stands on counts. As a claim about what one system is, at an instant, it stands on nothing the procedure returns. |

Four symbols, three different prices — and the pattern is §3.1's
pattern. The arithmetic content (Tr, the functional) is honest
exactly as far as its input is honest. The input, ρ, is an
ascription. And the one sentence that connects the ascription to
the laboratory — the preparation claim — is cashed, in every case
D.1.3 examines, by counts over runs.

**(c) The founder's route, as sourced history.** The formalism's
founder introduced the statistical operator by the population
route. Von Neumann's 1927 Göttingen papers present the operator
— his U — as the descriptor of an ensemble of systems (his word
is *Gesamtheiten*) not necessarily in the same state: the
probabilistic construction introduces it for such an ensemble,
and the thermodynamics paper of the same year derives, for an
ensemble of N systems, the entropy S = −Nk Tr(U ln U). The 1932
book, *Mathematische Grundlagen der Quantenmechanik*, carries
the construction into systematic form (its ch. V, §2), where a
mixed state is precisely the case in which we do not know which
state is actually present, only the weights w₁, w₂, … with which
the several states enter the description. The pricing point
needs no wider claim than that record. At its definition site,
the formalism's central object enters as the descriptor of a
declared population of systems — a preparation census in all
but name. The population-free possession of D.1.1 is not the
founder's presentation; it is the inheritance's, and it was
acquired the way the classical inheritance acquired its realism
(§2): the declaration was dropped in transit, and the device was
handed down as a description.


#### D.1.3 Where ρ comes from in practice

Price the preparation claim by watching it be paid. In practice,
ρ reaches the page by exactly two routes, and both run through
counts over runs. A route that terminates in a further ascription
taken as primitive — a ground state read off a Hamiltonian, a spin
state read off a field specification — is not a third route but a
deferral: it derives one ascription from another, and it is priced
as a deferral at condition C42 (§11), which concerns the chain's
end, not its links; D.1.4 prices the same pattern where it
sharpens — the improper mixture, whose ascription is likewise
taken from a larger one.

*Preparation procedures.* A preparation is a declared recipe: a
source, its settings, its selections and filters. The recipe's
warrant for the sentence "this procedure prepares ρ" is its
calibration record — earlier runs of the same recipe, measured
and tallied, on the strength of which the ascription is carried
to later runs. The ascription's authority is therefore a census
authority: counts over a declared population of earlier runs,
under a declared procedure held fixed. A preparation that has
never been calibrated ascribes nothing; its ρ is a hope, and the
practice says so in its own vocabulary of characterisation runs
and verification runs.

*State tomography.* Where ρ is not carried from a calibration
but determined, it is reconstructed. The procedure is run many
times; at each of several measurement settings, the outcomes of
the individual runs are counted; the counts, as ratios over the
runs at each setting, are inverted — by linear inversion or by a
declared fit — to a single operator, written ρ̂, the
reconstructed ascription. Every entry of ρ̂ is a function of
count ratios over a declared run population. The practice's own
reporting keeps the population index visible: the reconstruction
is quoted with uncertainties, and the uncertainties shrink as
the run count grows, because what was measured was a finite
census and ρ̂ is its summary. The ascription wears census
clothing underneath — not as this paper's metaphor, but as the
procedure's own bookkeeping: remove the runs, and no entry of
ρ̂ has a value. The standard reference for the reconstruction
makes the counting explicit: James, Kwiat, Munro & White
(2001), "Measurement of qubits," reconstruct the density
matrix of a qubit pair — by linear inversion or by maximum
likelihood — from the measured counts accumulated under a
complete set of polarisation projections: frequencies over
an ensemble of identically prepared runs, never a reading
from a single system.

*The single system at an instant.* Against both routes, set the
gloss's requirement. A measurement performed on one system
returns one outcome — one record. No setting, and no combination
of settings applied to the one system at the one instant,
returns an operator: the operator's entries are fixed by ratios
that only a population of runs supplies. "The system's ρ, now"
is therefore never a reading taken off the system. It is an
ascription carried to the system from a preparation census (the
first route) or summarising a reconstruction census (the
second), and the carrying is exactly the step the gloss does
not print. The positive reading of this subsection — ρ, in
practice, is census-backed wherever it is backed at all — is
this paper's finding about the practice, stated generally, and
it stands at [LEVEL B] (claim LD.2). It is a finding about how
ascriptions are earned. What it does not cover is stated next,
because the next case is the one where it stops.

#### D.1.4 Pure and mixed; proper and improper

**(a) Purity is a property of the ascription.** An ascription is
called pure when Tr ρ² = 1 — ρ a rank-one projector, one
eigenvalue 1 and the rest 0 — and mixed when Tr ρ² < 1. The
quantity Tr ρ² is computed from ρ exactly as written: it is a
property of the ascription, in the strict sense that two
different writings of an ascription for the same runs can differ
in it only by differing as ascriptions, and no procedure counts
it off a single system. "The system is in a pure state," in the
gloss's grammar, ascribes the ascription's algebraic property to
the system as its condition. Priced as what it is — a
classification of ρ, printed at D.1.2's price for ρ — the
sentence is exact. Printed as a possession, it is D.1.1's
promotion at one symbol.

**(b) Proper mixtures: a census behind the ascription.** A mixed
ascription is called proper — the proper/improper terminology
is d'Espagnat's (1966; *Conceptual Foundations of Quantum
Mechanics*, 1971), used here as attributed terminology — when
it is built the way its form
suggests: ρ = Σₖ wₖ ρₖ, where a preparation device runs
preparation k on a share wₖ of its runs. Here the weights are
census ratios of a preparation population. The selection of k
on each run is an event in the laboratory; it can be recorded,
and where it is recorded the population behind the ascription
is an ordinary declared census, of exactly the kind Paper 12's
rule (§3, Appendix B.1) prices. For proper mixtures, D.1.3's
finding holds without strain: the ascription's provenance is a
preparation census, and the census reading dissolves the
mixture's mystery into bookkeeping — shares of runs, counted
or countable, under a declared procedure.

**(c) Improper mixtures: no census behind the ascription.** A
mixed ascription is called improper when it arises by the
partial trace: a joint ascription for an entangled whole is
written down, one part is traced over, and the remaining
operator is ascribed to the other part alone. No preparation
population of that part exists. No device ran preparations of
the part and selected among them; no selection event occurred;
there is no label census *of the part* of which the weights
could be the shares: the weights can be shares of a *joint*
census's marginals (E.5's correlated census is exactly that),
but no census of the part, by preparation of the part, exists
— and the part's operator, the only object the formalism
assigns to the part, has no place where one could be entered. The subsystem's ρ is obtained by
discarding part of an ascription for a larger system, and by
nothing else. This appendix states the consequence honestly,
because it is the case where the mismatch this audit prices
sharpens rather than dissolves: the census reading of D.1.3
does *not* reach the improper case, and this paper claims no
census underneath it. What the improper case has underneath it
is a larger ascription and a trace — D.1.2's innocent device,
applied to D.1.2's ascription, one level up.

**(d) The non-recording.** The audit's claim at this site is
exactly one claim, and it is priced to its width. ρ is
identical in form for the two provenances. A ρ obtained from a
preparation census (proper) and the same ρ obtained by partial
trace (improper) are the same operator: same eigenvalues, same
purity, same entropy functional, same expectations under the
trace rule — and the operator carries no entry, no flag, and
no remainder in which the difference of provenance is
recorded. The difference *is* recorded one level up, in the
joint ascription — which is an ascription of the whole; the
part's own operator records neither provenance, and it is the
part's operator that the possession gloss is about. Instrument E.5 (§8) computes the identity at the
marginals exactly, over declared finite populations: a
correlated preparation census and the entangled ascription
|Φ+⟩ return subsystem ascriptions identical in form, while
only one of the two has a preparation census behind it. The
computed content stands at [LEVEL A: MACHINE — E.5]; the
classification it supports — that the formalism's state
ascription records nothing of the provenance the gloss's
sentences presuppose — is this paper's audit finding, marked
[CLASSIFIED] (claim LD.3). Nothing stronger is claimed. In
particular, it is not claimed that the improper case is a
preparation census in disguise: it is not one, and the
gloss's defect is the sharper for it. The gloss reads both
provenances as one possession — "the subsystem's own state" —
because the form is one. The form is one because the notation
was built to keep the expectations and discard the provenance.
A notation that discards provenance cannot then be cited as
evidence that provenance does not matter to what the system
is; yet that citation, in substance, is what the possession
reading of the improper case performs.

#### D.1.5 Verdict and scope fence

**The verdict block.** The quantum form of the blanket thesis
of §1.4 is stated here in its own words and examined at the
same sites as the classical theses — priced symbol by symbol
(D.1.2), its provenance in practice traced (D.1.3), and the
formalism's recording tested (D.1.4):

> **The quantum blanket thesis** — *"ρ is the system's own
> state, a population-free possession that settles what the
> system is"* — **earns NO BADGE.** The author's verdict on
> the gloss is recorded here as **[CLASSIFIED]**: every route
> by which ρ's weights are earned runs through counts over
> declared run populations (D.1.3, [LEVEL B]); the formalism's
> own operator records no provenance for its weights (D.1.4;
> computed content [LEVEL A: MACHINE — E.5]); and the
> population-free possession adds, over the ascription the
> formalism actually supplies, a surplus no procedure
> returns. **The verdict is not a Denied [Level A], and the
> difference is stated, not smoothed.** The register's four
> denials (§0.5.1) stand where a Level A positive account of
> the same quantity exists in the series — Paper 12's census
> account, underneath the audited term. No paper of the
> series has yet priced the quantum formalism positively;
> there is no Level A account of ρ in the framework for a
> denial to stand on, and this paper's scope — audit only,
> no native quantum ontology — forbids building one here.
> A denial at the register's rigor is therefore not this
> appendix's to return. **The strongest opposing routes are
> named, not priced:** theorem-grade arguments that the
> quantum state must be ontic under stated assumptions (the
> ψ-ontology literature), and claimed single-system state
> determinations (protective measurement). Pricing them
> belongs to the papers that own the quantum targets; their
> existence on this record is part of why the verdict is a
> classification and not a denial. **What would overturn
> it:** the condition stated once, at C42 (§11) — a
> determination of ρ for a single system at an instant whose
> full provenance chain consults no census and takes no
> state ascription as primitive. Exhibited, it reopens the
> record; the register question reopens with it.

**What stands.** The verdict is on the gloss, and the positive
readings priced along the way keep their own badges and no
others. The preparation and tomography finding — ρ is earned,
where it is earned, from counts over declared run populations
(D.1.3) — stands at [LEVEL B] (claim LD.2): a general statement
about the practice, honestly weaker than the computed
identities beside it. The computed content of D.1.4 — the
exact identities and separations of instrument E.5 — stands at
[LEVEL A: MACHINE — E.5] for that content only (claim LD.3);
the classification residue of the same claim is [CLASSIFIED],
and the halves do not cover each other (§0.5.6, rule 2). The
pricing of D.1.2 is the author's classification, [CLASSIFIED]
(claim LD.1). No sentence of this appendix wears a machine
badge it did not earn (§0.5.5).

**The scope fence.** This appendix prices a gloss; it builds
no quantum ontology. It states nothing about what ρ is in the
ledger's native terms beyond what Papers 11 and 12 already
export at their home standing (Appendix B.1–B.10, and B.11's
entry for this audit): the census vocabulary
in which the audit's positive findings are phrased is inherited
at that standing, and nothing further is imported. No new
primitive is introduced. No standard number is disputed. Paper
12's open joint (§§8.6/9.6 there) is carried as open here
(Appendix B.6), and no verdict in this appendix rests on
closing it. The framework's positive quantum-adjacent work
belongs to the later papers that own their targets — Papers
13 and 15 own theirs — and nothing in this appendix pre-empts,
constrains, or supplies premises to them. The audit ends where
its standard ends: the standard formalism's prose said a
population-free possession; its procedures returned counts over
runs, and its notation recorded no provenance. That
disagreement, exhibited, is the appendix's whole result.

### Appendix D claims

- **LD.1-P12.5** — The density operator prices symbol by symbol
  as follows: ρ is an ascription, not a count; Tr is arithmetic
  on the ascription and introduces no content beyond it; the
  functional −k_B Tr(ρ ln ρ) is a functional of the ascription,
  sharing the Gibbs functional's shape over an unlike domain
  (§6.1, row 4); and the preparation claim linking a procedure
  to ρ is cashed, where it is cashed at all, by counts over a
  declared population of runs. [CLASSIFIED — author's pricing,
  §0.5.5; Appendix D.1.2. The historical component — the
  founder's definition route through preparation ensembles,
  1927/1932 — is classified source work in §2's sense, verified against
  the v2 history dossier.]
- **LD.2-P12.5** — In practice, ρ is earned by exactly two
  routes, both over runs: carried from a preparation
  procedure's calibration census, or reconstructed by state
  tomography from outcome counts over a declared population of
  runs, with the reconstruction's uncertainties shrinking as
  the run count grows. A route terminating in a further
  ascription taken as primitive is a deferral, not a third
  route (D.1.3; priced at C42). No procedure returns ρ for a single
  system at an instant; a measurement on one system returns
  one outcome record. [LEVEL B — practice record, stated
  generally; Appendix D.1.3.]
- **LD.3-P12.5** — ρ is identical in form for the proper and
  improper provenances and records nothing of which it has:
  a subsystem ascription obtained from a preparation census
  and the same ascription obtained by partial trace of an
  entangled whole share eigenvalues, purity, entropy
  functional, and expectations, and the operator carries no
  provenance entry. The identity is computed exactly at the
  marginals over declared finite populations (the correlated
  preparation census and the |Φ+⟩ ascription of instrument
  E.5). [LEVEL A: MACHINE — E.5, for the computed content
  only; the classification residue — that the state
  ascription records no provenance — is CLASSIFIED, author's
  finding, §0.5.5; Appendix D.1.4. No census underneath the
  improper case is claimed.]
- **LD.4-P12.5** — The quantum blanket thesis — "ρ is the
  system's own state, a population-free possession that
  settles what the system is" — **earns NO BADGE**; the
  author's verdict on the gloss is **[CLASSIFIED]**, recorded
  at Appendix D.1.5, and is expressly NOT a Denied [Level A]
  register entry, for the reason stated there (no Level A
  positive account of the quantum formalism exists in the
  series for a denial to stand on). The verdict is on the
  gloss only: no eigenvalue, trace, entropy value, or
  expectation value is denied, and no native quantum claim
  is made in its place. [Appendix D.1.5.]

### D.2 Parking lot

Items named here are outside this paper's audit by declared scope: nothing parked is endorsed, denied,
or priced by being listed.

- **Quantum statistical ensembles; the density-matrix gloss.** Opened and audited in Appendix D.1 of
this paper (opened in v2): the gloss priced symbol by symbol, its provenance in practice, the blindness its form
requires, and the author's classified verdict (D.1.5 — expressly not a Denied register entry). What remains parked is only what D.1.5's fence names: any positive
ledger account of quantum states, which belongs to the later papers that own the quantum targets. - **The thermodynamic-limit formalism as such.** Parked: priced as a bridge where its prose is spent
(§9.4), not audited as mathematics. The limit theorems are exact mathematics on their own domain; this paper
audits only the travel between that domain and finite systems' claims. - **The negative-temperature dispute.** Noted, not adjudicated (§9.6): Dunkel and Hilbert's Gibbs-entropy objection (2014) and Abraham and Penrose's published reply (2017) are on the record; the standard reading is what the textbooks teach, and §5.3 maps the dispute onto the paper's two counting rules and shows its verdict — the paradox is the parameterization — standing on both branches, so the verdict does not depend on the dispute's outcome. - **Paper 12's open joint.** NOT parked. It is carried as open (§§7.3,
App. B.6), fenced by C38's scope clause, and remains a live obligation of the framework, not a deferred topic
of this critique.

### D.3 Revision history

| Version | Date | Entry |
|---|---|---|
| v1 | 2026-11-07 | Initial full draft: §§1–11 and Appendices A–E assembled from the staged chunks; verification suite (E.1–E.4, M.1–M.2, G.1–G.2, FW.1) run on the final tree; adversarial loop pass run (devil's advocate, evil auditor, red-team) and its sustained charges repaired before the version is declared green: the Denied register corrected to the four verdicts the audit actually returned; §7.3 scoped exactly to its falsifier; the KAM statement corrected to near-integrable systems, with the hard-ball proof class named; the reservoir route and the Shore–Johnson strengthening priced in §3; the Dunkel–Hilbert dispute mapped at §5.3; the falsification surface completed by C40–C41; suite re-run green on the repaired final tree. |
| v2 | 2026-11-08 | The quantum case opened: Appendix D restructured — D.1 audits the density operator in full (the gloss; ρ priced symbol by symbol; provenance in practice, tomography and preparation; the proper/improper distinction; the verdict and its fence), the parking lot moved to D.2 with the quantum item replaced by a pointer, this history to D.3. The quantum blanket thesis is examined at the classical sites and returned NO BADGE with the author's verdict [CLASSIFIED] at D.1.5 (claim LD.4); it is not entered in the Denied register — the loop pass sustained the charge that a denial at the register's rigor requires a Level A positive account of the audited domain standing in the series, which the quantum case has not got, and the register stays at four. New matter: §1.3.6, a style guide for authors (six Account A → Account B rewrite pairs, exhibited and machine-swept); §3.4, the updating bridge (the canonical weight as an updating rule over ledger records, priced [LEVEL B] under the bridge rule, claims L3.4.1–L3.4.3); §7.4, the open-joint programme (premise inventory P1–P6 with the Kac ring and Ehrenfest urn as boundary exhibits, milestones MA–MC, claims L7.4.1–L7.4.2 — the joint stated open in the section's closing sentence); §2's lineage extended (Loschmidt and Zermelo as resisters, the Ehrenfests' 1911 audit, Bridgman's ensemble epistemology of 1941, Jaynes 1992, von Neumann's Gesamtheiten, the who-was-listening passage) and Appendix A extended from thirteen rows to twenty-one, every addition verified against the v2 history dossier — the Bridgman date corrected to 1941, the unverified attributions (Gemenge; Rau as ensemble critic) dropped rather than printed; §10.2 gains the modern counting practice (Rau 2014, 2017) at the surface the sources support. Falsification surface extended: C42 (the density operator), C43 (the bridge), C44 (the inventory). Suite extended: E.5 quantum census, E.6 updating (the MaxEnt bridge, computed exactly), G.3 premise inventory, G.4 rewrite pairs added — thirteen instruments under the RB.1 runner, fourteen listings in Appendix E, by the convention Appendix E's headnote states (v1: nine instruments, ten listings); G.1's declared pairings extended to the new record; suite re-run green on the final tree. Loop repairs after the adversarial pass are recorded in the build record, not itemised here. |
| v3 | 2026-11-08 | The Crucible author's list on v2, enacted entire, on the author's word — the corrections version. (1) §0.5.1: "five claims wear it" corrected to "four", matching the register the section itself prints (the v2 Crucible's Gate 3 catch). (2) L8.7: "both mutants" corrected to "all three mutants"; census B's "in every class" kept at full strength and now checked as printed — E.6 asserts census B's difference from the posterior class by class, as it already did for census A (the wording was checked against the code first, the code strengthened where it fell short, the wording narrowed nowhere); §8.10's mutants labelled (a), (b) to match the instrument, the copycat standing as (c). (3) D.1.3: one qualifying sentence — a route terminating in a further ascription taken as primitive is a deferral, priced at C42, not a third route (D.1.4's improper mixture standing as the priced member of the deferral class). (4) §0.5.1: the Denied register's gating condition (a Level A positive account of the audited quantity standing in the series) stated inside the definition itself, so the rule is self-contained. (5) §3.4: L3.4.3's limit repeated at the price-table row. (6) L11.1: the G.1 parenthetical scoped to pairings; G.1 itself strengthened — a built-in mutant battery (two clean mini-papers plus eight planted violations, run through the same check function) and run-record diagnostics listing every unpaired body year-mention with context (56 occurrences, 16 unpaired on this tree). (7) FW.1: the neutrino exemption (Paper 15) tightened from substring to whole-word matching, closing the "abandoned" wash; the battery plants that case and a hyphen-compound case as violators, and a ban-carrying line as a clean case. A slang and innuendo sweep of the paper's own prose was run on the author's instruction: no slang and no innuendo found; the hits adjudicated in the build record are the audited models' own vocabulary (the urn's balls, the ring's balls) and the paper's deliberate critical metaphors, kept as such. Suite: thirteen instruments under RB.1, fourteen listings in Appendix E, re-run green on the final tree; the v3 loop pass's adjudication is recorded in the build record. |

---

---

## Appendix E &nbsp; SCRIPT LISTINGS

The fourteen scripts of the §0.5.4 protocol, embedded in full. Each script is standalone (stdlib only) and carries its own INPUT_PROVENANCE block; the suite runs green on this final tree under RB.1 (see §8).

### E.1 Census arrow — `E1_census_arrow.py`

````python
#!/usr/bin/env python3
"""
E1_census_arrow.py -- Full census of binary records (Paper 12.5 / Paper 12 S8).

INPUT_PROVENANCE:
  - n range 2..16                                  [control] declared check range.
  - Binary record, entries up/down                 [paper-defined] Paper 12 S8
    binary-record census: a record of length n with k "up" entries is
    counted C(n,k) times; total records 2^n.
  - Polarized records = the two all-equal records  [paper-defined] Paper 12 S8.
  - Claim (a): non-polarized share >= (n-1)/n       [cited-paper] Paper 12 S8
    stated form, used ONLY as an oracle compared against the enumeration.
  - Claim (b): balanced share C(n,n/2)/2^n does NOT [cited-paper] Paper 12 S8
    grow (L8.4 honesty); used ONLY as an oracle.
  - No other inputs. No declared-assumption, no arbitrary-representative.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact rational census arithmetic for n = 2..16: counts by k (C(n,k)),
  polarized / non-polarized shares as Fractions, and the balanced share
  for even n, including its strict decrease over n = 2,4,...,16.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Any physical / dynamical reading of "arrow" (drift, approach, time
  evolution) is NOT checked here. This script verifies counting shares
  only; Paper 12 S8.6/9.6's open joint (no tau-monotonicity -> Omega-drift
  theorem) is untouched and remains open.
METHOD (input-equals-output ban): shares are COMPUTED from the enumerated
  counts C(n,k) summed by class; the claimed bounds/forms are compared
  afterwards as oracles. Mutants with wrong formulas are run through the
  same comparison and must be rejected with printed witnesses.
"""
import sys
from fractions import Fraction
from math import comb


def census_counts(n):
    """Enumerate the census by class: counts[k] = number of records with
    exactly k up entries. Computed by direct recurrence-free counting via
    math.comb per class AND cross-checked by an independent Pascal-row
    construction below (in main), so the class counts are not taken from
    a single source."""
    return [comb(n, k) for k in range(n + 1)]


def pascal_row(n):
    """Independent construction of the same row by repeated addition."""
    row = [1]
    for _ in range(n):
        row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
    return row


def main():
    failures = []

    print("E1 census arrow -- binary records, n = 2..16")
    balanced_seq = []  # (n, Fraction share)
    equality_cases = []

    for n in range(2, 17):
        counts = census_counts(n)
        # Independent cross-check of the enumeration itself.
        if counts != pascal_row(n):
            failures.append(f"n={n}: comb row != Pascal row: {counts}")
            continue
        total = sum(counts)
        if total != 2 ** n:
            failures.append(f"n={n}: total {total} != 2^n {2 ** n}")
            continue

        # (a) Polarized = records with k=0 or k=n: counts[0]+counts[n] = 1+1.
        polarized_count = counts[0] + counts[n]
        if polarized_count != 2:
            failures.append(f"n={n}: polarized count {polarized_count} != 2")
        polarized_share = Fraction(polarized_count, total)
        nonpol_share = Fraction(total - polarized_count, total)
        # Computed share must equal the closed form computed from counts.
        if polarized_share != Fraction(2, 2 ** n):
            failures.append(f"n={n}: polarized share {polarized_share} != 2/2^n")
        bound = Fraction(n - 1, n)
        if not (nonpol_share >= bound):
            failures.append(
                f"n={n}: non-polarized share {nonpol_share} < bound {bound}")
        if nonpol_share == bound:
            equality_cases.append(n)

        # (b) Balanced share for even n.
        if n % 2 == 0:
            balanced_share = Fraction(counts[n // 2], total)
            balanced_seq.append((n, balanced_share))

        print(f"  n={n:2d} total={total:6d} polarized_share={polarized_share} "
              f"nonpol_share={nonpol_share} (~{float(nonpol_share):.6f}) "
              f"bound_(n-1)/n={bound}")

    # Equality case for (a) must be exactly n=2 in this range.
    if equality_cases != [2]:
        failures.append(f"equality cases for (n-1)/n bound: {equality_cases}, expected [2]")

    # (b) Strict decrease of the balanced share over even n.
    print("  balanced share sequence (even n):")
    for n, s in balanced_seq:
        print(f"    n={n:2d} balanced_share={s} (~{float(s):.6f}) [float is translator only]")
    for (n1, s1), (n2, s2) in zip(balanced_seq, balanced_seq[1:]):
        if not (s2 < s1):
            failures.append(
                f"balanced share not strictly decreasing: n={n1} {s1} -> n={n2} {s2}")

    # ---- Mutant battery -------------------------------------------------
    print("  mutant battery:")
    # Mutant (i): non-polarized share = 1 - 1/2^n (only ONE polarized record).
    mutant_rejected = False
    for n in range(2, 17):
        counts = census_counts(n)
        total = sum(counts)
        true_share = Fraction(total - (counts[0] + counts[n]), total)
        mutant_share = 1 - Fraction(1, 2 ** n)
        if mutant_share != true_share:
            print(f"    MUTANT(i) REJECTED at n={n}: mutant share {mutant_share} "
                  f"vs enumerated {true_share}")
            mutant_rejected = True
            break
    if not mutant_rejected:
        failures.append("mutant (i) 1 - 1/2^n was NOT rejected")

    # Mutant (ii): claim that the balanced share INCREASES with n.
    mutant2_rejected = False
    for (n1, s1), (n2, s2) in zip(balanced_seq, balanced_seq[1:]):
        if s2 < s1:  # an increase claim fails at the first decrease
            print(f"    MUTANT(ii) REJECTED: 'balanced share increases' fails at "
                  f"n={n1}->{n2}: {s1} -> {s2} (decrease, witness pair)")
            mutant2_rejected = True
            break
    if not mutant2_rejected:
        failures.append("mutant (ii) increasing balanced share was NOT rejected")

    if failures:
        print("E1 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"E1 PASS: n=2..16 enumerated; non-polarized share >= (n-1)/n for all n, "
          f"equality only at n=2 (share 1/2); at n=16 nonpol_share={Fraction(2**16-2, 2**16)}; "
          f"balanced share strictly decreasing over even n: "
          + ", ".join(f"n={n}:{s}" for n, s in balanced_seq)
          + "; both mutants rejected with witnesses.")
    return 0


if __name__ == "__main__":
    sys.exit(main())```

### E.2 Negative-temperature census — `E2_negative_temperature.py`

````python
#!/usr/bin/env python3
"""
E2_negative_temperature.py -- Bounded-population census (Ramsey counting form).

INPUT_PROVENANCE:
  - N range 4..24                                  [control] declared check range.
  - Two-level units, energies 0 or eps             [paper-defined] bounded
    population census as used for the negative-temperature audit row.
  - eps = 1                                        [arbitrary-representative]
    Energies enter ONLY through the count k of excited units; no checked
    value depends on eps. It is named here so no reader mistakes it for
    a derived scale.
  - Omega(k) = C(N,k)                              [paper-defined] census count
    of records with exactly k excited units; computed from enumeration
    (Pascal cross-check), never assumed monotone.
  - Unbounded ladder: N_osc = 3 units, each on levels 0,1,2,...
                                                   [declared-assumption] the
    harmonic-type ladder is the standard contrast case; the counting is
    assignments of levels to 3 labeled units summing to total energy E.
  - Ladder cutoffs CUT1 = 24, CUT2 = 48 (levels 0..CUT per unit)
                                                   [control] declared truncations;
    checked energies E = 0..12 lie far below either cutoff and the two
    cutoffs must agree exactly (see DISCLOSURE below).
  - "Negative temperature" / "hotter than infinity" prose
                                                   [cited-paper] Ramsey-style
    gloss; NOT an input and NOT checked -- see outside-domain line.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact integer comparisons Omega(k+1) vs Omega(k) for the bounded census
  (the sign of the count slope, i.e. the sign of Delta ln Omega, decided
  WITHOUT logarithms because Omega > 0 and ln is monotone), and exact
  integer counts for the truncated unbounded ladder at two cutoffs.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Temperature itself (any Stage-P bridge assigning T, including negative
  T) is not computed or verified here. The census fact is only the sign
  flip of the count slope at k = N/2 in the bounded case and its absence
  (over the checked range, at two agreeing cutoffs) in the ladder case.
  "Hotter than infinity" is gloss over that sign flip; the script takes
  no position on the gloss.
TRUNCATION DISCLOSURE: the ladder is infinite in the native claim. This
  script verifies growth only for E = 0..12 with per-unit cutoffs 24 and
  48; agreement of the two cutoffs shows the checked counts are not
  cutoff artifacts for E <= 12 (any assignment summing to E <= 12 uses
  levels <= 12 < 24). No claim is machine-checked for E beyond 12.
METHOD (input-equals-output ban): Omega values are computed by two
  independent routes (comb and Pascal row); the slope pattern is read off
  the computed values and only then compared to the claimed pattern.
  Ladder counts are computed by explicit dynamic-programming enumeration
  over level assignments, not by the stars-and-bars closed form, which
  is used afterwards only as an oracle for E in range at CUT2.
"""
import sys
from fractions import Fraction
from math import comb


def pascal_row(n):
    row = [1]
    for _ in range(n):
        row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
    return row


def ladder_counts(n_units, e_max, cutoff):
    """Exact count of assignments (level_1,...,level_n_units), each level
    in 0..cutoff, summing to E, for E = 0..e_max. DP enumeration."""
    # dp[e] = number of assignments for the units processed so far.
    dp = [0] * (e_max + 1)
    dp[0] = 1
    for _ in range(n_units):
        ndp = [0] * (e_max + 1)
        for e in range(e_max + 1):
            if dp[e] == 0:
                continue
            for lev in range(0, min(cutoff, e_max - e) + 1):
                ndp[e + lev] += dp[e]
        dp = ndp
    return dp


def main():
    failures = []
    print("E2 negative temperature -- bounded census slope, N = 4..24")

    flip_witnesses = {}
    for N in range(4, 25):
        omega = [comb(N, k) for k in range(N + 1)]
        if omega != pascal_row(N):
            failures.append(f"N={N}: comb row != Pascal row")
            continue
        # Slope pattern read off the computed values.
        # inc: Omega(k+1) > Omega(k); dec: < ; eq: ==.
        first_fall = None
        for k in range(N):
            if omega[k + 1] < omega[k] and first_fall is None:
                first_fall = k  # Omega falls from k to k+1
            if N % 2 == 0:
                if k < N // 2 and not (omega[k + 1] > omega[k]):
                    failures.append(f"N={N} (even): Omega not strictly increasing at k={k}: "
                                    f"{omega[k]} -> {omega[k + 1]}")
                if k >= N // 2 and not (omega[k + 1] < omega[k]):
                    failures.append(f"N={N} (even): Omega not strictly decreasing at k={k}: "
                                    f"{omega[k]} -> {omega[k + 1]}")
            else:
                # Odd N: strict increase up to the central pair, central
                # pair EQUAL (Omega((N-1)/2) == Omega((N+1)/2)), then
                # strict decrease. This is the honest odd-N shape.
                mid_lo = (N - 1) // 2
                if k < mid_lo and not (omega[k + 1] > omega[k]):
                    failures.append(f"N={N} (odd): Omega not strictly increasing at k={k}")
                if k == mid_lo and not (omega[k + 1] == omega[k]):
                    failures.append(f"N={N} (odd): central pair not equal at k={k}: "
                                    f"{omega[k]} vs {omega[k + 1]}")
                if k > mid_lo and not (omega[k + 1] < omega[k]):
                    failures.append(f"N={N} (odd): Omega not strictly decreasing at k={k}")
        flip_witnesses[N] = first_fall
        peak = max(omega)
        print(f"  N={N:2d} Omega_max={peak} at k={[k for k in range(N+1) if omega[k]==peak]} "
              f"first_fall_from_k={first_fall} "
              f"(k>{Fraction(N, 2)} region: adding energy decreases the record count)")

    # ---- Unbounded ladder contrast --------------------------------------
    n_osc, e_max = 3, 12
    counts_c1 = ladder_counts(n_osc, e_max, 24)
    counts_c2 = ladder_counts(n_osc, e_max, 48)
    print(f"  ladder contrast: {n_osc} units, levels 0..cutoff, E=0..{e_max}")
    print(f"    counts @cutoff24: {counts_c1}")
    print(f"    counts @cutoff48: {counts_c2}")
    if counts_c1 != counts_c2:
        failures.append(f"ladder cutoffs disagree: {counts_c1} vs {counts_c2}")
    for E in range(e_max):
        if not (counts_c2[E + 1] > counts_c2[E]):
            failures.append(f"ladder count not strictly growing at E={E}: "
                            f"{counts_c2[E]} -> {counts_c2[E + 1]}")
    # Oracle cross-check (stars and bars), used only after enumeration:
    for E in range(e_max + 1):
        oracle = comb(E + n_osc - 1, n_osc - 1)
        if counts_c2[E] != oracle:
            failures.append(f"ladder E={E}: enumerated {counts_c2[E]} != stars-bars oracle {oracle}")
    print(f"    ladder count grows strictly over E=0..{e_max} "
          f"({counts_c2[0]} -> {counts_c2[e_max]}); no sign flip in checked range.")

    # ---- Mutant battery --------------------------------------------------
    print("  mutant battery:")
    mutant_rejected = False
    for N in range(4, 25):
        omega = [comb(N, k) for k in range(N + 1)]
        for k in range(N):
            if omega[k + 1] < omega[k]:
                print(f"    MUTANT REJECTED: 'Omega monotone increasing on the whole "
                      f"bounded range' fails at N={N}, first fall k={k}: "
                      f"Omega({k})={omega[k]} > Omega({k+1})={omega[k + 1]}")
                mutant_rejected = True
                break
        if mutant_rejected:
            break
    if not mutant_rejected:
        failures.append("mutant monotone-increasing Omega was NOT rejected")

    if failures:
        print("E2 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"E2 PASS: bounded census slope flips sign at k=N/2 for every N=4..24 "
          f"(even N: strict rise then strict fall; odd N: strict rise, equal central "
          f"pair, strict fall; e.g. N=24 Omega(12)={comb(24,12)}, first fall from k=12; "
          f"N=4 Omega={ [comb(4,k) for k in range(5)] }); ladder census (3 units) grows "
          f"strictly E=0..12 ({counts_c2[0]}->{counts_c2[e_max]}), cutoffs 24 and 48 agree "
          f"exactly; monotone mutant rejected with witness.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### E.3 Gibbs-paradox counting — `E3_gibbs_paradox.py`

````python
#!/usr/bin/env python3
"""
E3_gibbs_paradox.py -- Exact mixing counts under two counting RULES.

INPUT_PROVENANCE:
  - N range 1..8 per side                          [control] declared range.
  - Slot model                                     [declared-assumption] the
    counting arena, stated in full so the verdict's domain is exact:
    2N distinct slots, N in the left compartment and N in the right.
    A micro-assignment is a bijection from labeled units to slots.
    BEFORE: the partitioned preparation, counted as the product of the
    two compartment counts (each compartment's units assigned to that
    compartment's slots). AFTER: the combined system, all 2N units
    assigned to all 2N slots. Populations: DISTINCT = N units of type X
    (initially left) and N of type Y (initially right), with the BEFORE
    count restricting X to left slots and Y to right slots; IDENTICAL =
    2N units of one type, BEFORE counted by the same per-compartment
    product procedure (this procedural sameness is exactly what the
    paradox turns on).
  - RULE A (distinguishable units)                 [paper-defined] count every
    bijection of labeled units: a system of m labeled units in m slots
    counts m! assignments.
  - RULE B (the 1/N! rule)                         [paper-defined] divide a
    system's Rule-A count by the product, over each distinct TYPE present
    in that system, of (count of that type)! . Before mixing, each
    compartment is a system; after mixing, the combined population is
    one system (one type of 2N for IDENTICAL; two types of N for DISTINCT).
  - Bridge sentence S = k_B ln Omega               [cited-paper] Paper 12 S8.4,
    the single declared Stage-P bridge sentence. Used ONLY in the
    translator line at the end; NO verdict in this script depends on it.

WHAT THIS SCRIPT CHECKS (verified domain):
  Exact integer assignment counts and exact Fraction ratios in the slot
  model above, for N = 1..8: (a) Rule-A identical mixing factor > 1;
  Rule-B identical factor == 1 exactly; Rule-B distinct factor equals
  the Rule-A distinct factor corrected only by the rule factor;
  (b) (Rule-A factor)/(Rule-B factor) equals exactly the factorial ratio
  introduced by the rule switch, per population kind.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Entropy values, thermodynamic mixing claims, and any continuum/volume
  formulation of the Gibbs paradox are outside. In particular the exact
  factor==1 for identical populations under Rule B is a fact of THIS
  finite slot census with the per-type factorial rule as stated; in a
  V^N volume counting the same rule gives factor==1 only in the
  Stirling limit, which is a separate, un-checked statement. The script
  also does not adjudicate which rule is "correct" -- it shows exactly
  what the rule switch changes, in counts.
METHOD (input-equals-output ban): assignment counts are computed by
  explicit permutation enumeration for N = 1..3 (brute force over
  itertools.permutations) and by an incremental slot-filling count
  (product of successive free-slot numbers) for all N; the two routes
  must agree where both run, and factorial closed forms are used only
  as a third oracle. Factors are computed from the counts, then compared
  to the claimed values. A one-sided-correction mutant must fail.
"""
import sys
from fractions import Fraction
from itertools import permutations
from math import factorial


def count_by_filling(m):
    """Number of bijections of m labeled units to m distinct slots,
    computed incrementally: unit by unit, multiply by the number of
    still-free slots. Exact integer; no factorial call."""
    total = 1
    for free in range(m, 0, -1):
        total *= free
    return total


def count_by_bruteforce(m):
    """Brute-force enumeration of bijections via permutations of slots."""
    return sum(1 for _ in permutations(range(m)))


def rule_factor(species_counts, compartment_systems):
    """Product of factorials the 1/N! rule divides by. compartment_systems
    is a list of systems; each system is a list of per-type unit counts."""
    f = 1
    for system in compartment_systems:
        for c in system:
            f *= factorial(c)
    return f


def main():
    failures = []
    print("E3 Gibbs paradox -- exact mixing counts, N = 1..8 per side")

    # Brute-force validation of the filling count (independent route).
    for m in range(0, 7):  # covers systems up to 2N for N=1..3 after mixing
        b, f = count_by_bruteforce(m), count_by_filling(m)
        if b != f or f != factorial(m):
            failures.append(f"m={m}: brute {b} / filling {f} / factorial {factorial(m)} disagree")
    print("  brute-force permutation counts agree with filling counts for m=0..6")

    rows = {}
    for N in range(1, 9):
        # --- Rule A counts (from the filling enumeration) ---
        comp = count_by_filling(N)            # one compartment: N units, N slots
        before_A = comp * comp                # product of compartment counts
        after_A = count_by_filling(2 * N)     # combined: 2N units, 2N slots
        factor_A_distinct = Fraction(after_A, before_A)
        factor_A_identical = Fraction(after_A, before_A)  # same procedural counts

        # --- Rule factors (what the switch divides by) ---
        # BEFORE systems: [left: one type of N], [right: one type of N]
        rf_before = rule_factor(None, [[N], [N]])
        # AFTER identical: one system, one type of 2N. AFTER distinct: one
        # system, two types of N each.
        rf_after_ident = rule_factor(None, [[2 * N]])
        rf_after_dist = rule_factor(None, [[N, N]])

        # --- Rule B counts ---
        before_B = Fraction(before_A, rf_before)
        after_B_ident = Fraction(after_A, rf_after_ident)
        after_B_dist = Fraction(after_A, rf_after_dist)
        factor_B_ident = after_B_ident / before_B
        factor_B_dist = after_B_dist / before_B

        rows[N] = (factor_A_identical, factor_B_ident, factor_B_dist)

        # (a) checks
        if not (factor_A_identical > 1):
            failures.append(f"N={N}: Rule-A identical factor {factor_A_identical} not > 1")
        if factor_B_ident != 1:
            failures.append(f"N={N}: Rule-B identical factor {factor_B_ident} != 1")
        # Rule-B distinct = Rule-A distinct corrected ONLY by rule factor:
        corrected = factor_A_distinct * Fraction(rf_before, rf_after_dist)
        if factor_B_dist != corrected:
            failures.append(f"N={N}: Rule-B distinct factor {factor_B_dist} != "
                            f"rule-corrected Rule-A factor {corrected}")
        # (b) ratio of factors == factorial ratio introduced by the switch
        ratio_ident = factor_A_identical / factor_B_ident
        switch_ident = Fraction(rf_after_ident, rf_before)
        if ratio_ident != switch_ident:
            failures.append(f"N={N}: identical (A/B) factor ratio {ratio_ident} != "
                            f"switch factorial ratio {switch_ident}")
        ratio_dist = factor_A_distinct / factor_B_dist
        switch_dist = Fraction(rf_after_dist, rf_before)
        if ratio_dist != switch_dist:
            failures.append(f"N={N}: distinct (A/B) factor ratio {ratio_dist} != "
                            f"switch factorial ratio {switch_dist}")

        print(f"  N={N}: before_A={before_A} after_A={after_A} "
              f"factor_A(ident)=factor_A(dist)={factor_A_distinct} "
              f"factor_B(ident)={factor_B_ident} factor_B(dist)={factor_B_dist} "
              f"switch_ratio_ident={switch_ident} switch_ratio_dist={switch_dist}")

    # ---- Mutant battery ---------------------------------------------------
    print("  mutant battery:")
    mutant_rejected = False
    for N in range(1, 9):
        comp = count_by_filling(N)
        before_A = comp * comp
        after_A = count_by_filling(2 * N)
        before_B = Fraction(before_A, factorial(N) * factorial(N))  # = 1
        # MUTANT: after mixing identical populations, divide by N! only
        # (one side's factorial) instead of (2N)!.
        after_mut = Fraction(after_A, factorial(N))
        factor_mut = after_mut / before_B
        if factor_mut != 1:
            print(f"    MUTANT REJECTED at N={N}: one-sided 1/N! correction gives "
                  f"identical factor {factor_mut} != 1 (required); "
                  f"witness after_mut={after_mut}, before_B={before_B}")
            mutant_rejected = True
            break
    if not mutant_rejected:
        failures.append("one-sided-correction mutant was NOT rejected")

    # ---- Translator line (NOT part of any verdict) ------------------------
    # Paper 12 S8.4's single declared bridge sentence S = k_B ln Omega,
    # quoted here only to translate the N=8 Rule-A identical count ratio
    # into the prose's units. Float; disclosed Stage-P translator only.
    import math
    fa = rows[8][0]
    print(f"  TRANSLATOR ONLY (Stage P, Paper 12 S8.4 bridge S = k_B ln Omega; "
          f"no verdict depends on this line): at N=8, ln(factor_A_identical) "
          f"= ln({fa}) ~= {math.log(fa):.6f}, i.e. Delta S = k_B * that value "
          f"under the bridge sentence.")

    if failures:
        print("E3 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print("E3 PASS: for all N=1..8, Rule-A identical mixing factor = C(2N,N) > 1 "
          f"(N=8: {rows[8][0]}); Rule-B identical factor == 1 exactly for all N; "
          f"Rule-B distinct factor == Rule-A distinct factor (rule ratio 1 for distinct; "
          f"N=8: {rows[8][2]}); (A/B) ratio == switch factorial ratio exactly "
          f"(identical at N=8: {Fraction(factorial(16), factorial(8)*factorial(8))}); "
          "one-sided mutant rejected with witness.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### E.4 Kac ring, exhaustive — `E4_kac_ring.py`

````python
#!/usr/bin/env python3
"""
E4_kac_ring.py -- Kac ring, exact and exhaustive at small size.

INPUT_PROVENANCE:
  - N range 4..10                                  [control] declared range;
    exhaustive means ALL cases in this range (count printed, formula-checked).
  - Ring of N sites, balls black/white, F flippers on edges
                                                   [paper-defined] Kac-ring
    census/dynamics as stated in the task: each step every ball moves one
    site clockwise; crossing a flipper toggles its color.
  - Encoding                                       [declared-assumption] a
    representation choice, verified equivalent by a slow list-based
    simulator on N=4..6 (cross-check inside this script): colors are a
    bitmask v (bit i = color at site i, 1 = black); a step sends
    v -> rot1(v) XOR rot1(Fmask), where rot1 moves bit i to site i+1
    (mod N) and Fmask has bit i set iff a flipper sits on edge i->i+1.
    A ball arriving at site i+1 came across edge i, so the toggle mask
    is the flipper mask rotated with the balls.
  - Balanced count(s)                              [paper-defined] for even N,
    b = N/2; for odd N, b in {floor(N/2), ceil(N/2)} (the closest counts).

WHAT THIS SCRIPT CHECKS (verified domain):
  (a) EXACT RECURRENCE, exhaustively: for every N in 4..10, every initial
  coloring (2^N) and every flipper placement (2^N placements, F=0..N),
  the coloring after 2N steps equals the initial coloring.
  (b) NON-MONOTONICITY: at least one concrete witness where the distance
  |b(t) - N/2| (exact Fraction) INCREASES from t to t+1.
  (c) TIME-SHARE: per case, the exact share (Fraction) of the 2N states
  t=0..2N-1 sitting at a balanced count; the script reports the MINIMUM
  over all cases (per N and overall).
WHAT THIS SCRIPT DOES NOT ASSERT: any monotone drift, approach, or
  equilibration theorem. Recurrence and non-monotone excursions are both
  counting facts of the same exhaustive census; nothing here supports a
  drift reading, and the script asserts none.
WHAT STAYS OUTSIDE THE MACHINE CHECK (native domain):
  Larger N (checked only 4..10), stochastic/continuous Kac variants, and
  any thermodynamic reading of b(t).
MUTANT DISCLOSURE (honest limitation, stated in-script as required):
  A STATIC removal of the toggle on one edge is merely another flipper
  placement, which also recurs at 2N -- it cannot serve as a recurrence-
  breaking mutant, and this script says so rather than faking a witness.
  The mutant actually tested is the placement-persistence violation the
  instruction points at: the edge-0 flipper's rule is REMOVED after the
  first lap (it toggles during steps 1..N and is gone for steps
  N+1..2N). That dynamics must break recurrence, and a concrete witness
  is searched for exhaustively at N=4 and printed.
"""
import sys
from fractions import Fraction
from itertools import combinations
from math import comb


def rot1(v, N, mask_all):
    return ((v << 1) & mask_all) | (v >> (N - 1))


def slow_step(colors, flippers, N):
    """List-based reference step: colors[i] = color at site i; ball at
    site i moves to i+1, toggling iff flippers[i] (edge i->i+1)."""
    nxt = [None] * N
    for i in range(N):
        c = colors[i] ^ (1 if flippers[i] else 0)
        nxt[(i + 1) % N] = c
    return nxt


def main():
    failures = []
    print("E4 Kac ring -- exhaustive, N = 4..10")

    # --- Encoding cross-check: bitmask dynamics == slow simulator -------
    for N in range(4, 7):
        mask_all = (1 << N) - 1
        for v in range(1 << N):
            colors = [(v >> i) & 1 for i in range(N)]
            for fmask in range(1 << N):
                flippers = [bool((fmask >> i) & 1) for i in range(N)]
                slow = slow_step(colors, flippers, N)
                fast = rot1(v, N, mask_all) ^ rot1(fmask, N, mask_all)
                fast_colors = [(fast >> i) & 1 for i in range(N)]
                if slow != fast_colors:
                    failures.append(f"encoding mismatch N={N} v={v} fmask={fmask}")
    if failures:
        print("E4 FAIL (encoding cross-check):")
        for f in failures[:5]:
            print(f"  - {f}")
        return 1
    print("  encoding cross-check: bitmask step == list simulator for all "
          "colorings/placements, N=4..6")

    witness_b = None          # (N, fmask, v0, t, b_t, b_t1, dist_t, dist_t1)
    total_cases = 0
    global_min_share = None
    global_min_case = None

    for N in range(4, 11):
        mask_all = (1 << N) - 1
        period = 2 * N
        half = Fraction(N, 2)
        if N % 2 == 0:
            balanced = {N // 2}
        else:
            balanced = {N // 2, N // 2 + 1}
        cases_N = 0
        min_share_N = None
        # Enumerate flipper placements by F then by combination, so the
        # placement census is visibly C(N,F)-structured.
        placements = []
        for F in range(N + 1):
            for edges in combinations(range(N), F):
                fm = 0
                for e in edges:
                    fm |= (1 << e)
                placements.append(fm)
        if len(placements) != 2 ** N or len(set(placements)) != 2 ** N:
            failures.append(f"N={N}: placements {len(placements)} != 2^N")
        placement_count_check = sum(comb(N, F) for F in range(N + 1))
        if placement_count_check != len(placements):
            failures.append(f"N={N}: sum C(N,F) {placement_count_check} != placements")

        for fmask in placements:
            rf = rot1(fmask, N, mask_all)
            for v0 in range(1 << N):
                cases_N += 1
                v = v0
                balanced_steps = 0
                prev_dist = None
                b_prev = None
                # States t = 0..2N-1 for the share; run one extra step
                # bookkeeping inside the loop for (b), and finish at 2N
                # for recurrence.
                for t in range(period):
                    b = v.bit_count()
                    if b in balanced:
                        balanced_steps += 1
                    dist = abs(Fraction(b) - half)
                    if (witness_b is None and prev_dist is not None
                            and dist > prev_dist):
                        witness_b = (N, fmask, v0, t - 1, b_prev, b,
                                     prev_dist, dist)
                    prev_dist = dist
                    b_prev = b
                    v = rot1(v, N, mask_all) ^ rf
                # After the loop, v is the state at t = 2N.
                if v != v0:
                    failures.append(
                        f"recurrence failed: N={N} fmask={fmask:0{N}b} v0={v0:0{N}b} "
                        f"v(2N)={v:0{N}b}")
                    if len(failures) > 5:
                        break
                share = Fraction(balanced_steps, period)
                if min_share_N is None or share < min_share_N:
                    min_share_N = share
                if global_min_share is None or share < global_min_share:
                    global_min_share = share
                    global_min_case = (N, fmask, v0)
            if len(failures) > 5:
                break
        total_cases += cases_N
        expected = (2 ** N) * (2 ** N)
        if cases_N != expected:
            failures.append(f"N={N}: cases {cases_N} != 4^N {expected}")
        print(f"  N={N:2d} cases={cases_N} (=2^N colorings x 2^N placements, "
              f"sum_F C(N,F)={placement_count_check}) recurrence held for all; "
              f"min balanced time-share over cases = {min_share_N}")

    expected_total = sum(4 ** N for N in range(4, 11))
    if total_cases != expected_total:
        failures.append(f"total cases {total_cases} != {expected_total}")
    print(f"  TOTAL exhaustive cases checked: {total_cases} "
          f"(sum of 4^N for N=4..10 = {expected_total})")

    # (b) witness must exist and be re-verified independently.
    if witness_b is None:
        failures.append("no non-monotonicity witness found")
    else:
        N, fmask, v0, t, b_t, b_t1, d_t, d_t1 = witness_b
        # Independent re-simulation of just this case, list-based.
        colors = [(v0 >> i) & 1 for i in range(N)]
        flippers = [bool((fmask >> i) & 1) for i in range(N)]
        states = [colors]
        for _ in range(t + 1):
            states.append(slow_step(states[-1], flippers, N))
        rb_t = sum(states[t])
        rb_t1 = sum(states[t + 1])
        if (rb_t, rb_t1) != (b_t, b_t1) or not (d_t1 > d_t):
            failures.append(f"witness re-verification failed: {witness_b} vs {(rb_t, rb_t1)}")
        print(f"  (b) NON-MONOTONE WITNESS: N={N}, flipper_mask={fmask:0{N}b} "
              f"(edges {sorted(i for i in range(N) if (fmask>>i)&1)}), "
              f"initial coloring={v0:0{N}b}, at t={t}: b={b_t} |b-N/2|={d_t}; "
              f"at t={t+1}: b={b_t1} |b-N/2|={d_t1} -- distance INCREASED "
              f"(re-verified with the list simulator)")

    print(f"  (c) minimum balanced time-share over ALL cases: {global_min_share} "
          f"at case (N, fmask, v0)={global_min_case}; shares are exact Fractions "
          f"over the 2N states t=0..2N-1. No drift is asserted.")

    # --- Mutant battery ----------------------------------------------------
    print("  mutant battery:")
    print("    NOTE (honest): statically deleting one edge's toggle is just "
          "another placement and still recurs at 2N; the mutant tested is "
          "the persistence violation -- edge-0 flipper removed after lap 1.")
    mutant_witness = None
    N = 4
    mask_all = (1 << N) - 1
    for fmask in range(1 << N):
        if not (fmask & 1):
            continue  # mutant differs only if edge 0 actually has a flipper
        fmask_lap2 = fmask & ~1  # edge-0 flipper removed for the second lap
        rf1 = rot1(fmask, N, mask_all)
        rf2 = rot1(fmask_lap2, N, mask_all)
        for v0 in range(1 << N):
            v = v0
            for _ in range(N):
                v = rot1(v, N, mask_all) ^ rf1
            for _ in range(N):
                v = rot1(v, N, mask_all) ^ rf2
            if v != v0:
                mutant_witness = (N, fmask, v0, v)
                break
        if mutant_witness:
            break
    if mutant_witness is None:
        failures.append("mutant (edge-0 flipper removed after lap 1) did NOT break recurrence")
    else:
        Nw, fmw, v0w, vfw = mutant_witness
        print(f"    MUTANT REJECTED: N={Nw}, flipper_mask={fmw:0{Nw}b}, initial "
              f"coloring={v0w:0{Nw}b}: standard dynamics returns to {v0w:0{Nw}b} at "
              f"t=2N={2*Nw}, mutant returns {vfw:0{Nw}b} != initial -- recurrence broken")

    if failures:
        print("E4 FAIL:")
        for f in failures[:10]:
            print(f"  - {f}")
        return 1

    print(f"E4 PASS: recurrence at 2N verified exhaustively in {total_cases} cases "
          f"(N=4..10; per N: 4^N cases, N=10 alone 1048576); non-monotone witness "
          f"printed above and re-verified; minimum balanced time-share over all cases "
          f"= {global_min_share}; mutant (flipper persistence violation) rejected "
          f"with witness. No drift asserted.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### E.5 Quantum census — `E5_quantum_census.py`

````python
#!/usr/bin/env python3
"""
E5_quantum_census.py -- Stage P/C audit instrument for Paper 12.5
("The Ensemble Illusion"): the density operator read as a census
object, and what its form does and does not record.

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C audit instrument, in the same class as
  the M-series (M1/M2). It audits the STANDARD quantum-statistical
  machinery on its own terms. It is NEVER a native (Stage N)
  derivation, and NOTHING native is badged on this instrument: no
  printed line here is a claim about the ledger framework's own
  populations or ontology.

WHAT IS EXACT, WHAT IS FLOAT, AND WHY (disclosure, per section
0.5.4's M-series precedent):
  - EXACT (fractions.Fraction throughout): every density matrix,
    eigenvalue, marginal, and trace distance in this script. The
    declared populations are finite counts; their census operators
    have rational entries, and the partial trace over the 4-dim
    pair space is carried out entry-by-entry in rational arithmetic.
  - FLOAT (math.log, disclosed continuum content): the von Neumann
    entropy VALUES S(rho) = -Tr(rho ln rho) only. A logarithm of a
    rational eigenvalue is generically irrational, so no exact
    rational value exists to compute; the float entropy values are
    this exhibit's disclosed continuum content, exhibited as the
    standard machinery's own output, never as census arithmetic.
    Entropy comparisons therefore use a declared tolerance
    (TOL_ENT = 1e-9) and, for the headline gap, a wide margin
    (the computed gap exceeds 0.5 nats; the tolerance is not load-
    bearing for that verdict).

INPUT_PROVENANCE:
  paper-defined:
    - The census reading of rho: for a declared population of
      two-level systems with counted preparations, rho_census is
      the diagonal operator whose entries are the counted shares
      (Paper 12 census rule applied to the preparation record).
    - Exhibit (3)'s conclusion form: two preparations with the
      same marginals and different joint entropies show that rho's
      form does not record its provenance -- the audit point this
      instrument computes.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the census operators here are
      that rule applied to the declared preparation counts.
  control:
    - TOL_ENT = 1e-9 (float entropy agreement tolerance, declared
      here, before any run).
    - GAP_MARGIN = 1/2 nat (the exhibit (1) entropy gap must exceed
      this; declared here, before any run).
  declared-assumption:
    - Basis order for the pair space is (00, 01, 10, 11); marginals
      are taken over the second system. The checked equalities are
      basis-labelling facts of this declared order only.
  arbitrary-representative:
    - Population sizes 12 (single systems) and 12 (pairs), and the
      specific counts (9, 3), (6, 6), (6 x 00, 6 x 11): declared
      representatives chosen so every share is a small rational;
      the structural conclusions (entropy attaches to the
      ascription; form does not record provenance) do not depend
      on the particular counts.

Checks:
  (1) Faulty preparer: census vs pure ascription -- eigenvalues,
      trace distance exactly 1/4, entropy gap > 1/2 nat.
  (2) Honest mixture: ascription == census, distance 0, entropies
      agree within TOL_ENT.
  (3) Provenance pair: mixture vs pure entangled ascription --
      marginal matrices identical exactly; joint entropies differ
      (ln 2 vs 0, floats).
  (4) Tomography note: the Z-basis run counts (9, 3) reconstruct
      exactly the census diagonal of exhibit (1).
  Mutants: (a) ascription-substitution checker (badges the pure
  ascription's entropy as the population's) must be REJECTED on
  exhibit (1) with its error printed; (b) a trace-5/4 rho candidate
  must be rejected by this script's own validation.

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import math
import sys
from fractions import Fraction

TOL_ENT = 1e-9
GAP_MARGIN = Fraction(1, 2)  # nats; float-compared, see header


# ---------- exact rational matrix helpers (small, dense) ----------

def mat(rows):
    return [[Fraction(x) for x in row] for row in rows]


def trace(m):
    return sum(m[i][i] for i in range(len(m)))


def diag_eigs_diag(m):
    """Eigenvalues of a DIAGONAL exact matrix: its diagonal entries.
    Used only where the matrix is diagonal by construction; the
    caller asserts diagonality first (off_diag_zero)."""
    return [m[i][i] for i in range(len(m))]


def off_diag_zero(m):
    return all(m[i][j] == 0
               for i in range(len(m)) for j in range(len(m)) if i != j)


def is_psd_exact(m):
    """Exact positive-semidefiniteness test for a symmetric matrix
    of Fractions, by LDL^T decomposition: PSD iff every pivot is
    >= 0 and every zero pivot has a zero column beneath it.
    (Loop repair: validation previously checked trace and diagonal
    entries only, and admitted non-positive candidates such as
    [[1/2, 2], [2, 1/2]] -- eigenvalue -3/2. D.1.2 prices rho >= 0
    as a headline symbol; the instrument now validates it.)"""
    n = len(m)
    a = [[Fraction(m[i][j]) for j in range(n)] for i in range(n)]
    for k in range(n):
        piv = a[k][k]
        if piv < 0:
            return False
        if piv == 0:
            if any(a[i][k] != 0 for i in range(k + 1, n)):
                return False
            continue
        for i in range(k + 1, n):
            f = a[i][k] / piv
            for j in range(k, n):
                a[i][j] -= f * a[k][j]
    return True


def validate_rho(m, label, failures):
    """A density operator candidate: square, symmetric, trace
    exactly 1, diagonal entries (populations-in-basis) in [0, 1],
    and positive semidefinite (exact test). Returns True iff
    valid; on failure appends a witness and returns False."""
    n = len(m)
    if any(len(row) != n for row in m):
        failures.append(f"{label}: not square")
        return False
    for i in range(n):
        for j in range(n):
            if m[i][j] != m[j][i]:
                failures.append(f"{label}: not symmetric at ({i},{j})")
                return False
    tr = trace(m)
    if tr != 1:
        failures.append(f"{label}: trace {tr} != 1")
        return False
    for i in range(n):
        if not (0 <= m[i][i] <= 1):
            failures.append(f"{label}: diagonal entry {m[i][i]} outside [0,1]")
            return False
    if not is_psd_exact(m):
        failures.append(f"{label}: not positive semidefinite "
                        f"(exact LDL^T test failed)")
        return False
    return True


def trace_distance_diag(p, q):
    """Trace distance between two DIAGONAL operators, exactly:
    (1/2) * sum_i |p_ii - q_ii|. Callers assert diagonality."""
    return sum(abs(p[i][i] - q[i][i]) for i in range(len(p))) / 2


def von_neumann_entropy(eigs):
    """FLOAT -- disclosed continuum content (see header). Eigenvalues
    are exact Fractions; S = -sum lambda ln lambda (0 ln 0 := 0),
    computed in floats because ln of a rational is generically
    irrational. Nats."""
    s = 0.0
    for lam in eigs:
        x = float(lam)
        if x > 0.0:
            s -= x * math.log(x)
    return s


def partial_trace_second(rho4):
    """Exact partial trace over the second system of a 4x4 operator
    in basis (00, 01, 10, 11). (Tr_B rho)_{a,a'} = sum_b rho_{ab,a'b},
    all entries Fractions."""
    out = [[Fraction(0), Fraction(0)], [Fraction(0), Fraction(0)]]
    for a in range(2):
        for ap in range(2):
            out[a][ap] = sum(rho4[2 * a + b][2 * ap + b] for b in range(2))
    return out


def census_rho(counts):
    """Census operator from counted preparations: diagonal, entries
    = counted shares, computed from the counts (never asserted)."""
    total = sum(counts)
    return mat([[Fraction(counts[0], total) if i == j == 0 else
                 Fraction(counts[1], total) if i == j == 1 else 0
                 for j in range(2)] for i in range(2)])


def main():
    failures = []
    print("E5 quantum census -- Stage P/C audit instrument "
          "(exact Fractions; float entropies disclosed)")

    # ---- (1) Faulty preparer -------------------------------------
    # Declared population: 12 two-level systems, preparation counts
    # (9 up, 3 down). The preparer ASCRIBES the pure state "all up".
    counts1 = (9, 3)
    rho_census = census_rho(counts1)
    rho_ascribed = mat([[1, 0], [0, 0]])
    if not validate_rho(rho_census, "exhibit(1) census rho", failures):
        pass  # failure already recorded; continue to print what we can
    validate_rho(rho_ascribed, "exhibit(1) ascribed rho", failures)
    if not off_diag_zero(rho_census) or not off_diag_zero(rho_ascribed):
        failures.append("exhibit(1): an operator is not diagonal")
    eigs_census = diag_eigs_diag(rho_census)
    eigs_ascribed = diag_eigs_diag(rho_ascribed)
    print(f"  (1) faulty preparer: counts={counts1} of 12; "
          f"census eigenvalues={eigs_census} (computed shares "
          f"{counts1[0]}/12, {counts1[1]}/12); ascribed pure "
          f"eigenvalues={eigs_ascribed}")
    if eigs_census != [Fraction(3, 4), Fraction(1, 4)]:
        failures.append(f"exhibit(1): census eigenvalues {eigs_census} "
                        f"!= (3/4, 1/4)")
    if eigs_ascribed != [Fraction(1), Fraction(0)]:
        failures.append(f"exhibit(1): ascribed eigenvalues {eigs_ascribed} "
                        f"!= (1, 0)")
    td1 = trace_distance_diag(rho_census, rho_ascribed)
    print(f"      trace distance census<->ascription = {td1} (exact)")
    if td1 != Fraction(1, 4):
        failures.append(f"exhibit(1): trace distance {td1} != 1/4")
    s_census = von_neumann_entropy(eigs_census)      # FLOAT, disclosed
    s_ascribed = von_neumann_entropy(eigs_ascribed)  # FLOAT, disclosed
    gap = s_census - s_ascribed
    print(f"      S(census rho) = {s_census:.6f} nats (float); "
          f"S(ascription) = {s_ascribed:.6f} nats (float); "
          f"gap = {gap:.6f} > {float(GAP_MARGIN)} required")
    if not (gap > float(GAP_MARGIN)):
        failures.append(f"exhibit(1): entropy gap {gap} does not exceed "
                        f"{float(GAP_MARGIN)} nats")
    print("      Reading: the entropy number attaches to the "
          "ASCRIPTION placed on the population, not to the counted "
          "population itself: same bench, same 12 systems, two "
          "numbers differing by more than half a nat.")

    # ---- (2) Honest mixture ---------------------------------------
    counts2 = (6, 6)
    rho_census2 = census_rho(counts2)
    rho_ascribed2 = census_rho(counts2)  # the honest ascription IS the census
    validate_rho(rho_census2, "exhibit(2) census rho", failures)
    eigs2 = diag_eigs_diag(rho_census2)
    td2 = trace_distance_diag(rho_census2, rho_ascribed2)
    s2_census = von_neumann_entropy(eigs2)
    s2_ascribed = von_neumann_entropy(diag_eigs_diag(rho_ascribed2))
    print(f"  (2) honest mixture: counts={counts2} of 12; census "
          f"eigenvalues={eigs2}; ascription == census; trace "
          f"distance = {td2} (exact); S(census)={s2_census:.6f}, "
          f"S(ascription)={s2_ascribed:.6f} (floats), "
          f"|diff|={abs(s2_census - s2_ascribed):.3e} <= tol {TOL_ENT}")
    if eigs2 != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(2): census eigenvalues {eigs2} != (1/2, 1/2)")
    if rho_ascribed2 != rho_census2 or td2 != 0:
        failures.append("exhibit(2): ascription != census or distance != 0")
    if abs(s2_census - s2_ascribed) > TOL_ENT:
        failures.append("exhibit(2): entropies disagree beyond tolerance")

    # ---- (3) Provenance pair --------------------------------------
    # Preparation census of 12 pairs: counts (6 x 00, 6 x 11).
    # Joint census operator in basis (00, 01, 10, 11), computed from
    # the counts.
    pair_counts = {(0, 0): 6, (1, 1): 6}
    total_pairs = sum(pair_counts.values())
    joint_mix = [[Fraction(0)] * 4 for _ in range(4)]
    for (a, b), c in pair_counts.items():
        joint_mix[2 * a + b][2 * a + b] = Fraction(c, total_pairs)
    validate_rho(joint_mix, "exhibit(3) mixture joint rho", failures)
    if not off_diag_zero(joint_mix):
        failures.append("exhibit(3): mixture joint rho is not diagonal")
    joint_eigs_mix = sorted(diag_eigs_diag(joint_mix), reverse=True)
    support_eigs = [e for e in joint_eigs_mix if e != 0]
    marg_mix = partial_trace_second(joint_mix)
    # Pure entangled ascription |Phi+> = (|00> + |11>)/sqrt(2):
    # |Phi+><Phi+| has entries 1/2 at the four corners (00/11 block),
    # 0 elsewhere -- exact Fractions, since amplitudes squared and
    # cross terms are (1/sqrt2)(1/sqrt2) = 1/2.
    joint_pure = [[Fraction(0)] * 4 for _ in range(4)]
    for i in (0, 3):
        for j in (0, 3):
            joint_pure[i][j] = Fraction(1, 2)
    validate_rho(joint_pure, "exhibit(3) pure joint rho", failures)
    marg_pure = partial_trace_second(joint_pure)
    print(f"  (3) provenance pair: 12 pairs, counts (6 x 00, 6 x 11); "
          f"mixture joint eigenvalues on support = {support_eigs}; "
          f"marginal (mixture) = {marg_mix}; "
          f"marginal (|Phi+>) = {marg_pure}")
    if support_eigs != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(3): mixture support eigenvalues "
                        f"{support_eigs} != [1/2, 1/2]")
    marg_eigs = diag_eigs_diag(marg_mix) if off_diag_zero(marg_mix) else None
    if marg_eigs != [Fraction(1, 2), Fraction(1, 2)]:
        failures.append(f"exhibit(3): mixture marginal eigenvalues "
                        f"{marg_eigs} != (1/2, 1/2)")
    if marg_mix != marg_pure:
        failures.append(f"exhibit(3): marginals differ: mixture "
                        f"{marg_mix} vs pure {marg_pure}")
    # Joint entropies (FLOATS, disclosed): the pure operator is pure
    # by construction -- its spectrum is computed from its exact
    # trace and its exact purity Tr(rho^2) = 1 (a pure operator's
    # spectrum is (1, 0, 0, 0)); the mixture's spectrum is its
    # diagonal.
    purity = sum(joint_pure[i][j] * joint_pure[j][i]
                 for i in range(4) for j in range(4))
    if purity != 1 or trace(joint_pure) != 1:
        failures.append(f"exhibit(3): pure candidate purity {purity} "
                        f"/ trace {trace(joint_pure)} -- not pure")
    s_joint_mix = von_neumann_entropy(joint_eigs_mix)
    s_joint_pure = von_neumann_entropy([Fraction(1), Fraction(0),
                                        Fraction(0), Fraction(0)])
    print(f"      joint S(mixture) = {s_joint_mix:.6f} nats (float; "
          f"ln 2 = {math.log(2):.6f}); joint S(|Phi+>) = "
          f"{s_joint_pure:.6f} nats (float); marginals identical "
          f"exactly, joint entropies differ by "
          f"{s_joint_mix - s_joint_pure:.6f}")
    if abs(s_joint_mix - math.log(2)) > TOL_ENT:
        failures.append("exhibit(3): mixture joint entropy != ln 2 "
                        "within tolerance")
    if abs(s_joint_pure) > TOL_ENT:
        failures.append("exhibit(3): pure joint entropy != 0 within "
                        "tolerance")
    if not (s_joint_mix - s_joint_pure > float(GAP_MARGIN)):
        failures.append("exhibit(3): joint entropy difference does "
                        "not exceed the declared margin")
    print("      Conclusion (the exhibit's): the marginal rho's form "
          "is identical for the counted mixture and the pure "
          "ascription -- rho's form does not record its provenance.")

    # ---- (4) Tomography note --------------------------------------
    # From the declared Z-basis run counts -- the (9, 3) census of
    # exhibit (1) itself -- the reconstructed diagonal is the counted
    # shares. One line: no new machinery.
    recon = [Fraction(counts1[0], sum(counts1)),
             Fraction(counts1[1], sum(counts1))]
    census_diag = [rho_census[i][i] for i in range(2)]
    print(f"  (4) tomography note: Z-basis counts {counts1} reconstruct "
          f"diagonal {recon}; census diagonal {census_diag}; "
          f"equal exactly: {recon == census_diag}")
    if recon != census_diag:
        failures.append("exhibit(4): reconstructed diagonal != census "
                        "diagonal")

    # ---- Mutant battery -------------------------------------------
    print("  mutant battery:")
    # (a) Ascription-substitution mutant: a checker that badges the
    # claimed pure ascription's entropy as the population's entropy.
    # Run against exhibit (1): its reported value is S(ascription);
    # the population's census entropy differs by the gap.
    mutant_reported = s_ascribed
    mutant_error = abs(mutant_reported - s_census)
    if mutant_error > float(GAP_MARGIN):
        print(f"    MUTANT(a) REJECTED: ascription-substitution badges "
              f"S = {mutant_reported:.6f} nats as the population's "
              f"entropy; the census entropy is {s_census:.6f} nats; "
              f"error {mutant_error:.6f} > margin "
              f"{float(GAP_MARGIN)} (witness: exhibit (1), counts "
              f"{counts1})")
    else:
        failures.append("mutant (a) ascription-substitution was NOT "
                        "rejected")
    # (b) Trace mutant: a rho candidate with trace 5/4 must be
    # rejected by this script's own validation.
    bad = mat([[Fraction(3, 4), 0], [0, Fraction(1, 2)]])
    bad_failures = []
    ok = validate_rho(bad, "mutant(b) candidate", bad_failures)
    if not ok and any("trace" in f for f in bad_failures):
        print(f"    MUTANT(b) REJECTED: candidate diag(3/4, 1/2) has "
              f"trace {trace(bad)} != 1 -- validation witness: "
              f"{bad_failures[0]}")
    else:
        failures.append("mutant (b) trace-5/4 candidate was NOT "
                        "rejected by validation")
    # (c) Non-positive candidate: trace 1, diagonal entries in
    # [0, 1], symmetric -- but eigenvalue -3/2 (det = -15/4 < 0).
    # Must be rejected by the positivity leg of validation.
    bad3 = mat([[Fraction(1, 2), 2], [2, Fraction(1, 2)]])
    bad3_failures = []
    ok3 = validate_rho(bad3, "mutant(c) candidate", bad3_failures)
    det3 = bad3[0][0] * bad3[1][1] - bad3[0][1] * bad3[1][0]
    if not ok3 and any("positive" in f for f in bad3_failures):
        print(f"    MUTANT(c) REJECTED: candidate [[1/2, 2], [2, 1/2]] "
              f"has trace 1 and diagonal entries in [0,1] but "
              f"det = {det3} < 0 (eigenvalue -3/2) -- validation "
              f"witness: {bad3_failures[0]}")
    else:
        failures.append("mutant (c) non-positive candidate was NOT "
                        "rejected by validation")

    if failures:
        print("E5 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"E5 PASS: (1) census eigenvalues (3/4, 1/4) vs ascribed "
          f"(1, 0), trace distance exactly 1/4, entropy gap "
          f"{gap:.6f} nats > 0.5 (floats, disclosed); (2) honest "
          f"mixture distance exactly 0, entropies agree; (3) "
          f"provenance pair: marginals identical exactly "
          f"(diag(1/2, 1/2) by exact partial trace), joint entropies "
          f"ln 2 vs 0 -- rho's form does not record its provenance; "
          f"(4) Z-basis reconstruction equals the census diagonal "
          f"exactly; all three mutants rejected with witnesses. Stage P/C "
          f"instrument: nothing native is badged on it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### E.6 Bayesian updating — `E6_bayesian_updating.py`

````python
#!/usr/bin/env python3
"""
E6_bayesian_updating.py -- MaxEnt / Bayesian updating read against
the census (Paper 12.5, "The Ensemble Illusion").

FULLY EXACT: every number in this script is a fractions.Fraction
(or an integer). No float is computed anywhere; there is no
continuum content to disclose. The exhibit separates two objects
that the standard prose runs together:

  - the CENSUS: counted shares of an actual declared population of
    records (frequencies = census ratios, Paper 12's rule);
  - the UPDATING RULE's output: a distribution manufactured from a
    prior and a single counted constraint (here the counted mean)
    by the maximum-entropy recipe. The rule's output is a function
    of the constraint ALONE -- exhibit (3) shows two populations
    with the same counted mean, hence the same posterior, and
    different censuses. The rule is not the census.

INPUT_PROVENANCE:
  paper-defined:
    - Record classes: energies (0, 1, 2) [paper-defined] the three
      declared record classes of the exhibit.
    - Census ratios as the population's frequencies [cited-paper]
      Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows).
  cited-paper:
    - The MaxEnt updating recipe under audit (uniform prior, single
      mean constraint, posterior proportional to (1, r, r^2) for
      equally spaced energies 0, 1, 2): the standard Jaynes-style
      construction, audited as it is standardly stated.
  control:
    - None. No tolerances: every comparison is exact.
  declared-assumption:
    - The prior is uniform over the 3 classes (declared here and in
      the paper's exhibit; it is the recipe's own starting point,
      exhibited, not smuggled).
    - The single constraint is the counted mean of census A. The
      recipe is fed the counted number; what it returns is its own.
  arbitrary-representative:
    - Census A: 14 records, energy counts (7, 6, 1). Census B: 7
      records, energy counts (5, 0, 2). Both are declared
      representatives, chosen so the two counted means coincide
      exactly (4/7) while the censuses differ -- the separation
      the exhibit turns on -- and so that NEITHER census's ratios
      coincide with the posterior in any class. (Loop repair,
      recorded: the first build's census A, counts (4, 2, 1),
      carried the posterior's own ratios, so a checker that
      copied census A passed every check undetected; the red
      team demonstrated the copycat. Census A was re-chosen and
      mutant (c) now rejects the copycat on a printed witness.)
      The algebra (factorisation, positive root, geometric
      ratios) is checked exactly, not fitted.

Checks:
  (1) Census A's counted mean is COMPUTED from its counts: 4/7.
  (2) The updating rule: mean(r) = (r + 2r^2)/(1 + r + r^2) = 4/7
      iff 10r^2 + 3r - 4 = 0; the factorisation
      10r^2 + 3r - 4 = (2r - 1)(5r + 4) is verified coefficient-wise
      in exact arithmetic; the unique positive root r = 1/2 is
      taken (the other root, -4/5, is negative and excluded as a
      weight); the posterior is computed as (4/7, 2/7, 1/7),
      verified to sum to 1, to meet the constraint exactly, to not
      be the uniform distribution, and to have exactly geometric
      ratios.
  (3) Separation exhibit: census B's counted mean is computed
      (= 4/7, the same constraint), its census ratios are
      (5/7, 0, 2/7) != posterior. Same counted mean, same posterior,
      different census. BOTH censuses' ratios are checked to
      differ from the posterior in EVERY class, by an explicit
      per-class comparison for each census (v3 strengthening,
      recorded: the v2 instrument asserted census B's difference
      only as a whole-tuple inequality while the paper's claim
      L8.7 prints the per-class wording; the per-class assert for
      census B is now in the code, so the wording stands as
      checked, not narrowed), and the two censuses are asserted
      distinct (A != B).
  Mutants: (a) posterior-as-count checker (asserts the posterior
  equals the census ratios of every population meeting the
  constraint) must be REJECTED on census B with the witness
  printed; (b) wrong-root mutant (r = -4/5) must be rejected by
  the script's own non-negativity validation for weights, with
  the negative weight printed; (c) copycat checker (discards the
  derivation and badges census A's ratios as the posterior) must
  be REJECTED on the printed inequality of ratios.

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import sys
from fractions import Fraction

ENERGIES = (0, 1, 2)
CENSUS_A_COUNTS = (7, 6, 1)
CENSUS_B_COUNTS = (5, 0, 2)


def counted_mean(counts):
    """Counted mean energy, computed from the counts."""
    total = sum(counts)
    return Fraction(sum(e * c for e, c in zip(ENERGIES, counts)), total)


def census_ratios(counts):
    total = sum(counts)
    return tuple(Fraction(c, total) for c in counts)


def posterior_mean(post):
    return sum(Fraction(e) * p for e, p in zip(ENERGIES, post))


def weights_from_r(r):
    """Unnormalised MaxEnt weights (1, r, r^2) for a candidate r;
    returns None when r yields a negative weight (a weight must be
    a non-negative share multiplier -- a negative 'weight' is not a
    distribution ingredient). This IS the script's non-negativity
    validation, used by the main derivation and the mutant alike."""
    w = (Fraction(1), r, r * r)
    if any(x < 0 for x in w):
        return None
    return w


def normalise(w):
    s = sum(w)
    return tuple(x / s for x in w)


def main():
    failures = []
    print("E6 Bayesian updating -- fully exact (Fractions; no floats)")

    # ---- (1) Census A and its counted mean -------------------------
    mean_a = counted_mean(CENSUS_A_COUNTS)
    ratios_a = census_ratios(CENSUS_A_COUNTS)
    print(f"  (1) census A: {sum(CENSUS_A_COUNTS)} records, energy "
          f"counts {CENSUS_A_COUNTS} over energies {ENERGIES}; "
          f"counted mean = {mean_a} (computed from the counts); "
          f"census ratios = {ratios_a}")
    if mean_a != Fraction(4, 7):
        failures.append(f"census A counted mean {mean_a} != 4/7")

    # ---- (2) The updating rule -------------------------------------
    # mean(r) = (r + 2r^2)/(1 + r + r^2). Setting mean(r) = 4/7:
    #   7(r + 2r^2) = 4(1 + r + r^2)  <=>  10r^2 + 3r - 4 = 0.
    # Verify the claimed factorisation coefficient-wise, exactly:
    # (2r - 1)(5r + 4) expands to (2*5) r^2 + (2*4 - 1*5) r + (-1*4).
    a2 = 2 * 5
    a1 = 2 * 4 + (-1) * 5
    a0 = (-1) * 4
    print(f"  (2) factorisation check: (2r - 1)(5r + 4) expands to "
          f"{a2}r^2 + ({a1})r + ({a0}); target polynomial "
          f"10r^2 + 3r - 4; coefficient-wise equal: "
          f"{(a2, a1, a0) == (10, 3, -4)}")
    if (a2, a1, a0) != (10, 3, -4):
        failures.append(f"factorisation expands to {(a2, a1, a0)}, "
                        f"not (10, 3, -4)")
    # Cross-check the derivation itself: 7*(r + 2r^2) - 4*(1 + r + r^2)
    # must be the same polynomial: coefficients (14-4, 7-4, -4).
    d2, d1, d0 = 7 * 2 - 4 * 1, 7 * 1 - 4 * 1, -4 * 1
    if (d2, d1, d0) != (10, 3, -4):
        failures.append(f"mean-equation polynomial {(d2, d1, d0)} != "
                        f"(10, 3, -4)")
    roots = (Fraction(1, 2), Fraction(-4, 5))  # from the two factors
    for r in roots:
        val = 10 * r * r + 3 * r - 4
        if val != 0:
            failures.append(f"claimed root {r} does not zero the "
                            f"polynomial (value {val})")
    r = Fraction(1, 2)
    print(f"      roots of 10r^2 + 3r - 4 = 0: r = 1/2 and r = -4/5 "
          f"(both verified exactly above); r = -4/5 is negative and "
          f"excluded as a weight; unique positive root r = {r}")
    w = weights_from_r(r)
    if w is None:
        failures.append("positive root r=1/2 failed non-negativity "
                        "validation -- derivation broken")
        w = (Fraction(1), r, r * r)
    posterior = normalise(w)
    print(f"      weights (1, r, r^2) at r=1/2: {w}; posterior = "
          f"{posterior} (computed by normalising)")
    if posterior != (Fraction(4, 7), Fraction(2, 7), Fraction(1, 7)):
        failures.append(f"posterior {posterior} != (4/7, 2/7, 1/7)")
    if sum(posterior) != 1:
        failures.append(f"posterior sums to {sum(posterior)} != 1")
    pm = posterior_mean(posterior)
    print(f"      posterior sums to {sum(posterior)}; posterior mean "
          f"= {pm}; constraint (census A counted mean) = {mean_a}; "
          f"meets it exactly: {pm == mean_a}")
    if pm != mean_a:
        failures.append(f"posterior mean {pm} != counted mean {mean_a}")
    uniform = (Fraction(1, 3),) * 3
    if posterior == uniform:
        failures.append("posterior equals the uniform prior -- the "
                        "rule did no work")
    else:
        print(f"      posterior != uniform prior {uniform}: the rule "
              f"did work (it moved the distribution).")
    ratios = (posterior[1] / posterior[0], posterior[2] / posterior[1])
    print(f"      successive ratios: p1/p0 = {ratios[0]}, "
          f"p2/p1 = {ratios[1]}; geometric with ratio r = {r}: "
          f"{ratios == (r, r)}")
    if ratios != (r, r):
        failures.append(f"posterior ratios {ratios} != (r, r) = "
                        f"{(r, r)} -- not geometric")
    if not all(x != y for x, y in zip(ratios_a, posterior)):
        failures.append("census A ratios do not differ from the "
                        "posterior in every class -- the exhibit's "
                        "derivation is not cleanly distinguished "
                        "from copying census A")
    else:
        print(f"      (checked: census A's ratios {ratios_a} differ "
              f"from the posterior {posterior} in every class; the "
              f"derivation is not a copy of its feeding census.)")
    if CENSUS_A_COUNTS == CENSUS_B_COUNTS:
        failures.append("censuses A and B are identical populations "
                        "-- the separation exhibit has one census, "
                        "not two")

    # ---- (3) Separation exhibit ------------------------------------
    mean_b = counted_mean(CENSUS_B_COUNTS)
    ratios_b = census_ratios(CENSUS_B_COUNTS)
    arith = "(" + " + ".join(f"{e}*{c}" for e, c
                              in zip(ENERGIES, CENSUS_B_COUNTS)) \
            + f")/{sum(CENSUS_B_COUNTS)}"
    print(f"  (3) census B: {sum(CENSUS_B_COUNTS)} records, energy "
          f"counts {CENSUS_B_COUNTS}; counted mean = "
          f"{arith} = {mean_b} (computed -- the SAME "
          f"constraint); census ratios = {ratios_b}; posterior "
          f"(same constraint, same rule) = {posterior}; "
          f"census != posterior: {ratios_b != posterior}")
    if mean_b != mean_a:
        failures.append(f"census B counted mean {mean_b} != census A "
                        f"counted mean {mean_a}")
    if ratios_b == posterior:
        failures.append("census B ratios equal the posterior -- "
                        "separation exhibit broken")
    # v3 strengthening: per-class difference for census B, asserted
    # class by class exactly as for census A in check (2) -- the
    # paper's claim L8.7 prints "differing from the posterior in
    # every class" for census B, and the instrument now checks
    # precisely that, not merely the whole-tuple inequality above.
    if not all(x != y for x, y in zip(ratios_b, posterior)):
        failures.append("census B ratios do not differ from the "
                        "posterior in every class -- the per-class "
                        "wording of claim L8.7 is not backed")
    else:
        print(f"      (checked per class: census B's ratios "
              f"{ratios_b} differ from the posterior {posterior} "
              f"in every class -- class 0: {ratios_b[0]} != "
              f"{posterior[0]}; class 1: {ratios_b[1]} != "
              f"{posterior[1]}; class 2: {ratios_b[2]} != "
              f"{posterior[2]}.)")
    print("      Print: same counted mean, same posterior, different "
          "census -- the rule is not the census.")

    # ---- Mutant battery --------------------------------------------
    print("  mutant battery:")
    # (a) Posterior-as-count checker: asserts the posterior equals
    # the census ratios of EVERY population meeting the constraint.
    # Census B meets the constraint (mean 4/7, verified above) and
    # its ratios differ -- the checker is refuted by that witness.
    checker_claim_holds = (ratios_b == posterior)
    if not checker_claim_holds and mean_b == mean_a:
        print(f"    MUTANT(a) REJECTED: posterior-as-count checker "
              f"claims posterior == census ratios for every "
              f"population meeting the constraint; witness census B: "
              f"counts {CENSUS_B_COUNTS}, counted mean {mean_b} "
              f"(meets the constraint), census ratios {ratios_b} != "
              f"posterior {posterior}")
    else:
        failures.append("mutant (a) posterior-as-count checker was "
                        "NOT rejected")
    # (b) Wrong-root mutant: build the 'posterior' from r = -4/5.
    r_bad = Fraction(-4, 5)
    w_bad_raw = (Fraction(1), r_bad, r_bad * r_bad)
    w_bad = weights_from_r(r_bad)
    if w_bad is None:
        print(f"    MUTANT(b) REJECTED: wrong root r = {r_bad} yields "
              f"raw weights {w_bad_raw} -- the second weight is "
              f"negative ({r_bad}); non-negativity validation "
              f"rejects it (no distribution can be built from it)")
    else:
        failures.append("mutant (b) wrong-root weights passed "
                        "non-negativity validation")
    # (c) Copycat checker: discards the derivation and badges
    # census A's ratios as the posterior. Rejected on the printed
    # inequality -- census A is a population meeting the constraint
    # whose ratios are not the rule's output.
    copycat = ratios_a
    if copycat != posterior and mean_a == Fraction(4, 7):
        print(f"    MUTANT(c) REJECTED: copycat checker badges "
              f"census A's ratios {copycat} as the posterior; the "
              f"derived posterior is {posterior}; the two differ "
              f"in every class, and census A meets the constraint "
              f"(counted mean {mean_a}) -- copying the feeding "
              f"census is not deriving the rule's output")
    else:
        failures.append("mutant (c) copycat checker was NOT "
                        "rejected (census A ratios == posterior)")

    if failures:
        print("E6 FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"E6 PASS: census A counted mean computed = 4/7; "
          f"factorisation 10r^2 + 3r - 4 = (2r - 1)(5r + 4) verified "
          f"coefficient-wise; unique positive root r = 1/2 (root "
          f"-4/5 excluded as a weight); posterior computed = "
          f"(4/7, 2/7, 1/7), sums to 1, meets the constraint "
          f"exactly, is not uniform, ratios exactly geometric; "
          f"census B: same counted mean 4/7, same posterior, census "
          f"ratios (5/7, 0, 2/7) differing from the posterior in "
          f"every class (asserted per class) -- the rule is not the "
          f"census; all three mutants rejected with witnesses. Fully "
          f"exact: no float computed anywhere.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### M.1 Canonical recipe (Monte Carlo audit instrument) — `M1_canonical_recipe.py`

````python
#!/usr/bin/env python3
"""
M1_canonical_recipe.py -- Monte-Carlo audit instrument for Paper 12.5
("The Ensemble Illusion").

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C instrument. It audits the STANDARD canonical
  machinery on its own terms. It is NEVER a native (Stage N) derivation,
  and nothing it prints is a claim about the ledger framework's own
  populations.

  WHAT IS SAMPLED: single-unit flip trajectories of a two-level system
  of N units, each unit in state 0 (energy 0) or 1 (energy epsilon).
  A record is one full assignment; k = number of excited units.

  WHAT RULE DOES THE SAMPLING: the Metropolis acceptance rule
  min(1, exp(-beta * dE)) for a uniformly proposed single-unit flip.

  THE SAMPLING RULE IS THE POSTULATE UNDER AUDIT. The exponential weight
  exp(-beta * k) is not measured from the population and not derived
  here; it is adopted by the recipe. The decisive exhibit (Exhibit B)
  runs the IDENTICAL sampler code with the acceptance weight replaced
  by 1 (uniform -- pure counting measure) and shows it converges to the
  beta=0 census values instead: the only ingredient the "canonical
  ensemble" adds beyond counting is the adopted weight. The weight is
  a dial on the sampler, not a property of the population.

  For beta > 0 the exact side uses float arithmetic (math.exp). That
  continuum machinery is itself the exhibit under audit and is disclosed
  here, not hidden: only the beta=0 exact side is pure census arithmetic
  (exact Fractions, weights all 1).

INPUT_PROVENANCE:
  paper-defined:
    - Two-level record structure (k = 0..N excitations, C(N,k) records
      at level k): the standard textbook system the canonical recipe is
      stated on; audited as the recipe states it.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the beta=0 census side is that
      rule applied to this record set.
  control:
    - beta grid {0.0, 0.5, 1.0, 2.0}: CONTROL parameters of the recipe,
      dialled by the auditor; not properties of any population.
    - Fixed seeds: BASE_SEED = 20251107; per-run seeds are derived
      deterministically as BASE_SEED + 1000*run_index (declared here,
      before any run).
    - Run length N_STEPS = 200000 sampled steps after BURN_IN = 10000
      discarded steps, per sampler run (declared before any run).
  declared-assumption:
    - None. No premise is bridged in by declaration; the exponential
      weight is the recipe's own postulate, exhibited, not assumed
      by this script on the framework's behalf.
  arbitrary-representative:
    - N = 10 units; epsilon = 1 (energy unit). Conclusions are
      structural (weight-as-dial) and do not depend on these choices;
      they are representatives, not fitted values.

PRE-REGISTERED TOLERANCES (stated here, before the runs; not fitted):
  TOL_MEAN  = 0.20   max |sampler mean k - exact mean k|
  TOL_SHARE = 0.025  max |sampler share(k) - exact share(k)| over k
  The mutant (sign-flipped weight) must MISS the beta>0 targets by
  MORE than TOL_MEAN on the mean -- rejection requires a witness
  residual printed by the script.

Checks:
  (a) Exact side by complete enumeration over k = 0..N.
  (b) Sampler side (canonical acceptance) vs exact targets, every beta.
  (c) Exhibit B: uniform-weight sampler vs beta=0 census targets.
  (d) Mutant: sign-flipped weight must miss beta>0 targets (witness).

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import math
import random
import sys
from fractions import Fraction

# ---- declared controls / representatives (see header) ----
N = 10
EPSILON = 1  # energy unit, representative
BETA_GRID = (0.0, 0.5, 1.0, 2.0)
BASE_SEED = 20251107
N_STEPS = 200_000
BURN_IN = 10_000
TOL_MEAN = 0.20
TOL_SHARE = 0.025


def exact_targets(beta):
    """Complete enumeration over k = 0..N.

    Returns (mean_k, shares list). At beta == 0 every weight is 1 and
    the computation is exact Fraction census arithmetic. At beta > 0
    weights are exp(-beta*k) floats (disclosed continuum machinery).
    The targets are COMPUTED from the enumeration, never hardcoded.
    """
    from math import comb

    if beta == 0.0:
        total = Fraction(0)
        weighted = Fraction(0)
        shares = []
        for k in range(N + 1):
            records = comb(N, k)  # C(N,k) records at level k, weight 1
            shares.append(Fraction(records, 2 ** N))
            total += records
            weighted += records * k
        mean = weighted / total  # exact Fraction
        return mean, shares
    total = 0.0
    weighted = 0.0
    raw = []
    for k in range(N + 1):
        w = comb(N, k) * math.exp(-beta * k * EPSILON)
        raw.append(w)
        total += w
        weighted += w * k
    shares = [w / total for w in raw]
    return weighted / total, shares


def run_sampler(beta, mode, seed):
    """Metropolis single-unit flip sampler.

    mode:
      "canonical" -- acceptance min(1, exp(-beta*dE))  (the recipe)
      "uniform"   -- acceptance weight replaced by 1   (pure counting)
      "flipped"   -- acceptance min(1, exp(+beta*dE))  (mutant)

    The three modes share every line of trajectory code; only the
    single acceptance probability for an upward flip differs (a
    downward flip's probability is its mirror). That is the point of
    the exhibit: the weight is one dial in one place.
    """
    rng = random.Random(seed)
    if mode == "canonical":
        p_up = math.exp(-beta * EPSILON)
    elif mode == "uniform":
        p_up = 1.0
    elif mode == "flipped":
        p_up = 1.0  # upward flips always accepted under +beta weight
    else:
        raise ValueError(mode)
    # Downward-flip acceptance: canonical 1, uniform 1, flipped exp(-beta).
    p_down = math.exp(-beta * EPSILON) if mode == "flipped" else 1.0

    state = [0] * N
    k = 0
    counts = [0] * (N + 1)
    total_steps = BURN_IN + N_STEPS
    for step in range(total_steps):
        i = rng.randrange(N)
        if state[i] == 0:
            if rng.random() < p_up:
                state[i] = 1
                k += 1
        else:
            if rng.random() < p_down:
                state[i] = 0
                k -= 1
        if step >= BURN_IN:
            counts[k] += 1
    mean = sum(kk * c for kk, c in enumerate(counts)) / N_STEPS
    shares = [c / N_STEPS for c in counts]
    return mean, shares


def max_share_resid(shares_a, shares_b):
    return max(abs(float(a) - float(b)) for a, b in zip(shares_a, shares_b))


def main():
    failures = []

    # Exact targets, computed once per beta.
    exact = {beta: exact_targets(beta) for beta in BETA_GRID}
    census_mean, census_shares = exact[0.0]
    print(f"M1 exact: beta=0 census mean_k={census_mean} "
          f"(={float(census_mean):.6f}), shares are C({N},k)/2^{N} "
          f"as exact Fractions")
    for beta in BETA_GRID:
        if beta == 0.0:
            continue
        m, _ = exact[beta]
        print(f"M1 exact: beta={beta} enumerated mean_k={m:.6f}")

    run_index = 0

    def next_seed():
        nonlocal run_index
        seed = BASE_SEED + 1000 * run_index
        run_index += 1
        return seed

    # (b) Canonical sampler vs exact recipe targets.
    print("M1 Exhibit A: canonical sampler vs exact recipe targets")
    for beta in BETA_GRID:
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "canonical", seed)
        e_mean, e_shares = exact[beta]
        r_mean = abs(s_mean - float(e_mean))
        r_share = max_share_resid(s_shares, e_shares)
        ok = r_mean <= TOL_MEAN and r_share <= TOL_SHARE
        if not ok:
            failures.append(f"canonical beta={beta} seed={seed}")
        print(f"  beta={beta} seed={seed} sampler_mean={s_mean:.4f} "
              f"exact_mean={float(e_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} "
              f"tol_mean={TOL_MEAN} tol_share={TOL_SHARE} "
              f"{'OK' if ok else 'FAIL'}")

    # (c) Exhibit B: uniform weight -> beta=0 census values.
    print("M1 Exhibit B: uniform-weight sampler (weight=1) vs beta=0 census")
    for beta in BETA_GRID:
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "uniform", seed)
        r_mean = abs(s_mean - float(census_mean))
        r_share = max_share_resid(s_shares, census_shares)
        ok = r_mean <= TOL_MEAN and r_share <= TOL_SHARE
        if not ok:
            failures.append(f"uniform beta={beta} seed={seed}")
        print(f"  nominal_beta={beta} seed={seed} sampler_mean={s_mean:.4f} "
              f"census_mean={float(census_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} {'OK' if ok else 'FAIL'}")
    print("  Reading: with the weight set to 1 the identical code counts; "
          "the exponential weight is the recipe's only added ingredient.")

    # (d) Mutant: sign-flipped weight must MISS beta>0 targets.
    print("M1 Mutant: sign-flipped weight min(1, exp(+beta*dE))")
    for beta in BETA_GRID:
        if beta == 0.0:
            continue  # at beta=0 the flip is identical; no witness exists
        seed = next_seed()
        s_mean, s_shares = run_sampler(beta, "flipped", seed)
        e_mean, e_shares = exact[beta]
        r_mean = abs(s_mean - float(e_mean))
        r_share = max_share_resid(s_shares, e_shares)
        rejected = r_mean > TOL_MEAN
        if not rejected:
            failures.append(f"mutant NOT rejected at beta={beta}")
        print(f"  beta={beta} seed={seed} mutant_mean={s_mean:.4f} "
              f"exact_mean={float(e_mean):.4f} resid_mean={r_mean:.4f} "
              f"max_resid_share={r_share:.4f} tol_mean={TOL_MEAN} "
              f"{'REJECTED (witness resid_mean > tol)' if rejected else 'NOT REJECTED -- FAIL'}")

    if failures:
        print(f"M1 FAIL: {failures}")
        return 1
    print(f"M1 PASS: canonical sampler matches enumerated recipe targets "
          f"at all {len(BETA_GRID)} beta values (tol_mean={TOL_MEAN}, "
          f"tol_share={TOL_SHARE}); uniform-weight run converges to the "
          f"beta=0 census; sign-flipped mutant rejected at every beta>0.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### M.2 Ehrenfest urn (Monte Carlo audit instrument) — `M2_ehrenfest.py`

````python
#!/usr/bin/env python3
"""
M2_ehrenfest.py -- Ehrenfest urn audit instrument for Paper 12.5
("The Ensemble Illusion").

STAGE P/C FRAMING (house rule -- read first):
  This script is a Stage P/C instrument. It audits the STANDARD
  Ehrenfest urn machinery on its own terms. It is NEVER a native
  (Stage N) derivation.

  WHAT IS SAMPLED: a single seeded trajectory of the urn process --
  one ball at a time, moved between two urns. There is one actual
  population of N balls and one actual sequence of moves.

  WHAT RULE DOES THE SAMPLING: at each step, pick one of the N balls
  uniformly at random (seeded RNG) and move it to the other urn.

  THE SAMPLING RULE IS THE POSTULATE UNDER AUDIT in the following
  precise sense: the textbook gloss calls the limiting frequencies
  an "equilibrium ensemble distribution". The audit point, printed
  in this script's summary, is that the stationary shares are the
  CENSUS shares C(N,k)/2^N -- a counting fact about the 2^N records --
  and the trajectory's counted time-shares converge to those same
  shares. No ensemble is consulted anywhere in the computation; the
  "ensemble average" and the counted time-share agree because both
  are the same count.

INPUT_PROVENANCE:
  paper-defined:
    - Ehrenfest urn process as stated in the standard literature and
      audited by Paper 12.5: 2 urns, N balls, uniform single-ball move.
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the empirical side is that rule
      applied to the declared run window.
  control:
    - Fixed seed SEED = 20251108 (declared here, before any run).
    - Run length N_STEPS = 4000000 steps (declared window; declared
      before any run). Mutant run length MUTANT_STEPS = 500000.
    - Mutant bias factor BIAS_FACTOR = 1.5 (declared control of the
      planted mutant, stated before the run).
  declared-assumption:
    - None.
  arbitrary-representative:
    - N = 20 balls. 2^N = 1048576 records; the all-in-one-urn record
      is rare enough to exhibit recurrence, common enough to recur
      inside the declared window in expectation.

PRE-REGISTERED TOLERANCE (stated here, before the runs; not fitted):
  TOL_SHARE = 0.008  max |empirical share(k) - C(N,k)/2^N| over k.
  The biased-picker mutant must MISS by more than TOL_SHARE --
  rejection requires a printed witness residual.

Checks:
  (a) Exact side: stationary shares = census shares (exact Fractions);
      exact mean recurrence time to k=0 computed as 1/share(0),
      an exact integer equal to 2^N.
  (b) Simulation side: empirical shares vs census shares within
      TOL_SHARE; returns to k=0 counted and printed.
  (c) Mutant: biased picker must miss census shares (witness).

Exit 0 iff every check passes. Python 3 stdlib only.
"""

import random
import sys
from fractions import Fraction
from math import comb

# ---- declared controls / representatives (see header) ----
N = 20
SEED = 20251108
N_STEPS = 4_000_000
MUTANT_SEED = 20251109
MUTANT_STEPS = 500_000
BIAS_FACTOR = 1.5
TOL_SHARE = 0.008


def census_shares():
    """Exact census shares C(N,k)/2^N as Fractions (computed)."""
    return [Fraction(comb(N, k), 2 ** N) for k in range(N + 1)]


def run_fair(seed, n_steps):
    """Seeded Ehrenfest trajectory; returns (counts, returns_to_0).

    A step picks one ball uniformly: with count k in urn A, a uniform
    draw in 0..N-1 below k picks an A-ball (k -> k-1), else a B-ball
    (k -> k+1). Counts record the state AFTER each step.
    """
    rng = random.Random(seed)
    randrange = rng.randrange
    k = N // 2
    counts = [0] * (N + 1)
    returns = 0
    for _ in range(n_steps):
        if randrange(N) < k:
            k -= 1
        else:
            k += 1
        counts[k] += 1
        if k == 0:
            returns += 1
    return counts, returns


def run_biased(seed, n_steps, factor):
    """Mutant trajectory: A-balls carry `factor` times the picking
    weight of B-balls, so P(move down | k) is proportional to
    factor*k against (N-k)."""
    rng = random.Random(seed)
    rand = rng.random
    k = N // 2
    counts = [0] * (N + 1)
    for _ in range(n_steps):
        denom = factor * k + (N - k)
        p_down = (factor * k / denom) if denom > 0 else 0.0
        if rand() < p_down:
            k -= 1
        else:
            k += 1
        counts[k] += 1
    return counts


def max_dev(counts, n_steps, exact):
    return max(abs(c / n_steps - float(e))
               for c, e in zip(counts, exact))


def main():
    failures = []

    # (a) Exact side.
    exact = census_shares()
    share0 = exact[0]
    recurrence = 1 / share0  # exact Fraction; must be the integer 2^N
    print(f"M2 exact: stationary shares are census shares C({N},k)/2^{N}; "
          f"share(k=0)={share0} (={float(share0):.6e})")
    print(f"M2 exact: mean recurrence time to k=0 = 1/share(0) = "
          f"{recurrence} steps (exact; 2^{N} = {2 ** N})")
    if recurrence != 2 ** N or recurrence.denominator != 1:
        failures.append("recurrence time is not the exact integer 2^N")
        print("M2 FAIL: recurrence computation did not return 2^N exactly")
    # Census shares must sum to exactly 1 (counting identity, computed).
    if sum(exact) != 1:
        failures.append("census shares do not sum to exactly 1")

    # (b) Simulation side.
    counts, returns = run_fair(SEED, N_STEPS)
    dev = max_dev(counts, N_STEPS, exact)
    worst_k = max(range(N + 1),
                  key=lambda kk: abs(counts[kk] / N_STEPS - float(exact[kk])))
    ok = dev <= TOL_SHARE
    if not ok:
        failures.append("fair run missed census shares")
    print(f"M2 sim: seed={SEED} steps={N_STEPS} "
          f"max_abs_dev={dev:.6f} at k={worst_k} "
          f"(empirical={counts[worst_k] / N_STEPS:.6f}, "
          f"census={float(exact[worst_k]):.6f}) tol={TOL_SHARE} "
          f"{'OK' if ok else 'FAIL'}")
    print(f"M2 sim: visits to k=0 counted = {returns} "
          f"(expected count at census share = "
          f"{N_STEPS * float(share0):.2f} over the declared window; "
          f"count reported, not fitted)")
    if returns < 1:
        failures.append("no return to k=0 observed in the declared window")

    # (c) Mutant: biased picker must miss census shares.
    m_counts = run_biased(MUTANT_SEED, MUTANT_STEPS, BIAS_FACTOR)
    m_dev = max_dev(m_counts, MUTANT_STEPS, exact)
    m_worst = max(range(N + 1),
                  key=lambda kk: abs(m_counts[kk] / MUTANT_STEPS
                                     - float(exact[kk])))
    rejected = m_dev > TOL_SHARE
    if not rejected:
        failures.append("biased mutant NOT rejected")
    print(f"M2 mutant: bias_factor={BIAS_FACTOR} seed={MUTANT_SEED} "
          f"steps={MUTANT_STEPS} max_abs_dev={m_dev:.6f} at k={m_worst} "
          f"(empirical={m_counts[m_worst] / MUTANT_STEPS:.6f}, "
          f"census={float(exact[m_worst]):.6f}) tol={TOL_SHARE} "
          f"{'REJECTED (witness dev > tol)' if rejected else 'NOT REJECTED -- FAIL'}")

    print("M2 audit point: stationarity of the empirical frequencies is "
          "convergence to CENSUS shares -- no ensemble was consulted; "
          "the 'ensemble average' and the counted time-share agree "
          "because both are the same count.")

    if failures:
        print(f"M2 FAIL: {failures}")
        return 1
    print(f"M2 PASS: empirical shares match census shares "
          f"C({N},k)/2^{N} within tol={TOL_SHARE} "
          f"(max_abs_dev={dev:.6f}); recurrence to k=0 is exactly "
          f"{2 ** N} steps by census share; biased mutant rejected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### G.1 History consistency — `G1_history_consistency.py`

````python
#!/usr/bin/env python3
# G1_history_consistency.py -- Paper 12.5 document check: the (year,
# author) PAIRINGS of Appendix A must be exactly the pairings the body
# makes, over the declared YEARS/NAMES lists below. Pairing consistency
# only: the truth of any row's content is the history dossier's work,
# not this script's (loop repair -- the earlier wording claimed the
# record itself).
#
# v3 strengthening (recorded): the v1/v2 instrument had no mutant
# battery -- a checker that cannot fail cannot verify -- and its
# coverage limit (body year-mentions that produce no pairing under
# the rules below) was disclosed in this header but invisible in the
# run record. The v3 instrument (a) carries a built-in mutant
# battery: ten synthetic mini-papers -- two clean (one pairing by
# the citation form, one by same-sentence proximity only) and eight
# planted violations (appendix-only pairing, body-only pairing,
# yearless appendix row, missing falsification condition, the
# condition present only inside a longer label, missing
# falsification heading, an appendix row naming no listed author,
# a proximity pairing the appendix does not carry) -- each run
# through the SAME check function used on the paper, the violations
# required to be caught and the clean cases required to pass; and
# (b) LISTS every unpaired body year-mention in the run record, with
# context, for inspection -- the coverage limit is printed, not
# merely confessed in the header. (Loop repairs within v3, recorded:
# the falsification-presence check now matches the condition label
# as a whole word over fence-stripped prose -- the v1/v2 substring
# test over the raw file passed on a longer label containing the
# characters, or on the label's occurrences inside this listing
# itself; and the appendix author read is whole-word, where the
# v1/v2 substring read took "Gibbson" for Gibbs.)
#
# INPUT_PROVENANCE:
#   paper-defined:      Appendix A's declared table structure (columns:
#                       Year | Author | Work | What it establishes here) and
#                       the paper's historical claim set (sections 2, 5, 9, 10).
#                       v2 extension, declared: YEARS and NAMES below were
#                       extended for the v2 lineage additions exactly by
#                       the years and names the v2 history dossier verified
#                       (1911, 1927, 1932, 1941, 1992, 2014, 2017;
#                       Bridgman, Neumann, Rau). No other set member changed.
#   control:            the paper path (argv[1] / $PAPER_MD / default).
#   declared-assumption: the PAIRING RULE, declared here: an appendix pairing
#                       is read STRUCTURALLY from the table's Year and Author
#                       columns (one pairing per listed author the row
#                       names; every row of the shipped appendix names
#                       exactly one). A body pairing binds a
#                       listed year to a listed author name by, in order:
#                       (i) the CITATION FORM -- the nearest listed name
#                       before the year owns it when at most 3 tokens, no
#                       other listed name or year, and no sentence terminator
#                       intervene ("Loschmidt (1876)", "Boltzmann's counting
#                       (1877)"), as citation syntax declares;
#                       (ii) otherwise the NEAREST listed name in the SAME
#                       SENTENCE within 60 characters. The prose is
#                       hard-wrapped, so same-line pairing is not the text's
#                       structure; and unrestricted proximity manufactures
#                       pairings across sentence boundaries and parenthetical
#                       lists (three such artifacts were caught and
#                       adjudicated at assembly -- the rule above is the
#                       repair, recorded here, not a silent loosening: rule
#                       (i) follows citation syntax, rule (ii) cannot cross
#                       a sentence boundary). Body text excludes fenced code
#                       blocks (Appendix E listings are data, not claims)
#                       and everything from the Appendix A heading on
#                       (appendices state the record; the body makes it).
#   arbitrary-representative:
#                     - The battery's synthetic mini-papers: minimal
#                       representatives of each offence class and of
#                       the clean case, constructed for this battery;
#                       they quote no source.
#
# WHAT IS CHECKED: (a) the set of (year, author) pairings in Appendix A
# equals the set in the body, both directions; (b) every Appendix A table row
# carries a year; (c) the condition label C34 stands as a whole word in the
# paper's prose (fenced listings excluded -- a listing's copy of the label
# is data, not the paper's falsification surface) and a falsification
# heading is present; (d) the mutant battery above passes. WHAT IS PRINTED BESIDE THE CHECK:
# every body occurrence of a listed year that produced no pairing, with
# context (the diagnostics) -- listed for inspection, not adjudicated.
# WHAT STAYS OUTSIDE: whether the historical claims are TRUE (that is the
# dossier's work, classified, section 2 / Appendix A of the paper); whether
# an unpaired year-mention makes a historical claim the appendix drops
# (human-audit territory -- the diagnostics exist so that audit reads a
# list, not a haystack).
import os
import re
import sys
from pathlib import Path

YEARS = {"1876", "1877", "1890", "1896", "1902", "1907", "1911", "1927",
         "1932", "1938", "1941", "1948", "1951", "1956", "1957", "1992",
         "1997", "1999", "2014", "2017"}
NAMES = {"Loschmidt", "Boltzmann", "Poincaré", "Poincare", "Zermelo",
         "Gibbs", "Ehrenfest", "Tolman", "Shannon", "Purcell", "Ramsey",
         "Jaynes", "Jarzynski", "Crooks", "Bridgman", "Neumann", "Rau"}
CANON = {"Poincare": "Poincaré"}
WINDOW = 60


def canon(name):
    return CANON.get(name, name)


def resolve(argv):
    if len(argv) > 1:
        return Path(argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def strip_fences(lines):
    out, in_fence = [], False
    for line in lines:
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return out


def appendix_rows(lines):
    """Table data rows of Appendix A: from its heading to Appendix B's."""
    start = end = None
    for i, line in enumerate(lines):
        if line.startswith("## Appendix A"):
            start = i
        elif start is not None and line.startswith("## Appendix B"):
            end = i
            break
    if start is None:
        return None, []
    seg = lines[start:end if end is not None else len(lines)]
    rows = []
    for line in seg:
        s = line.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if cells and cells[0].lower() == "year":
                continue  # header
            if all(set(c) <= set("-: ") for c in cells):
                continue  # separator
            rows.append((line, cells))
    return seg, rows


def body_pairings(lines):
    """Body (year, author) pairings under the declared pairing rule,
    plus diagnostics: every listed-year occurrence in the body, and
    the occurrences that produced no pairing (with context)."""
    body_lines = []
    for line in lines:
        if line.startswith("## Appendix A"):
            break
        body_lines.append(line)
    body_lines = strip_fences(body_lines)
    paragraphs, cur = [], []
    for line in body_lines:
        if line.strip():
            cur.append(line.strip())
        elif cur:
            paragraphs.append(" ".join(cur))
            cur = []
    if cur:
        paragraphs.append(" ".join(cur))
    body_text = "\n".join(paragraphs)

    name_pat = re.compile(r"\b(" + "|".join(sorted(NAMES)) + r")\b")
    year_pat = re.compile(r"\b(" + "|".join(sorted(YEARS)) + r")\b")
    name_hits = [(m.start(), m.end(), canon(m.group(1)))
                 for m in name_pat.finditer(body_text)]
    # sentence spans (for rule (ii)'s same-sentence restriction)
    spans, pos = [], 0
    for chunk in re.split(r"(?<=[.!?])\s+", body_text):
        spans.append((pos, pos + len(chunk)))
        pos += len(chunk) + 1

    def sentence_of(p):
        for s0, s1 in spans:
            if s0 <= p <= s1:
                return (s0, s1)
        return (0, len(body_text))

    body_pairs = set()
    year_occurrences = 0
    unpaired = []
    for m in year_pat.finditer(body_text):
        ypos, year = m.start(), m.group(1)
        year_occurrences += 1
        owner = None
        # rule (i): citation form -- the nearest listed name BEFORE the year
        # owns it when the intervening text is at most 3 tokens with no other
        # listed name, no listed year, and no sentence terminator between
        # ("Loschmidt (1876)"; "Boltzmann's counting (1877)").
        cands = [(nend, nname) for nstart, nend, nname in name_hits if nend <= ypos]
        if cands:
            nend, nname = max(cands)
            between = body_text[nend:ypos]
            tokens = between.split()
            if (len(tokens) <= 3
                    and not any(n in between for n in NAMES)
                    and not year_pat.search(between)
                    and not re.search(r"[.!?]", between)):
                owner = nname
        if not owner:
            # rule (ii): nearest listed name in the same sentence, within WINDOW
            s0, s1 = sentence_of(ypos)
            best, bestd = None, None
            for nstart, nend, nname in name_hits:
                if s0 <= nstart <= s1:
                    dist = abs(nstart - ypos)
                    if dist <= WINDOW and (bestd is None or dist < bestd):
                        best, bestd = nname, dist
            owner = best
        if owner:
            body_pairs.add((year, owner))
        else:
            ctx = body_text[max(0, ypos - 55):ypos + 30].replace("\n", " ")
            unpaired.append((year, ctx))
    diagnostics = {"year_occurrences": year_occurrences,
                   "unpaired": unpaired}
    return body_pairs, diagnostics


def check_text(raw):
    """The full G.1 check over a paper text. Returns (violations,
    stats) where stats carries the pairing counts and diagnostics.
    This is the single function the battery and the paper run share."""
    lines = raw.split("\n")
    violations = []

    # (c) falsification presence: the label as a WHOLE WORD over
    # fence-stripped prose (v3 loop repair -- the v1/v2 substring
    # test over the raw file passed on "C340" and on the label's
    # occurrences inside Appendix E's listings, this one included)
    prose = "\n".join(strip_fences(lines))
    if not re.search(r"\bC34\b", prose):
        violations.append('paper does not contain "C34" as a whole '
                          'word in its prose')
    if not re.search(r"^## .*falsification", raw, flags=re.M | re.I):
        violations.append("no falsification section heading found")

    seg, rows = appendix_rows(lines)
    if seg is None:
        violations.append("Appendix A heading not found")
        rows = []

    # appendix pairings: structural, from Year | Author columns
    app_pairs = set()
    for line, cells in rows:
        year_m = re.search(r"\b(1[89]\d\d|20\d\d)\b", cells[0]) if cells else None
        if not year_m:
            violations.append(f"appendix row lacks a year: {line.strip()[:90]}")
            continue
        year = year_m.group(1)
        author_cell = cells[1] if len(cells) > 1 else ""
        # whole-word author read (v3 loop repair: the v1/v2
        # substring test read "Gibbson" as Gibbs)
        found = [n for n in NAMES
                 if re.search(r"\b" + re.escape(n) + r"\b", author_cell)]
        if not found:
            violations.append(f"appendix row has no listed author: {line.strip()[:90]}")
            continue
        for n in found:
            app_pairs.add((year, canon(n)))

    body_pairs, diagnostics = body_pairings(lines)

    for pair in sorted(app_pairs - body_pairs):
        violations.append(f"appendix-only pairing {pair}: in Appendix A, never in body")
    for pair in sorted(body_pairs - app_pairs):
        violations.append(f"body-only pairing {pair}: in body, missing from Appendix A")

    stats = {"app_pairs": app_pairs, "body_pairs": body_pairs,
             "n_rows": len(rows), "diagnostics": diagnostics}
    return violations, stats


# ---- mutant battery: synthetic mini-papers, never the paper ----
_BATTERY_HEAD = [
    "# Mini paper",
    "",
    "## 11 FALSIFICATION CONDITIONS",
    "",
    "Condition C34 opens the surface.",
    "",
]
_BATTERY_APP_OPEN = [
    "## Appendix A HISTORICAL SOURCES",
    "",
    "| Year | Author | Work | What it establishes here |",
    "|---|---|---|---|",
]
_BATTERY_APP_CLOSE = [
    "",
    "## Appendix B INHERITANCE",
    "",
]


def _mini(body_lines, app_row_lines):
    return "\n".join(_BATTERY_HEAD + body_lines + [""]
                     + _BATTERY_APP_OPEN + app_row_lines
                     + _BATTERY_APP_CLOSE)


BATTERY_CLEAN = _mini(
    ["Gibbs (1902) wrote the book under audit here."],
    ["| 1902 | Gibbs | Elementary Principles | A row. |"])
# Second clean case: the pairing is made by rule (ii) ALONE -- the
# name and year share a sentence at a distance the citation form
# (rule (i), at most 3 intervening tokens) cannot bind ("published
# the book in" is four tokens). The battery asserts the pairing was
# in fact produced, so a rule-(ii) regression cannot pass silently.
BATTERY_CLEAN_II = _mini(
    ["Gibbs published the book in 1902, a generation later."],
    ["| 1902 | Gibbs | Elementary Principles | A row. |"])
BATTERY_CASES = [
    ("appendix-only pairing",
     _mini(["Gibbs (1902) wrote the book under audit here."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |",
            "| 1877 | Boltzmann | A memoir | A row the body never makes. |"])),
    ("body-only pairing",
     _mini(["Gibbs (1902) wrote the book under audit here.",
            "Loschmidt (1876) raised the objection."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |"])),
    ("appendix row lacks a year",
     _mini(["Gibbs (1902) wrote the book under audit here."],
           ["| 1902 | Gibbs | Elementary Principles | A row. |",
            "| -- | Gibbs | A dateless row | No year on this row. |"])),
    ('does not contain "C34"',
     "\n".join(["# Mini paper", "",
                "## 11 FALSIFICATION CONDITIONS", "",
                "The opening condition is not named here.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    # (v3 loop repair) the label present only inside a longer
    # label: the v1/v2 substring test passed this text.
    ('does not contain "C34"',
     "\n".join(["# Mini paper", "",
                "## 11 FALSIFICATION CONDITIONS", "",
                "Condition C340 opens the surface.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    ("no falsification section heading",
     "\n".join(["# Mini paper", "",
                "## 11 CONDITIONS", "",
                "Condition C34 opens the surface.", ""]
               + ["Gibbs (1902) wrote the book under audit here.", ""]
               + _BATTERY_APP_OPEN
               + ["| 1902 | Gibbs | Elementary Principles | A row. |"]
               + _BATTERY_APP_CLOSE)),
    ("no listed author",
     _mini(["The book under audit appeared in print."],
           ["| 1902 | Anon | A work | A row naming no listed author. |"])),
    # rule (ii) exercised in the failing direction: the body pairs
    # (1902, Gibbs) by proximity alone; the appendix carries a
    # different pairing for 1902 -- both directions must fire.
    ("body-only pairing",
     _mini(["Gibbs published the book in 1902, a generation later."],
           ["| 1902 | Boltzmann | A memoir | A mismatched row. |"])),
]


def run_battery():
    failures = []
    violations, _ = check_text(BATTERY_CLEAN)
    if violations:
        failures.append(f"clean mini-paper flagged: {violations}")
    violations, stats = check_text(BATTERY_CLEAN_II)
    if violations:
        failures.append(f"clean rule-(ii) mini-paper flagged: "
                        f"{violations}")
    elif ("1902", "Gibbs") not in stats["body_pairs"]:
        failures.append("rule-(ii) clean case produced no (1902, "
                        "Gibbs) body pairing -- rule (ii) is not "
                        "exercised by this battery")
    for expected, text in BATTERY_CASES:
        violations, _ = check_text(text)
        if not any(expected in v for v in violations):
            failures.append(f"planted violation not caught "
                            f"({expected}): violations={violations}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G1 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print(f"G1 battery: PASS (2 clean mini-papers pass -- citation "
          f"form and rule-(ii) proximity; {len(BATTERY_CASES)} "
          f"planted violations caught by the same check function)")

    paper = resolve(sys.argv)
    if not paper.exists():
        print(f"G1 FAIL: paper not found: {paper}")
        return 1
    raw = paper.read_text(encoding="utf-8")
    violations, stats = check_text(raw)
    diag = stats["diagnostics"]
    print(f"G1 diagnostics: body listed-year occurrences="
          f"{diag['year_occurrences']}; unpaired (no pairing under "
          f"the declared rule)={len(diag['unpaired'])} -- listed "
          f"for inspection, not adjudicated:")
    for year, ctx in diag["unpaired"]:
        print(f"  UNPAIRED year {year}: ...{ctx}...")
    if violations:
        print(f"G1 VIOLATIONS ({len(violations)}) for {paper}:")
        for v in violations:
            print(f"  - {v}")
        print(f"G1 counts: appendix_pairs={len(stats['app_pairs'])} "
              f"body_pairs={len(stats['body_pairs'])}")
        return 1
    print(f"G1 PASS: {paper}: appendix_pairs={len(stats['app_pairs'])} "
          f"body_pairs={len(stats['body_pairs'])} (sets equal); "
          f"appendix rows={stats['n_rows']} all carry years; C34 + "
          f"falsification present; battery green")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### G.2 Audit-matrix completeness — `G2_matrix_completeness.py`

````python
#!/usr/bin/env python3
"""
G2_matrix_completeness.py -- document check for Paper 12.5
("The Ensemble Illusion").

PURPOSE: the Section 4 audit matrix is the paper's central exhibit
(one row per audited construction, columns: what is counted / what
is postulated / what is measured / the prose claim / the equation's
actual content). This check proves the assembled paper's matrix is
complete and fully filled -- no row dropped, no cell left empty.

CHECKS:
  - Locate the Section 4 heading (a heading line for section 4),
    then the first markdown table following it.
  - The table's data rows must be EXACTLY the six required rows,
    identified by first-cell labels containing (case-insensitive):
      Microcanonical, Canonical, Grand canonical, Ergodic,
      Coarse-graining, Gibbs
    ("Canonical" must not be satisfied by the Microcanonical row:
    labels are matched most-specific first and each row counts once.)
  - Each of the six rows must have at least 5 non-empty cells.

INPUT_PROVENANCE:
  paper-defined:
    - The six audit-matrix rows: Paper 12.5 design brief's audit
      matrix (microcanonical / canonical / grand canonical /
      ergodic hypothesis / coarse-graining / Gibbs-Shannon).
    - The five-column shape (counted / postulated / measured /
      prose / equation): the paper's audit form, inherited from
      Paper 11.5's Section 3.7-style matrix.
  cited-paper:
    - Paper 11.5 audit-matrix form (see design brief, machinery
      inherited): form cited, contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      first existing of ../Paper_12_5_v3.md and
      ../../Paper_12_5_v3.md relative to this script, else the
      delivered copy under ~/workspace/paper_12_5_delivery/.
  declared-assumption:
    - The matrix is the first markdown table after the Section 4
      heading (declared here; matches the paper's layout contract).
  arbitrary-representative:
    - None.

Exit 0 on PASS, 1 on any violation. Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

# Most-specific first: "Microcanonical" before "Canonical".
REQUIRED = ["Microcanonical", "Grand canonical", "Canonical",
            "Ergodic", "Coarse-graining", "Gibbs"]
MIN_CELLS = 5


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    # Drop the empty artefacts of the leading/trailing pipe.
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def find_matrix_rows(lines):
    """Data rows (cell lists) of the first table after the S4 heading."""
    start = None
    for i, line in enumerate(lines):
        if re.match(r"^#{1,4}\s*4(\.|\s)", line) or \
                re.match(r"^#{1,4}\s*Section\s+4\b", line, re.IGNORECASE):
            start = i
            break
    if start is None:
        return None
    rows = []
    in_table = False
    for line in lines[start + 1:]:
        stripped = line.strip()
        if stripped.startswith("|"):
            if set(stripped) <= set("|-: "):
                in_table = True
                continue
            if in_table:
                rows.append(split_cells(line))
            else:
                # Header row: enters the table but is not a data row.
                in_table = "pending"
            continue
        if in_table and stripped.startswith("#"):
            break
        if in_table is True and stripped == "":
            # Allow a blank line only before the next heading/table;
            # a blank line after data rows ends this table.
            if rows:
                break
    return rows


def match_label(first_cell):
    low = first_cell.lower()
    for req in REQUIRED:
        if req.lower() in low:
            return req
    return None


def main():
    path = resolve_path()
    if not path.is_file():
        print(f"G2 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    violations = []

    rows = find_matrix_rows(lines)
    if rows is None:
        print(f"G2 VIOLATIONS for {path}: Section 4 heading not found")
        return 1
    if not rows:
        print(f"G2 VIOLATIONS for {path}: no data rows in the "
              f"Section 4 audit-matrix table")
        return 1

    matched = {}
    extras = []
    for cells in rows:
        label = match_label(cells[0]) if cells else None
        if label is None:
            extras.append(cells[0] if cells else "<empty row>")
        elif label in matched:
            extras.append(f"duplicate row for {label}: {cells[0]}")
        else:
            matched[label] = cells

    for req in REQUIRED:
        if req not in matched:
            violations.append(f"missing required matrix row: {req}")
    for e in extras:
        violations.append(f"unexpected matrix row: {e}")
    if len(rows) != len(REQUIRED):
        violations.append(
            f"matrix has {len(rows)} data rows, expected exactly "
            f"{len(REQUIRED)}")
    for req in REQUIRED:
        if req in matched:
            nonempty = sum(1 for c in matched[req] if c)
            if nonempty < MIN_CELLS:
                violations.append(
                    f"row {req!r} has {nonempty} non-empty cells "
                    f"(< {MIN_CELLS}): {matched[req]}")

    if violations:
        print(f"G2 VIOLATIONS ({len(violations)}) for {path}:")
        for v in violations:
            print(f"  - {v}")
        return 1
    print(f"G2 PASS: {path}: audit matrix has exactly {len(rows)} "
          f"rows ({', '.join(REQUIRED)}), each with >= {MIN_CELLS} "
          f"non-empty cells.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### G.3 Premise inventory — `G3_premise_inventory.py`

````python
#!/usr/bin/env python3
"""
G3_premise_inventory.py -- document + recomputation check for
Paper 12.5 ("The Ensemble Illusion"), section 7.4 premise inventory.

PURPOSE: section 7.4 names the premises a recurrence/drift claim
would have to buy, prices each against the two toy exhibits (Kac
ring, Ehrenfest urn), and closes by stating the joint is open.
This check proves (a) the assembled paper's inventory is complete
and priced, (b) the closing sentence is present, and (c) the two
load-bearing toy facts the inventory's prices rest on are TRUE,
recomputed here independently of the paper's prose.

CHECKS:
  (1) Locate "### 7.4"; within it find the premise table by its
      exact header
        | Premise | What it must supply | Kac ring | Ehrenfest urn | Price |
      Assert exactly 6 data rows, P1-P6 (P6 is the starting-record
      premise: the class of initial records over which drift is
      claimed, declared and priced), each with >= 5 cells and a
      Price cell carrying a price keyword from the inventory's
      printed price vocabulary (LEVEL / Unpriced / Owed /
      Discharged / NO BADGE / Stage / inherited / Missing / Open)
      -- a non-empty cell is not a printed price (loop repair).
  (2) Assert the exact sentence "The joint is open." occurs within
      section 7.4 (from the ### 7.4 heading to the next ## heading).
  (3) Recompute, independently of the paper:
      (i) Kac ring N=4, exhaustively over all colourings (2^4) x
          flipper placements (2^4): simulate the ring exactly and
          confirm at least one case whose |imbalance| trajectory
          over t = 0..2N is non-monotone (it both rises at some
          step and falls at some step); print one witness. Also
          confirm exact recurrence (the state at some t in 1..2N
          equals the initial state) for ALL cases at N=4.
      (ii) Ehrenfest census shares at N=20: exact Fractions
          C(20,k)/2^20; assert the unique maximum is at k=10 and
          each extreme share (k=0 and k=20) equals 1/2^20.

MUTANT BATTERY (built in, run on synthetic strings, not the paper):
  a premise table missing row P3 must FAIL check (1), and a section
  7.4 text without the closing sentence must FAIL check (2); both
  are run through the same functions used on the paper.

INPUT_PROVENANCE:
  paper-defined:
    - The premise table's header and row labels P1-P6, and the
      closing sentence: Paper 12.5 section 7.4 as assembled (the
      document side of this check audits that text; the header
      string is the layout contract, copied exactly).
    - Kac ring dynamics: N sites, balls black/white, each tick every
      ball advances one site and flips colour iff it passes a marked
      (flipper) site -- the paper's toy exhibit, restated here.
    - Ehrenfest census shares C(N,k)/2^N: the counting fact of the
      paper's second toy exhibit (see also M2's exact side).
  cited-paper:
    - Paper 12 section 8.6 / 9.6 open joint: the sentence "The joint
      is open." is this companion's restatement of that standing
      open joint for the premises inventoried here; its truth as a
      claim about the framework is the paper's, not this script's.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      default path relative to this script.
    - Kac recomputation size N=4 and Ehrenfest size N=20: declared
      check sizes (N=4 is the smallest ring exhibiting the full
      fall-and-rise trajectory; N=20 matches M2's census).
  declared-assumption:
    - Kac encoding: colours are a list per site (1 = black,
      0 = white); a flipper sits on edge i -> i+1 and toggles a
      ball crossing it; imbalance D(t) = (#black) - (#white)
      = 2*b(t) - N, and the trajectory audited is |D(t)|.
      Representation choices only -- the non-monotonicity and
      recurrence verdicts are invariant under relabelling.
    - The premise table is the table in section 7.4 whose header
      row equals the exact header string above; data rows are the
      following pipe rows up to the first non-pipe line.
  arbitrary-representative:
    - The battery's synthetic section-7.4 texts: representatives
      of the two failure classes, not quotations from any source.

Exit 0 iff the battery passes AND all paper checks pass AND the
recomputation confirms both toy facts. Python 3 stdlib only.
"""

import os
import sys
from fractions import Fraction
from math import comb
from pathlib import Path

TABLE_HEADER = ("| Premise | What it must supply | Kac ring | "
                "Ehrenfest urn | Price |")
REQUIRED_ROWS = ["P1", "P2", "P3", "P4", "P5", "P6"]
CLOSING_SENTENCE = "The joint is open."
# Loop repair: a Price cell must carry a price, not merely be
# non-empty (the red team passed a paper whose Price cells were
# all "x"). The inventory's price vocabulary is small and printed:
# badges, "Unpriced", "Owed", discharges, the joint's own name.
PRICE_KEYWORDS = ("LEVEL", "Unpriced", "Owed", "Discharged",
                  "NO BADGE", "Stage", "inherited", "Missing", "Open")
KAC_N = 4
EHRENFEST_N = 20


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def section_74_lines(lines):
    """Lines of section 7.4: from the '### 7.4' heading to the next
    '## ' heading (or end of file). None if the heading is absent."""
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("### 7.4"):
            start = i
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("## "):
            end = j
            break
    return lines[start:end]


def premise_table_rows(sec_lines):
    """Data rows (cell lists) of the premise table in section 7.4,
    found by its exact header. None if the header is absent."""
    if sec_lines is None:
        return None
    for i, line in enumerate(sec_lines):
        if line.strip() == TABLE_HEADER:
            rows = []
            for nxt in sec_lines[i + 1:]:
                s = nxt.strip()
                if not s.startswith("|"):
                    break
                if set(s) <= set("|-: "):
                    continue  # separator row
                rows.append(split_cells(nxt))
            return rows
    return None


def check_inventory(sec_lines):
    """Check (1): returns a list of violation strings."""
    violations = []
    rows = premise_table_rows(sec_lines)
    if rows is None:
        return ["section 7.4 heading or premise-table header not found"]
    if len(rows) != len(REQUIRED_ROWS):
        violations.append(
            f"premise table has {len(rows)} data rows, expected "
            f"exactly {len(REQUIRED_ROWS)} (P1-P6)")
    labels = []
    for cells in rows:
        labels.append(cells[0] if cells else "")
        if len(cells) < 5:
            violations.append(
                f"premise row {cells[0] if cells else '<empty>'} has "
                f"{len(cells)} cells (< 5)")
        elif not cells[4]:
            violations.append(
                f"premise row {cells[0]} has an empty Price cell")
        elif not any(k.lower() in cells[4].lower()
                     for k in PRICE_KEYWORDS):
            violations.append(
                f"premise row {cells[0]} has a Price cell carrying "
                f"no price keyword (one of {PRICE_KEYWORDS}) -- a "
                f"non-empty cell is not a printed price")
    for req in REQUIRED_ROWS:
        if not any(lab.startswith(req) for lab in labels):
            violations.append(f"premise table is missing row {req}")
    return violations


def check_closing(sec_lines):
    """Check (2): returns a list of violation strings."""
    if sec_lines is None:
        return ["section 7.4 heading not found"]
    if CLOSING_SENTENCE not in "\n".join(sec_lines):
        return [f'section 7.4 does not contain the exact sentence '
                f'"{CLOSING_SENTENCE}"']
    return []


# ---- (3)(i) Kac ring recomputation (exact, exhaustive at N=4) ----

def kac_step(colours, flippers, n):
    """One tick: the ball at site i moves to site i+1 (mod n),
    toggling iff flippers[i] (the edge i -> i+1 is marked)."""
    nxt = [None] * n
    for i in range(n):
        nxt[(i + 1) % n] = colours[i] ^ (1 if flippers[i] else 0)
    return nxt


def kac_recomputation():
    """Returns (failures, witness) where witness is
    (colouring, placement, |D| trajectory) for one non-monotone case."""
    failures = []
    n = KAC_N
    period = 2 * n
    witness = None
    cases = 0
    for v0 in range(1 << n):
        colouring0 = [(v0 >> i) & 1 for i in range(n)]
        for fmask in range(1 << n):
            flippers = [bool((fmask >> i) & 1) for i in range(n)]
            cases += 1
            colours = list(colouring0)
            traj = [abs(2 * sum(colours) - n)]
            returned_at = None
            for t in range(1, period + 1):
                colours = kac_step(colours, flippers, n)
                traj.append(abs(2 * sum(colours) - n))
                if colours == colouring0 and returned_at is None:
                    returned_at = t
            if returned_at is None:
                failures.append(
                    f"Kac N={n}: no recurrence at or before 2N for "
                    f"colouring {v0:0{n}b}, placement {fmask:0{n}b}")
                if len(failures) > 5:
                    return failures, witness
            if witness is None:
                diffs = [traj[i + 1] - traj[i] for i in range(period)]
                if any(d > 0 for d in diffs) and any(d < 0 for d in diffs):
                    witness = (f"{v0:0{n}b}", f"{fmask:0{n}b}", traj)
    if cases != (2 ** n) * (2 ** n):
        failures.append(f"Kac cases {cases} != {2 ** n}x{2 ** n}")
    if witness is None:
        failures.append("Kac N=4: no non-monotone |imbalance| case "
                        "found in the exhaustive census")
    return failures, witness


def ehrenfest_recomputation():
    """(3)(ii): exact census shares at N=20. Returns failures."""
    failures = []
    n = EHRENFEST_N
    shares = [Fraction(comb(n, k), 2 ** n) for k in range(n + 1)]
    if sum(shares) != 1:
        failures.append("Ehrenfest shares do not sum to exactly 1")
    top = max(shares)
    argmax = [k for k in range(n + 1) if shares[k] == top]
    if argmax != [10]:
        failures.append(f"Ehrenfest N=20: argmax {argmax} != [10] "
                        f"(unique maximum required)")
    for k in (0, n):
        if shares[k] != Fraction(1, 2 ** n):
            failures.append(f"Ehrenfest N=20: extreme share at k={k} "
                            f"is {shares[k]} != 1/2^20")
    return failures


# ---- mutant battery: synthetic section-7.4 texts -------------------

def _synthetic_section(rows, closing):
    lines = ["### 7.4 The premise inventory", "", TABLE_HEADER,
             "|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {r} | supply | kac | urn | Priced [LEVEL A: AUTHOR] |")
    lines.append("")
    if closing:
        lines.append("The joint is open.")
    lines.append("")
    lines.append("## 8 Next section")
    return lines


def run_battery():
    failures = []
    good = _synthetic_section(REQUIRED_ROWS, True)
    if check_inventory(good) or check_closing(good):
        failures.append("battery control (complete synthetic section) "
                        "did not pass its own checks")
    missing_p3 = _synthetic_section(
        [r for r in REQUIRED_ROWS if r != "P3"], True)
    v = check_inventory(missing_p3)
    if not v:
        failures.append("mutant table missing P3 was NOT caught by "
                        "check (1)")
    else:
        print(f"  battery: MUTANT REJECTED (missing P3): check (1) "
              f"reports: {v[0]}")
    missing_p6 = _synthetic_section(
        [r for r in REQUIRED_ROWS if r != "P6"], True)
    v6 = check_inventory(missing_p6)
    if not v6:
        failures.append("mutant table missing P6 was NOT caught by "
                        "check (1)")
    else:
        print(f"  battery: MUTANT REJECTED (missing P6): check (1) "
              f"reports: {v6[0]}")
    no_closing = _synthetic_section(REQUIRED_ROWS, False)
    v2 = check_closing(no_closing)
    if not v2:
        failures.append("mutant section without the closing sentence "
                        "was NOT caught by check (2)")
    else:
        print(f"  battery: MUTANT REJECTED (no closing sentence): "
              f"check (2) reports: {v2[0]}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G3 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print("G3 battery: PASS (missing-P3 and missing-P6 tables caught; "
          "closing-sentence omission caught; control passes)")

    # Recomputation side runs regardless of the paper's state: the
    # toy facts are this script's own verified domain.
    kac_failures, witness = kac_recomputation()
    ehr_failures = ehrenfest_recomputation()
    if witness is not None:
        print(f"  recompute Kac N={KAC_N}: exhaustive "
              f"{(2 ** KAC_N) * (2 ** KAC_N)} cases; recurrence at or "
              f"before 2N={2 * KAC_N} for all cases; non-monotone "
              f"witness: colouring={witness[0]}, placement="
              f"{witness[1]}, |D| trajectory t=0..{2 * KAC_N}: "
              f"{witness[2]}")
    print(f"  recompute Ehrenfest N={EHRENFEST_N}: shares "
          f"C(20,k)/2^20 exact; unique maximum at k=10 "
          f"(share {Fraction(comb(20, 10), 2 ** 20)}); extreme "
          f"shares = 1/2^20 = {Fraction(1, 2 ** 20)}")
    failures = kac_failures + ehr_failures

    path = resolve_path()
    if not path.is_file():
        print(f"G3 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    sec = section_74_lines(lines)
    failures += check_inventory(sec)
    failures += check_closing(sec)

    if failures:
        print(f"G3 VIOLATIONS ({len(failures)}) for {path}:")
        for f in failures:
            print(f"  - {f}")
        return 1
    rows = premise_table_rows(sec)
    print(f"G3 PASS: {path}: section 7.4 premise table has exactly "
          f"{len(rows)} rows (P1-P6), each >= 5 cells with a "
          f"Price cell carrying a price keyword; \"{CLOSING_SENTENCE}\" present in "
          f"section 7.4; Kac N=4 recomputation exhaustive (recurrence "
          f"for all cases, non-monotone witness printed); Ehrenfest "
          f"N=20 shares verified exactly (unique max at k=10, "
          f"extremes 1/2^20); battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### G.4 Rewrite pairs — `G4_rewrite_pairs.py`

````python
#!/usr/bin/env python3
"""
G4_rewrite_pairs.py -- document check for Paper 12.5
("The Ensemble Illusion"), section 1.3.6 rewrite pairs.

PURPOSE: section 1.3.6 exhibits the paper's method in miniature:
six standard idioms, each printed as found (Account A, an exhibit,
quotation-marked) and rewritten in census form (Account B). This
check proves the assembled paper's table is complete and that
every Account B actually is a census form: it speaks of a declared
population over a declared window, carries none of the banned
micro/macro vocabulary, and uses no probability language at all
(the framework adopts no probability postulate; the rewrites are
written to satisfy this, and this script enforces it).

CHECKS:
  (1) Locate "### 1.3.6"; parse its table by the exact header
        | # | Account A — the idiom as printed (exhibit) | Account B — the census form | What changed |
      (em-dashes as printed; this header string is the spec -- if
      the assembled paper differs, assembly aligns the paper to it).
  (2) Assert exactly 6 pair rows, numbered 1-6. For each row:
      - Account A cell is non-empty and contains a double-quote
        character (the exhibit marking);
      - Account B cell contains "population" and "window"
        (case-insensitive);
      - Account B cell contains NO match of the micro/macro regex
        micro\\w*scopic|macro\\w*scopic (case-insensitive);
      - Account B cell does not contain "probabilit" at all
        (case-insensitive).

MUTANT BATTERY (built in, run on synthetic rows, not the paper):
  five planted defective rows must each be CAUGHT by the same row
  check used on the paper -- (a) a B cell without "window",
  (b) a B cell carrying a banned micro/macro token, (c) an A cell
  without quotation marks, (d) a B cell carrying probability
  language, (e) a B cell without "population" -- and one clean
  synthetic row must pass. (Header corrected in v3: the v1/v2
  header named only the first three classes after the battery was
  completed to five.)

INPUT_PROVENANCE:
  paper-defined:
    - The six rewrite pairs and their four-column shape: Paper
      12.5 section 1.3.6 as assembled (the document side of this
      check audits that text; the header string is the layout
      contract, copied exactly from the drafting spec).
    - The B-cell conditions: the paper's own census form (a
      declared population, a declared window), Paper 12's standing
      no-micro/macro correction, and the framework's no-probability-
      postulate rule (cf. FW1 ban (c)).
  cited-paper:
    - Paper 12 census rule (frequencies = census ratios of actual
      counts over declared windows): the form Account B must take;
      contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      default path relative to this script.
  declared-assumption:
    - The rewrite-pairs table is the table in section 1.3.6 whose
      header row equals the exact header string above; data rows
      are the following pipe rows up to the first non-pipe line.
  arbitrary-representative:
    - The battery's synthetic rows: representatives of each
      failure class, not quotations from any source.

Exit 0 iff the battery passes AND the paper table passes.
Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

TABLE_HEADER = ("| # | Account A — the idiom as printed (exhibit) | "
                "Account B — the census form | What changed |")
MICRO_RE = re.compile(r"micro\w*scopic|macro\w*scopic", re.IGNORECASE)
N_PAIRS = 6


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def split_cells(line):
    parts = line.strip().split("|")
    if parts and parts[0].strip() == "":
        parts = parts[1:]
    if parts and parts[-1].strip() == "":
        parts = parts[:-1]
    return [p.strip() for p in parts]


def section_136_lines(lines):
    """Lines of section 1.3.6: from the '### 1.3.6' heading to the
    next heading of level <= 3 (or end of file)."""
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("### 1.3.6"):
            start = i
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if re.match(r"^#{1,3}\s", lines[j]):
            end = j
            break
    return lines[start:end]


def pairs_table_rows(sec_lines):
    """Data rows (cell lists) of the rewrite-pairs table, found by
    its exact header. None if the header is absent."""
    if sec_lines is None:
        return None
    for i, line in enumerate(sec_lines):
        if line.strip() == TABLE_HEADER:
            rows = []
            for nxt in sec_lines[i + 1:]:
                s = nxt.strip()
                if not s.startswith("|"):
                    break
                if set(s) <= set("|-: "):
                    continue  # separator row
                rows.append(split_cells(nxt))
            return rows
    return None


def check_row(cells):
    """Check (2) for one row: returns a list of violation strings.
    cells = [#, Account A, Account B, What changed]."""
    violations = []
    if len(cells) < 4:
        return [f"row has {len(cells)} cells (< 4): {cells}"]
    a_cell, b_cell = cells[1], cells[2]
    if not a_cell:
        violations.append("Account A cell is empty")
    elif '"' not in a_cell:
        violations.append("Account A cell carries no double-quote "
                          "(exhibit marking missing)")
    low_b = b_cell.lower()
    if "population" not in low_b:
        violations.append('Account B cell does not contain '
                          '"population"')
    if "window" not in low_b:
        violations.append('Account B cell does not contain "window"')
    m = MICRO_RE.search(b_cell)
    if m:
        violations.append(f"Account B cell carries the banned token "
                          f"{m.group(0)!r} (micro/macro vocabulary)")
    if "probabilit" in low_b:
        violations.append('Account B cell contains "probabilit..." '
                          "(probability language is banned in the "
                          "census form)")
    return violations


def check_table(sec_lines):
    """Checks (1)+(2) over a section's lines: returns violations."""
    violations = []
    rows = pairs_table_rows(sec_lines)
    if rows is None:
        return ["section 1.3.6 heading or rewrite-pairs table header "
                "not found"]
    if len(rows) != N_PAIRS:
        violations.append(f"rewrite-pairs table has {len(rows)} data "
                          f"rows, expected exactly {N_PAIRS}")
    for idx, cells in enumerate(rows, start=1):
        num = cells[0] if cells else ""
        if num != str(idx):
            violations.append(f"row {idx} is numbered {num!r}, "
                              f"expected {idx}")
        for v in check_row(cells):
            violations.append(f"row {idx}: {v}")
    return violations


# ---- mutant battery: synthetic rows --------------------------------

CLEAN_ROW = ["1", '"The ensemble average gives the pressure."',
             "The counted share of records in the declared "
             "population over the declared window gives the mean.",
             "Idiom replaced by a census ratio."]


def run_battery():
    failures = []
    if check_row(CLEAN_ROW):
        failures.append(f"battery control row did not pass: "
                        f"{check_row(CLEAN_ROW)}")
    mutants = [
        ("B cell without \"window\"",
         ["2", '"quoted idiom"', "The counted share of the declared "
          "population gives the mean.", "change"]),
        ("B cell with a banned token",
         ["3", '"quoted idiom"', "The macroscopic population over "
          "the declared window is counted.", "change"]),
        ("A cell without quotes",
         ["4", "The ensemble average gives the pressure.",
          "The counted share of the declared population over the "
          "declared window.", "change"]),
        ("B cell with probability language",
         ["5", '"quoted idiom"', "The probability that a record of "
          "the declared population falls in the class, over the "
          "declared window.", "change"]),
        ("B cell without \"population\"",
         ["6", '"quoted idiom"', "The counted share of records over "
          "the declared window gives the mean.", "change"]),
    ]
    for label, row in mutants:
        v = check_row(row)
        if not v:
            failures.append(f"mutant NOT caught: {label}")
        else:
            print(f"  battery: MUTANT REJECTED ({label}): {v[0]}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("G4 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print("G4 battery: PASS (5 planted defective rows caught, clean "
          "row passed)")

    path = resolve_path()
    if not path.is_file():
        print(f"G4 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    sec = section_136_lines(lines)
    violations = check_table(sec)
    if violations:
        print(f"G4 VIOLATIONS ({len(violations)}) for {path}:")
        for v in violations:
            print(f"  - {v}")
        return 1
    rows = pairs_table_rows(sec)
    print(f"G4 PASS: {path}: section 1.3.6 rewrite-pairs table has "
          f"exactly {len(rows)} rows numbered 1-6; every Account A "
          f"is a quoted exhibit; every Account B names a population "
          f"and a window, carries no micro/macro token and no "
          f"probability language; battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### FW.1 Firewall — `FW1_firewall_125.py`

````python
#!/usr/bin/env python3
"""
FW1_firewall_125.py -- own-voice firewall scan for Paper 12.5
("The Ensemble Illusion").

PURPOSE: the paper audits other people's language; its OWN voice
must not commit the offences it audits. This scan enforces three
standing bans on the paper's prose (fenced code blocks excluded --
 listings are exhibits, not the paper's voice):

  (a) MICRO/MACRO BAN: the tokens "microscopic" / "macroscopic"
      must not appear in the paper's own voice. Quotation contexts
      are exempt: a line containing a double-quote character, or a
      blockquote line (first non-space character ">"), is quoting
      or exhibiting the standard vocabulary, not using it.
  (b) NEUTRINO BAN: the framework bans neutrinos as travelling
      particles. The paper may mention the word ONLY on a line
      that also carries the ban -- the word "ban" or an inflection
      of it ("bans", "banned", "banning", "bannings") as a WHOLE
      WORD (word-boundary match, not followed by a hyphen or a
      word character, so a hyphen compound such as "ban-worthy"
      does not exempt) -- or points at the framework's treatment
      ("Paper 15"). (v3 repair, recorded: the v1/v2 exemption
      tested the substring "ban" anywhere on the line, so an
      unrelated word containing those letters -- "abandoned"
      is the printed example -- washed a neutrino line clean.
      The whole-word test closes that wash; battery violator (d)
      plants exactly that case and violator (e) the hyphen
      compound, and both must now be CAUGHT.)
  (c) NO ADOPTED PROBABILITY POSTULATE: the paper's framework
      adopts none. Lines matching
        (?i)we (adopt|assume).{0,60}probabilit
      are flagged -- the paper's own "we adopt / we assume" must
      never attach to probability language.

MUTANT BATTERY (built in, run on synthetic strings, not the paper):
  five planted violating lines must each be CAUGHT by the same scan
  function used on the paper -- one per ban group, plus violator
  (d): a neutrino line carrying "abandoned", the word whose "ban"
  substring washed such lines under the v1/v2 exemption, and
  violator (e): a neutrino line whose only ban-shaped token is the
  hyphen compound "ban-worthy" -- and three clean lines must pass,
  including a line that carries the ban in its own words. Battery
  failure = script failure.

INPUT_PROVENANCE:
  paper-defined:
    - Ban (a): Paper 12's standing correction -- no micro/macro
      split; "it's all relational" (author's ruling, binding on
      this companion critique).
    - Ban (b): the series' neutrino ban (framework record since
      the Papers 1-10 synopsis: "The Non-Existent Neutrino").
    - Ban (c): Paper 12's dissolution of the measure postulate --
      the framework has no probability postulate to adopt.
  cited-paper:
    - Paper 12 (census rule; no probability postulate) and
      Paper 15 (the ban's home treatment): cited as the bans'
      sources; contents not re-derived here.
  control:
    - The paper path itself: argv[1], else $PAPER_MD, else the
      first existing of ../Paper_12_5_v3.md and
      ../../Paper_12_5_v3.md relative to this script, else the
      delivered copy under ~/workspace/paper_12_5_delivery/.
  declared-assumption:
    - Quotation context := line contains '"' or begins (after
      whitespace) with '>' (declared here, per the task spec).
    - Ban (b) exemption := line carries the whole word "ban",
      "bans", "banned", "banning" or "bannings", not followed by
      a hyphen or a word character (word-boundary regex,
      case-insensitive; v3 repair of the v1/v2 substring test --
      see the ban (b) note above) or "Paper 15" (literally).
  arbitrary-representative:
    - The battery's synthetic lines: representatives of each
      offence class, not quotations from any source.

Exit 0 iff the battery passes AND the paper scan finds 0 hits.
Python 3 stdlib only.
"""

import os
import re
import sys
from pathlib import Path

MICRO_RE = re.compile(r"micro\w*scopic|macro\w*scopic", re.IGNORECASE)
NEUTRINO_RE = re.compile(r"neutrino", re.IGNORECASE)
BAN_WORD_RE = re.compile(r"\bban(?:s|ned|nings?)?\b(?![-\w])",
                         re.IGNORECASE)
ADOPT_RE = re.compile(r"we (adopt|assume).{0,60}probabilit",
                      re.IGNORECASE)


def resolve_path():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in [here.parent / "Paper_12_5_v3.md",
                 here.parent.parent / "Paper_12_5_v3.md",
                 Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md"]:
        if cand.exists():
            return cand
    return here.parent / "Paper_12_5_v3.md"


def scan_lines(lines):
    """Scan prose lines; returns (hits, n_prose_lines, exemptions).

    hits: list of (group, line_number_1based, line_text).
    exemptions: lines where ban (a)'s token matched inside a
    quotation context -- not hits, but LISTED, so the exemption is
    inspected rather than silent (loop repair: two legitimate
    attributed-paraphrase lines previously passed by punctuation
    accident; they are now printed in the run record).
    Fenced code blocks are excluded (listings are exhibits).
    """
    hits = []
    exemptions = []
    in_fence = False
    n_prose = 0
    for idx, line in enumerate(lines, start=1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        n_prose += 1
        # (a) micro/macro outside quotation contexts
        is_quote_ctx = ('"' in line) or line.lstrip().startswith(">")
        if MICRO_RE.search(line) and is_quote_ctx:
            exemptions.append((idx, line.strip()))
        if MICRO_RE.search(line) and not is_quote_ctx:
            hits.append(("a:micro/macro", idx, line.strip()))
        # (b) neutrino without the whole word ban/bans/banned/
        # banning/bannings (not hyphen-compounded) or Paper 15 on
        # the line (v3: word-boundary match; the v1/v2 substring
        # test let "abandoned" wash the line)
        if NEUTRINO_RE.search(line):
            if not BAN_WORD_RE.search(line) and "Paper 15" not in line:
                hits.append(("b:neutrino", idx, line.strip()))
        # (c) adopted probability postulate
        if ADOPT_RE.search(line):
            hits.append(("c:adopt-probability", idx, line.strip()))
    return hits, n_prose, exemptions


# ---- mutant battery: synthetic strings, never the paper ----
BATTERY_VIOLATORS = [
    ("a:micro/macro",
     "The microscopic state of each unit fixes the outcome."),
    ("b:neutrino",
     "The neutrino travels from the source to the detector."),
    ("c:adopt-probability",
     "We adopt a probability postulate for the ledger."),
    # (d) v3: the substring-wash case. Under the v1/v2 exemption
    # this line PASSED ("ban" inside "abandoned"); under the
    # whole-word exemption it must be CAUGHT.
    ("b:neutrino",
     "The neutrino flux was abandoned by the analysis team."),
    # (e) v3 loop repair: the hyphen-compound wash. The compound
    # carries the lexeme but does not state the ban; it must be
    # CAUGHT.
    ("b:neutrino",
     "The neutrino passage is ban-worthy prose."),
]
BATTERY_CLEAN = [
    "The census counts every record in the declared window.",
    '"microscopic" is the standard term under audit in this section.',
    # v3: a line carrying the ban in its own words stays clean
    # under the whole-word test (the paper's own exemption lines
    # are of this form).
    "The framework bans the neutrino as a travelling particle.",
]


def run_battery():
    failures = []
    for expected_group, line in BATTERY_VIOLATORS:
        hits, _, _ = scan_lines([line])
        groups = {g for g, _, _ in hits}
        if expected_group not in groups:
            failures.append(
                f"violator not caught ({expected_group}): {line!r}")
    for line in BATTERY_CLEAN:
        hits, _, _ = scan_lines([line])
        if hits:
            failures.append(f"clean line flagged: {line!r} -> {hits}")
    return failures


def main():
    battery_failures = run_battery()
    if battery_failures:
        print("FW1 BATTERY FAIL:")
        for f in battery_failures:
            print(f"  - {f}")
        return 1
    print(f"FW1 battery: PASS ({len(BATTERY_VIOLATORS)} planted "
          f"violators caught, {len(BATTERY_CLEAN)} clean lines passed)")

    path = resolve_path()
    if not path.is_file():
        print(f"FW1 FAIL: paper not found: {path}")
        return 1
    lines = path.read_text(encoding="utf-8").splitlines()
    hits, n_prose, exemptions = scan_lines(lines)
    print(f"FW1 scan: {path}: prose_lines_scanned={n_prose} "
          f"hits={len(hits)}")
    for lineno, text in exemptions:
        print(f"  EXEMPTED (quoted context, listed for inspection) "
              f"line {lineno}: {text[:110]}")
    if hits:
        for group, lineno, text in hits:
            print(f"  HIT [{group}] line {lineno}: {text}")
        print("FW1 FAIL: own-voice firewall violations present")
        return 1
    print("FW1 PASS: 0 hits on the paper; battery green.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### RB.1 Suite runner — `RB1_run_all.py`

````python
#!/usr/bin/env python3
# RB1_run_all.py -- Paper 12.5 verification suite runner.
#
# INPUT_PROVENANCE:
#   paper-defined:      the suite membership (Paper 12.5 section 0.5.4 protocol
#                       table): E1-E6, M1-M2, G1-G4, FW1.
#   control:            the paper path passed as argv[1] (or $PAPER_MD); the
#                       document scripts (G1, G2, G3, G4, FW1) audit that file.
#   declared-assumption: NONE.
#
# WHAT THIS RUNNER CHECKS: that every script in the suite exits 0 against the
# FINAL tree it is pointed at, in suite order, in one process record. It does
# not re-check any script's internal claims; each script carries its own
# provenance and domain disclosure. A green RB.1 run means: the suite as a
# whole passed on the exact paper file named in the run record -- nothing more.
#
# Usage: python3 RB1_run_all.py [path-to-Paper_12_5_v3.md]
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def resolve_paper(argv):
    if len(argv) > 1:
        return Path(argv[1])
    env = os.environ.get("PAPER_MD")
    if env:
        return Path(env)
    for cand in [
        HERE.parent / "Paper_12_5_v3.md",
        HERE.parent.parent / "Paper_12_5_v3.md",
        Path.home() / "workspace" / "paper_12_5_delivery" / "Paper_12_5_v3.md",
    ]:
        if cand.exists():
            return cand
    return HERE.parent / "Paper_12_5_v3.md"


SUITE = [
    ("E1_census_arrow.py", False),
    ("E2_negative_temperature.py", False),
    ("E3_gibbs_paradox.py", False),
    ("E4_kac_ring.py", False),
    ("E5_quantum_census.py", False),
    ("E6_bayesian_updating.py", False),
    ("M1_canonical_recipe.py", False),
    ("M2_ehrenfest.py", False),
    ("G1_history_consistency.py", True),
    ("G2_matrix_completeness.py", True),
    ("G3_premise_inventory.py", True),
    ("G4_rewrite_pairs.py", True),
    ("FW1_firewall_125.py", True),
]


def main():
    paper = resolve_paper(sys.argv)
    print(f"RB1 run-all: paper = {paper}")
    if not paper.exists():
        print("RB1 FAIL: paper file not found")
        return 1
    failures = []
    t0 = time.time()
    for name, needs_paper in SUITE:
        script = HERE / name
        cmd = [sys.executable, str(script)]
        if needs_paper:
            cmd.append(str(paper))
        t = time.time()
        proc = subprocess.run(cmd, capture_output=True, text=True)
        dt = time.time() - t
        status = "PASS" if proc.returncode == 0 else "FAIL"
        last = ""
        for line in (proc.stdout or "").splitlines():
            if "PASS" in line or "FAIL" in line or "REJECTED" in line:
                last = line.strip()
        print(f"  [{status}] {name} ({dt:.1f}s) {last[:150]}")
        if proc.returncode != 0:
            failures.append(name)
            tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-15:])
            print(f"    --- output tail ---\n{tail}")
    total = time.time() - t0
    if failures:
        print(f"RB1 FAIL: {len(failures)} script(s) failed: {failures} ({total:.1f}s)")
        return 1
    print(f"RB1 PASS: {len(SUITE)}/{len(SUITE)} scripts exit 0 on the final tree ({total:.1f}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````
