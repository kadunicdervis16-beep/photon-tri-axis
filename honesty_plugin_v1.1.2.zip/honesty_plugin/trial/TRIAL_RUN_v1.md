# TRIAL RUN v1 — honesty_plugin against the Paper 12.5 v3 verification package

**Scope of this document (read first).** This is an instrument smoke
test on ONE house corpus (the plugin author's own series package).
§3's registry was constructed from the package's own MANIFEST, so its
PASS establishes pointer-existence plumbing only; its `checks` fields
are the scripts' own header lines, so the token counts are weak
evidence by construction and are printed, not leaned on. NO section
of this trial bears on symmetry between corpora, on metrics M1–M5,
or on any standard-side corpus — none has been scored. The trial
evidences: the six tools run, the disclosure discipline holds, and
the planted-mutant battery is caught. Nothing more.

Package under test: `/home/hatch/workspace/paper_12_5_delivery/Paper_12_5_v3_verification_package.zip`
Corpus zip sha256: `0eb716aa43de45215a69511845cafc8604a7a8c9fe3e09af0fc336def72e2f88` (extracted fresh to `trial/extracted/`).
Instrument: honesty_plugin v1 (src layout), criteria v1.0, FREEZE 2026-11-08.
Freeze hash: 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c (source: manifest-verified).
Instrument manifest: sha256 2c07338cb3ea926b069dc5bfecc27ce3f566b96607d5de5c16efd5d80f3bee4f (pins src/, tests/, trial/run_trial.py).
Python: 3.12.3 on Linux.
Every section below is a tool's actual output from this run, reproduced
verbatim. The registry in §3/§6/§8 was constructed from the package's own
MANIFEST.sha256 (one entry per listed script) — a declared construction,
since the package ships no registry JSON of its own.

## 1. run_verification_suite — the package's own 13 scripts + RB1 runner

```text
TOOL: run_verification_suite
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: the verification claims of the named package, as a whole
  verified domain: exit codes of the package's own scripts in THIS environment: each listed script run once in a fresh subprocess, with the paper file passed as argument only where the runner's own flags say so; the runner (if executed) re-runs the suite
  map: script file -> subprocess execution; suite membership taken from the package's own RB1-style runner where one exists
  preserves: per-script pass/fail under each script's own exit contract (exit 0 = pass)
  outside: whether any script's assertions actually check its claim's content (that is M4 fidelity — a human/deep audit, not this tool); premise truth; behaviour in other environments; scripts the runner does not list. SECURITY: the scripts execute with the caller's privileges, unsandboxed — run only packages you trust, or inside a sandbox

package root: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification
paper file: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md
plan: suite membership + paper-argument flags taken from runner RB1_run_all.py (RB1-style); the runner is then executed once itself, which RE-RUNS the suite — that line is a second, aggregate observation, not independent evidence

  [PASS] E1_census_arrow.py (exit 0, 0.05s) — the script's own last line: "E1 PASS: n=2..16 enumerated; non-polarized share >= (n-1)/n for all n, equality only at n=2 (share 1/2); at n=16 nonpol_share=32767/32768; balanced share strictly decreasing over even n: n=2:1/2, n=4: […truncated]"
  [PASS] E2_negative_temperature.py (exit 0, 0.05s) — the script's own last line: "E2 PASS: bounded census slope flips sign at k=N/2 for every N=4..24 (even N: strict rise then strict fall; odd N: strict rise, equal central pair, strict fall; e.g. N=24 Omega(12)=2704156, first fall  […truncated]"
  [PASS] E3_gibbs_paradox.py (exit 0, 0.04s) — the script's own last line: "E3 PASS: for all N=1..8, Rule-A identical mixing factor = C(2N,N) > 1 (N=8: 12870); Rule-B identical factor == 1 exactly for all N; Rule-B distinct factor == Rule-A distinct factor (rule ratio 1 for d […truncated]"
  [PASS] E4_kac_ring.py (exit 0, 51.95s) — the script's own last line: "E4 PASS: recurrence at 2N verified exhaustively in 1398016 cases (N=4..10; per N: 4^N cases, N=10 alone 1048576); non-monotone witness printed above and re-verified; minimum balanced time-share over a […truncated]"
  [PASS] E5_quantum_census.py (exit 0, 0.05s) — the script's own last line: "E5 PASS: (1) census eigenvalues (3/4, 1/4) vs ascribed (1, 0), trace distance exactly 1/4, entropy gap 0.562335 nats > 0.5 (floats, disclosed); (2) honest mixture distance exactly 0, entropies agree;  […truncated]"
  [PASS] E6_bayesian_updating.py (exit 0, 0.04s) — the script's own last line: "E6 PASS: census A counted mean computed = 4/7; factorisation 10r^2 + 3r - 4 = (2r - 1)(5r + 4) verified coefficient-wise; unique positive root r = 1/2 (root -4/5 excluded as a weight); posterior compu […truncated]"
  [PASS] M1_canonical_recipe.py (exit 0, 1.23s) — the script's own last line: "M1 PASS: canonical sampler matches enumerated recipe targets at all 4 beta values (tol_mean=0.2, tol_share=0.025); uniform-weight run converges to the beta=0 census; sign-flipped mutant rejected at ev […truncated]"
  [PASS] M2_ehrenfest.py (exit 0, 2.02s) — the script's own last line: "M2 PASS: empirical shares match census shares C(20,k)/2^20 within tol=0.008 (max_abs_dev=0.000402); recurrence to k=0 is exactly 1048576 steps by census share; biased mutant rejected."
  [PASS] G1_history_consistency.py (exit 0, 0.09s) — the script's own last line: "G1 PASS: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md: appendix_pairs=21 body_pairs=21 (sets equal); appendix rows=21 all carry years; C34 + falsificat […truncated]"
  [PASS] G2_matrix_completeness.py (exit 0, 0.05s) — the script's own last line: "G2 PASS: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md: audit matrix has exactly 6 rows (Microcanonical, Grand canonical, Canonical, Ergodic, Coarse-gra […truncated]"
  [PASS] G3_premise_inventory.py (exit 0, 0.05s) — the script's own last line: "G3 PASS: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md: section 7.4 premise table has exactly 6 rows (P1-P6), each >= 5 cells with a Price cell carrying […truncated]"
  [PASS] G4_rewrite_pairs.py (exit 0, 0.05s) — the script's own last line: "G4 PASS: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md: section 1.3.6 rewrite-pairs table has exactly 6 rows numbered 1-6; every Account A is a quoted e […truncated]"
  [PASS] FW1_firewall_125.py (exit 0, 0.06s) — the script's own last line: "FW1 PASS: 0 hits on the paper; battery green."
  [PASS] RB1_run_all.py (runner, re-runs the suite) (exit 0, 55.06s) — the script's own last line: "RB1 PASS: 13/13 scripts exit 0 on the final tree (55.0s)"

RESULT: PASS — 13/13 listed scripts exited 0; runner exited 0
```

## 2. lint_provenance — the package's scripts directory

```text
TOOL: lint_provenance
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: premise/provenance completeness of the named scripts (PROV-COMPLETE)
  verified domain: presence of INPUT_PROVENANCE blocks (header anchored in comments or docstrings only), the provenance classes declared in them, and module-level literal bindings whose names do not appear in the block — a HEURISTIC scan
  map: script source -> comment/docstring extraction + AST scan of top-level literal assignments
  preserves: block presence, declared class labels, and name-level coverage
  outside: whether a binding that IS named in the block is classified CORRECTLY; bindings built by expressions, function calls, or imports (not literal top-level assignments) are outside this scan; premise soundness. 'Unclassified' below means 'not detected as classified by this heuristic', not 'proven unclassified'

target: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts
scripts scanned: 14

  [BLOCK]    E1_census_arrow.py — classes detected: cited-paper, control, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E2_negative_temperature.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E3_gibbs_paradox.py — classes detected: cited-paper, control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E4_kac_ring.py — classes detected: control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E5_quantum_census.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 1; not detected in block: (none)
  [BLOCK]    E6_bayesian_updating.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 3; not detected in block: ENERGIES, CENSUS_A_COUNTS, CENSUS_B_COUNTS
  [BLOCK]    FW1_firewall_125.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 2; not detected in block: BATTERY_VIOLATORS, BATTERY_CLEAN
  [BLOCK]    G1_history_consistency.py — classes detected: arbitrary-representative, control, declared-assumption, paper-defined; literal bindings: 8; not detected in block: CANON, WINDOW, _BATTERY_HEAD, _BATTERY_APP_OPEN, _BATTERY_APP_CLOSE, BATTERY_CASES
  [BLOCK]    G2_matrix_completeness.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 2; not detected in block: REQUIRED, MIN_CELLS
  [BLOCK]    G3_premise_inventory.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 6; not detected in block: TABLE_HEADER, REQUIRED_ROWS, CLOSING_SENTENCE, PRICE_KEYWORDS, KAC_N, EHRENFEST_N
  [BLOCK]    G4_rewrite_pairs.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 3; not detected in block: TABLE_HEADER, N_PAIRS, CLEAN_ROW
  [BLOCK]    M1_canonical_recipe.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 8; not detected in block: EPSILON, BETA_GRID
  [BLOCK]    M2_ehrenfest.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 7; not detected in block: MUTANT_SEED
  [BLOCK]    RB1_run_all.py — classes detected: control, declared-assumption, paper-defined; literal bindings: 1; not detected in block: SUITE

RESULT: PASS-WITH-WARNINGS — blocks detected in 14/14 scripts; 26 literal binding(s) not detected as classified (heuristic); 0 block(s) with zero classes parsed
```

## 3. check_registry_pointers — registry constructed from the package MANIFEST

```text
TOOL: check_registry_pointers
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: registry integrity: every badged claim points at a script that checks its content
  verified domain: existence of each pointed file, plus a DECLARED-CONTENT TOKEN HEURISTIC for entries that declare what they check
  map: registry JSON entries -> filesystem paths relative to the registry (or base_dir)
  preserves: the claim->script pointer structure and nothing else
  outside: whether the pointed script's assertions actually range over the claim's content (full AST claim matching is NOT implemented in v1; the token overlap is a heuristic signal, not a fidelity verdict — M4 fidelity remains a deep-audit task)

registry: /home/hatch/workspace/honesty_plugin/trial/registry_trial.json
base dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification
entries: 14

  [OK]      E1_census_arrow -> scripts/E1_census_arrow.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E2_negative_temperature -> scripts/E2_negative_temperature.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E3_gibbs_paradox -> scripts/E3_gibbs_paradox.py; declared-content tokens found 6/6 (whole-word heuristic)
  [OK]      E4_kac_ring -> scripts/E4_kac_ring.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      E5_quantum_census -> scripts/E5_quantum_census.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      E6_bayesian_updating -> scripts/E6_bayesian_updating.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      FW1_firewall_125 -> scripts/FW1_firewall_125.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G1_history_consistency -> scripts/G1_history_consistency.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G2_matrix_completeness -> scripts/G2_matrix_completeness.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G3_premise_inventory -> scripts/G3_premise_inventory.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G4_rewrite_pairs -> scripts/G4_rewrite_pairs.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      M1_canonical_recipe -> scripts/M1_canonical_recipe.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      M2_ehrenfest -> scripts/M2_ehrenfest.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      RB1_run_all -> scripts/RB1_run_all.py; declared-content tokens found 4/4 (whole-word heuristic)

RESULT: PASS — 14/14 pointed scripts exist (0 missing/escaped); 0 duplicate claim_id(s); 0 token gap(s)
```

## 4. fence_and_listing_check — the real paper vs its standalone scripts

```text
TOOL: fence_and_listing_check
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: identity between the paper's embedded listings and the standalone script files, plus fence integrity (BYTE-REPRO)
  verified domain: fence pairing (>=3-backtick fences, markdown closing rule) and fused-fence scan over the named markdown file; content matching of each fenced block against the named files — matched by CONTENT, never by position or shared header lines
  map: markdown text -> fence map + per-block content comparison
  preserves: per-block identity with its KIND printed: EXACT (byte-identical up to one trailing newline) or NORMALIZED (equal only after whole-block leading/trailing-whitespace and line-ending normalization); fence structure; fused-fence suspects
  outside: blocks that are not script listings (examples, shell snippets) report as unmatched and require human classification; whether the prose AROUND the listings describes them accurately; fused fences whose corruption leaves no line ending in ``` (a stated residual)

markdown: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md
files dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts
fence blocks paired: 14; unpaired fence lines: 0 (parity OK)

fenced blocks: 14; matched to a file by content: 14 (EXACT: 14, NORMALIZED: 0)
  [MATCH-EXACT] block at line 4312 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E1_census_arrow.py  (marker: 'E1_census_arrow.py -- Full census of binary records (Paper 12.5 / Paper 12 S8).')
  [MATCH-EXACT] block at line 4469 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E2_negative_temperature.py  (marker: 'E2_negative_temperature.py -- Bounded-population census (Ramsey counting form).')
  [MATCH-EXACT] block at line 4650 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E3_gibbs_paradox.py  (marker: 'E3_gibbs_paradox.py -- Exact mixing counts under two counting RULES.')
  [MATCH-EXACT] block at line 4854 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E4_kac_ring.py  (marker: 'E4_kac_ring.py -- Kac ring, exact and exhaustive at small size.')
  [MATCH-EXACT] block at line 5107 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E5_quantum_census.py  (marker: 'E5_quantum_census.py -- Stage P/C audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 5533 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E6_bayesian_updating.py  (marker: 'E6_bayesian_updating.py -- MaxEnt / Bayesian updating read against')
  [MATCH-EXACT] block at line 5861 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/M1_canonical_recipe.py  (marker: 'M1_canonical_recipe.py -- Monte-Carlo audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 6125 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/M2_ehrenfest.py  (marker: 'M2_ehrenfest.py -- Ehrenfest urn audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 6331 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G1_history_consistency.py  (marker: '# G1_history_consistency.py -- Paper 12.5 document check: the (year,')
  [MATCH-EXACT] block at line 6774 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G2_matrix_completeness.py  (marker: 'G2_matrix_completeness.py -- document check for Paper 12.5')
  [MATCH-EXACT] block at line 6962 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G3_premise_inventory.py  (marker: 'G3_premise_inventory.py -- document + recomputation check for')
  [MATCH-EXACT] block at line 7346 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G4_rewrite_pairs.py  (marker: 'G4_rewrite_pairs.py -- document check for Paper 12.5')
  [MATCH-EXACT] block at line 7615 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/FW1_firewall_125.py  (marker: 'FW1_firewall_125.py -- own-voice firewall scan for Paper 12.5')
  [MATCH-EXACT] block at line 7844 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/RB1_run_all.py  (marker: '# RB1_run_all.py -- Paper 12.5 verification suite runner.')

RESULT: PASS — fence parity OK; 0 fused-fence suspect(s); 14/14 blocks matched by content (EXACT 14, NORMALIZED 0)
```

## 5. param_prov — demonstration table (instrument trial, not a scoring run)

```text
TOOL: param_prov
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: free-parameter provenance accounting for the named table (PARAM-PROV)
  verified domain: classification of the table's entries per provenance class under the table's OWN named counting convention, and counts per class
  map: JSON parameter table -> class validation + counting
  preserves: provenance structure of the declared entries, with the convention attached
  outside: whether fewer or differently-classed inputs is a virtue (a theory-choice judgement, not bookkeeping); empirical adequacy; any total computed under a different convention. A count match or count advantage establishes nothing (FREEZE v1.0 §2). The verdict guard is a tripwire over known phrasings (listed in the source), not a semantic guarantee: verdicts encoded purely numerically, in other languages, or without comparative vocabulary can evade it and are outside this check — the substantive rule is the freeze's banned-constructions rule on human-written reports

table: /home/hatch/workspace/honesty_plugin/trial/fixtures/param_demo.json
counting convention: instrument-trial demonstration convention (NOT a scoring corpus)
entries: 5

per-entry classification:
  example_measured_mass: measured-input
  example_fitted_coupling: fitted
  example_window_choice: declared-assumption
  example_count_ratio: derived-from-structure
  example_representative_configuration: arbitrary-representative

counts per provenance class (under the convention named above):
  derived-from-structure: 1
  measured-input: 1
  fitted: 1
  declared-assumption: 1
  arbitrary-representative: 1

GUARD: no comparative verdict is emitted from these totals (FREEZE v1.0 §2, §6). Totals are bookkeeping under the named convention only; counts change under other conventions — re-run under each convention and report side by side.

RESULT: PASS — 5 entries classified under convention 'instrument-trial demonstration convention (NOT a scoring corpus)'
```

## 6. audit_dashboard — assembled (suite shown separately in §1, not re-run)

```text
TOOL: audit_dashboard
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: the comparative honesty dashboard for the named package
  verified domain: the assembled outputs of the mechanical checks actually run, below; each keeps its own disclosure and its own verified domain
  map: package -> per-check tool runs -> per-check dashboard lines
  preserves: per-check counts exactly as each tool established them
  outside: metrics M1–M5 (human-coding metrics — NOT scored by this instrument); any check not listed below was NOT run; empirical truth and every comparative conclusion. INPUT CONTRACTS: every input this instrument consumes is a house format (RB1-style runner tuples, INPUT_PROVENANCE blocks, this project's JSON schemas) — a corpus not already in those formats cannot be fed without a translation step that is itself unaudited (README: 'Input contracts')

package root: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification

DASHBOARD (per-check lines with counts; NO composite index is computed — FREEZE v1.0 §3):
  lint_provenance: PASS-WITH-WARNINGS  [14/14 blocks, 26 unclassified]
  check_registry_pointers: PASS  [0 missing of 14]
  fence_and_listing_check: PASS  [14/14 blocks matched]
  param_prov: PASS  [5 entries]
  run_verification_suite: NOT RUN in this dashboard (re-run with run_suite=true to include it)

----- full per-check reports -----

===== lint_provenance =====
TOOL: lint_provenance
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: premise/provenance completeness of the named scripts (PROV-COMPLETE)
  verified domain: presence of INPUT_PROVENANCE blocks (header anchored in comments or docstrings only), the provenance classes declared in them, and module-level literal bindings whose names do not appear in the block — a HEURISTIC scan
  map: script source -> comment/docstring extraction + AST scan of top-level literal assignments
  preserves: block presence, declared class labels, and name-level coverage
  outside: whether a binding that IS named in the block is classified CORRECTLY; bindings built by expressions, function calls, or imports (not literal top-level assignments) are outside this scan; premise soundness. 'Unclassified' below means 'not detected as classified by this heuristic', not 'proven unclassified'

target: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts
scripts scanned: 14

  [BLOCK]    E1_census_arrow.py — classes detected: cited-paper, control, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E2_negative_temperature.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E3_gibbs_paradox.py — classes detected: cited-paper, control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E4_kac_ring.py — classes detected: control, declared-assumption, paper-defined; literal bindings: 0; not detected in block: (none)
  [BLOCK]    E5_quantum_census.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 1; not detected in block: (none)
  [BLOCK]    E6_bayesian_updating.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 3; not detected in block: ENERGIES, CENSUS_A_COUNTS, CENSUS_B_COUNTS
  [BLOCK]    FW1_firewall_125.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 2; not detected in block: BATTERY_VIOLATORS, BATTERY_CLEAN
  [BLOCK]    G1_history_consistency.py — classes detected: arbitrary-representative, control, declared-assumption, paper-defined; literal bindings: 8; not detected in block: CANON, WINDOW, _BATTERY_HEAD, _BATTERY_APP_OPEN, _BATTERY_APP_CLOSE, BATTERY_CASES
  [BLOCK]    G2_matrix_completeness.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 2; not detected in block: REQUIRED, MIN_CELLS
  [BLOCK]    G3_premise_inventory.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 6; not detected in block: TABLE_HEADER, REQUIRED_ROWS, CLOSING_SENTENCE, PRICE_KEYWORDS, KAC_N, EHRENFEST_N
  [BLOCK]    G4_rewrite_pairs.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 3; not detected in block: TABLE_HEADER, N_PAIRS, CLEAN_ROW
  [BLOCK]    M1_canonical_recipe.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 8; not detected in block: EPSILON, BETA_GRID
  [BLOCK]    M2_ehrenfest.py — classes detected: arbitrary-representative, cited-paper, control, declared-assumption, paper-defined; literal bindings: 7; not detected in block: MUTANT_SEED
  [BLOCK]    RB1_run_all.py — classes detected: control, declared-assumption, paper-defined; literal bindings: 1; not detected in block: SUITE

RESULT: PASS-WITH-WARNINGS — blocks detected in 14/14 scripts; 26 literal binding(s) not detected as classified (heuristic); 0 block(s) with zero classes parsed

===== check_registry_pointers =====
TOOL: check_registry_pointers
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: registry integrity: every badged claim points at a script that checks its content
  verified domain: existence of each pointed file, plus a DECLARED-CONTENT TOKEN HEURISTIC for entries that declare what they check
  map: registry JSON entries -> filesystem paths relative to the registry (or base_dir)
  preserves: the claim->script pointer structure and nothing else
  outside: whether the pointed script's assertions actually range over the claim's content (full AST claim matching is NOT implemented in v1; the token overlap is a heuristic signal, not a fidelity verdict — M4 fidelity remains a deep-audit task)

registry: /home/hatch/workspace/honesty_plugin/trial/registry_trial.json
base dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification
entries: 14

  [OK]      E1_census_arrow -> scripts/E1_census_arrow.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E2_negative_temperature -> scripts/E2_negative_temperature.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E3_gibbs_paradox -> scripts/E3_gibbs_paradox.py; declared-content tokens found 6/6 (whole-word heuristic)
  [OK]      E4_kac_ring -> scripts/E4_kac_ring.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      E5_quantum_census -> scripts/E5_quantum_census.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      E6_bayesian_updating -> scripts/E6_bayesian_updating.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      FW1_firewall_125 -> scripts/FW1_firewall_125.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G1_history_consistency -> scripts/G1_history_consistency.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G2_matrix_completeness -> scripts/G2_matrix_completeness.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G3_premise_inventory -> scripts/G3_premise_inventory.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G4_rewrite_pairs -> scripts/G4_rewrite_pairs.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      M1_canonical_recipe -> scripts/M1_canonical_recipe.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      M2_ehrenfest -> scripts/M2_ehrenfest.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      RB1_run_all -> scripts/RB1_run_all.py; declared-content tokens found 4/4 (whole-word heuristic)

RESULT: PASS — 14/14 pointed scripts exist (0 missing/escaped); 0 duplicate claim_id(s); 0 token gap(s)

===== fence_and_listing_check =====
TOOL: fence_and_listing_check
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: identity between the paper's embedded listings and the standalone script files, plus fence integrity (BYTE-REPRO)
  verified domain: fence pairing (>=3-backtick fences, markdown closing rule) and fused-fence scan over the named markdown file; content matching of each fenced block against the named files — matched by CONTENT, never by position or shared header lines
  map: markdown text -> fence map + per-block content comparison
  preserves: per-block identity with its KIND printed: EXACT (byte-identical up to one trailing newline) or NORMALIZED (equal only after whole-block leading/trailing-whitespace and line-ending normalization); fence structure; fused-fence suspects
  outside: blocks that are not script listings (examples, shell snippets) report as unmatched and require human classification; whether the prose AROUND the listings describes them accurately; fused fences whose corruption leaves no line ending in ``` (a stated residual)

markdown: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/Paper_12_5_v3.md
files dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts
fence blocks paired: 14; unpaired fence lines: 0 (parity OK)

fenced blocks: 14; matched to a file by content: 14 (EXACT: 14, NORMALIZED: 0)
  [MATCH-EXACT] block at line 4312 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E1_census_arrow.py  (marker: 'E1_census_arrow.py -- Full census of binary records (Paper 12.5 / Paper 12 S8).')
  [MATCH-EXACT] block at line 4469 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E2_negative_temperature.py  (marker: 'E2_negative_temperature.py -- Bounded-population census (Ramsey counting form).')
  [MATCH-EXACT] block at line 4650 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E3_gibbs_paradox.py  (marker: 'E3_gibbs_paradox.py -- Exact mixing counts under two counting RULES.')
  [MATCH-EXACT] block at line 4854 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E4_kac_ring.py  (marker: 'E4_kac_ring.py -- Kac ring, exact and exhaustive at small size.')
  [MATCH-EXACT] block at line 5107 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E5_quantum_census.py  (marker: 'E5_quantum_census.py -- Stage P/C audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 5533 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/E6_bayesian_updating.py  (marker: 'E6_bayesian_updating.py -- MaxEnt / Bayesian updating read against')
  [MATCH-EXACT] block at line 5861 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/M1_canonical_recipe.py  (marker: 'M1_canonical_recipe.py -- Monte-Carlo audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 6125 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/M2_ehrenfest.py  (marker: 'M2_ehrenfest.py -- Ehrenfest urn audit instrument for Paper 12.5')
  [MATCH-EXACT] block at line 6331 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G1_history_consistency.py  (marker: '# G1_history_consistency.py -- Paper 12.5 document check: the (year,')
  [MATCH-EXACT] block at line 6774 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G2_matrix_completeness.py  (marker: 'G2_matrix_completeness.py -- document check for Paper 12.5')
  [MATCH-EXACT] block at line 6962 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G3_premise_inventory.py  (marker: 'G3_premise_inventory.py -- document + recomputation check for')
  [MATCH-EXACT] block at line 7346 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/G4_rewrite_pairs.py  (marker: 'G4_rewrite_pairs.py -- document check for Paper 12.5')
  [MATCH-EXACT] block at line 7615 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/FW1_firewall_125.py  (marker: 'FW1_firewall_125.py -- own-voice firewall scan for Paper 12.5')
  [MATCH-EXACT] block at line 7844 -> /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/RB1_run_all.py  (marker: '# RB1_run_all.py -- Paper 12.5 verification suite runner.')

RESULT: PASS — fence parity OK; 0 fused-fence suspect(s); 14/14 blocks matched by content (EXACT 14, NORMALIZED 0)

===== param_prov =====
TOOL: param_prov
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: free-parameter provenance accounting for the named table (PARAM-PROV)
  verified domain: classification of the table's entries per provenance class under the table's OWN named counting convention, and counts per class
  map: JSON parameter table -> class validation + counting
  preserves: provenance structure of the declared entries, with the convention attached
  outside: whether fewer or differently-classed inputs is a virtue (a theory-choice judgement, not bookkeeping); empirical adequacy; any total computed under a different convention. A count match or count advantage establishes nothing (FREEZE v1.0 §2). The verdict guard is a tripwire over known phrasings (listed in the source), not a semantic guarantee: verdicts encoded purely numerically, in other languages, or without comparative vocabulary can evade it and are outside this check — the substantive rule is the freeze's banned-constructions rule on human-written reports

table: /home/hatch/workspace/honesty_plugin/trial/fixtures/param_demo.json
counting convention: instrument-trial demonstration convention (NOT a scoring corpus)
entries: 5

per-entry classification:
  example_measured_mass: measured-input
  example_fitted_coupling: fitted
  example_window_choice: declared-assumption
  example_count_ratio: derived-from-structure
  example_representative_configuration: arbitrary-representative

counts per provenance class (under the convention named above):
  derived-from-structure: 1
  measured-input: 1
  fitted: 1
  declared-assumption: 1
  arbitrary-representative: 1

GUARD: no comparative verdict is emitted from these totals (FREEZE v1.0 §2, §6). Totals are bookkeeping under the named convention only; counts change under other conventions — re-run under each convention and report side by side.

RESULT: PASS — 5 entries classified under convention 'instrument-trial demonstration convention (NOT a scoring corpus)'
```

## 7. MUTANT (a) verdict-injection — CAUGHT

```text
TOOL: param_prov
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: free-parameter provenance accounting for the named table (PARAM-PROV)
  verified domain: classification of the table's entries per provenance class under the table's OWN named counting convention, and counts per class
  map: JSON parameter table -> class validation + counting
  preserves: provenance structure of the declared entries, with the convention attached
  outside: whether fewer or differently-classed inputs is a virtue (a theory-choice judgement, not bookkeeping); empirical adequacy; any total computed under a different convention. A count match or count advantage establishes nothing (FREEZE v1.0 §2). The verdict guard is a tripwire over known phrasings (listed in the source), not a semantic guarantee: verdicts encoded purely numerically, in other languages, or without comparative vocabulary can evade it and are outside this check — the substantive rule is the freeze's banned-constructions rule on human-written reports

table: /home/hatch/workspace/honesty_plugin/trial/fixtures/param_mutant.json

RESULT: REFUSED — verdict-injection detected (FREEZE v1.0 §6 guard).
WITNESS: field '<raw file text>' contains: '{\n  "convention": "instrument-trial demonstration convention (NOT a scoring corpus)",\n  "entries": [\n    {\n      "name": "example_measured_mass",\n      "class": "measured-input"\n    },\n    {\n      "name": "example_fitted_coupling",\n      "class": "fitted"\n    },\n    {\n      "name": "example_window_choice",\n      "class": "declared-assumption"\n    },\n    {\n      "name": "example_count_ratio",\n      "class": "derived-from-structure"\n    },\n    {\n      "name": "example_representative_configuration",\n      "class": "arbitrary-representative"\n    }\n  ],\n  "requested_conclusion": "therefore the ledger is preferable, having fewer parameters"\n}'
matched pattern: \btherefore\b[^.\n]{0,120}\b(preferab|superior|better|more honest|wins?|defeat|condemn)
This tool classifies entries and prints counts per class under a
named convention. It does not emit comparative verdicts from totals.
Remove the verdict language and re-run for bookkeeping output.
```

## 8. MUTANT (b) registry entry pointing at a nonexistent script — CAUGHT

```text
TOOL: check_registry_pointers
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: registry integrity: every badged claim points at a script that checks its content
  verified domain: existence of each pointed file, plus a DECLARED-CONTENT TOKEN HEURISTIC for entries that declare what they check
  map: registry JSON entries -> filesystem paths relative to the registry (or base_dir)
  preserves: the claim->script pointer structure and nothing else
  outside: whether the pointed script's assertions actually range over the claim's content (full AST claim matching is NOT implemented in v1; the token overlap is a heuristic signal, not a fidelity verdict — M4 fidelity remains a deep-audit task)

registry: /home/hatch/workspace/honesty_plugin/trial/registry_mutant.json
base dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification
entries: 15

  [OK]      E1_census_arrow -> scripts/E1_census_arrow.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E2_negative_temperature -> scripts/E2_negative_temperature.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      E3_gibbs_paradox -> scripts/E3_gibbs_paradox.py; declared-content tokens found 6/6 (whole-word heuristic)
  [OK]      E4_kac_ring -> scripts/E4_kac_ring.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      E5_quantum_census -> scripts/E5_quantum_census.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      E6_bayesian_updating -> scripts/E6_bayesian_updating.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      FW1_firewall_125 -> scripts/FW1_firewall_125.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G1_history_consistency -> scripts/G1_history_consistency.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G2_matrix_completeness -> scripts/G2_matrix_completeness.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G3_premise_inventory -> scripts/G3_premise_inventory.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      G4_rewrite_pairs -> scripts/G4_rewrite_pairs.py; declared-content tokens found 3/3 (whole-word heuristic)
  [OK]      M1_canonical_recipe -> scripts/M1_canonical_recipe.py; declared-content tokens found 5/5 (whole-word heuristic)
  [OK]      M2_ehrenfest -> scripts/M2_ehrenfest.py; declared-content tokens found 4/4 (whole-word heuristic)
  [OK]      RB1_run_all -> scripts/RB1_run_all.py; declared-content tokens found 4/4 (whole-word heuristic)
  [MISSING] MUTANT-B -> scripts/NO_SUCH_SCRIPT.py  WITNESS: resolved path /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts/NO_SUCH_SCRIPT.py does not exist

RESULT: FAIL — 14/15 pointed scripts exist (1 missing/escaped); 0 duplicate claim_id(s); 0 token gap(s)
```

## 9. MUTANT (c) provenance stripped from a real script (deleted the INPUT_PROVENANCE header line and 11 block-body line(s) (the whole block) from E1_census_arrow.py) — CAUGHT

```text
TOOL: lint_provenance
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: premise/provenance completeness of the named scripts (PROV-COMPLETE)
  verified domain: presence of INPUT_PROVENANCE blocks (header anchored in comments or docstrings only), the provenance classes declared in them, and module-level literal bindings whose names do not appear in the block — a HEURISTIC scan
  map: script source -> comment/docstring extraction + AST scan of top-level literal assignments
  preserves: block presence, declared class labels, and name-level coverage
  outside: whether a binding that IS named in the block is classified CORRECTLY; bindings built by expressions, function calls, or imports (not literal top-level assignments) are outside this scan; premise soundness. 'Unclassified' below means 'not detected as classified by this heuristic', not 'proven unclassified'

target: /home/hatch/workspace/honesty_plugin/trial/fixtures/E1_no_provenance.py
scripts scanned: 1

  [NO BLOCK] E1_no_provenance.py  WITNESS: no INPUT_PROVENANCE header detected in the file's comments or docstrings

RESULT: FAIL — blocks detected in 0/1 scripts; 0 literal binding(s) not detected as classified (heuristic); 0 block(s) with zero classes parsed
```

## 10. MUTANT (d) glued closing fence in the real paper (fused the closing fence of the first listing onto line 4464 (1-based) of Paper_12_5_v3.md) — CAUGHT

```text
TOOL: fence_and_listing_check
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: identity between the paper's embedded listings and the standalone script files, plus fence integrity (BYTE-REPRO)
  verified domain: fence pairing (>=3-backtick fences, markdown closing rule) and fused-fence scan over the named markdown file; content matching of each fenced block against the named files — matched by CONTENT, never by position or shared header lines
  map: markdown text -> fence map + per-block content comparison
  preserves: per-block identity with its KIND printed: EXACT (byte-identical up to one trailing newline) or NORMALIZED (equal only after whole-block leading/trailing-whitespace and line-ending normalization); fence structure; fused-fence suspects
  outside: blocks that are not script listings (examples, shell snippets) report as unmatched and require human classification; whether the prose AROUND the listings describes them accurately; fused fences whose corruption leaves no line ending in ``` (a stated residual)

markdown: /home/hatch/workspace/honesty_plugin/trial/fixtures/glued_fence.md
files dir: /home/hatch/workspace/honesty_plugin/trial/extracted/paper_12_5_verification/scripts
fence blocks paired: 13; unpaired fence lines: 1 (parity BROKEN — FAIL)

  [FUSED FENCE SUSPECT] line 4464: '    sys.exit(main())```'  WITNESS: non-fence line ending in ``` — a closing fence fused onto code text
  [PARITY FAIL] unpaired fence line(s) at: 7939
fenced blocks: 13; matched to a file by content: 0 (EXACT: 0, NORMALIZED: 0)
  [UNMATCHED] block at line 4312  (marker: '#!/usr/bin/env python3') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 4645  (marker: '### E.3 Gibbs-paradox counting — `E3_gibbs_paradox.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 4849  (marker: '### E.4 Kac ring, exhaustive — `E4_kac_ring.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 5102  (marker: '### E.5 Quantum census — `E5_quantum_census.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 5528  (marker: '### E.6 Bayesian updating — `E6_bayesian_updating.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 5856  (marker: '### M.1 Canonical recipe (Monte Carlo audit instrument) — `M1_canonical_recipe.p') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 6120  (marker: '### M.2 Ehrenfest urn (Monte Carlo audit instrument) — `M2_ehrenfest.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 6326  (marker: '### G.1 History consistency — `G1_history_consistency.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 6769  (marker: '### G.2 Audit-matrix completeness — `G2_matrix_completeness.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 6957  (marker: '### G.3 Premise inventory — `G3_premise_inventory.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 7341  (marker: '### G.4 Rewrite pairs — `G4_rewrite_pairs.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 7610  (marker: '### FW.1 Firewall — `FW1_firewall_125.py`') — not identical to any file in the dir, exactly or normalized (human classification required)
  [UNMATCHED] block at line 7839  (marker: '### RB.1 Suite runner — `RB1_run_all.py`') — not identical to any file in the dir, exactly or normalized (human classification required)

RESULT: FAIL — fence parity BROKEN; 1 fused-fence suspect(s); 0/13 blocks matched by content (EXACT 0, NORMALIZED 0)
```

## 11. MUTANT (a2) verdict-injection carried by a JSON key — CAUGHT

```text
TOOL: param_prov
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: free-parameter provenance accounting for the named table (PARAM-PROV)
  verified domain: classification of the table's entries per provenance class under the table's OWN named counting convention, and counts per class
  map: JSON parameter table -> class validation + counting
  preserves: provenance structure of the declared entries, with the convention attached
  outside: whether fewer or differently-classed inputs is a virtue (a theory-choice judgement, not bookkeeping); empirical adequacy; any total computed under a different convention. A count match or count advantage establishes nothing (FREEZE v1.0 §2). The verdict guard is a tripwire over known phrasings (listed in the source), not a semantic guarantee: verdicts encoded purely numerically, in other languages, or without comparative vocabulary can evade it and are outside this check — the substantive rule is the freeze's banned-constructions rule on human-written reports

table: /home/hatch/workspace/honesty_plugin/trial/fixtures/param_mutant_key.json

RESULT: REFUSED — verdict-injection detected (FREEZE v1.0 §6 guard).
WITNESS: field '<raw file text>' contains: '{\n  "convention": "instrument-trial demonstration convention",\n  "therefore the ledger is preferable": "yes",\n  "entries": [\n    {\n      "name": "example_x",\n      "class": "fitted"\n    }\n  ]\n}'
matched pattern: \btherefore\b[^.\n]{0,120}\b(preferab|superior|better|more honest|wins?|defeat|condemn)
This tool classifies entries and prints counts per class under a
named convention. It does not emit comparative verdicts from totals.
Remove the verdict language and re-run for bookkeeping output.
```

## 12. MUTANT (a3) verdict-injection carried by the convention string — CAUGHT

```text
TOOL: param_prov
CRITERIA: comparative-honesty-audit v1.0 | FREEZE: 9abc91c9eee9 (full 9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c; manifest-verified; frozen 2026-11-08)
DISCLOSURE (FREEZE v1.0 §6, five-part):
  native domain: free-parameter provenance accounting for the named table (PARAM-PROV)
  verified domain: classification of the table's entries per provenance class under the table's OWN named counting convention, and counts per class
  map: JSON parameter table -> class validation + counting
  preserves: provenance structure of the declared entries, with the convention attached
  outside: whether fewer or differently-classed inputs is a virtue (a theory-choice judgement, not bookkeeping); empirical adequacy; any total computed under a different convention. A count match or count advantage establishes nothing (FREEZE v1.0 §2). The verdict guard is a tripwire over known phrasings (listed in the source), not a semantic guarantee: verdicts encoded purely numerically, in other languages, or without comparative vocabulary can evade it and are outside this check — the substantive rule is the freeze's banned-constructions rule on human-written reports

table: /home/hatch/workspace/honesty_plugin/trial/fixtures/param_mutant_convention.json

RESULT: REFUSED — verdict-injection detected (FREEZE v1.0 §6 guard).
WITNESS: field '<raw file text>' contains: '{\n  "convention": "superiority of the ledger (counting rules)",\n  "entries": [\n    {\n      "name": "example_x",\n      "class": "fitted"\n    }\n  ]\n}'
matched pattern: \bsuperiority of\b
This tool classifies entries and prints counts per class under a
named convention. It does not emit comparative verdicts from totals.
Remove the verdict language and re-run for bookkeeping output.
```
