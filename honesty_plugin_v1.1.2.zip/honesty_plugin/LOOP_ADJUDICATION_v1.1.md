# LOOP ADJUDICATION — v1.1 build (Phases A–C), 2026-11-08

Standing loop pass (author's mandate): three read-only benches —
devil's advocate (DA), evil auditor (EA), red team (RT) — over the
FREEZE v1.1 Annex, the plugin v1.1 code delta, and the Dirac worked
example. Charges adjudicated by the coordinator with the files open;
sustained charges repaired and everything re-run on the final tree.
Benches' numbering is their own (the v1 pass's LOOP_ADJUDICATION.md
uses DA/EA/RT labels for different charges).

## Freeze integrity (checked before, during, and after)

FREEZE_v1.0.md `9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c`
and FREEZE_MANIFEST.sha256 `e514082831f67d…` are byte-unchanged across
Phases A–C and all repairs. FREEZE_v1.1_ANNEX.md `8ee2f8e9…` and its
manifest likewise unchanged after freezing. Repairs touched the
instrument (now v1.1.1), the README, and the worked-example documents
— never a frozen file.

## Final verification on the repaired tree (coordinator's own runs)

- Selftest: **42/42** (35 v1.1 cases + 7 repair cases).
- MCP proof: **8/8** (stdlib fallback path; SDK absent in this
  environment, fallback disclosed by the server itself).
- validate_cards: carder_A **PASS 32/32**, carder_B **PASS 32/32**,
  canonical **PASS 39/39** — and the canonical set additionally under
  source-manifest verification (`--sources-manifest
  sources/SOURCES.sha256`): both source hashes verified in the output,
  RESULT PASS 39/39 (verbatim output in the worked example report's
  validation record).
- INSTRUMENT_MANIFEST_v1.1.sha256: 18/18 OK.

## Charges and verdicts

### Devil's advocate (21 charges)

- **DA-1 SUSTAINED (major).** "Unusually explicit" — a baseline-less
  comparative in the report. Deleted; replaced by the declared-of-N
  counts themselves.
- **DA-2 SUSTAINED-IN-PART (major).** The report's Limits §6 named a
  paraphrase "the FREEZE ceiling sentence". Repaired: the ceiling is
  now quoted verbatim and the report states plainly that the
  demonstration does not reach it and prints no comparative
  conclusion.
- **DA-3 SUSTAINED (major).** Report and adjudication log printed PASS
  without the five-part disclosure header — a literal FREEZE §5
  breach. Repaired by attaching verbatim headered outputs (report
  validation record; log addendum).
- **DA-4 SUSTAINED-IN-PART (minor).** Dashboard-shaped tallies carry
  citation risk. Mitigation already heavy; a stripping-the-label
  warning added to the tallies section.
- **DA-5 SUSTAINED-IN-PART (major).** F1 ("blurring the chronology")
  was contradicted by §5.3's "historical detour" frame and by TNG-17's
  era note (which itself over-asserted a 1930 dating). F1 narrowed to
  "marked as history but not dated"; the era note was corrected and
  the canonical set rebuilt (see hash record in the log addendum).
- **DA-6 SUSTAINED (major).** F2 charged an upgrade of the 1928 text;
  Tong's sentence is about Dirac across the hole-stage work. F2
  rewritten to the residue its quotes support (an undated attribution
  in an undated detour).
- **DA-7 SUSTAINED (major).** F3 ("the stipulation changes costume")
  withdrawn as a fidelity finding: the conditions are derived in
  Dirac too, representation uniqueness is a theorem, and Tong uses
  Dirac's own "we must find" idiom. Retained only as a traceability
  observation (proof displayed vs asserted in prose).
- **DA-8 SUSTAINED-IN-PART (minor).** F4 relabelled: an expository
  observation; no A4.3 status shift asserted.
- **DA-9 SUSTAINED-IN-PART (major).** F5's register observation is
  accurate as tone; but TNG-12's aesthetic aside is not a bridge
  under FREEZE §1 M3 (no inference to a claim about physical
  reality). Card recoded bridges []; Tong's undeclared bridges go
  1 → 0 and the tallies were updated.
- **DA-10 NOT SUSTAINED.** F6 (the fidelity confirmation) is clean.
- **DA-11 SUSTAINED-IN-PART (major).** F7's sting ("his restraint
  does not either") removed; genre caution, TNG-21-as-relocated-
  restraint, and the "Dirac's analysis" attribution note added.
- **DA-12 SUSTAINED-IN-PART (major).** The premise row measures
  carding discipline at least as much as the texts; the inference
  sentence was reworded to say so before drawing anything from it.
- **DA-13 SUSTAINED-IN-PART (minor).** Composition/denominator note
  added to the tallies section.
- **DA-14 SUSTAINED-IN-PART (major).** Era shelter + genre confound:
  the falsifier paragraph and Limit 1 now print the form-vs-content
  distinction (Dirac did tie claims to observation) and the
  research-article-vs-lecture-notes strata problem.
- **DA-15 SUSTAINED-IN-PART (major).** Annex Door 1 lacks a timing
  guard against FREEZE §3. Annex is frozen; recorded for v1.2 and
  bound meanwhile by a house-practice note in the README (nominations
  only before a run's corpus freeze).
- **DA-16 SUSTAINED-IN-PART (major).** Annex §A6's ceiling reference
  can be read as a license. Frozen; recorded for v1.2; README
  house-practice note binds the reading (a bound, never a license;
  demonstrations print no comparative conclusions), and the report's
  repaired Limit 6 practises it.
- **DA-17 SUSTAINED-IN-PART (minor).** Door 3's edit pen and §A3's
  unnamed-independence adjudicator: structural licenses, honestly
  disclosed for this run (house adjudication, Limit 2). Recorded for
  v1.2; README note commits to printing a respondent's objection
  alongside any edit.
- **DA-18 NOT SUSTAINED.** The bridge rulings (B0/B1/B2, Q3) cut
  against Dirac as often as for him; the bench's own recomputation
  shows the all-B counterfactual flatters Dirac more (9/1 vs 8/2).
- **DA-19 NOT SUSTAINED** (as favouritism). Layer/freedom rulings
  flip no headline tally; effects recorded in the report's
  sensitivity paragraph.
- **DA-20 SUSTAINED-IN-PART (major).** The three existence rulings
  (I1/I2/D1) all tilt the tallies one way and the sensitivity was
  undisclosed. Each ruling's defence stands (printed in the log);
  the sensitivity paragraph now prints the losing-reading numbers,
  including the evidence-NONE row's reversal range.
- **DA-21 SUSTAINED (minor).** Canonical cards carried stale
  carder-set cross-references that misresolve inside the canonical
  set. Repaired by the membership-map pointer rewrite in
  build_canonical.py; a token sweep confirms none remain.

### Evil auditor (9 charges)

- **EA-1 SUSTAINED (major).** validate_cards did not bind validation
  to the A2.4 sources manifest and silently fell back to guessed
  filenames. Repaired in v1.1.1: SOURCE lines print each file's
  sha256 and size; fallback use is labelled SOURCE-FALLBACK with a
  warning; optional --sources-manifest enforces hash-pinning
  (mismatch or missing entry rejects the source's cards). The
  canonical run was re-executed in manifest mode.
- **EA-2 SUSTAINED (major).** The claim scan fell to a hyphen-split
  banned phrase. Repaired: the scan now tests both reconstructions
  of a hyphen+newline break (removal and space-joining); selftest
  case (vii).
- **EA-3 SUSTAINED (minor).** The seven-phrase tripwire list was
  disclosed only in source code and diverges from §5's semantic ban
  in both directions. Repaired by enumeration + literal-floor
  disclosure in the README repair note (incl. the two §5 categories
  with no tripwire); the list itself is unchanged (the freeze defines
  the ban semantically; the tripwire is a floor, now labelled one).
- **EA-4 SUSTAINED (minor).** era_note "n/a" passed against A1's
  explicit rule. Repaired: denylist for era_note, and carder values
  "anonymous"/"anon"/"unknown" are rejected (A1: anonymous cards are
  not admitted). Selftest case (viii).
...[truncated 3885 chars]
## Postscript — Paper 12.5 v4 loop pass (2026-11-08)

The v4 build's loop (three benches over the paper delta, H.1 and the
cards package) returned two charges against the instrument itself,
both sustained and repaired as **plugin v1.1.2** (selftest 43/43,
MCP proof 8/8, all card sets re-validated unchanged, manifest
regenerated; freezes untouched):

- **RT4-1** — `location` correctness was verified by no check and
  named in no disclosure: validation establishes membership in the
  named source *file*, never position within it. The disclosure's
  outside list and the tool description now name location
  correctness as outside. (The companion defect in the paper's own
  H.1 — an excerpt substrate whose scaffolding could validate as a
  quote — was repaired in H.1 itself by per-card excerpt-block
  search, a strengthening the full-text instrument does not need.)
- **RT4-2** — NONE-form reasons of pure punctuation passed. The
  reason must now carry an alphanumeric character, matching the
  evidence field's existing rule (selftest case xiv).
- **RT4-5 (record correction)** — the sensitivity figure for the
  D1 losing reading, printed in the worked example report and
  inherited by Paper 12.5 v4's Appendix F, read "2–0"; the cards
  give 2–1 for D1 alone (2–0 only under the I1+D1 combination, as
  DA-20's combined counterfactual correctly stated). Corrected in
  both documents, with the correction marked in place.
