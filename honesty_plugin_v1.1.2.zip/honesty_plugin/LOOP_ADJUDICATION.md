# LOOP ADJUDICATION — honesty_plugin v1

**Pass:** adversarial loop over the plugin tree, three read-only benches —
devil's advocate (DA-1…DA-13), evil auditor (EA-1…EA-20), red team
(RT-1…RT-10) — per the standing loop-pass mandate. No bench edited the
tree. Charges adjudicated by the coordinator with evidence; sustained
charges repaired; **the full verification sequence was re-run on the
final tree after the last edit** (results at the end). FREEZE_v1.0.md
was not edited at any point — its hash is unchanged
(`9abc91c9eee95c42…`); where a charge lands on the freeze text itself,
the repair is a recommendation for a future freeze version, recorded
below, because a pinned freeze is not silently amendable (that is the
freeze's own rule).

## Correction record (process)

The first trial run was executed against pre-fix instrument code (two
defects found by the trial itself: the bracket-tag provenance style and
a fence-scan false positive — both fixed, trial re-run). The loop
benches were dispatched while that re-run was in flight, so RT-3/DA-7/
EA-10 each caught the trial document mid-supersession. The factual core
(the first trial described superseded code) was true when filed; the
coordinator re-ran the trial and personally verified §2/§4 against the
shipped code before the reports landed, and the trial has since been
regenerated again on the final tree. The durable defect underneath the
charge — the instrument code was not hash-pinned — is repaired
(`INSTRUMENT_MANIFEST.sha256`; the trial now stamps the corpus zip hash,
the freeze hash, and the instrument manifest hash in its head).

## Verdicts

### Fence check

- **EA-1 (BLOCKER) double-glue with even parity passed clean.** SUSTAINED.
  Repaired: glued detection is now structural — any non-fence line
  *ending* in ``` is a fused-fence suspect regardless of parity (the
  Paper 11 corruption signature); pairing follows the markdown rule for
  ≥3-backtick fences (also repairs **EA-16**). Selftest case (d2)
  reproduces the double-glue: FAIL, 2 suspects.
- **EA-2 / DA-5 (BLOCKER) PASS with zero listings matched.** SUSTAINED.
  Repaired: status is FAIL when parity is broken, suspects exist, there
  are no blocks, or **zero** blocks matched; PASS-WITH-WARNINGS when
  some blocks are unmatched. Selftest case (d3).
- **EA-12 / DA-8 "byte-identity" wording outran strip-tolerant matching;
  markers were the shared shebang line.** SUSTAINED. Repaired: every
  block prints its match KIND — EXACT (byte-identical up to one trailing
  newline, same line-ending family) or NORMALIZED — and its marker is
  the first content line unique across all blocks, falling back to a
  block content hash; duplicate-content files are flagged AMBIGUOUS
  (**EA-19**). The trial now shows 14/14 EXACT. Selftest has a CRLF
  exhibit asserting kind NORMALIZED.
- **DA-4's fence half** — subsumed by EA-2.

### param_prov verdict guard

- **EA-3 (BLOCKER) the tool printed banned comparatives itself** —
  verdicts riding in the echoed convention / entry names passed under a
  PASS stamp. SUSTAINED. Repaired: the guard now scans the table's
  ENTIRE raw text (keys and values) plus every parsed string, after
  zero-width-character stripping; patterns broadened (bare "X wins/beats",
  "superiority of", "more honest than", "condemned by the checks", …).
  Selftest mutants (a2) key-carried and (a3) convention-carried and
  (a3b) name-carried verdicts all REFUSED; trial §§11–12 likewise.
- **EA-4 / RT-5 / DA-3 (MAJOR) residual bypass classes.** SUSTAINED IN
  PART: key-carried, split-across-fields (caught by the raw-text scan),
  zero-width, and the freeze's own §5 phrase are now caught. CONCEDED as
  a stated limit for the rest: a verdict encoded purely numerically, in
  another language, or with no comparative vocabulary can still evade a
  regex tripwire. The guard is now DISCLOSED as a tripwire — in the
  tool's own "outside" field and the README — not a semantic guarantee;
  the substantive rule remains the freeze's banned-constructions rule on
  human reports. *Freeze v1.1 recommendation:* FREEZE §6's categorical
  refusal wording should be amended to the tripwire formulation.
- **EA-17 / DA-13(e) vacuous table PASS.** SUSTAINED: zero entries now
  FAIL; a non-string convention is REFUSED. Selftest exhibits both.

### lint_provenance

- **EA-5 (MAJOR) the 6000-char window made coverage self-satisfying.**
  SUSTAINED. Repaired: the block is now the bounded header REGION
  (comment run, stopped at the code; or the docstring containing the
  header) — a binding's own assignment line can no longer classify it,
  and a binding named in the block is covered wherever it sits.
  Selftest (c2) reproduces the auditor's empty-block witness: both body
  bindings flagged, status PASS-WITH-WARNINGS, not PASS.
- **EA-6 (MAJOR) header inside a string literal counted; zero parsed
  classes still PASS.** SUSTAINED. Repaired: the header anchors only in
  comments (tokenizer-extracted, so `#` inside strings doesn't count) or
  docstrings; zero-class blocks downgrade the status. Selftest (c3).
- **DA-4 / RT-4 lint PASS ignored unclassified counts.** SUSTAINED:
  PASS now requires all blocks present, ≥1 class per block, and zero
  undetected bindings; otherwise PASS-WITH-WARNINGS / FAIL. Consequence
  on the real corpus: the trial lint is PASS-WITH-WARNINGS with 26
  named bindings — genuine heuristic findings (internal constants not
  individually named in the blocks), printed with names.
- **EA-18 silent degradations.** SUSTAINED: unparseable files report
  [PARSE ERROR] with witness and cannot pass; a nonexistent target is a
  headered ERROR (via the error-report path below).

### Disclosure integrity & error paths

- **DA-1 / EA-9 (BLOCKER) every error path emitted no disclosure
  header; SDK and fallback error semantics differed.** SUSTAINED.
  Repaired: a single `error_report()` carries the full five-part header;
  `call_tool` never raises for tool-level failures; the CLI prints the
  headered report and exits 2; the MCP SDK path returns
  `CallToolResult(isError=True)` and the fallback sets `isError: true`.
  Proven on the wire for both paths (mcp_proof: headered ERROR +
  isError, 8/8 each).
- **EA-7 (MAJOR) missing manifest silently labelled "manifest-verified".**
  SUSTAINED. Repaired in `disclose.py`: the label now reads
  "document-hash only (FREEZE_MANIFEST.sha256 absent at runtime — NOT
  manifest-verified)". Selftest reproduces on a manifest-less tree copy.
- **EA-20 (part) freeze status invisible in data dicts; dead code.**
  PARTLY SUSTAINED: the dead `_PROV_CLASSES` list is removed; the
  MANIFEST-MISMATCH tripwire still prints in every header. Tools still
  emit their verdict under a broken freeze (the header carries the
  mismatch in full); making mismatch a hard refusal is a *freeze v1.1
  recommendation*, since v1.0 §6 specifies the print-the-mismatch
  behaviour. Noted, not silently changed.
- **RT-10 / DA-6 / EA-11 the test oracles themselves were weak** —
  `header_ok` never checked the `map:` part or the freeze hash; mutant
  (a) tested one phrasing; the bracket style had no coverage. SUSTAINED.
  Repaired: `header_ok` and the MCP proof now require all five parts
  AND the freeze-hash short form; the selftest grew from 10 to 27 cases
  covering every sustained bypass class above (double-glue, zero-match,
  empty block, string-literal header, key/convention/name-carried
  verdicts, registry escape + duplicates, unlisted-suite refusal,
  dashboard failure propagation, CLI error header, manifest-absent
  label, CRLF kind).

### Dashboard

- **DA-2 / RT-4 (MAJOR) dashboard over a FAIL still exited 0 as
  "ASSEMBLED".** SUSTAINED. Repaired: worst-constituent status —
  ASSEMBLED-WITH-FAILURES (CLI exit 1) when any constituent is
  FAIL/REFUSED/ERROR; summary lines now carry counts (**DA-13(a)**);
  the SKIP pseudo-section carries a real disclosure header
  (**DA-12**); "no scripts found" corrected to "detected" (**DA-11**).

### Registry

- **EA-13 (MAJOR) pointers escaped their scope; duplicates unchecked.**
  SUSTAINED. Repaired: pointers must resolve inside the base dir
  (absolute/traversal → [ESCAPE] witness, FAIL); duplicate claim_ids →
  [DUPLICATE] witness, FAIL. Selftest (b2)/(b3).
- **EA-14 token heuristic substring-gameable and verdict-inert.**
  SUSTAINED IN PART: matching is now whole-word; gaps print [TOKEN GAP]
  and downgrade to PASS-WITH-WARNINGS. It remains an advisory heuristic
  by design, and says so.
- **DA-10 trial registry never exercised the heuristic.** SUSTAINED.
  Repaired: trial registry entries carry `checks` taken from each
  script's own header line; the branch now runs in §§3/6/8 (14/14
  tokens found). Adjudication note (RT-1's residue): tokens sourced
  from the script itself are weak evidence — the trial's scope
  statement says exactly that.

### Suite tool

- **RT-9 (MAJOR) unsandboxed arbitrary code execution, undisclosed.**
  SUSTAINED. Repaired: when no parseable RB1-style suite list exists,
  the tool REFUSES rather than executing unlisted scripts
  (`run_unlisted=true` is the explicit opt-in, on both faces); the
  security fact is stated in the tool's disclosure, the refusal text,
  and the README. Selftest exhibits refusal + opt-in.
- **EA-15 runner mis-identification + zip nesting fragility.**
  SUSTAINED. Repaired: runner identification by filename convention
  (`*_run_all.py` / `RB1*`); unparseable runner-shaped lines are
  counted and warned, never silently dropped (**DA-9**); package-root
  resolution searches downward deterministically (folder + stray file
  resolves). Header wording corrected (no "each run once / clean /
  against the named paper file"); the runner line is labelled a second,
  aggregate observation; per-script lines label the quoted text as the
  audited script's own last line, truncation marked (**DA-11**).

### Trial & packaging

- **RT-1 (MAJOR) trial circularity / framing.** SUSTAINED as to framing;
  the construction itself was declared, not hidden. Repaired: the trial
  now opens with a scope statement (smoke test; §3 = plumbing only;
  nothing bears on symmetry, M1–M5, or any standard-side corpus) and
  stamps corpus zip sha256, freeze hash, instrument manifest hash, and
  Python version. The trial's ceiling is stated in the document itself.
- **RT-2 (MAJOR) instrument-level vocabulary capture.** SUSTAINED as a
  disclosure defect; CONCEDED as a v1 scope fact. Repaired in text:
  README gains "Input contracts (v1)" (every input is a house format;
  a foreign corpus needs a disclosed adapter or an instrument
  extension) and the three-vocabulary mapping table; the dashboard's
  "outside" carries the same sentence. The protocol-level claim is
  untouched; the instrument-level limit is now printed wherever the
  outputs travel. *Freeze v1.1 recommendation:* add the input-contract
  sentence to §6.
- **RT-6 (MAJOR) counts-against #6 is self-adjudicated.** CONCEDED, in
  text: README "Adjudication status" states internal adjudication is
  not external validation (the design's O5 standard applied to
  ourselves). No repair is available to the coordinator — external
  adjudication is a later, external act. The gate's wording for any
  future *publication* claim must reflect that.
- **RT-7 (MAJOR) hash-pin is a record, not a constraint; manifest
  pointed out of tree.** SUSTAINED. Repaired: README states the
  tripwire/record nature plainly and that the freeze is **not
  externally anchored as of v1** (anchoring is the author's publication
  action, still open); `DESIGN_SYNTHESIS.md` is copied into the tree
  and the manifest re-pinned to the in-tree path (freeze hash
  unchanged; synthesis bytes identical, `75bc9e2c…`).
- **RT-8 (MAJOR) aggregate packaging.** SUSTAINED. Repaired: LICENSE
  (MIT, © Dervis Kadunic — **coordinator-chosen permissive default,
  flagged for the author's confirmation**), minimal `pyproject.toml`
  (requires-python ≥3.10; `mcp` an optional extra, version unpinned —
  the SDK proof ran against 2.3.0 in a scratch venv; the fallback path
  has no dependency), `INSTRUMENT_MANIFEST.sha256`, corpus-precheck
  before any extraction cleanup, no `__pycache__` or stray logs in the
  delivered tree. The trial report no longer identifies the corpus by
  bare absolute path alone — the zip sha256 is stamped.
- **EA-8 (MAJOR) fallback server killed by one non-object line; parse
  errors swallowed.** SUSTAINED. Repaired: non-object JSON is answered
  -32600 and the server keeps serving; malformed JSON is answered
  -32700 (id null) per spec. The MCP proof now opens with a
  hostile-lines prelude on BOTH paths: server survives, 8/8.
- **EA-10 / RT-3 / DA-7 trial not bound to shipped code.** See the
  correction record above; repaired by the instrument manifest + trial
  stamps + final-tree regeneration (below).

### Not sustained

- **DA-11's "(0 missing)" objection** (counted-fact parentheticals as
  unqualified absence claims): NOT SUSTAINED — "(0 missing)" reports a
  count the check computed over its declared domain (14 entries
  examined), the counted-fact form the house rules prescribe; the
  "detected" repairs were made where a genuine absence claim existed.

## Freeze v1.1 recommendations (for the author's ruling; v1.0 untouched)

1. §6: PARAM-PROV refusal wording → tripwire formulation (guard scans
   whole input; semantic guarantee disclaimed).
2. §6: add the input-contracts sentence (house formats; adapter rule).
3. Decide whether MANIFEST-MISMATCH should hard-refuse tool verdicts
   rather than print-and-proceed.
4. §4 counts-against #6: name the external-adjudication requirement
   explicitly, so internal loop adjudication can never be mistaken for
   the gate it describes.

## Final-tree re-run (after the last edit; coordinator's own runs)

- `tests/selftest.py` — **27/27 PASS**, exit 0.
- `tests/mcp_proof.py`, fallback path (stdlib, system Python) — **8/8**.
- `tests/mcp_proof.py`, SDK path (mcp 2.3.0, scratch venv) — **8/8**.
- `trial/run_trial.py` on the real Paper 12.5 v3 package — 12 sections:
  §1 suite **PASS 13/13 + runner**; §2 lint **PASS-WITH-WARNINGS**
  (14/14 blocks, 26 heuristic flags, names printed); §3 registry
  **PASS 14/14** (0 token gaps); §4 fence **PASS** (parity OK, 0
  suspects, **14/14 EXACT**); §5 param demo PASS; §6 dashboard
  ASSEMBLED with counts; mutants **(a) REFUSED, (a2) REFUSED,
  (a3) REFUSED, (b) CAUGHT (1 missing), (c) CAUGHT (whole block deleted,
  12 lines; fixture verified to contain zero provenance remnants),
  (d) CAUGHT (parity broken + fused-fence suspect)**.
- `sha256sum -c FREEZE_MANIFEST.sha256` — OK (freeze hash unchanged).
- `sha256sum -c INSTRUMENT_MANIFEST.sha256` — OK.
