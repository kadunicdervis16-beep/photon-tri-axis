#!/usr/bin/env python3
"""Scripted MCP client proof for honesty_plugin's MCP server.

Speaks raw MCP JSON-RPC (NDJSON) over stdio — no SDK on the client side —
so the same proof exercises the server's SDK path and its stdlib fallback
path identically. Performs: a hostile-lines prelude (batch array, bare
scalar, malformed JSON — the server must survive and keep serving),
initialize, notifications/initialized, tools/list, and three tools/call
round-trips (lint_provenance on a fixture; param_prov on a
verdict-injection fixture, which must come back REFUSED; and a call to a
nonexistent target, which must come back as a headered ERROR with
isError=true — on BOTH server paths).

Usage:
  python3 tests/mcp_proof.py -- <server command...>
e.g.
  python3 tests/mcp_proof.py -- python3 -m honesty_plugin.mcp_server
Exit 0 iff every proof step checks out. Prints a transcript summary.
"""
import json
import subprocess
import sys
from pathlib import Path

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def main() -> int:
    if "--" not in sys.argv:
        print("usage: mcp_proof.py -- <server command...>")
        return 2
    cmd = sys.argv[sys.argv.index("--") + 1:]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True)
    checks: list[tuple[str, bool]] = []

    def check(name: str, ok: bool) -> None:
        checks.append((name, ok))
        print(f"[{'PASS' if ok else 'FAIL'}] {name}")

    def send(obj) -> None:
        proc.stdin.write((obj if isinstance(obj, str) else json.dumps(obj)) + "\n")
        proc.stdin.flush()

    def recv(want_id) -> dict:
        while True:
            line = proc.stdout.readline()
            if not line:
                raise RuntimeError("server closed stdout unexpectedly")
            msg = json.loads(line)
            if msg.get("id") == want_id:
                return msg

    try:
        # ---- hostile-lines prelude: none of these may kill the server -----
        send('[{"jsonrpc": "2.0", "id": 99, "method": "ping"}]')   # batch array
        send("42")                                                  # bare scalar
        send("{this is not json")                                   # malformed
        send({"jsonrpc": "2.0", "id": 0, "method": "ping", "params": {}})
        pong = recv(0)
        check("hostile prelude: server survives batch/scalar/malformed lines",
              pong.get("result") == {} or "result" in pong)

        send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "honesty-proof-client", "version": "1.0"}}})
        init = recv(1)
        si = init.get("result", {}).get("serverInfo", {})
        check("initialize: server identifies as honesty-plugin",
              si.get("name") == "honesty-plugin")
        check("initialize: protocolVersion echoed",
              init.get("result", {}).get("protocolVersion") == "2024-11-05")
        send({"jsonrpc": "2.0", "method": "notifications/initialized"})

        send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        listing = recv(2)
        names = [t["name"] for t in listing.get("result", {}).get("tools", [])]
        expected = {"run_verification_suite", "check_registry_pointers",
                    "lint_provenance", "param_prov", "fence_and_listing_check",
                    "audit_dashboard", "validate_cards"}
        check("tools/list: all seven tools advertised (six v1 + validate_cards)",
              expected.issubset(set(names)))

        send({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
            "name": "lint_provenance",
            "arguments": {"target": str(FIXTURES / "with_prov.py")}}})
        call = recv(3)
        text = call.get("result", {}).get("content", [{}])[0].get("text", "")
        check("tools/call lint_provenance: full disclosure header (five parts + freeze hash)",
              "CRITERIA: comparative-honesty-audit v1.0" in text
              and "native domain:" in text and "verified domain:" in text
              and "map:" in text and "preserves:" in text and "outside:" in text
              and "9abc91c9eee9" in text)
        check("tools/call lint_provenance: block detected",
              "[BLOCK]" in text)

        send({"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {
            "name": "lint_provenance",
            "arguments": {"target": "/nonexistent/honesty_proof_target_xyz"}}})
        call = recv(5)
        res5 = call.get("result", {})
        text5 = res5.get("content", [{}])[0].get("text", "")
        check("tools/call error: headered ERROR report with isError=true",
              res5.get("isError") is True and "RESULT: ERROR" in text5
              and "CRITERIA:" in text5)

        send({"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {
            "name": "param_prov",
            "arguments": {"table_path": str(FIXTURES / "verdict_table.json")}}})
        call = recv(4)
        text = call.get("result", {}).get("content", [{}])[0].get("text", "")
        check("tools/call param_prov: verdict-injection REFUSED over MCP",
              "REFUSED" in text and "WITNESS" in text)
    finally:
        proc.stdin.close()
        proc.terminate()
        stderr_tail = proc.stderr.read() if proc.stderr else ""
    if stderr_tail.strip():
        print(f"(server stderr, first line: {stderr_tail.strip().splitlines()[0][:160]})")
    n_pass = sum(1 for _, ok in checks if ok)
    print(f"\nMCP PROOF: {n_pass}/{len(checks)} steps pass")
    return 0 if n_pass == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
