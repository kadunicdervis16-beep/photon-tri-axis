#!/usr/bin/env python3
"""Fixture script WITH an INPUT_PROVENANCE block.

INPUT_PROVENANCE:
  paper-defined:      THRESHOLD (the fixture's pass mark, defined here).
  declared-assumption: NONE.
"""
THRESHOLD = 2
VALUES = [1, 2, 3]

assert max(VALUES) >= THRESHOLD
print("with_prov OK")
