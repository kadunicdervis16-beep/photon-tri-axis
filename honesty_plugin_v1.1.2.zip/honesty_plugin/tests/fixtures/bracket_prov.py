#!/usr/bin/env python3
# INPUT_PROVENANCE:
#   - LIMIT, the fixture bound   [paper-defined] Fixture source S1
#   - SEED, a rig value          [control] Fixture rig
LIMIT = 10
EXTRA = "unnamed"
print("bracket_prov OK")
