#!/usr/bin/env python3
"""Self-test for honesty_plugin v1.1 — run on the FINAL tree before any
delivery claim. Builds its own fixtures in a temp dir; exercises every
tool, the disclosure-header discipline (all five parts AND the freeze
hash), and the planted-mutant classes:

  (a)  verdict-injection into param_prov (value-carried)   -> REFUSED
  (a2) verdict carried by a JSON key                       -> REFUSED
  (a3) verdict carried by the convention / an entry name   -> REFUSED
  (b)  registry entry -> nonexistent script                -> MISSING
  (b2) registry pointer escaping the base dir              -> ESCAPE/FAIL
  (b3) duplicate claim_id                                  -> FAIL
  (c)  script with INPUT_PROVENANCE removed                -> NO BLOCK
  (c2) header present but empty (zero classes)             -> not PASS
  (c3) header string inside executable code (not a block)  -> NO BLOCK
  (d)  listing with a glued closing fence                  -> FAIL
  (d2) double glue with EVEN parity                        -> FAIL
  (d3) tidy fences but zero listings matched               -> FAIL
  plus: bracket-tag provenance style, CRLF NORMALIZED match kind,
  unlisted-suite refusal, dashboard failure propagation, CLI error
  disclosure, and the manifest-absent label.
  Card mutants (validate_cards, Annex v1.1 §A7) over the synthetic
  historical-source fixtures in fixtures/cards/:
  (i)   one-word-altered quote                     -> card REJECTED
  (ii)  quote entirely absent from the source      -> card REJECTED
  (iii) banned construction in the claim field     -> card REJECTED
  (iv)  valid historical-style card (era_note filled, premises located)
                                                   -> accepted
  (v)   duplicate card_id                          -> set FAILs
  (vi)  premises omitted without NONE-form         -> card REJECTED
  (vii) hyphen-line-split banned phrase in claim   -> card REJECTED
  (viii) era_note "n/a" / carder "anonymous"       -> card REJECTED
  (ix)  bridges support ""                         -> card REJECTED
  (x)   evidence bare "NONE"                       -> card REJECTED
  (xi)  card_ids differing only by trailing space  -> set FAILs
  (xii) sources-manifest: correct PASSes / altered hash FAILs,
        with SOURCE lines printing the source sha256
  (xiii) {source_id}.txt fallback resolution       -> SOURCE-FALLBACK
        line + warning that the fallback is a guess

Prints one line per case; exit 0 iff all cases pass.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from honesty_plugin import disclose, tools  # noqa: E402

FIXTURES = Path(__file__).resolve().parent / "fixtures"
CASES: list[tuple[str, bool, str]] = []


def case(name: str, ok: bool, detail: str = "") -> None:
    CASES.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))


def header_ok(text: str) -> bool:
    return ("CRITERIA: comparative-honesty-audit v1.0" in text
            and "native domain:" in text and "verified domain:" in text
            and "map:" in text and "preserves:" in text and "outside:" in text
            and disclose.freeze_short() in text)


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="honesty_selftest_"))

    # ---- lint_provenance: block present, binding-level truth ---------------
    text, data = tools.lint_provenance(str(FIXTURES / "with_prov.py"))
    row = data["rows"][0]
    case("provenance: block detected; named binding classified, unnamed flagged",
         data["n_with_block"] == 1 and header_ok(text)
         and "VALUES" in row["unclassified"] and "THRESHOLD" not in row["unclassified"]
         and data["status"] == "PASS-WITH-WARNINGS",
         f"status={data['status']}, unclassified={row['unclassified']}")

    # ---- lint: bracket-tag declaration style -------------------------------
    text, data = tools.lint_provenance(str(FIXTURES / "bracket_prov.py"))
    row = data["rows"][0]
    case("provenance: bracket-tag style parsed (classes + named binding)",
         row["has_block"] and "paper-defined" in row["classes"]
         and "control" in row["classes"] and "EXTRA" in row["unclassified"]
         and "LIMIT" not in row["unclassified"],
         f"classes={row['classes']}")

    # ---- (c) provenance removed --------------------------------------------
    stripped = (FIXTURES / "with_prov.py").read_text().replace(
        "INPUT_PROVENANCE:", "PROVENANCE_REMOVED:")
    mutant_c = tmp / "no_prov.py"
    mutant_c.write_text(stripped)
    text, data = tools.lint_provenance(str(mutant_c))
    case("mutant (c): provenance-stripped script flagged NO BLOCK",
         data["n_with_block"] == 0 and "NO BLOCK" in text and "WITNESS" in text)

    # ---- (c2) empty block: header only, zero classes, bindings after it ----
    empty = tmp / "empty_block.py"
    empty.write_text('"""INPUT_PROVENANCE:\n"""\nSECRET = 42\nOTHER = "x"\n')
    text, data = tools.lint_provenance(str(empty))
    row = data["rows"][0]
    case("mutant (c2): empty block is not a PASS; body bindings not self-classified",
         data["status"] == "PASS-WITH-WARNINGS" and row["has_block"]
         and not row["classes"] and set(row["unclassified"]) == {"SECRET", "OTHER"},
         f"status={data['status']}, unclassified={row['unclassified']}")

    # ---- (c3) header inside a string constant is not a block ----------------
    strlit = tmp / "string_header.py"
    strlit.write_text('MARKER = "INPUT_PROVENANCE: SECRET is paper-defined"\nSECRET = 1\n')
    text, data = tools.lint_provenance(str(strlit))
    case("mutant (c3): header string in executable code does not count as a block",
         data["n_with_block"] == 0 and data["status"] == "FAIL")

    # ---- registry: good + (b) missing + (b2) escape + (b3) duplicate --------
    reg = {"entries": [
        {"claim_id": "T1", "script": "with_prov.py", "checks": "threshold values assert"},
        {"claim_id": "T2", "script": "definitely_missing_script.py"},
    ]}
    reg_path = tmp / "registry.json"
    reg_path.write_text(json.dumps(reg))
    text, data = tools.check_registry_pointers(str(reg_path), base_dir=str(FIXTURES))
    case("registry: existing script OK",
         data["rows"][0]["exists"] and header_ok(text))
    case("mutant (b): registry entry pointing at nonexistent script flagged",
         (not data["rows"][1]["exists"]) and "MISSING" in text and "WITNESS" in text)

    reg_esc = tmp / "registry_escape.json"
    reg_esc.write_text(json.dumps({"entries": [
        {"claim_id": "E1", "script": "/etc/hostname"}]}))
    text, data = tools.check_registry_pointers(str(reg_esc), base_dir=str(FIXTURES))
    case("mutant (b2): absolute-path pointer flagged ESCAPE, registry FAILs",
         data["status"] == "FAIL" and data["rows"][0]["escape"] and "ESCAPE" in text)

    reg_dup = tmp / "registry_dup.json"
    reg_dup.write_text(json.dumps({"entries": [
        {"claim_id": "DUP", "script": "with_prov.py"},
        {"claim_id": "DUP", "script": "with_prov.py"}]}))
    text, data = tools.check_registry_pointers(str(reg_dup), base_dir=str(FIXTURES))
    case("mutant (b3): duplicate claim_id FAILs the registry check",
         data["status"] == "FAIL" and "DUPLICATE" in text)

    # ---- param_prov: clean + (a)/(a2)/(a3) verdict-injection ----------------
    text, data = tools.param_prov(str(FIXTURES / "clean_table.json"))
    case("param_prov: clean table classified, counts per class, guard line present",
         data["status"].startswith("PASS") and data["counts"].get("fitted") == 1
         and "no comparative verdict is emitted" in text and header_ok(text))
    text, data = tools.param_prov(str(FIXTURES / "verdict_table.json"))
    case("mutant (a): verdict-injection (value) REFUSED with witness",
         data["status"] == "REFUSED" and "WITNESS" in text and "preferable" in text)

    key_tab = tmp / "key_verdict.json"
    key_tab.write_text(json.dumps({
        "convention": "fixture counting rules",
        "therefore the ledger is preferable": "yes",
        "entries": [{"name": "a", "class": "fitted"}]}))
    text, data = tools.param_prov(str(key_tab))
    case("mutant (a2): verdict carried by a JSON key REFUSED",
         data["status"] == "REFUSED" and "WITNESS" in text)

    conv_tab = tmp / "conv_verdict.json"
    conv_tab.write_text(json.dumps({
        "convention": "superiority of the ledger (counting rules)",
        "entries": [{"name": "a", "class": "fitted"}]}))
    text, data = tools.param_prov(str(conv_tab))
    case("mutant (a3): verdict carried by the convention string REFUSED (never echoed under PASS)",
         data["status"] == "REFUSED")

    name_tab = tmp / "name_verdict.json"
    name_tab.write_text(json.dumps({
        "convention": "fixture counting rules",
        "entries": [{"name": "ledger wins", "class": "fitted"}]}))
    text, data = tools.param_prov(str(name_tab))
    case("mutant (a3b): verdict carried by an entry name REFUSED",
         data["status"] == "REFUSED")

    empty_tab = tmp / "empty_table.json"
    empty_tab.write_text(json.dumps({"convention": "fixture rules", "entries": []}))
    text, data = tools.param_prov(str(empty_tab))
    case("param_prov: zero-entry table FAILs (no vacuous PASS)",
         data["status"] == "FAIL")

    # ---- fence: clean + (d) glued + (d2) double glue + (d3) zero match -----
    script_text = (FIXTURES / "with_prov.py").read_text()
    clean_md = tmp / "clean.md"
    clean_md.write_text("# Fixture paper\n\n```python\n" + script_text + "```\n")
    text, data = tools.fence_and_listing_check(str(clean_md), str(FIXTURES))
    case("fence: clean listing parity OK, matched EXACT by content",
         data["parity_ok"] and data["n_matched"] == 1
         and data["blocks"][0]["kind"] == "EXACT" and header_ok(text))

    crlf_md = tmp / "crlf.md"
    crlf_md.write_bytes(("# Fixture paper\r\n\r\n```python\r\n"
                         + script_text.replace("\n", "\r\n") + "```\r\n").encode())
    text, data = tools.fence_and_listing_check(str(crlf_md), str(FIXTURES))
    case("fence: CRLF listing matched with kind NORMALIZED (not claimed byte-identical)",
         data["n_matched"] == 1 and data["blocks"][0]["kind"] == "NORMALIZED",
         f"kind={data['blocks'][0]['kind'] if data['blocks'] else None}")

    glued_md = tmp / "glued.md"
    glued_md.write_text("# Fixture paper\n\n```python\n" + script_text.rstrip("\n") + "```\n")
    text, data = tools.fence_and_listing_check(str(glued_md), str(FIXTURES))
    case("mutant (d): glued closing fence FAILS with witness",
         data["status"] == "FAIL" and (not data["parity_ok"] or data["glued"])
         and ("FUSED FENCE SUSPECT" in text or "PARITY FAIL" in text))

    dbl = tmp / "double_glue.md"
    body = script_text.rstrip("\n")
    dbl.write_text("# Fixture paper\n\n```python\n" + body + "```\n"
                   "\nSome prose```\n\n```python\n" + body + "\n```\n")
    text, data = tools.fence_and_listing_check(str(dbl), str(FIXTURES))
    case("mutant (d2): double glue with EVEN parity FAILS (fused-fence suspects)",
         data["status"] == "FAIL" and len(data["glued"]) >= 2,
         f"parity_ok={data['parity_ok']}, suspects={len(data['glued'])}")

    nomatch_dir = tmp / "unrelated"
    nomatch_dir.mkdir()
    (nomatch_dir / "other.py").write_text("print('unrelated')\n")
    text, data = tools.fence_and_listing_check(str(clean_md), str(nomatch_dir))
    case("mutant (d3): tidy fences with ZERO listings matched FAIL (no vacuous PASS)",
         data["status"] == "FAIL" and data["n_matched"] == 0)

    # ---- suite: RB1-style + unlisted refusal --------------------------------
    pkg = tmp / "mini_pkg"
    (pkg / "scripts").mkdir(parents=True)
    (pkg / "scripts" / "with_prov.py").write_text((FIXTURES / "with_prov.py").read_text())
    runner = pkg / "scripts" / "RB1_run_all.py"
    runner.write_text(
        "# INPUT_PROVENANCE:\n"
        "#   control: SUITE and rc (the runner's own bookkeeping, selftest fixture).\n"
        "import subprocess, sys\n"
        "from pathlib import Path\n"
        "SUITE = [(\"with_prov.py\", False)]\n"
        "rc = 0\n"
        "for name, _ in SUITE:\n"
        "    rc |= subprocess.run([sys.executable, str(Path(__file__).parent / name)]).returncode\n"
        "print('RB1 PASS' if rc == 0 else 'RB1 FAIL')\n"
        "sys.exit(rc)\n")
    (pkg / "Paper_mini.md").write_text(
        "# mini\n\n```python\n" + (FIXTURES / "with_prov.py").read_text() + "```\n")
    text, data = tools.run_verification_suite(str(pkg), timeout_s=60)
    case("suite: mini package runs green RB1-style",
         data["status"] == "PASS" and data["n_pass"] == 1 and header_ok(text))

    pkg2 = tmp / "no_runner_pkg"
    (pkg2 / "scripts").mkdir(parents=True)
    (pkg2 / "scripts" / "with_prov.py").write_text((FIXTURES / "with_prov.py").read_text())
    text, data = tools.run_verification_suite(str(pkg2), timeout_s=60)
    case("suite: no runner -> unlisted execution REFUSED by default",
         data["status"] == "REFUSED")
    text, data = tools.run_verification_suite(str(pkg2), timeout_s=60, run_unlisted=True)
    case("suite: run_unlisted=true opt-in executes (explicit)",
         data["status"] == "PASS" and data["n_pass"] == 1)

    # ---- dashboard: clean assembly + failure propagation --------------------
    reg_ok = tmp / "registry_ok.json"
    reg_ok.write_text(json.dumps({"entries": [
        {"claim_id": "T1", "script": "scripts/with_prov.py",
         "checks": "THRESHOLD VALUES"}]}))
    text, data = tools.audit_dashboard(str(pkg), registry_path=str(reg_ok))
    case("dashboard: assembles per-check lines with counts, no composite index",
         data["status"] == "ASSEMBLED" and "NO composite index" in text
         and "lint_provenance" in text and header_ok(text),
         f"checks={data.get('checks')}")

    reg_bad = tmp / "registry_bad.json"
    reg_bad.write_text(json.dumps({"entries": [
        {"claim_id": "X1", "script": "scripts/nope.py"}]}))
    text, data = tools.audit_dashboard(str(pkg), registry_path=str(reg_bad))
    case("dashboard: a failing constituent surfaces as ASSEMBLED-WITH-FAILURES",
         data["status"] == "ASSEMBLED-WITH-FAILURES")

    # ---- validate_cards: valid set + v1.1 header + mutants (i)-(vi) ---------
    cards_dir = FIXTURES / "cards"
    cards_src = cards_dir / "sources"

    def cards_header_ok(t: str) -> bool:
        return ("CRITERIA: comparative-honesty-audit v1.1" in t
                and disclose.annex_short() in t
                and disclose.freeze_short() in t
                and "native domain:" in t and "verified domain:" in t
                and "map:" in t and "preserves:" in t and "outside:" in t)

    def load_cards():
        return json.loads((cards_dir / "valid_cards.json").read_text())

    def run_cards(obj, name):
        p = tmp / name
        p.write_text(json.dumps(obj))
        return tools.validate_cards(str(p), str(cards_src))

    text, data = tools.validate_cards(str(cards_dir / "valid_cards.json"),
                                      str(cards_src))
    case("cards: valid 2-card set PASSes (NONE-form falsifier + empty bridges)",
         data["status"] == "PASS" and data["n_cards"] == 2 and data["n_ok"] == 2
         and not data["rejected"],
         f"status={data['status']}")
    case("cards: v1.1 header (criteria v1.1 + annex short hash + v1.0 short hash + five parts)",
         cards_header_ok(text))
    case("cards (iv): historical-style card accepted (era_note filled, premises located)",
         "[OK] HIST-01-02" in text)

    obj = load_cards()
    obj["cards"][0]["quote"] = obj["cards"][0]["quote"].replace("evening", "nightfall")
    text, data = run_cards(obj, "cards_mutant_i.json")
    case("mutant (i): one-word-altered quote REJECTED with witness, set FAILs",
         data["status"] == "FAIL" and data["n_ok"] == 1
         and "[REJECT] HIST-01-01" in text
         and "The time of one complete oscillation" in text,
         f"rejected={[r['card_id'] for r in data['rejected']]}")

    obj = load_cards()
    obj["cards"][0]["quote"] = ("The comet returned in the winter and was "
                                "visible for forty nights together.")
    text, data = run_cards(obj, "cards_mutant_ii.json")
    case("mutant (ii): quote entirely absent from source REJECTED",
         data["status"] == "FAIL" and "[REJECT] HIST-01-01" in text
         and "not found verbatim" in text)

    obj = load_cards()
    obj["cards"][0]["claim"] = ("This establishes that the ledger is more "
                                "honest than the Standard Model.")
    text, data = run_cards(obj, "cards_mutant_iii.json")
    case("mutant (iii): banned construction in claim REJECTED, matched phrase printed",
         data["status"] == "FAIL" and "[REJECT] HIST-01-01" in text
         and "establishes that the ledger" in text
         and "more honest than" in text)

    obj = load_cards()
    obj["cards"][1]["card_id"] = obj["cards"][0]["card_id"]
    text, data = run_cards(obj, "cards_mutant_v.json")
    case("mutant (v): duplicate card_id FAILs the set",
         data["status"] == "FAIL" and "duplicate card_id" in text
         and len(data["rejected"]) == 2)

    obj = load_cards()
    del obj["cards"][0]["premises"]
    text, data = run_cards(obj, "cards_mutant_vi.json")
    case("mutant (vi): premises omitted without NONE-form REJECTED",
         data["status"] == "FAIL" and "[REJECT] HIST-01-01" in text
         and "premises" in text)

    # ---- v1.1.1 repair mutants (vii)-(xiii) ---------------------------------
    def run_cards_manifest(obj, name, manifest):
        p = tmp / name
        p.write_text(json.dumps(obj))
        return tools.validate_cards(str(p), str(cards_src),
                                    sources_manifest=manifest)

    obj = load_cards()
    obj["cards"][0]["claim"] = "This is more honest-\nthan the other account."
    text_a, data_a = run_cards(obj, "cards_mutant_vii_a.json")
    obj = load_cards()
    obj["cards"][0]["claim"] = "This is more hon-\nest than the other account."
    text_b, data_b = run_cards(obj, "cards_mutant_vii_b.json")
    case("mutant (vii): hyphen-line-split banned phrase in claim REJECTED "
         "(word-boundary and intra-word splits)",
         data_a["status"] == "FAIL" and "[REJECT] HIST-01-01" in text_a
         and "more honest than" in text_a
         and data_b["status"] == "FAIL" and "[REJECT] HIST-01-01" in text_b
         and "more honest than" in text_b)

    obj = load_cards()
    obj["cards"][0]["era_note"] = "n/a"
    text_a, data_a = run_cards(obj, "cards_mutant_viii_a.json")
    obj = load_cards()
    obj["cards"][0]["carder"] = "anonymous"
    text_b, data_b = run_cards(obj, "cards_mutant_viii_b.json")
    case("mutant (viii): era_note 'n/a' REJECTED; carder 'anonymous' REJECTED",
         data_a["status"] == "FAIL" and "[REJECT] HIST-01-01" in text_a
         and "era_note" in text_a and "WITNESS" in text_a
         and data_b["status"] == "FAIL" and "[REJECT] HIST-01-01" in text_b
         and "anonymous cards are not admitted" in text_b)

    obj = load_cards()
    obj["cards"][0]["bridges"][0]["support"] = ""
    text, data = run_cards(obj, "cards_mutant_ix.json")
    case("mutant (ix): bridges support '' REJECTED (non-empty string required)",
         data["status"] == "FAIL" and "[REJECT] HIST-01-01" in text
         and "support is not a non-empty string" in text)

    obj = load_cards()
    obj["cards"][0]["evidence"] = "NONE"
    text_a, data_a = run_cards(obj, "cards_mutant_x_a.json")
    obj = load_cards()
    obj["cards"][0]["evidence"] = "NONE — ."
    text_b, data_b = run_cards(obj, "cards_mutant_x_b.json")
    obj = load_cards()
    obj["cards"][0]["evidence"] = "NONE — no evidence is offered in the text."
    text_c, data_c = run_cards(obj, "cards_mutant_x_c.json")
    case("mutant (x): evidence bare 'NONE' (and 'NONE' + punctuation only) "
         "REJECTED with witness; 'NONE — <reason>' accepted",
         data_a["status"] == "FAIL" and "[REJECT] HIST-01-01" in text_a
         and "WITNESS" in text_a and "NONE" in text_a
         and data_b["status"] == "FAIL"
         and data_c["status"] == "PASS")

    # (xiv) v1.1.2 (Paper 12.5 v4 loop RT4-2): a NONE-form whose reason is
    # punctuation only carries no substance and must be REJECTED.
    obj = load_cards()
    obj["cards"][0]["falsifier"] = {"none": True, "reason": "!!! ??? ..."}
    text, data = run_cards(obj, "cards_mutant_xiv.json")
    case("mutant (xiv): NONE-form with punctuation-only reason REJECTED (v1.1.2)",
         data["status"] == "FAIL" and "[REJECT] HIST-01-01" in text)

    obj = load_cards()
    obj["cards"][1]["card_id"] = obj["cards"][0]["card_id"] + " "
    text, data = run_cards(obj, "cards_mutant_xi.json")
    case("mutant (xi): card_ids differing only by a trailing space FAIL the "
         "set (whitespace-stripped duplicate comparison)",
         data["status"] == "FAIL" and "duplicate card_id" in text
         and len(data["rejected"]) == 2)

    hist_sha = hashlib.sha256((cards_src / "HIST-01.txt").read_bytes()).hexdigest()
    hist_bytes = (cards_src / "HIST-01.txt").stat().st_size
    good_manifest = str(cards_dir / "sources.sha256")
    text, data = run_cards_manifest(load_cards(), "cards_xii_good.json",
                                    good_manifest)
    altered = tmp / "sources_altered.sha256"
    altered.write_text(
        (cards_dir / "sources.sha256").read_text().replace(
            hist_sha, "0" + hist_sha[1:]))
    text_alt, data_alt = run_cards_manifest(load_cards(),
                                            "cards_xii_alt.json",
                                            str(altered))
    case("mutant (xii): sources-manifest correct -> PASS with SOURCE line "
         "printing the fixture hash + '(verified)' note; altered hash -> FAIL "
         "with expected/actual witness",
         data["status"] == "PASS"
         and f"SOURCE HIST-01 -> HIST-01.txt sha256 {hist_sha} "
             f"({hist_bytes} bytes)" in text
         and f"sources manifest: {good_manifest} (verified)" in text
         and data.get("sources_manifest_verified") is True
         and data_alt["status"] == "FAIL" and len(data_alt["rejected"]) == 2
         and "expected" in text_alt and hist_sha in text_alt
         and ("0" + hist_sha[1:]) in text_alt,
         f"good={data['status']}, altered={data_alt['status']}")

    # the valid fixture carries no sources map, so HIST-01 resolves by
    # the {source_id}.txt fallback
    text, data = tools.validate_cards(str(cards_dir / "valid_cards.json"),
                                      str(cards_src))
    case("cards (xiii): fallback resolution prints SOURCE-FALLBACK line "
         "and the guess warning",
         data["status"] == "PASS" and "SOURCE-FALLBACK" in text
         and f"SOURCE HIST-01 -> HIST-01.txt sha256 {hist_sha}" in text
         and "the fallback is a guess, not a manifest resolution" in text)

    # ---- CLI surface: headered error + exit 2 --------------------------------
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    proc = subprocess.run(
        [sys.executable, "-m", "honesty_plugin", "provenance",
         str(tmp / "does_not_exist_xyz")],
        capture_output=True, text=True, env=env)
    case("CLI: tool error prints the disclosure header and exits 2",
         proc.returncode == 2 and "CRITERIA:" in proc.stdout
         and "RESULT: ERROR" in proc.stdout,
         f"rc={proc.returncode}")

    # ---- manifest absent: label must NOT claim manifest-verified -------------
    copy_root = tmp / "tree_copy"
    src_root = Path(__file__).resolve().parents[1]
    shutil.copytree(src_root / "src", copy_root / "src")
    shutil.copy2(src_root / "FREEZE_v1.0.md", copy_root / "FREEZE_v1.0.md")
    env2 = dict(os.environ)
    env2["PYTHONPATH"] = str(copy_root / "src")
    proc = subprocess.run(
        [sys.executable, "-m", "honesty_plugin", "provenance",
         str(FIXTURES / "with_prov.py")],
        capture_output=True, text=True, env=env2)
    case("disclosure: manifest absent -> header says NOT manifest-verified",
         "NOT manifest-verified" in proc.stdout,
         f"rc={proc.returncode}")

    n_pass = sum(1 for _, ok, _ in CASES if ok)
    print(f"\nSELFTEST: {n_pass}/{len(CASES)} cases pass")
    return 0 if n_pass == len(CASES) else 1


if __name__ == "__main__":
    raise SystemExit(main())
