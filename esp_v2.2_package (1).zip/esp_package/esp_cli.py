#!/usr/bin/env python3
"""
esp_cli.py — command-line presenter for the ESP v2.2 validator.

TRUST BOUNDARY (read before modifying):
  This tool is a PRESENTER, never a fixer. Envelopes pass through
  byte-identical to validate_message(); the ONLY place hashes may be
  filled is inside validate_message() itself (the v2.0.1 chat tier),
  where the checks list honestly records "computed-locally" vs
  "verified". If this CLI ever "helpfully" blanked forged hashes, fixed
  version strings, or renamed keys before validating, it would launder
  REJECTs into VALIDATEDs — that is forbidden by design.

Usage:
  python3 esp_cli.py validate [--batch] [--format phone|full|json] [file ...]
  (no file -> reads stdin; Dervis pastes chat output straight in)

Exit codes: 0 = all VALIDATED, 1 = any REJECTED, 2 = input error.
Standard library only.
"""

import json
import re
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from esp_v2 import Policy, validate_message, VERSION  # noqa: E402

FENCE_RE = re.compile(r"```(?:json)?\s*\n(.*?)```", re.DOTALL)


def extract_envelopes(text, batch=False):
    """Pull JSON envelopes out of pasted chat text. Never repairs.

    Returns (found, total): found is the list to validate (all in batch
    mode, the largest in single mode); total is how many were found, so
    callers can warn visibly when envelopes were skipped.
    """
    candidates = []
    for m in FENCE_RE.finditer(text):
        candidates.append(m.group(1))
    if not candidates:
        candidates = [text]
    found = []
    for cand in candidates:
        for obj in _balanced_objects(cand):
            try:
                parsed = json.loads(obj)
            except (json.JSONDecodeError, ValueError):
                continue
            if isinstance(parsed, dict) and "protocol" in parsed:
                found.append(obj)
    total = len(found)
    if not batch and total > 1:
        # single mode: validate the largest overall, but the caller must
        # say so IN THE VERDICT (phone users never see stderr).
        found.sort(key=len, reverse=True)
        found = found[:1]
    return found, total


def _balanced_objects(text):
    """Yield brace-balanced {...} substrings, largest-first per start."""
    out = []
    i = 0
    while i < len(text):
        if text[i] == "{":
            depth, instr, esc, j = 0, False, False, i
            while j < len(text):
                c = text[j]
                if instr:
                    if esc:
                        esc = False
                    elif c == "\\":
                        esc = True
                    elif c == '"':
                        instr = False
                else:
                    if c == '"':
                        instr = True
                    elif c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                        if depth == 0:
                            out.append(text[i:j + 1])
                            break
                j += 1
            i = j + 1 if j < len(text) else len(text)
        else:
            i += 1
    out.sort(key=len, reverse=True)
    return out


# Curated plain-language mapping: fixed error classes -> one plain sentence
# + one action sentence. The raw error stays available in --format full.
WHY_MAP = [
    ("content hash mismatch",
     "the sender's content hash doesn't match the content — forged or mistyped hash.",
     'leave content_hash and envelope_hash as "" — the validator computes them.'),
    ("envelope hash mismatch",
     "the sender's envelope hash doesn't match the header/context — forged or mistyped hash.",
     'leave content_hash and envelope_hash as "" — the validator computes them.'),
    ("expected one of",
     "a field uses a value outside the protocol's fixed vocabulary.",
     "use only the values listed in the chat kit — never invent new ones."),
    ("LEVEL_A requires",
     "a LEVEL_A badge was claimed without the mandatory falsification condition.",
     "add at least one falsification condition, or downgrade the badge to LEVEL_B."),
    ("axiom_set_hash mismatch",
     "the envelope's registry doesn't match the local registry.",
     "agree on the shared registry hash out-of-band before exchanging."),
    ("must be PENDING",
     "the sender declared its own validation status.",
     "set integrity.status to \"PENDING\" — only the validator decides."),
    ("in_reply_to",
     "a RESPONSE doesn't name the message it answers.",
     "set header.in_reply_to to the antecedent's message_id."),
    ("replay bound",
     "the envelope's timestamp is older than the policy's replay bound.",
     "re-emit with a current timestamp."),
    ("clock skew",
     "the envelope's timestamp is too far in the future.",
     "check the sender's clock and re-emit."),
    ("policy violations",
     "the content tripped the protocol's language policy.",
     "see the violations list in --format full for the exact span and term."),
    ("JSON parse failure",
     "the pasted text isn't valid JSON.",
     "paste the raw envelope without editing it."),
    ("unsupported protocol",
     "the envelope isn't ESP or the version doesn't match.",
     "use the chat kit template for the current version."),
    ("TIER_MISMATCH",
     "this message type needs the archival tier — the working tier carries conversation only.",
     "resend with envelope_tier \"archival\" and a full epistemic_context."),
    ("FREE_TEXT_DEPTH_EXCEEDED",
     "a nested field exceeded the depth bound — rejected fail-closed, never silently truncated.",
     "restructure the payload to nest less deeply (max 8 levels)."),
]


def why_plain(error):
    for needle, why, action in WHY_MAP:
        if needle in error:
            return why, action
    return ("rejected: " + error[:160], "see --format full for the raw error.")


NOT_ESTABLISHED_PHONE = [
    "claim truth",
    "sender identity",
    "transport authenticity",
    "mathematical soundness",
    "semantic validity",  # v2.0.4 D4
    "proof-script correspondence",
]


def _tier_of(result):
    for c in result.get("checks", []):
        if c.startswith("tier:"):
            return c.split(":", 1)[1].replace("-inferred", " (inferred)") \
                .replace("-declared", " (declared)")
    return "unknown"


def _envelope_tier_of(result):
    for c in result.get("checks", []):
        if c.startswith("envelope_tier:"):
            return c.split(":", 1)[1]
    return "unknown"


def phone_verdict(result, skipped_notice=""):
    lines = []
    status = result.get("status", "REJECTED")
    # v2.0.4 (held item): the headline names the message_id — the handle
    # Dervis uses to thread, cite, and re-check an envelope.
    mid = result.get("message_id", "?")
    if result.get("ok"):
        lines.append(
            f"ESP {VERSION} verdict: VALIDATED · {_tier_of(result)} tier · "
            f"{_envelope_tier_of(result)} envelope")
        lines.append(f"message_id: {mid}")
    else:
        lines.append(f"ESP {VERSION} verdict: REJECTED")
        lines.append(f"message_id: {mid}")
        why, action = why_plain(result.get("error", ""))
        lines.append(f"Why (plain): {why}")
        lines.append(f"What to do: {action}")
    warnings = result.get("firewall_warnings") or []
    if warnings:
        # v2.0.4 D1 advisory mode: working-tier lexical findings are
        # warnings, not rejections — shown plainly, never hidden.
        terms = sorted({w.get("term", "?") for w in warnings})
        lines.append(f"Firewall warnings (advisory, working tier): "
                     f"{', '.join(terms)}")
    if skipped_notice:
        lines.append(f"Note: {skipped_notice}")
    checks = result.get("checks", [])
    lines.append("Checks that ran: " + (", ".join(checks) if checks else "none"))
    lines.append("Not proven by this check: "
                 + ", ".join(NOT_ESTABLISHED_PHONE))
    lines.append("Registry note: demo placeholder registry — envelope "
                 "integrity only, not production.")
    return "\n".join(lines)


def main(argv):
    if len(argv) < 2 or argv[1] != "validate":
        sys.stderr.write("usage: esp_cli.py validate [--batch] "
                         "[--format phone|full|json | --format=X] [file ...]\n")
        return 2
    args = argv[2:]
    batch = "--batch" in args
    fmt = "phone"
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--batch":
            pass
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]
        elif a == "--format" and i + 1 < len(args):
            fmt = args[i + 1]
            i += 1
        elif not a.startswith("--"):
            rest.append(a)
        i += 1
    files = rest

    texts = []
    if files:
        for f in files:
            try:
                with open(f, encoding="utf-8") as fh:
                    texts.append((f, fh.read()))
            except OSError as exc:
                sys.stderr.write(f"input error: cannot read {f}: {exc}\n")
                return 2
    else:
        texts = [("<stdin>", sys.stdin.read())]

    policy = Policy(insecure_demo_registry=True, warn_on_validate=False)
    # v2.0.4 V22: the CLI suppresses the demo warning itself (batch use);
    # phone users never see stderr, and the registry note below covers it.
    _demo_warning = ""

    results = []  # (name, sender, result, skipped_notice)
    for name, text in texts:
        found, total = extract_envelopes(text, batch=batch)
        if not found:
            sys.stderr.write(f"input error: no ESP envelope found in {name}\n")
            return 2
        skipped = ""
        if not batch and total > 1:
            skipped = (f"{total} envelopes found; validated the largest "
                       "only — use --batch to check all")
        for obj in found:
            envelope = json.loads(obj)  # byte-identical passthrough
            sender = envelope.get("header", {}).get("sender_agent", "?")
            # v2.0.4 V22: warn_on_validate=False, so no stderr capture
            # needed — the call below cannot print the demo warning.
            result = validate_message(envelope, policy)
            results.append((name, sender, result, skipped))

    if fmt == "json":
        print(json.dumps([r for _, _, r, _ in results], indent=2))
    elif fmt == "full":
        for name, sender, r, skipped in results:
            print(f"--- {name} (sender: {sender}) ---")
            print(phone_verdict(r, skipped))
            print("raw:", json.dumps(r, indent=2)[:3000])
    else:  # phone
        if batch and len(results) > 1:
            print("sender | verdict | why")
            for _, sender, r, _ in results:
                why = ""
                if not r.get("ok"):
                    why, _ = why_plain(r.get("error", ""))
                    why = why[:80]
                print(f"{sender} | {r.get('status')} | {why}")
            print()
        for name, sender, r, skipped in results:
            if len(results) > 1 or len(texts) > 1:
                print(f"--- {name} (sender: {sender}) ---")
            print(phone_verdict(r, skipped))
            print()

    return 0 if all(r.get("ok") for _, _, r, _ in results) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
