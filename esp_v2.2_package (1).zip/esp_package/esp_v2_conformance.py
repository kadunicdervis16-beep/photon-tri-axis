#!/usr/bin/env python3
"""
ESP v2.2 conformance battery (Part 4 of esp_v2_design_brief.md).

Every case asserts the RIGHT rejection (error names the specific cause),
not just any failure. Must exit 0. Standard library only.

v2.0.4 additions: tiered envelopes (envelope_tier working/archival,
TIER_MISMATCH, context:undeclared), advisory firewall (firewall_warnings),
DISAGREEMENT + CONFRONTATION records, RT-001 fail-closed depth bound,
V19 attribute-chain dynamic calls, V20/V21/V22 policy hygiene,
case-insensitive markers, semantic_validity in not_established.

v24 FORTRESS additions: section 23 (physics_payload static-check profile
coverage — the profile shipped in the v2.2 patch round with only a
lexical-identical record, no python_static_check case under it); section
24 (declared demo registry: DEMO_REGISTRY_HASH + demo_registry=True,
with back-compat pins for the zero-hash insecure path).
"""
import copy
import json
import os
import sys
import uuid
from pathlib import Path

from esp_v2 import (
    Engine, Policy, ZERO_HASH, DEMO_REGISTRY_HASH, canonical, chunk_text,
    digest, make_message, object_digest, envelope_for_hash, reassemble,
    validate_message, ProtocolError, _free_texts, DepthBoundExceeded,
    lexical_check,
)

PASS = 0
FAIL = 0
FAILURES: list[str] = []


def demo_policy(**kw):
    kw.setdefault("axiom_set_hash", ZERO_HASH)
    kw.setdefault("insecure_demo_registry", True)
    kw.setdefault("warn_on_validate", False)  # v2.0.4 V22: quiet battery
    return Policy(**kw)


POLICY = demo_policy()
ENGINE = Engine(POLICY)


def base_kwargs(**kw):
    d = dict(sender="agent_A", target="agent_B", register="STAGE_P",
             badge="LEVEL_B", content="A plain structural claim.",
             lineage="prose")
    d.update(kw)
    return d


def good_msg(**kw):
    return ENGINE.make_message(**base_kwargs(**kw))


def check(label, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append(f"{label}: {detail}")


def expect_reject(label, message, *needles):
    """message may be a dict, JSON string, or a zero-arg callable."""
    try:
        result = message() if callable(message) else \
            validate_message(message, POLICY)
    except Exception as exc:  # noqa: BLE001 - must never happen
        check(label, False, f"raised {type(exc).__name__}: {exc}")
        return
    if not isinstance(result, dict) or result.get("ok") \
            or result.get("status") != "REJECTED":
        check(label, False, f"not REJECTED: {str(result)[:160]}")
        return
    err = str(result.get("error", ""))
    missing = [n for n in needles if n not in err]
    check(label, not missing,
          f"error missing {missing}; error was: {err[:200]}")


def expect_refusal(label, thunk, *needles):
    """Outbound refusal: make_message must RAISE ValueError naming the cause."""
    try:
        thunk()
    except ValueError as exc:
        err = str(exc)
        missing = [n for n in needles if n not in err]
        check(label, not missing and "outbound refusal" in err,
              f"error missing {missing}; error was: {err[:200]}")
        return
    except Exception as exc:  # noqa: BLE001
        check(label, False, f"wrong exception {type(exc).__name__}: {exc}")
        return
    check(label, False, "invalid payload was emitted (no refusal)")


def resign(msg):
    """Re-sign a mutated message so hash checks pass and policy checks run."""
    msg["integrity"]["content_hash"] = digest(msg["payload"]["content"])
    msg["integrity"]["envelope_hash"] = object_digest(
        envelope_for_hash(msg))
    return msg


def msg_with_content(content, **kw):
    base = dict(kw)
    if base.get("content_format") == "EXECUTABLE_PYTHON":
        base["content"] = "pass\n"  # valid placeholder; replaced below
    m = good_msg(**base)
    m["payload"]["content"] = content
    return resign(m)


def expect_valid(label, message, *checks_present):
    result = validate_message(message, POLICY)
    if not isinstance(result, dict) or not result.get("ok") \
            or result.get("status") != "VALIDATED":
        check(label, False, f"not VALIDATED: {str(result)[:200]}")
        return
    checks = result.get("checks") or []
    missing = [c for c in checks_present if c not in checks]
    check(label, not missing and len(checks) > 0,
          f"checks missing {missing}; checks were {checks}")
    check(label + " [not_established]",
          isinstance(result.get("not_established"), list)
          and len(result["not_established"]) > 0,
          "not_established list missing/empty")


def mutated(**kw):
    m = good_msg()
    m = copy.deepcopy(m)
    for path, value in kw.items():
        node = m
        *segs, last = path.split(".")
        for s in segs:
            node = node[s]
        node[last] = value
    return m


# ---------------------------------------------------------------- 1: types
expect_reject("malformed-json", "{not json", "JSON parse failure")
expect_reject("non-object", [1, 2, 3], "must be a JSON object")
expect_reject("bad-uuid",
              mutated(**{"header.message_id": "nope"}), "invalid UUID")
expect_reject("bad-sha",
              mutated(**{"epistemic_context.axiom_set_hash": "xyz"}),
              "expected lowercase SHA-256")
expect_reject("bad-timestamp",
              mutated(**{"header.timestamp": "yesterday"}),
              "invalid ISO-8601 timestamp")
expect_reject("missing-keys",
              lambda: validate_message({"protocol": {}}, POLICY),
              "missing keys")
m = good_msg()
m["payload"]["bogus_extra"] = 1
expect_reject("unknown-keys", m, "unknown keys")

# ------------------------------------------------- 2: register/badge rules
# (outbound refusal: the constructor must raise naming the cause)
expect_refusal("stageN-levelB",
               lambda: make_message(policy=POLICY, sender="a", target="b",
                                    register="STAGE_N", badge="LEVEL_B",
                                    content="x", lineage="prose"),
               "STAGE_N requires LEVEL_A")
expect_refusal("levelA-no-falsification",
               lambda: make_message(policy=POLICY, sender="a", target="b",
                                    register="STAGE_P", badge="LEVEL_A",
                                    content="x", lineage="prose"),
               "at least one falsification")
expect_refusal("levelA-bridge-B",
               lambda: make_message(
                   policy=POLICY, sender="a", target="b", register="STAGE_P",
                   badge="LEVEL_A", content="x", lineage="prose",
                   falsifiers=[{"id": "C1", "statement": "s"}],
                   bridges=[{"from": "P", "to": "Q",
                             "bridge_level": "B"}]),
               "cannot depend on a level B bridge")
expect_refusal("stochastic-stageN",
               lambda: make_message(
                   policy=POLICY, sender="a", target="b", register="STAGE_N",
                   badge="LEVEL_A", content="x", lineage="prose",
                   determinism={"mode": "STOCHASTIC"},
                   falsifiers=[{"id": "C1", "statement": "s"}]),
               "STAGE_N requires DETERMINISTIC or SEEDED")
expect_refusal("seeded-no-seed",
               lambda: make_message(policy=POLICY, sender="a", target="b",
                                    register="STAGE_P", badge="LEVEL_B",
                                    content="x", lineage="prose",
                                    determinism={"mode": "SEEDED"}),
               "determinism.seed")

# ------------------------------------------------- 3: registry honesty
skewed = demo_policy(registry_version=10, accepted_registry_skew=3)
mm = good_msg()
expect_reject("registry-skew",
              lambda: validate_message(mm, skewed), "skew")
try:
    Policy(axiom_set_hash=ZERO_HASH)  # no opt-in
    check("zero-registry-refuses", False, "constructor did not refuse")
except ValueError as exc:
    check("zero-registry-refuses", "insecure_demo_registry" in str(exc),
          str(exc)[:120])
wrong_hash = demo_policy(axiom_set_hash="ab" * 32)
expect_reject("axiom-hash-mismatch",
              lambda: validate_message(good_msg(), wrong_hash),
              "axiom_set_hash mismatch")

# ------------------------------------------------- 4: tamper detection
m = good_msg()
m["payload"]["content"] += " altered"
expect_reject("content-tamper", m, "content hash mismatch")
m = good_msg()
m["header"]["sender_agent"] = "mallory"
expect_reject("header-tamper", m, "envelope hash mismatch")

# ------------------------------------------------- 5: lexical firewall
# Inbound path: validator must REJECT with the right violation code.
expect_reject("hard-banned",
              msg_with_content("The integral diverges."),
              "HARD_BANNED", "integral")
expect_reject("context-banned-outside",
              msg_with_content("The vacuum expectation is real."),
              "CONTEXT_BANNED", "vacuum")
expect_valid("context-banned-inside-markers",
             msg_with_content("[COMPARATIVE_BEGIN]\nThe vacuum expectation "
                              "is real.\n[COMPARATIVE_END]"),
             "lexical")
expect_reject("unclosed-block",
              msg_with_content("[HISTORICAL_BEGIN]\nThe vacuum is old."),
              "BAD_CONTEXT_MARKER", "unclosed")
expect_reject("nested-block",
              msg_with_content("[COMPARATIVE_BEGIN]\n[SHADOW_BEGIN]\n"
                               "vacuum\n[SHADOW_END]\n[COMPARATIVE_END]"),
              "BAD_CONTEXT_MARKER", "nested")
expect_reject("mismatched-block",
              msg_with_content("[COMPARATIVE_BEGIN]\nthe field\n[SHADOW_END]"),
              "BAD_CONTEXT_MARKER", "mismatched")
# Outbound path: constructor must REFUSE (raise) instead of emitting.
expect_refusal("outbound-refusal-lexical",
               lambda: ENGINE.make_message(
                   **base_kwargs(content="The integral diverges.")),
               "outbound refusal", "HARD_BANNED")

# ------------------------------------------------- 6: arithmetic checks
PY_A = ("import math\n"
        "x = 1\n"
        "print(x)\n")


def py_msg(code, **kw):
    d = dict(register="STAGE_P", badge="LEVEL_A",
             content_format="EXECUTABLE_PYTHON",
             falsifiers=[{"id": "C1", "statement": "s"}])
    d.update(kw)
    return msg_with_content(code, **d)


expect_valid("math-import-passes", py_msg(PY_A), "arithmetic")
PY_FLOAT = "x = 1.5\nprint(x)\n"
expect_reject("float-levelA-reject", py_msg(PY_FLOAT), "FLOAT_IN_LEVEL_A")
PY_DISPLAY = 'print("value:", 1.5)  # (display only)\n'
expect_valid("float-display-passes", py_msg(PY_DISPLAY), "arithmetic")
PY_GAME = 'x = 1.5  # (display only)\n'
expect_reject("float-gameable-reject", py_msg(PY_GAME), "FLOAT_IN_LEVEL_A")
PY_BANNED = "import subprocess\nsubprocess.run(['x'])\n"
expect_reject("banned-module", py_msg(PY_BANNED),
              "BANNED_MODULE", "subprocess")
PY_EVAL = "x = eval('1+1')\n"
expect_reject("eval-reject", py_msg(PY_EVAL), "DYNAMIC_EXECUTION", "eval")

# ------------------------------------------------- 7: chunk protocol
text = "hello world, chunked " * 2000
chunks = chunk_text(text, max_chars=1000)
check("chunk-roundtrip", reassemble(chunks) == text, "roundtrip failed")
reordered = list(reversed(chunks))
check("chunk-reordered-passes", reassemble(reordered) == text,
      "order-independent reassembly failed")
corrupt = copy.deepcopy(chunks)
corrupt[0] = dict(corrupt[0])
corrupt[0]["data"] += "tamper"
try:
    reassemble(corrupt)
    check("chunk-corrupt-rejects", False, "corrupt chunk accepted")
except ProtocolError as exc:
    check("chunk-corrupt-rejects", "hash mismatch" in str(exc),
          str(exc)[:120])
dup = chunks + [chunks[0]]
try:
    reassemble(dup)
    check("chunk-duplicate-rejects", False, "duplicate index accepted")
except ProtocolError as exc:
    check("chunk-duplicate-rejects", "duplicate" in str(exc),
          str(exc)[:120])
missing = chunks[1:]
try:
    reassemble(missing)
    check("chunk-missing-rejects", False, "gap accepted")
except ProtocolError as exc:
    check("chunk-missing-rejects",
          "gap" in str(exc) or "count" in str(exc).lower()
          or "missing" in str(exc).lower(), str(exc)[:120])
other = chunk_text("different text " * 2000, max_chars=1000)
mixed = chunks[:1] + other[:1]
try:
    reassemble(mixed)
    check("chunk-mixed-rejects", False, "mixed transfers accepted")
except ProtocolError as exc:
    check("chunk-mixed-rejects", "mixed transfers" in str(exc),
          str(exc)[:120])

# ------------------------------------------------- 8: outbound refusal
try:
    make_message(policy=POLICY, sender="a", target="b",
                 register="STAGE_N", badge="LEVEL_B", content="x",
                 lineage="prose")
    check("outbound-refusal", False, "invalid payload was emitted")
except ValueError as exc:
    check("outbound-refusal", "outbound refusal" in str(exc),
          str(exc)[:160])

# ------------------------------------------------- 9: v1 migration signal
v1ish = good_msg()
v1ish["protocol"]["version"] = "1.0"
v1ish["epistemic_context"]["axiom_registry_hash"] = \
    v1ish["epistemic_context"].pop("axiom_set_hash")
expect_reject("v1-migration-error", v1ish,
              "axiom_registry_hash -> axiom_set_hash",
              "migrate_v1_to_v2")

# ------------------------------------------------- 10: badge truthfulness
result = validate_message(good_msg(), POLICY)
check("validated-checks-nonempty",
      result.get("ok") and len(result.get("checks", [])) > 0,
      f"checks={result.get('checks')}")
check("validated-checks-name-lexical",
      "lexical" in result.get("checks", []),
      "lexical not in checks despite default-on policy")

# ------------------------------------------------- 11: fuzz-hardening
from esp_v2 import migrate_v1_to_v2


def expect_value_error(label, thunk, *needles):
    try:
        thunk()
    except ValueError as exc:
        err = str(exc)
        missing = [n for n in needles if n not in err]
        check(label, not missing, f"missing {missing}: {err[:160]}")
        return
    except Exception as exc:  # noqa: BLE001
        check(label, False, f"wrong exception {type(exc).__name__}: {exc}")
        return
    check(label, False, "no exception raised")


expect_value_error("migrate-empty-dict", lambda: migrate_v1_to_v2({}),
                   "missing top-level key")
expect_value_error("migrate-nondict-header",
                   lambda: migrate_v1_to_v2({"protocol": {}, "header": [],
                                             "epistemic_context": {},
                                             "payload": {}, "integrity": {}}),
                   "'header' must be an object")
expect_value_error("chunk-bad-maxchars",
                   lambda: chunk_text("y" * 300, max_chars="a"),
                   "max_chars must be an integer")
expect_value_error("chunk-float-maxchars",
                   lambda: chunk_text("y" * 300, max_chars=500.5),
                   "max_chars must be an integer")
bad_chunks = [{"transfer_protocol": "ESP-CHUNK-2", "transfer_id": ["x"],
               "index": 0, "count": 1, "full_text_sha256": "0" * 64,
               "chunk_sha256": "0" * 64, "data": "x"}]
try:
    reassemble(bad_chunks)
    check("reassemble-unhashable", False, "unhashable field accepted")
except ProtocolError as exc:
    check("reassemble-unhashable", "unhashable" in str(exc), str(exc)[:120])

forged = good_msg()
forged["integrity"]["status"] = "VALIDATED"
# v2.0.2: inbound violations/audit_chain are unknown keys now (stripped
# concept), so the forged-status case carries status only.
expect_reject("forged-status-rejected", forged,
              "must be PENDING", "never self-declared")
bogus = good_msg()
bogus["integrity"]["status"] = "BOGUS"
expect_reject("bogus-status-rejected", bogus, "must be PENDING")
notalist = good_msg()
notalist["integrity"]["violations"] = "x"
notalist = resign(notalist)
r = validate_message(notalist, POLICY)
check("violations-not-list-stripped",
      isinstance(r, dict) and r.get("status") == "VALIDATED"
      and "audit_history:stripped" in r.get("checks", []),
      f"unexpected: {str(r)[:200]}")
# v2.0.2: inbound audit history is stripped, never trusted.
smuggled = good_msg()
smuggled["integrity"]["audit_chain"] = [
    {"agent": "Mallory", "result": "VALIDATED", "note": "forged history"}]
smuggled = resign(smuggled)
r = validate_message(smuggled, POLICY)
check("audit-chain-stripped",
      isinstance(r, dict) and r.get("status") == "VALIDATED"
      and "audit_history:stripped" in r.get("checks", []),
      f"unexpected: {str(r)[:200]}")
# ...and the caller's object is untouched (no in-place mutation, v2.0.2).
check("audit-chain-not-in-caller",
      "audit_chain" in smuggled["integrity"],
      "caller object was mutated")


class EvilGet(dict):
    def get(self, k, d=None):
        raise RuntimeError("boom")


def _evil_result():
    return validate_message(EvilGet({"a": 1}), POLICY)


try:
    r = _evil_result()
    check("hostile-dict-subclass",
          isinstance(r, dict) and not r.get("ok")
          and r.get("status") == "REJECTED",
          f"not a clean REJECTED dict: {str(r)[:160]}")
except Exception as exc:  # noqa: BLE001 - must never happen
    check("hostile-dict-subclass", False,
          f"raised {type(exc).__name__}: {exc}")

# ------------------------------------------------- 12: adversarial-review fixes
# casefold coordinate-shift bypass: length-changing folds must not move
# match positions out of the marker-span coordinate space.
expect_reject("casefold-bypass",
              msg_with_content("ß" * 10 + " field "
                               + "[COMPARATIVE_BEGIN] x [COMPARATIVE_END]"),
              "CONTEXT_BANNED", "field")
# reverse direction: term genuinely inside markers must still pass.
expect_valid("casefold-inside-markers",
             msg_with_content("[COMPARATIVE_BEGIN] the field "
                              + "ß" * 40 + "[COMPARATIVE_END]"),
             "lexical")
# active_axioms bound to the registry axiom universe.
evil_axioms = good_msg()
evil_axioms["epistemic_context"]["active_axioms"] = ["BOGUS_AXIOM"]
from esp_v2 import digest as _d, object_digest as _od, \
    envelope_for_hash as _efh
evil_axioms["integrity"]["content_hash"] = \
    _d(evil_axioms["payload"]["content"])
evil_axioms["integrity"]["envelope_hash"] = _od(_efh(evil_axioms))
expect_reject("unknown-axiom", evil_axioms,
              "not in registry axiom universe", "BOGUS_AXIOM")
# shadowed print voids the display exemption.
PY_SHADOW = "print = lambda v: v\ny = print(3.14)  # (display only)\n"
expect_reject("shadowed-print", py_msg(PY_SHADOW), "FLOAT_IN_LEVEL_A")
# three_line_register names its check when present.
tlr_msg = good_msg()
tlr_msg["payload"]["three_line_register"] = {
    "native": "n", "reconstruction": "r", "observation": "o"}
tlr_msg["integrity"]["content_hash"] = \
    _d(tlr_msg["payload"]["content"])
tlr_msg["integrity"]["envelope_hash"] = _od(_efh(tlr_msg))
expect_valid("three-line-register-named", tlr_msg, "three_line_register")
# make_message refuses non-string content with ValueError (not AttributeError).
expect_refusal("content-not-string",
               lambda: make_message(policy=POLICY, sender="a", target="b",
                                    register="STAGE_P", badge="LEVEL_B",
                                    content=123, lineage="prose"),
               "content must be a string")
# bare-string collection footgun refused at construction.
try:
    Policy(axiom_set_hash=ZERO_HASH, insecure_demo_registry=True,
           marker_names="ABC")
    check("bare-string-footgun", False, "bare string silently shredded")
except ValueError as exc:
    check("bare-string-footgun", "bare string" in str(exc),
          str(exc)[:120])


# --- v2.0.1 chat tier: blank hashes are computed locally, forged rejected ---
def blank_hashes(m):
    m = json.loads(json.dumps(m))
    m["integrity"]["content_hash"] = ""
    m["integrity"]["envelope_hash"] = ""
    return m

chat_msg = blank_hashes(good_msg())
r = validate_message(chat_msg, POLICY)
check("chat-tier-blank-hashes-valid",
      isinstance(r, dict) and r.get("status") == "VALIDATED",
      f"not VALIDATED: {str(r)[:200]}")
check("chat-tier-checks-name-tier",
      "content_hash:computed-locally" in r.get("checks", [])
      and "envelope_hash:computed-locally" in r.get("checks", []),
      f"checks: {r.get('checks')}")
check("chat-tier-hashes-filled",
      r.get("content_hash", "").strip() != ""
      and r.get("envelope_hash", "").strip() != "",
      "validator did not fill computed hashes into result")

# Forged (non-empty, wrong) hashes still REJECTED — tamper evidence intact.
forged = blank_hashes(good_msg())
forged["integrity"]["content_hash"] = "ab" * 32
expect_reject("forged-content-hash-rejected", forged, "content hash mismatch")
check("forged-hash-error-names-remedy",
      "leave" in validate_message(forged, POLICY)["error"]
      and "validator computes it" in validate_message(forged, POLICY)["error"],
      "rejection does not tell a chat AI what to do instead")

# Mixed: blank content hash + forged envelope hash -> REJECTED on envelope.
mixed = blank_hashes(good_msg())
mixed["integrity"]["envelope_hash"] = "cd" * 32
expect_reject("mixed-blank-forged-rejected", mixed, "envelope hash mismatch")

# Chat tier still runs policy checks: banned term with blank hashes -> REJECTED
# on the lexical violation, not on hashes.
bad_chat = blank_hashes(msg_with_content("the renormalization of the field"))
bad_chat["payload"]["content"] = "the renormalization of the field"
r2 = validate_message(bad_chat, POLICY)
check("chat-tier-lexical-still-enforced",
      isinstance(r2, dict) and r2.get("status") == "REJECTED"
      and "content_hash:computed-locally" in r2.get("checks", []),
      f"unexpected: {str(r2)[:200]}")

# Non-string hash value -> proper ProtocolError, not crash.
weird = blank_hashes(good_msg())
weird["integrity"]["content_hash"] = 12345
expect_reject("nonstring-hash-rejected", weird, "integrity.content_hash")


# --- v2.0.2: deep-copy (no caller mutation), tier signal, freshness, caps ---
# A1 regression: validating must not mutate the caller's dict. Chat-tier
# hashes stay blank in the caller's object; only the result carries them.
pristine = good_msg()
pristine["integrity"]["content_hash"] = ""
pristine["integrity"]["envelope_hash"] = ""
before = json.loads(json.dumps(pristine))
r = validate_message(pristine, POLICY)
check("no-caller-mutation",
      pristine == before and pristine["integrity"]["content_hash"] == "",
      "validate_message mutated the caller's envelope")
check("no-caller-mutation-valid",
      isinstance(r, dict) and r.get("status") == "VALIDATED",
      f"unexpected: {str(r)[:150]}")
# Revalidating the SAME (still blank-hash) object stays chat tier forever —
# the laundering primitive is dead.
r2 = validate_message(pristine, POLICY)
check("no-tier-escalation",
      "tier:chat-inferred" in r2.get("checks", [])
      and "content_hash:verified" not in r2.get("checks", []),
      f"checks: {r2.get('checks')}")

# Declared tiers enforced.
tchat = good_msg()
tchat["integrity"]["content_hash"] = ""
tchat["integrity"]["envelope_hash"] = ""
tchat["integrity"]["tier"] = "chat"
expect_valid("tier-chat-declared", tchat, "tier:chat-declared")
tmach = good_msg()  # make_message emits real hashes
tmach["integrity"]["tier"] = "machine"
expect_valid("tier-machine-declared", tmach, "tier:machine-declared")
bad_tier = good_msg()
bad_tier["integrity"]["tier"] = "military"
expect_reject("tier-enum-rejected", bad_tier, "integrity.tier")
contra = good_msg()
contra["integrity"]["tier"] = "chat"  # non-empty hashes contradict chat
expect_reject("tier-chat-contradiction", contra, "requires blank")
contra2 = good_msg()
contra2["integrity"]["content_hash"] = ""
contra2["integrity"]["envelope_hash"] = ""
contra2["integrity"]["tier"] = "machine"  # blank hashes contradict machine
expect_reject("tier-machine-contradiction", contra2, "requires non-empty")
# require_machine_tier policy refuses the chat tier outright.
strict_policy = Policy(insecure_demo_registry=True, require_machine_tier=True)
chatm = good_msg()
chatm["integrity"]["content_hash"] = ""
chatm["integrity"]["envelope_hash"] = ""
r = validate_message(chatm, strict_policy)
check("require-machine-tier-refuses-chat",
      isinstance(r, dict) and r.get("status") == "REJECTED"
      and "require_machine_tier" in r.get("error", ""),
      f"unexpected: {str(r)[:150]}")
r = validate_message(good_msg(), strict_policy)
check("require-machine-tier-allows-machine",
      isinstance(r, dict) and r.get("status") == "VALIDATED",
      f"unexpected: {str(r)[:150]}")

# RESPONSE must name its antecedent.
resp = good_msg(message_type="RESPONSE", in_reply_to=str(uuid.uuid4()))
expect_valid("response-with-in-reply-to", resp)
expect_refusal("response-without-in-reply-to-refused",
               lambda: good_msg(message_type="RESPONSE"),
               "in_reply_to")

# Timestamp freshness bound (opt-in).
fresh_policy = Policy(insecure_demo_registry=True, max_age_seconds=3600)
expect_valid("fresh-timestamp-ok", good_msg())
old = good_msg()
old["header"]["timestamp"] = "2020-01-01T00:00:00+00:00"
old = resign(old)
r = validate_message(old, fresh_policy)
check("stale-timestamp-rejected",
      isinstance(r, dict) and r.get("status") == "REJECTED"
      and "replay bound" in r.get("error", ""),
      f"unexpected: {str(r)[:150]}")
future = good_msg()
future["header"]["timestamp"] = "2999-01-01T00:00:00+00:00"
future = resign(future)
r = validate_message(future, fresh_policy)
check("future-timestamp-rejected",
      isinstance(r, dict) and r.get("status") == "REJECTED"
      and "clock skew" in r.get("error", ""),
      f"unexpected: {str(r)[:150]}")
# Default policy (no bound) still accepts old timestamps.
r = validate_message(old, POLICY)
check("no-bound-default-accepts-old",
      isinstance(r, dict) and r.get("status") == "VALIDATED",
      f"unexpected: {str(r)[:150]}")

# scope_notes is lexically scanned (was hashed-but-unscanned).
sneaky = good_msg()
sneaky["epistemic_context"]["scope_notes"] = "the renormalization trick"
sneaky = resign(sneaky)
expect_reject("scope-notes-lexical", sneaky, "renormalization")

# Length caps.
longn = good_msg()
longn["epistemic_context"]["scope_notes"] = "x" * 4001
expect_reject("scope-notes-cap", longn, "exceeds 4000")
longa = good_msg()
longa["header"]["sender_agent"] = "x" * 257
expect_reject("agent-name-cap", longa, "exceeds 256")

# --- v2.0.2 esp_cli.py: extraction + presenter-never-fixer ---
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location(
    "esp_cli", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "esp_cli.py"))
esp_cli = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(esp_cli)

_cli_msg = good_msg()
_cli_json = json.dumps(_cli_msg)
# Extraction from prose-wrapped paste (fenced block).
pasted = "Here you go:\n```json\n" + _cli_json + "\n```\nDone."
found, total = esp_cli.extract_envelopes(pasted)
check("cli-extract-fenced", len(found) == 1 and total == 1
      and json.loads(found[0]) == _cli_msg, f"found {len(found)}/{total}")
# Extraction without fences (bare brace scan).
found2, total2 = esp_cli.extract_envelopes("noise " + _cli_json + " tail")
check("cli-extract-bare", len(found2) == 1 and total2 == 1
      and json.loads(found2[0]) == _cli_msg, f"found {len(found2)}/{total2}")
# No envelope -> empty.
f0, t0 = esp_cli.extract_envelopes("no json here")
check("cli-extract-none", f0 == [] and t0 == 0, "false positive extraction")
# Batch extracts all.
two = pasted + "\nsecond:\n```json\n" + _cli_json + "\n```"
check("cli-extract-batch", len(esp_cli.extract_envelopes(two, batch=True)) == 2,
      "batch missed one")
# Presenter-never-fixer: extraction output is byte-identical to input object.
fm, _ = esp_cli.extract_envelopes(pasted)
check("cli-no-mutation", json.loads(fm[0]) == _cli_msg,
      "extraction altered the envelope")
# phone_verdict shape.
pv = esp_cli.phone_verdict({"ok": True, "status": "VALIDATED",
                            "checks": ["structure", "tier:chat-inferred"],
                            "not_established": []})
check("cli-phone-verdict", "VALIDATED" in pv and "Not proven" in pv
      and "chat (inferred) tier" in pv and "proof-script correspondence" in pv,
      pv[:120])
pvn = esp_cli.phone_verdict({"ok": True, "status": "VALIDATED",
                             "checks": ["structure"]}, "2 found; --batch")
check("cli-phone-skipped-notice", "Note: 2 found; --batch" in pvn, pvn[:80])
rv = esp_cli.phone_verdict({"ok": False, "status": "REJECTED",
                            "error": "content hash mismatch (x)",
                            "checks": ["structure"], "not_established": []})
check("cli-phone-why", "Why (plain):" in rv and "What to do:" in rv, rv[:80])

# --- v2.0.3: [/NAME] grammar, extended lexical fields, unconditional skew ---
# Kit-advertised [NAME]...[/NAME] pair now parses (was silently ignored).
expect_valid("slash-pair-clean",
             msg_with_content("[COMPARATIVE] the manifold [/COMPARATIVE] ok"))
expect_valid("slash-pair-multiline",
             msg_with_content("[COMPARATIVE]\nthe manifold\n[/COMPARATIVE]"))
expect_valid("mixed-pair",
             msg_with_content("[COMPARATIVE_BEGIN] the manifold [/COMPARATIVE]"))
expect_reject("slash-unclosed",
              msg_with_content("[COMPARATIVE] the manifold"),
              "BAD_CONTEXT_MARKER", "unclosed")
expect_reject("slash-unmatched",
              msg_with_content("the manifold [/COMPARATIVE]"),
              "BAD_CONTEXT_MARKER", "unmatched")
expect_reject("slash-mismatched",
              msg_with_content("[COMPARATIVE] the manifold [/SHADOW]"),
              "BAD_CONTEXT_MARKER", "mismatched")
expect_reject("slash-nested",
              msg_with_content("[COMPARATIVE] a [SHADOW] b [/SHADOW] [/COMPARATIVE]"),
              "BAD_CONTEXT_MARKER", "nested")
expect_valid("begin-end-still-works",
             msg_with_content("[COMPARATIVE_BEGIN] the manifold [COMPARATIVE_END]"))

# Extended lexical fields: falsification, metadata, session_id, formal_assertions.
def smuggle(field_fn):
    m = good_msg()
    field_fn(m)
    return resign(m)

f1 = good_msg()
f1["payload"]["falsification"] = {"conditions": [
    {"id": "C1", "statement": "fails if the vacuum shifts"}]}
expect_reject("lexical-falsification", resign(f1), "vacuum")
f2 = good_msg()
f2["payload"]["metadata"] = {"note": "the gauge choice"}
expect_reject("lexical-metadata", resign(f2), "gauge")
f3 = good_msg()
f3["epistemic_context"]["session_id"] = "manifold-session-1"
expect_reject("lexical-session-id", resign(f3), "manifold")
f4 = good_msg()
f4["payload"]["formal_assertions"] = ["field equations hold"]
expect_reject("lexical-formal-assertions", resign(f4), "field")
# ...but inside a proper block they pass.
f5 = good_msg()
f5["payload"]["metadata"] = {"note": "[COMPARATIVE] the gauge choice [/COMPARATIVE]"}
expect_valid("lexical-metadata-blocked", resign(f5), "lexical")
# v2.0.4 (held item): provenance.depends_on and bridge_descriptions are
# scanned free-text channels too.
f6 = good_msg()
f6["payload"]["provenance"]["depends_on"] = ["the vacuum lemma"]
expect_reject("lexical-depends-on", resign(f6), "vacuum")
f7 = good_msg()
f7["payload"]["bridge_levels"] = [{"from": "a", "to": "b",
                                   "bridge_level": "B",
                                   "bridge_description": "the gauge bridge"}]
expect_reject("lexical-bridge-description", resign(f7), "gauge")

# Future-skew bound is unconditional now (no policy flag needed).
sk = good_msg()
sk["header"]["timestamp"] = "2999-01-01T00:00:00+00:00"
r = validate_message(resign(sk), POLICY)
check("skew-unconditional",
      isinstance(r, dict) and r.get("status") == "REJECTED"
      and "clock skew" in r.get("error", ""), f"unexpected: {str(r)[:120]}")

# Boundary tests: caps.
b1 = good_msg(); b1["epistemic_context"]["scope_notes"] = "x" * 4000
expect_valid("scope-notes-4000-ok", resign(b1))
b2 = good_msg(); b2["header"]["sender_agent"] = "x" * 256
expect_valid("agent-256-ok", resign(b2))
# Policy constructor validation.
for bad_kw, needle in [({"max_age_seconds": 0}, "positive int"),
                       ({"max_age_seconds": -5}, "positive int"),
                       ({"max_age_seconds": "hour"}, "positive int"),
                       ({"max_age_seconds": True}, "positive int"),
                       ({"require_machine_tier": "yes"}, "must be a bool")]:
    try:
        Policy(insecure_demo_registry=True, **bad_kw)
        check(f"policy-ctor-{needle}-{bad_kw}", False, "accepted bad value")
    except ValueError as exc:
        check(f"policy-ctor-{str(bad_kw)[:20]}", needle in str(exc),
              str(exc)[:100])
# require_machine_tier vs mixed tier.
mpol = Policy(insecure_demo_registry=True, require_machine_tier=True)
mx = good_msg(); mx["integrity"]["content_hash"] = ""
r = validate_message(mx, mpol)
check("require-machine-tier-mixed",
      isinstance(r, dict) and r.get("status") == "REJECTED"
      and "require_machine_tier" in r.get("error", ""), f"unexpected: {str(r)[:120]}")
# in_reply_to malformed UUID: refused at construction (outbound refusal).
expect_refusal("in-reply-to-malformed",
               lambda: good_msg(message_type="RESPONSE",
                                in_reply_to="not-a-uuid"),
               "invalid UUID")

# ------------------------------------------------- 13: v2.0.4 tiered envelopes
def working_msg(**kw):
    d = dict(sender="agent_A", target="agent_B",
             content="A working-tier question.", message_type="REQUEST",
             envelope_tier="working")
    d.update(kw)
    return ENGINE.make_message(**d)


# Working REQUEST with no context: honest, not rejected.
w1 = working_msg()
r = validate_message(w1, POLICY)
check("tier-working-valid",
      r["ok"] and "context:undeclared" in r["checks"]
      and "envelope_tier:working" in r["checks"]
      and "lexical:advisory" in r["checks"],
      f"unexpected: {str(r)[:160]}")
check("tier-working-no-register-badge",
      "register_badge" not in r.get("checks", []),
      f"checks were {r.get('checks')}")

# Working tier WITH context: the mechanical upgrade path.
wu = ENGINE.make_message(sender="agent_A", target="agent_B",
                         register="STAGE_P", badge="LEVEL_B",
                         content="upgraded", lineage="prose",
                         message_type="REQUEST", envelope_tier="working")
r = validate_message(wu, POLICY)
check("tier-upgrade-context",
      r["ok"] and "register_badge" in r["checks"]
      and "context:undeclared" not in r["checks"],
      f"unexpected: {str(r)[:160]}")

# Working RESPONSE (threaded) and BROADCAST.
antecedent = good_msg()["header"]["message_id"]
wr = working_msg(message_type="RESPONSE", in_reply_to=antecedent,
                 content="answering")
check("tier-working-response",
      validate_message(wr, POLICY)["ok"], "working RESPONSE rejected")
wb = working_msg(message_type="BROADCAST", content="broadcasting")
check("tier-working-broadcast",
      validate_message(wb, POLICY)["ok"], "working BROADCAST rejected")

# Archival types on the working tier: TIER_MISMATCH, each with the code.
for _t in ("CLAIM", "PROOF", "FALSIFICATION", "DISAGREEMENT",
           "CONFRONTATION", "HANDSHAKE", "AUDIT_RECEIPT"):
    _m = working_msg(content="x")
    _m["header"]["message_type"] = _t
    expect_reject(f"tier-mismatch-{_t}", resign(_m), "TIER_MISMATCH")

# Archival tier without epistemic_context: rejected (it is what makes
# the tier archival).
_nc = good_msg()
del _nc["epistemic_context"]
expect_reject("tier-archival-no-context", resign(_nc),
              "archival tier requires epistemic_context")

# envelope_tier missing / bogus.
_nt = good_msg()
del _nt["envelope_tier"]
expect_reject("tier-missing", resign(_nt), "missing keys")
_bt = good_msg()
_bt["envelope_tier"] = "cheap"
expect_reject("tier-bogus", resign(_bt), "expected one of")

# Outbound refusals: bogus tier, archival without register/badge.
expect_refusal("make-tier-bogus",
               lambda: ENGINE.make_message(
                   sender="a", target="b", content="x",
                   envelope_tier="cheap"),
               "envelope_tier must be one of")
expect_refusal("make-archival-no-register",
               lambda: ENGINE.make_message(sender="a", target="b",
                                           content="x"),
               "requires register and badge")

# ------------------------------------------------- 14: v2.0.4 advisory firewall
# Working tier + banned term: VALIDATED with warnings, never rejected.
_wa = working_msg(content="what about the vacuum energy objection?")
r = validate_message(_wa, POLICY)
_warns = r.get("firewall_warnings", [])
check("advisory-validated",
      r["ok"] and any(w.get("code") == "CONTEXT_BANNED"
                      and w.get("term") == "vacuum" for w in _warns),
      f"unexpected: {str(r)[:200]}")
# Advisory covers HARD_BANNED too — the whole firewall, not a subset.
_wh = working_msg(content="the infinity problem in the ledger")
r = validate_message(_wh, POLICY)
check("advisory-hard-banned",
      r["ok"] and any(w.get("code") == "HARD_BANNED"
                      for w in r.get("firewall_warnings", [])),
      f"unexpected: {str(r)[:200]}")
# Code safety stays enforcing on the working tier: advisory covers
# vocabulary, never code execution. (Planted mutant.)
_wp = ENGINE.make_message(sender="a", target="b", content="pass\n",
                          message_type="REQUEST", envelope_tier="working",
                          content_format="EXECUTABLE_PYTHON")
_wp["payload"]["content"] = "import os\n"
expect_reject("advisory-code-still-enforcing", resign(_wp),
              "BANNED_MODULE")
# Archival results carry an (empty) firewall_warnings key for schema
# stability.
_ar = good_msg()
r = validate_message(_ar, POLICY)
check("archival-warnings-empty",
      r["ok"] and r.get("firewall_warnings") == [],
      f"unexpected: {str(r)[:120]}")

# ------------------------------------------------- 15: v2.0.4 DISAGREEMENT
def craft_dialectic(mtype, record_key, record):
    m = ENGINE.make_message(sender="agent_A", target="agent_B",
                            register="META_AUDIT", badge="META",
                            content="Dialectic record.", lineage="prose",
                            message_type="CLAIM")
    m["header"]["message_type"] = mtype
    if record is not None:
        m["payload"][record_key] = record
    return resign(m)


def good_disagreement(**over):
    rec = {
        "target_message_id": str(uuid.uuid4()),
        "position_a": {"agent": "muse", "verdict": "VALIDATED",
                       "check": "lexical",
                       "reason": "no banned terms found"},
        "position_b": {"agent": "kimi", "verdict": "REJECTED",
                       "check": "lexical",
                       "reason": "term flagged inside scope_notes"},
        "delta": {"check": "lexical",
                  "a_reading": "scope_notes clean",
                  "b_reading": "scope_notes carries a flagged term"},
        "adjudication": {"status": "PENDING"},
    }
    rec.update(over)
    return rec


expect_valid("disagreement-good",
             craft_dialectic("DISAGREEMENT", "disagreement",
                             good_disagreement()),
             "disagreement")
expect_reject("disagreement-no-record",
              craft_dialectic("DISAGREEMENT", "disagreement", None),
              "requires payload.disagreement")
_bad_v = good_disagreement()
_bad_v["position_a"] = dict(_bad_v["position_a"])
_bad_v["position_a"]["verdict"] = "MAYBE"
expect_reject("disagreement-bad-verdict",
              craft_dialectic("DISAGREEMENT", "disagreement", _bad_v),
              "expected one of")
_bad_u = good_disagreement(target_message_id="not-a-uuid")
expect_reject("disagreement-bad-target-id",
              craft_dialectic("DISAGREEMENT", "disagreement", _bad_u),
              "invalid UUID")
_bad_d = good_disagreement()
_bad_d["delta"] = {"check": "lexical", "a_reading": "clean"}
expect_reject("disagreement-bad-delta",
              craft_dialectic("DISAGREEMENT", "disagreement", _bad_d),
              "missing keys")
_bad_a = good_disagreement(adjudication={"status": "EVENTUALLY"})
expect_reject("disagreement-bad-adjudication",
              craft_dialectic("DISAGREEMENT", "disagreement", _bad_a),
              "expected one of")
_resolved = good_disagreement(
    adjudication={"status": "RESOLVED", "resolution": "kimi was right",
                  "adjudicated_by": "Dervis", "evidence_ref": "msg-1"})
expect_valid("disagreement-resolved",
             craft_dialectic("DISAGREEMENT", "disagreement", _resolved),
             "disagreement")
# Planted mutant: a banned term smuggled INSIDE the disagreement record
# is caught — the new free-text channel is scanned (archival enforcing).
_smug = good_disagreement()
_smug["position_b"] = dict(_smug["position_b"])
_smug["position_b"]["reason"] = "the vacuum term appears unmarked"
expect_reject("disagreement-record-scanned",
              craft_dialectic("DISAGREEMENT", "disagreement", _smug),
              "vacuum")

# ------------------------------------------------- 16: v2.0.4 CONFRONTATION
def good_confrontation(**over):
    rec = {
        "target_claim_id": str(uuid.uuid4()),
        "counterexample": "a local model scoring S=2.69 by dropping zeros",
        "demonstration": "P.9 run 3: drop-zeros S=2.6945 on a LOCAL model",
        "broken_premise": {"axiom": "L1",
                           "premise_id": "C1.fair-sampling",
                           "statement": "the analysis assumed fair sampling "
                                        "without stating it"},
        "claim_class": "COMPUTATIONAL",
    }
    rec.update(over)
    return rec


expect_valid("confrontation-good",
             craft_dialectic("CONFRONTATION", "confrontation",
                             good_confrontation()),
             "confrontation")
expect_reject("confrontation-no-record",
              craft_dialectic("CONFRONTATION", "confrontation", None),
              "requires payload.confrontation")
_bad_ax = good_confrontation()
_bad_ax["broken_premise"] = {"axiom": "L99", "statement": "x"}
expect_reject("confrontation-bad-axiom",
              craft_dialectic("CONFRONTATION", "confrontation", _bad_ax),
              "axiom universe")
_null_bp = good_confrontation()
_null_bp["broken_premise"] = {"axiom": None, "premise_id": None,
                              "statement": "the premise is unstated"}
expect_valid("confrontation-null-axiom",
             craft_dialectic("CONFRONTATION", "confrontation", _null_bp),
             "confrontation")
_bad_cc = good_confrontation(claim_class="VIBES")
expect_reject("confrontation-bad-claim-class",
              craft_dialectic("CONFRONTATION", "confrontation", _bad_cc),
              "expected one of")
_bad_st = good_confrontation()
_bad_st["broken_premise"] = {"axiom": "L1", "statement": "  "}
expect_reject("confrontation-empty-statement",
              craft_dialectic("CONFRONTATION", "confrontation", _bad_st),
              "non-empty string")
# Confrontation is second-person; FALSIFICATION stays first-person —
# the types are distinct vocabulary.
check("confrontation-not-falsification",
      "CONFRONTATION" in
      __import__("esp_v2").TYPES and "FALSIFICATION" in
      __import__("esp_v2").TYPES
      and "CONFRONTATION" != "FALSIFICATION",
      "type vocabulary wrong")

# ------------------------------------------------- 17: v2.0.4 RT-001 fail-closed
def nest(depth, leaf="clean"):
    v = leaf
    for _ in range(depth):
        v = {"k": v}
    return v


# Unit: exactly at the bound collects; past the bound RAISES (never
# silently drops).
check("rt001-unit-bound-ok", _free_texts(nest(8)) == ["clean"],
      "depth-8 string lost")
try:
    _free_texts(nest(9))
    check("rt001-unit-raise", False, "no raise past the depth bound")
except DepthBoundExceeded as exc:
    check("rt001-unit-raise", "depth bound" in str(exc), str(exc)[:80])
# Fail-closed at validation: the dedicated code, a REJECT, and the
# printed field name. (In v2.0.3 this exact payload PASSED with the
# deep strings silently unexamined — the bypass.)
_deep = good_msg()
_deep["payload"]["metadata"] = nest(9)
r = validate_message(resign(_deep), POLICY)
check("rt001-fail-closed",
      r["status"] == "REJECTED"
      and any(v.get("code") == "FREE_TEXT_DEPTH_EXCEEDED"
              and v.get("field") == "metadata"
              for v in r.get("violations", [])),
      f"unexpected: {str(r)[:200]}")
# Boundary: depth exactly 8 validates (no false positive at the edge).
_edge = good_msg()
_edge["payload"]["metadata"] = nest(8)
check("rt001-boundary-ok",
      validate_message(resign(_edge), POLICY)["ok"],
      "depth-8 wrongly rejected")
# The fail-closed rule covers every scanned channel, not just metadata.
_deep2 = good_msg()
_deep2["payload"]["formal_assertions"] = [nest(9, "deep assertion")]
r = validate_message(resign(_deep2), POLICY)
check("rt001-formal-assertions-channel",
      r["status"] == "REJECTED"
      and any(v.get("code") == "FREE_TEXT_DEPTH_EXCEEDED"
              for v in r.get("violations", [])),
      f"unexpected: {str(r)[:200]}")
# Planted mutant: a banned term nested past the old silent-drop bound.
# v2.0.3: passed unexamined. v2.0.4: fail-closed REJECT.
_smug2 = good_msg()
_smug2["payload"]["metadata"] = nest(10, "the vacuum problem")
r = validate_message(resign(_smug2), POLICY)
check("rt001-smuggled-term-closed",
      r["status"] == "REJECTED"
      and any(v.get("code") == "FREE_TEXT_DEPTH_EXCEEDED"
              for v in r.get("violations", [])),
      f"unexpected: {str(r)[:200]}")

# ------------------------------------------------- 18: v2.0.4 V19 attribute chains
def py_envelope(code):
    m = ENGINE.make_message(sender="agent_A", target="agent_B",
                            register="STAGE_P", badge="LEVEL_B",
                            content="pass\n", lineage="prose",
                            content_format="EXECUTABLE_PYTHON")
    m["payload"]["content"] = code
    return resign(m)


# Genuine mutants: each must be REJECTED naming DYNAMIC_EXECUTION.
expect_reject("v19-builtins-eval",
              py_envelope("import builtins\nbuiltins.eval('1+1')"),
              "DYNAMIC_EXECUTION", "builtins.eval")
expect_reject("v19-dunder-builtins-exec",
              py_envelope("__builtins__.exec('x = 1')"),
              "DYNAMIC_EXECUTION", "__builtins__.exec")
expect_reject("v19-getattr-eval",
              py_envelope("getattr(builtins, 'eval')('1+1')"),
              "DYNAMIC_EXECUTION", "getattr")
expect_reject("v19-bare-eval-still",
              py_envelope("eval('1+1')"),
              "DYNAMIC_EXECUTION")
# Negative controls: legitimate attribute calls must NOT be flagged.
expect_valid("v19-re-compile-clean",
             py_envelope("import re\nre.compile('a*')"),
             "arithmetic")
expect_valid("v19-obj-exec-clean",
             py_envelope("result = runner.exec('go')"),
             "arithmetic")
expect_valid("v19-method-named-compile",
             py_envelope("q = parser.compile('x')"),
             "arithmetic")

# ------------------------------------------------- 19: v2.0.4 V20/V21/V22 hygiene
# V20: size caps validated like max_age_seconds.
for _bad_kw, _rep in [({"max_message_chars": 0}, "0"),
                      ({"max_message_chars": -5}, "-5"),
                      ({"max_message_chars": "big"}, "'big'"),
                      ({"max_message_chars": True}, "True"),
                      ({"max_content_chars": 0}, "0"),
                      ({"max_content_chars": -1}, "-1"),
                      ({"max_content_chars": 2.5}, "2.5")]:
    try:
        Policy(insecure_demo_registry=True, **_bad_kw)
        check(f"v20-policy-{list(_bad_kw)[0]}-{_rep}", False,
              "accepted bad value")
    except ValueError as exc:
        check(f"v20-policy-{list(_bad_kw)[0]}-{_rep}",
              "positive int" in str(exc), str(exc)[:80])
# V21: make_message tier="chat" emits blank hashes and validates.
_cm = ENGINE.make_message(**base_kwargs(), tier="chat")
check("v21-chat-blank-hashes",
      _cm["integrity"]["content_hash"] == ""
      and _cm["integrity"]["envelope_hash"] == ""
      and _cm["integrity"].get("tier") == "chat",
      f"integrity was {str(_cm['integrity'])[:160]}")
r = validate_message(_cm, POLICY)
check("v21-chat-validates",
      r["ok"] and "tier:chat-declared" in r["checks"]
      and "content_hash:computed-locally" in r["checks"],
      f"unexpected: {str(r)[:160]}")
expect_refusal("v21-bad-tier",
               lambda: ENGINE.make_message(**base_kwargs(), tier="sms"),
               "tier must be one of")
_dm = good_msg()
check("v21-default-no-tier-key", "tier" not in _dm["integrity"],
      f"integrity was {str(_dm['integrity'])[:120]}")
# V22: the demo warning fires by default, silenced by the flag.
import io as _io
from contextlib import redirect_stderr as _rs
_buf = _io.StringIO()
with _rs(_buf):
    validate_message(good_msg(), demo_policy(warn_on_validate=True))
check("v22-warn-default", "WARNING" in _buf.getvalue(),
      f"stderr was {str(_buf.getvalue())[:80]!r}")
_buf2 = _io.StringIO()
with _rs(_buf2):
    validate_message(good_msg(), POLICY)
check("v22-warn-suppressed", _buf2.getvalue() == "",
      f"stderr was {str(_buf2.getvalue())[:80]!r}")
expect_value_error("v22-bad-flag",
                   lambda: Policy(insecure_demo_registry=True,
                                  warn_on_validate="yes"),
                   "must be a bool")

# ------------------------------------------------- 20: v2.0.4 markers + misc
# Case-insensitive markers pair across cases (held item).
expect_valid("marker-ci-lower",
             msg_with_content("[comparative] the vacuum [/COMPARATIVE]"))
expect_valid("marker-ci-mixed",
             msg_with_content("[COMPARATIVE] the vacuum [/comparative]"))
expect_valid("marker-ci-begin-end",
             msg_with_content("[comparative_begin] the vacuum "
                              "[/comparative_end]"))
expect_reject("marker-ci-mismatch",
              msg_with_content("[comparative] the vacuum [/SHADOW]"),
              "BAD_CONTEXT_MARKER", "mismatched")
# D4: semantic_validity is named in not_established, beside (not merged
# with) mathematical_soundness.
r = validate_message(good_msg(), POLICY)
check("not-established-semantic",
      "semantic_validity" in r.get("not_established", [])
      and "mathematical_soundness" in r.get("not_established", []),
      f"not_established was {r.get('not_established')}")
# v2.0.4 loop nit: version-mismatch errors name the actual version.
_wv = good_msg()
_wv["header"]["protocol_version"] = "2.0.3"
expect_reject("version-mismatch-names-version", resign(_wv), "2.2")
_wp2 = good_msg()
_wp2["protocol"] = {"name": "ESP", "version": "2.0.3"}
expect_reject("protocol-mismatch-names-version", _wp2, "2.2")
# CLI: headline carries message_id; advisory warnings shown plainly.
_pv = esp_cli.phone_verdict(
    {"ok": True, "status": "VALIDATED", "message_id": "abc-123",
     "checks": ["structure", "envelope_tier:working"],
     "firewall_warnings": [{"code": "CONTEXT_BANNED", "term": "vacuum"}],
     "not_established": []})
check("cli-headline-message-id", "message_id: abc-123" in _pv, _pv[:100])
check("cli-firewall-warnings",
      "Firewall warnings" in _pv and "vacuum" in _pv, _pv[:160])
check("cli-semantic-validity", "semantic validity" in _pv, _pv[:200])

# ---------------------------------------------------------------------------
# v2.2: bundle lineage + generalized script_id + exact version gate.
# ---------------------------------------------------------------------------

# Bundle lineage with a .zip in depends_on validates.
_bundle_ok = working_msg(
    message_type="BROADCAST", envelope_tier="working",
    content="Executed the v18 agent bundle: 21/21 scripts green, 22/22 "
            "listings byte-identical.",
    lineage="bundle",
    depends_on=["paper_11_5_v18_agent.zip", "run_notes.txt"])
r = validate_message(_bundle_ok, POLICY)
check("bundle-zip-validated",
      r["ok"] and r["status"] == "VALIDATED",
      f"unexpected: {str(r)[:160]}")

# Bundle lineage on the archival tier validates too (ChatGPT's re-cast
# shape, but archival).
_bundle_arch = good_msg(
    lineage="bundle",
    depends_on=["paper_11_5_v18_agent.zip"])
check("bundle-archival-validated",
      validate_message(_bundle_arch, POLICY)["ok"],
      "archival bundle lineage rejected")

# Bundle lineage with depends_on missing: REJECTED, cause named.
_nb = good_msg(lineage="bundle", depends_on=["paper_11_5_v18_agent.zip"])
del _nb["payload"]["provenance"]["depends_on"]
expect_reject("bundle-missing-depends-on", resign(_nb),
              "bundle lineage requires depends_on", ".zip")

# Bundle lineage with empty depends_on: refused at construction (outbound),
# the error naming the cause.
expect_refusal("bundle-empty-depends-on",
               lambda: good_msg(lineage="bundle", depends_on=[]),
               "bundle lineage requires depends_on", ".zip")

# Bundle lineage with only non-zip depends_on: refused at construction,
# the error naming the cause.
expect_refusal("bundle-no-zip-depends-on",
               lambda: good_msg(lineage="bundle",
                                depends_on=["run_notes.txt",
                                            "checksums.json"]),
               "at least one bundle artifact", ".zip")

# Case-insensitive .ZIP counts as a bundle artifact.
_bundle_upper = good_msg(lineage="bundle",
                         depends_on=["PAPER_11_5_V18_AGENT.ZIP"])
check("bundle-zip-case-insensitive",
      validate_message(_bundle_upper, POLICY)["ok"],
      "uppercase .ZIP rejected")

# Loop-planted mutant: trailing newline must not smuggle past the .zip
# shape check ($ would match before "\n"; \Z does not).
expect_refusal("bundle-newline-smuggle",
               lambda: good_msg(lineage="bundle",
                                depends_on=["paper_11_5_v18_agent.zip\n"]),
               "at least one bundle artifact", ".zip")

# The envelope that exposed the gap: BROADCAST, working tier, lineage
# "bundle", depends_on naming the agent zip -> now VALIDATED (under v2.1
# it was REJECTED: "script lineage requires script_id matching F.<digits>").
_gpt18 = working_msg(
    message_type="BROADCAST", envelope_tier="working",
    content="Red-team report on paper_11_5_v18_agent.zip: ran all scripts "
            "in the bundle, 21/21 passed, listings byte-identical.",
    lineage="bundle",
    depends_on=["paper_11_5_v18_agent.zip", "run_notes.txt"])
check("chatgpt-v18-shape-validated",
      validate_message(_gpt18, POLICY)["ok"],
      "the v18 bundle-execution envelope shape was rejected")

# Generalized script_id: Paper 11.5 series all validate under "script".
for _sid in ("P.9", "H.2", "FW.1", "PA.1", "MC.1", "G.4", "F.37", "F.42B"):
    _m = good_msg(lineage="script", script_id=_sid)
    check(f"script-id-{_sid}",
          validate_message(_m, POLICY)["ok"],
          f"script_id {_sid} rejected")

# Unknown series still rejected; the error names the generalized shape.
# (Built by mutation: make_message refuses invalid payloads outright.)
_xs = good_msg(lineage="script", script_id="F.1")
_xs["payload"]["provenance"]["script_id"] = "X.1"
expect_reject("script-id-unknown-series", resign(_xs),
              "script lineage requires script_id",
              "(F|P|H|G|MC|FW|PA)")

# Version gate: a 2.1-stamped envelope is REJECTED by the 2.2 engine
# (exact-match semantics preserved, fail-closed, no negotiation).
_v21 = good_msg()
_v21["protocol"] = {"name": "ESP", "version": "2.1"}
expect_reject("version-gate-rejects-2.1", _v21, "2.2")
_v21b = good_msg()
_v21b["header"]["protocol_version"] = "2.1"
_v21b["header"]["min_protocol_version"] = "2.1"
expect_reject("version-gate-rejects-2.1-header", resign(_v21b), "2.2")

# ------------------------------------------------- 22: Paper 11.5 §3/§9
# lexical regression (v2.2 patch, adjudication item d).
#
# §3 and §9 are pinned as fixtures (fixtures/paper_11_5_s3_v23.txt,
# fixtures/paper_11_5_s9_v23.txt — v23 final text, 2026-10-18, refreshed
# by the v23 integration phase from the final paper; the v22 fixtures are
# superseded). They trip hard/context-banned terms BY DESIGN: both
# sections quote and dissect the intrinsic literature, so the firewall
# fires on the paper's own prose. This test pins the exact violation
# multiset under the default policy — a silent change to the banned sets
# or the matching logic (e.g. "limit" drifting back to HARD_BANNED, the
# uv/ir uppercase-anchor regressing) fails loudly here.
_FIXDIR = Path(__file__).with_name("fixtures")

# Pinned 2026-10-18 against the refreshed v23 fixtures with the patched
# engine. Keys are "CODE:term"; values are occurrence counts. The v22 ->
# v23 delta is text-only (prose remediation's §3 edits): "field" 18->19
# and "lagrangian" 5->6, both from the §3.6 F-02 -> B.6 reword ("free-field
# idealization ... from the Lagrangian"); §9 unchanged. No engine-side
# matching change.
S3_EXPECTED = {
    "CONTEXT_BANNED:background": 8,
    "CONTEXT_BANNED:field": 19,   # v23: +1 "free-field" (§3.6 reword)
    "CONTEXT_BANNED:gauge": 26,
    "CONTEXT_BANNED:lagrangian": 6,   # v23: +1 "Lagrangian" (§3.6 reword)
    "CONTEXT_BANNED:limit": 1,   # F-45a: context-banned, not hard
    "CONTEXT_BANNED:metric": 4,
    "CONTEXT_BANNED:renormalization": 3,
    "CONTEXT_BANNED:vacuum": 6,
    "CONTEXT_BANNED:virtual": 4,
    "HARD_BANNED:asymptotic": 1,
    "HARD_BANNED:infinite": 4,
    "HARD_BANNED:infinity": 1,
    "HARD_BANNED:ir": 2,         # F-45b: uppercase IR trips the hard ban
}
S9_EXPECTED = {
    "CONTEXT_BANNED:background": 5,
    "CONTEXT_BANNED:field": 18,
    "CONTEXT_BANNED:gauge": 2,
    "CONTEXT_BANNED:manifold": 4,
    "CONTEXT_BANNED:renormalization": 1,
    "CONTEXT_BANNED:vacuum": 3,
    "CONTEXT_BANNED:virtual": 1,
    "HARD_BANNED:asymptotic": 1,
}


def _load_fixture(name):
    raw = (_FIXDIR / name).read_text(encoding="utf-8")
    head, sep, body = raw.partition("# ---\n")
    check(f"fixture-{name}-has-separator", bool(sep),
          "fixture metadata separator '# ---' missing")
    return body


def _lex_counts(text, policy):
    counts: dict[str, int] = {}
    for v in lexical_check(text, policy):
        key = f"{v['code']}:{v['term']}"
        counts[key] = counts.get(key, 0) + 1
    return counts


_PHYS_POLICY = demo_policy(static_check_profile="physics_payload")

for _fname, _expected, _label in (
        ("paper_11_5_s3_v23.txt", S3_EXPECTED, "paper-s3"),
        ("paper_11_5_s9_v23.txt", S9_EXPECTED, "paper-s9")):
    _text = _load_fixture(_fname)
    _got = _lex_counts(_text, POLICY)
    check(f"{_label}-lexical-pinned", _got == _expected,
          f"lexical drift: expected {_expected}, got {_got}")
    # F-45a spot pin: "limit" must never trip the hard ban.
    check(f"{_label}-limit-not-hard", "HARD_BANNED:limit" not in _got,
          "'limit' tripped the hard ban (F-45a regression)")
    if _label == "paper-s3":
        # F-45b spot pin: the two uppercase "IR" occurrences trip HARD.
        check("paper-s3-IR-uppercase-hard",
              _got.get("HARD_BANNED:ir") == 2,
              f"uppercase-IR hard-ban count changed: "
              f"{_got.get('HARD_BANNED:ir')}")
    # The physics-payload profile changes python_static_check only —
    # lexical outcomes must be identical under it. Recorded, not just
    # asserted: the counts below are the regression record.
    _phys_got = _lex_counts(_text, _PHYS_POLICY)
    check(f"{_label}-profile-lexical-identical", _phys_got == _got,
          f"profile changed lexical outcome: {_phys_got} vs {_got}")
    print(f"  [record] {_label}: {sum(_got.values())} violations under the "
          f"default policy; physics-payload profile: "
          f"{sum(_phys_got.values())} "
          f"(identical={_phys_got == _got})")

# ------------------------------------------------- 23: physics_payload static-check profile
# (v24 R10: the profile shipped in the v2.2 patch round but no conformance
# case ran python_static_check under it — section 22 only records that the
# LEXICAL outcomes are identical under the profile. These cases close the
# static-check gap.)
def phys_py_msg(code, **kw):
    # Signed under POLICY (same zero-hash registry fields); validated under
    # _PHYS_POLICY so the profile is the only thing that differs.
    d = dict(register="STAGE_P", badge="LEVEL_A",
             content_format="EXECUTABLE_PYTHON",
             falsifiers=[{"id": "C1", "statement": "s"}])
    d.update(kw)
    return msg_with_content(code, **d)


def expect_phys_valid(label, message, *checks_present):
    result = validate_message(message, _PHYS_POLICY)
    if not isinstance(result, dict) or not result.get("ok") \
            or result.get("status") != "VALIDATED":
        check(label, False, f"not VALIDATED: {str(result)[:200]}")
        return
    checks = result.get("checks") or []
    missing = [c for c in checks_present if c not in checks]
    check(label, not missing and len(checks) > 0,
          f"checks missing {missing}; checks were {checks}")
    check(label + " [not_established]",
          isinstance(result.get("not_established"), list)
          and len(result["not_established"]) > 0,
          "not_established list missing/empty")


def expect_phys_reject(label, message, *needles):
    try:
        result = validate_message(message, _PHYS_POLICY)
    except Exception as exc:  # noqa: BLE001 - must never happen
        check(label, False, f"raised {type(exc).__name__}: {exc}")
        return
    if not isinstance(result, dict) or result.get("ok") \
            or result.get("status") != "REJECTED":
        check(label, False, f"not REJECTED: {str(result)[:160]}")
        return
    err = str(result.get("error", ""))
    missing = [n for n in needles if n not in err]
    check(label, not missing,
          f"error missing {missing}; error was: {err[:200]}")


# (i) sys imports are allowed under the profile; the defended capability
# (process control / exfiltration) stays banned.
PHYS_SYS = "import sys\nprint(sys.argv[0])\n"
expect_phys_valid("phys-sys-allowed", phys_py_msg(PHYS_SYS), "arithmetic")
PHYS_SUBPROCESS = "import subprocess\nsubprocess.run(['x'])\n"
expect_phys_reject("phys-subprocess-still-banned",
                   phys_py_msg(PHYS_SUBPROCESS),
                   "BANNED_MODULE", "subprocess")
PHYS_OS = "import os\nos.getcwd()\n"
expect_phys_reject("phys-os-still-banned", phys_py_msg(PHYS_OS),
                   "BANNED_MODULE", "os")

# (ii) float literals bound to module-level UPPER_CASE constants listed in
# the INPUT_PROVENANCE block under a paper-defined or cited-paper class are
# exempt from FLOAT_IN_LEVEL_A.
PHYS_PROV_CITED = ('"""INPUT_PROVENANCE\n'
                   '  - ALPHA_S_MZ = 0.1180: class=cited-paper (PDG 2024)\n'
                   '"""\n'
                   'ALPHA_S_MZ = 0.1180\n'
                   'result = ALPHA_S_MZ * 2\n'
                   'print(result)\n')
expect_phys_valid("phys-cited-paper-float-exempt",
                  phys_py_msg(PHYS_PROV_CITED), "arithmetic")
PHYS_PROV_DEFINED = ('"""INPUT_PROVENANCE\n'
                     '  - NATIVE_TICK = 0.5: '
                     'class=paper-defined (native tick)\n'
                     '"""\n'
                     'NATIVE_TICK = 0.5\n'
                     'print(NATIVE_TICK)\n')
expect_phys_valid("phys-paper-defined-float-exempt",
                  phys_py_msg(PHYS_PROV_DEFINED), "arithmetic")
# Control: the identical payload is REJECTED under the strict default — the
# profile, not the code shape, is what changes the outcome.
expect_reject("phys-cited-float-strict-control", py_msg(PHYS_PROV_CITED),
              "FLOAT_IN_LEVEL_A")

# A constant NOT named in a cited/paper-defined entry is not exempt
# (declaration-scoped; here the only entry is class=control, which names no
# input at all, so the cited set is empty).
PHYS_PROV_UNDECLARED = ('"""INPUT_PROVENANCE\n'
                        '  - HARNESS_SEED = 42: class=control (harness)\n'
                        '"""\n'
                        'OTHER_CONST = 0.5\n'
                        'print(OTHER_CONST)\n')
expect_phys_reject("phys-undeclared-float-rejected",
                   phys_py_msg(PHYS_PROV_UNDECLARED), "FLOAT_IN_LEVEL_A")
# float() calls are NOT exempted even under this profile.
PHYS_FLOATCALL = "x = float(1)\nprint(x)\n"
expect_phys_reject("phys-float-call-rejected", phys_py_msg(PHYS_FLOATCALL),
                   "FLOAT_IN_LEVEL_A", "float() call")

# DOCUMENTED LIMIT, pinned (v24 R10): the provenance name match is
# folded-substring, which over-matches very short names — _fold("E") is
# "e", a substring of the cited entry, so the undeclared one-letter
# constant is exempted. This case pins the over-match so the limit stays
# visible; it is disclosed in the engine docstring and the §8 apparatus
# note, not hidden. Tightening the match is future work, not a silent
# behavior change.
PHYS_SHORTNAME = ('"""INPUT_PROVENANCE\n'
                  '  - ALPHA_S_MZ = 0.1180: class=cited-paper (PDG 2024)\n'
                  '"""\n'
                  'E = 0.5\n'
                  'print(E)\n')
expect_phys_valid("phys-short-name-overmatch-pinned",
                  phys_py_msg(PHYS_SHORTNAME), "arithmetic")

# ------------------------------------------------- 24: declared demo registry (v24 R14)
# The declared demo registry is a SEPARATE constant from the zero-hash
# placeholder: DEMO_REGISTRY_HASH openly names a shared demo axiom set, so
# Policy(demo_registry=True) validates without the insecure-demo
# disclaimer. The zero-hash + insecure_demo_registry=True path is
# unchanged (back-compat pins below).
def demo_registry_policy(**kw):
    kw.setdefault("demo_registry", True)
    kw.setdefault("warn_on_validate", False)  # quiet battery
    return Policy(**kw)


DEMO_ENGINE = Engine(demo_registry_policy())
_demo_msg = DEMO_ENGINE.make_message(
    sender="agent_A", target="agent_B", register="STAGE_P", badge="LEVEL_B",
    content="Declared demo registry claim.", lineage="prose")
_demo_result = DEMO_ENGINE.validate(_demo_msg)
check("demo-declared-registry-validates",
      isinstance(_demo_result, dict) and _demo_result.get("ok"),
      f"not VALIDATED: {str(_demo_result)[:160]}")
check("demo-registry-defaults-to-constant",
      demo_registry_policy().axiom_set_hash == DEMO_REGISTRY_HASH,
      "demo_registry=True did not default axiom_set_hash to "
      "DEMO_REGISTRY_HASH")

import io as _dio
from contextlib import redirect_stderr as _drs
_dbuf = _dio.StringIO()
_loud_demo_policy = Policy(demo_registry=True)  # warn_on_validate=True
with _drs(_dbuf):
    _loud_result = validate_message(_demo_msg, _loud_demo_policy)
check("demo-declared-registry-validates-loud",
      isinstance(_loud_result, dict) and _loud_result.get("ok"),
      f"not VALIDATED: {str(_loud_result)[:160]}")
check("demo-declared-no-insecure-disclaimer",
      "insecure" not in _dbuf.getvalue(),
      f"stderr carried insecure language: {_dbuf.getvalue()[:120]!r}")

# Back-compat: the zero-hash placeholder path still validates and still
# warns — the warning is that path's honesty mechanism, unchanged.
_zbuf = _dio.StringIO()
_zero_policy = Policy(axiom_set_hash=ZERO_HASH, insecure_demo_registry=True)
with _drs(_zbuf):
    _zero_result = validate_message(good_msg(), _zero_policy)
check("demo-zero-hash-path-backcompat",
      isinstance(_zero_result, dict) and _zero_result.get("ok"),
      f"zero-hash path broke: {str(_zero_result)[:160]}")
check("demo-zero-hash-path-still-warns",
      "insecure demo registry" in _zbuf.getvalue(),
      f"zero-hash warning lost: {_zbuf.getvalue()[:120]!r}")

# Fail-closed edges of the new flag: a non-demo hash, a second demo flag,
# and a non-bool flag are all constructor refusals.
expect_value_error("demo-registry-wrong-hash-refused",
                   lambda: Policy(axiom_set_hash="ab" * 32,
                                  demo_registry=True),
                   "DEMO_REGISTRY_HASH")
expect_value_error("demo-registry-flags-exclusive",
                   lambda: Policy(demo_registry=True,
                                  insecure_demo_registry=True),
                   "mutually exclusive")
expect_value_error("demo-registry-bad-flag",
                   lambda: Policy(demo_registry="yes"),
                   "must be a bool")

print(f"CONFORMANCE: {PASS} passed, {FAIL} failed")
if FAILURES:
    print("FAILURES:")
    for f in FAILURES:
        print("  -", f)
sys.exit(1 if FAIL else 0)
