ESP v2.2 — READ ME FIRST
============================

WHAT THIS IS
An agent-to-agent communication protocol: a JSON envelope shape plus a
Python validator that checks it. Two AIs talk by exchanging envelopes;
the validator judges whether each envelope is well-formed, honestly
badged, and lexically disciplined. It does NOT judge whether claims are
true — see "what it does not do" below.

START HERE (pick ONE path)

  PATH A — chat only (no code):
    1. Open ESP_v2.2_START_HERE.txt. Paste the whole thing into the AI
       chat. Use the working-tier template for questions, the archival
       template for claims that must survive.
    2. Read esp_v2.2_COMPENDIUM.txt for the full kit (chat kit,
       how-it-works briefing, design brief). No code in there — prose only.

  PATH B — you run Python:
    1. python3 esp_v2.py selftest            (engine sanity)
    2. python3 esp_v2_conformance.py         (235-case battery, must exit 0)
    3. python3 esp_v2_demo.py                (end-to-end story)
    4. Paste a chat AI's envelope into esp_cli.py:
       python3 esp_cli.py validate envelope.json

  PATH C — give an AI agent everything:
    Hand it the four .py files + ESP_v2.2_START_HERE.txt.
    The .py files are the binding artifact: if prose and code disagree,
    the code wins.

THE FILES
  esp_v2.py                 the validator (stdlib only). This is the judge.
  esp_cli.py                command-line presenter (phone/full/json).
  esp_v2_conformance.py     235-case battery. Run after any change.
  esp_v2_demo.py            end-to-end demo.
  ESP_v2.2_START_HERE.txt paste-ready initiation block (working +
                            archival templates).
  esp_v2_chat_kit.txt       the chat kit.
  esp_how_it_works_briefing.txt  plain-language briefing.
  esp_v2_design_brief.md    design brief incl. the v2.2 spec (Part 7).
  esp_v2.2_COMPENDIUM.txt code-free compendium (5 parts).
  esp_v2.2_WHATS_NEW.txt  what's new since v2.1 (for Appendix J).
  esp_v2.0.4_design__deepseek_accommodation.md  the v2.1 design doc.

WHAT'S NEW IN v2.2 (one line each)
  - New provenance lineage "bundle": reports outcomes of executing a
    bundle of scripts; depends_on must name at least one .zip artifact
    (fail-closed). Closes the gap that rejected ChatGPT's v18
    bundle-execution envelope.
  - script_id generalized to (F|P|H|G|MC|FW|PA).<digits> — covers Paper
    11.5's P./H./G./MC./FW./PA. series, not just Paper 11's F. series.
  - Version gate unchanged: exact 2.2 match, fail-closed, no negotiation.
    2.1 envelopes are REJECTED.
  - Correction on the record: v2.1's note said "no engine behavior
    change"; the version gate rejecting 2.0.4 envelopes WAS a behavior
    change. This note states v2.2's behavior changes up front.

WHAT IT DOES NOT DO (read before trusting it)
  A VALIDATED badge attests: the envelope is well-formed, self-consistent,
  and passed the named checks. It does NOT attest: claim truth, sender
  identity, transport authenticity, mathematical soundness, semantic
  validity, or proof-script correspondence. The firewall is a floor, not a
  ceiling — PASS means "no structural defect found," never "content
  approved." Chat AIs cannot compute SHA-256: they leave hashes blank and
  the validator computes them ("computed-locally"). There is no tamper
  evidence across a human clipboard, and the protocol does not pretend
  otherwise. A "bundle" VALIDATED attests the envelope is well-formed and
  names a .zip — it does NOT attest the named bundle exists; verify that
  yourself.

REGISTRY NOTE
  The demo uses a placeholder (zero-hash) registry: pass
  insecure_demo_registry=True explicitly. For real shared work, agree on
  the registry hash out-of-band first. Envelopes validated against the
  demo registry attest envelope integrity only — not production.
