================================================================
ESP v2.2 — PACKAGE README
Epistemic Swarm Protocol (ESP) v2.2 — an agent-to-agent
communication protocol by Dervis Kadunic.
Standalone package for the publication of Paper 11.5,
"The Intrinsic Illusion." (ESP is a separate package from the
paper's own verification suite.)
================================================================

WHAT IT IS
----------
ESP is a JSON envelope format plus a Python validator. Two AI
agents exchange messages as envelopes; the engine checks each
envelope for well-formedness, honest badging (provenance,
capability, hashes), and lexical discipline. It does NOT judge
whether a claim inside an envelope is true — it judges whether
the message is honestly and correctly presented. Envelopes come
in two completeness tiers (working / archival) under one schema.

FILES
-----
Engine and battery (canonical, from the Paper 11.5 v26 tree):
  esp_v2.py               — the validator engine (267-case build;
                            sha256 6cebc541ae12ef4be166731569c39618af31b71c744ed9d128dcd1837eb0d517)
  esp_v2_conformance.py   — the conformance battery (267 cases)
  esp_cli.py              — command-line validator for envelope files
  fixtures/               — sample paper excerpts used by the battery

User-facing documents:
  ESP_v2.2_START_HERE.txt — the initiation block: paste the whole
                            file into an AI chat to start an
                            ESP v2.2 exchange
  READ_ME_FIRST_v22.txt   — orientation: what ESP does and does
                            not do, and the reading paths
  esp_v2.2_COMPENDIUM.txt — code-free master compendium: the whole
                            kit as plain text, for chat interfaces
                            that accept neither zips nor .py files
  esp_v2.2_WHATS_NEW.txt  — what changed since v2.1 (incl. the
                            fifth provenance lineage, "bundle")
  esp_v2_chat_kit.txt     — how to talk agent-to-agent in a chat
                            window (preamble + envelope shape)
  v2.2_model_packs/       — per-model starter packs: the canonical
                            initiation block plus a short delivery
                            card per model (ChatGPT, DeepSeek,
                            Grok, Kimi, Qwen; a Claude draft is
                            included, marked DRAFT)

HOW TO RUN
----------
Python 3, standard library only. From this folder:

  Conformance battery (expect 267/267, exit code 0):
      python3 esp_v2_conformance.py

  Engine selftest:
      python3 esp_v2.py selftest

  Validate envelope files with the CLI:
      python3 esp_cli.py validate <file> [file ...]
      (see: python3 esp_cli.py --help)

HONESTY RULES (the point of the protocol)
-----------------------------------------
- Chat tier: hash fields may be left blank ("computed-locally")
  — a blank hash is honest. A FORGED hex hash (typed, invented,
  not actually computed) is REJECTED.
- Disclosed inability PASSES; fabricated capability FAILS. Saying
  "I cannot compute hashes in this chat" is compliant; claiming
  a capability you do not have is not.
- The machine tier verifies hashes strictly. Machine-tier
  checking is corruption detection — it is not tamper-evidence
  against a competent attacker, and ESP does not claim it is.
- ESP does NOT authenticate senders. A valid envelope proves the
  envelope is well-formed and honestly badged, not who sent it.
- Exact-version gate: this engine accepts v2.2 envelopes only.
  Envelopes stamped with earlier versions (2.1, 2.0.x) are
  rejected by design.

================================================================
