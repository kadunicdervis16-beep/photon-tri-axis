#!/usr/bin/env python3
"""
ESP v2.2 — unified agent-to-agent protocol engine.

Lineage: Grok v4 (EpistemicSwarmEngine) -> Gemini/Qwen ESP v1.0 ->
ChatGPT improvements -> this unification (Valkyrie, 2026-10-09,
per Dervis: executable, high-class, simple, stageable into Paper 11.5).

Standard library only. Single file.

Design decisions (binding, from esp_v2_design_brief.md):
  1. Checks run by default; the badge names what ran (checks list on every
     VALIDATED; lexical policy ON by default).
  2. Externalized canon: banned terms, context markers, axiom universe
     injected via constructor; sane defaults shipped.
  3. Block context markers with malformed-marker ERRORS (unclosed, nested,
     mismatched -> violations, never silent fallthrough).
  4. Outbound refusal: constructors raise on invalid payloads.
  5. Two-tier hash honesty (v2.0.1): chat tier leaves hashes blank and the
     validator computes them (recorded "computed-locally"); machine tier
     carries sender-computed hashes verified strictly; forged hex is
     REJECTED. v2.0.2: explicit integrity.tier signal ("chat"|"machine",
     enforced when declared, inferred otherwise); the validator deep-copies
     before validating so a chat-tier pass can never manufacture
     machine-tier credentials on revalidation.
     Honesty scope: VALIDATED attests well-formedness + self-consistency
     at validation time + the named checks that ran. It is NOT
     tamper-evidence against a competent attacker (anyone with Python can
     recompute hashes) — the machine tier is corruption-detection plus
     lazy-forgery detection. sender_identity and transport_authenticity
     are never established (see not_established).
  6. Audit receipts kept; inbound audit history is stripped, never trusted
     (v2.0.2).
  7. not_established list on every validation result (validation proves
     envelope integrity only, never claim truth).
  8. Registry honesty: zero-hash registry requires explicit
     insecure_demo_registry=True, else the constructor refuses.
  9. Capability-based module policy (subprocess/socket/os/sys banned;
     math and numerics ALLOWED). LEVEL_A float discipline with a
     hardened display exemption (AST parent-chain check: the float must
     reach the print/format call with no intervening call; v2.2 patch
     F-48 closed the nested-call bypass the old "non-gameable" claim
     overstated).
 10. STAGE_N requires LEVEL_A + deterministic/seeded; LEVEL_A requires
     >=1 falsification condition; LEVEL_A cannot depend on B/C bridges;
     registry skew bounded (default +-3).
 11. Chunk protocol: transfer_id, per-chunk + whole-text hashes,
     gap/duplication/mixed-transfer detection.
 12. migrate_v1_to_v2 helper (field renames); v4 payloads documented,
     not auto-migrated.
 13. Tiered envelopes (v2.0.4, D1): envelope_tier "working"|"archival".
     Working tier (REQUEST/RESPONSE/BROADCAST) makes epistemic_context
     optional (records "context:undeclared") and runs the lexical firewall
     in ADVISORY mode — violations become firewall_warnings, never
     rejections. Archival tier stays enforcing; CLAIM/PROOF/FALSIFICATION/
     DISAGREEMENT/CONFRONTATION on the working tier are REJECTED with
     TIER_MISMATCH. One schema, two completeness levels.
 14. DISAGREEMENT (v2.0.4, D2): archival message type recording two
     agents' divergent verdicts on one envelope, the precise structured
     delta, and a later human adjudication. CONFRONTATION (v2.0.4, D3):
     archival second-person challenge ("your claim fails because..."),
     distinct from FALSIFICATION (first-person), with a structured
     broken_premise {axiom, premise_id, statement}.
 15. RT-001 fail-closed (v2.0.4): _free_texts no longer silently drops
     strings past its depth bound — it raises DepthBoundExceeded, which
     the validator converts to a FREE_TEXT_DEPTH_EXCEEDED violation
     (REJECTED). The lexical bypass is closed.
 16. python_static_check hardened (v2.0.4, V19): attribute-chain dynamic
     calls (builtins.eval(...)) and getattr(x, "eval")(...) are now
     DYNAMIC_EXECUTION violations. Documented heuristic limits remain:
     aliased imports (from builtins import eval as e) are out of scope.
 17. Policy hygiene (v2.0.4, V20/V22): max_message_chars/max_content_chars
     validated as positive ints; warn_on_validate flag suppresses the
     demo warning for batch validation. make_message gained a tier
     parameter (V21): tier="chat" emits blank-hash chat-tier envelopes.
 18. Markers are case-insensitive (v2.0.4, held item): [comparative]
     pairs with [/COMPARATIVE]. not_established gains "semantic_validity":
     mathematical_soundness = the derivation steps, as written, are
     valid; semantic_validity = the claim, as written, refers to
     something real and asserts something true of it. The validator
     establishes neither — the lexical firewall is a floor, not a
     ceiling (D4/D6).
 19. Bundle lineage (v2.2): lineage "bundle" — "the claim reports outcomes
     of executing a bundle of scripts; the bundle manifest named in
     depends_on is the grounding." Validator requires depends_on to name
     at least one bundle artifact (a string ending in .zip,
     case-insensitive) — fail-closed otherwise, error names the cause.
     Existence of the named bundle is NOT machine-checked: depends_on is
     a claim about grounding, verified by the recipient, exactly like
     script_id (SCRIPT_RE checks shape, not existence). A fake .zip name
     passes the shape check the same way a fake "F.999" passes — the
     envelope is well-formed; the grounding claim is the recipient's to
     verify. This fixes the v18 gap: the most honest execution report in
     the program was REJECTED because no lineage covered it. script_id
     generalized (v2.2): ^(F|P|H|G|MC|FW|PA)\.\d+[A-Z]?$ — the engine must
     cover the paper it ships with (Paper 11.5's P./H./G./MC./FW./PA.
     series, not just Paper 11's F. series). Version gate unchanged:
     exact 2.2 match required, fail-closed, no negotiation (negotiation
     still needs Dervis's word).
20. Patch round (v2.2 engine, 2026-10-17, Dervis's "correct everything
    now" — VERSION stays 2.2, no envelope-schema change):
    F-45 lexical defaults: (a) "limit" moved from DEFAULT_HARD_BANNED to
    DEFAULT_CONTEXT_BANNED — it rejected ordinary prose, and as a
    context-banned term [COMPARATIVE]/marker blocks can exempt it for
    legitimate comparative use; (b) "uv"/"ir" trip the hard ban only as
    whole-word UPPERCASE ("UV"/"IR" are regime jargon; lowercase in
    ordinary prose does not trip); (c) correction, stated plainly: some
    v2.2 package doc text claimed context-marker blocks exempt
    hard-banned terms — FALSE. Hard-banned terms are exempt NOWHERE;
    marker blocks exempt CONTEXT_BANNED terms only. The engine's rule
    (this docstring + lexical_check) is authoritative; the stale package
    doc text is superseded and must not be rebuilt from it.
    F-47: human_review lineage now requires reviewer + review_date +
    attestation_ref (reviewer identity, date, attestation reference) —
    the one lineage asserting human sign-off. Any of the three missing
    or empty REJECTS (fail closed). The validator checks presence, never
    attestation truth — content is the recipient's check, same as
    script_id existence.
    F-48: float_exempt() hardened against the nested-call bypass —
    the float's AST parent chain must reach the builtin print()/format()
    call WITHOUT passing through another call, so print("result",
    compute(1.5))  # (display only) no longer exempts the computational
    1.5. The old "non-gameable" claim overstated the check; the
    docstrings now describe what the code actually enforces.
    F-52 dead-code removal: STATUSES and module-level _BLOCK_RE deleted
    (defined, never used); context_spans error strings now render the
    actual opener token — a mismatched close of a bare [NAME] opener no
    longer misreports it as "[NAME_BEGIN]".
    Adjudication item (d) — named "physics-payload" static-check profile
    (STATIC_CHECK_PROFILES; Policy(static_check_profile=...)): "strict"
    keeps the exact prior behavior and stays the default (the right
    choice for untrusted code); "physics_payload" is for declared physics
    payloads carrying INPUT_PROVENANCE — (i) `sys` imports allowed (the
    defended capability is process control/exfiltration via
    subprocess/socket/os-level access; sys.exit/sys.argv are neither;
    subprocess/socket/os stay banned); (ii) float literals bound to
    module-level UPPER_CASE constants listed in the script's
    INPUT_PROVENANCE block under the paper-defined or cited-paper class
    are exempt from FLOAT_IN_LEVEL_A (declaration-scoped: the validator
    checks the constant is named in a cited/paper-defined entry, never
    that the citation is genuine — same honesty boundary as script_id).
    Item (d) also adds Paper 11.5 §3/§9 to the conformance corpus as a
    permanent lexical regression test (pinned fixture; asserts the
    F-45-era expected violations under the default policy so silent
    banned-set drift fails loudly; records the physics-payload-profile
    outcome). Fixture pinned from the v22 text 2026-10-17 — §3 is under
    F-12 edit by another worker, so the integration phase must refresh
    the fixture from the final paper text and re-run.
21. Declared demo registry (v24): DEMO_REGISTRY_HASH — a fixed, public,
    reproducible hash naming the shared demo axiom set, separate from the
    zero/placeholder hash. Policy(demo_registry=True) validates against it
    WITHOUT the insecure-demo disclaimer, because the demo use is declared
    in the constructor, not smuggled. The zero-hash +
    insecure_demo_registry=True path is unchanged (back-compat); the two
    flags are mutually exclusive, and demo_registry=True refuses any hash
    other than DEMO_REGISTRY_HASH. The disclaimer stays on the zero-hash
    path: a null registry that printed no warning could be mistaken for a
    real one; the declared demo registry is openly named, so the flag is
    the declaration.

Validation does NOT establish that a scientific claim is true.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

VERSION = "2.2"
CHUNK_PROTOCOL = "ESP-CHUNK-2"

# ---------------------------------------------------------------------------
# Vocabularies
# ---------------------------------------------------------------------------

REGISTERS = {"STAGE_N", "STAGE_P", "STAGE_C", "META_AUDIT"}
BADGES = {"LEVEL_A", "LEVEL_B", "LEVEL_C", "META"}
FORMATS = {
    "NATIVE_STATEMENT", "PROOF_AST", "EXECUTABLE_PYTHON",
    "CLAIM_REGISTRY_JSON", "TEX_EQUATION", "FALSIFICATION_CONDITION",
    "PLAIN_TEXT", "JSON_DATA", "AUDIT_REPORT",
}
CLAIMS = {
    "EXISTENCE", "UNIVERSAL", "RELATIONAL", "STRUCTURAL",
    "COMPUTATIONAL", "DEFINITIONAL", "OBSERVATIONAL",
}
LINEAGES = {"script", "inherited", "prose", "human_review", "bundle"}
MODES = {"DETERMINISTIC", "SEEDED", "STOCHASTIC"}
TYPES = {
    "REQUEST", "RESPONSE", "BROADCAST", "HANDSHAKE",
    "AUDIT_RECEIPT", "CLAIM", "PROOF", "FALSIFICATION",
    "DISAGREEMENT", "CONFRONTATION",  # v2.0.4: D2, D3 (archival tier)
}
BRIDGES = {"A", "B", "C"}
TIERS = {"chat", "machine"}
# v2.0.4 D1: envelope completeness tiers. Working = cheap conversational
# layer (epistemic_context optional, firewall advisory). Archival = full
# context, firewall enforcing. One schema, two completeness levels.
ENVELOPE_TIERS = {"working", "archival"}
# The ONLY message types permitted on the working tier. Everything else
# (CLAIM, PROOF, FALSIFICATION, DISAGREEMENT, CONFRONTATION, HANDSHAKE,
# AUDIT_RECEIPT) requires archival; a working-tier archival type is
# REJECTED with TIER_MISMATCH.
WORKING_TYPES = {"REQUEST", "RESPONSE", "BROADCAST"}
DISAGREEMENT_VERDICTS = {"VALIDATED", "REJECTED"}
ADJUDICATION_STATUSES = {"PENDING", "RESOLVED"}
RECEIPT_RESULTS = {"VALIDATED", "REJECTED", "DEFERRED"}

MARKER_NAMES = ("COMPARATIVE", "HISTORICAL", "SHADOW", "RECONSTRUCTION")

# v2.2 patch (F-45): "limit" moved from HARD to CONTEXT_BANNED. As a hard
# ban it rejected ordinary prose ("limit the scope"); as a context-banned
# term it is still barred from native prose but [COMPARATIVE]/marker
# blocks can exempt it for legitimate comparative use. (STATUSES removed
# in the same patch: defined, never used — see F-52.)
DEFAULT_HARD_BANNED = frozenset({
    "infinity", "infinite", "infinitesimal", "derivative",
    "integral", "asymptotic", "path integral", "uv", "ir",
})
DEFAULT_CONTEXT_BANNED = frozenset({
    "field", "gauge", "vacuum", "manifold", "metric", "curvature",
    "geodesic", "observer", "background", "lagrangian", "quantized",
    "propagator", "virtual", "renormalization", "limit",
})
DEFAULT_AXIOM_UNIVERSE = frozenset({
    "L1", "L2", "L3", "L4", "PTR", "BUDGET", "DSC", "S3",
    "SINGLE_REGIME", "NULL_BOUNDARY", "NULL_CONTINUUM",
})
# Capability-based: exfiltration / process control / dynamic execution.
# math and numerics are ALLOWED (physics payloads need them).
DEFAULT_BANNED_MODULES = frozenset({"subprocess", "socket", "os", "sys"})
DEFAULT_BANNED_CALLS = frozenset({"eval", "exec", "compile", "__import__"})

# Named static-check profiles for EXECUTABLE_PYTHON payloads
# (v2.2 patch, adjudication item d).
#
# "strict" (default): the full capability ban exactly as configured on
# the Policy; no provenance exemptions. This is the right choice for
# untrusted or adversarial code, and it is what every existing caller
# gets unless they opt in.
#
# "physics_payload": for code that IS the physics payload — a declared
# verification script carrying an INPUT_PROVENANCE block (e.g. the
# paper's own scripts). Two relaxations, both documented and bounded:
#   (i) `sys` imports are allowed. Rationale: the defended capability is
#       process control / exfiltration via subprocess/socket/os-level
#       access; sys.exit/sys.argv are neither. subprocess, socket and os
#       stay banned under this profile.
#   (ii) float literals bound to module-level UPPER_CASE constants listed
#       in the script's INPUT_PROVENANCE block under the paper-defined or
#       cited-paper class are exempt from FLOAT_IN_LEVEL_A (e.g.
#       ALPHA_S_MZ = 0.1180 with "alpha_s(M_Z) = 0.1180: class=cited-paper"
#       in the block). The check is declaration-scoped: the validator
#       verifies the constant is NAMED in a cited/paper-defined provenance
#       entry; whether the citation is genuine is the recipient's check —
#       the same honesty boundary as script_id (shape checked, existence
#       not). float() calls are NOT exempted even under this profile.
#
# When each applies: "strict" is the default — keep it for anything you
# do not already trust. "physics_payload" is for code the recipient
# already treats as a declared physics payload; it must never be
# selected to make hostile code pass.
STATIC_CHECK_PROFILES = {"strict", "physics_payload"}

HASH_RE = re.compile(r"^[0-9a-f]{64}$")
UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-"
    r"[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$"
)
# v2.2: generalized. F. = Paper 11 scripts; P./H./G./MC./FW./PA. = the
# Paper 11.5 series the engine ships with (the engine must cover the paper
# it ships with). Shape check only — the validator cannot know whether a
# named script exists; that is the recipient's job, same as depends_on.
SCRIPT_RE = re.compile(r"^(F|P|H|G|MC|FW|PA)\.\d+[A-Z]?$")
# v2.2: a bundle artifact is a string naming a bundle file. A bundle
# artifact = a string ending in .zip (case-insensitive, \Z-anchored so a
# trailing newline cannot smuggle past the shape check). Shape check only:
# depends_on is a CLAIM about grounding, verified by the recipient, same
# as script_id (see design decision 19). A fake .zip name passes the shape
# check exactly like a fake script_id passes SCRIPT_RE — the envelope is
# well-formed, the grounding claim is the recipient's to verify.
BUNDLE_RE = re.compile(r"\.zip\Z", re.IGNORECASE)
COND_RE = re.compile(r"^C\d+[A-Z]?$")
ZERO_HASH = "0" * 64
# Declared demo registry (v24, design decision 21): a fixed, public,
# reproducible hash naming the shared demo axiom set — a SEPARATE constant
# from the zero/placeholder hash. The value is the SHA-256 of the fixed
# seed string "ESP v2.2 declared demo registry"; anyone can recompute it.
# Policy(demo_registry=True) validates against it without the insecure-demo
# disclaimer (the demo use is declared in the constructor, not smuggled).
DEMO_REGISTRY_HASH = \
    "661d95cfa230277ec4acd44e76b4210c44c527e2678d26edec297557853351b7"

NOT_ESTABLISHED = [
    "mathematical_soundness",
    "semantic_validity",  # v2.0.4 D4: the claim, as written, refers to
    # something real and asserts something true of it (truth, not just
    # validity). mathematical_soundness = the derivation steps, as
    # written, are valid. The validator establishes neither.
    "proof_script_correspondence",
    "claim_truth",
    "sender_identity",
    "transport_authenticity",
]


class ProtocolError(ValueError):
    """Raised for malformed chunk sets and programmer errors (not messages)."""


class DepthBoundExceeded(ProtocolError):
    """v2.0.4 RT-001: _free_texts hit its depth bound.

    Fail-closed: a free-text tree nested deeper than the bound is
    never silently truncated. On the archival tier this surfaces as a
    FREE_TEXT_DEPTH_EXCEEDED violation (REJECTED); on the working tier
    the whole firewall is advisory (D1), so it surfaces as a
    firewall_warnings entry instead — loud, not silent, but not a
    rejection. (The v2.0.3 behavior — silently dropping strings past
    depth 8 — was a lexical bypass: banned terms nested deep enough
    passed unexamined.)"""


# ---------------------------------------------------------------------------
# Hashing / canonical form
# ---------------------------------------------------------------------------

def canonical(value) -> str:
    """Stable JSON representation used for hashing.

    Raises ValueError/TypeError on non-serializable input (NaN, sets,
    bytes, ...). Callers that must never crash convert these to REJECTED.
    """
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    )


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def object_digest(value) -> str:
    return digest(canonical(value))


def now() -> str:
    return datetime.now(timezone.utc).isoformat(
        timespec="seconds").replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# Policy (externalized canon lives here)
# ---------------------------------------------------------------------------

class Policy:
    """Local validation policy. The canon — banned terms, markers, axiom
    universe, module policy — is injected here, never hardcoded in checks.

    Registry honesty: a zero/placeholder axiom_set_hash is refused unless
    insecure_demo_registry=True is passed explicitly. Demo validations print
    a loud warning on every call unless warn_on_validate=False (V22, for
    batch use).

    Declared demo mode (v24, design decision 21): Policy(demo_registry=True)
    validates against the declared demo registry hash DEMO_REGISTRY_HASH
    (which the constructor defaults axiom_set_hash to when unset) and prints
    NO disclaimer — the demo use is declared in the constructor, so there is
    nothing to warn about. The two demo paths are separate and mutually
    exclusive: (1) zero-hash placeholder + insecure_demo_registry=True —
    back-compat; prints the WARNING above on every validate; (2)
    DEMO_REGISTRY_HASH + demo_registry=True — declared demo mode; no
    disclaimer. demo_registry=True refuses any other hash. (A bare
    Policy(axiom_set_hash=DEMO_REGISTRY_HASH) without the flag is treated
    like any other non-zero registry reference — the hash openly names a
    demo registry; the flag is the declaration of demo USE.)

    static_check_profile (v2.2 patch, item d): selects the named
    python_static_check profile — "strict" (default, full capability ban,
    no provenance exemptions) or "physics_payload" (sys imports allowed;
    cited-paper float constants exempt; see STATIC_CHECK_PROFILES).
    """

    def __init__(
        self,
        *,
        registry_version: int = 0,
        axiom_set_hash: str | None = None,
        insecure_demo_registry: bool = False,
        demo_registry: bool = False,  # v24 decision 21: declared demo mode
        accepted_registry_skew: int = 3,
        max_message_chars: int = 2_500_000,
        max_content_chars: int = 2_000_000,
        enforce_lexical_policy: bool = True,  # ON by default (fixes Q1)
        max_age_seconds: int | None = None,  # v2.0.2: optional replay bound
        require_machine_tier: bool = False,  # v2.0.2: refuse chat-tier hashes
        warn_on_validate: bool = True,  # v2.0.4 V22: demo warning on every
        # validate_message call; set False for batch validation (the CLI
        # does this) to suppress the noise.
        hard_banned=None,
        context_banned=None,
        marker_names=None,
        axiom_universe=None,
        banned_modules=None,
        banned_calls=None,
        static_check_profile: str = "strict",  # v2.2 patch, item d
    ):
        if not isinstance(demo_registry, bool):
            raise ValueError("demo_registry must be a bool")
        if not isinstance(insecure_demo_registry, bool):
            raise ValueError("insecure_demo_registry must be a bool")
        if demo_registry and insecure_demo_registry:
            raise ValueError(
                "demo_registry and insecure_demo_registry are mutually "
                "exclusive: the declared demo registry and the zero-hash "
                "placeholder are separate paths"
            )
        if axiom_set_hash is None:
            # Declared demo mode defaults to the declared demo registry;
            # the zero-hash placeholder stays the default otherwise.
            axiom_set_hash = DEMO_REGISTRY_HASH if demo_registry else ZERO_HASH
        if not isinstance(axiom_set_hash, str) \
                or not HASH_RE.fullmatch(axiom_set_hash):
            raise ValueError("axiom_set_hash must be a lowercase SHA-256 hex")
        if demo_registry and axiom_set_hash != DEMO_REGISTRY_HASH:
            raise ValueError(
                "demo_registry=True requires "
                "axiom_set_hash=DEMO_REGISTRY_HASH (the declared demo "
                "registry); pass the constant explicitly or leave "
                "axiom_set_hash unset"
            )
        if axiom_set_hash == ZERO_HASH and not insecure_demo_registry:
            raise ValueError(
                "zero/placeholder axiom_set_hash refused: pass "
                "insecure_demo_registry=True explicitly for demo use, or "
                "configure a real shared registry"
            )
        if not isinstance(registry_version, int) \
                or isinstance(registry_version, bool) or registry_version < 0:
            raise ValueError("registry_version must be a non-negative int")
        if not isinstance(accepted_registry_skew, int) \
                or isinstance(accepted_registry_skew, bool) \
                or accepted_registry_skew < 0:
            raise ValueError("accepted_registry_skew must be a non-negative int")

        self.registry_version = registry_version
        self.axiom_set_hash = axiom_set_hash
        self.insecure_demo_registry = insecure_demo_registry
        self.demo_registry = demo_registry  # v24 decision 21
        self.accepted_registry_skew = accepted_registry_skew
        # v2.0.4 V20: size caps are validated like max_age_seconds —
        # negative or non-int caps previously passed through silently.
        for _name, _val in (("max_message_chars", max_message_chars),
                            ("max_content_chars", max_content_chars)):
            if not isinstance(_val, int) or isinstance(_val, bool) \
                    or _val <= 0:
                raise ValueError(f"{_name} must be a positive int")
        self.max_message_chars = max_message_chars
        self.max_content_chars = max_content_chars
        self.enforce_lexical_policy = enforce_lexical_policy
        if max_age_seconds is not None:
            if not isinstance(max_age_seconds, int) \
                    or isinstance(max_age_seconds, bool) \
                    or max_age_seconds <= 0:
                raise ValueError(
                    "max_age_seconds must be a positive int or None")
        if not isinstance(require_machine_tier, bool):
            raise ValueError("require_machine_tier must be a bool")
        if not isinstance(warn_on_validate, bool):
            raise ValueError("warn_on_validate must be a bool")
        self.max_age_seconds = max_age_seconds
        self.require_machine_tier = require_machine_tier
        self.warn_on_validate = warn_on_validate

        def _collection(name, value):
            # Fail fast on the classic footgun: a bare string where a
            # collection of strings was meant ("ABC" -> ('A','B','C')).
            if isinstance(value, str):
                raise ValueError(
                    f"{name}: expected a collection of strings, got a "
                    f"bare string")
            return value

        self.hard_banned = frozenset(
            _collection("hard_banned", hard_banned)
            if hard_banned is not None else DEFAULT_HARD_BANNED)
        self.context_banned = frozenset(
            _collection("context_banned", context_banned)
            if context_banned is not None else DEFAULT_CONTEXT_BANNED)
        self.marker_names = tuple(
            _collection("marker_names", marker_names)
            if marker_names is not None else MARKER_NAMES)
        self.axiom_universe = frozenset(
            _collection("axiom_universe", axiom_universe)
            if axiom_universe is not None else DEFAULT_AXIOM_UNIVERSE)
        self.banned_modules = frozenset(
            _collection("banned_modules", banned_modules)
            if banned_modules is not None else DEFAULT_BANNED_MODULES)
        self.banned_calls = frozenset(
            _collection("banned_calls", banned_calls)
            if banned_calls is not None else DEFAULT_BANNED_CALLS)
        # v2.2 patch, item d: named static-check profile. Fail fast on an
        # unknown name — a misspelled profile must never silently fall
        # back to "strict" (or vice versa).
        if static_check_profile not in STATIC_CHECK_PROFILES:
            raise ValueError(
                "static_check_profile must be one of "
                f"{sorted(STATIC_CHECK_PROFILES)}")
        self.static_check_profile = static_check_profile

    def warn_if_demo(self):
        # v24 decision 21: the declared demo_registry path prints no
        # disclaimer — the demo use is declared in the constructor. Only
        # the zero-hash placeholder path warns.
        if self.insecure_demo_registry:
            print("WARNING: insecure demo registry in use — VALIDATED badges "
                  "from this policy attest to envelope integrity only, "
                  "against a NULL registry. Not for production.",
                  file=sys.stderr)


# ---------------------------------------------------------------------------
# Field validators (structural layer)
# ---------------------------------------------------------------------------

def _req_object(value, path: str) -> dict:
    if not isinstance(value, dict):
        raise ProtocolError(f"{path}: expected object")
    return value


def _req_keys(value: dict, required: set, allowed: set, path: str):
    missing = required - set(value)
    extra = set(value) - allowed
    if missing:
        raise ProtocolError(f"{path}: missing keys {sorted(missing)}")
    if extra:
        raise ProtocolError(f"{path}: unknown keys {sorted(extra)}")


def _req_enum(value, choices: set, path: str):
    if not isinstance(value, str) or value not in choices:
        raise ProtocolError(f"{path}: expected one of {sorted(choices)}")


def _req_nonempty(value, path: str):
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{path}: expected non-empty string")


def _req_sha(value, path: str):
    if not isinstance(value, str) or not HASH_RE.fullmatch(value):
        raise ProtocolError(f"{path}: expected lowercase SHA-256")


def _req_uuid(value, path: str, nullable: bool = False):
    if nullable and value is None:
        return
    if not isinstance(value, str) or not UUID_RE.fullmatch(value):
        raise ProtocolError(f"{path}: invalid UUID")


def _req_maxlen(value, path: str, limit: int):
    if isinstance(value, str) and len(value) > limit:
        raise ProtocolError(
            f"{path}: exceeds {limit} characters ({len(value)})")


def _req_timestamp(value, path: str):
    if not isinstance(value, str):
        raise ProtocolError(f"{path}: expected ISO-8601 timestamp")
    try:
        parsed = datetime.fromisoformat(
            value[:-1] + "+00:00" if value.endswith("Z") else value)
    except ValueError as exc:
        raise ProtocolError(f"{path}: invalid ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{path}: timestamp must include timezone")
    return parsed


def _req_int(value, path: str, minimum=None):
    if isinstance(value, bool) or not isinstance(value, int) \
            or (minimum is not None and value < minimum):
        raise ProtocolError(f"{path}: invalid integer")


def _req_unique_strs(value, path: str):
    if not isinstance(value, list) \
            or any(not isinstance(i, str) or not i for i in value) \
            or len(value) != len(set(value)):
        raise ProtocolError(f"{path}: must be unique non-empty strings")


# ---------------------------------------------------------------------------
# Lexical firewall (context markers + banned terms)
# ---------------------------------------------------------------------------


def _block_pattern(marker_names) -> re.Pattern:
    names = "|".join(re.escape(n) for n in marker_names)
    # Openers: [NAME_BEGIN], bare [NAME]. Closers: [NAME_END], [/NAME].
    # v2.0.4 (held item): matching is case-insensitive — [comparative]
    # pairs with [/COMPARATIVE]. context_spans() normalizes to upper case
    # for pairing.
    return re.compile(rf"\[(/)?({names})(?:_(BEGIN|END))?\]", re.IGNORECASE)


def context_spans(text: str, marker_names):
    """Find paired contextual blocks.

    Grammar (v2.0.3): markers come in pairs. Openers are [NAME_BEGIN] or
    bare [NAME]; closers are [NAME_END] or [/NAME], interoperable (a
    [/NAME] may close a [NAME_BEGIN] block and vice versa). A bare [NAME]
    opens a block that must be closed — there is no whole-line special
    case anymore.

    Returns (spans, errors). Errors cover: nested open, unmatched close,
    mismatched close, unclosed open. Malformed markers are ERRORS, never
    silent fallthrough (fixes Grok-G1; v2.0.3 closes the kit-advertised
    [NAME]...[/NAME] gap the engine previously ignored). v2.0.4: marker
    names match case-insensitively and are normalized to upper case for
    pairing.
    """
    spans: list[tuple[int, int]] = []
    errors: list[str] = []
    pattern = _block_pattern(marker_names)
    # v2.2 patch (F-52): active carries the actual opener TOKEN, not a
    # re-rendered "[{name}_BEGIN]" — error strings must name the marker as
    # written, because a bare [NAME] opener is legal and rendering it as
    # "[NAME_BEGIN]" misdescribes the input.
    active: tuple[str, int, str] | None = None

    for match in pattern.finditer(text):
        slash, name, edge = match.group(1), match.group(2).upper(), \
            match.group(3)
        # v2.0.4: the pattern is case-insensitive, so normalize the edge
        # too — "[comparative_begin]" must open, not baffle the parser.
        edge = edge.upper() if edge else None
        token = match.group(0)
        is_opener = edge == "BEGIN" or (not slash and edge is None)
        if is_opener:
            if active is not None:
                errors.append(
                    f"nested context block: {token} inside {active[2]}")
            else:
                active = (name, match.start(), token)
        else:  # closer: [NAME_END] or [/NAME]
            if active is None:
                errors.append(f"unmatched {token} (no open block)")
            elif active[0] != name:
                errors.append(
                    f"mismatched context block: {token} closes {active[2]}")
                active = None
            else:
                spans.append((active[1], match.end()))
                active = None

    if active is not None:
        errors.append(f"unclosed {active[2]} block (no matching close)")

    return spans, errors


def _free_texts(value, _depth=0) -> list[str]:
    """Recursively collect string leaves from a JSON-shaped value.

    Used by the lexical firewall to reach every free-text channel
    (falsification statements, metadata, formal_assertions,
    dependencies). Depth-capped so hostile nesting cannot blow the
    stack; non-string leaves are ignored.

    v2.0.4 RT-001 FAIL-CLOSED: strings past the depth bound are NEVER
    silently dropped. Exceeding the bound raises DepthBoundExceeded,
    which the validator converts to a FREE_TEXT_DEPTH_EXCEEDED finding
    — a REJECTED violation on the archival tier, a firewall_warnings
    entry on the working tier (advisory firewall, D1). A silent drop
    was a lexical bypass — banned terms nested deep enough passed
    unexamined.
    """
    out: list[str] = []
    if value is None:
        return out
    if _depth > 8:
        raise DepthBoundExceeded(
            f"free-text nesting exceeds depth bound (>{8} levels); "
            "refusing to silently truncate — restructure the payload")
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for v in value.values():
            out.extend(_free_texts(v, _depth + 1))
    elif isinstance(value, (list, tuple)):
        for v in value:
            out.extend(_free_texts(v, _depth + 1))
    return out


def lexical_check(text: str, policy: Policy) -> list[dict]:
    """Return violation dicts for banned-term use.

    HARD_BANNED: never permitted — not in native prose, and not inside
    context-marker blocks either. Marker blocks exempt CONTEXT_BANNED
    terms only; there is no marker, tier, or envelope form that exempts a
    hard-banned term. (v2.2 patch F-45c: some v2.2 package doc text
    implied marker blocks exempt hard-banned terms; that text is wrong —
    this docstring is the rule, and the code below enforces it.)
    Malformed markers are violations too.

    Matching is case-insensitive via re.IGNORECASE on the ORIGINAL text so
    match positions share the coordinate space of the marker spans computed
    by context_spans(). (Matching on text.casefold() instead would shift
    positions for length-changing folds like ß->ss and break the span
    check — a firewall bypass.)
    v2.2 patch F-45b: the terms "uv"/"ir" are jargon only in UPPERCASE
    (UV cutoff, IR regime); lowercase "uv"/"ir" in ordinary prose does
    not trip the hard ban. The pattern is therefore case-sensitive and
    uppercase-only for exactly these two terms.
    """
    violations: list[dict] = []
    spans, errors = context_spans(text, policy.marker_names)
    for error in errors:
        violations.append({"code": "BAD_CONTEXT_MARKER", "detail": error})

    def inside_allowed_span(position: int) -> bool:
        return any(start <= position < end for start, end in spans)

    def banned_pattern(term: str) -> re.Pattern:
        # v2.2 patch F-45b: uppercase-anchor uv/ir — only the uppercase
        # whole-word forms are regime jargon; lowercase in ordinary prose
        # must not trip the hard ban. Every other term keeps the
        # case-insensitive whole-word match.
        if term in ("uv", "ir"):
            return re.compile(r"(?<!\w)" + re.escape(term.upper())
                              + r"(?!\w)")
        return re.compile(r"(?<!\w)" + re.escape(term) + r"(?!\w)",
                          re.IGNORECASE)

    for term in sorted(policy.hard_banned):
        for match in banned_pattern(term).finditer(text):
            violations.append({
                "code": "HARD_BANNED",
                "term": term,
                "span": text[max(0, match.start() - 30):match.end() + 30],
            })
    for term in sorted(policy.context_banned):
        for match in banned_pattern(term).finditer(text):
            if not inside_allowed_span(match.start()):
                violations.append({
                    "code": "CONTEXT_BANNED",
                    "term": term,
                    "span": text[max(0, match.start() - 30):match.end() + 30],
                })
    return violations


# ---------------------------------------------------------------------------
# Python static check (EXECUTABLE_PYTHON payloads)
# ---------------------------------------------------------------------------

# v2.2 patch, item d(ii): classes whose INPUT_PROVENANCE entries name
# cited/defined inputs (the other two classes — control,
# declared-assumption — describe scaffolding/assumptions, not inputs).
_PROVENANCE_INPUT_CLASSES = frozenset({"paper-defined", "cited-paper"})
_PROVENANCE_CLASS_RE = re.compile(
    r"(?:class\s*=\s*|:\s*)"
    r"(paper-defined|cited-paper|control|declared-assumption|"
    r"arbitrary-representative)\b")


def _fold(s: str) -> str:
    """Alphanumeric fold for provenance name matching: lowercase, drop
    everything else, so ALPHA_S_MZ matches a block entry naming
    "alpha_s(M_Z)"."""
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _provenance_cited_inputs(code: str) -> set[str]:
    """Folded texts of INPUT_PROVENANCE entries classed paper-defined or
    cited-paper (v2.2 patch, item d(ii)).

    Heuristic, fail-closed: if the block cannot be found or parsed the
    result is empty and no provenance exemption applies.

    Recognized shape (the shape the paper's scripts use): a line
    containing the token INPUT_PROVENANCE, followed by indented bullet
    entries ("  - <text>: class=<cls> ..." or the colon form
    "  - <text>: <cls> ..."), entries possibly spanning continuation
    lines. Documented limits: only this docstring-style indented block
    is parsed (a col-0 `#`-comment block is not recognized); the first
    class tag found in an entry wins; name matching is folded-substring,
    which can over-match very short names. The exemption this feeds is
    declaration-scoped (see STATIC_CHECK_PROFILES): the validator checks
    the constant is NAMED in a cited/paper-defined entry, never that the
    citation is genuine.
    """
    lines = code.splitlines()
    start = next((i for i, ln in enumerate(lines)
                  if "INPUT_PROVENANCE" in ln), None)
    if start is None:
        return set()
    block: list[str] = []
    for ln in lines[start + 1:]:
        if not ln.strip() or ln[0] in " \t" \
                or ln.lstrip().startswith("#"):
            block.append(ln)
        else:
            break
    entries: list[str] = []
    for ln in block:
        s = ln.strip()
        if s.startswith("- ") or s == "-":
            entries.append(s[1:].strip())
        elif entries and s:
            entries[-1] += " " + s
        # Blank lines and any text before the first bullet are ignored.
    cited: set[str] = set()
    for entry in entries:
        m = _PROVENANCE_CLASS_RE.search(entry)
        if m and m.group(1) in _PROVENANCE_INPUT_CLASSES:
            cited.add(_fold(entry))
    return cited


def python_static_check(code: str, badge: str, policy: Policy) -> list[dict]:
    """Heuristic static checks only; this is NOT a code sandbox.

    - banned modules / banned dynamic calls come from Policy
      (capability-based; math and numerics are allowed).
    - Banned dynamic calls are caught in three shapes: bare calls
      (eval(...)), attribute chains rooted at builtins
      (builtins.eval(...)), and getattr with a string literal
      (getattr(x, "eval")(...)). v2.0.4 V19: the attribute-chain case
      closed a real bypass (builtins.eval walked straight through the
      old ast.Name-only check).
    - DOCUMENTED HEURISTIC LIMITS (not caught, by design of a static
      heuristic): aliased imports (from builtins import eval as e),
      rebinding (ev = builtins.eval), and computed attribute access.
      The check proves "no obvious dynamic execution in the source as
      written" — it is not a sandbox and never claims to be.
    - LEVEL_A float discipline: float literals and float() calls are
      violations unless the float is a direct argument of a builtin
      print()/format() call AND its source line carries the "(display
      only)" marker. The exemption is hardened against the nesting
      bypass: the float's parent chain must reach the print/format call
      without passing through any other call — print("r", compute(1.5))
      does NOT exempt the 1.5. (v2.2 patch F-48; fixes the gameable walk
      the old "non-gameable" claim overstated.)
    - Named profiles (v2.2 patch, item d; see STATIC_CHECK_PROFILES).
      "strict" (default): everything above, exactly. "physics_payload":
      (i) `sys` imports are allowed — the defended capability is process
      control/exfiltration via subprocess/socket/os-level access;
      sys.exit/sys.argv are neither; (ii) float LITERALS (not float()
      calls) bound to module-level UPPER_CASE constants listed in the
      script's INPUT_PROVENANCE block under the paper-defined or
      cited-paper class are exempt from FLOAT_IN_LEVEL_A. The profile is
      selected via Policy(static_check_profile=...); "strict" is the
      default and the right choice for untrusted code.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return [{"code": "PYTHON_SYNTAX", "detail": str(exc)}]
    except (ValueError, MemoryError, RecursionError) as exc:
        return [{"code": "PYTHON_SYNTAX", "detail": f"unparseable: {exc}"}]

    violations: list[dict] = []
    lines = code.splitlines()
    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent

    # v2.2 patch, item d: named static-check profile from the Policy.
    profile = policy.static_check_profile
    if profile == "physics_payload":
        # (i) `sys` is allowed under this profile: the defended capability
        # is process control/exfiltration via subprocess/socket/os-level
        # access; sys.exit/sys.argv are neither. subprocess, socket and
        # os stay banned.
        banned_modules = policy.banned_modules - {"sys"}
    else:
        banned_modules = policy.banned_modules
    # (ii) cited/paper-defined float inputs, parsed once per check.
    cited_inputs: set[str] = set()
    if profile == "physics_payload" and badge == "LEVEL_A":
        cited_inputs = _provenance_cited_inputs(code)

    # Names rebound at module top level. A shadowed `print`/`format`
    # (e.g. `print = lambda v: v`) voids the display exemption: the
    # exemption trusts the builtin, not the name.
    bound_top: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            bound_top.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    bound_top.add(target.id)
                elif isinstance(target, (ast.Tuple, ast.List)):
                    for elt in target.elts:
                        if isinstance(elt, ast.Name):
                            bound_top.add(elt.id)
        elif isinstance(node, ast.AnnAssign) \
                and isinstance(node.target, ast.Name):
            bound_top.add(node.target.id)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                bound_top.add((alias.asname or alias.name).split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                bound_top.add(alias.asname or alias.name)

    def provenance_input_exempt(node: ast.AST) -> bool:
        """physics_payload only: a float literal is exempt when it sits
        inside the value assigned to a module-level UPPER_CASE constant
        listed in the script's INPUT_PROVENANCE block under the
        paper-defined or cited-paper class (v2.2 patch, item d(ii)).

        The walk climbs through value-expression nodes (BinOp/UnaryOp/
        Tuple/...); any other node type (a Call, a Subscript, ...) between
        the float and the assignment means the float is computed, not a
        declared input — not exempt. The assignment must be module-level
        (directly in the module body), single-target, and UPPER_CASE.
        """
        if not cited_inputs:
            return False
        cur = node
        while cur in parents:
            cur = parents[cur]
            if isinstance(cur, (ast.BinOp, ast.UnaryOp, ast.Tuple,
                                ast.List, ast.Set, ast.Dict, ast.IfExp,
                                ast.Starred)):
                continue  # still inside the assigned value expression
            if isinstance(cur, ast.Assign):
                targets = cur.targets
            elif isinstance(cur, ast.AnnAssign):
                targets = [cur.target]
            else:
                return False
            names = [t.id for t in targets
                     if isinstance(t, ast.Name) and t.id.isupper()]
            if len(names) == 1 and parents.get(cur) is tree \
                    and any(_fold(names[0]) in entry
                            for entry in cited_inputs):
                return True
            return False
        return False

    def float_exempt(node: ast.AST) -> bool:
        """Hardened display exemption: walk the AST parent chain; the
        float must reach a *builtin* print()/format() call whose source
        line carries the (display only) marker WITHOUT passing through
        any other call on the way.

        v2.2 patch F-48: the old walk ignored intermediate calls, so
        `print("result", compute(1.5))  # (display only)` wrongly exempted
        the computational 1.5. A float nested inside a non-print/format
        call is never a display argument — fail closed.
        """
        cur = node
        while cur in parents:
            cur = parents[cur]
            if isinstance(cur, ast.Call):
                if isinstance(cur.func, ast.Name) \
                        and cur.func.id in ("print", "format"):
                    if cur.func.id in bound_top:
                        return False  # shadowed: not the builtin
                    lineno = getattr(node, "lineno", 0)
                    if 1 <= lineno <= len(lines) \
                            and "(display only)" in lines[lineno - 1]:
                        return True
                    return False
                # v2.2 patch F-48: the float sits inside a nested
                # non-print/format call (e.g. compute(1.5) inside print)
                # — the value is computational, not display. Not exempt.
                return False
        return False

    def _dotted_name(func: ast.AST) -> str | None:
        """Resolve a.b.c attribute chains to their dotted name.

        Returns None for anything that is not a pure Name-rooted
        attribute chain (calls, subscripts, ...)."""
        parts: list[str] = []
        cur = func
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
            return ".".join(reversed(parts))
        return None

    def _dynamic_call_term(node: ast.Call) -> str | None:
        """Name the dynamic-execution primitive if this call uses one.

        Shapes caught: bare eval(...); builtins-rooted attribute chains
        (builtins.eval(...), __builtins__.exec(...)); getattr with a
        string literal naming a banned call (getattr(x, "eval")(...)).
        Returns the dotted/literal term, or None.
        """
        func = node.func
        if isinstance(func, ast.Name):
            if func.id in policy.banned_calls:
                return func.id
            return None
        if isinstance(func, ast.Attribute):
            dotted = _dotted_name(func)
            if dotted is not None:
                bits = dotted.split(".")
                # Restrict to the builtins root: re.compile(...) and
                # obj.exec(...) are legitimate code, not dynamic
                # execution. Only builtins.<banned> is the bypass shape.
                if len(bits) >= 2 and bits[-1] in policy.banned_calls \
                        and bits[0] in ("builtins", "__builtins__"):
                    return dotted
            return None
        if isinstance(func, ast.Call) and isinstance(func.func, ast.Name) \
                and func.func.id == "getattr" and len(func.args) >= 2:
            name_arg = func.args[1]
            if isinstance(name_arg, ast.Constant) \
                    and isinstance(name_arg.value, str) \
                    and name_arg.value in policy.banned_calls:
                return f'getattr(..., "{name_arg.value}")'
        return None

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top = alias.name.split(".")[0]
                if top in banned_modules:
                    violations.append({
                        "code": "BANNED_MODULE",
                        "term": alias.name,
                        "line": getattr(node, "lineno", None),
                    })
        elif isinstance(node, ast.ImportFrom):
            top = (node.module or "").split(".")[0]
            if top in banned_modules:
                violations.append({
                    "code": "BANNED_MODULE",
                    "term": node.module or "",
                    "line": getattr(node, "lineno", None),
                })
        elif isinstance(node, ast.Call):
            term = _dynamic_call_term(node)
            if term is not None:
                violations.append({
                    "code": "DYNAMIC_EXECUTION",
                    "term": term,
                    "line": getattr(node, "lineno", None),
                })

        if badge == "LEVEL_A":
            is_float_call = isinstance(node, ast.Call) \
                and isinstance(node.func, ast.Name) \
                and node.func.id == "float"
            is_float_literal = isinstance(node, ast.Constant) \
                and isinstance(node.value, float)
            if (is_float_call or is_float_literal) \
                    and not float_exempt(node) \
                    and not (is_float_literal
                             and provenance_input_exempt(node)):
                violations.append({
                    "code": "FLOAT_IN_LEVEL_A",
                    "term": "float() call" if is_float_call else "float literal",
                    "line": getattr(node, "lineno", None),
                })
    return violations


# ---------------------------------------------------------------------------
# Envelope construction
# ---------------------------------------------------------------------------

def envelope_for_hash(message: dict) -> dict:
    """Fields covered by the envelope hash (integrity metadata excluded to
    avoid a circular hash).

    v2.0.4: envelope_tier is hash-covered (tier is a security-relevant
    claim — a working/archival swap must invalidate the hash).
    epistemic_context is covered when present (working tier may omit it).
    """
    covered = {k: message[k]
               for k in ("protocol", "header", "envelope_tier", "payload")
               if k in message}
    if "epistemic_context" in message:
        covered["epistemic_context"] = message["epistemic_context"]
    return covered


def make_message(
    *,
    policy: Policy,
    sender: str,
    target: str,
    register: str | None = None,
    badge: str | None = None,
    content: str,
    envelope_tier: str = "archival",  # v2.0.4 D1: "working"|"archival"
    tier: str | None = None,  # v2.0.4 V21: hash tier "chat"|"machine"|None
    axiom_set_hash: str | None = None,
    registry_version: int | None = None,
    session_id: str = "default",
    content_format: str = "PLAIN_TEXT",
    claim_class: str = "STRUCTURAL",
    lineage: str = "prose",
    script_id: str | None = None,
    inherited_from: str | None = None,
    theorem_id: str | None = None,
    # v2.2 patch F-47: human_review lineage requires these three; the
    # validator rejects a human_review envelope missing any of them.
    reviewer: str | None = None,
    review_date: str | None = None,
    attestation_ref: str | None = None,
    depends_on=None,
    falsifiers=None,
    bridges=None,
    determinism=None,
    message_type: str = "REQUEST",
    in_reply_to: str | None = None,
    three_line_register=None,
    scope_notes: str = "",
) -> dict:
    """Build a message envelope. Refuses (raises ValueError) if the message
    fails its own validation — never emits an invalid payload.

    v2.0.4: envelope_tier selects the completeness tier. "archival"
    (default) requires register+ badge and the full envelope. "working"
    makes epistemic_context optional — it is included only when register
    and badge are both given, otherwise omitted (the validator records
    "context:undeclared"). tier selects the hash tier: None (default)
    computes real hashes with no declared tier (machine behavior, as
    before); "machine" computes real hashes and declares tier "machine";
    "chat" leaves both hashes blank and declares tier "chat" (for
    machine-side construction of chat-tier envelopes).
    """
    if not isinstance(content, str):
        raise ValueError("outbound refusal: content must be a string")
    if envelope_tier not in ENVELOPE_TIERS:
        raise ValueError(
            f"outbound refusal: envelope_tier must be one of "
            f"{sorted(ENVELOPE_TIERS)}")
    if envelope_tier == "archival" and (register is None or badge is None):
        raise ValueError(
            "outbound refusal: archival tier requires register and badge")
    if tier is not None and tier not in TIERS:
        raise ValueError(
            f"outbound refusal: tier must be one of {sorted(TIERS)}")
    header: dict = {
        "message_id": str(uuid.uuid4()),
        "message_type": message_type,
        "sender_agent": sender,
        "target_agent": target,
        "timestamp": now(),
        "protocol_version": VERSION,
        "min_protocol_version": VERSION,
    }
    if in_reply_to is not None:
        header["in_reply_to"] = in_reply_to

    provenance: dict = {"lineage": lineage,
                        "depends_on": list(depends_on or [])}
    if script_id is not None:
        provenance["script_id"] = script_id
    if inherited_from is not None:
        provenance["inherited_from"] = inherited_from
    if theorem_id is not None:
        provenance["theorem_id"] = theorem_id
    if reviewer is not None:
        provenance["reviewer"] = reviewer
    if review_date is not None:
        provenance["review_date"] = review_date
    if attestation_ref is not None:
        provenance["attestation_ref"] = attestation_ref

    payload: dict = {
        "format": content_format,
        "content": content,
        "claim_class": claim_class,
        "provenance": provenance,
        "determinism": determinism or {"mode": "DETERMINISTIC"},
    }
    if falsifiers is not None:
        payload["falsification"] = {"conditions": list(falsifiers)}
    if bridges is not None:
        payload["bridge_levels"] = list(bridges)
    if three_line_register is not None:
        payload["three_line_register"] = dict(three_line_register)

    message = {
        "protocol": {"name": "ESP", "version": VERSION},
        "header": header,
        "envelope_tier": envelope_tier,
        "payload": payload,
        "integrity": {
            "content_hash": "" if tier == "chat" else digest(content),
            "envelope_hash": "",
            "axiom_set_hash": axiom_set_hash or policy.axiom_set_hash,
            "registry_version": registry_version
            if registry_version is not None else policy.registry_version,
            "status": "PENDING",
            # v2.0.2: violations/audit_chain are validator-emitted only;
            # outbound messages never carry them (inbound ones are stripped).
        },
    }
    if register is not None and badge is not None:
        message["epistemic_context"] = {
            "session_id": session_id,
            "register": register,
            "badge": badge,
            "axiom_set_hash": axiom_set_hash or policy.axiom_set_hash,
            "registry_version": registry_version
            if registry_version is not None else policy.registry_version,
            "active_axioms": sorted(policy.axiom_universe),
            "scope_notes": scope_notes,
        }
    if tier is not None:
        message["integrity"]["tier"] = tier
    if tier != "chat":
        message["integrity"]["envelope_hash"] = object_digest(
            envelope_for_hash(message))

    result = validate_message(message, policy)
    if not result["ok"]:
        raise ValueError(
            f"outbound refusal: constructed message failed own validation: "
            f"{result.get('error')}")
    return message


# ---------------------------------------------------------------------------
# Dialectic records (v2.0.4 D2/D3 — archival tier)
# ---------------------------------------------------------------------------

def _validate_disagreement(dis, policy: Policy):
    """Structural validation of a DISAGREEMENT record (D2).

    Records two agents' divergent verdicts on one envelope plus the
    precise structured delta and an optional later human adjudication.
    The protocol routes disagreements; it does not adjudicate them.
    """
    dis = _req_object(dis, "payload.disagreement")
    _req_keys(dis,
              {"target_message_id", "position_a", "position_b", "delta"},
              {"target_message_id", "position_a", "position_b", "delta",
               "adjudication"},
              "payload.disagreement")
    _req_uuid(dis["target_message_id"], "disagreement.target_message_id")
    for side in ("position_a", "position_b"):
        pos = _req_object(dis[side], f"disagreement.{side}")
        _req_keys(pos, {"agent", "verdict", "check", "reason"},
                  {"agent", "verdict", "check", "reason"},
                  f"disagreement.{side}")
        _req_nonempty(pos["agent"], f"disagreement.{side}.agent")
        _req_enum(pos["verdict"], DISAGREEMENT_VERDICTS,
                  f"disagreement.{side}.verdict")
        _req_nonempty(pos["check"], f"disagreement.{side}.check")
        _req_nonempty(pos["reason"], f"disagreement.{side}.reason")
    delta = _req_object(dis["delta"], "disagreement.delta")
    _req_keys(delta, {"check", "a_reading", "b_reading"},
              {"check", "a_reading", "b_reading"}, "disagreement.delta")
    for key in ("check", "a_reading", "b_reading"):
        _req_nonempty(delta[key], f"disagreement.delta.{key}")
    if "adjudication" in dis:
        adj = _req_object(dis["adjudication"], "disagreement.adjudication")
        _req_keys(adj, {"status"},
                  {"status", "resolution", "adjudicated_by", "evidence_ref"},
                  "disagreement.adjudication")
        _req_enum(adj["status"], ADJUDICATION_STATUSES,
                  "disagreement.adjudication.status")
        for key in ("resolution", "adjudicated_by", "evidence_ref"):
            if key in adj and not isinstance(adj[key], str):
                raise ProtocolError(
                    f"disagreement.adjudication.{key} must be a string")


def _validate_confrontation(con, policy: Policy):
    """Structural validation of a CONFRONTATION record (D3).

    Second-person challenge: "your claim fails because...". Distinct
    from FALSIFICATION (first-person: "what would falsify my claim").
    broken_premise is structured {axiom, premise_id, statement} so a
    reader can check whether the named premise exists and fails.
    """
    con = _req_object(con, "payload.confrontation")
    _req_keys(con,
              {"target_claim_id", "counterexample", "demonstration",
               "broken_premise", "claim_class"},
              {"target_claim_id", "counterexample", "demonstration",
               "broken_premise", "claim_class"},
              "payload.confrontation")
    _req_uuid(con["target_claim_id"], "confrontation.target_claim_id")
    _req_nonempty(con["counterexample"], "confrontation.counterexample")
    _req_nonempty(con["demonstration"], "confrontation.demonstration")
    _req_enum(con["claim_class"], CLAIMS, "confrontation.claim_class")
    bp = _req_object(con["broken_premise"], "confrontation.broken_premise")
    _req_keys(bp, {"statement"}, {"axiom", "premise_id", "statement"},
              "confrontation.broken_premise")
    _req_nonempty(bp["statement"], "confrontation.broken_premise.statement")
    if bp.get("axiom") is not None \
            and bp["axiom"] not in policy.axiom_universe:
        raise ProtocolError(
            "confrontation.broken_premise.axiom not in registry axiom "
            f"universe: {bp['axiom']}")
    if bp.get("premise_id") is not None \
            and not isinstance(bp["premise_id"], str):
        raise ProtocolError(
            "confrontation.broken_premise.premise_id must be a string "
            "or null")


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _looks_like_v1(message: dict) -> bool:
    try:
        if message.get("protocol", {}).get("version") == "1.0":
            return True
        for section in ("epistemic_context", "integrity"):
            ctx = message.get(section, {})
            if isinstance(ctx, dict) and "axiom_registry_hash" in ctx:
                return True
    except Exception:
        # Heuristic pre-check only: any failure means "not v1-shaped";
        # the main validator will reject the malformed input properly.
        return False
    return False


def validate_message(message, policy: Policy | None = None) -> dict:
    """Validate a message. NEVER raises on malformed input: every failure
    mode returns {"ok": False, "status": "REJECTED", "error": ...}.

    On success returns status VALIDATED plus a `checks` list naming exactly
    the checks that ran, and the `not_established` honesty list.
    """
    if policy is None:
        raise ValueError(
            "a Policy is required; use Policy(demo_registry=True) for the "
            "declared demo registry, Policy(insecure_demo_registry=True) "
            "for the zero-hash placeholder, or configure a real registry")
    # v2.0.4 V22: the demo warning is suppressible for batch validation.
    if policy.warn_on_validate:
        policy.warn_if_demo()
    checks: list[str] = []

    def rejected(error: str) -> dict:
        return {"ok": False, "status": "REJECTED", "error": error,
                "checks": checks, "not_established": NOT_ESTABLISHED}

    try:
        if isinstance(message, str):
            try:
                message = json.loads(message)
            except (json.JSONDecodeError, ValueError) as exc:
                return rejected(f"JSON parse failure: {exc}")
        if not isinstance(message, dict):
            return rejected("message must be a JSON object")

        if _looks_like_v1(message):
            return rejected(
                "ESP v1.0 envelope detected (field renames in v2.0: "
                "axiom_registry_hash -> axiom_set_hash, "
                "protocol.version 1.0 -> 2.0, "
                "integrity.axiom_registry_hash -> integrity.axiom_set_hash); "
                "use migrate_v1_to_v2() to convert")

        try:
            size = len(canonical(message))
        except (ValueError, TypeError) as exc:
            return rejected(f"message not JSON-canonicalizable: {exc}")
        if size > policy.max_message_chars:
            return rejected("message exceeds size limit")

        message = _req_object(message, "$")
        _req_keys(message,
                  {"protocol", "header", "envelope_tier", "payload",
                   "integrity"},
                  {"protocol", "header", "envelope_tier", "epistemic_context",
                   "payload", "integrity"},
                  "$")
        checks.append("structure")

        if message["protocol"] != {"name": "ESP", "version": VERSION}:
            raise ProtocolError(
                f"unsupported protocol (expected ESP {VERSION})")

        # v2.0.4 D1: envelope completeness tier. Working = cheap
        # conversational layer; archival = full context, enforcing.
        tier = message["envelope_tier"]
        _req_enum(tier, ENVELOPE_TIERS, "envelope_tier")
        checks.append(f"envelope_tier:{tier}")

        header = _req_object(message["header"], "header")
        _req_keys(header,
                  {"message_id", "message_type", "sender_agent",
                   "target_agent", "timestamp", "protocol_version",
                   "min_protocol_version"},
                  {"message_id", "in_reply_to", "correlation_id",
                   "message_type", "sender_agent", "target_agent",
                   "timestamp", "protocol_version", "min_protocol_version"},
                  "header")
        _req_uuid(header["message_id"], "header.message_id")
        _req_uuid(header.get("in_reply_to"), "header.in_reply_to",
                  nullable=True)
        if header.get("correlation_id") is not None:
            _req_uuid(header["correlation_id"], "header.correlation_id")
        _req_enum(header["message_type"], TYPES, "header.message_type")
        # v2.0.4 D1: the working tier carries conversation only. An
        # archival message type on the working tier is REJECTED with
        # TIER_MISMATCH — the mechanical upgrade path is filling
        # epistemic_context and resending as archival.
        if tier == "working" and header["message_type"] not in WORKING_TYPES:
            raise ProtocolError(
                f"TIER_MISMATCH: message_type {header['message_type']} "
                f"requires the archival tier (working tier carries "
                f"{sorted(WORKING_TYPES)} only); resend with envelope_tier "
                f"'archival' and full epistemic_context")
        _req_nonempty(header["sender_agent"], "header.sender_agent")
        _req_nonempty(header["target_agent"], "header.target_agent")
        _req_maxlen(header["sender_agent"], "header.sender_agent", 256)
        _req_maxlen(header["target_agent"], "header.target_agent", 256)
        # v2.0.2: a RESPONSE must name its antecedent — audit threading.
        if header["message_type"] == "RESPONSE" \
                and not header.get("in_reply_to"):
            raise ProtocolError(
                "RESPONSE requires header.in_reply_to (audit threading)")
        parsed_ts = _req_timestamp(header["timestamp"], "header.timestamp")
        # v2.0.3: future-dating is never legitimate traffic — the clock-skew
        # bound is unconditional hygiene. The replay bound stays opt-in
        # (async sparring rounds are legitimately validated hours later).
        age = (datetime.now(timezone.utc) - parsed_ts).total_seconds()
        if age < -300:
            raise ProtocolError(
                "header.timestamp is more than 300s in the future "
                "(clock skew bound)")
        if policy.max_age_seconds is not None \
                and age > policy.max_age_seconds:
            raise ProtocolError(
                f"header.timestamp is {int(age)}s old, older than "
                f"max_age_seconds={policy.max_age_seconds} (replay bound)")
        if header["protocol_version"] != VERSION \
                or header["min_protocol_version"] != VERSION:
            raise ProtocolError("unsupported protocol version "
                                f"(expected {VERSION})")

        # v2.0.4 D1: epistemic_context is optional on the working tier.
        # Absent context is recorded honestly ("context:undeclared"), not
        # rejected — but register/badge/registry checks cannot run without
        # it, so they are skipped and the checks list says so.
        ctx_raw = message.get("epistemic_context")
        if ctx_raw is None:
            if tier != "working":
                raise ProtocolError(
                    "archival tier requires epistemic_context "
                    "(full context is what makes the tier archival)")
            checks.append("context:undeclared")
            ctx = None
            register = None
            badge = None
        else:
            ctx = _req_object(ctx_raw, "epistemic_context")
            _req_keys(ctx,
                      {"session_id", "register", "badge", "axiom_set_hash",
                       "registry_version"},
                      {"session_id", "register", "badge", "axiom_set_hash",
                       "registry_version", "active_axioms", "scope_notes"},
                      "epistemic_context")
            _req_nonempty(ctx["session_id"], "session_id")
            _req_maxlen(ctx["session_id"], "session_id", 256)
            _req_enum(ctx["register"], REGISTERS, "register")
            _req_enum(ctx["badge"], BADGES, "badge")
            _req_sha(ctx["axiom_set_hash"], "axiom_set_hash")
            _req_int(ctx["registry_version"], "registry_version", 0)
            if "active_axioms" in ctx:
                _req_unique_strs(ctx["active_axioms"], "active_axioms")
                unknown = [a for a in ctx["active_axioms"]
                           if a not in policy.axiom_universe]
                if unknown:
                    raise ProtocolError(
                        "active_axioms not in registry axiom universe: "
                        f"{unknown}")
            if "scope_notes" in ctx \
                    and not isinstance(ctx["scope_notes"], str):
                raise ProtocolError("scope_notes must be a string")
            _req_maxlen(ctx.get("scope_notes", ""), "scope_notes", 4000)

            register = ctx["register"]
            badge = ctx["badge"]
            if register == "STAGE_N" and badge != "LEVEL_A":
                raise ProtocolError("STAGE_N requires LEVEL_A badge")
            if register == "STAGE_P" and badge not in {"LEVEL_A", "LEVEL_B"}:
                raise ProtocolError("STAGE_P requires LEVEL_A or LEVEL_B")
            if register == "STAGE_C" and badge not in {"LEVEL_B", "LEVEL_C"}:
                raise ProtocolError("STAGE_C requires LEVEL_B or LEVEL_C")
            if register == "META_AUDIT" and badge != "META":
                raise ProtocolError("META_AUDIT requires META badge")
            checks.append("register_badge")

            if ctx["axiom_set_hash"] != policy.axiom_set_hash:
                raise ProtocolError(
                    "axiom_set_hash mismatch with local registry")
            skew = abs(ctx["registry_version"] - policy.registry_version)
            if skew > policy.accepted_registry_skew:
                raise ProtocolError(
                    f"registry version skew {skew} exceeds accepted bound "
                    f"+-{policy.accepted_registry_skew}")
            checks.append("registry_match")

        payload = _req_object(message["payload"], "payload")
        _req_keys(payload,
                  {"format", "content", "claim_class", "provenance",
                   "determinism"},
                  {"format", "content", "claim_class", "provenance",
                   "determinism", "three_line_register", "falsification",
                   "bridge_levels", "formal_assertions", "dependencies",
                   "metadata", "disagreement", "confrontation"},
                  "payload")
        _req_enum(payload["format"], FORMATS, "payload.format")
        _req_enum(payload["claim_class"], CLAIMS, "payload.claim_class")
        _req_nonempty(payload["content"], "payload.content")
        if len(payload["content"]) > policy.max_content_chars:
            raise ProtocolError("content exceeds size limit")

        prov = _req_object(payload["provenance"], "provenance")
        _req_keys(prov, {"lineage"},
                  {"lineage", "script_id", "inherited_from", "theorem_id",
                   "depends_on", "reviewer", "review_date",
                   "attestation_ref"},
                  "provenance")
        _req_enum(prov["lineage"], LINEAGES, "provenance.lineage")
        if prov["lineage"] == "script":
            sid = prov.get("script_id")
            if not isinstance(sid, str) or not SCRIPT_RE.fullmatch(sid):
                raise ProtocolError(
                    "script lineage requires script_id matching "
                    "(F|P|H|G|MC|FW|PA).<digits>")
        if prov["lineage"] == "bundle":
            # v2.2: bundle lineage reports outcomes of executing a bundle
            # of scripts. The bundle manifest named in depends_on is the
            # grounding — fail closed when it is missing or names no
            # bundle artifact. Existence is the recipient's check (shape
            # check only, same as script_id); the error names the cause.
            deps = prov.get("depends_on")
            if not isinstance(deps, list) or not deps:
                raise ProtocolError(
                    "bundle lineage requires depends_on naming at least "
                    "one bundle artifact (.zip)")
            if not any(isinstance(d, str) and BUNDLE_RE.search(d)
                       for d in deps):
                raise ProtocolError(
                    "bundle lineage requires depends_on to name at least "
                    "one bundle artifact (.zip): none of the named "
                    f"{len(deps)} entries ends in .zip")
        if prov["lineage"] == "inherited":
            _req_nonempty(prov.get("inherited_from"),
                          "inherited lineage requires inherited_from")
        if prov["lineage"] == "human_review":
            # v2.2 patch F-47: human_review is the one lineage asserting
            # human sign-off, so it must name its reviewer, the review
            # date, and a reference to the attestation. Fail closed: any
            # of the three missing or empty rejects the envelope. (The
            # validator establishes that the fields are PRESENT, never
            # that the human actually reviewed — attestation content is
            # the recipient's check, same as script_id existence.)
            for _key in ("reviewer", "review_date", "attestation_ref"):
                _req_nonempty(
                    prov.get(_key),
                    f"human_review lineage requires {_key}")
        if "depends_on" in prov:
            _req_unique_strs(prov["depends_on"], "depends_on")

        det = _req_object(payload["determinism"], "determinism")
        _req_keys(det, {"mode"}, {"mode", "seed", "note"}, "determinism")
        _req_enum(det["mode"], MODES, "determinism.mode")
        if det["mode"] == "SEEDED":
            _req_int(det.get("seed"), "determinism.seed")
        if "note" in det and not isinstance(det["note"], str):
            raise ProtocolError("determinism.note must be a string")
        if det["mode"] == "STOCHASTIC" and register == "STAGE_N":
            raise ProtocolError(
                "STAGE_N requires DETERMINISTIC or SEEDED mode")
        checks.append("determinism")

        tlr = payload.get("three_line_register")
        if tlr is not None:
            tlr = _req_object(tlr, "three_line_register")
            _req_keys(tlr, set(),
                      {"native", "reconstruction", "observation"},
                      "three_line_register")
            if any(not isinstance(v, str) for v in tlr.values()):
                raise ProtocolError(
                    "three_line_register values must be strings")
            if register == "STAGE_N" and badge == "LEVEL_A" \
                    and not tlr.get("native", "").strip():
                raise ProtocolError(
                    "STAGE_N/LEVEL_A requires a non-empty native register "
                    "line when three_line_register is supplied")
            checks.append("three_line_register")

        fals = payload.get("falsification")
        # LEVEL_A always requires >=1 falsification condition (binding
        # decision 10 — no toggle). The "falsification" check name is
        # appended only when the check actually ran (badge truthfulness).
        if badge == "LEVEL_A":
            if not isinstance(fals, dict) \
                    or not isinstance(fals.get("conditions"), list) \
                    or not fals["conditions"]:
                raise ProtocolError(
                    "LEVEL_A requires at least one falsification "
                    "condition")
        if fals is not None:
            fals = _req_object(fals, "falsification")
            _req_keys(fals, {"conditions"}, {"conditions"},
                      "falsification")
            seen: set[str] = set()
            for i, cond in enumerate(fals["conditions"]):
                path = f"falsification.conditions[{i}]"
                cond = _req_object(cond, path)
                _req_keys(cond, {"id", "statement"},
                          {"id", "statement", "trigger"}, path)
                cid = cond["id"]
                if not isinstance(cid, str) \
                        or not COND_RE.fullmatch(cid) or cid in seen:
                    raise ProtocolError(
                        f"{path}: invalid or duplicate condition id")
                seen.add(cid)
                _req_nonempty(cond["statement"], path + ".statement")
                if "trigger" in cond \
                        and not isinstance(cond["trigger"], str):
                    raise ProtocolError(f"{path}.trigger must be a string")
            checks.append("falsification")

        bridges = payload.get("bridge_levels", [])
        if not isinstance(bridges, list):
            raise ProtocolError("bridge_levels must be an array")
        if bridges:
            for i, bridge in enumerate(bridges):
                path = f"bridge_levels[{i}]"
                bridge = _req_object(bridge, path)
                _req_keys(bridge, {"from", "to", "bridge_level"},
                          {"from", "to", "bridge_level",
                           "bridge_description"}, path)
                _req_nonempty(bridge["from"], path + ".from")
                _req_nonempty(bridge["to"], path + ".to")
                _req_enum(bridge["bridge_level"], BRIDGES,
                          path + ".bridge_level")
                if "bridge_description" in bridge \
                        and not isinstance(bridge["bridge_description"], str):
                    raise ProtocolError(
                        path + ".bridge_description must be a string")
                if badge == "LEVEL_A" and bridge["bridge_level"] != "A":
                    raise ProtocolError(
                        "LEVEL_A payload cannot depend on a level "
                        f"{bridge['bridge_level']} bridge")
            checks.append("bridges")

        # v2.0.4 D2/D3: the dialectic message types carry structured
        # records. The TIER_MISMATCH gate above already forced archival;
        # here the record shape itself is validated.
        mtype = header["message_type"]
        if mtype == "DISAGREEMENT":
            if "disagreement" not in payload:
                raise ProtocolError(
                    "DISAGREEMENT requires payload.disagreement "
                    "{target_message_id, position_a, position_b, delta, "
                    "adjudication?}")
            _validate_disagreement(payload["disagreement"], policy)
            checks.append("disagreement")
        if mtype == "CONFRONTATION":
            if "confrontation" not in payload:
                raise ProtocolError(
                    "CONFRONTATION requires payload.confrontation "
                    "{target_claim_id, counterexample, demonstration, "
                    "broken_premise, claim_class}")
            _validate_confrontation(payload["confrontation"], policy)
            checks.append("confrontation")

        # v2.0.2: validate a DEEP COPY. The v2.0.1 chat tier wrote computed
        # hashes back into the caller's dict, so one chat-tier pass
        # manufactured machine-tier "verified" credentials on revalidation
        # (tier laundering). The caller's object is never touched now.
        message = copy.deepcopy(message)
        # Re-fetch views into the copy (payload/ctx/tlr were bound above).
        # v2.0.4: epistemic_context may be absent (working tier).
        payload = message["payload"]
        ctx = message.get("epistemic_context")
        header = message["header"]
        tlr = payload.get("three_line_register")

        integ = _req_object(message["integrity"], "integrity")
        _req_keys(integ,
                  {"content_hash", "envelope_hash", "axiom_set_hash",
                   "registry_version", "status"},
                  {"content_hash", "envelope_hash", "axiom_set_hash",
                   "registry_version", "status", "tier",
                   "violations", "audit_chain"},
                  "integrity")
        for key in ("axiom_set_hash",):
            _req_sha(integ[key], "integrity." + key)
        # Two-tier hash handling (v2.0.1, hardened in v2.0.2):
        #  - Chat tier: a chat AI cannot compute SHA-256, so it MUST leave
        #    content_hash/envelope_hash as "" — the validator computes them.
        #  - Machine tier: non-empty hashes are verified strictly; forged
        #    hashes are REJECTED.
        # Honesty scope (v2.0.2 correction): both tiers attest
        # well-formedness + self-consistency at validation time + the named
        # checks that ran. Neither tier is tamper-evidence against a
        # competent attacker (anyone with Python can recompute hashes);
        # the machine tier is corruption-detection plus lazy-forgery
        # detection. sender_identity and transport_authenticity are never
        # established — see NOT_ESTABLISHED.
        for key in ("content_hash", "envelope_hash"):
            val = integ[key]
            if not isinstance(val, str) or (val != "" and not HASH_RE.fullmatch(val)):
                raise ProtocolError(f"integrity.{key}: expected lowercase SHA-256 or \"\" (compute-locally)")
        _req_int(integ["registry_version"], "integrity.registry_version", 0)
        # v2.0.2: explicit tier signal. Declared tiers are enforced;
        # undeclared tiers are inferred from hash presence and labeled so.
        # A liar can still misdeclare, but downgrade becomes an explicit
        # false claim in the envelope instead of a silent omission.
        declared_tier = integ.get("tier")
        if declared_tier is not None:
            _req_enum(declared_tier, TIERS, "integrity.tier")
        # Validation state is determined by the validator, never
        # self-declared: inbound messages must carry PENDING.
        if integ["status"] != "PENDING":
            raise ProtocolError(
                "inbound integrity.status must be PENDING; validation "
                "state is determined by the validator, never self-declared")
        # v2.0.2: inbound audit history is stripped, not trusted. The old
        # comment claimed forged violations/audit_chain "must not survive
        # validation" but the code only type-checked them — forged entries
        # survived in the mutated object. Now they are dropped outright;
        # only validator-emitted violations (below) and receipts exist.
        if "violations" in integ or "audit_chain" in integ:
            integ.pop("violations", None)
            integ.pop("audit_chain", None)
            checks.append("audit_history:stripped")
        # v2.0.4: with no epistemic_context (working tier), the integrity
        # registry fields are checked against the LOCAL policy — the only
        # registry reference available.
        ref_hash = ctx["axiom_set_hash"] if ctx is not None \
            else policy.axiom_set_hash
        ref_version = ctx["registry_version"] if ctx is not None \
            else policy.registry_version
        if integ["axiom_set_hash"] != ref_hash \
                or integ["registry_version"] != ref_version:
            raise ProtocolError("integrity/context registry mismatch")

        blank_content = integ["content_hash"] == ""
        blank_envelope = integ["envelope_hash"] == ""
        if declared_tier == "machine" and (blank_content or blank_envelope):
            raise ProtocolError(
                "integrity.tier 'machine' requires non-empty content_hash "
                "and envelope_hash (sender-computed)")
        if declared_tier == "chat" and not (blank_content and blank_envelope):
            raise ProtocolError(
                "integrity.tier 'chat' requires blank content_hash and "
                "envelope_hash; non-empty hashes contradict the chat tier "
                "(declare 'machine' or omit tier)")
        if blank_content and blank_envelope:
            effective_tier = "chat"
        elif not blank_content and not blank_envelope:
            effective_tier = "machine"
        else:
            effective_tier = "mixed"
        # v2.0.2: high-stakes deployments can refuse the chat tier outright.
        if policy.require_machine_tier and effective_tier != "machine":
            raise ProtocolError(
                "policy require_machine_tier: chat/mixed-tier hashes refused; "
                "resubmit with sender-computed hashes and tier 'machine'")
        checks.append(
            f"tier:{effective_tier}"
            + ("-declared" if declared_tier else "-inferred"))

        computed_content = digest(payload["content"])
        if blank_content:
            integ["content_hash"] = computed_content
            checks.append("content_hash:computed-locally")
        elif computed_content != integ["content_hash"]:
            raise ProtocolError(
                "content hash mismatch (sender-supplied "
                f"{integ['content_hash'][:16]}… != recomputed "
                f"{computed_content[:16]}…): tampered content or forged hash. "
                "If you are a chat AI, you cannot compute SHA-256 — leave "
                "content_hash as \"\" and the validator computes it; "
                "invented hex is always rejected.")
        else:
            checks.append("content_hash:verified")
        computed_envelope = object_digest(envelope_for_hash(message))
        if blank_envelope:
            integ["envelope_hash"] = computed_envelope
            checks.append("envelope_hash:computed-locally")
        elif computed_envelope != integ["envelope_hash"]:
            raise ProtocolError(
                "envelope hash mismatch (sender-supplied "
                f"{integ['envelope_hash'][:16]}… != recomputed "
                f"{computed_envelope[:16]}…): tampered header/context or "
                "forged hash. Chat AIs: leave envelope_hash as \"\" and the "
                "validator computes it; invented hex is always rejected.")
        else:
            checks.append("envelope_hash:verified")

        violations: list[dict] = []
        # v2.0.4: lexical findings are tracked separately from enforcing
        # violations. On the working tier the firewall is ADVISORY (D1):
        # findings become firewall_warnings, never rejections. The
        # archival tier stays enforcing.
        lex_findings: list[dict] = []

        def _scan_free(value, label: str) -> list[str]:
            # v2.0.4 RT-001 fail-closed: a depth-bound breach becomes a
            # dedicated violation code, never a silent truncation.
            try:
                return _free_texts(value)
            except DepthBoundExceeded as exc:
                lex_findings.append({
                    "code": "FREE_TEXT_DEPTH_EXCEEDED",
                    "field": label,
                    "detail": str(exc),
                })
                return []

        if policy.enforce_lexical_policy:
            texts = [payload["content"]]
            if tlr:
                texts.extend(tlr.values())
            # v2.0.2: scope_notes is free text and was previously hashed but
            # never scanned — a banned term smuggled there passed silently.
            if ctx is not None and ctx.get("scope_notes"):
                texts.append(ctx["scope_notes"])
            # v2.0.3/v2.0.4: the known free-text channels are scanned:
            # content, three_line_register values, scope_notes,
            # falsification, metadata, formal_assertions, dependencies,
            # disagreement, confrontation, provenance.depends_on,
            # bridge_descriptions, determinism.note, session_id.
            # Deliberately NOT scanned: sender_agent/target_agent and other
            # identifier-shaped header fields (identity is not_established;
            # scanning names invites false positives).
            # KNOWN UNSCANNED (v2.0.4 loop, held for the author's ruling):
            # provenance.inherited_from, provenance.theorem_id,
            # bridge_levels[].from/.to, and dict KEYS inside
            # _free_texts-walked trees. Named here, not hidden — the
            # firewall is a floor, not a ceiling (D6).
            # v2.0.4: DISAGREEMENT and CONFRONTATION records are free-text
            # channels too — scanned with the same fail-closed depth rule.
            # v2.0.4 (held item): provenance.depends_on and
            # bridge_descriptions are free-text channels as well — a
            # banned term rides in a dependency label as easily as in a
            # statement.
            for _field in ("falsification", "metadata", "formal_assertions",
                           "dependencies", "disagreement", "confrontation"):
                texts.extend(_scan_free(payload.get(_field), _field))
            texts.extend(_scan_free(prov.get("depends_on"),
                                    "provenance.depends_on"))
            texts.extend(_scan_free(
                [b.get("bridge_description") for b in bridges
                 if isinstance(b, dict)],
                "bridge_levels.bridge_description"))
            det_note = payload["determinism"].get("note")
            if det_note:
                texts.append(det_note)
            if ctx is not None and ctx.get("session_id"):
                texts.append(ctx["session_id"])
            for text in texts:
                lex_findings.extend(lexical_check(text, policy))
            checks.append(
                "lexical" if tier == "archival" else "lexical:advisory")

        if payload["format"] == "EXECUTABLE_PYTHON":
            violations.extend(
                python_static_check(payload["content"], badge, policy))
            checks.append("arithmetic")

        # v2.0.4 D1 advisory mode: working-tier lexical findings ride on
        # the result as warnings. Code-safety findings (the
        # EXECUTABLE_PYTHON static check) stay enforcing on both tiers —
        # advisory covers vocabulary, never code execution.
        firewall_warnings: list[dict] = []
        if tier == "working":
            firewall_warnings = lex_findings
        else:
            violations.extend(lex_findings)

        if violations:
            return {"ok": False, "status": "REJECTED",
                    "error": "policy violations: "
                    + canonical(violations)[:2000],
                    "violations": violations,
                    "checks": checks,
                    "not_established": NOT_ESTABLISHED}

        if not checks:
            # Internal bug guard: a VALIDATED badge with an empty checks
            # list must never ship.
            return rejected("internal error: empty checks list on success")

        return {"ok": True, "status": "VALIDATED",
                "message_id": header["message_id"],
                "content_hash": integ["content_hash"],
                "envelope_hash": integ["envelope_hash"],
                "checks": checks,
                # v2.0.4 D1: working-tier advisory firewall findings.
                # Empty on the archival tier (findings there reject).
                "firewall_warnings": firewall_warnings,
                "not_established": NOT_ESTABLISHED}
    except ProtocolError as exc:
        return rejected(str(exc))
    except Exception as exc:
        # Never crash on malformed input: every failure mode is REJECTED.
        # (Exception, not a narrower tuple: hostile dict subclasses and
        # exotic objects must not escape the validator. BaseException
        # subclasses like KeyboardInterrupt/SystemExit still propagate.)
        return rejected(f"validation error: {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------------------
# Audit receipts
# ---------------------------------------------------------------------------

def emit_audit_receipt(agent: str, payload_hash: str, result: str,
                       notes: str = "") -> dict:
    """Co-sign a validation outcome. Receipts are attestations, not proofs."""
    if not isinstance(agent, str) or not agent.strip():
        raise ValueError("agent must be a non-empty string")
    if not isinstance(payload_hash, str) \
            or not HASH_RE.fullmatch(payload_hash):
        raise ValueError("payload_hash must be a lowercase SHA-256 hex")
    if result not in RECEIPT_RESULTS:
        raise ValueError(f"result must be one of {sorted(RECEIPT_RESULTS)}")
    return {"agent": agent, "payload_hash": payload_hash, "result": result,
            "timestamp": now(), "notes": notes}


# ---------------------------------------------------------------------------
# v1.0 -> v2.0 migration
# ---------------------------------------------------------------------------

def migrate_v1_to_v2(v1msg: dict) -> dict:
    """Convert an ESP v1.0 envelope to v2.0.

    Field renames: axiom_registry_hash -> axiom_set_hash (context and
    integrity), protocol.version 1.0 -> 2.0, header protocol_version /
    min_protocol_version -> 2.0. Hashes are recomputed; status reset to
    PENDING (migration does not validate).
    Grok-v4 payloads are envelope-incompatible: no auto-migration.

    Raises ValueError on any malformed input (never KeyError/TypeError/
    AttributeError/RecursionError).
    """
    if not isinstance(v1msg, dict):
        raise ValueError("v1 message must be a dict")
    for key in ("protocol", "header", "epistemic_context", "payload",
                "integrity"):
        if key not in v1msg:
            raise ValueError(f"v1 message missing top-level key: {key}")
        if not isinstance(v1msg[key], dict):
            raise ValueError(f"v1 message: '{key}' must be an object")
    try:
        msg = json.loads(canonical(v1msg))
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError(f"v1 message not serializable: {exc}") from exc
    ctx = msg.get("epistemic_context", {})
    if "axiom_registry_hash" in ctx:
        ctx["axiom_set_hash"] = ctx.pop("axiom_registry_hash")
    integ = msg.get("integrity", {})
    if "axiom_registry_hash" in integ:
        integ["axiom_set_hash"] = integ.pop("axiom_registry_hash")
    if isinstance(msg.get("protocol"), dict):
        msg["protocol"]["version"] = VERSION
    header = msg.get("header", {})
    header["protocol_version"] = VERSION
    header["min_protocol_version"] = VERSION
    # v2.0.4: migrated envelopes land on the archival tier (full context
    # is what migration preserves).
    msg["envelope_tier"] = "archival"
    payload = msg.get("payload", {})
    if isinstance(payload, dict) and isinstance(payload.get("content"), str):
        integ["content_hash"] = digest(payload["content"])
    integ["envelope_hash"] = object_digest(envelope_for_hash(msg))
    integ["status"] = "PENDING"
    integ["violations"] = []
    integ["audit_chain"] = []
    return msg


# ---------------------------------------------------------------------------
# Chunk protocol (ESP-CHUNK-2)
# ---------------------------------------------------------------------------

def chunk_text(text: str, max_chars: int = 12000,
               max_chunks: int = 10000) -> list[dict]:
    """Split text into indexed chunks with per-chunk and whole-text hashes."""
    if not isinstance(text, str) or not text:
        raise ProtocolError("cannot chunk empty or non-text input")
    if isinstance(max_chars, bool) or not isinstance(max_chars, int):
        raise ProtocolError("max_chars must be an integer")
    if isinstance(max_chunks, bool) or not isinstance(max_chunks, int):
        raise ProtocolError("max_chunks must be an integer")
    if max_chars < 256:
        raise ProtocolError("max_chars must be >= 256")
    parts = [text[i:i + max_chars]
             for i in range(0, len(text), max_chars)]
    if len(parts) > max_chunks:
        raise ProtocolError("chunk count exceeds limit")
    transfer_id = str(uuid.uuid4())
    whole = digest(text)
    return [{"transfer_protocol": CHUNK_PROTOCOL,
             "transfer_id": transfer_id,
             "index": i, "count": len(parts),
             "full_text_sha256": whole,
             "chunk_sha256": digest(part),
             "data": part}
            for i, part in enumerate(parts)]


def reassemble(chunks: list[dict], max_chunks: int = 10000) -> str:
    """Reassemble only a complete, consistent, hash-valid chunk set."""
    if not isinstance(chunks, list) or not chunks:
        raise ProtocolError("empty, invalid, or oversized chunk set")
    if isinstance(max_chunks, bool) or not isinstance(max_chunks, int):
        raise ProtocolError("max_chunks must be an integer")
    if len(chunks) > max_chunks:
        raise ProtocolError("oversized chunk set")
    if any(not isinstance(c, dict) for c in chunks):
        raise ProtocolError("each chunk must be an object")
    if any(c.get("transfer_protocol") != CHUNK_PROTOCOL for c in chunks):
        raise ProtocolError("unsupported chunk protocol")
    try:
        tids = {c["transfer_id"] for c in chunks}
        counts = {c["count"] for c in chunks}
        wholes = {c["full_text_sha256"] for c in chunks}
    except KeyError as exc:
        raise ProtocolError(f"chunk missing required field: {exc}") from exc
    except TypeError as exc:
        raise ProtocolError(
            f"chunk field unhashable or of wrong type: {exc}") from exc
    if len(tids) != 1 or len(counts) != 1 or len(wholes) != 1:
        raise ProtocolError("mixed transfers")
    transfer_id = next(iter(tids))
    _req_uuid(transfer_id, "transfer_id")
    _req_sha(next(iter(wholes)), "full_text_sha256")
    count = next(iter(counts))
    if isinstance(count, bool) or not isinstance(count, int) \
            or count != len(chunks):
        raise ProtocolError("missing or duplicate chunks")
    by_index: dict[int, str] = {}
    for c in chunks:
        i = c.get("index")
        if isinstance(i, bool) or not isinstance(i, int) \
                or not 0 <= i < count or i in by_index:
            raise ProtocolError("invalid or duplicate chunk index")
        data = c.get("data")
        if not isinstance(data, str):
            raise ProtocolError(f"chunk {i} data must be text")
        _req_sha(c.get("chunk_sha256"), f"chunk {i} hash")
        if digest(data) != c["chunk_sha256"]:
            raise ProtocolError(f"chunk {i} hash mismatch")
        by_index[i] = data
    if set(by_index) != set(range(count)):
        raise ProtocolError("chunk gap")
    text = "".join(by_index[i] for i in range(count))
    if digest(text) != next(iter(wholes)):
        raise ProtocolError("full-text hash mismatch")
    return text


# ---------------------------------------------------------------------------
# Engine (externalized canon via constructor)
# ---------------------------------------------------------------------------

class Engine:
    """Unified ESP v2.2 engine. The canon (banned terms, markers, axiom
    universe, module policy) is injected via Policy at construction."""

    def __init__(self, policy: Policy | None = None, **canon_overrides):
        if policy is None:
            policy = Policy(**canon_overrides) if canon_overrides else None
            if policy is None:
                raise ValueError(
                    "an explicit Policy is required; use "
                    "Policy(demo_registry=True) for the declared demo "
                    "registry, Policy(insecure_demo_registry=True) for the "
                    "zero-hash placeholder, or configure a real registry")
        self.policy = policy

    def make_message(self, **kwargs) -> dict:
        return make_message(policy=self.policy, **kwargs)

    def validate(self, message) -> dict:
        return validate_message(message, self.policy)

    @staticmethod
    def receipt(agent: str, payload_hash: str, result: str,
                notes: str = "") -> dict:
        return emit_audit_receipt(agent, payload_hash, result, notes)

    def migrate_v1(self, v1msg: dict) -> dict:
        return migrate_v1_to_v2(v1msg)


# ---------------------------------------------------------------------------
# Minimal CLI
# ---------------------------------------------------------------------------

def _selftest() -> int:
    policy = Policy(axiom_set_hash=ZERO_HASH, insecure_demo_registry=True)
    engine = Engine(policy)
    msg = engine.make_message(
        sender="agent_A", target="agent_B", register="STAGE_P",
        badge="LEVEL_B", content="A conditional inherited claim.",
        lineage="inherited", inherited_from="Paper 10 theorem T-10",
        falsifiers=[{"id": "C1",
                     "statement": "Reject if the cited theorem is absent."}])
    result = engine.validate(msg)
    assert result["ok"] and result["checks"], result
    tampered = json.loads(canonical(msg))
    tampered["payload"]["content"] += " altered"
    assert not engine.validate(tampered)["ok"]
    serialized = canonical(msg)
    assert reassemble(chunk_text(serialized, 300)) == serialized
    print("SELFTEST PASS")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="ESP v2.2 engine")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("selftest")
    args = parser.parse_args(argv)
    if args.command == "selftest":
        return _selftest()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
