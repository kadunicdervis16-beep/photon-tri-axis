# AAVEP v1.1 — Delta Specification

This document specifies what AAVEP v1.1 changes relative to the
frozen v1.0 specification (`AAVEP_SPEC.md`, which remains the base
specification and is not reissued). Section numbers here are this
document's own (§D1…§D10); design references are to
`DESIGN_PROPOSAL_v1.1.md`, whose §17.3 amendments govern where the
two differ. Claim cards AV2-01…AV2-04 quote this document.

**Standing: DEMONSTRATION** — before and after v1.1. The promotion
event (an external, unaffiliated, certified run) has not occurred.

## §D1. Calibration custody (CAL v2)

The calibration battery is re-issued as **AAVEP-CAL v2** under the
custody model specified in `cal/AAVEP_CAL_SPEC_v2.md`: a 256-bit
CSPRNG secret in the administrator tree only, HMAC-derived
fixtures, an opening commitment recorded before subject contact,
snapshot-verified scoring, allowlisted receipts, principal-keyed
administration grades, and post-close key publication.
Post-close key publication restores public re-scorability of a
receipt whose custody was private while the session was live.
<!-- claim: aavep_cal.cal.key-publication-rescore -->
Signatures are **not** part of v1.1: the commitment model is the
whole custody mechanism, and no placeholder in the kit implies a
signature layer exists. (Deferred to a v1.2 question by ruling.)

**Gate 0 tier rule (v1.1 delta, stated here because the base
text says otherwise).** A v1.1 run opens only on a receipt at
tier **PASS**. This supersedes the base specification's §4.1
("PASS or CONDITIONAL") and claim card AV-03's tier clause
**for v1.1 runs**: CONDITIONAL receipts remain gradable and
printable everywhere, but they do not open a v1.1 run. The
tightening is deliberate — Gate 0 is the protocol's admission
control, and v1.1 admits only fully passing calibration —
and the v1.1 demonstration's first administration records
exactly this refusal operating on CONDITIONAL receipts. (The
base text and the v1.0 card set are frozen v1.0 artifacts and
are not edited; this paragraph is their v1.1 supersession.)

## §D2. One derivation pipeline (derive_all)

Report build and report verify run the same pipeline. It derives
statuses from the event log under the shared expectation gate,
**recomputes the overall** (a recorded overall that disagrees is
a refusal-grade divergence), recomputes the lock table from the
real package, grades the genesis calibration receipts, applies
SL-2b witness verification, and checks the event log's head
against the head the runner recorded in the run's adjudication
ledger at close.
<!-- claim: aavep_report.report.derive-all-parity -->
Receipt grades print as RESCORED, COMMITMENT-ONLY (with the
administration grade printed CLAIMED), LEGACY-CUSTODY, or
UNVERIFIED, with the reason. The top stamp (ENGINE-VALIDATED)
requires every derivation to pass, the ESP engine to validate
the envelope, and every genesis receipt to grade RESCORED or
COMMITMENT-ONLY with binding.
<!-- claim: aavep_report.report.receipt-grades -->
When the ledger that carries the event-log binding is itself
UNANCHORED, the integrity block prints
`event-log binding: UNANCHORED-BOUND`.
<!-- claim: aavep_report.report.eventlog-binding -->
A witness packet whose verbatim quote is its source's boilerplate
first line draws a WITNESS-TRIVIAL lint and needs a packet note.

## §D3. Ledger verdict vocabulary

The chain format and finding lifecycle are v1.0's, unchanged.
<!-- claim: aavep_ledger.ledger.lifecycle -->
The verdict is split: CHAIN-VALID / CHAIN-INVALID; GENESIS
GROUNDED (naming the pins used — externally supplied pins are
distinguished from bundle-internal ones) or GENESIS UNGROUNDED;
INVALID (GENESIS-MISMATCH) when presented artifacts contradict
the genesis. An anchor whose hash is identical to an in-tree
anchor is labelled UNVERIFIED-ROOT — hash identity decides, not
the anchor's path.
<!-- claim: aavep_ledger.ledger.unverified-root -->
Every verdict prints the residue: a valid chain proves the
recorded history was not rewritten after the fact, given an
externally checked head; it does not prove the history happened.

## §D4. Runner confinement

- **Manifest path validation**: argv paths must sit inside the
  instrument's declared reach (default `{package, workspace,
  store}`); violations are MANIFEST-UNSAFE at preflight, and the
  runner re-resolves at execution (ESCAPE-REFUSED).
- **Store-placed bytes**: the bytes executed for every pinned
  instrument and declared module are placed from the
  content-addressed store into the scratch tree, hash-verified
  at placement, and re-verified immediately before execution;
  divergence at either check refuses the instrument. Execution
  itself is from the scratch copy — files an instrument reads
  from scratch beyond its placed set are write-set-recorded,
  not hash-gated (the declared limit of the portable
  mechanism).
  <!-- claim: aavep_run.run.store-executed-bytes -->
- **Write-sets and consumes**: the scratch tree is hashed before
  and after each instrument; the delta is the instrument's
  write-set and is recorded. An instrument that reads a file an
  earlier instrument wrote, without declaring that instrument in
  `consumes`, is capped at PASSED-DEGRADED
  (DEPENDENCY-UNDECLARED). Symlink creations are LINK-WRITE
  events; out-of-reach links are removed before the next
  instrument runs.
  <!-- claim: aavep_run.run.writesets-consumes -->
- **Process groups and the survivor census**: instruments run in
  their own process groups; timeouts kill the group (TERM, grace,
  KILL). At every instrument close and at run close the runner
  sweeps the process census for survivors — by descent or by
  workspace handles — kills them, and records SURVIVOR events;
  RUN_CLOSE prints the residual process list.
  <!-- claim: aavep_run.run.survivor-sweep -->
- **Environment**: HOME and TMPDIR are runner-owned directories,
  never the operator's; the allowlist is (PATH, LANG, LC_ALL, TZ,
  TMPDIR) plus manifest-declared `env_passthrough` entries, which
  print in RUN_OPEN and in the report.
- **Output**: streams are captured to spill files through a
  hasher that never stops; the event record always carries the
  full-stream sha256, the byte count, and the truncation state.
  A per-attempt ceiling (default 64 MiB) bounds what is *kept*,
  never what is *hashed*.
  <!-- claim: aavep_run.run.output-capture -->
- **Quotas and limits**: the effective extraction cap is
  min(4 GiB, free space × 0.5), probed at preflight and before
  Stage D; a declared `workspace_quota_bytes` binds tighter.
  QUOTA-EXCEEDED is a recorded state, never a crash. RLIMIT_FSIZE
  and RLIMIT_CPU are mandatory; RLIMIT_AS is off by default and
  the reason prints.
- **Confinement level**: the runner attempts the platform's OS
  facilities and prints the achieved level — portable floor or
  the named facility — in RUN_OPEN and every status record
  (attempt-and-print). The portable floor confines declared
  interfaces mechanically. A level confines only what its name
  names: the `os-sandbox: network-namespace` level confines the
  network and nothing else — filesystem reach at that level
  remains governed by the declared interfaces, the HOME/TMPDIR
  redirection, and the write-set record, and no sentence in
  this kit claims mechanical filesystem confinement for it.
  Mechanical filesystem confinement is claimed only where a
  facility that actually confines the filesystem is the
  achieved and printed level. Hard rule: a run refuses to open
  if a CAL administrator tree is found inside the run
  workspace.

## §D5. The degraded rungs

PASSED-DEGRADED (per instrument) and COMPLETE-DEGRADED (overall)
are computed states on the ladder. The protocol-default marker
set (partial-result vocabulary: UNCHECKABLE, NOT RUN, PARTIAL,
…) applies to every instrument and cannot be undeclared by a
manifest. An unmet non-advisory expectation fails the attempt
(EXPECTATION-UNMET); an unmet advisory expectation, an observed
partial marker, an undeclared dependency, an undeclared import,
or a truncated check caps at PASSED-DEGRADED, and the status
record names which degradations fired. Majority rule: if more
than half of the executed required instruments are
PASSED-DEGRADED, the overall is INCOMPLETE — a run that is
mostly degraded is not complete-with-asterisks.

## §D6. Manifest and package custody

Byte-compilation caches are **unmanifestable**: manifest
generation excludes `__pycache__/`, `*.pyc`, `*.pyo` and declared
exclusions; a manifested cache path is a *manifest defect*
charged to the manifest's author, never target tampering.
Author-declared exclusions are type-bounded: a pattern whose
literal core is not cache-shaped is itself a defect, no exclusion
may cover an instrument, a declared source, a card, a fixture, or
registry data, and the effective exclusion list prints in the
report header. A documented run is an enforced run: the runner
refuses to open unless the kit manifest and the package manifest
both verify.

**Kit manifest coverage (v1.1 rule).** `AAVEP_MANIFEST.sha256`
covers every file in the kit except: itself, `ANCHOR.txt`, the
`AAVEP_FREEZE*` records, everything under `demo/evidence/` (the
demonstration bundles carry their own integrity: ledger chains,
lock tables, and per-file records inside each bundle), and
cache paths as above. Receivers verifying a kit should know
the exclusion is deliberate and stated here, not an oversight:
the manifest pins the machinery; the evidence pins itself.

## §D7. Crucible adapter: content-bound FULL

FULL requires the adapter to hash a *presented tree* equal to the
freeze record's tree_hash, and presented submission / adjudica-
tion / charter *files* whose hashes the freeze record declares
(self-hash fields are corroboration, not evidence). Anchor
evidence must be a content-bound record naming the exact head or
tree hash it anchors; a bare string anchor is UNANCHORED and caps
at PARTIAL. The FULL line always carries the anchor status
inline, e.g. `FULL · anchor UNVERIFIED-EXTERNAL` — the adapter
does not resolve anchors (no-network invariant), and
UNVERIFIED-EXTERNAL is the strongest anchor label it can print.
<!-- claim: crucible_adapter.adapter.full-content-bound -->

## §D8. External-source instruments

External content reaches an instrument only through the store:
preflight copies it, the lock pins it, execution reads the store
copy. A run-time resolution against the ambient environment (a
`$HOME`-relative locator evaluated at execution) is non-
conforming by construction and is flagged at preflight. Each
instrument that takes an ambient default declares
`default_target`, which preflight checks like a dependency.

## §D9. Demonstration shipping standard

A shipped demonstration carries: the complete bundles (event log,
lock table, statuses, ledger, published-form receipts), the
expected and actual outcomes, and the workspaces whole — or,
where a workspace duplicates a hash-pinned delivered artifact,
the workspace's own bundle manifest with the substitution stated
in the record. A selftest case runs report verify over a shipped
bundle and asserts the verdicts match the record.

**Kit-pin coupling, stated plainly.** A bundle's report grounds
on the kit manifest hash of the kit that produced it. Any later
change to the kit — however legitimate — changes that hash, and
the bundle's report then verifies only under the kit it was
recorded against. Demonstration reports are therefore built on
the final, frozen kit tree, and a receiver who modifies the kit
should expect shipped bundles to refuse rather than silently
re-ground.

## §D10. Frozen, migration, self-status

Frozen from v1.0: the trap classes and scoring semantics; SOURCE-
LOCK; the reproduction gate; the ledger chain format; the ladder
states and transitions that v1.0 defined; the vendored ESP v2.4
engine and honesty plugin (byte-identical under their own
freezes); the GS-4 specification; the extraction refusal classes;
the completeness gate; governance. Schema changes in v1.1 are
additive-optional only. v1.0 manifest instances remain valid
v1.1 input; the behaviours they inherit print as preflight
notices. v1.0 ledgers verify under v1.1 tooling with
LEGACY-CUSTODY receipt grades and UNVERIFIED-ROOT anchor labels
where the shipped material supports no stronger statement; the
v1.0 demonstration's findings (including F-DEMO-1) stand exactly
as recorded and are never re-adjudicated by v1.1 machinery.
