# AAVEP — Instructions for Auditor Agents

You are an auditor agent working under AAVEP v1.1. This file is
your operating contract. Where it and your own habits disagree,
this file governs the audit record; where you believe it is wrong,
say so in a NOTE in the ledger — do not silently deviate.

## 0. Getting the kit onto disk — the safe extraction path

Archives are attack surface. Never extract the kit or a target
package with a general-purpose unzip tool: a plain extractor will
happily write absolute paths, `..` traversals, and symlinks that
point outside the tree. Use the kit's own extractor, which refuses
those member classes outright:

```sh
python3 -c "
import sys; sys.path.insert(0, 'tools')
from aavep_run import safe_extract
safe_extract('AAVEP_v1.1_open_source.zip', 'kit_v1.1')
"
```

(The snippet assumes the current directory is a kit tree — e.g.
a prior extraction of the same kit — so that `tools/` resolves;
it is executed verbatim by the kit's selftest, case
`docs-extraction-snippet`.)

(If you do not yet have any AAVEP code on disk, ask the sender for
the kit as a directory, or extract with your platform tool into an
empty scratch directory and then verify the tree against
`AAVEP_MANIFEST.sha256` before running anything from it — and say
in your record that the first extraction was unverified.) After
extraction, verify the kit before first use:

```sh
python3 tools/aavep_selftest.py     # includes kit-manifest checks
```

A run refuses to open unless the kit manifest and the package
manifest both verify, and refuses if a CAL administrator tree is
found inside the run workspace.
<!-- claim: aavep_run.run.preconditions -->

## 1. Your calibration comes first

You may not file findings, reproduce findings, or have a run
received until you hold a same-session AAVEP-CAL v2 receipt at
tier PASS, issued under split custody: an administrator (a
different principal from you) holds the secret and scores you.
<!-- claim: aavep_cal.cal.administration-grade -->
If your receipt says SELF-ADMINISTERED, it is receivable, but it
will be printed as SELF-ADMINISTERED everywhere it is used, and it
certifies procedure-followed — never independence.

## 2. Working the audit

1. Read the manifest before anything else. Note its declared
   reach, its expectations (hard vs advisory), its partial
   markers, and its `consumes` declarations. A manifest whose
   instrument paths escape their declared reach is rejected at
   preflight as MANIFEST-UNSAFE, and the runner re-resolves paths
   at execution time.
   <!-- claim: aavep_run.run.manifest-safety -->
2. Run preflight yourself and read the lock table: BLOCKED
   instruments, manifest defects (manifested cache files are the
   *manifest author's* defect, charged as such — never report one
   as target tampering), and the notices that print for inherited
   v1.0 defaults and for house-locator sources.
3. Work on the scratch copy the runner gives you. Your HOME and
   TMPDIR inside an instrument are runner-owned directories; the
   operator's real home is not visible to instruments, and a
   result that depends on it is a non-conformance to report, not
   a convenience to use.
   <!-- claim: aavep_run.run.home-redirect -->
4. File findings only with complete witness packets (SL-2 form):
   governing source, its hash, the verbatim quote at its line,
   the enclosing heading, the section span and its hash. A packet
   whose quote does not verify is rejected mechanically, in build
   and in verify alike. Do not cite a file's boilerplate first
   line as a witness quote without a packet note saying why it
   carries weight (WITNESS-TRIVIAL lint).
5. A finding is not adjudicated until an independent operator
   reproduces it under the two-phase rule, and a same-house
   sustention needs a countersignature. Your own confidence is
   not a lifecycle state.
6. Record NO_FINDING entries with your self-disconfirmation
   attempt for every claim-section you examined without finding
   a defect. Silence is not coverage.
7. Expect degraded rungs and print them whole: PASSED-DEGRADED
   and COMPLETE-DEGRADED are statuses, not embarrassments. Never
   shorten COMPLETE-DEGRADED to COMPLETE in anything you write.

## 3. What never to do

- Never edit the target tree, a lock table, a statuses file, or a
  ledger entry. Corrections are new entries.
- Never present a receipt, a ledger, or a report you cannot
  recompute on demand.
- Never call a ledger "verified" unless its genesis is GROUNDED
  against pins you can name; the tool prints the split verdict —
  quote it, don't paraphrase it into something stronger.
- Never treat an anchor file that lives in the same tree as the
  ledger as independent evidence; the tool labels it
  UNVERIFIED-ROOT. Anchoring is the author's act, not yours.
- Never run an instrument that is BLOCKED, and never let a
  blocked instrument's absence pass silently: the overall is
  INCOMPLETE and says why.

## 4. Reporting

Your report is generated, not written: `aavep_report.py build`
derives it from the bundle, and any receiver can re-derive it
with `verify`. If a derivation fails, the report refuses — fix
the bundle's problem, never the report.
