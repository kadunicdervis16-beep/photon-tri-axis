THE CRUCIBLE -- INSTRUMENT KIT
Version: Crucible v1.1 (kit accompanying the GS-4 Gold v1.0 design)
Release: open, by its author, for anyone's use (see README.txt and
CREDITS.txt in the release root).

WHAT THIS KIT IS
The v1.0 release published the Crucible's design (GS4_GOLD_SPEC.md), a
plain-language README, the first run's full trial report as a worked
example, and its credits. That is a description plus an example. This
kit is the addition GPT-6's closing advice called for -- the part that
makes the Crucible a reusable verification INSTRUMENT: everything a
researcher who has never seen the originating work needs to take the
specification, run the benches on their own paper, inspect the
evidence, and reproduce the adjudication. (The principle is quoted in
full in REPRODUCIBILITY.txt.)

CONTENTS
  QUICKSTART.txt        the stranger's path, step by step, in order:
                        prepare, freeze, sample, blind packet, briefs,
                        examine, seal, mutate, adjudicate blind,
                        unblind and report, publish everything.
  REPRODUCIBILITY.txt   how the first run's adjudication reproduces
                        from its published record (artifact -> step ->
                        what to check), the reproduction procedure, and
                        the record layout a new run must keep.
  templates/            blank artifacts generalized from the first run:
                        the four role charters, the hostile overlay,
                        the freeze record (with the v1.1 environment
                        block), the submission, the finding card, the
                        adjudication, the charter-integrity audit, the
                        registry input shape, and the protocol notes.
  tools/                four working scripts, python3 standard library
                        only, every path an argument, no constants from
                        any paper:
                        - sample_selection.py: the deterministic
                          claim sample (quotas, centrality, audit
                          trail) over a TSV registry.
                        - blind_packet.py: strips status material and
                          refuses to release a packet whose
                          verification scan is not zero.
                        - seal.py: write-once sealing and verification
                          of a submissions tree.
                        - mutation_log.py: mutation pre-registration
                          with mechanically enforced ordering
                          (expectations seal before observations
                          exist) and per-half witness files.
                        Each tool has --help and a --selftest that runs
                        clean on toy inputs.

v1.1 REFINEMENTS FOLDED IN (over the first run's practice)
- Per-half mutation witness FILES (structural separation, not
  attestation) -- templates/PROTOCOL_NOTES.txt note 2, mutation_log.py
  --half.
- The continuation-agent rule, formalized -- PROTOCOL_NOTES note 1.
- The environment freeze in the freeze record -- templates/
  FREEZE_RECORD.md section 3, and Role D's environment record.
- The anonymization style caveat stated where adjudicators will see
  it -- PROTOCOL_NOTES note 4.

WHAT DID NOT GENERALIZE (named, per the release's own discipline)
- The first run's packaging scripts that parse a specific paper's
  internals (its registry tables, its script manifest, its listing
  format -- select_sample.py / make_blind.py / make_cards.py /
  build_briefs.py / assemble_data.py in the trial record) are
  paper-shaped by nature. The kit generalizes their FUNCTIONS
  (sampling over a declared TSV; stripping + zero-scan; card format as
  a template) but a new user must still connect the sampler to their
  own registry -- that connection is the TSV, and filling it honestly
  is the user's work, not a script's.
- Card extraction and report assembly remain coordinator work guided
  by templates; no tool in this kit pretends to anonymize prose
  automatically, because argument-text fidelity is checked by diffing,
  and the diff needs a human (or agent) who answers for it.

HONESTY LABELS (unchanged from v1.0)
An independent-context trial, not independent human review unless the
examiners are. It awards no badge by itself and validates no physics.
Publish everything: failures, defences, inconclusive attacks,
disagreements, code, logs, versions, corrections.
