# AAVEP — Changelog

## v1.1 (2026-11-12) — custody, parity, confinement

Built to `DESIGN_PROPOSAL_v1.1.md`; its §17.3 amendments (B-1…
B-38) govern. Every change below answers a witnessed v1.0 defect
from the internal tests (three-persona review; developer-lens
probes P1–P8, executed). Standing remains DEMONSTRATION.

- **CAL v2 custody (design §2).** Two-tree sessions; 256-bit
  CSPRNG secret (the `--seed` interface is abolished); fixtures
  and key HMAC-derived with domain separation; opening commitment
  binds fixture hashes, identities, battery version, the secret
  commitment, and the administrator-tree manifest hash, recorded
  before subject release; scoring snapshots fixtures into the
  administrator tree and hashes them before scoring (B-25);
  receipts are schema-allowlisted (no secret, seed, responses, or
  fixture hashes); administration_grade computed from principals;
  post-close per-trap key publication restores public re-scoring
  (B-19); receipt grades RESCORED / COMMITMENT-ONLY / UNVERIFIED.
  The v1 trap classes and scoring semantics are unchanged; the
  v1 battery stays frozen with v1.0 and v1 sessions re-score
  under LEGACY-CUSTODY grading.
- **Report parity (design §3).** One `derive_all` pipeline for
  build and verify: statuses from events, overall recomputed
  (hand-flips refuse as OVERALL DIVERGENCE), lock table
  recomputed from the real package, genesis receipts graded,
  SL-2b applied in verify, event-log head checked against the
  runner's close-time ledger note (B-26), WITNESS-TRIVIAL lint
  (F8). The word "verified" is never applied to an UNGROUNDED
  ledger by the generator.
- **Ledger verdict split (design §4).** CHAIN-VALID · GENESIS
  GROUNDED / GROUNDED (bundle-internal pins only) / UNGROUNDED /
  INVALID (GENESIS-MISMATCH); `--expect-head`, `--expect-kit`,
  `--expect-manifest` pins; `--strict`; UNVERIFIED-ROOT decided
  by hash identity with the in-tree anchor (B-28); receipt grades
  printed per genesis receipt; the §4.4 residue prints in every
  verdict. Chain format unchanged.
- **Runner confinement (design §5).** Manifest `reach`
  validation (MANIFEST-UNSAFE) + execution-time re-resolution
  (ESCAPE-REFUSED); store-executed bytes for instruments and
  declared `modules`, with isolated import configuration and
  IMPORTS-UNDECLARED capping (B-30); per-instrument write-sets
  and `consumes` enforcement (DEPENDENCY-UNDECLARED); process
  groups with a census survivor sweep at every instrument close
  and run close (B-31); HOME/TMPDIR redirected to runner-owned
  directories and HOME removed from the environment allowlist
  (B-7); streamed output capture with full-stream hashes and a
  kept-bytes ceiling (B-6); environment-aware quotas and
  mandatory RLIMIT_CPU/FSIZE (§5.7); confinement level attempted
  and printed in RUN_OPEN and every status record (attempt-and-
  print, ruling 5). Portable-floor scope honestly narrowed
  (B-29): declared interfaces are confined mechanically; arbitrary
  code's filesystem reach is mechanical only at OS-sandbox level.
- **Ladder (design §6).** PASSED-DEGRADED and COMPLETE-DEGRADED
  computed states; protocol-default marker set that cannot be
  undeclared; expectations gate (named deviation B-3: an unmet
  *advisory* expectation caps at PASSED-DEGRADED rather than
  UNRESOLVED, because UNRESOLVED would cap the whole audit
  INCOMPLETE and invert the advisory declaration's meaning);
  majority rule (>½ executed required instruments degraded ⇒
  INCOMPLETE); `overall_status` differential property case in
  the selftest (B-33).
- **Manifest custody (design §7).** Caches unmanifestable;
  manifested cache paths are manifest defects charged to the
  manifest's author; author exclusions type-bounded (B-38) and
  printed in the report header; import-then-verify selftest
  case; the runner refuses to open unless the kit manifest and
  the package manifest both verify. (B-1 correction recorded:
  v1.0's preflight *already* enforced the package-manifest pin;
  the real D4 gap was the absence of any pin for the target's
  package-manifest hash in a governed artifact — a paper-side
  item, carried by the protocol requirement, not by this kit.)
- **Crucible adapter (design §8).** FULL is content-bound:
  presented tree hashed by the adapter and required equal to the
  freeze record's tree_hash; submissions/adjudication/charter
  hashed as files; anchor evidence content-bound, printed inline
  (`FULL · anchor UNVERIFIED-EXTERNAL`); no tree ⇒ PARTIAL +
  TREE-NOT-PRESENTED (B-35).
- **Documentation conformance (design §11).** New tool
  `aavep_docs.py`: behaviour keys are issued from the selftest
  case registry, normative claims carry markers, safety-class
  claims on unpinned keys fail, orphan safety keys fail,
  procedure sequences are order-checked, RECORD-class documents
  cite bundle paths that must exist (B-8).
- **Demonstration (design §10).** Predictions lodged before runs;
  split-custody CAL v2 administration in fact (administrator and
  operators are different agents; the administrator tree never
  sits inside a run workspace) (B-16); both targets — a synthetic
  fixture package with scriptable negative cases, and Paper 12.5
  v10 (scratch copy; the delivered tree is read-only); shipping
  standard with whole bundles and a selftest case that
  re-verifies the shipped synthetic bundle; cost accounting
  against v1.0 (B-36).
- **Housekeeping.** `AGENT_INSTRUCTIONS.md` now prescribes the
  kit's own safe extraction path (plain `unzip` on an untrusted
  archive is the P4 exposure). The v1.0 report generator's
  target-domain lexical guard (a Paper-12.5-specific word list)
  is **not** carried into v1.1: it was application content inside
  a protocol tool, and no v1.1 mechanism depends on it.
  `aavep_index_export.py` is unchanged; `aavep_completeness.py`
  was changed — see the completeness-gate addendum below (an
  earlier draft of this bullet claimed both unchanged; the
  loop pass corrected it). Claim cards AV2-01…AV2-04 added;
  AV-01…AV-08 stand.

# AAVEP — Changelog

## v1.0 (2026-11-11) — first frozen version

Built in one session from the design record (DESIGN_PROPOSAL v0.1,
retained in the author's build archive) under the author's five
rulings of 2026-11-11: MIT license; the name AAVEP; freeze + anchor at
creation, no external publication; battery governance (house
authorship, author-frozen versions, synthetic fixtures only, external
authorship an earned standing); and the gate binding everybody.

### Inheritance (24 design elements, as amended by the design loop)

- **INHERIT (7):** the ESP v2.4 engine (byte-identical, hash-verified
  against its package manifest); the honesty plugin v1.1.2
  (byte-identical, unmodified — its MIT settlement confirmed by the
  author as bookkeeping only); the Crucible GS-4 Gold kit; the ESP
  status/report discipline; the claim-card schema (FREEZE v1.1,
  14-field); the five-part disclosure + INPUT_PROVENANCE discipline
  (every kit script carries both); the adversarial loop method itself.
- **ADAPT (7):** the status model → §4.4's computed ladder with the
  full-vector rule; claim cards → AAVEP's own 8 normative claims
  (cards/aavep_claim_cards.json, validated 8/8 by the shipped plugin);
  the Crucible → the §8 adapter that computes states and cannot
  freeze; ESP reports → §7's bundle-recompute receivability; the
  plugin's provenance check → a demonstration instrument; the house
  manifest practice → the paper-agnostic schema of §3; the index
  practice → tools/aavep_index_export.py.
- **BUILD NEW (10):** N1 SOURCE-LOCK with site-binding locks; N2 the
  authority-transcription verification; N3 derivation-source
  LOCKED-BY-PIN; N4 the calibration battery AAVEP-CAL (six traps,
  tool-administered, seed-regenerated scoring); N5 the two-phase
  reproduction gate with phase-1 commitments; N6 the append-only
  hash-chained adjudication ledger with role-conflict voiding; N7 the
  completeness gate with correspondence/substantive coverage typing;
  N8 the fenced runner (scratch-only execution, timeout + 2× retry,
  network isolation where enforceable, canary); N9 the Crucible
  adapter's guard-staged state computation; N10 the kit self-test with
  planted mutants.

### The design loop (record)

50 charges against the design: 21 sustained, 27 sustained in part, 2
not sustained — producing amendments A-1…A-32, all folded into
AAVEP_SPEC.md. Two adjudication corrections from the incident record
are carried in the design: the governing-source error class includes
verdicts against a non-governing *site* within the right source, and
locators must be version-specific.

### The build loop

Three read-only agents over the near-final kit: devil's advocate (20
charges), red team (14 charges), evil auditor (5 charges executed of
9 angles before interruption — reported as partial, never dressed as
complete; the remaining angles were covered by the other two benches
and by new self-test checks). Charges were overwhelmingly SUSTAINED
and every one was repaired before the demonstration, including:
Gate 0 made unskippable with mandatory receipt re-scoring (a forged
receipt is refused, self-tested); calibration transcript hashes made
time-independent (receipt core excludes `scored_at`) and the session
key file removed; report statuses re-derived from the hash-chained
event log by the state machine, with pre-build tampering refused;
report identity fields moved into the ledger genesis (no caller
overrides); preflight problems made gates (exit 4, `valid: false`),
with the runner recomputing the lock table and refusing divergence,
dependency blocking propagated to a fixed point, instrument bytes
hash-locked; SL-2b witnesses restricted to declared sources or locked
package files; the Crucible adapter rebuilt to compute its five
states from C-3 evidence (an in-session freeze or a bench operator
caps the state at SIMULATED); the spec amended where the code's
conservatism was right (§4.4 overall rule, §1 "certified run" defined
in receipt vocabulary, FM-7/FM-8 residuals declared). Self-test after
repairs: 56/56. The demonstration then found four more defects —
relative-workspace argv double-resolution, lock-table path spelling,
sample-rerun event-log head, and two filing-shape gaps — each
repaired with a regression check; final self-test on the frozen tree:
see the freeze record.

### The demonstration

Full record: demo/DEMO_RECORD.md (evidence in demo/evidence/).
Summary — Setting S (stranger): predictions matched except two
shipped instruments (IDX1, H9) that depend on house paths a stranger
does not have; overall INCOMPLETE as predicted (H6/RB1 BLOCKED);
IDX1 provenance observation filed unadjudicated. Setting H (house):
every prediction matched, including H6's exact summary line; the one
failure (plugin-provenance) carried finding F-DEMO-1 through the full
gate — filed by h-filer, reproduced SAME-HOUSE by h-reproducer with
its phase-1 commitment hashed before unblinding, countersigned by
s-auditor, adjudicated **SUSTAINED**. D7b (blind one-token plant):
caught by H4/H10, not by the predicted H6 — deviation recorded; the
blind agent identified a B.1-centred content divergence from the
outputs alone. All three reports: ESP stamp ENGINE-VALIDATED,
anchoring UNANCHORED, envelopes recompute byte-identically, canary
not propagated, Crucible NOT RUN. All four demonstration operators
held PASS 6/6 AAVEP-CAL receipts (ruling 5). Chandler clause (a)
remains UNRESOLVED on the record.

### Known limitations at freeze

- Coverage typing in the demonstration manifest is coarse by
  declaration: four claims carry verified substantive coverage; the
  rest stand UNRESOLVED at substantive grade on the record, with
  correspondence coverage executed. Claim-by-claim substantive mapping
  is v1.1 manifest work.
- Setting S of the demonstration shares the host machine; its
  isolation is workspace + HOME redirection + offline preflight, with
  the residual disclosed in the demo record.
- The ESP engine validates against its demo placeholder registry
  under the CLI's own policy; ENGINE-VALIDATED means what the report
  prints, no more.
- AAVEP's standing at freeze: DEMONSTRATION (see AAVEP_SPEC §1 and
  card AV-06).

## v1.1 build addendum (2026-11-12, completion pass)

- **CAL v2 spec §1.1 added** — the T5 witness packet's canonical
  serialization (heading verbatim with markers; `section_sha256`
  = sha256 of the span's lines joined by "\n", no trailing
  newline) is now stated in the battery specification. In the
  first demonstration administration all four operators missed
  T5 on exactly these two unstated points and tiered
  CONDITIONAL; the adjudication and the repair are recorded in
  demo/DEMO_RECORD.md. The scorer's rule did not change — the
  document caught up with it.
- **Runner path-resolution repair (demonstration-found).** The
  v1.1 rewrite dropped v1.0's entry-point resolution of
  `--workspace`/`--package` to absolute paths; with a relative
  workspace, instrument argv double-resolved against the child
  cwd and every instrument failed on its own bytes. Restored in
  `aavep_run.py`, with regression case `run-relative-workspace`
  in the selftest. Found by the synthetic demonstration's first
  run (all three instruments FAILED on the doubled path); the
  defective run's record is preserved in the build work area and
  the deviation is written in demo/DEMO_RECORD.md.
- **Receipt-grading fallback (demonstration-found).**
  `verify_receipt` returned UNVERIFIED whenever the administrator
  re-score path errored — including the foreseeable published-form
  case of a redacted admin record (no secret) presented together
  with published keys. A completed divergent re-score remains
  decisive; an administrator path that cannot run now falls
  through to the published-keys grading. Regression case
  `cal2-redacted-admin-fallback`.
- **Lock-table path recording (demonstration-found).** Recorded
  lock entries now use workspace-relative paths inside the
  workspace, `package/<rel>` inside the target package, and
  absolute paths only for genuinely external files;
  `compute_lock_table` resolves its inputs at entry. A shipped
  bundle's lock table therefore recomputes identically from any
  tree location. (Scoped by the loop pass: the sentence is about
  the lock table. The first shipped synthetic bundle also
  carried an absolute build-machine source locator in its
  manifest, which bound the bundle as a whole to its birthplace;
  the demonstration was re-run with a `{kit}`-relative locator
  and the selftest gained a relocated-bundle verify case,
  `demo-bundle-relocated`.) Regression case
  `report-relative-paths`.
- **Completeness gate statuses (demonstration-found).** The gate
  read v1.0's flat statuses shape and counted no instrument as
  executed on a v1.1 run; it now accepts both shapes, and
  PASSED-DEGRADED counts as executed coverage. Regression case
  `completeness-degraded-executed`.

Build addendum 2 — loop pass (red team bench; charges adjudicated
with evidence by the build coordinator, repairs re-verified):

- score_session_v2 now enumerates the subject tree: a file
  outside the issued fixture set and the two session artifacts
  invalidates the session (section 2.4's extra-file clause,
  previously unimplemented — the red team's planted extra file
  scored PASS). The demonstration's eight subject trees were
  re-enumerated under the repaired rule: no extra files; the
  issued receipts stand. [cal2-extra-file-invalid]
- aavep_ledger verify2: COMMITMENT-ONLY now requires the
  receipt core to recompute and the commitment to appear in a
  record independent of the receipt itself (the genesis is
  searched without its calibration_receipts). The red team's
  ghost receipt (fabricated transcript hash) previously graded
  COMMITMENT-ONLY on this path. [ledger-ghost-receipt-unverified]
- redact_check exempts a published keys file (publish_keys'
  exact document shape): its top-level 'key' field is the
  sanctioned publication, not a leak. The checker previously
  failed the kit's own demonstration trees. [cal2-redact-keys-exempt]
- Key publication now upgrades the published receipt:
  publish-keys --receipt/--receipt-out re-issues it with
  key_disclosure: published (mark_keys_published). The field
  sits outside the transcript core hash, so no grade changes.
  The demonstration's published receipts were re-issued under
  the repaired constructor; all re-grade RESCORED.
  [cal2-key-disclosure-upgrade]
- Probes the bench left unexecuted were executed by the
  coordinator on the final tree: a forged calibration pair is
  refused when its core does not recompute, and grades
  COMMITMENT-ONLY with the grade printed CLAIMED when it does
  (the section 3.5 / B-23 leg-iii residual, by design); the
  planter-to-checker probe records the planter's write-set in
  the event log, and an argv-referenced plant draws
  DEPENDENCY-UNDECLARED (a read inside instrument code remains
  the section 5.2 declared limit).
- Attempt lineage (devil's advocate): official scorings now
  persist in the administrator record, and the tier rule's
  re-run cap (a PASS on a re-run after a FAIL caps at
  CONDITIONAL) reads that lineage — the attempt was previously
  hardcoded to 1 and the cap could never fire. Re-scores
  reproduce the original attempt context and persist nothing.
  [cal2-reattempt-cap]
- Fallback boundary (devil's advocate, on demonstration repair
  2): the published-keys path now hash-checks the presented
  fixture bytes against the administrator record whenever one
  is presented, and a keys-path agreement reached after a
  presented-but-unrunnable administrator path with no fixture
  anchor caps at COMMITMENT-ONLY, with the cap printed. A
  tampered fixture under a redacted record grades UNVERIFIED.
  [cal2-fallback-fixture-anchor]
- Execution bytes (devil's advocate): module placements are
  hash-verified like entries, and placed bytes are re-verified
  immediately before execution; section D4's prose is narrowed
  to the implemented store-placed form, and the confinement
  paragraph now states that the network-namespace level
  confines the network only.
- The B-33 differential now enumerates its promised domain
  (sizes 1–4 × 8 states, plus a degraded-flag invariance
  sweep); the first build enumerated sizes 1–3 × 7 states.
- AGENT_INSTRUCTIONS section 0's extraction snippet pointed at
  a `bootstrap/` path that exists nowhere in the kit; it now
  names `tools/`, and the selftest executes the snippet
  verbatim. [docs-extraction-snippet]
- Report and runner output now print the FAILED-instrument
  count beside the overall (devil's advocate: completion
  vocabulary must not launder a defective target).
- Preflight resolves the `{kit}` placeholder in source
  locators (it validated the placeholder but never substituted
  it, so a `{kit}`-relative source locked ABSENT). Found by
  the synthetic demonstration's frozen-kit re-run, which the
  loop pass required after the second bundle proved
  location-dependent; the demonstration bundle now ships from
  a `{kit}`-relative locator and verifies from a relocated
  copy of the kit. [preflight-kit-locator,
  demo-bundle-relocated]
