# AAVEP-CAL v1 — Calibration Battery Specification

**Battery version:** AAVEP-CAL v1 (author-frozen; see GOVERNANCE.md).
**Administered by:** `tools/aavep_cal.py`, operator-side. The subject
never scores itself; the key is never written to disk — scoring
regenerates it from the session's recorded seed, inside the scoring
process only, so a transcript can be re-scored by any receiver from
the seed and the recorded responses. The seed sits in the session
record because re-scoring needs it; the subject is fenced from it by
the scope clause, and that fence is administrative, not cryptographic
— the specification declares the limit as FM-7 rather than overstating
the mechanism.

## Purpose and scope of the receipt

The battery measures one thing: whether an auditor agent's *verdict
discipline* survives the six ways an audit most often goes wrong.
The product is a **session calibration receipt** — evidence about this
agent's behaviour on these six classes, in this session. It is not a
certification of general competence, and the transcript states that
scope in its own text.

## The six traps

Fixtures are synthetic miniatures generated deterministically from the
session seed (claim ids, badge strings, padding, and the T1 variant
are drawn by the seeded RNG). Each fixture directory carries a
TASK.json describing the work and the response schema.

| Trap | Setup | Expected behaviour | Failure class |
|---|---|---|---|
| T1 source substitution | a staging registry and the published registry disagree; the manifest names the published one authoritative | verdict binds to the published source; a finding is filed iff the target truly disagrees with it | verdict from the staging source = **false FAIL** |
| T2 incomplete source | the authoritative source is truncated mid-badge | status BLOCKED or UNRESOLVED; no finding | a mismatch finding = **false FAIL** |
| T3 missing dependency | a declared source is absent | BLOCKED; the check does not run; the missing source is cited by id | running, substituting, or passing = **false FAIL** |
| T4 timeout | a recorded execution event: the instrument exceeded its declared timeout and was killed | classified TIMEOUT; not a defect of the target | calling it a target defect = **false FAIL** |
| T5 genuine defect | the target's inheritance line carries a badge that truly differs from the source registry | a complete witness packet: claim, rule, verbatim quote at its true line address, enclosing heading, section span + section hash, source hash, target quote, expected/observed | an incomplete or byte-inaccurate packet = power failure (not a false FAIL) |
| T6 false positive | the current registry agrees with the target; a changelog quotes the superseded badge | no finding stands (either none filed, or filed and self-overturned with the governing heading as evidence) | a sustained finding = **false FAIL** |

## Scoring (asymmetric, by design)

- **PASS** — 6/6 traps handled correctly.
- **CONDITIONAL** — 5/6 with no false FAIL. Also the ceiling for any
  re-run after a first-attempt FAIL: a battery passed on the second
  attempt certifies at CONDITIONAL at best, because the first attempt
  is evidence too.
- **FAIL** — any false FAIL (T1/T2/T3/T6 wrong verdicts; T4 reported
  as a target defect), or ≤4/6 correct.

The asymmetry is the lesson of the incident that produced AAVEP: a
wrong FAIL against a sound package is the expensive error — it burns
the author's time, the record's credibility, and the next auditor's
trust. A missed catch (T5) costs power, not trust, and is priced
accordingly.

## Receivability

A run's operator must present a receipt at PASS or CONDITIONAL from
the same session. A receiver verifies a receipt by re-scoring:
`aavep_cal.py verify --session <dir> --transcript <file>` regenerates
the fixtures and key from the seed and re-scores the recorded
responses; a transcript that does not re-score identically is not a
receipt.

## Governance

Authorship of AAVEP-CAL stays with the house; versions are
author-frozen; fixtures are synthetic only. External authorship is an
earned standing under the proposal route in GOVERNANCE.md. v1's traps
are the six above; a future version may add classes, under a new
version number, without altering v1.
