# AAVEP-CAL v2 — Calibration Battery Specification (custody edition)

**Status:** frozen under AAVEP v1.1. The v1 battery stays frozen
with AAVEP v1.0; v2 is a new edition of the same battery. The six
trap classes and their scoring semantics are unchanged from v1
(they are listed in §1 for completeness). Everything v2 changes is
custody: who can know what, when, and what a receipt may carry.

## 1. The battery (unchanged from v1)

| Trap | Class | Passing behaviour |
|---|---|---|
| T1 | source substitution | verdict rests on the published (governing) registry, not the staging copy; a finding is filed exactly when the variant disagrees |
| T2 | truncated authoritative source | the check is BLOCKED or UNRESOLVED; no finding is manufactured from a source that cannot be read whole |
| T3 | missing declared dependency | status BLOCKED, the check does not run, and the un-lockable source_id is cited |
| T4 | event classification | a runner-timeout event is TIMEOUT, not a paper defect |
| T5 | genuine defect | the defect is affirmed and a witness packet is built that verifies byte-for-byte against the governing source (SL-2 form) |
| T6 | false alarm | no finding is sustained on a decontextualised quote (a superseded changelog entry); the governing site's heading is the evidence |

Tier rule (unchanged): any false FAIL, or ≤4 correct, is FAIL;
6/6 is PASS; 5/6 is CONDITIONAL; a PASS earned on a re-run after a
FAIL caps at CONDITIONAL.

### 1.1 The T5 witness packet — canonical serialization (SL-2)

A T5 packet verifies mechanically against the governing source's
bytes, under exactly these rules — no other serialization is
accepted:

- `enclosing_heading`: the heading line that opens the section
  containing the quoted line, **verbatim, including its markdown
  markers** (e.g. `## Appendix B. Claim registry`).
- `line_address`: the 1-based address of the registry row in the
  governing source; `verbatim_quote` is text appearing at that
  line (the full row, or a substring of it).
- `section_span`: `[first, last]` — the 1-based line addresses
  bounding the enclosing section; the span must cover
  `line_address`.
- `section_sha256`: the sha256 of the span's lines joined by a
  single `\n` (U+000A) **with no trailing newline**, UTF-8
  encoded — `sha256("\n".join(lines[first-1:last]))`. This is
  deliberately *not* the hash of any file: a span that covers a
  whole file still hashes without the file's final newline.
- `source_sha256`: the sha256 of the governing source file's
  bytes exactly as issued.

(Added during the v1.1 build, after the first demonstration
administration: four operators independently missed T5 on the
heading's markers and on this hash's serialization, neither of
which was stated in any battery document — the misses are
recorded in the demonstration record, and the rule is stated
here so the trap tests packet discipline, not telepathy.)

## 2. Custody model

A session involves two trees and two principals.

- The **administrator tree** holds the session secret: 256 bits
  from the system CSPRNG, generated at session creation. There is
  no integer seed anywhere in the v2 interface.
  <!-- claim: aavep_cal.cal.secret-custody -->
- The **subject tree** holds only the six fixture directories and
  `subject_open.json`. It never contains the secret, the key, or
  any derivative that would let a reader regenerate the key.
- **Fixtures and key are derived, not stored**: both are
  deterministic functions of the secret via HMAC-SHA256 with
  per-purpose domain separation. The administrator re-derives them
  at score time; the key exists only inside the scoring process.
- **Opening commitment before subject contact**: at creation, the
  administrator record binds the fixture hashes, both identities,
  the battery version, the secret commitment `sha256(secret)`,
  and the administrator-tree manifest hash into
  `session_commitment = sha256("AAVEP-CAL-OPEN" ‖ canonical(…))`,
  recorded in the administrator's opening record before the
  subject tree is released.
  <!-- claim: aavep_cal.cal.commitment-before-contact -->
- **Administration grade**: computed from the principals —
  `ADMINISTERED` when the administrator principal differs from the
  operator principal, `SELF-ADMINISTERED` when they are the same
  principal, whatever the role labels say.
  <!-- claim: aavep_cal.cal.administration-grade -->
  SELF-ADMINISTERED receipts are receivable (governance ruling:
  keep it receivable) and are printed with that grade everywhere;
  the grade certifies procedure-followed and carries **no
  independence content**.

## 3. Scoring discipline (B-25)

Scoring is administrator-side and hash-verified:

1. The subject's fixture files are **snapshotted into the
   administrator tree** and each file's hash is checked against
   the opening commitment *before* any response is scored.
2. Any divergence — tampered, replaced, appended, or missing
   fixture — fails the session with `FIXTURE-INTEGRITY-FAIL` and
   **no tier is issued**.
3. Scoring reads the snapshot, never the live subject tree.
4. After scoring, the subject tree is re-hashed; a mutation
   during scoring is recorded as `SUBJECT-TREE-MUTATED-DURING-
   SCORE` and likewise issues no tier.
<!-- claim: aavep_cal.cal.fixture-integrity-at-score -->

Measurements are not fixture content: where a trap involves a
measured quantity (T4's wall time), the fixture records the
declared parameters and the outcome class; the measurement itself
lives in the administrator's record. Content hashes therefore
recompute identically across administrations.

## 4. Receipts

A published receipt carries **only** the allowlisted fields:
battery, version, session_id, session_commitment, operator and
administrator ids and principals, administration_grade, tier,
per-trap outcomes (booleans), transcript_sha256 (over the receipt
core), responses_sha256, key_disclosure, and opening_record
(`ledgered` | `administrator-held`). No secret, seed, response
content, fixture hash, or key material ever appears in a receipt.
<!-- claim: aavep_cal.cal.receipt-allowlist -->
The kit fails its own publication checks if a receipt-shaped
document in a published tree carries a field outside the list
(redact-check).

Receipt grades at reception: **RESCORED** (a receiver re-scored
the responses from administrator custody or from published keys),
**COMMITMENT-ONLY** (the core recomputes and the commitment is
found in a record independent of the receipt; the administration
grade is then printed as CLAIMED), **UNVERIFIED** (anything else).
A bare receipt, however internally consistent, is UNVERIFIED —
consistency is not custody.

## 5. Key publication (B-19)

After a session closes, the administrator *may* publish the key
(`publish-keys`). Publication flips the receipt's key_disclosure
to `published` and upgrades any receiver's grade to RESCORED,
because the responses can then be re-scored publicly against the
public fixtures. Publication is the administrator's act and is
irreversible for that session; sessions whose keys are never
published remain COMMITMENT-ONLY at best for outside receivers.

## 6. Residuals (graded, not solved)

- **Administrator collusion**: a colluding administrator and
  operator can manufacture a genuine-looking ADMINISTERED
  receipt. The custody model makes forgery require the
  administrator; it cannot make collusion impossible. The defence
  is governance (who may administer) plus key publication.
- **Declared identity**: two named principals are two *strings*.
  That they are two minds is attested by the process that named
  them, not by this tool.
- **The v1 battery's custody is what it was**: v1 receipts remain
  gradable only as LEGACY-CUSTODY (see the v1.1 spec §D10); their
  seeds are, in the shipped v1.0 record, published — the label is
  permanent and travels with every citation of F-DEMO-1 and the
  other v1.0 demonstration outcomes.
