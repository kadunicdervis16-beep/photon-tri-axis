# AAVEP v1.1 — Agent-Agnostic Verification & Escalation Protocol

AAVEP makes an AI auditor's work on a verification package
*receivable*: the auditor calibrates against a trap battery before
its findings count, everything it consumes is hash-locked before it
runs, every status in its report is recomputed from a hash-chained
event log by the receiver, and its findings live in an append-only
ledger whose verdict vocabulary never prints an unqualified "valid".

**Standing: DEMONSTRATION.** AAVEP v1.1 is a working instrument
whose v1.1 mechanisms have been exercised by its own selftest and by
the house demonstration shipped in `demo/` — a demonstration that
found the kit defective in four places, which were repaired and
regression-cased before the shipped runs (see `CHANGELOG.md` and
`demo/DEMO_RECORD.md`). It has not been run by
an unaffiliated external operator; that event, and only that event,
promotes its standing. Nothing in this kit claims otherwise.

v1.1 is a delta on the frozen v1.0 (see `AAVEP_SPEC.md` for the base
specification and `AAVEP_SPEC_v1.1.md` for what changed and why).
The changes answer the v1.0 internal tests: a three-persona review
and an executed developer-lens probe battery (P1–P8) that forged a
calibration receipt from public material, tampered fixtures after
session issue, built a ghost ledger, flipped a report's overall
status, and escaped the v1.0 runner's confinement. Each v1.1
mechanism names the probe it answers.

## The five ideas

1. **Calibration before reception.** An operator's findings count
   only after it passes AAVEP-CAL in the same session. Under v2
   custody the battery's secret never leaves the administrator
   tree, and a receipt carries only allowlisted fields.
   <!-- claim: aavep_cal.cal.secret-custody -->
   <!-- claim: aavep_cal.cal.receipt-allowlist -->
2. **Lock before execution.** Preflight hashes every source,
   instrument, and module into a content-addressed store; a run
   whose inputs do not match the lock does not open.
3. **Gate 0.** A run refuses to open unless every operator's
   calibration receipt re-verifies in the runner itself.
   <!-- claim: aavep_run.run.gate0 -->
4. **Derive, never copy.** One pipeline derives statuses, the
   overall, the lock table, and the receipt grades — identically
   when the report is built and when a receiver verifies it. A
   hand-edited overall is a divergence, not an edit.
   <!-- claim: aavep_report.report.derive-all-parity -->
5. **Split verdicts.** The ledger prints CHAIN-VALID or
   CHAIN-INVALID, GENESIS GROUNDED or UNGROUNDED with the pins
   used, and a grade per receipt — never a bare "valid".
   <!-- claim: aavep_ledger.ledger.verdict-split -->

Two rungs are new in v1.1: an instrument that executes and meets
its hard contract but trips a partial marker, an advisory
expectation, or an undeclared dependency is **PASSED-DEGRADED**;
a run whose vector contains one is **COMPLETE-DEGRADED** (never
shortened to COMPLETE).
<!-- claim: aavep_run.run.expectation-gate -->

Every status record prints the confinement level the runner
actually achieved on this platform — the portable floor, or the OS
facility it managed to use.
<!-- claim: aavep_run.run.confinement-printed -->

## Quickstart

```sh
# 0. extract this kit with the kit's own safe extraction
#    (AGENT_INSTRUCTIONS.md gives the exact commands — plain
#    `unzip` on an untrusted archive is not the prescribed path)
# 1. verify the kit against its manifest and run the selftest
python3 tools/aavep_selftest.py
# 2. calibration (administrator and operator are distinct roles)
python3 tools/aavep_cal.py new --admin-dir <admin> \
    --subject-dir <subject> --operator <id> \
    --operator-principal <p1> --administrator <id> \
    --administrator-principal <p2>
#    ... the operator answers the six TASK.json files ...
python3 tools/aavep_cal.py score --admin-dir <admin> \
    --subject-dir <subject> --responses <subject>/responses.json \
    --transcript-out <t.json> --receipt-out <receipt.json>
# 3. preflight (lock table) -> ledger genesis -> run -> report
python3 tools/aavep_preflight.py --manifest <m.json> \
    --package <pkg> --workspace <ws> --out <ws>/locktable.json
python3 tools/aavep_run.py --manifest <m.json> --package <pkg> \
    --workspace <ws> --receipt <receipt.json> --ledger <led.jsonl>
python3 tools/aavep_report.py build --manifest <m.json> \
    --package <pkg> --workspace <ws> --ledger <led.jsonl>
python3 tools/aavep_report.py verify --manifest <m.json> \
    --package <pkg> --workspace <ws> --ledger <led.jsonl> \
    --record-out <record.json> --envelope-out <envelope.json>
```

<!-- sequence: aavep_run.run.gate0 < aavep_run.run.expectation-gate -->

## Layout

- `tools/` — the machinery: `aavep_cal.py` (CAL v2 custody),
  `aavep_preflight.py` (SOURCE-LOCK), `aavep_run.py` (confined
  execution), `aavep_ledger.py` (adjudication ledger),
  `aavep_report.py` (derive_all report + ESP envelope),
  `aavep_completeness.py`, `aavep_index_export.py`,
  `crucible_adapter.py`, `aavep_docs.py` (documentation
  conformance), `aavep_selftest.py`.
- `cal/AAVEP_CAL_SPEC_v2.md` — the CAL v2 custody specification.
  The v1 battery stays frozen with v1.0.
- `esp/` — the vendored ESP v2.4 engine (byte-identical under its
  own freeze), used to validate report envelopes.
- `plugin/` — the vendored honesty-audit plugin (byte-identical
  under its own freezes).
- `crucible/` — the GS-4 Gold Crucible specification and kit.
- `cards/` — the protocol's claim cards (AV-01…AV-08 carried from
  v1.0; AV2-01…AV2-04 are v1.1's). AV-03's tier clause is
  superseded for v1.1 runs by the Gate 0 delta in
  `AAVEP_SPEC_v1.1.md` §D1 (PASS only).
- `manifest/` — the manifest-instance JSON Schema, and
  `example_manifest.json`, a v1.0 instance retained as a migration
  fixture (v1.0 instances remain valid v1.1 input).
- `demo/` — the v1.1 demonstration: predictions lodged before the
  runs, both targets (a synthetic fixture package and Paper 12.5
  v10), whole workspaces, and the record.
- `legacy_fixtures/` — the v1.0 demonstration's Setting H ledger,
  retained so v1.1 tooling's LEGACY-CUSTODY grading is checkable.

## Documentation conformance

Normative claims in this kit's documents carry behaviour-key
markers, and `aavep_docs.py` checks them against the registry of
behaviours the selftest actually executes.
<!-- claim: aavep_docs.docs.claims-pinned -->

## License

MIT © Dervis Kadunic. See `LICENSE` and `GOVERNANCE.md` (which
carries the house rulings the kit is built under, including:
the gate binds everybody, and the calibration battery's authorship
stays with the house until an outside party meets or exceeds the
standard — the opportunity is always given).
