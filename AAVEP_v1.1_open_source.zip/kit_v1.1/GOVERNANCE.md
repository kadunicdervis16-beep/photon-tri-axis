# AAVEP — Governance

Decisions of the author (Dervis Kadunic), recorded as given. The
kit implements them; it does not reinterpret them.

## From v1.0 (2026-11-11) — the five rulings and their v1.1 disposition

1. **License: standard MIT** — carried unchanged; restated
   under Standing rules below.
2. **The name is AAVEP** — carried unchanged.
3. **Freeze and anchor at creation** — carried unchanged;
   restated under Standing rules below.
4. **CAL authorship stays with the house** until someone proves
   themselves by meeting or exceeding the standard. The
   opportunity is always given. Fixtures are synthetic-only; the
   battery is never authored against a live target.
5. **The gate binds everybody.** No house exemption: house
   operators earn their calibration receipts under the same rules
   as any outside operator, before their findings count. This
   rule was applied to the house first, in the v1.0 demonstration
   and again in v1.1's.

## The external run — the standing offer

The kit's standing is DEMONSTRATION until an external,
unaffiliated agent completes a certified run. That event is
invited concretely, not rhetorically: any unaffiliated operator
may ask the author for an AAVEP-CAL v2 administration (custody
exactly as the CAL specification describes; the resulting
receipts are re-scorable by any receiver from the published
keys), and any unaffiliated administrator may administer the
battery to house operators on the same terms — house receipts
earned under an outside administrator print that fact. A
completed external administration, with its bundle published,
is the promotion event; until it happens the standing label is
a fact, not a posture.

## From the v1.1 rulings (2026-11-12)

1. **AAVEP-CAL v2 is a fresh battery edition**, frozen under
   v1.1. The v1 battery stays frozen with v1.0, untouched.
2. **Signatures are deferred to a v1.2 question.** v1.1 ships the
   stdlib commitment model only. No signature machinery is built,
   and no placeholder implies it exists.
3. **SELF-ADMINISTERED and COMMITMENT-ONLY evidence stays
   receivable** — graded, vocabulary-capped in report logic, and
   never wordable as independent verification.
4. **Demonstration targets: both** — a synthetic fixture package
   with scriptable negative cases, and Paper 12.5 v10.
   Predictions are lodged before any run.
5. **Sandboxing: attempt-and-print.** The portable floor runs
   everywhere; an OS sandbox is attempted where the platform
   offers one; the achieved confinement level is printed in every
   status record.

## Standing rules (all versions)

- **Freeze and anchor at creation.** Each version's freeze record
  and anchor are computed when the version is built. External
  anchoring (publication) is the author's act, never the kit's
  and never an operator's.
- **License: MIT © Dervis Kadunic**, for AAVEP and for the
  vendored honesty plugin.
- **A finding stands as recorded.** Later versions never
  re-adjudicate an earlier version's findings or silently
  strengthen their grades; corrections are new records that cite
  the standing label.
- **Predictions before runs.** Every demonstration lodges its
  expected outcomes, in writing, before any run executes.
  Deviations are recorded as deviations, with reasons.
