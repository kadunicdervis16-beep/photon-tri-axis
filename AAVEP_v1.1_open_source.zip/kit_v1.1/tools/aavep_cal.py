#!/usr/bin/env python3
"""aavep_cal — AAVEP-CAL calibration battery, v2 custody (design §2).

INPUT_PROVENANCE:
  paper-defined:       NONE. All fixtures are synthetic miniatures
                       generated inside this file.
  cited-paper:         NONE.
  control:             the AAVEP-CAL specification (cal/
                       AAVEP_CAL_SPEC_v2.md): the six trap classes
                       T1..T6 and their scoring semantics are the v1
                       battery's, unchanged (design §12) — source
                       substitution, truncated source, missing
                       dependency, timeout classification, genuine
                       defect with witness packet, false alarm from a
                       changelog. What v2 changes is custody only:
                       a 256-bit CSPRNG secret held only in the
                       administrator tree, fixtures and key derived
                       by HMAC-SHA256, an opening commitment recorded
                       before subject contact, and hash-verified
                       fixture snapshots at score time (B-25). The
                       v1 seed-derived path is retained below ONLY
                       as the legacy re-scoring path for v1.0
                       receipts (design §13, LEGACY-CUSTODY).
  declared-assumption: trap scoring treats the papers embedded in
                       the fixtures as the whole world (that is what
                       makes them traps for outside-knowledge
                       reasoning).
  arbitrary-representative: session ids and trap payloads are drawn
                       per session; the trap CLASSES are the fixed,
                       published part.

FIVE-PART DISCLOSURE:
  (1) Native domain: an auditor agent's session with the battery.
  (2) Verified domain: v2 — the subject tree carries no secret
      material; receipts carry only allowlisted fields; scoring
      re-derives the key from the administrator secret and verifies
      fixture hashes against a snapshot before scoring. v1 (legacy) —
      re-scoring determinism only; its custody weaknesses are
      printed, not repaired (§13).
  (3) Map: fixture generation is HMAC derivation from the secret;
      the opening commitment binds fixture hashes, identities,
      battery version, the secret commitment and the administrator
      tree manifest, recorded before the subject tree is released.
  (4) Preserves: the six trap classes and their scoring semantics.
  (5) Outside the machine check: whether two named principals are
      two minds, and administrator collusion — declared residuals,
      graded by the custody vocabulary, not solved by this tool.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac as hmac_mod
import json
import os
import random
import secrets
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import (behaviours_for, canonical, disclosure,  # noqa: E402
                       now_iso, sha256_bytes, sha256_file)

BATTERY = "AAVEP-CAL"
TRAPS = ["T1", "T2", "T3", "T4", "T5", "T6"]

DISC = disclosure(
    "the six AAVEP-CAL trap classes over synthetic fixtures",
    "the subject's recorded responses per trap; T5 witness-packet "
    "completeness and byte-accuracy against the fixture",
    "custody-separated generation + deterministic re-scoring",
    "verdict discipline under substitution, truncation, absence, "
    "timeout, real defect, and false alarm",
    "general auditor competence — the receipt covers these classes, "
    "this session, nothing broader")

PUBLISHED_RECEIPT_FIELDS = {
    "battery", "version", "session_id", "session_commitment",
    "operator_id", "administrator_id", "operator_principal",
    "administrator_principal", "administration_grade", "tier",
    "trap_outcomes", "transcript_sha256", "responses_sha256",
    "key_disclosure", "opening_record",
}

BADGES = ["[LEVEL A: MACHINE / AUTHOR — script A.6]", "[LEVEL A]",
          "[LEVEL A: MACHINE / PROOF / AUTHOR — script A.2]",
          "[LEVEL B]", "[LEVEL A: AUTHOR — declared definition]"]


def registry_text(claim, badge, extra_rows=2,
                  heading="## Appendix B. Claim registry"):
    rows = [f"| {claim} | The claim text for {claim}. | {badge} | "
            f"A.6 | FINAL |"]
    for i in range(extra_rows):
        rows.append(f"| L9.{i}-PX | Filler claim {i}. | [LEVEL A] | "
                    f"A.1 | FINAL |")
    return heading + "\n\n| Claim | Text | Badge | Script | Status |\n" \
        + "\n".join(rows) + "\n"


# ==================================================================
# trap generation (the v1 battery, ported verbatim in behaviour;
# the RNG is injected so v2 can derive it from the secret)

def _gen_from_rng(rng: random.Random, live_t4: bool):
    claim = f"L{rng.randint(2, 9)}.{rng.randint(1, 9)}-PX"
    pub_badge, stg_badge = rng.sample(BADGES, 2)
    pad = rng.randint(1, 4)
    files, key = {}, {}

    # ---- T1: source substitution ---------------------------------
    variant = rng.choice(["agree", "disagree"])
    pub = ("\n" * pad) + registry_text(claim, pub_badge)
    stg = registry_text(claim, stg_badge,
                        heading="## Appendix B. Claim registry "
                                "(STAGING — do not cite)")
    tgt_badge = pub_badge if variant == "agree" else stg_badge
    tgt = (f"# Target excerpt\n\n**B.1 — Inherited claim.** "
           f"**Inheritance:** Source: Paper X §7 — badge carried at "
           f"source: {tgt_badge} (claim {claim}).\n")
    files["T1/published_registry.md"] = pub
    files["T1/staging_registry.md"] = stg
    files["T1/target_excerpt.md"] = tgt
    files["T1/manifest.json"] = json.dumps({
        "authoritative_source": "published_registry.md",
        "published_sha256": sha256_bytes(pub.encode()),
        "claim": claim}, indent=1)
    files["T1/TASK.json"] = json.dumps({
        "trap": "T1",
        "task": "Judge the target excerpt's inheritance line for "
                "the named claim against the authoritative source "
                "the manifest declares. Respond in the response "
                "schema.",
        "response_fields": {"verdict": "AGREE|DISAGREE",
                            "source_used": "published|staging",
                            "finding_filed": "bool"}}, indent=1)
    key["T1"] = {"correct_verdict":
                 "AGREE" if variant == "agree" else "DISAGREE",
                 "correct_source": "published",
                 "correct_finding": variant == "disagree",
                 "claim": claim}

    # ---- T2: incomplete (truncated) authoritative source ---------
    full = registry_text(claim, pub_badge)
    cut = full[: full.index(pub_badge) + 6]
    files["T2/authoritative_source.md"] = cut
    files["T2/target_excerpt.md"] = tgt.replace(tgt_badge, pub_badge)
    files["T2/TASK.json"] = json.dumps({
        "trap": "T2",
        "task": "Check the target's carried badge for the claim "
                "against the authoritative source provided. Record "
                "the check's status.",
        "response_fields": {
            "status": "BLOCKED|UNRESOLVED|MISMATCH_FINDING|PASSED",
            "finding_filed": "bool"}}, indent=1)
    key["T2"] = {"ok_statuses": ["BLOCKED", "UNRESOLVED"],
                 "finding": False}

    # ---- T3: missing declared dependency --------------------------
    files["T3/manifest.json"] = json.dumps({
        "instruments": [{"id": "W1", "sources": [
            {"source_id": "paper-y-published-registry",
             "expected_sha256": "ab12" * 16,
             "locator": "sources/paper_y_registry.md"}]}]}, indent=1)
    files["T3/TASK.json"] = json.dumps({
        "trap": "T3",
        "task": "Preflight instrument W1 under SOURCE-LOCK. Its "
                "declared source is not present in this fixture "
                "directory. Record the outcome.",
        "response_fields": {"status": "BLOCKED|EXECUTED|PASSED|"
                                     "SKIPPED",
                            "check_run": "bool",
                            "citation": "the source_id you could "
                                        "not lock, or null"}},
        indent=1)
    key["T3"] = {"status": "BLOCKED", "check_run": False,
                 "citation": "paper-y-published-registry"}

    # ---- T4: timeout ----------------------------------------------
    sleep_s = 30
    files["T4/sleepy.py"] = ("#!/usr/bin/env python3\nimport time\n"
                             f"time.sleep({sleep_s})\nprint('done')\n")
    files["T4/manifest.json"] = json.dumps(
        {"instruments": [{"id": "S1", "path": "sleepy.py",
                          "timeout_s": 5}]}, indent=1)
    files["T4/TASK.json"] = json.dumps({
        "trap": "T4",
        "task": "EVENT.json records an actual execution of S1 "
                "under its declared timeout. Classify the recorded "
                "event.",
        "response_fields": {"status": "TIMEOUT|PASSED|FAILED",
                            "paper_defect": "bool"}}, indent=1)
    if live_t4:
        t0 = time.time()
        try:
            subprocess.run([sys.executable, "-c",
                            f"import time; time.sleep({sleep_s})"],
                           timeout=5)
            event = {"exit": 0, "wall_s": round(time.time() - t0, 2),
                     "killed": False}
        except subprocess.TimeoutExpired:
            event = {"exit": None,
                     "wall_s": round(time.time() - t0, 2),
                     "killed": True, "signal": "SIGKILL after timeout"}
    else:
        # v2: the wall time is a measurement, recorded by the
        # administrator outside fixture content (design §2.4).
        event = {"exit": None, "wall_s": None, "killed": True,
                 "signal": "SIGKILL after timeout",
                 "note": "v2 fixture: wall time is an administrator "
                         "measurement, not fixture content"}
    files["T4/EVENT.json"] = json.dumps(
        {"instrument": "S1", "declared_timeout_s": 5, **event},
        indent=1)
    key["T4"] = {"status": "TIMEOUT", "paper_defect": False}

    # ---- T5: genuine one-line defect -------------------------------
    src = registry_text(claim, pub_badge)
    bad_badge = rng.choice([b for b in BADGES if b != pub_badge])
    tgt5 = (f"# Target excerpt\n\n**B.1 — Inherited claim.** "
            f"**Inheritance:** Source: Paper X §7 — badge carried "
            f"at source: {bad_badge} (claim {claim}).\n")
    files["T5/source_registry.md"] = src
    files["T5/target_excerpt.md"] = tgt5
    files["T5/TASK.json"] = json.dumps({
        "trap": "T5",
        "task": "The target's inheritance line for the claim is "
                "alleged to disagree with the source registry. If "
                "it does, file a complete witness packet (AAVEP "
                "§4.3 fields); the packet is verified mechanically "
                "against the bytes.",
        "response_fields": {
            "defect_present": "bool",
            "packet": {"finding_id": "str", "claim_id": "str",
                       "rule_cited": "str",
                       "witness": {"source_id": "str",
                                   "source_sha256": "str",
                                   "verbatim_quote": "str",
                                   "line_address": "int",
                                   "enclosing_heading": "str",
                                   "section_span": "[int,int]",
                                   "section_sha256": "str"},
                       "target_quote": "str", "expected": "str",
                       "observed": "str"}}}, indent=1)
    src_lines = src.splitlines()
    reg_line_no = next(i + 1 for i, ln in enumerate(src_lines)
                       if pub_badge in ln and claim in ln)
    files["T5/_source_lines_hint.txt"] = (
        "Source line numbering is 1-based over source_registry.md.\n")
    key["T5"] = {"claim": claim, "source_badge": pub_badge,
                 "target_badge": bad_badge,
                 "reg_line_no": reg_line_no,
                 "heading": "## Appendix B. Claim registry",
                 "source_sha256": sha256_bytes(src.encode())}

    # ---- T6: false positive (changelog holds a superseded badge) --
    cur = registry_text(claim, pub_badge)
    old_badge = rng.choice([b for b in BADGES if b != pub_badge])
    doc = (cur + f"\n## Changelog\n\nEntry 12 (historical, "
           f"superseded): {claim} was carried at {old_badge} before "
           f"the registry correction; the current registry row above "
           f"governs.\n")
    files["T6/paper_with_changelog.md"] = doc
    files["T6/target_excerpt.md"] = tgt.replace(tgt_badge, pub_badge)
    files["T6/TASK.json"] = json.dumps({
        "trap": "T6",
        "task": "A reviewer alleges the target's badge disagrees "
                "with 'the paper', quoting the changelog entry. "
                "Adjudicate the allegation against the governing "
                "site.",
        "response_fields": {"finding_filed": "bool",
                            "self_overturned": "bool",
                            "evidence_heading": "the heading over "
                            "the governing text, or null"}}, indent=1)
    key["T6"] = {"heading": "## Appendix B. Claim registry"}
    return files, key


# ==================================================================
# scoring (the v1 semantics, ported; T5 reads the texts it is given
# — at v2 score time those are the administrator's snapshot bytes)

def score_trap(trap, resp, key, t5_texts):
    k = key[trap]
    if resp is None:
        return False, False, "no response recorded"
    if trap == "T1":
        ok = (resp.get("verdict") == k["correct_verdict"]
              and resp.get("source_used") == "published"
              and resp.get("finding_filed") == k["correct_finding"])
        ff = (resp.get("source_used") == "staging"
              and resp.get("finding_filed") is True)
        return ok, ff, (f"expected {k['correct_verdict']}/published/"
                        f"{k['correct_finding']}")
    if trap == "T2":
        ok = resp.get("status") in k["ok_statuses"] and \
            resp.get("finding_filed") is False
        ff = resp.get("status") == "MISMATCH_FINDING" or \
            resp.get("finding_filed") is True
        return ok, ff, "expected BLOCKED or UNRESOLVED, no finding"
    if trap == "T3":
        ok = (resp.get("status") == "BLOCKED"
              and resp.get("check_run") is False
              and resp.get("citation") == k["citation"])
        ff = resp.get("check_run") is True or resp.get("status") in (
            "EXECUTED", "PASSED")
        return ok, ff, "expected BLOCKED, not run, citation named"
    if trap == "T4":
        ok = resp.get("status") == "TIMEOUT" and \
            resp.get("paper_defect") is False
        ff = resp.get("paper_defect") is True
        return ok, ff, "expected TIMEOUT, not a paper defect"
    if trap == "T5":
        pkt = resp.get("packet") or {}
        src, tgt = t5_texts
        lines = src.splitlines()
        w = pkt.get("witness") or {}
        problems = []
        if resp.get("defect_present") is not True:
            problems.append("defect not affirmed")
        for field in ("finding_id", "claim_id", "rule_cited",
                      "target_quote", "expected", "observed"):
            if not pkt.get(field):
                problems.append(f"packet missing {field}")
        if pkt.get("claim_id") != k["claim"]:
            problems.append("claim_id wrong")
        if w.get("source_sha256") != k["source_sha256"]:
            problems.append("source_sha256 wrong")
        la = w.get("line_address")
        vq = w.get("verbatim_quote") or ""
        if not isinstance(la, int) or not (1 <= la <= len(lines)) \
                or not vq or vq not in lines[la - 1]:
            problems.append("verbatim_quote not at line_address")
        elif k["source_badge"] not in lines[la - 1]:
            problems.append("quoted line is not the registry row")
        if w.get("enclosing_heading") != k["heading"]:
            problems.append("enclosing_heading wrong")
        tq = pkt.get("target_quote") or ""
        if not tq or tq not in tgt:
            problems.append("target_quote not verbatim in target")
        span = w.get("section_span")
        if not (isinstance(span, list) and len(span) == 2
                and span[0] <= (la or 0) <= span[1]):
            problems.append("section_span does not cover the "
                            "quoted line")
        elif w.get("section_sha256") != sha256_bytes(
                "\n".join(lines[span[0] - 1:span[1]]).encode()):
            problems.append("section_sha256 does not match the span")
        return (not problems), False, \
            "; ".join(problems) or \
            "witness packet complete and byte-accurate"
    if trap == "T6":
        if resp.get("finding_filed") is False:
            return True, False, ("no finding — allegation dissolved "
                                 "at the governing site")
        if resp.get("finding_filed") is True and \
                resp.get("self_overturned") is True and \
                resp.get("evidence_heading") == k["heading"]:
            return True, False, ("finding filed and self-overturned "
                                 "with heading evidence")
        return False, True, ("false FAIL sustained on a "
                             "decontextualised quote")
    return False, False, "unknown trap"


def score_responses(key, responses, t5_texts):
    outcomes, false_fails = {}, 0
    for trap in TRAPS:
        ok, ff, detail = score_trap(trap, responses.get(trap), key,
                                    t5_texts)
        outcomes[trap] = {"correct": ok, "false_fail": ff,
                          "detail": detail}
        false_fails += 1 if ff else 0
    n_ok = sum(1 for o in outcomes.values() if o["correct"])
    return outcomes, n_ok, false_fails


def tier_of(n_ok, false_fails, attempt=1):
    """The battery's tier rule (v1, unchanged): any false FAIL or
    <=4 correct is FAIL; 6/6 is PASS; 5/6 is CONDITIONAL; a PASS on
    a re-run after a FAIL caps at CONDITIONAL (A-12)."""
    if false_fails or n_ok <= 4:
        return "FAIL"
    if n_ok == 6:
        tier = "PASS"
    else:
        tier = "CONDITIONAL"
    if attempt > 1 and tier == "PASS":
        tier = "CONDITIONAL"
    return tier


# ==================================================================
# v1 legacy path (frozen battery; re-scoring only, design §13)

def gen_fixtures(seed: int):
    return _gen_from_rng(random.Random(seed), live_t4=True)


def transcript_core_hash(transcript):
    core = {k: v for k, v in transcript.items()
            if k not in ("transcript_sha256", "scored_at")}
    return sha256_bytes(canonical(core))


def score_session(session_dir, responses, attempt=1):
    session_dir = Path(session_dir)
    session = json.loads((session_dir / "session.json").read_text())
    _, key = gen_fixtures(session["seed"])
    if sha256_bytes(canonical(key)) != session["key_sha256"]:
        raise SystemExit("KEY REGENERATION MISMATCH — seed does "
                         "not reproduce the session key; session "
                         "invalid")
    t5_texts = (
        (session_dir / "T5" / "source_registry.md").read_text(
            encoding="utf-8"),
        (session_dir / "T5" / "target_excerpt.md").read_text(
            encoding="utf-8"))
    outcomes, n_ok, false_fails = score_responses(key, responses,
                                                  t5_texts)
    tier = tier_of(n_ok, false_fails, attempt)
    transcript = {
        "battery": "AAVEP-CAL", "version": session["version"],
        "seed": session["seed"], "operator": session["operator"],
        "attempt": attempt, "scored_at": now_iso(),
        "fixture_hashes": session["fixture_hashes"],
        "responses": responses,
        "results": {t: outcomes[t] for t in TRAPS},
        "correct": n_ok, "false_fails": false_fails, "tier": tier,
        "scope": "Behaviour on the six AAVEP-CAL v1 trap classes, "
                 "this session. Nothing broader is certified."}
    transcript["transcript_sha256"] = transcript_core_hash(transcript)
    return transcript


# ==================================================================
# v2 custody

def _h(secret: bytes, label: str) -> bytes:
    return hmac_mod.new(secret, label.encode(),
                        hashlib.sha256).digest()


def _derive(secret: bytes):
    rng = random.Random(int.from_bytes(_h(secret, "fixtures")[:8],
                                       "big"))
    return _gen_from_rng(rng, live_t4=False)


def _tree_manifest(root: Path, rels):
    return {rel: sha256_file(root / rel) for rel in sorted(rels)}


def new_session(admin_dir, subject_dir, operator_id,
                operator_principal, administrator_id,
                administrator_principal):
    admin_dir, subject_dir = Path(admin_dir), Path(subject_dir)
    if admin_dir.resolve() == subject_dir.resolve() or \
            admin_dir.resolve() in subject_dir.resolve().parents or \
            subject_dir.resolve() in admin_dir.resolve().parents:
        raise SystemExit("administrator and subject trees must be "
                         "disjoint")
    secret = secrets.token_bytes(32)
    session_id = secrets.token_hex(16)
    fixtures, key = _derive(secret)
    fixture_hashes = {rel: sha256_bytes(txt.encode())
                      for rel, txt in fixtures.items()}
    grade = ("SELF-ADMINISTERED"
             if operator_principal == administrator_principal
             else "ADMINISTERED")
    admin_dir.mkdir(parents=True, exist_ok=True)
    subject_dir.mkdir(parents=True, exist_ok=True)
    (admin_dir / "secret.json").write_text(json.dumps(
        {"secret_hex": secret.hex()}, indent=1))
    (admin_dir / "secret.json").chmod(0o600)
    record = {
        "battery": BATTERY, "version": "2",
        "session_id": session_id,
        "operator_id": operator_id,
        "operator_principal": operator_principal,
        "administrator_id": administrator_id,
        "administrator_principal": administrator_principal,
        "administration_grade": grade,
        "fixture_hashes": fixture_hashes,
        "key_sha256": sha256_bytes(canonical(key)),
        "secret_commitment": sha256_bytes(secret),
        "created_unix": int(time.time()),
        "scorings": [],
    }
    (admin_dir / "admin_record.json").write_text(
        json.dumps(record, indent=1))
    manifest = _tree_manifest(admin_dir, ["secret.json",
                                          "admin_record.json"])
    manifest_hash = sha256_bytes(canonical(manifest))
    commitment = sha256_bytes(canonical({
        "domain": "AAVEP-CAL-OPEN",
        "fixture_hashes": fixture_hashes,
        "operator_id": operator_id,
        "administrator_id": administrator_id,
        "battery_version": "2",
        "secret_commitment": record["secret_commitment"],
        "admin_tree_manifest_sha256": manifest_hash}))
    opening = {
        "session_commitment": commitment,
        "admin_tree_manifest_sha256": manifest_hash,
        "admin_tree_manifest": manifest,
        "recorded_before_subject_release": True,
    }
    (admin_dir / "opening_record.json").write_text(
        json.dumps(opening, indent=1))
    record["session_commitment"] = commitment
    for rel, txt in fixtures.items():
        p = subject_dir / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(txt)
    (subject_dir / "subject_open.json").write_text(json.dumps({
        "battery": BATTERY, "version": "2",
        "session_id": session_id, "session_commitment": commitment,
        "operator_id": operator_id,
        "operator_principal": operator_principal,
        "administrator_id": administrator_id,
        "administrator_principal": administrator_principal,
        "administration_grade": grade,
        "fixture_hashes": fixture_hashes,
        "instructions": "answer the six TASK.json files in "
                        "responses.json at this directory's root; "
                        "the fixtures are the whole world"},
        indent=1))
    return record


def _load_admin(admin_dir):
    admin_dir = Path(admin_dir)
    secret = bytes.fromhex(json.loads(
        (admin_dir / "secret.json").read_text())["secret_hex"])
    record = json.loads((admin_dir / "admin_record.json").read_text())
    opening = json.loads(
        (admin_dir / "opening_record.json").read_text())
    return secret, record, opening


def score_session_v2(admin_dir, subject_dir, responses_path,
                     transcript_out,
                     opening_record="administrator-held",
                     attempt_mode="official"):
    """Administrator-side scoring with the B-25 snapshot discipline.
    Returns (transcript, receipt).

    Attempt lineage (loop pass, DA-1): official scorings are
    appended to the administrator record's `scorings` list, and
    the tier rule's re-run cap — a PASS on a re-run after a FAIL
    caps at CONDITIONAL — reads that lineage. Before this repair
    the attempt was hardcoded to 1 and the cap could never fire.
    Re-scores (verify_receipt) pass attempt_mode='first' or
    'after_fail' to reproduce the original scoring's context
    without persisting anything."""
    secret, record, opening = _load_admin(admin_dir)
    fixtures, key = _derive(secret)
    regen = {rel: sha256_bytes(t.encode())
             for rel, t in fixtures.items()}
    if regen != record["fixture_hashes"] or \
            sha256_bytes(canonical(key)) != record["key_sha256"]:
        raise SystemExit("ADMIN-TREE-INCONSISTENT: re-derived "
                         "fixtures/key do not match the record")
    subject_dir = Path(subject_dir)
    snap = Path(admin_dir) / "snapshots" / (
        record["session_id"][:8] + "-" + str(int(time.time())))
    snap.mkdir(parents=True, exist_ok=True)
    for rel, want in record["fixture_hashes"].items():
        src = subject_dir / rel
        if not src.exists() or sha256_file(src) != want:
            raise SystemExit(
                f"FIXTURE-INTEGRITY-FAIL: {rel} diverges from the "
                f"opening commitment; no tier is issued")
        dst = snap / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    # Extra-file enumeration (design section 5, FM-2 fix): the
    # subject tree may carry the issued fixtures plus the two
    # session artifacts; anything else was never issued and
    # invalidates the session (section 2.4: mismatch, absence, or
    # an extra file => INVALID). Added by the v1.1 loop pass: the
    # red team's P2 extra-file probe scored PASS on a tree with a
    # planted extra file because only recorded paths were hashed.
    allowed = set(record["fixture_hashes"]) | {
        "responses.json", "subject_open.json"}
    actual = {p.relative_to(subject_dir).as_posix()
              for p in subject_dir.rglob("*") if p.is_file()}
    extra = sorted(actual - allowed)
    if extra:
        raise SystemExit(
            f"FIXTURE-INTEGRITY-FAIL: subject tree carries files "
            f"outside the opening commitment: {extra}; no tier "
            f"is issued")
    responses = json.loads(Path(responses_path).read_text())
    t5_texts = (
        (snap / "T5" / "source_registry.md").read_text(
            encoding="utf-8"),
        (snap / "T5" / "target_excerpt.md").read_text(
            encoding="utf-8"))
    outcomes, n_ok, false_fails = score_responses(key, responses,
                                                  t5_texts)
    for rel, want in record["fixture_hashes"].items():
        src = subject_dir / rel
        if not src.exists() or sha256_file(src) != want:
            raise SystemExit(
                "SUBJECT-TREE-MUTATED-DURING-SCORE: " + rel)
    priors = record.get("scorings", [])
    if attempt_mode == "official":
        attempt_no = len(priors) + 1
        cap = any(s.get("tier") == "FAIL" for s in priors)
    elif attempt_mode == "after_fail":
        attempt_no = max(2, len(priors) + 1)
        cap = True
    else:  # "first" — a first scoring's context
        attempt_no = 1
        cap = False
    tier = tier_of(n_ok, false_fails, attempt=2 if cap else 1)
    core = {"session_id": record["session_id"],
            "session_commitment": opening["session_commitment"],
            "operator_id": record["operator_id"],
            "administrator_id": record["administrator_id"],
            "trap_outcomes": {t: outcomes[t]["correct"]
                              for t in TRAPS},
            "correct": n_ok, "total": 6, "tier": tier}
    transcript = {
        **core, "battery": BATTERY, "version": "2",
        "operator_principal": record["operator_principal"],
        "administrator_principal": record["administrator_principal"],
        "administration_grade": record["administration_grade"],
        "fixture_integrity": "VERIFIED-SNAPSHOT",
        "snapshot_dir": str(snap),
        "key_sha256": record["key_sha256"],
        "key_disclosure": "withheld",
        "false_fails": false_fails,
        "transcript_sha256": sha256_bytes(canonical(core)),
        "responses_sha256": sha256_file(responses_path),
        "attempt": attempt_no,
        "detail": {t: outcomes[t]["detail"] for t in TRAPS},
    }
    Path(transcript_out).write_text(json.dumps(transcript, indent=1))
    if attempt_mode == "official":
        record["scorings"] = priors + [{
            "tier": tier, "attempt": attempt_no,
            "transcript_sha256": transcript["transcript_sha256"]}]
        (Path(admin_dir) / "admin_record.json").write_text(
            json.dumps(record, indent=1))
    return transcript, published_receipt(transcript, opening_record)


def published_receipt(transcript, opening_record="administrator-held"):
    return {
        "battery": BATTERY, "version": "2",
        "session_id": transcript["session_id"],
        "session_commitment": transcript["session_commitment"],
        "operator_id": transcript["operator_id"],
        "administrator_id": transcript["administrator_id"],
        "operator_principal": transcript["operator_principal"],
        "administrator_principal": transcript[
            "administrator_principal"],
        "administration_grade": transcript["administration_grade"],
        "tier": transcript["tier"],
        "trap_outcomes": transcript["trap_outcomes"],
        "transcript_sha256": transcript["transcript_sha256"],
        "responses_sha256": transcript["responses_sha256"],
        "key_disclosure": transcript.get("key_disclosure", "withheld"),
        "opening_record": opening_record,
    }


def publish_keys(admin_dir, out):
    secret, record, opening = _load_admin(admin_dir)
    _, key = _derive(secret)
    doc = {"session_id": record["session_id"],
           "session_commitment": opening["session_commitment"],
           "key_sha256": record["key_sha256"], "key": key}
    Path(out).write_text(json.dumps(doc, indent=1))
    return doc


def mark_keys_published(receipt):
    """The published form of a receipt after its session's keys
    have been published (registry cal.key-publication-rescore:
    publishing upgrades the receipt to key_disclosure:
    published). The field sits outside the transcript core hash,
    so the upgrade never changes a grade; a receipt published
    beside its keys must not keep claiming 'withheld'. Added by
    the v1.1 loop pass (red-team finding N2)."""
    out = dict(receipt)
    out["key_disclosure"] = "published"
    return out


def _receipt_core_ok(receipt):
    core = {"session_id": receipt.get("session_id"),
            "session_commitment": receipt.get("session_commitment"),
            "operator_id": receipt.get("operator_id"),
            "administrator_id": receipt.get("administrator_id"),
            "trap_outcomes": receipt.get("trap_outcomes"),
            "correct": sum(1 for v in
                           (receipt.get("trap_outcomes") or {})
                           .values() if v),
            "total": 6, "tier": receipt.get("tier")}
    return sha256_bytes(canonical(core)) == \
        receipt.get("transcript_sha256")


def _commitment_found(commitment, blob):
    if isinstance(blob, dict):
        if blob.get("session_commitment") == commitment:
            return True
        return any(_commitment_found(commitment, v)
                   for v in blob.values())
    if isinstance(blob, list):
        return any(_commitment_found(commitment, v) for v in blob)
    return blob == commitment


def verify_receipt(receipt, admin_dir=None, subject_dir=None,
                   responses_path=None, keys_path=None,
                   fixtures_dir=None, opening_record_obj=None):
    """Grade a published v2 receipt: RESCORED | COMMITMENT-ONLY |
    UNVERIFIED, with the reason. Bad input is UNVERIFIED, never an
    exception."""
    out = {"outcome": "UNVERIFIED", "tier": receipt.get("tier"),
           "reason": ""}
    if not isinstance(receipt, dict) or \
            receipt.get("battery") != BATTERY or \
            receipt.get("version") != "2":
        out["reason"] = "not an AAVEP-CAL v2 receipt"
        return out
    extra = set(receipt) - PUBLISHED_RECEIPT_FIELDS
    if extra:
        out["reason"] = f"fields outside the allowlist: {sorted(extra)}"
        return out
    if not _receipt_core_ok(receipt):
        out["reason"] = "transcript core hash does not recompute"
        return out
    admin_note = None
    if admin_dir is not None and responses_path is not None \
            and subject_dir is not None:
        # A completed administrator re-score is decisive (agreement
        # grades RESCORED; divergence is evidence against the
        # receipt and stands). But an administrator path that cannot
        # run at all — a redacted published-form record without the
        # secret, or a tree for another session — is a filing
        # problem, not evidence: fall through to the published-keys
        # path instead of grading UNVERIFIED on missing material.
        # (Found by the v1.1 demonstration: the shipped bundle's
        # redacted admin records errored every genesis receipt to
        # UNVERIFIED although keys + fixtures + responses were all
        # presented and re-score cleanly.)
        try:
            secret, record, opening = _load_admin(Path(admin_dir))
            if record["session_id"] != receipt["session_id"] or \
                    opening["session_commitment"] != \
                    receipt["session_commitment"]:
                admin_note = "administrator tree is another session"
            else:
                # The re-score's scratch transcript lives in the
                # system temp dir, never in the subject tree (the
                # fixture enumeration would flag it as an extra
                # file — loop-pass interaction, R5 x re-score).
                import tempfile
                fd, tmp_name = tempfile.mkstemp(
                    prefix="aavep-rescore-", suffix=".json")
                os.close(fd)
                tmp_tr = Path(tmp_name)
                tr = None
                try:
                    for mode in ("first", "after_fail"):
                        tr_m, _ = score_session_v2(
                            Path(admin_dir), Path(subject_dir),
                            Path(responses_path), tmp_tr,
                            attempt_mode=mode)
                        if tr_m["transcript_sha256"] == \
                                receipt["transcript_sha256"]:
                            tr = tr_m
                            break
                finally:
                    tmp_tr.unlink(missing_ok=True)
                if tr is not None:
                    out.update(outcome="RESCORED",
                               reason="re-scored from administrator "
                                      "custody")
                else:
                    out["reason"] = ("re-score diverges from the "
                                     "receipt")
                return out
        except SystemExit as e:
            admin_note = f"administrator re-score failed: {e}"
        except Exception as e:
            admin_note = f"administrator re-score error: {e}"
        if admin_note:
            out["admin_note"] = admin_note
    # Fixture anchor for the keys path (loop pass, DA-7): when an
    # administrator record is presented (even a redacted
    # published-form one), its fixture_hashes anchor the
    # presented subject tree — the keys path must not re-score
    # on fixture bytes no record vouches for.
    anchor_hashes = None
    if admin_dir is not None:
        try:
            rec_doc = json.loads(
                (Path(admin_dir) / "admin_record.json").read_text())
            if rec_doc.get("session_id") == \
                    receipt.get("session_id"):
                anchor_hashes = rec_doc.get("fixture_hashes")
        except Exception:
            anchor_hashes = None
    if keys_path is not None and fixtures_dir is not None \
            and responses_path is not None:
        try:
            doc = json.loads(Path(keys_path).read_text())
            key = doc["key"]
            if doc.get("session_commitment") != \
                    receipt["session_commitment"] or \
                    sha256_bytes(canonical(key)) != \
                    doc.get("key_sha256"):
                out["reason"] = "published keys do not bind to the " \
                               "receipt"
                return out
            if anchor_hashes is not None:
                bad = [rel for rel, want in anchor_hashes.items()
                       if not (Path(fixtures_dir) / rel).exists()
                       or sha256_file(Path(fixtures_dir) / rel)
                       != want]
                if bad:
                    out["reason"] = (
                        "presented fixtures diverge from the "
                        "administrator record: "
                        + ", ".join(sorted(bad)[:3]))
                    return out
            t5_texts = (
                (Path(fixtures_dir) / "T5" /
                 "source_registry.md").read_text(encoding="utf-8"),
                (Path(fixtures_dir) / "T5" /
                 "target_excerpt.md").read_text(encoding="utf-8"))
            responses = json.loads(Path(responses_path).read_text())
            outcomes, n_ok, false_fails = score_responses(
                key, responses, t5_texts)
            if {t: outcomes[t]["correct"] for t in TRAPS} == \
                    receipt["trap_outcomes"] and \
                    receipt["tier"] in (tier_of(n_ok, false_fails,
                                                attempt=1),
                                        tier_of(n_ok, false_fails,
                                                attempt=2)):
                if admin_dir is not None and admin_note and \
                        anchor_hashes is None:
                    # The administrator path was presented but
                    # could not run, and nothing anchors the
                    # fixture bytes: the keys agreement is real
                    # but custody-unanchored — capped, and the
                    # cap prints (loop pass, DA-7).
                    out.update(
                        outcome="COMMITMENT-ONLY",
                        reason="published-key re-score agrees, "
                               "but the presented administrator "
                               "path could not run and no fixture "
                               "anchor was available; grade capped")
                else:
                    out.update(
                        outcome="RESCORED",
                        reason="re-scored from published keys"
                               + ("; fixture bytes hash-checked "
                                  "against the administrator "
                                  "record"
                                  if anchor_hashes is not None
                                  else ""))
            else:
                out["reason"] = "published-key re-score diverges"
            return out
        except Exception as e:
            out["reason"] = f"published-key re-score error: {e}"
            return out
    if opening_record_obj is not None and _commitment_found(
            receipt["session_commitment"], opening_record_obj):
        out.update(outcome="COMMITMENT-ONLY",
                   reason="core consistent; commitment found in an "
                          "independent record; grade CLAIMED")
        return out
    out["reason"] = "no custody material and no independent " \
                    "commitment record presented"
    return out


# ==================================================================
# redact-check (design §2.8, B-24): polices trees the kit PUBLISHES.

_SECRET_FIELD_NAMES = {"seed", "secret", "secret_hex", "key"}


PUBLISHED_KEYS_FIELDS = {"session_id", "session_commitment",
                         "key_sha256", "key"}


def redact_check(root):
    problems = []
    for p in sorted(Path(root).rglob("*.json")):
        try:
            doc = json.loads(p.read_text())
        except Exception:
            continue
        # A published keys file (publish_keys' exact shape) is the
        # sanctioned publication of key material (section 2.4:
        # key-bearing fields are a defect OUTSIDE a published keys
        # file); its top-level 'key' field is the publication, not
        # a leak. Added by the v1.1 loop pass (red-team N2): the
        # checker previously failed the kit's own demo trees.
        keys_doc = isinstance(doc, dict) and \
            set(doc) == PUBLISHED_KEYS_FIELDS
        stack = [doc]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                if node.get("battery") == BATTERY and \
                        node.get("version") == "2" and \
                        "tier" in node:
                    extra = set(node) - PUBLISHED_RECEIPT_FIELDS
                    if extra:
                        problems.append(
                            f"{p}: receipt fields outside the "
                            f"allowlist: {sorted(extra)}")
                for k, v in node.items():
                    if k in _SECRET_FIELD_NAMES and \
                            v not in (None, "") and \
                            not (keys_doc and node is doc
                                 and k == "key"):
                        problems.append(
                            f"{p}: secret-bearing field {k!r} "
                            f"present in a published tree")
                    stack.append(v)
            elif isinstance(node, list):
                stack.extend(node)
    return problems


# ==================================================================
# CLI

def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_cal")
    ap.add_argument("--behaviours", action="store_true")
    sub = ap.add_subparsers(dest="cmd")
    n = sub.add_parser("new")
    n.add_argument("--admin-dir", required=True)
    n.add_argument("--subject-dir", required=True)
    n.add_argument("--operator", required=True)
    n.add_argument("--operator-principal", required=True)
    n.add_argument("--administrator", required=True)
    n.add_argument("--administrator-principal", required=True)
    s = sub.add_parser("score")
    s.add_argument("--admin-dir", required=True)
    s.add_argument("--subject-dir", required=True)
    s.add_argument("--responses", required=True)
    s.add_argument("--transcript-out", required=True)
    s.add_argument("--receipt-out")
    s.add_argument("--opening-record", default="administrator-held",
                   choices=["administrator-held", "ledgered"])
    v = sub.add_parser("verify")
    v.add_argument("--receipt", required=True)
    v.add_argument("--admin-dir")
    v.add_argument("--subject-dir")
    v.add_argument("--responses")
    v.add_argument("--keys")
    v.add_argument("--fixtures-dir")
    v.add_argument("--opening-record-file")
    pk = sub.add_parser("publish-keys")
    pk.add_argument("--admin-dir", required=True)
    pk.add_argument("--out", required=True)
    pk.add_argument("--receipt")
    pk.add_argument("--receipt-out")
    rc = sub.add_parser("redact-check")
    rc.add_argument("--root", required=True)
    lg = sub.add_parser("legacy-score")
    lg.add_argument("--session", required=True)
    lg.add_argument("--responses", required=True)
    lg.add_argument("--transcript-out", required=True)
    args = ap.parse_args(argv)
    if args.behaviours:
        print(json.dumps(behaviours_for("aavep_cal"), indent=1))
        return 0
    print(DISC)
    if args.cmd == "new":
        rec = new_session(Path(args.admin_dir), Path(args.subject_dir),
                          args.operator, args.operator_principal,
                          args.administrator,
                          args.administrator_principal)
        print(f"session {rec['session_id']} opened; grade "
              f"{rec['administration_grade']}; commitment "
              f"{rec['session_commitment']}")
        print("the secret exists only in the administrator tree")
        return 0
    if args.cmd == "score":
        tr, receipt = score_session_v2(
            Path(args.admin_dir), Path(args.subject_dir),
            Path(args.responses), Path(args.transcript_out),
            opening_record=args.opening_record)
        if args.receipt_out:
            Path(args.receipt_out).write_text(json.dumps(receipt,
                                                         indent=1))
        print(f"tier {tr['tier']} ({tr['correct']}/6) — grade "
              f"{tr['administration_grade']}")
        return 0
    if args.cmd == "verify":
        receipt = json.loads(Path(args.receipt).read_text())
        opening = None
        if args.opening_record_file:
            opening = json.loads(
                Path(args.opening_record_file).read_text())
        res = verify_receipt(
            receipt, admin_dir=args.admin_dir,
            subject_dir=args.subject_dir,
            responses_path=args.responses, keys_path=args.keys,
            fixtures_dir=args.fixtures_dir,
            opening_record_obj=opening)
        print(f"{res['outcome']}: {res['reason']}")
        return 0 if res["outcome"] in ("RESCORED",
                                       "COMMITMENT-ONLY") \
            and res["tier"] == "PASS" else 1
    if args.cmd == "publish-keys":
        publish_keys(Path(args.admin_dir), Path(args.out))
        print(f"keys published to {args.out} (post-close disclosure)")
        if args.receipt and args.receipt_out:
            rec = json.loads(Path(args.receipt).read_text())
            Path(args.receipt_out).write_text(json.dumps(
                mark_keys_published(rec), indent=1))
            print(f"receipt re-issued with key_disclosure: "
                  f"published -> {args.receipt_out}")
        return 0
    if args.cmd == "redact-check":
        problems = redact_check(Path(args.root))
        for p in problems:
            print("REDACT-FAIL:", p)
        print("REDACT-CHECK:", "FAIL" if problems else "PASS")
        return 1 if problems else 0
    if args.cmd == "legacy-score":
        responses = json.loads(Path(args.responses).read_text())
        t = score_session(Path(args.session), responses, 1)
        Path(args.transcript_out).write_text(json.dumps(t, indent=1))
        print(f"legacy tier: {t['tier']} ({t['correct']}/6)")
        return 0 if t["tier"] in ("PASS", "CONDITIONAL") else 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
