#!/usr/bin/env python3
"""crucible_adapter — AAVEP's read-only view of a Crucible trial (§4.8).

INPUT_PROVENANCE:
  paper-defined:       the trial's own artifacts (freeze record,
                       submission manifests, adjudication and charter
                       records) — read as data, never trusted beyond
                       what their hashes and operator identities
                       establish.
  cited-paper:         the Crucible specification bundled in this kit
                       (crucible/GS4_GOLD_SPEC.md) — the trial design
                       this adapter reports against.
  control:             the adapter rules of the design §4.8 (C-1
                       version-lock and target-config list, C-2 the
                       adapter may not freeze, C-3 the state logic,
                       C-4 a specification is not a trial) as amended
                       by A-13 (a freeze record without an external
                       anchor reference is UNVERIFIED and caps the
                       state at PARTIAL).
  declared-assumption: operator identity strings are taken as
                       declared; the adapter verifies self-hashes and
                       presence, not the external anchor's existence —
                       the anchor reference is printed for a receiver
                       to check, and the spec says so.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: Crucible trial states (NOT RUN / SIMULATED /
      PARTIAL / FULL).
  (2) Verified domain: which of those states the presented artifacts
      and operator identities actually support, with every C-3 element
      hash-checked or listed as missing.
  (3) Map: artifact presence + self-hash verification + freeze
      anchoring + operator distinctness -> state, by the §4.8 rules.
  (4) What the map preserves: the trial's independence structure — the
      property the FULL badge depends on.
  (5) What stays outside the machine check: the quality of any bench's
      findings, and the existence of the external anchor record. The
      adapter reports trial state, never trial merit; verdicts on
      findings belong to the ledger.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import (behaviours_for, canonical, disclosure,  # noqa: E402
                       sha256_bytes, sha256_file)

DISC = disclosure(
    "Crucible trial states",
    "which state the presented artifacts and operator identities "
    "support, C-3 elements hash-checked or listed missing",
    "artifact presence + self-hash verification + freeze anchoring + "
    "operator distinctness",
    "the trial's independence structure",
    "the quality of any bench's findings, and the external anchor's "
    "existence (the reference is printed for a receiver to check)")

HEX = set("0123456789abcdef")


def is_hash(s):
    return isinstance(s, str) and len(s) == 64 and set(s) <= HEX


def self_hash_ok(obj, field):
    if not is_hash(obj.get(field)):
        return False
    body = {k: v for k, v in obj.items() if k != field}
    return sha256_bytes(canonical(body)) == obj[field]


def tree_hash_of(tree_dir):
    """The GS-4 tree hash, computed by the adapter itself (B-35):
    sha256 over the canonical {relpath: file sha256} map."""
    root = Path(tree_dir)
    members = {}
    for p in sorted(root.rglob("*")):
        if p.is_file() and not p.is_symlink():
            members[str(p.relative_to(root))] = sha256_file(p)
    return sha256_bytes(canonical(members)), members


def compute_state(freeze, submissions, adjudication=None, charter=None,
                  auditing_operator=None, tree_dir=None,
                  artifact_files=None, anchor_evidence=None):
    """Design §4.8 C-3, with the A-13 anchoring cap and the v1.1
    content binding (B-35): FULL requires the adapter to hash a
    presented tree equal to the freeze record's tree_hash, presented
    submission/adjudication/charter FILES whose hashes the freeze
    record declares, and anchor evidence that is a content-bound
    record naming the exact head/tree hash it anchors. A bare string
    anchor is UNANCHORED and caps the state at PARTIAL. Returns
    (state, notes, anchor_status)."""
    notes = []
    if not freeze:
        return "NOT RUN", ["no freeze record — where only the spec is "
                           "present, the status is NOT RUN (C-4); the "
                           "adapter cannot manufacture a frozen target "
                           "(C-2)"], "UNANCHORED"
    if freeze.get("authored_in_session"):
        return "SIMULATED", ["freeze record authored inside the audit "
                             "session — a trial of one's own target in "
                             "one session is SIMULATED by construction "
                             "(C-2)"], "UNANCHORED"
    ops = [s.get("operator") for s in submissions]
    if auditing_operator and auditing_operator in ops:
        return "SIMULATED", ["a submission's operator is the auditing "
                             "operator (C-3)"], "UNANCHORED"
    if len(set(ops)) != len(ops) and len(ops) >= 2:
        return "SIMULATED", ["both benches name the same operator — a "
                             "house exercise, honestly labelled (C-3)"], \
            "UNANCHORED"
    missing = []
    if not self_hash_ok(freeze, "record_sha256"):
        missing.append("freeze record self-hash does not verify")
    if not is_hash(freeze.get("tree_hash")):
        missing.append("freeze record carries no frozen-tree hash")
    anchor = freeze.get("anchor") or {}
    if not anchor.get("record"):
        missing.append("freeze record is UNVERIFIED: no external "
                       "anchor reference (A-13)")
    benches = {s.get("bench") for s in submissions}
    if len(submissions) < 2 or len(benches) < 2:
        missing.append("fewer than two bench submissions")
    for s in submissions:
        if not is_hash(s.get("outputs_sha256")):
            missing.append(f"submission {s.get('bench')}: outputs not "
                           "hash-sealed")
        if not self_hash_ok(s, "seal_sha256"):
            missing.append(f"submission {s.get('bench')}: seal does "
                           "not verify")
    if not adjudication or adjudication.get("blind") is not True:
        missing.append("no blind adjudication record")
    elif adjudication.get("adjudicator") in ops:
        missing.append("adjudicator ran a bench (C-1 (v))")
    if not charter or not is_hash(charter.get("text_sha256")):
        missing.append("no charter-integrity record")
    # --- v1.1 content binding (B-35) --------------------------------
    anchor_status = "UNANCHORED"
    if tree_dir is None:
        missing.append("TREE-NOT-PRESENTED: FULL requires the "
                       "adapter to hash the frozen tree itself; "
                       "without it the ceiling is PARTIAL")
    elif is_hash(freeze.get("tree_hash")):
        computed, _ = tree_hash_of(tree_dir)
        if computed != freeze["tree_hash"]:
            missing.append("presented tree's computed hash differs "
                           "from the freeze record's tree_hash")
    declared = freeze.get("artifact_hashes") or {}
    artifact_files = artifact_files or {}
    for bench, path in sorted(artifact_files.items()):
        if bench in ("adjudication", "charter"):
            continue
        want = declared.get("submissions", {}).get(bench)
        if not want:
            missing.append(f"freeze record declares no hash for "
                           f"submission {bench} — the presented file "
                           f"cannot be content-bound")
        elif sha256_file(path) != want:
            missing.append(f"submission {bench}: presented file's "
                           f"hash differs from the freeze record's "
                           f"declaration")
    for name in ("adjudication", "charter"):
        path = artifact_files.get(name)
        if path is None:
            continue
        want = declared.get(name)
        if not want:
            missing.append(f"freeze record declares no hash for the "
                           f"{name} — the presented file cannot be "
                           f"content-bound")
        elif sha256_file(path) != want:
            missing.append(f"{name}: presented file's hash differs "
                           f"from the freeze record's declaration")
    if anchor_evidence is not None:
        names = {anchor_evidence.get("anchors_head"),
                 anchor_evidence.get("tree_hash"),
                 anchor_evidence.get("anchors_tree_hash")}
        if freeze.get("tree_hash") in names or \
                freeze.get("head") in names:
            anchor_status = "UNVERIFIED-EXTERNAL"
        else:
            missing.append("anchor evidence does not name the "
                           "freeze record's head/tree hash — not "
                           "content-bound")
    else:
        missing.append("no content-bound anchor evidence record "
                       "presented (a bare string anchor is "
                       "UNANCHORED, A-13/B-35)")
    if missing:
        return "PARTIAL", ["missing or unverified C-3 elements:"] + \
            [f"  - {m}" for m in missing], anchor_status
    return "FULL", ["C-3 complete, content-bound (B-35): the "
                    "adapter hashed the presented tree and files "
                    "against the freeze record's declarations; two "
                    "sealed submissions from distinct operators; a "
                    "blind adjudication record; a charter-integrity "
                    "record"], anchor_status


def main(argv=None):
    ap = argparse.ArgumentParser(prog="crucible_adapter")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("state")
    p.add_argument("--freeze-record", help="JSON freeze record, if any")
    p.add_argument("--submissions", nargs="*", default=[],
                   help="submission manifest JSON files")
    p.add_argument("--adjudication", help="blind adjudication record JSON")
    p.add_argument("--charter", help="charter-integrity record JSON")
    p.add_argument("--auditing-operator")
    p.add_argument("--tree",
                   help="the frozen tree directory; the adapter "
                        "hashes it itself (B-35)")
    p.add_argument("--anchor-evidence",
                   help="JSON record naming the exact head/tree hash "
                        "it anchors (content-bound evidence)")
    p.add_argument("--out")
    p.add_argument("--behaviours", action="store_true")
    p = sub.add_parser("template")
    p.add_argument("--target", required=True)
    p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    print(DISC)
    if a.cmd == "template":
        tpl = {"template": "AAVEP-CRUCIBLE-TARGET-CONFIG",
               "status": "TEMPLATE — UNFROZEN (the adapter cannot freeze "
                         "a target; freezing is the author's act, C-2)",
               "target": a.target,
               "required_config_C1": [
                   "(i) an author-frozen target tree + its hash",
                   "(ii) a target freeze record (the kit's FREEZE_RECORD "
                   "template, completed)",
                   "(iii) an examiner packet derived from GS-4 with the "
                   "target substituted — a derivation the author must "
                   "approve",
                   "(iv) a mutation set registered against the target",
                   "(v) a named adjudicator who runs neither arm"],
               "freeze": None}
        Path(a.out).write_text(json.dumps(tpl, indent=1), encoding="utf-8")
        print(f"template written: {a.out} (UNFROZEN)")
        return 0
    if getattr(a, "behaviours", False):
        print(json.dumps(behaviours_for("crucible_adapter"),
                         indent=1))
        return 0
    freeze = None
    if a.freeze_record and Path(a.freeze_record).is_file():
        freeze = json.loads(Path(a.freeze_record).read_text())
    subs = [json.loads(Path(s).read_text()) for s in a.submissions]
    adj = json.loads(Path(a.adjudication).read_text()) \
        if a.adjudication and Path(a.adjudication).is_file() else None
    charter = json.loads(Path(a.charter).read_text()) \
        if a.charter and Path(a.charter).is_file() else None
    artifact_files = {}
    for s_path, s_doc in zip(a.submissions, subs):
        if s_doc.get("bench"):
            artifact_files[s_doc["bench"]] = s_path
    af = {}
    for bench, path in artifact_files.items():
        af[bench] = path
    if a.adjudication:
        af["adjudication"] = a.adjudication
    if a.charter:
        af["charter"] = a.charter
    evidence = None
    if a.anchor_evidence and Path(a.anchor_evidence).is_file():
        evidence = json.loads(Path(a.anchor_evidence).read_text())
    state, notes, anchor_status = compute_state(
        freeze, subs, adj, charter, a.auditing_operator,
        tree_dir=a.tree, artifact_files=af, anchor_evidence=evidence)
    state_line = f"{state} · anchor {anchor_status}"
    out = {"crucible_state": state, "state_line": state_line,
           "anchor_status": anchor_status, "notes": notes,
           "freeze_record": freeze, "submissions": subs}
    print(state_line)
    print(json.dumps(out, indent=1))
    if a.out:
        Path(a.out).write_text(json.dumps(out, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
