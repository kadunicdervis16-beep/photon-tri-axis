#!/usr/bin/env python3
"""aavep_index_export — target index -> manifest draft + claim inventory.

INPUT_PROVENANCE:
  paper-defined:       the target package's own index file and suite
                       runner — the only inputs; their contents are
                       transcribed, never interpreted.
  cited-paper:         NONE.
  control:             the export rules of the design §3/§4.11 (the
                       manifest is built FROM the target's own
                       enumeration so the completeness gate has a
                       surface to check against).
  declared-assumption: the draft's timeouts (420 s, the shipped plugin
                       default the house suites use) and the
                       coverage-type defaults are starting declarations
                       for the manifest author to confirm or correct;
                       the draft says so in its own header.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: a target package's machine-readable index.
  (2) Verified domain: transcription fidelity — every indexed claim and
      every runner-listed instrument appears in the draft exactly once.
  (3) Map: index JSON + runner source -> manifest draft JSON + claim
      inventory JSON.
  (4) What the map preserves: the target's own enumeration of its
      claims and instruments — the gate's surface.
  (5) What stays outside the machine check: source locks, site pins,
      coverage typing, and authority transcription. Those are authored
      declarations the draft leaves explicitly blank; an exported draft
      is NOT a runnable manifest until a human completes it.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import disclosure, sha256_file  # noqa: E402

DISC = disclosure(
    "a target package's machine-readable index",
    "transcription fidelity of claims and runner-listed instruments",
    "index JSON + runner source -> manifest draft + claim inventory",
    "the target's own enumeration of its claims and instruments",
    "source locks, site pins, coverage typing, authority transcription "
    "— left blank for the manifest author")


def claim_section(claim_id: str) -> str:
    m = re.match(r"L(\d+)(?:\.(\d+))?", claim_id)
    if not m:
        return "?"
    return f"§{m.group(1)}" + (f".{m.group(2)}" if m.group(2) else "")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_index_export")
    ap.add_argument("--index", required=True)
    ap.add_argument("--runner", required=True)
    ap.add_argument("--manuscript", required=True)
    ap.add_argument("--out-manifest", required=True)
    ap.add_argument("--out-inventory", required=True)
    a = ap.parse_args(argv)
    print(DISC)
    idx = json.loads(Path(a.index).read_text(encoding="utf-8"))
    runner_src = Path(a.runner).read_text(encoding="utf-8",
                                          errors="replace")
    script_files = sorted(set(re.findall(r'"([A-Za-z0-9_]+\.py)"',
                                         runner_src)))
    instruments = []
    for f in script_files:
        if f == Path(a.runner).name:
            continue
        stem = f[:-3]
        instruments.append({
            "id": stem, "kind": "suite_script", "path": f"scripts/{f}",
            "runner": Path(a.runner).name, "timeout_s": 420,
            "pass_exit_codes": [0], "sources": [],
            "_note": "DRAFT — declare sources[] (every external read) "
                     "before this manifest can lock."})
    claims = []
    raw_claims = idx.get("claims") or []
    if isinstance(idx.get("claim_lists"), dict):
        raw_claims = [{"id": k, "section": v.get("home")}
                      for k, v in idx["claim_lists"].items()]
    for c in raw_claims:
        cid = c.get("id") or c.get("claim_id")
        claims.append({"claim_id": cid,
                       "section": c.get("section") or claim_section(cid),
                       "coverage": [],
                       "_note": "DRAFT — author the coverage map "
                                "(substantive/correspondence) or an "
                                "unresolved_reason per claim."})
    draft = {
        "_draft": "AAVEP MANIFEST DRAFT — exported from the target's own "
                  "index. NOT runnable until sources, site pins, "
                  "coverage, and the authority transcription are "
                  "authored and preflight verifies them.",
        "aavep_version": "1.0",
        "target": {"manuscript_path": Path(a.manuscript).name,
                   "manuscript_sha256": sha256_file(a.manuscript)},
        "suite_runner": {"path": Path(a.runner).name, "timeout_s": 420},
        "instruments": instruments,
        "claims": claims}
    Path(a.out_manifest).write_text(json.dumps(draft, indent=1),
                                    encoding="utf-8")
    inventory = {"claims": len(claims),
                 "conditions": len(idx.get("conditions", [])),
                 "inheritance_lines": len(idx.get("inheritance_lines", [])),
                 "claim_ids": [c["claim_id"] for c in claims]}
    Path(a.out_inventory).write_text(json.dumps(inventory, indent=1),
                                     encoding="utf-8")
    print(f"draft manifest: {len(instruments)} instruments, "
          f"{len(claims)} claims -> {a.out_manifest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
