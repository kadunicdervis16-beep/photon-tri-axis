#!/usr/bin/env python3
"""aavep_selftest — the AAVEP v1.1 kit's own verification suite.

INPUT_PROVENANCE:
  paper-defined:       NONE. All fixtures are synthetic miniatures
                       generated inside this file.
  cited-paper:         NONE.
  control:             the behaviours asserted are the AAVEP v1.1
                       design's rules (DESIGN_PROPOSAL_v1.1.md as
                       amended B-1..B-38), including the developer
                       test's executed probes re-run against v1.1
                       mechanisms (P1 forge, P2 fixture tamper, P3
                       ghost ledger, P5 confinement set, P6 overall
                       flip) and the differential property case for
                       overall_status (B-33). Case ids are the
                       pinning cases named by the behaviour registry
                       in aavep_lib; the meta-case at the end asserts
                       every registry key's cases exist in this suite.
  declared-assumption: the vendored ESP conformance battery runs as
                       shipped under its own freeze.
  arbitrary-representative: operator names, claim ids, and payloads
                       in the fixtures are arbitrary representatives
                       of their classes.

FIVE-PART DISCLOSURE:
  (1) Native domain: the kit's tools (cal, ledger, preflight,
      runner, report, adapter, docs).
  (2) Verified domain: the design's machine-checkable rules over
      synthetic fixtures, including planted mutants.
  (3) Map: each case drives the real CLI or the real library
      function and asserts on observable output.
  (4) What the map preserves: custody separation, derivation
      parity, chain tamper-evidence, the degraded rungs, and
      report/bundle correspondence.
  (5) What stays outside the machine check: behaviour on real
      packages at scale (the demonstration's record is that
      evidence) and every judgement an agent makes inside the
      machinery.
"""
from __future__ import annotations

import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import (BEHAVIOUR_REGISTRY, canonical, disclosure,  # noqa: E402
                       is_cache_path, lint_manifest_entries,
                       overall_status, sha256_bytes, sha256_file)
import aavep_cal  # noqa: E402
import aavep_ledger  # noqa: E402
import aavep_preflight  # noqa: E402
import aavep_run  # noqa: E402
import crucible_adapter  # noqa: E402

DISC = disclosure(
    "the kit's tools over synthetic fixtures",
    "the v1.1 design's machine-checkable rules, incl. the developer "
    "probes re-run as cases",
    "real CLI / library calls asserted on observable output",
    "custody separation, derivation parity, chain tamper-evidence, "
    "degraded rungs, report correspondence",
    "behaviour on real packages at scale (the demonstration's "
    "record is that evidence)")

TOOLS = Path(__file__).resolve().parent
KIT = TOOLS.parent
RESULTS = []
CASES_RUN = []


def check(case, name, cond, detail=""):
    CASES_RUN.append(case)
    RESULTS.append((f"{case}: {name}", bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {case}: {name}"
          + (f" — {detail}" if detail and not cond else ""))


def cli(*args, expect=None, env=None, timeout=900):
    e = dict(os.environ)
    if env:
        e.update(env)
    p = subprocess.run([sys.executable] + [str(a) for a in args],
                       capture_output=True, text=True, timeout=timeout,
                       env=e)
    return p


def gen_kit_manifest(root: Path):
    """The freeze rule: every file except the manifest itself, the
    freeze record, the anchor, caches, and demo evidence workspaces
    (those carry their own bundle manifests)."""
    root = Path(root)
    lines = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.is_symlink():
            continue
        rel = str(p.relative_to(root))
        if rel in ("AAVEP_MANIFEST.sha256", "ANCHOR.txt") or \
                rel.startswith("AAVEP_FREEZE") or \
                rel.startswith("demo/evidence/") or \
                is_cache_path(rel):
            continue
        lines.append(f"{sha256_file(p)}  {rel}")
    (root / "AAVEP_MANIFEST.sha256").write_text(
        "\n".join(lines) + "\n")
    return len(lines)


# ------------------------------------------------------------------
# toy package

def toy_package(root: Path, scripts):
    """scripts: {relpath: text}. Returns (pkg_dir, manifest_path)."""
    pkg = root / "pkg"
    pkg.mkdir(parents=True, exist_ok=True)
    (pkg / "manuscript.md").write_text(
        "# Toy target\n\n## Registry\n\n| claim | badge |\n"
        "|---|---|\n| TOY-1 | [LEVEL A] |\n")
    for rel, text in scripts.items():
        p = pkg / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    entries = {}
    for p in sorted(pkg.rglob("*")):
        if p.is_file():
            entries[str(p.relative_to(pkg))] = sha256_file(p)
    (pkg / "MANIFEST.sha256").write_text(
        "".join(f"{h}  {r}\n" for r, h in entries.items()))
    return pkg


def toy_manifest(root: Path, pkg: Path, instruments, extra=None):
    man = {"aavep_version": "1.1",
           "target": {"manuscript_path": "manuscript.md",
                      "manuscript_sha256": sha256_file(
                          pkg / "manuscript.md"),
                      "package_manifest_path": "MANIFEST.sha256",
                      "package_manifest_sha256": sha256_file(
                          pkg / "MANIFEST.sha256"),
                      "package_subdir": ""},
           "instruments": instruments, "claims": []}
    if extra:
        man.update(extra)
    mp = root / "manifest.json"
    mp.write_text(json.dumps(man, indent=1))
    return mp


def suite_inst(iid, rel, **kw):
    d = {"id": iid, "kind": "suite_script", "path": rel,
         "timeout_s": kw.pop("timeout_s", 60)}
    d.update(kw)
    return d


def run_toy(kit_tools, manifest, pkg, ws, extra_args=(), env=None):
    return cli(kit_tools / "aavep_run.py", "--manifest", manifest,
               "--package", pkg, "--workspace", ws,
               "--house-root", os.environ.get("HOME", "/nonexistent"),
               *extra_args, env=env, timeout=1200)


def statuses_of(ws):
    return json.loads((Path(ws) / "statuses.json").read_text())


# ------------------------------------------------------------------
# CAL v2 cases

def perfect_responses(key, fixtures):
    """The honest-perfect subject for the ported v1 trap engine."""
    src = fixtures["T5/source_registry.md"]
    tgt = fixtures["T5/target_excerpt.md"]
    lines = src.splitlines()
    la = key["T5"]["reg_line_no"]
    span = [1, len(lines)]
    tq = next(ln for ln in tgt.splitlines()
              if key["T5"]["target_badge"] in ln)
    return {
        "T1": {"verdict": key["T1"]["correct_verdict"],
               "source_used": "published",
               "finding_filed": key["T1"]["correct_finding"]},
        "T2": {"status": "BLOCKED", "finding_filed": False},
        "T3": {"status": "BLOCKED", "check_run": False,
               "citation": key["T3"]["citation"]},
        "T4": {"status": "TIMEOUT", "paper_defect": False},
        "T5": {"defect_present": True,
               "packet": {"finding_id": "X1",
                          "claim_id": key["T5"]["claim"],
                          "rule_cited": "registry governs",
                          "witness": {
                              "source_id": "fixture-registry",
                              "source_sha256":
                                  key["T5"]["source_sha256"],
                              "verbatim_quote":
                                  key["T5"]["source_badge"],
                              "line_address": la,
                              "enclosing_heading":
                                  key["T5"]["heading"],
                              "section_span": span,
                              "section_sha256": sha256_bytes(
                                  "\n".join(
                                      lines[span[0] - 1:span[1]]
                                  ).encode())},
                          "target_quote": tq.strip(),
                          "expected": key["T5"]["source_badge"],
                          "observed": key["T5"]["target_badge"]}},
        "T6": {"finding_filed": False, "self_overturned": False,
               "evidence_heading": key["T6"]["heading"]}}


def perfect_responses_v2(admin_dir):
    secret, record, opening = aavep_cal._load_admin(Path(admin_dir))
    fixtures, key = aavep_cal._derive(secret)
    return perfect_responses(key, fixtures)


def cal_session(tmp, operator="op-a", op_principal="principal-a",
                admin="adm-a", adm_principal="principal-adm"):
    adm, subj = tmp / "admin", tmp / "subj"
    rec = aavep_cal.new_session(adm, subj, operator, op_principal,
                                admin, adm_principal)
    resp = perfect_responses_v2(adm)
    (subj / "responses.json").write_text(json.dumps(resp))
    tr, receipt = aavep_cal.score_session_v2(
        adm, subj, subj / "responses.json", tmp / "transcript.json")
    return adm, subj, rec, tr, receipt


def test_cal(tmp):
    adm, subj, rec, tr, receipt = cal_session(tmp / "c1")
    check("cal2-subject-tree-clean", "subject tree carries no secret "
          "material", all(
              rec["secret_commitment"] not in p.read_text(
                  errors="replace")
              and "secret_hex" not in p.read_text(errors="replace")
              for p in subj.rglob("*") if p.is_file()))
    p = cli(TOOLS / "aavep_cal.py", "new", "--seed", "7",
            "--admin-dir", tmp / "x", "--subject-dir", tmp / "y",
            "--operator", "o", "--operator-principal", "p",
            "--administrator", "a", "--administrator-principal", "q")
    check("cal2-no-seed-interface", "the v2 interface has no --seed "
          "(argparse refuses)", p.returncode != 0)
    check("cal2-commitment-binds-fixtures", "receipt commitment "
          "equals the administrator opening record",
          receipt["session_commitment"] == rec["session_commitment"])
    # P2: fixture tamper between issue and score
    adm2, subj2, rec2, _, _ = cal_session(tmp / "c2")
    victim = subj2 / "T1" / "staging_registry.md"
    victim.write_text(victim.read_text() + "\ntampered\n")
    p = cli(TOOLS / "aavep_cal.py", "score", "--admin-dir", adm2,
            "--subject-dir", subj2, "--responses",
            subj2 / "responses.json", "--transcript-out",
            tmp / "c2" / "t.json")
    check("cal2-fixture-tamper", "tampered fixture fails the session "
          "(FIXTURE-INTEGRITY-FAIL, no tier)",
          p.returncode != 0 and "FIXTURE-INTEGRITY-FAIL"
          in (p.stdout + p.stderr))
    check("cal2-receipt-allowlist", "published receipt fields are "
          "exactly the allowlist",
          set(receipt) <= aavep_cal.PUBLISHED_RECEIPT_FIELDS)
    bad_tree = tmp / "pub"
    bad_tree.mkdir()
    (bad_tree / "receipt.json").write_text(json.dumps(
        {**receipt, "seed": 1202}))
    good_tree = tmp / "pub2"
    good_tree.mkdir()
    (good_tree / "receipt.json").write_text(json.dumps(receipt))
    check("docs-redact-check", "redact-check fails a seed-bearing "
          "tree and passes a conforming one",
          aavep_cal.redact_check(bad_tree) != []
          and aavep_cal.redact_check(good_tree) == [])
    adm3, subj3, rec3, _, _ = cal_session(
        tmp / "c3", op_principal="same-principal",
        adm_principal="same-principal")
    check("cal2-grade-principal-keyed", "same principal in both "
          "roles grades SELF-ADMINISTERED despite distinct labels",
          rec3["administration_grade"] == "SELF-ADMINISTERED")
    keys_f = tmp / "c1" / "keys.json"
    aavep_cal.publish_keys(adm, keys_f)
    res = aavep_cal.verify_receipt(
        receipt, keys_path=keys_f, fixtures_dir=subj,
        responses_path=subj / "responses.json")
    check("cal2-key-publication", "published keys make the receipt "
          "publicly re-scorable (RESCORED)",
          res["outcome"] == "RESCORED")
    res = aavep_cal.verify_receipt(receipt)
    check("cal2-key-publication", "bare receipt without custody "
          "material is UNVERIFIED", res["outcome"] == "UNVERIFIED")
    # regression (v1.1 demonstration): a redacted published-form
    # admin record (no secret) presented WITH published keys must
    # grade by the keys, not error out to UNVERIFIED.
    redacted = tmp / "redacted_admin"
    redacted.mkdir()
    for f in ("admin_record.json", "opening_record.json"):
        (redacted / f).write_text((adm / f).read_text())
    res = aavep_cal.verify_receipt(
        receipt, admin_dir=redacted, subject_dir=subj,
        responses_path=subj / "responses.json", keys_path=keys_f,
        fixtures_dir=subj)
    check("cal2-redacted-admin-fallback", "redacted admin record "
          "falls through to published keys (RESCORED)",
          res["outcome"] == "RESCORED", res.get("reason", ""))
    # loop-pass repairs (red team P2-extra / N2): an extra file
    # invalidates; a constructor keys file passes redact-check;
    # key publication upgrades the receipt's disclosure.
    adm4, subj4 = tmp / "c4" / "admin", tmp / "c4" / "subj"
    aavep_cal.new_session(adm4, subj4, "op-x", "principal-x",
                          "adm-x", "principal-admx")
    (subj4 / "responses.json").write_text(json.dumps(
        perfect_responses_v2(adm4)))
    (subj4 / "T1" / "evil_extra.txt").write_text("planted\n")
    p = cli(TOOLS / "aavep_cal.py", "score", "--admin-dir", adm4,
            "--subject-dir", subj4, "--responses",
            subj4 / "responses.json", "--transcript-out",
            tmp / "c4" / "t.json")
    check("cal2-extra-file-invalid", "an extra file in the subject "
          "tree invalidates the session (no tier)",
          p.returncode != 0 and "FIXTURE-INTEGRITY-FAIL"
          in (p.stdout + p.stderr))
    pub = tmp / "pubtree"
    pub.mkdir()
    (pub / "keys.json").write_text(keys_f.read_text())
    (pub / "receipt.json").write_text(json.dumps(
        aavep_cal.mark_keys_published(receipt)))
    check("cal2-redact-keys-exempt", "redact-check passes a "
          "published tree carrying a constructor keys file and a "
          "published receipt", aavep_cal.redact_check(pub) == [])
    upgraded = aavep_cal.mark_keys_published(receipt)
    res = aavep_cal.verify_receipt(
        upgraded, keys_path=keys_f, fixtures_dir=subj,
        responses_path=subj / "responses.json")
    check("cal2-key-disclosure-upgrade", "key publication upgrades "
          "key_disclosure to published; the grade is unchanged",
          upgraded["key_disclosure"] == "published"
          and res["outcome"] == "RESCORED")
    # loop-pass repair (DA-7): with an administrator record
    # presented, the keys path anchors fixture bytes to it — a
    # tampered fixture cannot reach RESCORED through the
    # fallback.
    subj_t = tmp / "subj_tampered"
    shutil.copytree(subj, subj_t)
    victim = subj_t / "T1" / "staging_registry.md"
    victim.write_text(victim.read_text() + "\ntampered\n")
    res = aavep_cal.verify_receipt(
        receipt, admin_dir=redacted, subject_dir=subj_t,
        responses_path=subj / "responses.json", keys_path=keys_f,
        fixtures_dir=subj_t)
    check("cal2-fallback-fixture-anchor", "tampered fixture "
          "under a redacted administrator record grades "
          "UNVERIFIED, not RESCORED",
          res["outcome"] == "UNVERIFIED", res.get("reason", ""))
    # loop-pass repair (DA-1): attempt lineage — an official
    # re-run after a FAIL caps PASS at CONDITIONAL, the lineage
    # persists in the administrator record, and the capped
    # receipt still re-scores.
    adm5, subj5 = tmp / "c5" / "admin", tmp / "c5" / "subj"
    aavep_cal.new_session(adm5, subj5, "op-y", "principal-y",
                          "adm-y", "principal-admy")
    bad = perfect_responses_v2(adm5)
    bad["T1"]["verdict"] = "NO DEFECT" \
        if bad["T1"]["verdict"] != "NO DEFECT" else "DEFECT"
    bad["T5"]["defect_present"] = False
    (subj5 / "responses.json").write_text(json.dumps(bad))
    tr1, _ = aavep_cal.score_session_v2(
        adm5, subj5, subj5 / "responses.json", tmp / "c5" / "t1.json")
    (subj5 / "responses.json").write_text(json.dumps(
        perfect_responses_v2(adm5)))
    tr2, rec2y = aavep_cal.score_session_v2(
        adm5, subj5, subj5 / "responses.json", tmp / "c5" / "t2.json")
    res = aavep_cal.verify_receipt(
        rec2y, admin_dir=adm5, subject_dir=subj5,
        responses_path=subj5 / "responses.json")
    check("cal2-reattempt-cap", "official re-run after a FAIL "
          "caps at CONDITIONAL (attempt 2, lineage persisted); "
          "the capped receipt re-scores RESCORED",
          tr1["tier"] == "FAIL" and tr2["tier"] == "CONDITIONAL"
          and tr2["attempt"] == 2
          and res["outcome"] == "RESCORED")


def test_cal_legacy(tmp):
    sess = tmp / "v1sess"
    sess.mkdir()
    fixtures, key = aavep_cal.gen_fixtures(7)
    for rel, text in fixtures.items():
        p = sess / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    (sess / "session.json").write_text(json.dumps({
        "seed": 7, "operator": "legacy-op", "version": "1",
        "fixture_hashes": {rel: sha256_bytes(t.encode())
                           for rel, t in fixtures.items()},
        "key_sha256": sha256_bytes(canonical(key))}))
    resp = perfect_responses(key, fixtures)
    tr = aavep_cal.score_session(sess, resp)
    check("cal1-legacy-rescore", "v1 session re-scores PASS under "
          "the legacy path", tr["tier"] == "PASS"
          and tr["version"] == "1")


# ------------------------------------------------------------------
# ledger cases

def genesis_payload(receipts):
    return {"target_sha256": "a" * 64, "manifest_sha256": "b" * 64,
            "calibration_receipts": receipts,
            "report_fields": {"sender": "selftest",
                              "target_agent": "reader",
                              "session_id": "selftest-1",
                              "anchor": "UNANCHORED"}}


def test_ledger(tmp):
    led = tmp / "led.jsonl"
    aavep_ledger.append(led, "SESSION_OPEN", "coord",
                        genesis_payload([{
                            "operator": "filer-a", "tier": "PASS",
                            "transcript_sha256": "c" * 64}]))
    aavep_ledger.append(led, "FINDING_FILED", "filer-a",
                        {"finding_id": "F1",
                         "packet": {"finding_id": "F1"}})
    aavep_ledger.append(led, "ADJUDICATION", "coord",
                        {"finding_id": "F1", "outcome": "SUSTAINED"})
    v = aavep_ledger.verify(led)
    check("ledger-lifecycle", "SUSTAINED before reproduction is a "
          "verification problem",
          any("before a successful reproduction" in p
              for p in v["problems"]))
    aavep_ledger.append(led, "FINDING_FILED", "filer-a",
                        {"finding_id": "F2",
                         "packet": {"finding_id": "F2"}})
    aavep_ledger.append(led, "REPRODUCTION_PHASE1", "repro-b",
                        {"finding_id": "F2",
                         "commitment_sha256": "d" * 64})
    aavep_ledger.append(led, "REPRODUCTION", "repro-b",
                        {"finding_id": "F2",
                         "outcome": "REPRODUCED_SAME_HOUSE"})
    aavep_ledger.append(led, "ADJUDICATION", "coord",
                        {"finding_id": "F2", "outcome": "SUSTAINED",
                         "countersignature": "coord"})
    v = aavep_ledger.verify(led)
    check("ledger-lifecycle", "same-house SUSTAINED with "
          "countersignature is effective",
          v["findings"]["F2"]["state"] == "SUSTAINED")
    aavep_ledger.append(led, "FINDING_FILED", "filer-a",
                        {"finding_id": "F3",
                         "packet": {"finding_id": "F3"}})
    aavep_ledger.append(led, "REPRODUCTION_PHASE1", "repro-b",
                        {"finding_id": "F3",
                         "commitment_sha256": "e" * 64})
    aavep_ledger.append(led, "REPRODUCTION", "repro-b",
                        {"finding_id": "F3",
                         "outcome": "REPRODUCED_INDEPENDENT"})
    aavep_ledger.append(led, "ADJUDICATION", "filer-a",
                        {"finding_id": "F3", "outcome": "SUSTAINED"})
    v = aavep_ledger.verify(led)
    check("ledger-lifecycle", "role-conflicted adjudication is void",
          v["findings"]["F3"]["state"] == "UNRESOLVED"
          and v["findings"]["F3"]["adjudication"]["effect"]
          == "VOID_ROLE_CONFLICT")
    # P3: a fictional ledger is internally consistent — the split
    # verdict must say so without grounding it. The ghost receipt
    # is fully self-consistent (its core recomputes; its
    # commitment sits in a genesis opening record): even a
    # perfect ghost caps at COMMITMENT-ONLY (loop pass: the
    # pre-repair fixture's non-recomputing core now grades
    # UNVERIFIED — that stricter behaviour is pinned by
    # ledger-ghost-receipt-unverified below).
    _gcore = {"session_id": "ghost-session",
              "session_commitment": "1" * 64,
              "operator_id": "ghost-op",
              "administrator_id": "ghost-adm",
              "trap_outcomes": {t: True for t in aavep_cal.TRAPS},
              "correct": 6, "total": 6, "tier": "PASS"}
    _gp = genesis_payload([{
        "battery": aavep_cal.BATTERY, "version": "2", **_gcore,
        "transcript_sha256": aavep_cal.sha256_bytes(
            aavep_cal.canonical(_gcore)),
        "responses_sha256": "e" * 64,
        "administration_grade": "ADMINISTERED",
        "key_disclosure": "withheld",
        "opening_record": "administrator-held"}])
    _gp["opening_record"] = {"session_commitment": "1" * 64}
    ghost = tmp / "ghost.jsonl"
    aavep_ledger.append(ghost, "SESSION_OPEN", "ghost-op", _gp)
    v2 = aavep_ledger.verify2(ghost)
    check("ledger-verdict-split", "fictional ledger: CHAIN-VALID, "
          "GENESIS UNGROUNDED, and its self-filed receipt grades no "
          "better than COMMITMENT-ONLY (grade CLAIMED, B-23)",
          v2["chain"] == "CHAIN-VALID"
          and v2["genesis"]["state"] == "GENESIS UNGROUNDED"
          and v2["receipts"][0]["grade"] == "COMMITMENT-ONLY")
    p = cli(TOOLS / "aavep_ledger.py", "verify", ghost, "--strict")
    check("ledger-verdict-split", "--strict refuses the ungrounded "
          "ghost ledger", p.returncode != 0)
    # P3b: re-chained edit passes naive verify, fails --expect-head
    orig_head = aavep_ledger.head(ghost)
    entries = aavep_ledger.load(ghost)
    entries[0]["payload"]["report_fields"]["sender"] = "mallory"
    from aavep_lib import canonical as _canon
    prev = "0" * 64
    lines = []
    for e in entries:
        e["prev_hash"] = prev
        body = {k: val for k, val in e.items() if k != "entry_hash"}
        e["entry_hash"] = sha256_bytes(prev.encode()
                                       + _canon(body))
        prev = e["entry_hash"]
        lines.append(json.dumps(e, ensure_ascii=False))
    ghost2 = tmp / "ghost2.jsonl"
    ghost2.write_text("\n".join(lines) + "\n")
    v2b = aavep_ledger.verify2(ghost2, expect_head=orig_head)
    check("ledger-rechain-expect-head", "re-chained ledger fails "
          "the externally supplied head pin",
          v2b["chain"] == "CHAIN-INVALID")
    # UNVERIFIED-ROOT by hash identity
    tree = tmp / "kittree"
    tree.mkdir()
    (tree / "AAVEP_FREEZE_test.md").write_text("freeze\n")
    anchor = tree / "ANCHOR.txt"
    anchor.write_text(f"head: {orig_head}\n")
    led3 = tree / "led.jsonl"
    aavep_ledger.append(led3, "SESSION_OPEN", "coord",
                        genesis_payload([{
                            "operator": "filer-a", "tier": "PASS",
                            "transcript_sha256": "c" * 64}]))
    v2c = aavep_ledger.verify2(led3, anchor_file=anchor,
                               intree_anchor_files=[anchor])
    check("ledger-unverified-root", "in-tree anchor is labelled "
          "UNVERIFIED-ROOT",
          any("UNVERIFIED-ROOT" in lbl
              for lbl in v2c["anchor_labels"]))
    # loop-pass repair (red team Defect 2): verify2's
    # COMMITMENT-ONLY requires a recomputing core AND the
    # commitment in a record independent of the receipt itself.
    def _ghost(commitment, core_ok):
        core = {"session_id": "ghost-session-1",
                "session_commitment": commitment,
                "operator_id": "ghost-op",
                "administrator_id": "ghost-adm",
                "trap_outcomes": {t: True for t in aavep_cal.TRAPS},
                "correct": 6, "total": 6, "tier": "PASS"}
        h = aavep_cal.sha256_bytes(aavep_cal.canonical(core)) \
            if core_ok else "3" * 64
        return {"battery": aavep_cal.BATTERY, "version": "2",
                **core, "transcript_sha256": h,
                "responses_sha256": "e" * 64,
                "administration_grade": "ADMINISTERED",
                "key_disclosure": "withheld",
                "opening_record": "administrator-held"}
    gc = "f" * 64
    gled = tmp / "ghost_r6a.jsonl"
    gp = genesis_payload([_ghost(gc, False)])
    gp["opening_record"] = {"session_commitment": gc}
    aavep_ledger.append(gled, "SESSION_OPEN", "coord", gp)
    ok = aavep_ledger.verify2(gled)["receipts"][0]["grade"] \
        == "UNVERIFIED"
    gled2 = tmp / "ghost_r6b.jsonl"
    aavep_ledger.append(gled2, "SESSION_OPEN", "coord",
                        genesis_payload([_ghost(gc, True)]))
    ok = ok and aavep_ledger.verify2(gled2)["receipts"][0][
        "grade"] == "UNVERIFIED"
    bdir = tmp / "gbundle_r6"
    bdir.mkdir()
    (bdir / "opening_record.json").write_text(json.dumps(
        {"session_commitment": gc}))
    ok = ok and aavep_ledger.verify2(
        gled2, bundle_dir=bdir)["receipts"][0]["grade"] \
        == "COMMITMENT-ONLY"
    check("ledger-ghost-receipt-unverified", "ghost genesis "
          "receipts grade UNVERIFIED (bad core; self-bound "
          "commitment); COMMITMENT-ONLY only with a recomputing "
          "core and an independent record", ok)
    # shipped v1.0 Setting H ledger under v1.1 tooling
    legacy = KIT / "legacy_fixtures" / "setting_h_ledger_v1.0.jsonl"
    if legacy.exists():
        v2d = aavep_ledger.verify2(legacy)
        check("ledger-verdict-split", "v1.0 Setting H ledger: "
              "CHAIN-VALID with LEGACY-CUSTODY receipt grades",
              v2d["chain"] == "CHAIN-VALID"
              and all(r["grade"] == "LEGACY-CUSTODY"
                      for r in v2d["receipts"]))


# ------------------------------------------------------------------
# runner cases

def test_runner(tmp, kit_tools):
    # expectation gate + degraded rungs + parity of derivation
    root = tmp / "gate"
    root.mkdir()
    pkg = toy_package(root, {
        "scripts/ok.py": "print('hello world')\n",
        "scripts/unc.py": "print('UNCHECKABLE 1 (source absent)')\n",
    })
    man = toy_manifest(root, pkg, [
        suite_inst("W-OK", "scripts/ok.py",
                   expect_stdout_contains=["hello"]),
        {"id": "W-TRUE", "kind": "command", "command": ["/bin/true"],
         "timeout_s": 30,
         "expect_stdout_contains": ["ZZZ-ABSENT"]},
        {"id": "W-ADV", "kind": "command",
         "command": ["/bin/echo", "done"], "timeout_s": 30,
         "expect_stdout_contains": [
             {"needle": "ZZZ-ABSENT", "advisory": True}]},
        suite_inst("W-UNC", "scripts/unc.py"),
    ])
    ws = root / "ws"
    p = run_toy(kit_tools, man, pkg, ws)
    st = statuses_of(ws)["statuses"]
    check("run-expectation-gate", "hard unmet expectation FAILS; "
          "advisory unmet and default marker degrade",
          p.returncode == 0
          and st["W-OK"]["status"] == "PASSED"
          and st["W-TRUE"]["status"] == "FAILED"
          and st["W-ADV"]["status"] == "PASSED-DEGRADED"
          and st["W-UNC"]["status"] == "PASSED-DEGRADED")
    check("run-confinement-printed", "statuses.json records the "
          "achieved confinement level",
          bool(statuses_of(ws).get("confinement")))
    # planter -> checker
    root = tmp / "plant"
    root.mkdir()
    pkg = toy_package(root, {
        "scripts/planter.py":
            "open('shared.txt','w').write('PLANTED-VALUE')\n"
            "print('planted')\n",
        "scripts/checker.py":
            "print(open('shared.txt').read())\n",
    })
    man = toy_manifest(root, pkg, [
        suite_inst("W-PLANT", "scripts/planter.py"),
        suite_inst("W-CHECK", "scripts/checker.py",
                   inputs=["shared.txt"],
                   expect_stdout_contains=["PLANTED-VALUE"]),
    ])
    ws = root / "ws"
    run_toy(kit_tools, man, pkg, ws)
    st = statuses_of(ws)["statuses"]
    check("run-planter-checker", "undeclared sibling consumption "
          "caps the checker at PASSED-DEGRADED",
          st["W-CHECK"]["status"] == "PASSED-DEGRADED"
          and "DEPENDENCY-UNDECLARED" in st["W-CHECK"]
          ["degradations"])
    man2 = toy_manifest(root, pkg, [
        suite_inst("W-PLANT", "scripts/planter.py"),
        suite_inst("W-CHECK", "scripts/checker.py",
                   inputs=["shared.txt"], consumes=["W-PLANT"],
                   expect_stdout_contains=["PLANTED-VALUE"]),
    ])
    ws2 = root / "ws2"
    run_toy(kit_tools, man2, pkg, ws2)
    st = statuses_of(ws2)["statuses"]
    check("run-planter-checker", "declared consumption passes clean",
          st["W-CHECK"]["status"] == "PASSED")
    # HOME redirect (P5 exfil channel closed)
    root = tmp / "home"
    root.mkdir()
    fakehome = root / "fakehome"
    fakehome.mkdir()
    (fakehome / "planted_secret.txt").write_text("SECRET-CONTENT")
    pkg = toy_package(root, {
        "scripts/probe.py":
            "import os\n"
            "p = os.path.join(os.environ['HOME'], "
            "'planted_secret.txt')\n"
            "print('HOME-IS', os.environ['HOME'])\n"
            "print('SECRET-READ' if os.path.exists(p) "
            "else 'SECRET-ABSENT')\n",
    })
    man = toy_manifest(root, pkg, [
        suite_inst("W-PROBE", "scripts/probe.py",
                   expect_stdout_contains=["SECRET-ABSENT"])])
    ws = root / "ws"
    p = run_toy(kit_tools, man, pkg, ws, env={"HOME": str(fakehome)})
    st = statuses_of(ws)["statuses"]
    check("run-home-redirect", "instrument sees the runner-owned "
          "HOME, never the operator's planted secret",
          st["W-PROBE"]["status"] == "PASSED")
    # output flood (P5): streamed, hashed, bounded in memory
    root = tmp / "flood"
    root.mkdir()
    pkg = toy_package(root, {
        "scripts/flood.py":
            "import sys\n"
            "sys.stdout.write('x' * 20_000_000)\n"})
    man = toy_manifest(root, pkg, [suite_inst("W-FLOOD",
                                              "scripts/flood.py")])
    ws = root / "ws"
    run_toy(kit_tools, man, pkg, ws)
    events = [json.loads(ln) for ln in
              (ws / "event_log.jsonl").read_text().splitlines()]
    ex = next(e for e in events if e.get("phase") == "execute")
    spill = (ws / "spill" / "W-FLOOD-1.out").read_bytes()
    check("run-output-flood", "20 MB stream: byte count and full "
          "hash recorded; spill is complete under the ceiling",
          ex["stdout_bytes"] == 20_000_000
          and ex["stdout_sha256"] == sha256_bytes(spill))
    # survivor sweep (P5): detached grandchild is killed at close
    root = tmp / "surv"
    root.mkdir()
    hb = root / "heartbeat.txt"
    pkg = toy_package(root, {
        "scripts/heartbeat.py": (
            "import sys, time\n"
            "while True:\n"
            "    open(sys.argv[1], 'a').write('x')\n"
            "    time.sleep(0.3)\n"),
        "scripts/spawn.py": (
            "import subprocess, sys, time\n"
            "subprocess.Popen([sys.executable, 'scripts/"
            "heartbeat.py', sys.argv[1]], start_new_session=True)\n"
            "time.sleep(30)\n")})
    man = toy_manifest(root, pkg, [
        suite_inst("W-SPAWN", "scripts/spawn.py", timeout_s=10)])
    # bake the heartbeat path into the spawn script (suite_script
    # argv carries no extra arguments); the parent outlives the
    # first attempt's 10 s budget but finishes inside the 2x retry
    (pkg / "scripts" / "spawn.py").write_text(
        "import subprocess, sys, time\n"
        "subprocess.Popen([sys.executable, 'scripts/heartbeat.py', "
        f"'{hb}'], start_new_session=True)\n"
        "time.sleep(12)\n")
    ws = root / "ws"
    run_toy(kit_tools, man, pkg, ws)
    events = [json.loads(ln) for ln in
              (ws / "event_log.jsonl").read_text().splitlines()]
    size1 = hb.stat().st_size if hb.exists() else 0
    time.sleep(1.6)
    size2 = hb.stat().st_size if hb.exists() else 0
    check("run-survivor-sweep", "detached grandchild swept: "
          "SURVIVOR event recorded and the heartbeat stops",
          any(e.get("phase") == "survivor" for e in events)
          and size1 == size2 and size1 > 0)
    # store placement: corrupted scratch is healed from the store
    root = tmp / "store"
    root.mkdir()
    pkg = toy_package(root, {
        "scripts/heal.py": "print('TRUE-BYTES')\n"})
    man = toy_manifest(root, pkg, [
        suite_inst("W-HEAL", "scripts/heal.py",
                   expect_stdout_contains=["TRUE-BYTES"])])
    ws = root / "ws"
    cli(kit_tools / "aavep_preflight.py", "--manifest", man,
        "--package", pkg, "--workspace", ws,
        "--house-root", os.environ.get("HOME", "/nonexistent"),
        "--out", ws / "locktable.json")
    scratch = ws / "scratch"
    shutil.copytree(pkg, scratch)
    (scratch / "scripts" / "heal.py").write_text(
        "print('CORRUPTED')\n")
    p = run_toy(kit_tools, man, pkg, ws)
    st = statuses_of(ws)["statuses"]
    check("run-store-bytes-placed", "executed bytes come from the "
          "store: a corrupted scratch copy is overwritten",
          st["W-HEAL"]["status"] == "PASSED")
    # manifest safety (P5): textual rejection at preflight
    root = tmp / "unsafe"
    root.mkdir()
    pkg = toy_package(root, {"scripts/a.py": "print('a')\n"})
    man = toy_manifest(root, pkg, [
        {"id": "W-ABS", "kind": "command",
         "command": ["/bin/cat", "/etc/passwd"], "timeout_s": 30},
        suite_inst("W-ESC", "../escape.py"),
    ])
    table, _ = aavep_preflight.compute_lock_table(
        man, pkg, root / "ws", os.environ.get("HOME", "/x"), False)
    # loop pass: {kit}-relative source locators resolve (the
    # placeholder was validated but never substituted in
    # resolve_locator, so such sources locked ABSENT).
    man_k = toy_manifest(root, pkg, [
        {"id": "W-KIT", "kind": "command", "command": ["/bin/true"],
         "timeout_s": 30,
         "sources": [{"source_id": "kit-license",
                      "role": "authoritative",
                      "locator": {"kind": "path",
                                  "value": "{kit}/LICENSE"},
                      "expected_sha256": sha256_file(
                          KIT / "LICENSE")}]}])
    table_k, _ = aavep_preflight.compute_lock_table(
        man_k, pkg, root / "ws2", os.environ.get("HOME", "/x"),
        False)
    check("preflight-kit-locator", "{kit}-relative source "
          "locator resolves and locks",
          table_k["instruments"]["W-KIT"]["sources"][0]["state"]
          == "LOCKED")
    check("run-manifest-unsafe", "absolute path outside reach and "
          "escaping suite path are MANIFEST-UNSAFE",
          sum("MANIFEST-UNSAFE" in p for p in table["problems"])
          >= 2)
    # runtime escape through a planted symlink
    root = tmp / "rtesc"
    root.mkdir()
    outside = root / "outside.txt"
    outside.write_text("OUTSIDE-SECRET")
    pkg = toy_package(root, {"scripts/a.py": "print('a')\n"})
    os.symlink(outside, pkg / "link_out.txt")
    man = toy_manifest(root, pkg, [
        {"id": "W-CAT", "kind": "command",
         "command": ["/bin/cat", "{scratch}/link_out.txt"],
         "timeout_s": 30}])
    ws = root / "ws"
    run_toy(kit_tools, man, pkg, ws)
    st = statuses_of(ws)["statuses"]
    check("run-runtime-escape", "symlink escape at execution is "
          "ESCAPE-REFUSED and FAILED",
          st["W-CAT"]["status"] == "FAILED")
    # preconditions: admin tree inside the workspace refuses (B-29)
    root = tmp / "admintree"
    root.mkdir()
    pkg = toy_package(root, {"scripts/a.py": "print('a')\n"})
    adm_dir = pkg / "cal_admin"
    adm_dir.mkdir()
    (adm_dir / "secret.json").write_text("{}")
    (adm_dir / "admin_record.json").write_text(json.dumps(
        {"battery": "AAVEP-CAL", "version": "2"}))
    man = toy_manifest(root, pkg, [suite_inst("W-A",
                                              "scripts/a.py")])
    ws = root / "ws"
    p = run_toy(kit_tools, man, pkg, ws)
    check("run-preconditions", "CAL administrator tree inside the "
          "run workspace refuses the run",
          p.returncode == 2 and "administrator tree" in p.stdout)
    # regression (v1.1 demonstration, synthetic run 1): a RELATIVE
    # --workspace double-resolved instrument argv against the
    # child's cwd and failed every instrument; the runner now
    # resolves the workspace and package root at entry.
    root = tmp / "relws"
    root.mkdir()
    pkg = toy_package(root, {"scripts/a.py": "print('rel-ok')\n"})
    man = toy_manifest(root, pkg, [suite_inst(
        "W-REL", "scripts/a.py",
        expect_stdout_contains=["rel-ok"])])
    p = subprocess.run(
        [sys.executable, str(kit_tools / "aavep_run.py"),
         "--manifest", str(man.relative_to(root)),
         "--package", str(pkg.relative_to(root)),
         "--workspace", "ws",
         "--house-root", os.environ.get("HOME", "/nonexistent")],
        cwd=root, capture_output=True, text=True, timeout=1200)
    st = statuses_of(root / "ws")["statuses"] \
        if (root / "ws" / "statuses.json").exists() else {}
    check("run-relative-workspace", "relative --workspace and "
          "--package paths run instruments correctly (no "
          "double-resolution against the child cwd)",
          p.returncode == 0
          and st.get("W-REL", {}).get("status") == "PASSED",
          (p.stdout + p.stderr)[-300:])


def test_gate0(tmp, kit_tools):
    root = tmp / "gate0"
    root.mkdir()
    pkg = toy_package(root, {"scripts/a.py": "print('a')\n"})
    man = toy_manifest(root, pkg, [suite_inst("W-A",
                                              "scripts/a.py")])
    # P1: a receipt minted from public material (core-consistent,
    # invented commitment) is UNVERIFIED at Gate 0.
    core = {"session_id": "forged", "session_commitment": "9" * 64,
            "operator_id": "mallory", "administrator_id": "mallory",
            "trap_outcomes": {t: True for t in aavep_cal.TRAPS},
            "correct": 6, "total": 6, "tier": "PASS"}
    forged = {"battery": "AAVEP-CAL", "version": "2",
              "session_id": "forged",
              "session_commitment": "9" * 64,
              "operator_id": "mallory", "administrator_id": "mallory",
              "operator_principal": "mallory",
              "administrator_principal": "mallory",
              "administration_grade": "ADMINISTERED", "tier": "PASS",
              "trap_outcomes": core["trap_outcomes"],
              "transcript_sha256": sha256_bytes(canonical(core)),
              "responses_sha256": "8" * 64,
              "key_disclosure": "withheld",
              "opening_record": "administrator-held"}
    rf = root / "forged.json"
    rf.write_text(json.dumps(forged))
    p = run_toy(kit_tools, man, pkg, root / "ws1",
                extra_args=("--receipt", rf))
    check("run-gate0-forged-receipt", "minted receipt refused at "
          "Gate 0 (UNVERIFIED, no custody material)",
          p.returncode == 2 and "UNVERIFIED" in p.stdout)
    # a real session's receipt, re-scored via published keys, opens
    adm, subj, rec, tr, receipt = cal_session(root / "real")
    keys_f = root / "real" / "keys.json"
    aavep_cal.publish_keys(adm, keys_f)
    receipt_f = root / "receipt.json"
    receipt_f.write_text(json.dumps(receipt))
    p = run_toy(kit_tools, man, pkg, root / "ws2",
                extra_args=("--receipt", receipt_f,
                            "--cal-keys", keys_f,
                            "--cal-subject-dir", subj))
    check("run-gate0-accepts-real", "real receipt re-scored from "
          "published keys opens the run",
          p.returncode == 0 and "RESCORED" in p.stdout)


# ------------------------------------------------------------------
# report cases

def build_bundle(tmp, kit_tools, with_bad_packet=False):
    """A complete toy bundle: CAL, ledger, run, and (optionally) a
    finding with a defective witness packet."""
    root = tmp
    adm, subj, rec, tr, receipt = cal_session(root / "cal")
    keys_f = root / "cal" / "keys.json"
    aavep_cal.publish_keys(adm, keys_f)
    pkg = toy_package(root, {
        "scripts/check.py":
            "print('registry verified')\n"})
    man = toy_manifest(root, pkg, [
        suite_inst("W-CHK", "scripts/check.py",
                   expect_stdout_contains=["registry verified"],
                   sources=[{
                       "source_id": "toy-manuscript",
                       "locator": {"kind": "path",
                                   "value": str(pkg
                                                / "manuscript.md")},
                       "expected_sha256": sha256_file(
                           pkg / "manuscript.md")}])])
    led = root / "ledger.jsonl"
    aavep_ledger.append(led, "SESSION_OPEN", "coord", {
        "target_sha256": sha256_file(pkg / "manuscript.md"),
        "manifest_sha256": sha256_file(man),
        "calibration_receipts": [receipt],
        "report_fields": {"sender": "selftest-filer",
                          "target_agent": "selftest-reader",
                          "session_id": "selftest-bundle",
                          "anchor": "UNANCHORED"}})
    ws = root / "ws"
    receipt_f = root / "receipt.json"
    receipt_f.write_text(json.dumps(receipt))
    p = run_toy(kit_tools, man, pkg, ws,
                extra_args=("--receipt", receipt_f,
                            "--cal-keys", keys_f,
                            "--cal-subject-dir", subj,
                            "--ledger", led))
    assert p.returncode == 0, p.stdout[-2000:]
    if with_bad_packet:
        lines = (pkg / "manuscript.md").read_text().splitlines()
        pkt = {"finding_id": "F-BAD", "claim_id": "TOY-1",
               "rule_cited": "registry governs",
               "witness": {"source_id": "toy-manuscript",
                           "source_sha256": sha256_file(
                               pkg / "manuscript.md"),
                           "verbatim_quote": "THIS LINE IS ABSENT",
                           "line_address": 1,
                           "enclosing_heading": lines[0],
                           "section_span": [1, len(lines)],
                           "section_sha256": sha256_bytes(
                               "\n".join(lines).encode())},
               "target_quote": lines[0], "expected": "x",
               "observed": "y"}
        aavep_ledger.append(led, "FINDING_FILED", "coord",
                            {"finding_id": "F-BAD", "packet": pkt})
    return root, man, pkg, ws, led, adm, subj, keys_f


def report_cli(kit_tools, mode, man, pkg, ws, led, root, **kw):
    args = [kit_tools / "aavep_report.py", mode,
            "--manifest", man, "--package", pkg, "--workspace", ws,
            "--ledger", led,
            "--house-root", os.environ.get("HOME", "/nonexistent"),
            "--cal-sessions", kw.get("sessions", root / "cal"),
            "--cal-keys", kw.get("keys", root / "cal")]
    if kw.get("envelope"):
        args += ["--envelope-out", kw["envelope"]]
    if kw.get("record"):
        args += ["--record-out", kw["record"]]
    return cli(*args, timeout=1200)


def test_report(tmp, kit_tools):
    root = tmp / "bundle"
    root.mkdir()
    _, man, pkg, ws, led, adm, subj, keys_f = build_bundle(
        root, kit_tools)
    rec_f, env_f = root / "record.json", root / "envelope.json"
    p = report_cli(kit_tools, "build", man, pkg, ws, led, root,
                   envelope=env_f, record=rec_f)
    record = json.loads(rec_f.read_text()) if rec_f.exists() else {}
    check("report-eventlog-binding", "report builds over a bound "
          "bundle with the event-log head recorded in the ledger",
          p.returncode == 0
          and record.get("integrity", {}).get("eventlog_binding")
          == "BOUND · UNANCHORED-BOUND")
    check("report-ghost-receipt", "real receipt grades RESCORED "
          "and the stamp is ENGINE-VALIDATED",
          record.get("stamp") == "ENGINE-VALIDATED"
          and record["integrity"]["receipt_grades"][0]["grade"]
          == "RESCORED")
    p = report_cli(kit_tools, "verify", man, pkg, ws, led, root,
                   envelope=env_f, record=rec_f)
    check("report-derive-all-parity", "verify recomputes the record "
          "and the envelope byte-identically", p.returncode == 0)
    # regression (v1.1 demonstration): verify with RELATIVE
    # --package/--workspace spellings (cwd = the bundle root) must
    # recompute the same lock table — recorded paths are
    # package-/workspace-relative, never spelling-dependent.
    p = subprocess.run(
        [sys.executable, str(kit_tools / "aavep_report.py"),
         "verify", "--manifest", str(Path(man).name),
         "--package", str(Path(pkg).name),
         "--workspace", str(Path(ws).name),
         "--ledger", str(Path(led).name),
         "--house-root", os.environ.get("HOME", "/nonexistent"),
         "--cal-sessions", "cal", "--cal-keys", "cal",
         "--envelope-out", "envelope.json",
         "--record-out", "record.json"],
        cwd=root, capture_output=True, text=True, timeout=1200)
    check("report-relative-paths", "verify with relative path "
          "spellings reproduces the record (lock table is "
          "spelling-independent)",
          p.returncode == 0, (p.stdout + p.stderr)[-300:])
    # P6: flip the recorded overall -> build refuses
    ws2 = root / "ws_flip"
    shutil.copytree(ws, ws2)
    sdoc = json.loads((ws2 / "statuses.json").read_text())
    sdoc["overall"] = "INCOMPLETE" if sdoc["overall"] == "COMPLETE" \
        else "COMPLETE"
    (ws2 / "statuses.json").write_text(json.dumps(sdoc))
    p = report_cli(kit_tools, "build", man, pkg, ws2, led, root,
                   envelope=root / "e2.json",
                   record=root / "r2.json")
    check("report-overall-flip", "hand-flipped overall refuses the "
          "report (OVERALL DIVERGENCE)", p.returncode != 0
          and "OVERALL DIVERGENCE" in p.stdout)
    # lock divergence: mutate the package post-run
    pkg2 = root / "pkg2"
    shutil.copytree(pkg, pkg2)
    (pkg2 / "scripts" / "check.py").write_text("print('x')\n")
    p = report_cli(kit_tools, "build", man, pkg2, ws, led, root,
                   envelope=root / "e3.json",
                   record=root / "r3.json")
    check("report-lock-divergence", "mutated package diverges the "
          "recomputed lock table", p.returncode != 0
          and "LOCKS DIVERGE" in p.stdout)
    # SL-2b in the verify path: bad witness packet in the ledger
    root2 = tmp / "bundle2"
    root2.mkdir()
    _, man2, pkg2b, ws2b, led2, _, _, _ = build_bundle(
        root2, kit_tools, with_bad_packet=True)
    p = report_cli(kit_tools, "build", man2, pkg2b, ws2b, led2,
                   root2, envelope=root2 / "e.json",
                   record=root2 / "r.json")
    check("report-sl2b-in-verify", "defective witness packet "
          "refuses the report (SL-2b applied in the pipeline)",
          p.returncode != 0 and "SL-2b" in p.stdout)


# ------------------------------------------------------------------
# adapter / docs / misc cases

def test_adapter(tmp):
    def sealed(obj, field="seal_sha256"):
        body = {k: v for k, v in obj.items() if k != field}
        obj[field] = sha256_bytes(canonical(body))
        return obj
    tree = tmp / "tree"
    tree.mkdir()
    (tree / "target.txt").write_text("frozen target\n")
    th, _ = crucible_adapter.tree_hash_of(tree)
    subs = []
    for bench, op in (("DA", "op-1"), ("RT", "op-2")):
        s = sealed({"bench": bench, "operator": op,
                    "outputs_sha256": "a" * 64})
        f = tmp / f"sub_{bench}.json"
        f.write_text(json.dumps(s))
        subs.append((bench, f, s))
    adj = {"blind": True, "adjudicator": "op-3"}
    adj_f = tmp / "adj.json"
    adj_f.write_text(json.dumps(adj))
    charter = {"text_sha256": "b" * 64}
    ch_f = tmp / "charter.json"
    ch_f.write_text(json.dumps(charter))
    freeze = {"tree_hash": th, "anchor": {"record": "zenodo:123"},
              "artifact_hashes": {
                  "submissions": {b: sha256_file(f)
                                  for b, f, _ in subs},
                  "adjudication": sha256_file(adj_f),
                  "charter": sha256_file(ch_f)}}
    freeze = sealed(freeze, "record_sha256")
    evidence = tmp / "evidence.json"
    evidence.write_text(json.dumps({"anchors_head": th}))
    docs = [s for _, _, s in subs]
    state, notes, anchor = crucible_adapter.compute_state(
        freeze, docs, adj, charter, tree_dir=None)
    check("adapter-full-requires-content", "self-consistent set "
          "without a presented tree is PARTIAL (TREE-NOT-PRESENTED)",
          state == "PARTIAL"
          and any("TREE-NOT-PRESENTED" in n for n in notes))
    af = {b: str(f) for b, f, _ in subs}
    af["adjudication"] = str(adj_f)
    af["charter"] = str(ch_f)
    state, notes, anchor = crucible_adapter.compute_state(
        freeze, docs, adj, charter, tree_dir=tree, artifact_files=af,
        anchor_evidence=json.loads(evidence.read_text()))
    check("adapter-full-requires-content", "content-bound set is "
          "FULL with the anchor status inline UNVERIFIED-EXTERNAL",
          state == "FULL" and anchor == "UNVERIFIED-EXTERNAL")


def test_docs_and_misc(tmp):
    bad = tmp / "bad.md"
    bad.write_text("A claim. <!-- claim: aavep_run.run.nope -->\n")
    import aavep_docs
    problems, _, _ = aavep_docs.check_docs([bad], tmp)
    check("docs-claims-pinned", "unknown behaviour key fails the "
          "docs check", any("unknown behaviour key" in p
                            for p in problems))
    docs = [KIT / "README.md", KIT / "AGENT_INSTRUCTIONS.md",
            KIT / "AAVEP_SPEC_v1.1.md", KIT / "cal" /
            "AAVEP_CAL_SPEC_v2.md"]
    docs = [d for d in docs if d.exists()]
    problems, _, orphans = aavep_docs.check_docs(docs, KIT)
    check("docs-claims-pinned", "the kit's own documents pass the "
          "conformance check (all safety keys claimed, all pinned)",
          problems == [], "; ".join(problems[:4]))
    # EA-5 (loop pass): the section 0 safe-extraction snippet in
    # AGENT_INSTRUCTIONS is executed verbatim — a printed command
    # is a tested command. (The first build's snippet inserted a
    # 'bootstrap' path that exists nowhere in the kit.)
    instr = (KIT / "AGENT_INSTRUCTIONS.md").read_text()
    m = re.search(r"sys\.path\.insert\(0, '([^']+)'\)", instr)
    snippet_ok = False
    if m:
        zpath = tmp / "mini.zip"
        with zipfile.ZipFile(zpath, "w") as z:
            z.writestr("hello.txt", "hi\n")
        code = (f"import sys; sys.path.insert(0, '{m.group(1)}')\n"
                f"from aavep_run import safe_extract\n"
                f"safe_extract({str(zpath)!r}, {str(tmp / 'mini_out')!r})\n")
        p = subprocess.run([sys.executable, "-c", code], cwd=KIT,
                           capture_output=True, text=True, timeout=120)
        snippet_ok = p.returncode == 0 and \
            (tmp / "mini_out" / "hello.txt").exists()
    check("docs-extraction-snippet", "AGENT_INSTRUCTIONS section "
          "0's safe-extraction snippet executes as printed",
          snippet_ok)
    # extraction refusal classes (A-26, unchanged)
    def _symlink(z):
        info = zipfile.ZipInfo("link")
        info.external_attr = 0o120777 << 16
        z.writestr(info, "target")
    for name, make in (
            ("symlink", _symlink),
            ("traversal", lambda z: z.writestr("../evil.txt", "x")),
            ("absolute", lambda z: z.writestr("/evil.txt", "x"))):
        zp = tmp / f"{name}.zip"
        with zipfile.ZipFile(zp, "w") as z:
            make(z)
        try:
            aavep_run.safe_extract(zp, tmp / f"out_{name}")
            refused = False
        except ValueError:
            refused = True
        check("extraction-refusals", f"{name} member refused",
              refused)
    # manifest hygiene (section 7.1 / B-38)
    defects, _ = lint_manifest_entries(
        ["scripts/a.py", "scripts/__pycache__/a.cpython-311.pyc"],
        [])
    check("manifest-cache-lint", "manifested .pyc is a manifest "
          "defect", len(defects) == 1)
    defects, _ = lint_manifest_entries(["a.py"], ["scripts/**"])
    check("manifest-cache-lint", "non-cache-shaped exclusion is a "
          "defect (B-38)", len(defects) == 1)
    defects, eff = lint_manifest_entries(
        ["a.py"], ["**/__pycache__/**"])
    check("manifest-cache-lint", "cache-shaped exclusion passes",
          defects == [] and eff == ["**/__pycache__/**"])
    # v1.0 manifest instance remains valid v1.1 input (section 13)
    v1man = KIT / "manifest" / "example_manifest.json"
    if v1man.exists():
        probs = aavep_preflight.validate_manifest_structure(
            json.loads(v1man.read_text()))
        check("manifest-v1-instance", "v1.0 manifest instance "
              "passes v1.1 structural validation",
              not any("aavep_version" in p for p in probs))
    # completeness gate over the v1.1 statuses shape (regression:
    # the gate read v1.0's flat shape and counted nothing as
    # executed; PASSED-DEGRADED is an execution)
    import aavep_ledger as _led
    gman = tmp / "gman.json"
    gman.write_text(json.dumps({"claims": [
        {"claim_id": "G-1", "section": "sA", "coverage": [
            {"instrument": "W1", "type": "substantive"}]},
        {"claim_id": "G-2", "section": "sB", "coverage": [
            {"instrument": "W2", "type": "substantive"}]}]}))
    gstat = tmp / "gstatuses.json"
    gstat.write_text(json.dumps({"statuses": {
        "W1": {"status": "PASSED-DEGRADED", "degradations": []},
        "W2": {"status": "FAILED", "degradations": []}}}))
    gled = tmp / "gled.jsonl"
    _led.append(gled, "SESSION_OPEN", "op", genesis_payload([]))
    for sec in ("sA", "sB"):
        _led.append(gled, "NO_FINDING", "op",
                    {"section": sec, "self_disconfirmation": "x"})
    p = cli(TOOLS / "aavep_completeness.py", "gate",
            "--manifest", gman, "--statuses", gstat,
            "--ledger", gled, "--operator", "op")
    check("completeness-degraded-executed", "completeness gate "
          "reads v1.1 nested statuses; PASSED-DEGRADED counts as "
          "executed coverage", p.returncode == 0,
          (p.stdout + p.stderr)[-300:])


def test_kit_manifest(tmp):
    copy = tmp / "kitcopy"
    shutil.copytree(KIT, copy, ignore=shutil.ignore_patterns(
        "demo", "__pycache__", "AAVEP_MANIFEST.sha256",
        "AAVEP_FREEZE*", "ANCHOR.txt"))
    (copy / "demo").mkdir(exist_ok=True)
    gen_kit_manifest(copy)
    env = {k: v for k, v in os.environ.items()
           if k != "PYTHONDONTWRITEBYTECODE"}
    p = subprocess.run(
        [sys.executable, "-c",
         "import aavep_run; "
         "print(aavep_run.verify_kit_manifest())"],
        cwd=copy / "tools", capture_output=True, text=True, env=env)
    check("kit-manifest-import-verify", "importing kit modules "
          "(creating __pycache__) does not break kit manifest "
          "verification",
          p.returncode == 0 and "(True," in p.stdout,
          p.stdout[-200:] + p.stderr[-200:])


def test_ladder_differential(tmp):
    """B-33: overall_status vs an independent truth-table
    implementation of the section 6 text, enumerated exhaustively
    for small instrument sets."""
    def truth(statuses):
        req = statuses  # all required in this fixture
        if any(s is None for s in req):
            return "TARGET_MISMATCH"
        if any(s in ("BLOCKED", "TIMEOUT", "UNRESOLVED")
               for s in req):
            return "INCOMPLETE"
        executed = [s for s in req
                    if s in ("PASSED", "PASSED-DEGRADED", "FAILED")]
        degraded = [s for s in executed if s == "PASSED-DEGRADED"]
        if executed and len(degraded) * 2 > len(executed):
            return "INCOMPLETE"
        if any(s == "PASSED-DEGRADED" for s in req):
            return "COMPLETE-DEGRADED"
        return "COMPLETE"
    # B-33's domain: instrument sets up to size 4, all eight
    # per-instrument states (the seven printed states plus
    # ABSENT, which the ladder reads as TARGET_MISMATCH), and
    # the degraded-flag dimension — overall_status is a function
    # of statuses only, so flags are enumerated as an invariance
    # sweep (sizes 1-3) on top of the size-4 truth-table sweep.
    # (Extended by the v1.1 loop pass: the first build enumerated
    # sizes 1-3 x 7 states only — 399 vectors against a badge
    # that promised the larger domain.)
    states = ["PASSED", "PASSED-DEGRADED", "FAILED", "BLOCKED",
              "TIMEOUT", "UNRESOLVED", "NOT_APPLICABLE", None]
    bad = 0
    total = 0
    for n in (1, 2, 3, 4):
        for combo in itertools.product(states, repeat=n):
            insts = [{"id": f"i{k}"} for k in range(n)]
            sts = {f"i{k}": combo[k] for k in range(n)}
            total += 1
            if overall_status(insts, sts) != truth(list(combo)):
                bad += 1
    flag_total = 0
    for n in (1, 2, 3):
        for combo in itertools.product(states, repeat=n):
            for flags in itertools.product((False, True), repeat=n):
                insts = [{"id": f"i{k}"} for k in range(n)]
                sts = {f"i{k}": combo[k] for k in range(n)}
                flag_total += 1
                if overall_status(insts, sts) != truth(list(combo)):
                    bad += 1
    check("ladder-differential", f"overall_status agrees with the "
          f"independent truth table on {total} enumerated vectors "
          f"(sizes 1-4 x 8 states) and {flag_total} degraded-flag "
          f"invariance vectors", bad == 0, f"{bad} divergences")


def test_demo_bundle(tmp):
    args_f = KIT / "demo" / "evidence" / "synthetic" / \
        "verify_args.json"
    if not args_f.exists():
        check("demo-bundle-verify", "shipped synthetic demonstration "
              "bundle is present", False, "demo not built")
        return
    spec = json.loads(args_f.read_text())
    p = cli(TOOLS / "aavep_report.py", "verify",
            "--manifest", spec["manifest"], "--package",
            spec["package"], "--workspace", spec["workspace"],
            "--ledger", spec["ledger"], "--house-root",
            spec["house_root"], "--cal-sessions",
            spec["cal_sessions"], "--cal-keys", spec["cal_keys"],
            "--envelope-out", spec["envelope"], "--record-out",
            spec["record"], timeout=1200)
    check("demo-bundle-verify", "report verify over the shipped "
          "demonstration bundle reproduces its record",
          p.returncode == 0, p.stdout[-400:])
    # relocation (loop pass, EA-2/DA-12): the same verify from a
    # byte copy of the kit at a different root must also pass —
    # the first shipped bundle carried an absolute build-machine
    # source locator and refused relocated with LOCKS DIVERGE.
    rel = tmp / "relocated_kit"
    shutil.copytree(KIT, rel, ignore=shutil.ignore_patterns(
        "__pycache__", "*.pyc"))
    spec2 = json.loads((rel / "demo" / "evidence" / "synthetic" /
                        "verify_args.json").read_text())
    p = subprocess.run(
        [sys.executable, str(rel / "tools" / "aavep_report.py"),
         "verify", "--manifest", spec2["manifest"], "--package",
         spec2["package"], "--workspace", spec2["workspace"],
         "--ledger", spec2["ledger"], "--house-root",
         spec2["house_root"], "--cal-sessions",
         spec2["cal_sessions"], "--cal-keys", spec2["cal_keys"],
         "--envelope-out", spec2["envelope"], "--record-out",
         spec2["record"]], cwd=rel, capture_output=True,
        text=True, timeout=1200)
    check("demo-bundle-relocated", "report verify over the "
          "shipped bundle passes from a relocated copy of the kit",
          p.returncode == 0, (p.stdout + p.stderr)[-300:])


def test_esp_conformance(tmp):
    p = cli(KIT / "esp" / "esp_v2_conformance.py", timeout=1200)
    out = p.stdout + p.stderr
    check("esp-conformance", "vendored ESP v2.4 conformance battery "
          "passes as shipped", p.returncode == 0
          and "283" in out, out[-200:])


def main():
    print(DISC)
    tmp = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    import tempfile
    base = tmp or Path(tempfile.mkdtemp(prefix="aavep-selftest-"))
    base.mkdir(parents=True, exist_ok=True)
    # the runner refuses a kit whose manifest does not verify:
    # generate it for the tree under test (the freeze rule).
    if not (KIT / "AAVEP_MANIFEST.sha256").exists():
        gen_kit_manifest(KIT)
    for sub in ("cal", "callegacy", "ledger", "runner", "gate0x",
                "report", "adapter", "misc", "kitman"):
        (base / sub).mkdir(parents=True, exist_ok=True)
    test_cal(base / "cal")
    test_cal_legacy(base / "callegacy")
    test_ledger(base / "ledger")
    test_runner(base / "runner", TOOLS)
    test_gate0(base / "gate0x", TOOLS)
    test_report(base / "report", TOOLS)
    test_adapter(base / "adapter")
    test_docs_and_misc(base / "misc")
    test_kit_manifest(base / "kitman")
    test_ladder_differential(base)
    test_demo_bundle(base)
    test_esp_conformance(base)
    # meta-case: every registry-pinned case exists in this suite
    pinned = set()
    for keys in BEHAVIOUR_REGISTRY.values():
        for entry in keys.values():
            pinned.update(entry["cases"])
    missing = pinned - set(CASES_RUN)
    check("registry-meta", "every behaviour key's pinning cases "
          "exist and ran", not missing, f"missing: {missing}")
    failed = [n for n, ok in RESULTS if not ok]
    print(f"\nSELFTEST: {len(RESULTS) - len(failed)}/{len(RESULTS)} "
          f"checks passed")
    if failed:
        print("FAILED:", *failed, sep="\n  ")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
