#!/usr/bin/env python3
"""aavep_lib — shared primitives for the AAVEP v1.1 kit.

INPUT_PROVENANCE:
  paper-defined:       NONE.
  cited-paper:         NONE.
  control:             AAVEP v1.1 design (DESIGN_PROPOSAL_v1.1.md,
                       §17.3 amendments B-1..B-38 governing): hashing,
                       canonical JSON, the status ladder (with the
                       PASSED-DEGRADED / COMPLETE-DEGRADED rungs,
                       B-32), the protocol-default marker set, and the
                       expectation-gating derivation contract shared by
                       the runner and the report path (§3, §5.3).
  declared-assumption: NONE.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: AAVEP audit machinery state.
  (2) Verified domain: this module only defines primitives; the
      selftest pins their behaviour.
  (3) Map: n/a (definitions).
  (4) Preserves: one shared definition between the tools that must
      agree (runner, report, ledger, docs checker).
  (5) Outside the machine check: everything else.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone

AAVEP_VERSION = "1.1"
CAL_V1_VERSION = "1"
CAL_V2_VERSION = "2"
CAL_VERSION = "2"

# ------------------------------------------------------------------
# hashing / canonical form

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def is_hash(s) -> bool:
    return (isinstance(s, str) and len(s) == 64
            and all(c in "0123456789abcdef" for c in s))


def sha256_canonical(obj) -> str:
    return sha256_bytes(canonical(obj))


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --- Ledger vocabulary (design §4.5, A-19, A-21, A-25, A-30) ------
ENTRY_TYPES = {
    "SESSION_OPEN", "LOCK_TABLE", "FINDING_FILED",
    "REPRODUCTION_PHASE1", "REPRODUCTION", "ADJUDICATION",
    "GENERATOR_REJECTION", "NO_FINDING", "COMPLETENESS",
    "MANIFEST_AMENDMENT", "SAMPLE_RERUN", "NOTE",
}
REPRO_OUTCOMES = {
    "REPRODUCED_INDEPENDENT", "REPRODUCED_SAME_HOUSE",
    "NOT_REPRODUCED", "CANNOT_ATTEMPT",
}
ADJUDICATIONS = {"SUSTAINED", "PARTIALLY_SUSTAINED", "OVERTURNED",
                 "UNRESOLVED"}


# ------------------------------------------------------------------
# the status ladder (design §6 as amended B-32)

STATUS_LADDER = [
    "DECLARED", "AVAILABLE", "EXECUTABLE", "EXECUTED",
    "PASSED", "PASSED-DEGRADED", "FAILED", "UNRESOLVED", "TIMEOUT",
    "BLOCKED", "NOT_APPLICABLE",
]
TERMINAL = {"PASSED", "PASSED-DEGRADED", "FAILED", "UNRESOLVED",
            "TIMEOUT", "BLOCKED", "NOT_APPLICABLE"}
TRANSITIONS = {
    "DECLARED": {"AVAILABLE", "NOT_APPLICABLE", "BLOCKED"},
    "AVAILABLE": {"EXECUTABLE", "BLOCKED"},
    "EXECUTABLE": {"EXECUTED", "TIMEOUT", "BLOCKED"},
    "EXECUTED": {"PASSED", "PASSED-DEGRADED", "FAILED", "UNRESOLVED"},
    "PASSED": set(), "PASSED-DEGRADED": set(), "FAILED": set(),
    "UNRESOLVED": set(), "TIMEOUT": set(), "BLOCKED": set(),
    "NOT_APPLICABLE": set(),
}
OVERALL_STATUSES = {"COMPLETE", "COMPLETE-DEGRADED", "INCOMPLETE",
                    "TARGET_MISMATCH"}

# Protocol-default marker set (§6.1/B-32): output substrings marking a
# partial / uncheckable result. They apply to EVERY instrument by
# protocol and cannot be undeclared; manifest partial_markers only add.
PROTOCOL_DEFAULT_MARKERS = [
    "UNCHECKABLE", "NOT CHECKED", "NOT RUN", "SKIPPED", "DEGRADED",
    "PARTIAL", "INCOMPLETE", "UNRESOLVED", "NO COUNTERPART",
    "REFUSED", "MANIFEST DEFECT", "NON-CONFORMING",
]

DEGRADATION_KINDS = {
    "PARTIAL-MARKER",
    "ADVISORY-EXPECTATION-UNMET",
    "DEPENDENCY-UNDECLARED",
    "IMPORTS-UNDECLARED",
    "OUTPUT-TRUNCATED",
}


def overall_status(instruments, statuses):
    """Overall run status (design §6.2 as amended B-32).

    Majority rule: if more than half of the executed required
    instruments are PASSED-DEGRADED, the overall is INCOMPLETE.
    A FAILED instrument is a completed execution and does not by
    itself make the run INCOMPLETE.
    """
    required = [i for i in instruments
                if i.get("applicability") != "not_applicable"]
    if any(statuses.get(i["id"]) in (None, "PENDING", "QUEUED")
           for i in instruments):
        return "TARGET_MISMATCH"
    if any(statuses.get(i["id"]) in ("BLOCKED", "TIMEOUT", "UNRESOLVED")
           for i in required):
        return "INCOMPLETE"
    executed = [i for i in required
                if statuses.get(i["id"]) in ("PASSED", "PASSED-DEGRADED",
                                             "FAILED")]
    degraded = [i for i in executed
                if statuses.get(i["id"]) == "PASSED-DEGRADED"]
    if executed and len(degraded) * 2 > len(executed):
        return "INCOMPLETE"
    if any(statuses.get(i["id"]) == "PASSED-DEGRADED" for i in instruments):
        return "COMPLETE-DEGRADED"
    return "COMPLETE"


def expectations_of(inst):
    """Normalise expect_stdout_contains: a bare string is a HARD
    expectation (v1.0 meaning preserved, B-12); {"needle", "advisory"}
    opts into advisory. Returns [{"needle", "advisory"}]."""
    out = []
    for e in inst.get("expect_stdout_contains", []) or []:
        if isinstance(e, str):
            out.append({"needle": e, "advisory": False})
        elif isinstance(e, dict) and isinstance(e.get("needle"), str):
            out.append({"needle": e["needle"],
                        "advisory": bool(e.get("advisory", False))})
    return out


def gate_status(exit_code, inst, observations, truncated=False):
    """The expectation gate (design §5.3), shared verbatim by the
    runner and derive-side recomputation so the two cannot drift.

    observations: [{"needle", "observed"}] covering every expectation
    and every partial marker (default + manifest) that was checked.
    Returns (status, degradations).
    """
    if exit_code is None:
        return "TIMEOUT", []
    degradations = []
    obs = {o["needle"]: bool(o.get("observed")) for o in observations}
    hard_fail = False
    for e in expectations_of(inst):
        if not obs.get(e["needle"], False):
            if e["advisory"]:
                degradations.append("ADVISORY-EXPECTATION-UNMET")
            else:
                hard_fail = True
    markers = set(PROTOCOL_DEFAULT_MARKERS)
    for m in inst.get("partial_markers", []) or []:
        markers.add(m)
    if any(obs.get(m) for m in markers):
        degradations.append("PARTIAL-MARKER")
    failed_exit = exit_code not in inst.get("pass_exit_codes", [0])
    if hard_fail or failed_exit:
        return "FAILED", degradations
    if degradations:
        return "PASSED-DEGRADED", degradations
    if truncated:
        return "PASSED-DEGRADED", ["OUTPUT-TRUNCATED"]
    return "PASSED", []


# ------------------------------------------------------------------
# package-manifest hygiene (design §7.1 as amended B-38)

CACHE_PATH_RE = re.compile(
    r"(^|/)(__pycache__/|\.pytest_cache/|\.mypy_cache/)|\.py[co]$")


def is_cache_path(rel: str) -> bool:
    return bool(CACHE_PATH_RE.search(rel.replace("\\", "/")))


def lint_manifest_entries(entries, exclusions):
    """Returns (defects, effective_exclusions). A manifested cache
    path is a MANIFEST DEFECT charged to the manifest's author.
    Exclusion patterns are type-bounded (B-38): each pattern's literal
    core must itself be cache-shaped."""
    defects = []
    for rel in entries:
        if is_cache_path(rel):
            defects.append(f"manifested cache path (manifest defect): "
                           f"{rel}")
    effective = []
    for pat in exclusions or []:
        core = str(pat).replace("**", "").replace("*", "").strip("/")
        # Type bound (B-38): the pattern's literal core must itself
        # denote a cache location — a cache directory component, or
        # a cache file suffix. "scripts" fails; "__pycache__" and
        # ".pyc" pass.
        probes = [core, core + "/",
                  ("x" + core) if core.startswith(".") else core]
        if not any(is_cache_path(p) for p in probes):
            defects.append(f"exclusion pattern is not cache-shaped "
                           f"(B-38 type bound): {pat}")
        else:
            effective.append(pat)
    return defects, effective


def parse_sha256_manifest(text: str):
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) == 2 and is_hash(parts[0]):
            out[parts[1].lstrip("*").strip()] = parts[0]
    return out


# ------------------------------------------------------------------
# behaviour-key registry (design §11 as amended B-34)

BEHAVIOUR_REGISTRY = {
    "aavep_cal": {
        "cal.secret-custody": {
            "class": "custody",
            "text": "the CAL v2 secret is generated by CSPRNG at "
                    "session creation, held only in the administrator "
                    "tree, and never written to the subject tree, the "
                    "receipt, or stdout",
            "cases": ["cal2-subject-tree-clean", "cal2-no-seed-interface"]},
        "cal.commitment-before-contact": {
            "class": "custody",
            "text": "the opening commitment over the fixture hashes "
                    "is computed and recorded in the administrator "
                    "record before the subject tree is released",
            "cases": ["cal2-commitment-binds-fixtures"]},
        "cal.fixture-integrity-at-score": {
            "class": "failure-mode",
            "text": "fixtures are snapshotted into the administrator "
                    "tree and hash-verified at score time; any "
                    "divergence — edit, absence, or an extra "
                    "unissued file in the subject tree — fails "
                    "the session (FIXTURE-INTEGRITY-FAIL) and no "
                    "tier is issued",
            "cases": ["cal2-fixture-tamper",
                      "cal2-extra-file-invalid"]},
        "cal.receipt-allowlist": {
            "class": "custody",
            "text": "a published receipt carries only allowlisted "
                    "fields; no secret, seed, response, or key "
                    "material appears in it",
            "cases": ["cal2-receipt-allowlist", "docs-redact-check",
                      "cal2-redact-keys-exempt"]},
        "cal.administration-grade": {
            "class": "status",
            "text": "administration_grade is computed from the "
                    "operator and administrator principals: identical "
                    "principals grade SELF-ADMINISTERED whatever the "
                    "role labels say; the tier rule's re-run cap "
                    "reads the administrator record's persisted "
                    "scoring lineage (a PASS on a re-run after a "
                    "FAIL caps at CONDITIONAL)",
            "cases": ["cal2-grade-principal-keyed",
                      "cal2-reattempt-cap"]},
        "cal.key-publication-rescore": {
            "class": "capability",
            "text": "after session close the administrator may "
                    "publish the per-trap key material, upgrading a "
                    "receipt to publicly re-scorable form "
                    "(key_disclosure: published)",
            "cases": ["cal2-key-publication",
                      "cal2-redacted-admin-fallback",
                      "cal2-key-disclosure-upgrade",
                      "cal2-fallback-fixture-anchor"]},
    },
    "aavep_run": {
        "run.gate0": {
            "class": "status",
            "text": "a run refuses to open (Gate 0) unless every "
                    "operator holds a same-session CAL receipt that "
                    "the runner itself re-verified (re-scored where "
                    "custody material is presented, else commitment-"
                    "checked and labelled)",
            "cases": ["run-gate0-forged-receipt", "run-gate0-accepts-real"]},
        "run.manifest-safety": {
            "class": "failure-mode",
            "text": "preflight rejects manifests whose instrument "
                    "paths escape their declared reach "
                    "(MANIFEST-UNSAFE), and the runner re-resolves "
                    "paths at execution (ESCAPE-REFUSED)",
            "cases": ["run-manifest-unsafe", "run-runtime-escape",
                      "run-relative-workspace"]},
        "run.store-executed-bytes": {
            "class": "capability",
            "text": "the bytes executed for every pinned instrument "
                    "and declared module are placed from the "
                    "content-addressed store and re-verified by hash "
                    "at placement time and again immediately "
                    "before execution",
            "cases": ["run-store-bytes-placed"]},
        "run.writesets-consumes": {
            "class": "status",
            "text": "per-instrument write-sets are recorded; an "
                    "instrument that consumes an undeclared sibling "
                    "output is capped at PASSED-DEGRADED "
                    "(DEPENDENCY-UNDECLARED)",
            "cases": ["run-planter-checker"]},
        "run.expectation-gate": {
            "class": "status",
            "text": "an unmet non-advisory expectation fails the "
                    "attempt (EXPECTATION-UNMET); an unmet advisory "
                    "expectation or an observed partial marker caps "
                    "the instrument at PASSED-DEGRADED",
            "cases": ["run-expectation-gate", "ladder-differential"]},
        "run.survivor-sweep": {
            "class": "failure-mode",
            "text": "at every instrument close and at run close the "
                    "runner sweeps the process census for survivors "
                    "of killed process groups and kills them, "
                    "recording a SURVIVOR event",
            "cases": ["run-survivor-sweep"]},
        "run.home-redirect": {
            "class": "custody",
            "text": "instruments run with HOME and TMPDIR redirected "
                    "to runner-owned directories; the operator's real "
                    "HOME is never on the environment allowlist",
            "cases": ["run-home-redirect"]},
        "run.output-capture": {
            "class": "capability",
            "text": "instrument output is streamed to spill files "
                    "with a per-attempt byte ceiling; the event "
                    "record always carries the full-stream sha256, "
                    "the byte count, and the truncation state",
            "cases": ["run-output-flood"]},
        "run.confinement-printed": {
            "class": "status",
            "text": "the achieved confinement level (portable floor "
                    "or the OS facility actually achieved) is printed "
                    "in RUN_OPEN and in every status record",
            "cases": ["run-confinement-printed"]},
        "run.preconditions": {
            "class": "failure-mode",
            "text": "a run refuses to open unless the kit manifest "
                    "and the package manifest both verify, and "
                    "refuses if a CAL administrator tree is found "
                    "inside the run workspace",
            "cases": ["run-preconditions"]},
    },
    "aavep_report": {
        "report.derive-all-parity": {
            "class": "status",
            "text": "report build and report verify run the same "
                    "derive_all pipeline: statuses re-derived from "
                    "events, overall recomputed (never copied), lock "
                    "table recomputed from the real package, genesis "
                    "receipts re-scored, SL-2b applied",
            "cases": ["report-overall-flip", "report-lock-divergence",
                      "report-sl2b-in-verify"]},
        "report.receipt-grades": {
            "class": "status",
            "text": "genesis calibration receipts print as RESCORED, "
                    "COMMITMENT-ONLY (grade CLAIMED), LEGACY-CUSTODY, "
                    "or UNVERIFIED with the reason; the top stamp "
                    "requires RESCORED or commitment-bound receipts",
            "cases": ["report-ghost-receipt", "ledger-verdict-split"]},
        "report.eventlog-binding": {
            "class": "failure-mode",
            "text": "verify checks the presented event log's head "
                    "against the head recorded in the run's "
                    "adjudication ledger; a mismatch refuses, and an "
                    "unanchored ledger prints event-log binding: "
                    "UNANCHORED-BOUND",
            "cases": ["report-eventlog-binding"]},
    },
    "aavep_ledger": {
        "ledger.verdict-split": {
            "class": "status",
            "text": "ledger verify never prints an unqualified "
                    "'valid': it prints CHAIN-VALID or CHAIN-INVALID, "
                    "GENESIS GROUNDED or UNGROUNDED with the pins "
                    "used, and a grade per genesis receipt",
            "cases": ["ledger-verdict-split", "ledger-rechain-expect-head",
                      "ledger-ghost-receipt-unverified"]},
        "ledger.unverified-root": {
            "class": "status",
            "text": "an anchor whose hash is identical to an in-tree "
                    "anchor is labelled UNVERIFIED-ROOT (hash "
                    "identity, not path, decides)",
            "cases": ["ledger-unverified-root"]},
        "ledger.lifecycle": {
            "class": "status",
            "text": "the finding lifecycle is enforced as recorded: "
                    "no dispositive outcome before reproduction, "
                    "same-house sustainment needs a countersignature, "
                    "role-conflicted adjudications are void",
            "cases": ["ledger-lifecycle"]},
    },
    "crucible_adapter": {
        "adapter.full-content-bound": {
            "class": "status",
            "text": "a FULL Crucible state requires the adapter to "
                    "hash a presented tree and the presented "
                    "submission / adjudication / charter files and "
                    "match them against the freeze record; the "
                    "state line always carries the anchor status "
                    "inline (anchor UNVERIFIED-EXTERNAL at best)",
            "cases": ["adapter-full-requires-content"]},
    },
    "aavep_docs": {
        "docs.claims-pinned": {
            "class": "failure-mode",
            "text": "a normative claim in a kit document fails the "
                    "docs check if its behaviour key is unknown or "
                    "unpinned for a status / failure-mode / custody "
                    "claim",
            "cases": ["docs-claims-pinned"]},
    },
}


def _norm_observations(raw):
    """Execute events carry stdout observations either as a v1.0 dict
    {needle: bool} or as a v1.1 list of {"needle", "observed"}."""
    if isinstance(raw, dict):
        return [{"needle": k, "observed": bool(v)}
                for k, v in raw.items()]
    return list(raw or [])


def derive_statuses(events, instruments=None):
    """Recompute instrument statuses from the runner's event log
    (design §3). The event chain is the v1.0 form: each event_hash is
    sha256(prev_hash || canonical(body)), genesis prev "0"*64.

    Returns (statuses, problems), statuses mapping id ->
    {"status", "degradations"}. When the manifest contracts are
    supplied, every recorded status is additionally checked against
    the expectation gate recomputed from the execute events (§5.3
    parity): a recorded PASSED whose gate recomputes otherwise is a
    derivation problem, not a status. Lawful shapes (A-27): TIMEOUT
    requires the attempt and the 2x retry, both timed out.
    """
    problems = []
    prev = "0" * 64
    statuses = {}
    executes = {}
    status_evs = {}
    for ev in events:
        if "event_hash" in ev:
            body = {k: v for k, v in ev.items() if k != "event_hash"}
            if ev.get("prev_hash") != prev:
                problems.append(
                    f"event {ev.get('seq')}: prev_hash break")
            if sha256_bytes(prev.encode() + canonical(body)) != \
                    ev["event_hash"]:
                problems.append(
                    f"event {ev.get('seq')}: event_hash mismatch "
                    f"(log edited)")
            prev = ev["event_hash"]
        iid = ev.get("instrument")
        if not iid:
            continue
        if ev.get("phase") == "execute":
            executes.setdefault(iid, []).append(ev)
        elif ev.get("phase") == "status":
            status_evs[iid] = ev
            statuses[iid] = {
                "status": ev["status"],
                "degradations": ev.get("degradations", []),
            }
    contracts = {i["id"]: i for i in instruments} if instruments else {}
    for iid, st in statuses.items():
        exs = executes.get(iid, [])
        sev = status_evs[iid]
        recorded = st["status"]
        if recorded not in TERMINAL:
            problems.append(f"{iid}: status {recorded} not terminal")
            continue
        if recorded in ("BLOCKED", "NOT_APPLICABLE"):
            if exs:
                problems.append(
                    f"{iid}: {recorded} recorded after executions")
            continue
        if not exs:
            problems.append(
                f"{iid}: status {recorded} with no execute event")
            continue
        last = exs[-1]
        if recorded == "TIMEOUT":
            if len(exs) < 2 or not all(e.get("timed_out")
                                       for e in exs):
                problems.append(
                    f"{iid}: TIMEOUT without the attempt and the 2x "
                    f"retry both timing out (A-27)")
            continue
        if last.get("timed_out"):
            problems.append(
                f"{iid}: {recorded} recorded but the last attempt "
                f"timed out")
            continue
        inst = contracts.get(iid)
        if inst is not None:
            obs = _norm_observations(sev.get("stdout_observations")
                                     or last.get(
                                         "stdout_observations"))
            derived, _ = gate_status(
                last.get("exit"), inst, obs,
                truncated=bool(last.get("stdout_truncated")))
            if recorded == "PASSED" and derived != "PASSED":
                problems.append(
                    f"{iid}: recorded PASSED but the gate recomputes "
                    f"{derived} (EXPECTATION-UNMET or marker)")
            if recorded == "PASSED-DEGRADED":
                if derived == "FAILED":
                    problems.append(
                        f"{iid}: recorded PASSED-DEGRADED but the "
                        f"gate recomputes FAILED")
                if not st["degradations"]:
                    problems.append(
                        f"{iid}: PASSED-DEGRADED names no degradation")
            if recorded == "FAILED" and derived == "PASSED":
                problems.append(
                    f"{iid}: recorded FAILED but the gate recomputes "
                    f"PASSED")
        if recorded == "PASSED-DEGRADED" and not st["degradations"]:
            problems.append(
                f"{iid}: PASSED-DEGRADED names no degradation")
    return statuses, problems


def behaviours_for(tool):
    return BEHAVIOUR_REGISTRY.get(tool, {})


def disclosure(native, verified, map_, preserves, outside):
    """The five-part disclosure header every kit tool prints."""
    return (
        "FIVE-PART DISCLOSURE:\n"
        f"  (1) Native domain: {native}\n"
        f"  (2) Verified domain: {verified}\n"
        f"  (3) Map: {map_}\n"
        f"  (4) What the map preserves: {preserves}\n"
        f"  (5) What stays outside the machine check: {outside}\n"
    )
