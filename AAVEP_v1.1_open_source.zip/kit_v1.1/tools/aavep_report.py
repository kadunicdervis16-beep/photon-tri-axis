#!/usr/bin/env python3
"""aavep_report — Stage H report + ESP envelope generation (v1.1).

INPUT_PROVENANCE:
  paper-defined:       the bundle's own artifacts (event log, lock
                       table inputs, ledger, manifest) — the report
                       generates no new evidence, it derives.
  cited-paper:         NONE.
  control:             AAVEP v1.1 design §3 (B-20, B-23, B-26):
                       ONE derivation pipeline, derive_all, shared by
                       build and verify — statuses re-derived from
                       events under the shared gate, the overall
                       RECOMPUTED (never copied from statuses.json;
                       the v1.0 line-244 verbatim copy is gone), the
                       lock table recomputed from the real package,
                       genesis calibration receipts re-scored or
                       graded (RESCORED / COMMITMENT-ONLY with the
                       grade printed CLAIMED / LEGACY-CUSTODY /
                       UNVERIFIED), SL-2b applied in BOTH modes, the
                       event log's head checked against the head
                       recorded in the run's ledger (UNANCHORED-BOUND
                       printed when the ledger's anchor is the string
                       UNANCHORED), and the WITNESS-TRIVIAL lint (F8).
                       The ESP envelope is assembled by the vendored
                       ESP v2.4 engine from these computed values; the
                       stamp is ENGINE-VALIDATED only when every
                       derivation passes and the engine validates.
  declared-assumption: report_fields (sender, addressee, anchor) are
                       operator-supplied declarations, printed as
                       such; the anchor's status is labelled, never
                       upgraded by this tool.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: one completed run's bundle.
  (2) Verified domain: the correspondence between the bundle's
      artifacts and the values the report prints — derivations,
      not the run's own truth.
  (3) Map: derive_all, executed identically at build and at verify.
  (4) Preserves: a report that verifies is a report whose every
      printed number was recomputed from the bundle by the same
      code that produced it.
  (5) Outside the machine check: whether the run happened as its
      log describes (the ledger residue, printed in the record).
"""
from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "esp"))
import aavep_cal  # noqa: E402
import aavep_ledger  # noqa: E402
import aavep_preflight  # noqa: E402
from aavep_lib import (PROTOCOL_DEFAULT_MARKERS, behaviours_for,  # noqa: E402
                       canonical, derive_statuses, disclosure,
                       expectations_of, overall_status, sha256_bytes,
                       sha256_file)

KIT = Path(__file__).resolve().parent.parent
DISC = disclosure(
    "one completed run's bundle",
    "correspondence between the bundle's artifacts and every value "
    "the report prints",
    "derive_all, identical at build and verify",
    "recompute-equality of statuses, overall, locks, receipts, and "
    "the envelope",
    "whether the run happened as its log describes")

RECEIPT_OK_FOR_STAMP = ("RESCORED", "COMMITMENT-ONLY")


# ------------------------------------------------------------------
# SL-2b + WITNESS-TRIVIAL (F8)

def sl2b_check_bundle(ledger_entries, lock, store_dirs):
    """Verify witness packets against the store copies named by the
    lock table. store_dirs: candidate store directories (bundle
    workspaces). Returns (problems, witness_trivial_flags)."""
    problems, trivial = [], []
    srcmap = {}
    for entry in lock.get("instruments", {}).values():
        for s in entry.get("sources", []):
            if s.get("store_path"):
                srcmap[s["source_id"]] = s
    for e in ledger_entries:
        if e["type"] not in ("FINDING_FILED", "NO_FINDING"):
            continue
        pkt = e.get("payload", {}).get("packet")
        if not pkt:
            continue
        fid = pkt.get("finding_id", "?")
        w = pkt.get("witness") or {}
        src = srcmap.get(w.get("source_id"))
        if src is None:
            problems.append(f"{fid}: witness source not in the lock "
                            f"table (SL-2b: QUOTES-UNVERIFIED)")
            continue
        blob = None
        for sd in store_dirs:
            cand = Path(sd) / Path(src["store_path"]).name
            if cand.exists():
                blob = cand.read_bytes()
                break
        if blob is None:
            problems.append(f"{fid}: store copy of "
                            f"{w.get('source_id')} not presented "
                            f"(SL-2b: QUOTES-UNVERIFIED)")
            continue
        if sha256_bytes(blob) != src["observed_sha256"]:
            problems.append(f"{fid}: store copy hash mismatch")
            continue
        lines = blob.decode("utf-8", "replace").splitlines()
        la = w.get("line_address")
        quote = w.get("verbatim_quote", "")
        if not isinstance(la, int) or not (1 <= la <= len(lines)):
            problems.append(f"{fid}: line address out of range")
            continue
        if quote not in lines[la - 1]:
            problems.append(f"{fid}: verbatim quote not at the cited "
                            f"line")
        if la >= 1 and lines[la - 1].startswith("#!") and \
                quote == lines[la - 1].strip():
            trivial.append(
                f"{fid}: WITNESS-TRIVIAL — the cited quote is the "
                f"source's boilerplate first line; a packet note is "
                f"required for the quote to carry weight (F8)")
        span = w.get("section_span") or [0, 0]
        try:
            section = "\n".join(lines[span[0] - 1:span[1]])
            if sha256_bytes(section.encode()) != \
                    w.get("section_sha256"):
                problems.append(f"{fid}: section hash mismatch")
            if lines[span[0] - 1].strip() != \
                    w.get("enclosing_heading"):
                problems.append(f"{fid}: enclosing heading mismatch")
        except Exception:
            problems.append(f"{fid}: section span unreadable")
    return problems, trivial


# ------------------------------------------------------------------
# receipt grading (§3.3)

def grade_receipts(genesis, sessions_dir, keys_dir, bundle_docs):
    """Grade each genesis calibration receipt. Returns a list of
    {operator, grade, detail, administration_grade}."""
    out = []
    admin_by_session, keys_by_session = {}, {}
    if sessions_dir:
        for d in Path(sessions_dir).iterdir():
            if (d / "admin_record.json").exists():
                rec = json.loads((d / "admin_record.json").read_text())
                admin_by_session[rec["session_id"]] = d
            if (d / "subject_open.json").exists():
                pass
    keys_by_session = {}
    if keys_dir:
        for f in Path(keys_dir).iterdir():
            if f.suffix == ".json":
                try:
                    doc = json.loads(f.read_text())
                except Exception:
                    continue
                if "session_id" in doc and "key" in doc:
                    keys_by_session[doc["session_id"]] = f
    subj_by_session = {}
    if sessions_dir:
        for d in Path(sessions_dir).iterdir():
            if (d / "subject_open.json").exists():
                so = json.loads((d / "subject_open.json").read_text())
                subj_by_session[so["session_id"]] = d
    for r in genesis.get("calibration_receipts", []) or []:
        if not isinstance(r, dict):
            continue
        if r.get("session_commitment"):
            sid = r.get("session_id")
            res = aavep_cal.verify_receipt(
                r, admin_dir=admin_by_session.get(sid),
                subject_dir=subj_by_session.get(sid),
                responses_path=(subj_by_session[sid] / "responses.json")
                if sid in subj_by_session and
                (subj_by_session[sid] / "responses.json").exists()
                else None,
                keys_path=keys_by_session.get(sid),
                fixtures_dir=subj_by_session.get(sid),
                opening_record_obj=genesis)
            grade = res["outcome"]
            detail = res["reason"]
            if grade == "COMMITMENT-ONLY":
                detail += "; the administration grade is CLAIMED"
            out.append({"operator": r.get("operator_id"),
                        "grade": grade, "detail": detail,
                        "administration_grade":
                            r.get("administration_grade")})
        else:
            out.append({"operator": r.get("operator"),
                        "grade": "LEGACY-CUSTODY",
                        "detail": "v1 receipt; re-score requires the "
                                  "v1 session and responses (the "
                                  "runner's Gate 0 path); custody "
                                  "label per design section 13",
                        "administration_grade": "LEGACY"})
    return out


# ------------------------------------------------------------------
# derive_all (§3.1): the single pipeline

def derive_all(manifest_path, package, workspace, house_root,
               ledger_path, sessions_dir=None, keys_dir=None,
               package_zip=None):
    """Run every derivation over a bundle. Returns a dict of
    computed values + a list of refusal-grade problems + warnings.
    Build and verify both call this; neither copies."""
    ws = Path(workspace)
    man = json.loads(Path(manifest_path).read_text())
    d = {"problems": [], "warnings": [], "man": man}
    statuses_f = ws / "statuses.json"
    events_f = ws / "event_log.jsonl"
    if not statuses_f.exists() or not events_f.exists():
        d["problems"].append("workspace lacks statuses.json or "
                             "event_log.jsonl")
        return d
    recorded = json.loads(statuses_f.read_text())
    events = [json.loads(ln) for ln in events_f.read_text()
              .splitlines() if ln.strip()]
    d["recorded"] = recorded
    d["confinement"] = recorded.get("confinement")
    # 1. statuses from events (shared gate)
    derived, dprobs = derive_statuses(events, man["instruments"])
    d["derive_problems"] = dprobs
    d["statuses"] = {k: v["status"] for k, v in derived.items()}
    d["degradations"] = {k: v["degradations"]
                         for k, v in derived.items()}
    # 2. overall recomputed — never copied
    d["overall"] = overall_status(man["instruments"], d["statuses"])
    if recorded.get("overall") != d["overall"]:
        d["problems"].append(
            f"OVERALL DIVERGENCE: statuses.json records "
            f"{recorded.get('overall')}; the pipeline recomputes "
            f"{d['overall']} — statuses were edited after the run, "
            f"or overall was hand-set (P6)")
    if recorded.get("statuses") and \
            {k: v.get("status") for k, v in
             recorded["statuses"].items()} != d["statuses"]:
        d["problems"].append(
            "STATUS DIVERGENCE: statuses.json disagrees with the "
            "event log derivation")
    if elog_head(events) != recorded.get("event_log_head"):
        d["problems"].append(
            "event_log_head in statuses.json does not match the "
            "presented log (the log was extended or replaced)")
    d["event_log_head"] = elog_head(events)
    # 3. lock table recomputed from the real package
    if package is not None:
        table, _ = aavep_preflight.compute_lock_table(
            manifest_path, package, ws, house_root, False,
            package_zip=package_zip)
        recorded_lock_f = ws / "locktable.json"
        recorded_lock = json.loads(recorded_lock_f.read_text()) \
            if recorded_lock_f.exists() else None
        d["lock"] = table
        if recorded_lock != table:
            d["problems"].append(
                "LOCKS DIVERGE: the recomputed lock table differs "
                "from the bundle's recorded one")
        pin = man["target"].get("package_manifest_sha256")
        d["package_manifest_pin"] = pin
        d["package_manifest_observed"] = table.get(
            "target", {}).get("package_manifest_sha256")
    else:
        d["lock"] = None
        d["warnings"].append(
            "LOCKS NOT RE-VERIFIED: no package presented; the top "
            "stamp is unavailable")
    # 4-5. ledger: chain, event-log binding, receipts, SL-2b
    entries = aavep_ledger.load(ledger_path)
    lv = aavep_ledger.verify(ledger_path)
    d["ledger_valid"] = lv["valid"]
    d["ledger_head"] = lv["head"]
    d["findings"] = lv["findings"]
    genesis = entries[0].get("payload", {}) if entries else {}
    d["genesis"] = genesis
    d["session_open_ts"] = entries[0].get("ts") if entries else None
    if not lv["valid"]:
        d["problems"].append(
            "ledger chain/lifecycle invalid: " + "; ".join(
                lv["problems"][:3]))
    notes = [e for e in entries if e["type"] == "NOTE"
             and e.get("payload", {}).get("event")
             == "EVENT_LOG_HEAD"]
    d["eventlog_binding"] = "NOT RECORDED"
    if notes:
        bound_head = notes[-1].get("payload", {}).get(
            "event_log_head")
        if bound_head != d["event_log_head"]:
            d["problems"].append(
                "EVENT-LOG BINDING BROKEN: the ledger records head "
                f"{bound_head}; the presented log's head is "
                f"{d['event_log_head']} (B-26)")
            d["eventlog_binding"] = "MISMATCH"
        else:
            d["eventlog_binding"] = "BOUND"
            fields = genesis.get("report_fields", {})
            if fields.get("anchor") == "UNANCHORED":
                d["warnings"].append(
                    "event-log binding: UNANCHORED-BOUND — the "
                    "binding is recorded in a ledger whose anchor "
                    "is UNANCHORED (B-26)")
                d["eventlog_binding"] = "BOUND · UNANCHORED-BOUND"
    bundle_docs = []
    for p in sorted(ws.rglob("*.json")):
        try:
            bundle_docs.append(json.loads(p.read_text()))
        except Exception:
            pass
    d["receipt_grades"] = grade_receipts(
        genesis, sessions_dir, keys_dir, bundle_docs)
    for g in d["receipt_grades"]:
        if g["grade"] == "UNVERIFIED":
            d["warnings"].append(
                f"genesis receipt UNVERIFIED: {g['operator']} — "
                f"{g['detail']}")
    if d["lock"] is not None:
        store_dirs = [ws / "store"]
        probs, trivial = sl2b_check_bundle(entries, d["lock"],
                                           store_dirs)
        d["sl2b_problems"] = probs
        d["witness_trivial"] = trivial
        if probs:
            d["problems"].append(
                "SL-2b FAILED (quotes unverified): "
                + "; ".join(probs[:3]))
    else:
        d["sl2b_problems"] = ["QUOTES-UNVERIFIED (no lock table)"]
        d["witness_trivial"] = []
        d["warnings"].append("SL-2b: QUOTES-UNVERIFIED — no package "
                             "presented")
    # grounding summary (labels only; the ledger tool owns verdicts)
    d["grounding"] = aavep_ledger.verify2(
        ledger_path, bundle_dir=ws)["genesis"]
    return d


def elog_head(events):
    return events[-1]["event_hash"] if events else None


# ------------------------------------------------------------------
# record + envelope

def status_vector_lines(d):
    man = d["man"]
    declared_markers = sum(len(i.get("partial_markers", []) or [])
                           for i in man["instruments"])
    advisory = sum(1 for i in man["instruments"]
                   for e in expectations_of(i) if e["advisory"])
    hard = sum(1 for i in man["instruments"]
               for e in expectations_of(i) if not e["advisory"])
    lines = [f"confinement: {d.get('confinement')}",
             f"markers: {len(PROTOCOL_DEFAULT_MARKERS)} "
             f"protocol-default + {declared_markers} manifest-declared;"
             f" expectations: {hard} hard, {advisory} advisory"]
    for inst in man["instruments"]:
        iid = inst["id"]
        st = d["statuses"].get(iid, "MISSING")
        deg = d.get("degradations", {}).get(iid) or []
        lines.append(f"{iid}: {st}"
                     + (f" [{', '.join(deg)}]" if deg else ""))
    n_failed = sum(1 for s in d["statuses"].values()
                   if s == "FAILED")
    lines.append(f"OVERALL (recomputed): {d['overall']} · "
                 f"{n_failed} FAILED")
    return lines


def build_record(d, fields):
    man = d["man"]
    rec = {
        "overall": d["overall"],
        "ledger_head_hash": d["ledger_head"],
        "manifest_sha256": d["genesis"].get("manifest_sha256"),
        "session_open_ts": d.get("session_open_ts"),
        "statuses": d["statuses"],
        "confinement": d.get("confinement"),
        "grounding": {
            "target_sha256": d["genesis"].get("target_sha256"),
            "manifest_sha256": d["genesis"].get("manifest_sha256"),
            "kit_manifest_sha256": sha256_file(
                KIT / "AAVEP_MANIFEST.sha256")
            if (KIT / "AAVEP_MANIFEST.sha256").exists() else None},
        "integrity": {
            "target_manifest_pin": d.get("package_manifest_pin"),
            "target_manifest_observed":
                d.get("package_manifest_observed"),
            "receipt_grades": d["receipt_grades"],
            "ledger_genesis": d["grounding"],
            "eventlog_binding": d.get("eventlog_binding"),
            "sl2b_problems": d.get("sl2b_problems"),
            "witness_trivial": d.get("witness_trivial"),
            "anchor": fields.get("anchor", "UNANCHORED"),
        },
        "findings": {fid: {"state": st["state"]}
                     for fid, st in d["findings"].items()},
        "status_vector": status_vector_lines(d),
        "warnings": d["warnings"],
        "residue": aavep_ledger.RESIDUE,
    }
    return rec


def stamp_for(d):
    if d["problems"]:
        return "FORMATTED — NOT ENGINE-VALIDATED", \
            "derivation problems: " + "; ".join(d["problems"][:3])
    if d.get("lock") is None:
        return "FORMATTED — NOT ENGINE-VALIDATED", \
            "LOCKS NOT RE-VERIFIED"
    if d.get("sl2b_problems"):
        return "FORMATTED — NOT ENGINE-VALIDATED", \
            "SL-2b: QUOTES-UNVERIFIED"
    for g in d["receipt_grades"]:
        if g["grade"] not in RECEIPT_OK_FOR_STAMP + ("LEGACY-CUSTODY",):
            return "FORMATTED — NOT ENGINE-VALIDATED", \
                f"genesis receipt grade {g['grade']} for " \
                f"{g['operator']}"
        if g["grade"] == "LEGACY-CUSTODY":
            return "FORMATTED — NOT ENGINE-VALIDATED", \
                "LEGACY-CUSTODY receipts cap the stamp in the " \
                "report path (their re-score is the runner's)"
    return "ENGINE-VALIDATED", "all derivations pass"


ZERO = "0" * 64


def derive_uuid(seed_text: str) -> str:
    """Deterministic UUID from bundle material (v1.0 form)."""
    h = list(sha256_bytes(seed_text.encode())[:32])
    h[12] = "4"
    h[16] = "89ab"[int(h[16], 16) % 4]
    return str(uuid.UUID("".join(h)))


def build_envelope(record, fields):
    """The ESP v2.4 envelope (v1.0 construction, unchanged): the
    audit record rides as canonical JSON in the payload; the
    envelope is validated by the vendored engine, never by this
    tool's own say-so."""
    content = json.dumps(record, sort_keys=True,
                         separators=(",", ":"), ensure_ascii=False)
    env = {
        "protocol": {"name": "ESP", "version": "2.4"},
        "header": {
            "message_id": derive_uuid(
                (record["ledger_head_hash"] or "")
                + (record["manifest_sha256"] or "")),
            "message_type": "AUDIT_RECEIPT",
            "protocol_version": "2.4", "min_protocol_version": "2.4",
            "sender_agent": fields["sender"],
            "target_agent": fields["target_agent"],
            "timestamp": record["session_open_ts"],
        },
        "envelope_tier": "archival",
        "epistemic_context": {
            "session_id": fields["session_id"],
            "register": "META_AUDIT", "badge": "META",
            "axiom_set_hash": ZERO, "registry_version": 0,
            "scope_notes": "AAVEP audit report envelope. The audit "
                           "record rides as canonical JSON in "
                           "payload content; witness text stays in "
                           "the run bundle, referenced by hash.",
        },
        "payload": {
            "format": "AUDIT_REPORT", "content": content,
            "claim_class": "OBSERVATIONAL",
            "provenance": {"lineage": "prose", "depends_on": []},
            "determinism": {"mode": "DETERMINISTIC"},
            "falsification": {"conditions": [{
                "id": "C1",
                "statement": "This report is falsified if "
                             "recomputation from its run bundle "
                             "yields a different envelope hash."}]},
            "metadata": record,
        },
        "integrity": {"content_hash": "", "envelope_hash": "",
                      "axiom_set_hash": ZERO, "registry_version": 0,
                      "status": "PENDING", "tier": "machine"},
    }
    env["integrity"]["content_hash"] = sha256_bytes(content.encode())
    for_hash = {k: env[k] for k in
                ("protocol", "header", "envelope_tier", "payload",
                 "epistemic_context")}
    env["integrity"]["envelope_hash"] = sha256_bytes(
        canonical(for_hash))
    return env


def esp_validate(envelope_path):
    """Validate an envelope with the vendored ESP engine
    (esp_cli.py, chat-tier demo registry — its caveat is printed
    wherever the stamp is used, as in v1.0)."""
    import subprocess
    cmd = [sys.executable, str(KIT / "esp" / "esp_cli.py"),
           "validate", "--format", "json", str(envelope_path)]
    p = subprocess.run(cmd, capture_output=True, text=True,
                       timeout=120)
    verdict = None
    try:
        verdict = json.loads(p.stdout)[0]
    except Exception:
        pass
    return p.returncode == 0 and bool(verdict and verdict.get("ok"))


def run_pipeline(args, mode):
    print(DISC)
    manifest_path = Path(args.manifest)
    entries = aavep_ledger.load(args.ledger)
    genesis_fields = None
    if entries:
        genesis_fields = entries[0].get("payload", {}).get(
            "report_fields")
    fields = genesis_fields or {
        "sender": "aavep-report", "target_agent": "reader",
        "session_id": "unspecified", "anchor": "UNANCHORED"}
    d = derive_all(manifest_path, args.package, args.workspace,
                   args.house_root, args.ledger,
                   sessions_dir=args.cal_sessions,
                   keys_dir=args.cal_keys,
                   package_zip=args.package_zip)
    rec = build_record(d, fields)
    stamp, reason = stamp_for(d)
    if d["problems"]:
        print(f"REFUSED ({mode}): the pipeline's derivations fail:")
        for p in d["problems"]:
            print("  -", p)
        for w in d["warnings"]:
            print("  warning:", w)
        return None, d, fields, stamp, reason
    rec["stamp"] = stamp
    rec["stamp_reason"] = reason
    return rec, d, fields, stamp, reason


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_report")
    ap.add_argument("--behaviours", action="store_true")
    sub = ap.add_subparsers(dest="cmd")
    for name in ("build", "verify"):
        p = sub.add_parser(name)
        p.add_argument("--manifest", required=True)
        p.add_argument("--package")
        p.add_argument("--package-zip")
        p.add_argument("--workspace", required=True)
        p.add_argument("--ledger", required=True)
        p.add_argument("--house-root", default=str(Path.home()))
        p.add_argument("--cal-sessions",
                       help="dir of CAL session trees (admin and/or "
                            "subject) for receipt re-scoring")
        p.add_argument("--cal-keys",
                       help="dir of published CAL key files")
        p.add_argument("--envelope-out")
        p.add_argument("--record-out")
    args = ap.parse_args(argv)
    if args.behaviours:
        print(json.dumps(behaviours_for("aavep_report"), indent=1))
        return 0
    if args.cmd not in ("build", "verify"):
        ap.print_help()
        return 2
    rec, d, fields, stamp, reason = run_pipeline(args, args.cmd)
    if rec is None:
        return 1
    if args.cmd == "build":
        env = build_envelope(rec, fields)
        env_path = Path(args.envelope_out) if args.envelope_out \
            else Path(args.workspace) / "envelope.json"
        env_path.write_text(json.dumps(env, indent=1))
        engine_ok = esp_validate(env_path)
        if stamp == "ENGINE-VALIDATED" and not engine_ok:
            stamp = "FORMATTED — NOT ENGINE-VALIDATED"
            reason = "the ESP engine did not validate the envelope"
        rec["stamp"] = stamp
        rec["stamp_reason"] = reason
        rec["envelope_hash"] = env["integrity"]["envelope_hash"]
        if args.record_out:
            Path(args.record_out).write_text(json.dumps(rec,
                                                         indent=1))
        print(f"built: overall {rec['overall']} · "
              f"{sum(1 for s in rec['statuses'].values() if s == 'FAILED')} "
              f"FAILED — stamp {stamp}")
        for ln in rec["status_vector"]:
            print(" ", ln)
        for g in rec["integrity"]["receipt_grades"]:
            print(f"  receipt {g['operator']}: {g['grade']} — "
                  f"{g['detail']}")
        print("  event-log binding:",
              rec['integrity']['eventlog_binding'])
        print("  genesis:",
              rec['integrity']['ledger_genesis']['state'])
        return 0
    # verify: recompute and compare against the recorded record
    if not args.record_out:
        print("verify needs --record-out naming the recorded record "
              "to compare against")
        return 2
    recorded = json.loads(Path(args.record_out).read_text())
    fresh = {k: rec[k] for k in ("overall", "statuses", "confinement",
                                  "findings", "integrity", "grounding",
                                  "status_vector")}
    stale = {k: recorded.get(k) for k in fresh}
    if fresh != stale:
        print("VERIFY FAILED: the recorded record diverges from "
              "the recomputation")
        print("  recorded:", json.dumps(stale, sort_keys=True)[:600])
        print("  recomputed:", json.dumps(fresh, sort_keys=True)[:600])
        return 1
    env = build_envelope(rec, fields)
    if env["integrity"]["envelope_hash"] != \
            recorded.get("envelope_hash"):
        print("VERIFY FAILED: the envelope does not recompute "
              "byte-identically")
        return 1
    engine_ok = esp_validate(Path(args.envelope_out)) \
        if args.envelope_out and Path(args.envelope_out).exists() \
        else False
    print(f"verified: overall {rec['overall']} · "
          f"{sum(1 for s in rec['statuses'].values() if s == 'FAILED')} "
          f"FAILED — stamp {stamp} — "
          f"envelope recomputes byte-identically: True — engine "
          f"revalidates: {engine_ok}")
    for g in rec["integrity"]["receipt_grades"]:
        print(f"  receipt {g['operator']}: {g['grade']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
