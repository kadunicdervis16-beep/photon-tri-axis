#!/usr/bin/env python3
"""aavep_ledger — append-only, hash-chained adjudication ledger (AAVEP D6).

INPUT_PROVENANCE:
  paper-defined:       NONE. The ledger records an audit's events; it
                       reads no paper.
  cited-paper:         NONE.
  control:             the entry vocabulary and finding-lifecycle rules of
                       the AAVEP design §4.5 as amended (A-14, A-19, A-21,
                       A-25): hash chaining, role separation checked over
                       declared operator identities, no SUSTAINED before a
                       reproduction, overturns appended never edited.
  declared-assumption: operator identities are declared strings; the chain
                       proves consistency of the record, not the truth of
                       an identity (design FM-1/FM-5 residuals, printed).
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: ledger entry streams (JSONL) of one audit run.
  (2) Verified domain: hash-chain integrity; entry-type legality; finding
      lifecycle legality (a finding is born UNADJUDICABLE; ADJUDICATION
      with SUSTAINED / PARTIALLY_SUSTAINED is effective only after a
      REPRODUCED_* entry, with adjudicator countersignature when the
      reproduction was SAME-HOUSE); role-conflict voiding.
  (3) Map: canonical JSON serialisation + sha256 chaining
      (entry_hash = sha256(prev_hash || canonical(entry sans entry_hash))).
  (4) What the map preserves: order and tamper-evidence of the
      adjudication history; overturned findings ship with the record.
  (5) What stays outside the machine check: the correctness of any ruling
      recorded in the ledger; the ledger's antiquity (an UNANCHORED chain
      proves internal consistency, not history — design FM-5).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import (ADJUDICATIONS, ENTRY_TYPES, REPRO_OUTCOMES,  # noqa: E402
                       canonical, disclosure, now_iso, sha256_bytes)

GENESIS_PREV = "0" * 64


def entry_hash(entry: dict) -> str:
    body = {k: v for k, v in entry.items() if k != "entry_hash"}
    return sha256_bytes(entry["prev_hash"].encode() + canonical(body))


def load(path):
    entries = []
    p = Path(path)
    if p.is_file():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                entries.append(json.loads(line))
    return entries


def append(path, type_, operator, payload):
    """Append one entry; returns the entry. Lifecycle legality is NOT
    enforced here (history must be recordable); it is enforced by
    compute_states/verify, and an illegal sequence fails verification."""
    if type_ not in ENTRY_TYPES:
        raise ValueError(f"unknown entry type: {type_}")
    entries = load(path)
    prev = entries[-1]["entry_hash"] if entries else GENESIS_PREV
    e = {"seq": len(entries), "ts": now_iso(), "type": type_,
         "operator": operator, "payload": payload, "prev_hash": prev}
    e["entry_hash"] = entry_hash(e)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return e


def head(path):
    entries = load(path)
    return entries[-1]["entry_hash"] if entries else GENESIS_PREV


def compute_states(entries):
    """Finding lifecycles + adjudication effectiveness, per §4.3/§4.5."""
    findings = {}
    problems = []
    amendments = 0
    for e in entries:
        t, p, op = e["type"], e.get("payload", {}), e.get("operator")
        if t == "MANIFEST_AMENDMENT":
            amendments += 1
            if amendments > 1:
                problems.append(f"seq {e['seq']}: second MANIFEST_AMENDMENT "
                                "(A-30 allows at most one per run)")
        if t == "FINDING_FILED":
            fid = p.get("finding_id")
            if fid in findings:
                problems.append(f"seq {e['seq']}: duplicate finding {fid}")
            findings[fid] = {"filer": op, "state": "UNADJUDICABLE",
                             "packet": p.get("packet"), "history": [e["seq"]]}
        elif t in ("REPRODUCTION_PHASE1", "REPRODUCTION"):
            fid = p.get("finding_id")
            if fid not in findings:
                problems.append(f"seq {e['seq']}: {t} for unknown finding {fid}")
                continue
            f = findings[fid]
            f["history"].append(e["seq"])
            if t == "REPRODUCTION_PHASE1":
                if "phase1" in f:
                    problems.append(f"seq {e['seq']}: second PHASE1 for {fid}")
                f["phase1"] = {"operator": op,
                                "commitment_sha256": p.get("commitment_sha256")}
            else:
                if "phase1" not in f:
                    problems.append(
                        f"seq {e['seq']}: REPRODUCTION for {fid} without a "
                        "prior REPRODUCTION_PHASE1 commitment (A-19)")
                if p.get("outcome") not in REPRO_OUTCOMES:
                    problems.append(f"seq {e['seq']}: bad outcome "
                                    f"{p.get('outcome')}")
                f["reproduction"] = {"operator": op,
                                     "outcome": p.get("outcome")}
                if p.get("outcome") in ("REPRODUCED_INDEPENDENT",
                                        "REPRODUCED_SAME_HOUSE"):
                    f["state"] = "ADJUDICABLE"
                elif p.get("outcome") == "NOT_REPRODUCED":
                    f["state"] = "UNRESOLVED-OBSERVATION"
                elif p.get("outcome") == "CANNOT_ATTEMPT":
                    f["state"] = "UNRESOLVED"
        elif t == "ADJUDICATION":
            fid = p.get("finding_id")
            if fid not in findings:
                problems.append(f"seq {e['seq']}: ADJUDICATION for unknown "
                                f"finding {fid}")
                continue
            f = findings[fid]
            f["history"].append(e["seq"])
            outcome = p.get("outcome")
            if outcome not in ADJUDICATIONS:
                problems.append(f"seq {e['seq']}: bad adjudication {outcome}")
                continue
            roles = {"filer": f.get("filer"),
                     "reproducer": f.get("reproduction", {}).get("operator"),
                     "adjudicator": op}
            ids = [v for v in roles.values() if v]
            role_conflict = len(ids) != len(set(ids))
            effective = True
            if outcome in ("SUSTAINED", "PARTIALLY_SUSTAINED", "OVERTURNED"):
                # Every dispositive ruling requires a reproduced finding
                # (loop repair: an unreproduced finding cannot be buried
                # by OVERTURNED any more than it can be sustained).
                if f["state"] != "ADJUDICABLE":
                    problems.append(
                        f"seq {e['seq']}: {outcome} for {fid} before a "
                        f"successful reproduction (state {f['state']})")
                    effective = False
                repro = f.get("reproduction", {})
                if repro.get("outcome") == "REPRODUCED_SAME_HOUSE" and \
                        not p.get("countersignature"):
                    problems.append(
                        f"seq {e['seq']}: {outcome} for {fid} on a SAME-HOUSE "
                        "reproduction without adjudicator countersignature "
                        "(A-19)")
                    effective = False
            if outcome == "UNRESOLVED" and f["state"] in (
                    "SUSTAINED", "PARTIALLY_SUSTAINED", "OVERTURNED"):
                problems.append(
                    f"seq {e['seq']}: UNRESOLVED adjudication cannot "
                    f"retract a decided finding ({fid} is {f['state']}); "
                    "a later ruling must be a new adjudication of a "
                    "re-filed finding")
                effective = False
            if role_conflict:
                # A-14: the ruling is recorded; its effect is void.
                effective = False
                f["state"] = "UNRESOLVED"
                f["adjudication"] = {"operator": op, "outcome": outcome,
                                     "effect": "VOID_ROLE_CONFLICT",
                                     "roles": roles}
                problems.append(
                    f"seq {e['seq']}: ROLE-CONFLICT in adjudication of "
                    f"{fid} — effect void, finding returns to UNRESOLVED")
            elif effective:
                f["state"] = outcome
                f["adjudication"] = {"operator": op, "outcome": outcome,
                                     "effect": "EFFECTIVE", "roles": roles}
            else:
                f["adjudication"] = {"operator": op, "outcome": outcome,
                                     "effect": "INEFFECTIVE", "roles": roles}
    return findings, problems


def verify(path):
    entries = load(path)
    problems = []
    # Genesis (A-25): the first entry must be SESSION_OPEN carrying the
    # session's identity — target hash, manifest hash, and the
    # calibration receipts the run's findings rest on.
    if not entries:
        problems.append("ledger is empty — no SESSION_OPEN genesis")
    else:
        g = entries[0]
        if g.get("type") != "SESSION_OPEN":
            problems.append("entry 0 is not SESSION_OPEN (A-25 genesis)")
        else:
            gp = g.get("payload", {})
            for field in ("target_sha256", "manifest_sha256"):
                if not gp.get(field):
                    problems.append(f"genesis SESSION_OPEN lacks {field} "
                                    "(A-25)")
            receipts = gp.get("calibration_receipts")
            if not isinstance(receipts, list) or not receipts:
                problems.append("genesis SESSION_OPEN lacks "
                                "calibration_receipts (A-25)")
            else:
                for r in receipts:
                    v1_shape = all(r.get(k) for k in
                                   ("operator", "tier",
                                    "transcript_sha256"))
                    v2_shape = all(r.get(k) for k in
                                   ("operator_id", "tier",
                                    "transcript_sha256",
                                    "session_commitment"))
                    if not (v1_shape or v2_shape):
                        problems.append("genesis calibration receipt "
                                        "incomplete (v1: operator/tier/"
                                        "transcript_sha256; v2: "
                                        "operator_id/tier/"
                                        "transcript_sha256/"
                                        "session_commitment)")
    prev = GENESIS_PREV
    for i, e in enumerate(entries):
        if e.get("seq") != i:
            problems.append(f"entry {i}: seq is {e.get('seq')}")
        if e.get("prev_hash") != prev:
            problems.append(f"entry {i}: prev_hash mismatch (chain break)")
        if e.get("entry_hash") != entry_hash(e):
            problems.append(f"entry {i}: entry_hash mismatch (tampered)")
        if e.get("type") not in ENTRY_TYPES:
            problems.append(f"entry {i}: unknown type {e.get('type')}")
        prev = e.get("entry_hash", prev)
    findings, life_problems = compute_states(entries)
    problems.extend(life_problems)
    return {"entries": len(entries), "head": prev, "findings": findings,
            "problems": problems, "valid": not problems}


DISC = disclosure(
    "ledger entry streams (JSONL) of one audit run",
    "hash-chain integrity, entry-type legality, finding-lifecycle legality, "
    "role-conflict voiding",
    "canonical JSON serialisation + sha256 chaining",
    "order and tamper-evidence of the adjudication history",
    "the correctness of any ruling recorded; the ledger's antiquity "
    "(UNANCHORED chains prove consistency, not history)")

# ------------------------------------------------------------------
# v1.1 split verdict (design §4 as amended B-20/B-23/B-27/B-28).
# The chain format and lifecycle above are v1.0's, unchanged. What
# v1.1 changes is the verdict vocabulary: verify never prints an
# unqualified "valid" — it prints CHAIN-VALID / CHAIN-INVALID,
# GENESIS GROUNDED / UNGROUNDED (naming the pins used), a grade per
# genesis receipt, and the UNVERIFIED-ROOT anchor label.

RESIDUE = ("residue: a valid chain proves the recorded history was "
           "not rewritten after the fact, given an externally "
           "checked head; it does not prove the history happened.")


def _bundle_hashes(bundle_dir):
    """Candidate target/manifest/kit hashes from JSON artifacts in a
    presented bundle (lock table, envelope, report record)."""
    from aavep_lib import is_hash
    found = {"target": set(), "manifest": set(), "kit": set()}
    if not bundle_dir:
        return found
    for p in sorted(Path(bundle_dir).rglob("*.json")):
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        stack = [doc]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                t = node.get("target")
                if isinstance(t, dict) and is_hash(
                        t.get("observed_sha256")):
                    found["target"].add(t["observed_sha256"])
                if is_hash(node.get("target_sha256")):
                    found["target"].add(node["target_sha256"])
                g = node.get("grounding")
                if isinstance(g, dict):
                    for k, slot in (("target_sha256", "target"),
                                    ("manifest_sha256", "manifest"),
                                    ("kit_manifest_sha256", "kit")):
                        if is_hash(g.get(k)):
                            found[slot].add(g[k])
                if is_hash(node.get("manifest_sha256")):
                    found["manifest"].add(node["manifest_sha256"])
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
    return found


def _freeze_root(p: Path):
    cur = p.resolve()
    while cur != cur.parent:
        if any(cur.glob("AAVEP_FREEZE_*.md")):
            return cur
        cur = cur.parent
    return None


def verify2(path, bundle_dir=None, expect_head=None, expect_kit=None,
            expect_manifest=None, anchor_file=None,
            intree_anchor_files=(), sessions_dir=None):
    """The v1.1 verdict over the v1.0 chain/lifecycle substrate."""
    from aavep_lib import sha256_file
    base = verify(path)
    entries = load(path)
    genesis = entries[0].get("payload", {}) if entries else {}
    verdict = {"chain": "CHAIN-VALID" if base["valid"]
               else "CHAIN-INVALID",
               "problems": list(base["problems"]),
               "head": base["head"], "entries": base["entries"],
               "findings": base["findings"],
               "genesis": {}, "receipts": [], "anchor_labels": []}
    pins = []
    if expect_head:
        pins.append("externally supplied --expect-head")
        if expect_head != base["head"]:
            verdict["problems"].append(
                "HEAD MISMATCH against the externally supplied pin")
            verdict["chain"] = "CHAIN-INVALID"
    bh = _bundle_hashes(bundle_dir)
    g_target = genesis.get("target_sha256")
    g_manifest = genesis.get("manifest_sha256")
    g_kit = genesis.get("kit_sha256")
    checks = []
    if bundle_dir and g_target:
        checks.append(("target", g_target in bh["target"]))
    if bundle_dir and g_manifest:
        checks.append(("manifest", g_manifest in bh["manifest"]))
    if bundle_dir and g_kit:
        checks.append(("kit", g_kit in bh["kit"]))
    if expect_manifest:
        pins.append("externally supplied --expect-manifest")
        checks.append(("manifest-pin", expect_manifest == g_manifest))
    if expect_kit:
        pins.append("externally supplied --expect-kit")
        checks.append(("kit-pin", expect_kit == g_kit))
    if any(not ok for _, ok in checks):
        bad = [n for n, ok in checks if not ok]
        verdict["genesis"] = {
            "state": "INVALID (GENESIS-MISMATCH)",
            "detail": f"genesis fields fail against: {bad}"}
        verdict["problems"].append(
            f"genesis mismatch on: {', '.join(bad)}")
    elif checks:
        verdict["genesis"] = {
            "state": "GENESIS GROUNDED" if pins else
                     "GENESIS GROUNDED (bundle-internal pins only)",
            "detail": f"resolved against: {[n for n, _ in checks]}; "
                      f"pins: {pins or ['bundle-internal only']}"}
    else:
        verdict["genesis"] = {
            "state": "GENESIS UNGROUNDED",
            "detail": "no bundle artifacts or external pins "
                      "presented; genesis field presence proves "
                      "nothing (P3)"}
    import aavep_cal
    sessions = {}
    if sessions_dir:
        for d in Path(sessions_dir).iterdir():
            rec_f = d / "admin_record.json"
            if rec_f.exists():
                try:
                    rec = json.loads(rec_f.read_text())
                    sessions[rec["session_id"]] = d
                except Exception:
                    pass
    bundle_docs = []
    if bundle_dir:
        for p in sorted(Path(bundle_dir).rglob("*.json")):
            try:
                bundle_docs.append(json.loads(
                    p.read_text(encoding="utf-8")))
            except Exception:
                pass
    # COMMITMENT-ONLY (B-27: grades per section 3's definitions)
    # requires the receipt core to recompute AND the commitment
    # to be found in a record independent of the receipt itself:
    # the genesis is searched WITHOUT its calibration_receipts
    # (which carry the receipt's own copy). Repaired by the v1.1
    # loop pass: the red team's ghost receipt (transcript_sha256
    # 3333...) graded COMMITMENT-ONLY here because neither check
    # ran on this path.
    genesis_core = {k: v for k, v in genesis.items()
                    if k != "calibration_receipts"}
    for r in genesis.get("calibration_receipts", []) or []:
        if isinstance(r, dict) and r.get("session_commitment"):
            res = {"operator": r.get("operator_id"),
                   "session_id": r.get("session_id")}
            if r.get("session_id") in sessions:
                res["grade"] = "PRESENTED-ADMIN (re-score is the " \
                               "report path's step)"
            elif aavep_cal._receipt_core_ok(r) and any(
                    aavep_cal._commitment_found(
                        r["session_commitment"], b)
                    for b in [genesis_core] + bundle_docs
                    if not (isinstance(b, dict) and
                            b.get("transcript_sha256")
                            == r.get("transcript_sha256"))):
                res["grade"] = "COMMITMENT-ONLY"
            else:
                res["grade"] = "UNVERIFIED"
            verdict["receipts"].append(res)
        elif isinstance(r, dict):
            verdict["receipts"].append({
                "operator": r.get("operator"),
                "grade": "LEGACY-CUSTODY",
                "detail": "v1 receipt under v1 seed custody; in the "
                          "shipped v1.0 record the seeds are in "
                          "fact published (B-5) — the standing "
                          "label, not a defect in this run"})
    if anchor_file:
        ah = sha256_file(anchor_file)
        intree_hashes = {sha256_file(f) for f in intree_anchor_files
                         if Path(f).exists()}
        root = _freeze_root(Path(path))
        under_root = root is not None and \
            root in Path(anchor_file).resolve().parents
        if ah in intree_hashes or under_root:
            verdict["anchor_labels"].append(
                "UNVERIFIED-ROOT: the presented anchor is "
                "hash-identical to / located within the ledger's "
                "own tree; it attests distribution, not independence")
        if base["head"] and base["head"] in \
                Path(anchor_file).read_text(errors="replace"):
            verdict["anchor_labels"].append(
                "anchor names this ledger's head")
    verdict["residue"] = RESIDUE
    return verdict


def print_verdict(v):
    print(f"{v['chain']} · {v['genesis'].get('state', '')} · "
          f"entries {v['entries']} · head {v['head']}")
    print(f"  genesis: {v['genesis'].get('detail', '')}")
    for r in v["receipts"]:
        print(f"  receipt {r.get('operator')}: {r['grade']}"
              + (f" — {r['detail']}" if r.get("detail") else ""))
    for lbl in v["anchor_labels"]:
        print(f"  {lbl}")
    for p in v["problems"]:
        print(f"  PROBLEM: {p}")
    print(" ", v["residue"])


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_ledger")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("ledger")
    p.add_argument("--operator", required=True)
    p.add_argument("--payload", required=True, help="JSON file: SESSION_OPEN payload")
    p = sub.add_parser("append"); p.add_argument("ledger")
    p.add_argument("--type", required=True); p.add_argument("--operator", required=True)
    p.add_argument("--payload", required=True, help="JSON file with the payload object")
    p = sub.add_parser("verify"); p.add_argument("ledger")
    p.add_argument("--bundle")
    p.add_argument("--expect-head")
    p.add_argument("--expect-kit")
    p.add_argument("--expect-manifest")
    p.add_argument("--anchor-file")
    p.add_argument("--intree-anchor", action="append", default=[])
    p.add_argument("--sessions-dir")
    p.add_argument("--strict", action="store_true",
                   help="exit non-zero unless the chain is valid, "
                        "the genesis is grounded, and no receipt is "
                        "UNVERIFIED (B-20)")
    p.add_argument("--json", action="store_true",
                   help="also print the v1.0-shaped verdict dict")
    p.add_argument("--behaviours", action="store_true")
    p = sub.add_parser("head"); p.add_argument("ledger")
    a = ap.parse_args(argv)
    if getattr(a, "behaviours", False):
        from aavep_lib import behaviours_for
        print(json.dumps(behaviours_for("aavep_ledger"), indent=1))
        return 0
    print(DISC)
    if a.cmd == "init":
        if Path(a.ledger).exists():
            print("REFUSED: ledger already exists (append-only)"); return 2
        payload = json.loads(Path(a.payload).read_text(encoding="utf-8"))
        e = append(a.ledger, "SESSION_OPEN", a.operator, payload)
        print(f"SESSION_OPEN seq=0 head={e['entry_hash']}")
        return 0
    if a.cmd == "append":
        payload = json.loads(Path(a.payload).read_text(encoding="utf-8"))
        e = append(a.ledger, a.type, a.operator, payload)
        print(f"appended seq={e['seq']} type={a.type} hash={e['entry_hash']}")
        return 0
    if a.cmd == "verify":
        v = verify2(a.ledger, bundle_dir=a.bundle,
                    expect_head=a.expect_head, expect_kit=a.expect_kit,
                    expect_manifest=a.expect_manifest,
                    anchor_file=a.anchor_file,
                    intree_anchor_files=a.intree_anchor,
                    sessions_dir=a.sessions_dir)
        print_verdict(v)
        if a.json:
            r = verify(a.ledger)
            print(json.dumps(r, indent=1, ensure_ascii=False))
        if v["chain"] != "CHAIN-VALID":
            return 1
        if a.strict:
            if v["genesis"]["state"] not in (
                    "GENESIS GROUNDED",
                    "GENESIS GROUNDED (bundle-internal pins only)"):
                return 1
            if any(r["grade"] == "UNVERIFIED" for r in v["receipts"]):
                return 1
        return 0
    if a.cmd == "head":
        print(head(a.ledger)); return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
