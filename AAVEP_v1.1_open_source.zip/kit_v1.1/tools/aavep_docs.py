#!/usr/bin/env python3
"""aavep_docs — documentation conformance checker (design §11, B-34).

INPUT_PROVENANCE:
  paper-defined:       NONE.
  cited-paper:         NONE.
  control:             the behaviour-key registry in aavep_lib
                       (BEHAVIOUR_REGISTRY). Every normative claim in
                       a kit document carries a claim marker naming
                       its key:
                           <!-- claim: aavep_run.run.expectation-gate -->
                       A key pins the selftest case(s) that execute
                       the behaviour. This checker fails a document
                       when: a cited key is unknown; a status /
                       failure-mode / custody claim cites a key with
                       no pinning case (UNPINNED); a safety-class key
                       is claimed by NO checked document (an orphan —
                       an undocumented safety behaviour); or a
                       DEMO_RECORD-class document makes a recompute
                       claim without citing a bundle path that exists
                       (B-8). Sequence markers
                           <!-- sequence: keyA < keyB -->
                       are checked for claim order in the document.
  declared-assumption: the checker verifies the marker discipline,
                       not the prose's fidelity where no case pins
                       it — such claims print UNPINNED in the
                       registry and capability-class claims are the
                       honest remainder.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: the kit's own documents.
  (2) Verified domain: marker/key correspondence and the pinning of
      safety-class keys by named selftest cases.
  (3) Map: marker extraction + registry lookup + case-table
      cross-reference (the selftest asserts the named cases exist
      and pass).
  (4) Preserves: a normative sentence in a kit document cannot
      outrun the machinery that was executed for it.
  (5) Outside the machine check: whether the prose faithfully
      paraphrases its key where the key's cases pin behaviour but
      language remains human.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import BEHAVIOUR_REGISTRY, behaviours_for, disclosure

DISC = disclosure(
    "the kit's documents and their behaviour claims",
    "marker/key correspondence; pinning of safety-class keys",
    "marker extraction + registry lookup",
    "documentation cannot outrun executed machinery",
    "prose fidelity beyond what the pinning cases execute")

SAFETY_CLASSES = {"status", "failure-mode", "custody"}
CLAIM_RE = re.compile(r"<!--\s*claim:\s*([a-z0-9_.\-]+)\s*-->")
SEQ_RE = re.compile(r"<!--\s*sequence:\s*([a-z0-9_.\-]+)\s*<\s*"
                    r"([a-z0-9_.\-]+)\s*-->")
BUNDLE_RE = re.compile(r"<!--\s*bundle-path:\s*([^\s>]+)\s*-->")


def parse_marker(full):
    """Marker form: '<tool>.<key>' with tool in the registry."""
    for tool in BEHAVIOUR_REGISTRY:
        if full.startswith(tool + "."):
            return tool, full[len(tool) + 1:]
    return None, None


def check_docs(doc_paths, root):
    problems, claimed = [], {}
    per_doc = {}
    for dp in doc_paths:
        text = Path(dp).read_text(encoding="utf-8")
        keys = []
        for m in CLAIM_RE.finditer(text):
            full = m.group(1)
            tool, key = parse_marker(full)
            if tool is None:
                problems.append(f"{dp}: unknown behaviour key "
                                f"{full}")
                continue
            entry = BEHAVIOUR_REGISTRY[tool].get(key)
            if entry is None:
                problems.append(f"{dp}: unknown behaviour key "
                                f"{full}")
                continue
            keys.append(full)
            claimed[full] = entry
            if entry["class"] in SAFETY_CLASSES and not entry["cases"]:
                problems.append(
                    f"{dp}: {full} is UNPINNED — a "
                    f"{entry['class']} claim with no pinning selftest "
                    f"case (B-34)")
        for m in SEQ_RE.finditer(text):
            a, b = m.group(1), m.group(2)
            ia = [mm.start() for mm in CLAIM_RE.finditer(text)
                  if mm.group(1) == a]
            ib = [mm.start() for mm in CLAIM_RE.finditer(text)
                  if mm.group(1) == b]
            if not ia or not ib or min(ia) > min(ib):
                problems.append(
                    f"{dp}: sequence claim {a} < {b} not honoured "
                    f"by the document's claim order")
        per_doc[str(dp)] = keys
        # B-8: recompute claims in record-class documents must cite
        # an existing bundle path.
        if "DEMO_RECORD" in Path(dp).name or \
                "RECORD" in Path(dp).name:
            bundles = [m.group(1) for m in BUNDLE_RE.finditer(text)]
            if re.search(r"recompute|recomput", text):
                if not bundles:
                    problems.append(
                        f"{dp}: recompute claims without any "
                        f"bundle-path citation (B-8)")
                for b in bundles:
                    if not (Path(root) / b).exists():
                        problems.append(
                            f"{dp}: cited bundle path does not "
                            f"exist: {b}")
    # orphans: safety-class keys claimed by no checked document
    orphans = []
    for tool, keys in BEHAVIOUR_REGISTRY.items():
        for key, entry in keys.items():
            full = f"{tool}.{key}"
            if entry["class"] in SAFETY_CLASSES \
                    and full not in claimed:
                orphans.append(full)
    for o in orphans:
        problems.append(f"orphan safety key claimed by no checked "
                        f"document: {o}")
    return problems, per_doc, orphans


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_docs")
    ap.add_argument("--behaviours", action="store_true",
                    help="print the full behaviour registry")
    sub = ap.add_subparsers(dest="cmd")
    c = sub.add_parser("check")
    c.add_argument("--root", required=True,
                   help="kit root (bundle paths resolve against it)")
    c.add_argument("--docs", nargs="+", required=True)
    a = ap.parse_args(argv)
    if a.behaviours:
        print(json.dumps(BEHAVIOUR_REGISTRY, indent=1))
        return 0
    if a.cmd == "check":
        print(DISC)
        problems, per_doc, orphans = check_docs(a.docs, a.root)
        for dp, keys in per_doc.items():
            print(f"{dp}: {len(keys)} claim(s)")
        for p in problems:
            print("DOCS-FAIL:", p)
        print("DOCS:", "FAIL" if problems else "PASS",
              f"({sum(len(v) for v in per_doc.values())} claims, "
              f"{len(orphans)} orphans)")
        return 1 if problems else 0
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
