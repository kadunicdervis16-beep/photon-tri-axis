#!/usr/bin/env python3
"""aavep_run — Stage C/D execution on a scratch copy (AAVEP v1.1).

INPUT_PROVENANCE:
  paper-defined:       the target package and its manifest (operator
                       inputs, hash-locked at preflight).
  cited-paper:         NONE.
  control:             AAVEP v1.1 design §§3/5/6 as amended
                       (B-3..B-38): Gate 0 (v2 receipts re-verified
                       under the custody model; v1 receipts labelled
                       LEGACY-CUSTODY); preconditions — kit manifest
                       and package manifest must both verify, and a
                       CAL administrator tree inside the workspace
                       refuses the run (B-29); confinement — manifest
                       path validation at preflight and re-resolution
                       here (ESCAPE-REFUSED), instrument and module
                       bytes placed from the content-addressed store
                       (§5.2), per-instrument write-sets and consumes
                       declarations, process-group kills with a
                       census survivor sweep at every instrument
                       close (B-31), HOME/TMPDIR redirected to
                       runner-owned directories (§5.5/B-7), streamed
                       capped output with a full-stream hash (§5.6),
                       quotas and rlimits (§5.7), the achieved
                       confinement level printed in every status
                       record (ruling 5: attempt-and-print), and the
                       PASSED-DEGRADED rung with the shared
                       expectation gate (§5.3/§6).
  declared-assumption: the host is one machine; process-group and
                       census confinement is the portable floor, and
                       the achieved OS facility is printed, never
                       assumed.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: executing a target package's declared
      instruments.
  (2) Verified domain: statuses derive from the hash-chained event
      log via the shared gate; nothing in the run is asserted beyond
      what the log records.
  (3) Map: preflight lock table recomputed and compared before
      anything executes; every execution is an event.
  (4) Preserves: the target tree is never written (all work happens
      on the scratch copy); the executed bytes are the locked bytes.
  (5) Outside the machine check: arbitrary code's filesystem reach
      beyond the declared interfaces at the portable confinement
      level (design §5.8, printed).
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aavep_cal  # noqa: E402
import aavep_preflight  # noqa: E402
from aavep_lib import (canonical, derive_statuses, disclosure,  # noqa: E402
                       expectations_of, gate_status, is_cache_path,
                       overall_status, parse_sha256_manifest,
                       sha256_bytes, sha256_file)

KIT = Path(__file__).resolve().parent.parent
DISC = disclosure(
    "executing a target package's declared instruments on a scratch "
    "copy",
    "statuses re-derivable from the hash-chained event log under the "
    "shared gate; executed bytes hash-equal to the locked bytes",
    "preflight lock table recomputed and compared pre-run; every "
    "execution is a chained event",
    "target-tree immutability; byte identity of what ran",
    "arbitrary code's reach beyond declared interfaces at the "
    "portable confinement level")

MAX_FILES = 100_000
MAX_TOTAL = 4 * 1024 ** 3
ENV_ALLOWLIST = ("PATH", "LANG", "LC_ALL", "TZ")
DEFAULT_OUTPUT_CEILING = 64 * 1024 * 1024


# ------------------------------------------------------------------
# safe extraction (A-26, refusal classes unchanged)

def _check_member(name, declared_size, running_total):
    if name.startswith(("/", "\\")) or \
            (len(name) > 1 and name[1] == ":"):
        raise ValueError(f"unsafe archive member (absolute): {name!r}")
    parts = [p for p in name.replace("\\", "/").split("/")
             if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise ValueError(f"unsafe archive member (traversal): {name!r}")
    if declared_size is not None and declared_size < 0:
        raise ValueError(f"unsafe archive member (size): {name!r}")
    if running_total > MAX_TOTAL:
        raise ValueError("archive exceeds the 4 GiB extraction cap")


def safe_extract(archive, dest):
    dest = Path(dest)
    archive = Path(archive)
    total = 0
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            infos = z.infolist()
            if len(infos) > MAX_FILES:
                raise ValueError("archive exceeds the file-count cap")
            for info in infos:
                total += max(info.file_size, 0)
                _check_member(info.filename, info.file_size, total)
                if info.is_dir():
                    continue
                mode = (info.external_attr >> 16) & 0o170000
                if mode == 0o120000:
                    raise ValueError(
                        f"unsafe archive member (symlink): "
                        f"{info.filename!r}")
            z.extractall(dest)
    elif tarfile.is_tarfile(archive):
        with tarfile.open(archive) as t:
            members = t.getmembers()
            if len(members) > MAX_FILES:
                raise ValueError("archive exceeds the file-count cap")
            for m in members:
                total += max(m.size, 0)
                _check_member(m.name, m.size, total)
                if m.issym() or m.islnk():
                    raise ValueError(
                        f"unsafe archive member (link): {m.name!r}")
            t.extractall(dest, filter="data")
    else:
        raise ValueError(f"not a zip or tar archive: {archive}")
    return dest


# ------------------------------------------------------------------
# event log

class EventLog:
    """The v1.0 chained form (frozen): each event carries seq, ts,
    prev_hash and event_hash = sha256(prev_hash || canonical(body)),
    genesis prev "0"*64. The runner is the log's only writer."""

    def __init__(self, path):
        self.path = Path(path)
        self.seq = 0
        self.prev = "0" * 64
        if self.path.is_file():
            for ln in self.path.read_text().splitlines():
                if ln.strip():
                    self.seq += 1
                    try:
                        self.prev = json.loads(ln)["event_hash"]
                    except Exception:
                        pass

    def add(self, **event):
        from aavep_lib import now_iso
        event = {"seq": self.seq, "ts": now_iso(), **event,
                 "prev_hash": self.prev}
        event["event_hash"] = sha256_bytes(
            self.prev.encode() + canonical(
                {k: v for k, v in event.items()
                 if k != "event_hash"}))
        self.prev = event["event_hash"]
        self.seq += 1
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
        return event

    def events(self):
        if not self.path.is_file():
            return []
        return [json.loads(ln) for ln in
                self.path.read_text().splitlines() if ln.strip()]


# ------------------------------------------------------------------
# process census / survivor sweep (B-31)

def _census():
    out = {}
    proc = Path("/proc")
    if not proc.exists():
        return out
    for d in proc.iterdir():
        if not d.name.isdigit():
            continue
        pid = int(d.name)
        try:
            stat = (d / "stat").read_text().split()
            ppid = int(stat[3])
            start = int(stat[21])
            cwd = os.readlink(d / "cwd")
        except Exception:
            continue
        out[pid] = {"ppid": ppid, "start": start, "cwd": cwd}
    return out


def _descendants(census, roots):
    kids = {}
    for pid, info in census.items():
        kids.setdefault(info["ppid"], []).append(pid)
    seen, stack = set(), list(roots)
    while stack:
        cur = stack.pop()
        for k in kids.get(cur, []):
            if k not in seen:
                seen.add(k)
                stack.append(k)
    return seen


class Confinement:
    """Attempt-and-print (ruling 5): probe the OS facilities, wrap
    with what exists, and print the achieved level in every record."""

    def __init__(self):
        self.net_ns = self._probe(["unshare", "-n", "true"])
        self.user_ns = self._probe(["unshare", "-rm", "true"])
        if self.net_ns:
            self.level = "os-sandbox: network-namespace"
            self.wrap = ["unshare", "-n"]
        else:
            self.level = "portable"
            self.wrap = []
        self.detail = (f"network namespace probe: "
                       f"{'ok' if self.net_ns else 'unavailable'}; "
                       f"user+mount namespace probe: "
                       f"{'ok' if self.user_ns else 'unavailable'}; "
                       f"process groups + census sweep: active")

    @staticmethod
    def _probe(argv):
        try:
            return subprocess.run(argv, capture_output=True,
                                  timeout=10).returncode == 0
        except Exception:
            return False


# ------------------------------------------------------------------
# kit manifest verification (§7.3)

def verify_kit_manifest():
    """Returns (ok, detail). Cache entries in the kit manifest are
    an author defect (noted, and the entry is skipped); any other
    divergence refuses the run."""
    mf = KIT / "AAVEP_MANIFEST.sha256"
    if not mf.is_file():
        return False, "kit manifest absent (AAVEP_MANIFEST.sha256)"
    entries = parse_sha256_manifest(mf.read_text())
    problems, notes = [], []
    for rel, want in entries.items():
        if is_cache_path(rel):
            notes.append(f"manifested cache path (manifest defect): "
                         f"{rel}")
            continue
        p = KIT / rel
        if not p.is_file():
            problems.append(f"kit file missing: {rel}")
        elif sha256_file(p) != want:
            problems.append(f"kit file diverges: {rel}")
    if problems:
        return False, "; ".join(problems[:5])
    return True, ("ok" + (f"; notes: {notes}" if notes else ""))


def find_admin_tree(root: Path):
    """B-29 hard rule support: a CAL administrator tree (secret.json
    beside a CAL admin_record.json) anywhere under root."""
    for p in Path(root).rglob("admin_record.json"):
        try:
            doc = json.loads(p.read_text())
        except Exception:
            continue
        if doc.get("battery") == "AAVEP-CAL" and \
                (p.parent / "secret.json").exists():
            return p.parent
    return None


# ------------------------------------------------------------------
# Gate 0 (v1.1 custody)

def check_gate0(receipts, sessions, admin_dirs, keys_files,
                subject_dirs, opening_record_obj, ledger_path):
    """Returns (ok, lines). v2 receipts are graded by
    aavep_cal.verify_receipt with whatever custody material is
    presented (administrator tree + subject responses, or published
    keys + public fixtures + responses, or an independent opening
    record); v1 transcripts are re-scored under the v1 rules and
    labelled LEGACY-CUSTODY."""
    lines = []
    ok = True
    genesis_receipts = []
    if ledger_path and Path(ledger_path).exists():
        import aavep_ledger
        entries = aavep_ledger.load(ledger_path)
        if entries:
            genesis_receipts = entries[0].get("payload", {}).get(
                "calibration_receipts", []) or []
    admin_by_session, keys_by_session, subj_by_session = {}, {}, {}
    for d in admin_dirs:
        rec_f = Path(d) / "admin_record.json"
        if rec_f.exists():
            admin_by_session[json.loads(rec_f.read_text())
                             ["session_id"]] = Path(d)
    for kf in keys_files:
        doc = json.loads(Path(kf).read_text())
        keys_by_session[doc["session_id"]] = Path(kf)
    for d in subject_dirs:
        open_f = Path(d) / "subject_open.json"
        if open_f.exists():
            subj_by_session[json.loads(open_f.read_text())
                            ["session_id"]] = Path(d)
    for rp in receipts:
        receipt = json.loads(Path(rp).read_text())
        sid = receipt.get("session_id")
        subj = subj_by_session.get(sid)
        resp = (subj / "responses.json") if subj else None
        res = aavep_cal.verify_receipt(
            receipt,
            admin_dir=admin_by_session.get(sid),
            subject_dir=subj,
            responses_path=resp if resp and resp.exists() else None,
            keys_path=keys_by_session.get(sid),
            fixtures_dir=subj,
            opening_record_obj=opening_record_obj)
        grade = receipt.get("administration_grade", "?")
        if genesis_receipts and sid:
            bound = any(gr.get("session_commitment")
                        == receipt.get("session_commitment")
                        for gr in genesis_receipts
                        if isinstance(gr, dict))
            if not bound:
                ok = False
                lines.append(
                    f"{receipt.get('operator_id')}: UNVERIFIED for "
                    f"this run — the session commitment is absent "
                    f"from the presenting run's genesis (B-22)")
                continue
        lines.append(
            f"{receipt.get('operator_id')}: {res['outcome']} "
            f"(grade {grade}; {res['reason']})")
        if res["outcome"] == "UNVERIFIED" or \
                receipt.get("tier") != "PASS":
            ok = False
    for sp in sessions:  # v1 legacy transcripts
        sp = Path(sp)
        meta = json.loads((sp / "session.json").read_text())
        resp_f = sp / "responses.json"
        if not resp_f.exists():
            ok = False
            lines.append(f"{meta['operator']}: LEGACY-CUSTODY — no "
                         f"responses file to re-score")
            continue
        rescored = aavep_cal.score_session(
            sp, json.loads(resp_f.read_text()))
        lines.append(
            f"{meta['operator']}: LEGACY-CUSTODY re-score "
            f"{rescored['tier']} ({rescored['correct']}/6) under "
            f"v1 rules; v1 custody weaknesses apply (§13)")
        if rescored["tier"] != "PASS":
            ok = False
    return ok, lines


# ------------------------------------------------------------------
# snapshots / write-sets

def tree_snapshot(root: Path):
    snap = {}
    for p in sorted(Path(root).rglob("*")):
        rel = str(p.relative_to(root))
        if p.is_symlink():
            snap[rel] = {"type": "link", "target": os.readlink(p)}
        elif p.is_file():
            snap[rel] = {"type": "file", "sha256": sha256_file(p)}
    return snap


def dir_size(root: Path):
    total = 0
    for p in Path(root).rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def diff_snapshots(before, after):
    changes = []
    for rel in sorted(set(before) | set(after)):
        b, a = before.get(rel), after.get(rel)
        if b == a:
            continue
        if b is None:
            changes.append({"path": rel, "change": "created",
                            "type": a["type"]})
        elif a is None:
            changes.append({"path": rel, "change": "deleted",
                            "type": b["type"]})
        else:
            changes.append({"path": rel, "change": "modified",
                            "type": a["type"]})
    return changes


# ------------------------------------------------------------------
# streamed process execution (§5.6, B-31)

class _Stream:
    def __init__(self, pipe, spill_path, ceiling):
        self.pipe = pipe
        self.spill = open(spill_path, "wb")
        self.ceiling = ceiling
        self.hasher = hashlib.sha256()
        self.total = 0
        self.written = 0
        self.thread = threading.Thread(target=self._pump, daemon=True)

    def _pump(self):
        while True:
            chunk = self.pipe.read(65536)
            if not chunk:
                break
            self.hasher.update(chunk)
            self.total += len(chunk)
            if self.written < self.ceiling:
                take = min(len(chunk), self.ceiling - self.written)
                self.spill.write(chunk[:take])
                self.written += take
        self.spill.close()

    def start(self):
        self.thread.start()

    def finish(self):
        self.thread.join(timeout=10)
        head = b""
        try:
            with open(self.spill.name, "rb") as f:
                head = f.read(1 << 20)
        except OSError:
            pass
        return {"sha256": self.hasher.hexdigest(),
                "bytes": self.total,
                "truncated": self.total > self.ceiling,
                "excerpt": head.decode("utf-8", "replace")}


def _rlimits(cpu_s, fsize):
    def apply():
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_s, cpu_s + 5))
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
    return apply


def run_process(argv, cwd, env, timeout, ceiling, spill_dir, stem,
                wrap, spawned_roots):
    spill_dir = Path(spill_dir)
    spill_dir.mkdir(parents=True, exist_ok=True)
    cmd = list(wrap) + list(argv)
    proc = subprocess.Popen(
        cmd, cwd=str(cwd), env=env, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, start_new_session=True,
        preexec_fn=_rlimits(int(timeout) + 30, 512 * 1024 * 1024))
    spawned_roots.add(proc.pid)
    out = _Stream(proc.stdout, spill_dir / f"{stem}.out", ceiling)
    err = _Stream(proc.stderr, spill_dir / f"{stem}.err", ceiling)
    out.start(); err.start()
    timed_out = False
    t0 = time.time()
    while proc.poll() is None:
        if time.time() - t0 > timeout:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            break
        time.sleep(0.1)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        pass
    return {"exit": None if timed_out else proc.returncode,
            "timed_out": timed_out,
            "stdout": out.finish(), "stderr": err.finish()}


# ------------------------------------------------------------------
# argv resolution + escape re-check (§5.1)

def _subst(tok, scratch_pkg, ws):
    return (tok.replace("{kit}", str(KIT))
               .replace("{scratch}", str(scratch_pkg))
               .replace("{ws}", str(ws))
               .replace("{store}", str(Path(ws) / "store")))


def resolve_argv(inst, scratch_pkg, ws):
    if inst.get("kind") == "suite_script":
        argv = [sys.executable, str(scratch_pkg / inst["path"])]
        argv += [_subst(str(a), scratch_pkg, ws)
                 for a in inst.get("args", [])]
        return argv
    return [_subst(str(tok), scratch_pkg, ws)
            for tok in inst.get("command", [])]


def argv_escape(argv, scratch_pkg, ws):
    """Re-resolve at execution (§5.1): any path-bearing token whose
    realpath leaves the allowed roots is an ESCAPE. Returns the
    offending token or None."""
    roots = [Path(scratch_pkg).resolve(), Path(ws).resolve(),
             KIT.resolve()]
    for tok in argv[1:]:
        cand = tok.split("=", 1)[-1] if "=" in tok else tok
        if "/" not in cand:
            continue
        p = Path(cand)
        if not p.is_absolute():
            p = Path(scratch_pkg) / cand
        try:
            rp = p.resolve()
        except OSError:
            continue
        if any(rp == r or r in rp.parents for r in roots):
            continue
        if str(rp).startswith(("/usr/", "/bin/", "/lib/", "/etc/")):
            continue
        return tok
    return None


def undeclared_imports(inst, scratch_pkg):
    """B-30 detectable channel: statically scan the instrument's
    source for imports of package-local modules that are neither
    the instrument itself nor declared in `modules`."""
    if inst.get("kind") != "suite_script":
        return []
    src = Path(scratch_pkg) / inst["path"]
    try:
        tree = ast.parse(src.read_text(encoding="utf-8",
                                       errors="replace"))
    except Exception:
        return []
    declared = {Path(m).stem for m in inst.get("modules", []) or []}
    declared.add(Path(inst["path"]).stem)
    pkg_files = {p.stem for p in Path(scratch_pkg).rglob("*.py")}
    stdlib = set(sys.stdlib_module_names)
    bad = set()
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Import):
            names = [a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names = [node.module.split(".")[0]]
        for n in names:
            if n in pkg_files and n not in declared \
                    and n not in stdlib:
                bad.add(n)
    return sorted(bad)


# ------------------------------------------------------------------

def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_run")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--package")
    ap.add_argument("--package-zip")
    ap.add_argument("--workspace", required=True)
    ap.add_argument("--house-root", default=str(Path.home()))
    ap.add_argument("--receipt", action="append", default=[],
                    help="CAL v2 published receipt (Gate 0)")
    ap.add_argument("--session", action="append", default=[],
                    help="CAL v1 session dir (Gate 0, legacy)")
    ap.add_argument("--cal-admin-dir", action="append", default=[])
    ap.add_argument("--cal-keys", action="append", default=[])
    ap.add_argument("--cal-subject-dir", action="append", default=[])
    ap.add_argument("--opening-record")
    ap.add_argument("--ledger",
                    help="the run's adjudication ledger; at close "
                         "the event-log head is recorded in it "
                         "(B-26)")
    ap.add_argument("--only")
    ap.add_argument("--sample", action="store_true",
                    help="re-run a >=20% sample of PASSED "
                         "instruments (A-21)")
    ap.add_argument("--behaviours", action="store_true")
    args = ap.parse_args(argv)
    if args.behaviours:
        from aavep_lib import behaviours_for
        print(json.dumps(behaviours_for("aavep_run"), indent=1))
        return 0
    print(DISC)
    man = json.loads(Path(args.manifest).read_text())
    # Resolve the workspace (and the package root below) to absolute
    # paths at entry: instrument argv are built from the scratch
    # path and executed with the scratch tree as cwd, so a relative
    # workspace double-resolves against the child's cwd and every
    # instrument fails to find its own bytes. (v1.0 carried this
    # repair; the v1.1 rewrite dropped it — restored after the
    # v1.1 demonstration's first synthetic run failed all three
    # instruments on exactly this.)
    ws = Path(args.workspace).resolve()
    ws.mkdir(parents=True, exist_ok=True)

    # ---- preconditions (§7.3, B-29)
    kit_ok, kit_detail = verify_kit_manifest()
    print("kit manifest:", kit_detail)
    if not kit_ok:
        print("RUN REFUSED: the kit manifest does not verify (§7.3)")
        return 2
    opening_record_obj = None
    if args.opening_record:
        opening_record_obj = json.loads(
            Path(args.opening_record).read_text())
    gate_ok, gate_lines = check_gate0(
        args.receipt, args.session, args.cal_admin_dir, args.cal_keys,
        args.cal_subject_dir, opening_record_obj, args.ledger)
    for ln in gate_lines:
        print("Gate 0:", ln)
    if not gate_ok:
        print("RUN REFUSED at Gate 0: the gate binds everybody "
              "(governance ruling 5)")
        return 2

    # ---- lock table recompute + compare
    pkg_root = Path(args.package).resolve() if args.package \
        else ws / "package"
    if args.package_zip:
        if not pkg_root.exists():
            safe_extract(args.package_zip, pkg_root)
    table, _ = aavep_preflight.compute_lock_table(
        args.manifest, pkg_root, ws, args.house_root, False,
        package_zip=args.package_zip)
    existing = ws / "locktable.json"
    if existing.exists():
        recorded = json.loads(existing.read_text())
        if recorded != table:
            print("RUN REFUSED: LOCK TABLE DIVERGES from preflight "
                  "(aavep_preflight must be re-run, or the package "
                  "changed)")
            return 2
    else:
        existing.write_text(json.dumps(table, indent=1))
    if table.get("target", {}).get("state") == "TARGET_MISMATCH":
        print("TARGET MISMATCH — the run does not open")
        return 3
    if not table["valid"]:
        for p in table["problems"]:
            print("  PROBLEM:", p)
        print("RUN REFUSED: lock table invalid")
        return 2
    for d in table.get("manifest_defects", []):
        print("  MANIFEST DEFECT (author's, not the target's):", d)
    pkg = pkg_root / man["target"].get("package_subdir", "")
    scratch = ws / "scratch"
    if not scratch.exists():
        shutil.copytree(pkg, scratch, symlinks=True)
    adm = find_admin_tree(ws)
    if adm is not None:
        print(f"RUN REFUSED: a CAL administrator tree sits inside "
              f"the run workspace at {adm} (B-29 hard rule)")
        return 2
    runhome = ws / "runhome"; runhome.mkdir(exist_ok=True)
    runtmp = ws / "runtmp"; runtmp.mkdir(exist_ok=True)
    store = ws / "store"

    conf = Confinement()
    quota = (man["target"].get("workspace_quota_bytes")
             or min(MAX_TOTAL,
                    shutil.disk_usage(ws).free // 2))
    elog = EventLog(ws / "event_log.jsonl")
    baseline = _census()
    spawned = set()
    own_chain = {os.getpid()}
    elog.add(phase="run_open", confinement=conf.level,
                confinement_detail=conf.detail,
                kit_manifest_sha256=sha256_file(
                    KIT / "AAVEP_MANIFEST.sha256"),
                workspace_quota_bytes=quota,
                env_passthrough=man.get("env_passthrough", []),
                env_declarations={
                    i["id"]: i.get("env")
                    for i in man.get("instruments", [])
                    if i.get("env")})
    print(f"confinement: {conf.level}")

    def sweep(context):
        now = _census()
        desc = _descendants(now, spawned)
        killed = []
        for pid, info in now.items():
            if pid in baseline or pid in own_chain:
                continue
            cwd = info.get("cwd") or ""
            if pid in desc or cwd.startswith(str(ws.resolve())):
                try:
                    os.kill(pid, signal.SIGKILL)
                    killed.append(pid)
                except (ProcessLookupError, PermissionError):
                    pass
        if killed:
            elog.add(phase="survivor", context=context, killed=killed)
        return killed

    instruments = man["instruments"]
    if args.only:
        instruments = [i for i in instruments
                       if i["id"] == args.only]
        if not instruments:
            print(f"no instrument {args.only}")
            return 2
    write_sets = {}
    statuses = {}

    def snapshot_status(iid):
        st, probs = derive_statuses(elog.events(), man["instruments"])
        return st, probs

    for inst in instruments:
        iid = inst["id"]
        entry = table["instruments"][iid]
        if entry["lock_state"] == "NOT_APPLICABLE":
            elog.add(phase="status", instrument=iid,
                        status="NOT_APPLICABLE",
                        reason=entry.get("reason"))
            continue
        if entry["lock_state"] == "BLOCKED":
            elog.add(phase="status", instrument=iid, status="BLOCKED",
                        reason=entry.get("reason", "lock BLOCKED"))
            continue
        if dir_size(ws) > quota:
            elog.add(phase="quota", instrument=iid,
                        usage_bytes=dir_size(ws), quota_bytes=quota)
            elog.add(phase="status", instrument=iid, status="BLOCKED",
                        reason="QUOTA-EXCEEDED")
            continue
        # placement from the store (§5.2)
        if inst.get("kind") == "suite_script" and \
                entry.get("store_path"):
            dst = scratch / inst["path"]
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(store / entry["instrument_sha256"], dst)
            placement_bad = \
                sha256_file(dst) != entry["instrument_sha256"]
            for m in entry.get("modules", []):
                if m.get("state") == "LOCKED":
                    mdst = scratch / m["path"]
                    mdst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(store / m["sha256"], mdst)
                    if sha256_file(mdst) != m["sha256"]:
                        placement_bad = True
            if placement_bad:
                elog.add(phase="status", instrument=iid,
                            status="FAILED",
                            reason="store placement hash mismatch")
                continue
        argv = resolve_argv(inst, scratch, ws)
        esc = argv_escape(argv, scratch, ws)
        if esc is not None:
            elog.add(phase="escape_refused", instrument=iid, token=esc)
            elog.add(phase="status", instrument=iid, status="FAILED",
                        degradations=[],
                        reason=f"ESCAPE-REFUSED: {esc}",
                        confinement=conf.level)
            continue
        env = {k: os.environ[k] for k in ENV_ALLOWLIST if k
               in os.environ}
        env["HOME"] = str(runhome)
        env["TMPDIR"] = str(runtmp)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONNOUSERSITE"] = "1"
        for pv in man.get("env_passthrough", []):
            if pv["name"] in os.environ:
                env[pv["name"]] = os.environ[pv["name"]]
        # manifest-declared per-instrument environment (v1.0
        # instance field): values are substituted and applied as
        # declared — they print in RUN_OPEN's env declarations.
        for k, v in (inst.get("env") or {}).items():
            env[k] = _subst(str(v), scratch, ws)
        ceiling = inst.get("output_ceiling_bytes",
                           man.get("output_ceiling_bytes",
                                   DEFAULT_OUTPUT_CEILING))
        timeout = inst.get("timeout_s", 600)
        # Pre-execution re-verification (loop pass, DA-4): the
        # placed entry and module bytes are re-hashed immediately
        # before the first spawn, so a write that landed after
        # placement (e.g. a surviving process from an earlier
        # instrument) refuses the execution instead of running
        # substituted bytes. Files an instrument merely reads
        # from scratch remain write-set-recorded, not hash-gated
        # (section 5.2's declared limit).
        if inst.get("kind") == "suite_script" and \
                entry.get("store_path"):
            diverged = sha256_file(scratch / inst["path"]) != \
                entry["instrument_sha256"] or any(
                    m.get("state") == "LOCKED" and
                    sha256_file(scratch / m["path"]) != m["sha256"]
                    for m in entry.get("modules", []))
            if diverged:
                elog.add(phase="status", instrument=iid,
                            status="FAILED",
                            reason="execution bytes diverged "
                                   "after placement")
                continue
        before = tree_snapshot(scratch)
        # A-27: a timeout is retried once at 2x; TIMEOUT is the
        # status only when both attempts time out.
        attempts = 0
        attempt_timeouts = []
        while True:
            attempts += 1
            tmo = timeout if attempts == 1 else timeout * 2
            attempt_timeouts.append(tmo)
            res = run_process(
                argv, scratch, env, tmo, ceiling,
                ws / "spill", f"{iid}-{attempts}", conf.wrap, spawned)
            sweep(f"after {iid} attempt {attempts}")
            elog.add(
                phase="execute", instrument=iid, argv=argv,
                exit=res["exit"], timed_out=res["timed_out"],
                timeout_s=tmo, attempt=attempts,
                stdout_sha256=res["stdout"]["sha256"],
                stdout_bytes=res["stdout"]["bytes"],
                stdout_truncated=res["stdout"]["truncated"]
                or res["stderr"]["truncated"],
                stderr_sha256=res["stderr"]["sha256"],
                confinement=conf.level)
            if not res["timed_out"] or attempts == 2:
                break
        after = tree_snapshot(scratch)
        changes = diff_snapshots(before, after)
        for ch in changes:
            if ch["type"] == "link":
                tgt = after[ch["path"]]["target"]
                rp = (scratch / ch["path"]).resolve()
                elog.add(phase="link_write", instrument=iid,
                            path=ch["path"], target=tgt,
                            realpath=str(rp))
                if not str(rp).startswith(str(scratch.resolve())):
                    (scratch / ch["path"]).unlink(missing_ok=True)
                    ch["removed"] = "out-of-reach link removed"
        write_sets[iid] = {c["path"] for c in changes
                           if c["change"] in ("created", "modified")}
        if changes:
            elog.add(phase="writeset", instrument=iid, changes=changes)
        combined = (res["stdout"]["excerpt"] + "\n"
                    + res["stderr"]["excerpt"])
        obs = []
        for e in expectations_of(inst):
            obs.append({"needle": e["needle"],
                        "observed": e["needle"] in combined})
        from aavep_lib import PROTOCOL_DEFAULT_MARKERS
        for m in set(PROTOCOL_DEFAULT_MARKERS) | set(
                inst.get("partial_markers", []) or []):
            obs.append({"needle": m, "observed": m in combined})
        truncated = res["stdout"]["truncated"] or \
            res["stderr"]["truncated"]
        degradations = []
        if undeclared_imports(inst, scratch):
            degradations.append("IMPORTS-UNDECLARED")
        declared_consumes = set(inst.get("consumes", []) or [])
        consumed = set()
        for tok in argv[1:]:
            cand = tok.split("=", 1)[-1]
            p = Path(cand)
            if not p.is_absolute():
                p = scratch / cand
            try:
                rel = str(p.resolve().relative_to(scratch.resolve()))
            except ValueError:
                continue
            consumed.add(rel)
        for rel in inst.get("inputs", []) or []:
            consumed.add(rel)
        for other, paths in write_sets.items():
            if other == iid:
                continue
            if (consumed & paths) and other not in declared_consumes:
                degradations.append("DEPENDENCY-UNDECLARED")
                break
        status, gate_deg = gate_status(res["exit"], inst, obs,
                                       truncated=truncated)
        degradations = sorted(set(degradations) | set(gate_deg))
        if status == "PASSED" and degradations:
            status = "PASSED-DEGRADED"
        elog.add(phase="status", instrument=iid, status=status,
                 exit=res["exit"], stdout_observations=obs,
                 degradations=degradations,
                 confinement=conf.level)
        print(f"{iid}: {status}"
              + (f" ({', '.join(degradations)})" if degradations
                 else ""))

    sweep("run close")
    censor = _census()
    residual = [pid for pid, info in censor.items()
                if pid not in baseline and pid not in own_chain
                and (info.get("cwd") or "").startswith(
                    str(ws.resolve()))]
    elog.add(phase="run_close", residual_processes=residual)
    derived, problems = derive_statuses(elog.events(),
                                        man["instruments"])
    for p in problems:
        print("  DERIVATION PROBLEM:", p)
    final = {iid: {"status": derived[iid]["status"],
                   "degradations": derived[iid]["degradations"]}
             for iid in derived}
    overall = overall_status(man["instruments"],
                             {k: v["status"] for k, v in final.items()})
    out = {"overall": overall, "statuses": final,
           "event_log_head": elog.prev, "confinement": conf.level,
           "kit_manifest_sha256": sha256_file(
               KIT / "AAVEP_MANIFEST.sha256")}
    # A-21 sample re-run
    if args.sample:
        import random as _random
        passed = [i["id"] for i in man["instruments"]
                  if final.get(i["id"], {}).get("status")
                  in ("PASSED", "PASSED-DEGRADED")
                  and i.get("kind")]
        k = max(1, -(-len(passed) // 5))
        seed = int(elog.prev[:8], 16)
        sample = _random.Random(seed).sample(
            passed, min(k, len(passed)))
        agree = {}
        for iid in sample:
            inst = next(i for i in man["instruments"]
                        if i["id"] == iid)
            argv = resolve_argv(inst, scratch, ws)
            env = {kk: os.environ[kk] for kk in ENV_ALLOWLIST
                   if kk in os.environ}
            env.update({"HOME": str(runhome), "TMPDIR": str(runtmp),
                        "PYTHONDONTWRITEBYTECODE": "1",
                        "PYTHONNOUSERSITE": "1"})
            res = run_process(
                argv, scratch, env, inst.get("timeout_s", 600),
                DEFAULT_OUTPUT_CEILING, ws / "spill",
                f"sample-{iid}", conf.wrap, spawned)
            comb = res["stdout"]["excerpt"]
            obs = [{"needle": e["needle"],
                    "observed": e["needle"] in comb}
                   for e in expectations_of(inst)]
            st2, _ = gate_status(res["exit"], inst, obs)
            agree[iid] = (st2 == final[iid]["status"])
            elog.add(phase="sample", instrument=iid, status=st2,
                        agrees=agree[iid], sample_of=elog.prev)
        out["sample"] = {"instruments": sample, "agreement": agree}
        out["event_log_head"] = elog.prev
        print(f"sample re-run: {sum(agree.values())}/{len(agree)} "
              f"agree")
    (ws / "statuses.json").write_text(json.dumps(out, indent=1))
    if args.ledger and Path(args.ledger).exists():
        import aavep_ledger
        aavep_ledger.append(Path(args.ledger), "NOTE", "aavep_run",
                            {"event": "EVENT_LOG_HEAD",
                             "event_log_head": elog.prev,
                             "workspace": str(ws)})
        out["ledger_event_log_head_recorded"] = True
        (ws / "statuses.json").write_text(json.dumps(out, indent=1))
    print(f"overall: {overall} · "
          f"{sum(1 for v in out['statuses'].values() if v['status'] == 'FAILED')} "
          f"FAILED — confinement {conf.level} — "
          f"event log head {elog.prev}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
