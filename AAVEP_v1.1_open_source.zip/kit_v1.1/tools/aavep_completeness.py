#!/usr/bin/env python3
"""aavep_completeness — the §4.11 completeness gate + §4.9 NO-FINDING entries.

INPUT_PROVENANCE:
  paper-defined:       the target package's own claim index, as carried
                       in the manifest's claims list — the surface the
                       gate checks coverage against.
  cited-paper:         NONE.
  control:             the gate rules of the design §4.9/§4.11 as amended
                       (A-21: every indexed claim maps to at least one
                       executed check or carries an explicit UNRESOLVED
                       entry; per-claim-section NO-FINDING entries carry
                       the filer's self-disconfirmation note).
  declared-assumption: the claim->instrument coverage map in the manifest
                       is the audit author's declaration; the gate checks
                       that coverage *happened*, not that the map is the
                       right map. Coverage typed "correspondence" (an
                       instrument that enumerates the claim) is reported
                       separately from "substantive" coverage and never
                       silently upgraded.
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: the indexed claim surface of one target.
  (2) Verified domain: for each claim, whether a covering instrument
      executed, or an UNRESOLVED entry with a reason stands in the
      ledger; and whether every claim section carries a NO-FINDING
      entry or a filed finding.
  (3) Map: manifest coverage declarations x run statuses x ledger.
  (4) What the map preserves: the difference between "checked and
      clean", "checked and found", and "not checkable here, on the
      record" — the three states a silent gap would collapse.
  (5) What stays outside the machine check: whether the coverage map is
      complete in substance. An index that omits a claim omits it from
      this gate too; the index's own integrity is the target's
      instrument problem (e.g. an index validator), not this gate's.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import disclosure  # noqa: E402
import aavep_ledger  # noqa: E402

DISC = disclosure(
    "the indexed claim surface of one target",
    "per-claim executed coverage or an on-record UNRESOLVED; per-section "
    "NO-FINDING presence",
    "manifest coverage x run statuses x ledger entries",
    "the checked-clean / checked-found / not-checkable distinction",
    "the substantive completeness of the coverage map itself")

EXECUTED = ("PASSED", "PASSED-DEGRADED", "FAILED")


def cmd_gate(a):
    print(DISC)
    man = json.loads(Path(a.manifest).read_text(encoding="utf-8"))
    raw = json.loads(Path(a.statuses).read_text())["statuses"]
    # v1.1 statuses nest per-instrument objects ({"status": …,
    # "degradations": […]}); v1.0 wrote bare strings. Accept both —
    # the gate's question is which instruments EXECUTED, and a
    # PASSED-DEGRADED instrument executed (its degradation is a
    # status, printed in the run record, not a non-execution).
    # (v1.1 demonstration repair: the gate read the v1.0 shape and
    # reported every claim uncovered on a healthy v1.1 run.)
    statuses = {k: (v.get("status") if isinstance(v, dict) else v)
                for k, v in raw.items()}
    entries = aavep_ledger.load(a.ledger)
    recorded_unresolved = {e["payload"].get("claim_id") for e in entries
                           if e["type"] == "COMPLETENESS"
                           and e["payload"].get("coverage") == "UNRESOLVED"}
    rows, gaps = [], []
    for claim in man.get("claims", []):
        cid = claim["claim_id"]
        cov = claim.get("coverage", [])
        sub = [c for c in cov if c.get("type") == "substantive"
               and statuses.get(c["instrument"]) in EXECUTED]
        cor = [c for c in cov if c.get("type") == "correspondence"
               and statuses.get(c["instrument"]) in EXECUTED]
        if sub:
            rows.append((cid, "COVERED-SUBSTANTIVE",
                         [c["instrument"] for c in sub]))
        elif claim.get("unresolved_reason"):
            # An explicit UNRESOLVED disposition stands on its own
            # (loop repair: it never required a correspondence execution
            # to be honest — §4.8 names it as a standalone alternative).
            if cid not in recorded_unresolved:
                aavep_ledger.append(
                    a.ledger, "COMPLETENESS", a.operator,
                    {"claim_id": cid, "coverage": "UNRESOLVED",
                     "reason": claim["unresolved_reason"],
                     "correspondence_only": [c["instrument"] for c in cor]})
                recorded_unresolved.add(cid)
            rows.append((cid, "UNRESOLVED-ON-RECORD",
                         claim["unresolved_reason"]))
        elif cor:
            rows.append((cid, "COVERED-CORRESPONDENCE-ONLY",
                         [c["instrument"] for c in cor]))
        else:
            gaps.append((cid, "no covering instrument executed and no "
                              "UNRESOLVED entry"))
    # per-section NO-FINDING presence
    sections = {}
    for claim in man.get("claims", []):
        sections.setdefault(claim["section"], []).append(claim["claim_id"])
    filed = {e["payload"].get("packet", {}).get("claim_id")
             for e in entries if e["type"] == "FINDING_FILED"}
    nofinding = {e["payload"].get("section") for e in entries
                 if e["type"] == "NO_FINDING"}
    section_rows = []
    for sec, cids in sorted(sections.items()):
        if any(c in filed for c in cids):
            section_rows.append((sec, "has filed finding(s)"))
        elif sec in nofinding:
            section_rows.append((sec, "NO-FINDING on record"))
        else:
            section_rows.append((sec, "SILENT — no finding, no NO-FINDING"))
            gaps.append((sec, "claim section silent (§4.9/§4.11)"))
    for r in rows:
        print(" ", r)
    for r in section_rows:
        print("  section", r)
    if gaps:
        print("COMPLETENESS GATE: FAIL")
        for g in gaps:
            print("  GAP:", g)
        return 1
    print("COMPLETENESS GATE: PASS (every indexed claim executed-covered "
          "or UNRESOLVED on record; every section speaks)")
    return 0


def cmd_no_finding(a):
    print(DISC)
    e = aavep_ledger.append(a.ledger, "NO_FINDING", a.operator,
                            {"section": a.section,
                             "self_disconfirmation": a.note})
    print(f"NO-FINDING recorded for section {a.section} at seq {e['seq']}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_completeness")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("gate"); p.add_argument("--manifest", required=True)
    p.add_argument("--statuses", required=True)
    p.add_argument("--ledger", required=True)
    p.add_argument("--operator", required=True)
    p = sub.add_parser("no-finding"); p.add_argument("--ledger", required=True)
    p.add_argument("--section", required=True)
    p.add_argument("--operator", required=True)
    p.add_argument("--note", required=True,
                   help="the filer's self-disconfirmation sentence (§4.9)")
    a = ap.parse_args(argv)
    return cmd_gate(a) if a.cmd == "gate" else cmd_no_finding(a)


if __name__ == "__main__":
    raise SystemExit(main())
