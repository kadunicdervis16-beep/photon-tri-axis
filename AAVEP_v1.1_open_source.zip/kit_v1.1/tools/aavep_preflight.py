#!/usr/bin/env python3
"""aavep_preflight — manifest resolution and SOURCE-LOCK (AAVEP Stage A/B).

INPUT_PROVENANCE:
  paper-defined:       the AAVEP manifest instance under resolution — its
                       target hash, instrument list, source declarations,
                       site pins, and authority transcription are the
                       claims under test, never a source of truth for
                       themselves.
  cited-paper:         NONE. Source papers enter only as hash-pinned bytes
                       named by the manifest; this tool judges identity,
                       never content.
  control:             the lock rules of the AAVEP design §4.2 as amended
                       (SL-1..SL-3, A-2 site binding + authority
                       transcription, A-6 version-specific locators, A-7
                       derivation sources, A-23 index reconciliation and
                       timeout bounds, A-26 content-addressed store).
  declared-assumption: a locator of kind "doi" is fetched only under
                       --fetch; offline, an unfetched DOI source is absent
                       (design K-2: network is an accelerator for LOCKED,
                       never a source of new evidence).
  arbitrary-representative: NONE.

FIVE-PART DISCLOSURE:
  (1) Native domain: (manifest, filesystem) pairs of one audit run.
  (2) Verified domain: hash equality of every declared file; presence or
      absence of every declared source; site pins (verbatim quote at the
      declared line range under the declared heading); the authority
      transcription quote against the target's bytes; derivation pins
      (re-derived text, quote + heading co-occurrence, extracted-text
      hash); target-hash match (M-4); manifest-vs-runner reconciliation.
  (3) Map: sha256 over raw bytes; pdftotext -layout as the one declared
      derivation rule; line-addressed quote search in text sources.
  (4) What the map preserves: byte identity — the property every
      downstream claim depends on — and governing-site identity.
  (5) What stays outside the machine check: whether a locked source is
      the *right* source. That is the manifest author's declaration,
      transcribed from the target paper's own governing rule where one
      exists (A-2) and shipped in the lock table for anyone to challenge;
      it is not preflight's to judge (design FM-2 residual, printed).
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aavep_lib import (disclosure, lint_manifest_entries,  # noqa: E402
                       parse_sha256_manifest, sha256_bytes,
                       sha256_file)

DISC = disclosure(
    "(manifest, filesystem) pairs of one audit run",
    "hash equality of declared files; site pins at declared line ranges; "
    "authority transcription against the target's bytes; derivation pins "
    "over re-derived text; target-hash match; runner reconciliation",
    "sha256 over raw bytes; pdftotext -layout as the declared derivation",
    "byte identity and governing-site identity",
    "whether a locked source is the right source (the manifest author's "
    "declaration, shipped in the lock table for challenge)")

TIMEOUT_MIN, TIMEOUT_MAX = 10, 86400


KIT_ROOT = Path(__file__).resolve().parent.parent


def resolve_locator(loc, workspace: Path, house_root: Path):
    """Return a Path (possibly nonexistent) for a locator, or None."""
    kind, value = loc.get("kind"), loc.get("value", "")
    if kind == "path":
        # {kit} joins {house}/{workspace} here (loop pass: the
        # placeholder was validated and argv-substituted but
        # never resolved in locators, so a {kit}-relative source
        # locked ABSENT — found by the v1.1 demonstration re-run).
        v = value.replace("{house}", str(house_root)).replace(
            "{workspace}", str(workspace)).replace(
            "{kit}", str(KIT_ROOT))
        return Path(v)
    if kind == "workspace_file":
        return workspace / value
    if kind == "doi":
        return None  # handled by fetch step
    return None


def fetch_doi(loc, dest_dir: Path):
    """Best-effort fetch of a version-DOI file. Returns Path or None.
    Fetched bytes are eligible only on hash equality (SL-1); this function
    judges nothing."""
    doi = loc.get("value", "")
    fname = loc.get("file") or "fetched.bin"
    url = f"https://zenodo.org/api/records/{doi.split('/')[-1]}"
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            rec = json.loads(r.read().decode("utf-8"))
        for f in rec.get("files", []):
            if f.get("key") == fname:
                out = dest_dir / fname
                with urllib.request.urlopen(f["links"]["self"],
                                            timeout=120) as r, \
                        open(out, "wb") as w:
                    shutil.copyfileobj(r, w)
                return out
    except Exception:
        return None
    return None


def text_lines(path: Path):
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def check_site(path: Path, site):
    """Verify a site pin: pinned quote verbatim within the declared line
    range (1-based, inclusive) of a text source, and the declared
    enclosing heading as the nearest heading above the range."""
    if site is None:
        return {"site": None, "verified": None,
                "note": "no site pin declared"}
    lines = text_lines(path)
    lo, hi = site["line_range"]
    quote = site["quote"]
    found = None
    for i in range(max(0, lo - 1), min(len(lines), hi)):
        if quote in lines[i]:
            found = i + 1
            break
    heading_ok = None
    if site.get("enclosing_heading"):
        heading_ok = False
        for i in range(min(found or lo, len(lines)) - 1, -1, -1):
            if lines[i].lstrip().startswith("#"):
                heading_ok = (lines[i].strip() == site["enclosing_heading"])
                break
    return {"site": site, "verified": found is not None and heading_ok is not False,
            "quote_found_at_line": found, "heading_ok": heading_ok}


def check_derivation(path: Path, derivation, work_dir: Path, tag: str):
    """A-7: re-derive the consumed text by the declared rule and verify
    the pins (verbatim quotes under headings + extracted-text hash)."""
    rule = derivation.get("rule")
    if rule != "pdftotext-layout":
        return {"state": "BLOCKED",
                "reason": f"unsupported derivation rule: {rule}"}
    out_txt = work_dir / f"derived_{tag}.txt"
    work_dir.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(["pdftotext", "-layout", str(path), str(out_txt)],
                       capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        return {"state": "BLOCKED",
                "reason": f"derivation failed: {r.stderr[:200]}"}
    text = out_txt.read_text(encoding="utf-8", errors="replace")
    norm = "\n".join(ln.rstrip() for ln in text.splitlines())
    got = sha256_bytes(norm.encode("utf-8"))
    if derivation.get("extracted_sha256") and got != derivation["extracted_sha256"]:
        return {"state": "BLOCKED",
                "reason": "extracted-text hash mismatch after re-derivation",
                "extracted_sha256": got}
    dlines = text.splitlines()
    for pin in derivation.get("pins", []):
        q, h = pin["quote"], pin.get("enclosing_heading")
        qline = next((i for i, ln in enumerate(dlines) if q in ln), None)
        if qline is None:
            return {"state": "BLOCKED",
                    "reason": f"derivation pin quote not found: {q[:60]}…"}
        if h:
            # The declared heading must be the nearest occurrence above
            # the quote, within the pin's window (loop repair: an
            # anywhere-earlier heading does not govern the quote).
            window = pin.get("within_lines", 200)
            hline = next((i for i in range(qline - 1, -1, -1)
                          if h in dlines[i]), None)
            if hline is None or qline - hline > window:
                return {"state": "BLOCKED",
                        "reason": f"derivation pin heading not the "
                                  f"nearest above the quote within "
                                  f"{window} lines: {h[:60]}"}
    return {"state": "LOCKED-BY-PIN", "extracted_sha256": got,
            "derived_text": str(out_txt)}


def _ws_rel(path, workspace):
    """Record workspace artifacts relative to the workspace, so a lock
    table is identical however the workspace path was spelled
    (demonstration repair: a relative --workspace made preflight's
    table diverge from the runner's absolute-path recomputation)."""
    try:
        return str(Path(path).relative_to(Path(workspace)))
    except ValueError:
        return str(path)


def _record_path(path, workspace, pkg=None):
    """The recorded form of a locked file's location, chosen so a
    lock table recomputes identically wherever the bundle is
    presented: workspace-relative inside the workspace,
    'package/<rel>' inside the target package, absolute (resolved)
    only for genuinely external files, whose locks are house-bound
    by nature. (v1.1 demonstration repair: absolute package-internal
    paths made the shipped bundle's lock table unreproducible from
    any other tree location.)"""
    p = Path(path).resolve()
    for base, prefix in ((Path(workspace).resolve(), ""),
                         (Path(pkg).resolve(), "package:")
                         if pkg is not None else (None, "")):
        if base is None:
            continue
        try:
            return prefix + str(p.relative_to(base))
        except ValueError:
            continue
    return str(p)


def lock_source(src, workspace, house_root, store: Path, fetch, fetch_dir,
                work_dir, pkg=None):
    sid = src["source_id"]
    rec = {"source_id": sid, "role": src.get("role"),
           "describes": src.get("describes")}
    path = resolve_locator(src["locator"], workspace, house_root)
    if path is None and src["locator"].get("kind") == "doi":
        # A copy fetched by an earlier preflight into this workspace is
        # reused (its hash still has to match) so that lock tables are
        # reproducible offline and the runner's recompute agrees.
        fname = src["locator"].get("file") or "fetched.bin"
        prior = fetch_dir / fname
        if prior.is_file():
            path = prior
            rec["fetched_via"] = "doi (prior fetch, hash-gated)"
        elif fetch:
            path = fetch_doi(src["locator"], fetch_dir)
            rec["fetched_via"] = "doi"
    if path is None or not Path(path).is_file():
        rec.update(state="ABSENT",
                   reason="absent at declared locator (no substitute "
                          "eligible, SL-3)")
        return rec, "BLOCKED"
    path = Path(path)
    observed = sha256_file(path)
    rec["observed_sha256"] = observed
    rec["locator_resolved"] = _record_path(path, workspace, pkg)
    if observed != src["expected_sha256"]:
        rec.update(state="HASH-MISMATCH",
                   reason="present but hash differs from manifest "
                          "(substitute never eligible, SL-3)")
        return rec, "BLOCKED"
    # locked: store a content-addressed copy (A-26)
    dest = store / observed
    if not dest.exists():
        shutil.copyfile(path, dest)
        dest.chmod(0o444)
    rec["store_path"] = _ws_rel(dest, workspace)
    if src.get("derivation"):
        d = check_derivation(path, src["derivation"], work_dir, sid)
        if d.get("derived_text"):
            d["derived_text"] = _ws_rel(d["derived_text"], workspace)
        rec["derivation"] = d
        if d["state"] != "LOCKED-BY-PIN":
            rec.update(state="BLOCKED", reason=d.get("reason"))
            return rec, "BLOCKED"
        rec["state"] = "LOCKED-BY-PIN"
    else:
        rec["state"] = "LOCKED"
    if src.get("site"):
        s = check_site(path, src["site"])
        rec["site_check"] = s
        if not s["verified"]:
            rec.update(state="BLOCKED",
                       reason="site pin does not verify against the "
                              "locked bytes (manifest site defect)")
            return rec, "BLOCKED"
    return rec, rec["state"]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aavep_preflight")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--package", required=True,
                    help="target package directory (or its parent staging)")
    ap.add_argument("--workspace", required=True, help="audit workspace")
    ap.add_argument("--house-root", default=str(Path.home()),
                    help="root substituted for {house} in locators")
    ap.add_argument("--fetch", action="store_true",
                    help="permit DOI fetches (default: offline, K-2)")
    ap.add_argument("--package-zip",
                    help="the target package archive, when the manifest "
                         "pins its sha256")
    ap.add_argument("--out", required=True, help="lock table JSON output")
    a = ap.parse_args(argv)
    print(DISC)
    table, code = compute_lock_table(
        a.manifest, a.package, a.workspace, a.house_root, a.fetch,
        getattr(a, "package_zip", None))
    Path(a.out).write_text(json.dumps(table, indent=1, ensure_ascii=False),
                           encoding="utf-8")
    if code == 3:
        print("TARGET MISMATCH — see lock table")
        return 3
    blocked = [k for k, v in table["instruments"].items()
               if v["lock_state"] == "BLOCKED"]
    print(f"preflight complete: target MATCH; instruments "
          f"{len(table['instruments'])}; BLOCKED: {blocked or 'none'}; "
          f"problems: {len(table['problems'])}; valid: {table['valid']}")
    for p in table["problems"]:
        print("  PROBLEM:", p)
    return code


def validate_manifest_structure(man):
    """Structural check of the fields the tools consume (the shipped
    JSON Schema, enforced at the level the stdlib allows)."""
    problems = []
    if man.get("aavep_version") not in ("1.0", "1.1"):
        problems.append("manifest aavep_version is not '1.0' or "
                        "'1.1' (v1.0 instances remain valid v1.1 "
                        "input; design section 13)")
    tgt = man.get("target") or {}
    for f in ("manuscript_path", "manuscript_sha256"):
        if not tgt.get(f):
            problems.append(f"manifest target lacks {f}")
    ids = set()
    for inst in man.get("instruments", []):
        if inst.get("id") in ids:
            problems.append(f"duplicate instrument id {inst.get('id')}")
        ids.add(inst.get("id"))
        if inst.get("kind") not in ("suite_script", "command"):
            problems.append(f"{inst.get('id')}: unknown kind "
                            f"{inst.get('kind')}")
        for src in inst.get("sources", []):
            for f in ("source_id", "locator", "expected_sha256"):
                if not src.get(f):
                    problems.append(f"{inst.get('id')}: source lacks {f}")
            loc = src.get("locator") or {}
            if loc.get("kind") == "doi" and "concept" in str(
                    loc.get("value", "")).lower():
                problems.append(f"{inst.get('id')}: concept DOI locator "
                                "is not version-specific (A-6)")
    problems.extend(validate_paths_and_reach(man))
    return problems


_PLACEHOLDER_ROOTS = ("{kit}", "{house}", "{scratch}", "{ws}")


def _token_roots(tok):
    """Classify one argv token for the reach check (§5.1). Returns
    (root, rest): root in package|workspace|store|kit|house|absolute|
    relative; rest is the path under the root."""
    for ph, root in (("{kit}", "kit"), ("{house}", "house"),
                     ("{scratch}", "package"), ("{ws}", "workspace")):
        if tok == ph or tok.startswith(ph + "/"):
            return root, tok[len(ph):].lstrip("/")
    if tok.startswith("/"):
        return "absolute", tok.lstrip("/")
    return "relative", tok


def _escapes(rest):
    """True if a root-relative path climbs above its root."""
    depth = 0
    for seg in rest.split("/"):
        if seg in ("", "."):
            continue
        if seg == "..":
            depth -= 1
            if depth < 0:
                return True
        else:
            depth += 1
    return False


def validate_paths_and_reach(man):
    """Design §5.1/§9: argv paths must sit inside the instrument's
    declared reach; suite_script paths must be package-relative and
    non-escaping; default targets must resolve. Problems are
    MANIFEST-UNSAFE class (preflight rejection)."""
    problems = []
    src_ids = {s.get("source_id") for i in man.get("instruments", [])
               for s in i.get("sources", [])}
    for inst in man.get("instruments", []):
        iid = inst.get("id")
        reach = set(inst.get("reach", ["package", "workspace", "store"]))
        if inst.get("kind") == "suite_script":
            p = inst.get("path", "")
            if p.startswith("/") or _escapes(p):
                problems.append(
                    f"{iid}: MANIFEST-UNSAFE — suite_script path "
                    f"escapes the package: {p}")
        for ti, tok in enumerate(inst.get("command", []) or []):
            if not isinstance(tok, str):
                continue
            if ti == 0 and tok.startswith("/"):
                # argv[0] is the program itself; the runner resolves
                # and records it (B-7). Data paths are what reach
                # governs.
                continue
            root, rest = _token_roots(tok)
            if root == "absolute":
                if not any(isinstance(r, str) and r.startswith("/")
                           and (tok == r or tok.startswith(r + "/"))
                           for r in reach):
                    problems.append(
                        f"{iid}: MANIFEST-UNSAFE — absolute path "
                        f"outside declared reach: {tok}")
            elif root in ("house",) and root not in reach:
                problems.append(
                    f"{iid}: MANIFEST-UNSAFE — path rooted at "
                    f"{{{root}}} not covered by declared reach")
            elif root in ("kit", "workspace", "package") \
                    and _escapes(rest):
                problems.append(
                    f"{iid}: MANIFEST-UNSAFE — path escapes its "
                    f"root: {tok}")
            elif root == "relative" and _escapes(rest):
                problems.append(
                    f"{iid}: MANIFEST-UNSAFE — relative path climbs "
                    f"above its root: {tok}")
        dt = inst.get("default_target")
        if dt and dt not in src_ids and dt.startswith("/"):
            problems.append(
                f"{iid}: MANIFEST-UNSAFE — default_target is an "
                f"absolute path not declared as a source: {dt}")
        if inst.get("external_reads_unmediated"):
            problems.append(
                f"{iid}: NON-CONFORMING (section 9) — instrument "
                f"declares unmediated external reads; external "
                f"content is consumed only via the store")
    return problems


def compute_lock_table(manifest_path, package, workspace, house_root,
                       fetch, package_zip=None):
    """The whole preflight computation, importable so the runner can
    recompute the table and refuse a forged or stale one (loop
    repair). Returns (table, exit_code): 3 = TARGET MISMATCH,
    4 = problems present (table invalid), 0 = clean."""
    ws = Path(workspace).resolve(); ws.mkdir(parents=True, exist_ok=True)
    store = ws / "store"; store.mkdir(exist_ok=True)
    fetch_dir = ws / "fetched"; fetch_dir.mkdir(exist_ok=True)
    work_dir = ws / "preflight_work"
    man = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    pkg = Path(package).resolve() / man["target"].get(
        "package_subdir", "")
    table = {"manifest_sha256": sha256_file(manifest_path),
             "target": {}, "authority": {}, "instruments": {},
             "external_bindings": {}, "problems": []}
    table["problems"].extend(validate_manifest_structure(man))

    def check_timeout(owner, t):
        if t is not None and not (TIMEOUT_MIN <= t <= TIMEOUT_MAX):
            table["problems"].append(
                f"{owner}: timeout_s {t} outside [{TIMEOUT_MIN}, "
                f"{TIMEOUT_MAX}] — preflight rejection (A-23)")
    for inst in man.get("instruments", []):
        check_timeout(inst["id"], inst.get("timeout_s"))
    if man.get("suite_runner"):
        check_timeout("suite_runner", man["suite_runner"].get("timeout_s"))

    tgt = man["target"]
    if package_zip and tgt.get("package_zip_sha256"):
        zh = sha256_file(package_zip)
        table["target"]["package_zip_sha256"] = zh
        table["target"]["package_zip_matches"] = (
            zh == tgt["package_zip_sha256"])
        if zh != tgt["package_zip_sha256"]:
            table["problems"].append(
                "package zip hash differs from the manifest's pin")
    mpath = pkg / tgt["manuscript_path"]
    if not mpath.is_file():
        table["target"] = {"state": "TARGET_MISMATCH",
                           "reason": f"manuscript not found at {mpath}"}
        table["valid"] = False
        return table, 3
    mhash = sha256_file(mpath)
    table["target"].update(
        {"manuscript_path": _record_path(mpath, ws, pkg),
         "observed_sha256": mhash,
         "expected_sha256": tgt["manuscript_sha256"],
         "state": "MATCH" if mhash == tgt["manuscript_sha256"]
         else "TARGET_MISMATCH"})
    if table["target"]["state"] != "MATCH":
        table["valid"] = False
        return table, 3
    if tgt.get("package_manifest_path"):
        pm = pkg / tgt["package_manifest_path"]
        if not pm.is_file():
            table["problems"].append(
                "package manifest file absent at the declared path — "
                "target identity cannot be fully verified")
        else:
            table["target"]["package_manifest_sha256"] = sha256_file(pm)
            match = sha256_file(pm) == tgt.get("package_manifest_sha256")
            table["target"]["package_manifest_matches"] = match
            if not match:
                table["problems"].append(
                    "package manifest hash differs from the manifest's "
                    "pin — the package is not the declared package")

    auth = man.get("authority")
    if auth:
        lines = text_lines(mpath)
        lo, hi = auth["site"]["line_range"]
        span = "\n".join(lines[lo - 1:hi])
        ok = auth["rule_quote"] in span
        table["authority"] = {"rule_quote": auth["rule_quote"],
                              "site": auth["site"], "verified": ok}
        if not ok:
            table["problems"].append(
                "authority transcription does not verify against the "
                "target's bytes at the declared site (A-2)")

    for inst in man.get("instruments", []):
        recs, worst = [], "LOCKED"
        for src in inst.get("sources", []):
            rec, state = lock_source(src, ws, Path(house_root), store,
                                     fetch, fetch_dir, work_dir, pkg=pkg)
            recs.append(rec)
            if state == "BLOCKED":
                worst = "BLOCKED"
            elif state == "LOCKED-BY-PIN" and worst == "LOCKED":
                worst = "LOCKED-BY-PIN"
        entry = {"lock_state": worst if recs else "NO_SOURCES",
                 "sources": recs,
                 "applicability": inst.get("applicability", "required")}
        # Instrument bytes are locked too (loop repair): the code whose
        # exit code becomes the status is part of the lock.
        if inst.get("kind") == "suite_script":
            ipath = pkg / inst["path"]
            if ipath.is_file():
                entry["instrument_sha256"] = sha256_file(ipath)
                if inst.get("sha256") and \
                        inst["sha256"] != entry["instrument_sha256"]:
                    entry["lock_state"] = "BLOCKED"
                    entry["reason"] = ("instrument bytes differ from the "
                                       "manifest's declared sha256")
                else:
                    # v1.1 (§5.2): the instrument's bytes also enter
                    # the content-addressed store; the runner places
                    # them from the store at execution time.
                    dst = store / entry["instrument_sha256"]
                    if not dst.exists():
                        shutil.copyfile(ipath, dst)
                    dst.chmod(0o444)
                    entry["store_path"] = f"store/{entry['instrument_sha256']}"
            else:
                entry["lock_state"] = "BLOCKED"
                entry["reason"] = f"instrument file absent: {inst['path']}"
        # Declared modules (B-30): package modules the instrument
        # imports are pinned and store-copied like instrument bytes.
        mods = []
        for mrel in inst.get("modules", []) or []:
            mpath = pkg / mrel
            if mpath.is_file():
                mh = sha256_file(mpath)
                dst = store / mh
                if not dst.exists():
                    shutil.copyfile(mpath, dst)
                dst.chmod(0o444)
                mods.append({"path": mrel, "sha256": mh,
                             "state": "LOCKED"})
            else:
                mods.append({"path": mrel, "sha256": None,
                             "state": "BLOCKED"})
                entry["lock_state"] = "BLOCKED"
                entry["reason"] = f"declared module absent: {mrel}"
        if mods:
            entry["modules"] = mods
        if inst.get("applicability") == "not_applicable":
            entry["lock_state"] = "NOT_APPLICABLE"
            entry["reason"] = inst.get("na_reason")
        table["instruments"][inst["id"]] = entry

    # Dependency locks, propagated to a fixed point (loop repair: a
    # single forward sweep was order-dependent and laundered chains).
    changed = True
    while changed:
        changed = False
        for inst in man.get("instruments", []):
            entry = table["instruments"][inst["id"]]
            if entry["lock_state"] == "BLOCKED":
                continue
            blocked_by = [d for d in inst.get("depends_on_instruments", [])
                          if table["instruments"].get(d, {}).get(
                              "lock_state") == "BLOCKED"]
            if blocked_by:
                entry["lock_state"] = "BLOCKED"
                entry["dependency_blocked_by"] = blocked_by
                changed = True

    sr = man.get("suite_runner")
    if sr:
        rpath = pkg / sr["path"]
        if rpath.is_file():
            listed = set(re.findall(r'"([A-Za-z0-9_]+\.py)"',
                                    rpath.read_text(encoding="utf-8",
                                                    errors="replace")))
            declared = {i["path"].split("/")[-1]
                        for i in man.get("instruments", [])
                        if i.get("kind") == "suite_script"}
            missing = sorted(s for s in listed
                             if s.endswith(".py") and s not in declared
                             and "RB1" not in s)
            table["reconciliation"] = {
                "runner_listed": sorted(listed),
                "manifest_declared": sorted(declared),
                "missing_from_manifest": missing,
                "manifest_incomplete": bool(missing)}
            if missing:
                table["problems"].append(
                    f"MANIFEST INCOMPLETE: runner lists {missing} not "
                    "declared in the manifest (A-23) — the affected "
                    "surface is capped at UNRESOLVED")

    # v1.1 notices (design §13): behaviours a v1.0 instance inherits
    # are printed, never silent. §9 notices mark house-locator sources
    # whose consumption must be store-mediated.
    notices = []
    if man.get("aavep_version") == "1.0":
        notices.append(
            "v1.0 manifest instance under v1.1 rules: expectations "
            "now gate statuses (§5.3); HOME/TMPDIR are redirected "
            "(§5.5); reach defaults to {package, workspace, store}; "
            "the protocol-default marker set applies (§6.1)")
    for inst in man.get("instruments", []):
        for src in inst.get("sources", []):
            loc = src.get("locator") or {}
            if loc.get("kind") == "path" and "{house}" in str(
                    loc.get("value", "")):
                notices.append(
                    f"{inst['id']}/{src['source_id']}: house-locator "
                    f"source — consumption is conforming only via "
                    f"the store copy (§9); a runtime resolution "
                    f"against the ambient $HOME is non-conforming "
                    f"by construction")
    if notices:
        table["notices"] = notices
    # §7.1 lint of the package's own manifest: manifested cache
    # paths are defects of the manifest, recorded — not problems
    # against the target, and never read as tampering.
    if tgt.get("package_manifest_path"):
        pm = pkg / tgt["package_manifest_path"]
        if pm.is_file():
            entries = parse_sha256_manifest(
                pm.read_text(encoding="utf-8", errors="replace"))
            defects, effective = lint_manifest_entries(
                sorted(entries), tgt.get("exclusions"))
            if defects:
                table["manifest_defects"] = defects
            if effective:
                table["effective_exclusions"] = effective

    table["valid"] = not table["problems"]
    return table, (0 if table["valid"] else 4)


if __name__ == "__main__":
    raise SystemExit(main())
