# Comparative Honesty Audit — Design Synthesis (Valkyrie adjudication, 2026-11-08)

Commission: Dervis, 2026-11-08 — take ChatGPT's Paper 12.5 review device (five-layer separation, derivation ≠ interpretation, burden-of-proof table), keep what works, go further: a machine-checked comparative audit of the 27-state ledger vs the Standard Model. Four-agent swarm (metrics / five-layer receipts / machine-check programme / red-team steelman), adjudicated below. DESIGN ONLY — no build authorized or started; staging and any pilot await his word.

## 1. The definition (metrics agent, adopted)

Honesty = **accounting fidelity**: the gap between a framework's public self-presentation and what independent audit finds about its premises, freedoms, evidence, interpretive bridges, scope, and corrections. Explicitly NOT truth, parsimony, empirical success, or parameter count. The definition must be able to convict the ledger (a hardcoded verification script fails it; the PDG parameter tables score high under it) or it is rigged and discarded.

## 2. The strongest five metrics (ranked)

1. **M3 Undeclared Bridge Density** — formal result → physical meaning without a marked, supported bridge, per 100 major claims. The centre of the whole question.
2. **M1 Load-Bearing Premise Declaration Rate** — premises found by counterfactual-removal test; declared = epistemic status identifiable at first load-bearing use. Keyword counting killed (house-style bias); functional test instead.
3. **M2 Degree-of-Freedom Provenance Accuracy** — every freedom that can move an output (parameters, cutoffs, windows, script constants, representatives) traced to derived / measured / fitted / assumed / arbitrary. Can favour the SM (PDG provenance is meticulous) — a necessary anti-rigging feature.
4. **M4 Claim–Evidence Traceability & Fidelity** — format-neutral: does the cited artefact support THIS claim at THIS strength? Kills badge-counting, citation-stuffing, and input-equals-output scripts on both sides.
5. **M5 Falsifier Coverage & Sharpness** — 0/1/2 rubric (none / vague / concrete defeating condition), plus a false-falsifier rate; headline claims scored, not weakened restatements.

## 3. Killed metrics (rigged or empty — excluded by design)

- Raw free-parameter count (parsimony ≠ honesty) → replaced by M2.
- **The 26-vs-27 count resemblance: killed and excluded — not evidence, not a tiebreaker, not a scoring bonus.**
- Raw badge / registry / "Level A" counts (home-format bias) → replaced by M4.
- "No probability postulate" as a point in itself (hidden measure-equivalents are scored under M1/M2/M3/M6 wherever they occur, either side).
- Word-frequency counts of contested terms; raw machine-verified claim counts.

Repaired before use: layer separation (score inference EDGES, not headings; functional roles; dropped from headlines if blind coders can't apply it reliably, κ ≲ 0.6); correction behaviour (bounded accountable corpora only, severity-weighted, acknowledgment/linkage not volume — otherwise reported as parallel case studies, never ranked).

## 4. Protocol (non-negotiable)

- **Freeze before scoring:** corpora named by edition, hash-pinned; claim-extraction rules, coding manual, severity weights frozen; post-hoc metric change voids the run.
- **Matched strata:** formal vs formal (Papers 11/11.5/12/12.5 + registries vs PDG review + named QFT/stat-mech texts), gloss vs gloss (cheat sheets vs textbook introductions/review glosses). Gloss results never reported as formal-theory results (the H-series label discipline).
- **Blind duplicate coding** with inter-rater reliability per metric; adversarial re-annotation pass instructed to make BOTH sides' scores worse.
- **Dashboard, not an index:** numerator/denominator, intervals, weighted + unweighted, pass and fail examples from both sides. No single "Honesty Index."
- **Adversarial metric nomination:** SM-side reviewers nominate honesty metrics of their own, scored with equal weight.
- **Pre-registered counts-against list:** named findings that will be printed as defeats — up to withdrawal of the comparative claim (e.g., blind coders rating the ledger's own cheat-sheet prose as sliding at a rate comparable to textbook prose).

## 5. Machine-check suite (11 checks; symmetric, same script both corpora)

PROV-COMPLETE (premise/provenance closure), REG-POINT (badge→script content match), LAYER-SEP (layer-crossing scan, "detected" is load-bearing), FALS-COV, PARAM-PROV (convention-explicit bookkeeping; the reporter is FORBIDDEN from emitting a verdict from totals — verdict-injection is a planted mutant), BRIDGE-DEBT (unargued interpretations itemised with creditor and age, both sides), CENSUS-TRACE (every frequency claim traced to count / declared postulate / theorem-with-hypotheses / NO TERMINUS FOUND), ANTI-VAC (delete-the-assertion + premise-perturbation + genuine mutant batteries; order-preserving wrong inputs printed as LIMITS), BYTE-REPRO (content-marker listing identity, fence parity, fresh-extraction re-run), GLOSS-EVID (cross-side claims need verbatim anchored quotes; quote-mining rejected), OPEN-PRESERVE (openness conserved through the citation graph; silent closure/deletion rejected).

Every check prints the five-part disclosure (native domain / verified domain / map / what it preserves / what stays outside) or fails the suite regardless of result.

## 6. Five-layer findings so far (receipts agent; quotes sourced)

Seven claims audited (microcanonical weights, canonical derivation, ergodic identification, ensemble ontology, density operators/improper mixtures, SM parameters, MaxEnt). Strongest asymmetries:

1. **The ergodic identification** — the standard side's ensemble average reaches measurement only through a hypothesis unproven for realistic systems and known-false in generality (KAM/FPU), yet the condition is dropped within pages wherever results are used. The ledger has no second, fictitious average; the step does not exist.
2. **Measure provenance** — every standard weighting traces to the equal-a-priori postulate, a derivation inheriting it, or MaxEnt's inference rule + extra bridge. The ledger assigns no weights; its own stipulation sits once at L1 (the 27-state inventory), declared as ontology.
3. **L5 status instability** — ensemble: "imagined" copies vs states "represented an equal number of times," same chapter; reduced ρ: statistics-sufficient instrument (theorem) vs "the state the subsystem is in" (gloss HJW forbids for improper mixtures).

Credits to the standard side, printed in the audit: (a) its foundations literature self-polices — proper/improper distinction, HJW, ergodic limits are documented inside its own canon; most audit ammunition is manufactured there; (b) Jaynes (1957) states his conditional openly and the PDG institutionalises declared-input practice — the slides concentrate in secondary retelling. Defensible charge, narrowed: the establishment knows its joints; the knowledge does not propagate into the working texts where the claims are consumed.

Ledger's symmetric costs, on record: narrower scope (declared populations/windows only), an L1 stipulation of its own, no continuum/partition-function machinery, zero comparable empirical wins to date.

## 7. Red-team conditions (the price of survival)

Ranked dangers: **O2 gerrymandered scoreboard** (most lethal; H.4's 5/5-vs-0/5 shutout precedent in print; its standing tu quoque defence is insufficient) → **O5 vocabulary capture + verification circularity** (answerable only by genuine externality: unaffiliated replicators, at least one bench the author does not select/brief/adjudicate) → **O3 straw gloss** (repaired by matched strata + page-cited load-bearing cases) → **O6 vacuous honesty** (risk-weighting + claim-yield rows printed beside honesty rows) → **O1 consolation prize** (cannot be neutralized; conceded: the empirical axis is scored, disclosed, and the SM wins it overwhelmingly; honest accounting of a weak record is still a weak record) → **O4 corpus asymmetry** (matched sampling; completeness = evidence about auditability, not integrity).

## 8. The ceiling (the strongest claim the programme may ever print)

> "Under one published set of bookkeeping criteria, applied symmetrically and open to return application, the ledger's texts declare more of what they assume than the cited standard texts declare of theirs — and here is the itemised account, the criteria, and the machine record, so the reader can check the account and dispute the criteria."

Banned constructions (tripwired in prose): "proves/demonstrates the ledger is more honest than the Standard Model" (unscoped); "machine-verified superiority"; "the SM fails verification"; any naked comparative without convention + corpus scope in the same sentence; any PASS without its disclosure header.

## 9. Recommended pilot (awaits his word)

One domain first: statistical mechanics (Papers 12/12.5 territory). Frozen corpus per side; 60–100 major claims per side; the five metrics only; coding manual published before results; two blind coders + adjudicator; dashboard out. Structural note (Valkyrie): the frozen protocol is a reusable instrument — it is the natural shared backbone for the Tier 2 critique papers (18–26), each applying the same pre-registered audit to its domain instead of inventing its own standard per paper.
