"""honesty_plugin — machine-check instrument for the Comparative Honesty
Audit protocol, FREEZE v1.0 (2026-11-08).

v1 implements the mechanical checks named in FREEZE_v1.0.md §6. It does NOT
score metrics M1–M5 (those are human-coding metrics over claim corpora).
Every tool output carries the criteria version, the freeze hash (short
form in the header line, full hash in the source line), and the five-part
disclosure header required by the freeze. Version 1.1 adds a seventh tool,
validate_cards, under Annex v1.1 (FREEZE_v1.1_ANNEX.md), which reports
criteria v1.1; the six original tools still report criteria v1.0.
"""

CRITERIA_VERSION = "1.0"
ANNEX_VERSION = "1.1"
FREEZE_DATE = "2026-11-08"
PLUGIN_VERSION = "1.1.2"

__all__ = ["CRITERIA_VERSION", "ANNEX_VERSION", "FREEZE_DATE", "PLUGIN_VERSION"]
