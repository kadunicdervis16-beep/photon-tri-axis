"""MCP server face of honesty_plugin — same tools, same reports as the CLI.

Transport: stdio. Implementation order:
  1. The official `mcp` Python SDK (lowlevel Server API), if importable.
  2. A minimal hand-rolled MCP JSON-RPC (NDJSON) server, stdlib only, used
     when the SDK is absent or when HONESTY_PLUGIN_MCP_FORCE_FALLBACK=1.

Both paths dispatch through tools.call_tool, so the tool behaviour is
identical whichever face serves it. The active path is printed to stderr at
startup (stdout is the protocol channel and is never polluted).
"""
from __future__ import annotations

import json
import os
import sys

from . import PLUGIN_VERSION, tools

SERVER_NAME = "honesty-plugin"


def _tool_defs() -> list[dict]:
    defs = []
    for name, spec in tools.TOOL_SPECS.items():
        defs.append({
            "name": name,
            "description": spec["description"],
            "inputSchema": {
                "type": "object",
                "properties": spec["properties"],
                "required": spec["required"],
            },
        })
    return defs


# ---------------------------------------------------------------------------
# path 1: official SDK
# ---------------------------------------------------------------------------

def _run_sdk() -> None:
    import anyio
    import mcp.types as types
    from mcp.server.lowlevel import Server
    from mcp.server.stdio import stdio_server

    server = Server(SERVER_NAME)

    @server.list_tools()
    async def _list_tools():
        return [types.Tool(name=d["name"], description=d["description"],
                           inputSchema=d["inputSchema"]) for d in _tool_defs()]

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict | None):
        # Errors come back as headered reports with isError set — the same
        # semantics as the fallback path (tools._call_tool_full never
        # raises for tool-level failures).
        text, is_err = tools._call_tool_full(name, arguments or {})
        content = [types.TextContent(type="text", text=text)]
        try:
            return types.CallToolResult(content=content, isError=is_err)
        except Exception:
            if is_err:
                raise RuntimeError(text)
            return content

    async def _main():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream,
                             server.create_initialization_options())

    anyio.run(_main)


# ---------------------------------------------------------------------------
# path 2: hand-rolled minimal MCP JSON-RPC over stdio (NDJSON), stdlib only
# ---------------------------------------------------------------------------

def _run_fallback() -> None:
    def send(obj: dict) -> None:
        sys.stdout.write(json.dumps(obj) + "\n")
        sys.stdout.flush()

    def result(req_id, payload):
        send({"jsonrpc": "2.0", "id": req_id, "result": payload})

    def error(req_id, code, message):
        send({"jsonrpc": "2.0", "id": req_id,
              "error": {"code": code, "message": message}})

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            # per JSON-RPC: a parse error is ANSWERED (-32700, id null),
            # never silently swallowed (a client awaiting it would hang)
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32700, "message": "parse error"}})
            continue
        if not isinstance(msg, dict):
            # valid JSON, wrong shape (batch array, bare scalar): answer
            # -32600 and KEEP SERVING — one bad line must not kill the server
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32600,
                            "message": "invalid request: expected a JSON-RPC object"}})
            continue
        method = msg.get("method", "")
        req_id = msg.get("id")
        params = msg.get("params") or {}
        if method == "initialize":
            result(req_id, {
                "protocolVersion": params.get("protocolVersion", "2024-11-05"),
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "version": PLUGIN_VERSION},
            })
        elif method.startswith("notifications/"):
            continue
        elif method == "ping":
            result(req_id, {})
        elif method == "tools/list":
            result(req_id, {"tools": _tool_defs()})
        elif method == "tools/call":
            name = params.get("name", "")
            text, is_err = tools._call_tool_full(name, params.get("arguments") or {})
            result(req_id, {"content": [{"type": "text", "text": text}],
                            "isError": is_err})
        elif req_id is not None:
            error(req_id, -32601, f"method not found: {method}")


def main() -> int:
    force_fallback = os.environ.get("HONESTY_PLUGIN_MCP_FORCE_FALLBACK") == "1"
    if not force_fallback:
        try:
            import mcp  # noqa: F401
            print(f"[{SERVER_NAME}] serving via official mcp SDK", file=sys.stderr)
            _run_sdk()
            return 0
        except Exception as exc:
            print(f"[{SERVER_NAME}] SDK path unavailable ({type(exc).__name__}: {exc}); "
                  "falling back to stdlib JSON-RPC", file=sys.stderr)
    else:
        print(f"[{SERVER_NAME}] fallback forced by env", file=sys.stderr)
    _run_fallback()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
