"""The tools: the six v1 tools plus validate_cards (v1.1, Annex §A7).
Each returns (report_text, data_dict).

Every report begins with the five-part disclosure header (disclose.header).
Labels state v1 limits in the output itself: heuristics are called
heuristics, existence checks are not dressed up as content matching, and
scan results say "detected". Nothing here scores metrics M1–M5.
"""
from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

from .disclose import header, header_cards

# --------------------------------------------------------------------------
# shared helpers
# --------------------------------------------------------------------------

def _resolve_package(path: str) -> tuple[Path, tempfile.TemporaryDirectory | None]:
    """Accept a package directory or a .zip; return (root_dir, tmpdir)."""
    p = Path(path).expanduser()
    if p.is_dir():
        return p, None
    if p.is_file() and p.suffix == ".zip":
        tmp = tempfile.TemporaryDirectory(prefix="honesty_pkg_")
        with zipfile.ZipFile(p) as zf:
            zf.extractall(tmp.name)
        root = Path(tmp.name)
        # Locate the package root: the shallowest directory (deterministic
        # order) containing a scripts/ dir or top-level .py files. A zip
        # wrapping a folder PLUS a stray top-level file still resolves.
        def _score(d: Path) -> int:
            if (d / "scripts").is_dir():
                return 0
            if any(d.glob("*.py")):
                return 1
            return 2
        cands = [root] + sorted((p for p in root.rglob("*") if p.is_dir()),
                                key=lambda d: (len(d.parts), str(d)))
        for d in cands:
            if _score(d) < 2:
                root = d
                break
        return root, tmp
    raise FileNotFoundError(f"package path not found or not a dir/.zip: {path}")


def _find_scripts_dir(root: Path) -> Path | None:
    if (root / "scripts").is_dir():
        return root / "scripts"
    py = list(root.glob("*.py"))
    return root if py else None


def _find_paper(root: Path) -> Path | None:
    mds = sorted(root.glob("*.md"))
    for m in mds:
        if m.name.lower().startswith("paper"):
            return m
    for m in mds:
        if "readme" not in m.name.lower() and "manifest" not in m.name.lower():
            return m
    return None


def _last_line(text: str) -> str:
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    if not lines:
        return "(no output)"
    last = lines[-1]
    return last[:200] + " […truncated]" if len(last) > 200 else last


# --------------------------------------------------------------------------
# 1. run_verification_suite
# --------------------------------------------------------------------------

_SUITE_ENTRY = re.compile(r'\(\s*"([A-Za-z0-9_]+\.py)"\s*,\s*(True|False)\s*\)')


def _looks_like_runner(name: str) -> bool:
    n = name.lower()
    return n == "run_all.py" or n.endswith("_run_all.py") or n.startswith("rb1")


def run_verification_suite(package_path: str, timeout_s: int = 420,
                           run_unlisted: bool = False) -> tuple[str, dict]:
    root, tmp = _resolve_package(package_path)
    try:
        scripts_dir = _find_scripts_dir(root)
        paper = _find_paper(root)
        results: list[dict] = []
        runner_note = "no RB1-style runner detected"
        if scripts_dir is None:
            text = header(
                "run_verification_suite",
                "the verification claims of the named package",
                "nothing — no scripts directory or top-level .py files detected",
                "package path -> filesystem scan",
                "nothing",
                "everything; the check did not run",
            ) + "\nRESULT: FAIL — no scripts detected in package.\n"
            return text, {"status": "FAIL", "scripts": []}

        all_py = sorted(scripts_dir.glob("*.py"))
        runner = None
        for f in all_py:
            if _looks_like_runner(f.name):
                runner = f
        plan: list[tuple[Path, bool]] = []
        n_unparsed = 0
        if runner is not None:
            rsrc = runner.read_text(encoding="utf-8", errors="replace")
            suite_entries = _SUITE_ENTRY.findall(rsrc)
            tupleish = len(re.findall(r"\(\s*\"[^\"]+\.py\"", rsrc))
            n_unparsed = max(0, tupleish - len(suite_entries))
            if suite_entries:
                runner_note = (f"suite membership + paper-argument flags taken from runner "
                               f"{runner.name} (RB1-style); the runner is then executed once "
                               "itself, which RE-RUNS the suite — that line is a second, "
                               "aggregate observation, not independent evidence")
                if n_unparsed:
                    runner_note += (f"; WARNING: {n_unparsed} runner line(s) looked like "
                                    "suite entries but did not parse and were NOT run")
                for name, needs in suite_entries:
                    plan.append((scripts_dir / name, needs == "True"))
            else:
                runner_note = f"runner {runner.name} found but its suite list was not parseable"
        if not plan:
            if not run_unlisted:
                text = header(
                    "run_verification_suite",
                    "the verification claims of the named package, as a whole",
                    "nothing was executed",
                    "package path -> filesystem scan + runner inspection",
                    "nothing",
                    "everything; the run was refused before execution. SECURITY: "
                    "this tool executes package code with the caller's privileges; "
                    "executing scripts that no runner vouches for requires the "
                    "explicit run_unlisted opt-in",
                ) + (f"\npackage root: {root}\nplan: {runner_note}\n\n"
                     "RESULT: REFUSED — no parseable RB1-style suite list was detected, "
                     "and run_verification_suite does not execute unlisted scripts "
                     "without run_unlisted=true (they would run with your privileges, "
                     "unvouched by any runner). Re-run with the opt-in only for "
                     "packages you trust.\n")
                return text, {"status": "REFUSED", "scripts": [],
                              "reason": "no parseable suite list; unlisted execution not opted in"}
            plan = [(f, False) for f in all_py if f is not runner]
            runner_note += "; run_unlisted=true — executing every script with no arguments (explicit opt-in)"

        def _run(script: Path, needs_paper: bool) -> dict:
            cmd = [sys.executable, str(script)]
            if needs_paper and paper is not None:
                cmd.append(str(paper))
            t0 = time.time()
            try:
                proc = subprocess.run(cmd, capture_output=True, text=True,
                                      timeout=timeout_s, cwd=str(root))
                dt = time.time() - t0
                return {"name": script.name, "exit": proc.returncode,
                        "pass": proc.returncode == 0, "seconds": round(dt, 2),
                        "last_line": _last_line(proc.stdout + proc.stderr)}
            except subprocess.TimeoutExpired:
                return {"name": script.name, "exit": None, "pass": False,
                        "seconds": round(time.time() - t0, 2),
                        "last_line": f"TIMEOUT after {timeout_s}s"}
            except Exception as exc:  # spawn failure etc.
                return {"name": script.name, "exit": None, "pass": False,
                        "seconds": round(time.time() - t0, 2),
                        "last_line": f"SPAWN ERROR: {exc}"}

        for script, needs in plan:
            if script.exists():
                results.append(_run(script, needs))
            else:
                results.append({"name": script.name, "exit": None, "pass": False,
                                "seconds": 0.0, "last_line": "LISTED IN RUNNER BUT FILE MISSING"})
        runner_result = None
        if runner is not None:
            runner_result = _run(runner, True)
            runner_result["name"] = runner.name + " (runner, re-runs the suite)"

        npass = sum(1 for r in results if r["pass"])
        lines = [header(
            "run_verification_suite",
            "the verification claims of the named package, as a whole",
            "exit codes of the package's own scripts in THIS environment: "
            "each listed script run once in a fresh subprocess, with the "
            "paper file passed as argument only where the runner's own "
            "flags say so; the runner (if executed) re-runs the suite",
            "script file -> subprocess execution; suite membership taken from "
            "the package's own RB1-style runner where one exists",
            "per-script pass/fail under each script's own exit contract (exit 0 = pass)",
            "whether any script's assertions actually check its claim's content "
            "(that is M4 fidelity — a human/deep audit, not this tool); premise "
            "truth; behaviour in other environments; scripts the runner does not "
            "list. SECURITY: the scripts execute with the caller's privileges, "
            "unsandboxed — run only packages you trust, or inside a sandbox",
        ), f"package root: {root}", f"paper file: {paper}", f"plan: {runner_note}", ""]
        for r in results:
            lines.append(f"  [{'PASS' if r['pass'] else 'FAIL'}] {r['name']} "
                         f"(exit {r['exit']}, {r['seconds']}s) — the script's own last line: \"{r['last_line']}\"")
        if runner_result is not None:
            r = runner_result
            lines.append(f"  [{'PASS' if r['pass'] else 'FAIL'}] {r['name']} "
                         f"(exit {r['exit']}, {r['seconds']}s) — the script's own last line: \"{r['last_line']}\"")
        status = "PASS" if results and npass == len(results) and (runner_result is None or runner_result["pass"]) else "FAIL"
        lines.append(f"\nRESULT: {status} — {npass}/{len(results)} listed scripts exited 0"
                     + (f"; runner exited {runner_result['exit']}" if runner_result else ""))
        data = {"status": status, "scripts": results, "runner": runner_result,
                "n_pass": npass, "n_total": len(results)}
        return "\n".join(lines) + "\n", data
    finally:
        if tmp is not None:
            tmp.cleanup()


# --------------------------------------------------------------------------
# 2. check_registry_pointers
# --------------------------------------------------------------------------

def _registry_entries(registry_path: str) -> tuple[list[dict], Path]:
    rp = Path(registry_path).expanduser()
    raw = json.loads(rp.read_text(encoding="utf-8"))
    if isinstance(raw, dict):
        entries = raw.get("entries", [])
    elif isinstance(raw, list):
        entries = raw
    else:
        raise ValueError("registry JSON must be an object with 'entries' or a bare list")
    return entries, rp


def check_registry_pointers(registry_path: str, base_dir: str | None = None) -> tuple[str, dict]:
    entries, rp = _registry_entries(registry_path)
    base = Path(base_dir).expanduser() if base_dir else rp.parent
    base_resolved = base.resolve()
    rows: list[dict] = []
    seen_ids: dict[str, int] = {}
    for e in entries:
        cid = str(e.get("claim_id", "?"))
        seen_ids[cid] = seen_ids.get(cid, 0) + 1
        script = str(e.get("script", ""))
        target = (base / script) if script else base / ""
        # Containment: pointers must resolve INSIDE the base dir. Absolute
        # paths and ../ traversal are registry defects, not pointers.
        escape = False
        try:
            resolved = target.resolve()
            escape = not resolved.is_relative_to(base_resolved)
        except Exception:
            escape = True
        exists = bool(script) and not escape and target.is_file()
        found = total = 0
        if exists and e.get("checks"):
            src = target.read_text(encoding="utf-8", errors="replace")
            words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9_]{4,}", str(e["checks"]))][:12]
            total = len(words)
            found = sum(1 for w in words
                        if re.search(r"\b" + re.escape(w) + r"\b", src))
        rows.append({"claim_id": cid, "script": script, "exists": exists,
                     "escape": escape,
                     "tokens_found": found, "tokens_total": total})
    n_missing = sum(1 for r in rows if not r["exists"])
    duplicates = {k: v for k, v in seen_ids.items() if v > 1}
    token_gaps = sum(1 for r in rows if r["tokens_total"] and r["tokens_found"] < r["tokens_total"])
    lines = [header(
        "check_registry_pointers",
        "registry integrity: every badged claim points at a script that checks its content",
        "existence of each pointed file, plus a DECLARED-CONTENT TOKEN HEURISTIC "
        "for entries that declare what they check",
        "registry JSON entries -> filesystem paths relative to the registry (or base_dir)",
        "the claim->script pointer structure and nothing else",
        "whether the pointed script's assertions actually range over the claim's "
        "content (full AST claim matching is NOT implemented in v1; the token "
        "overlap is a heuristic signal, not a fidelity verdict — M4 fidelity "
        "remains a deep-audit task)",
    ), f"registry: {rp}", f"base dir: {base}", f"entries: {len(rows)}", ""]
    for r in rows:
        if r["escape"]:
            lines.append(f"  [ESCAPE]  {r['claim_id']} -> {r['script']}  WITNESS: pointer resolves "
                         f"outside the base dir ({base_resolved}); absolute paths and traversal "
                         "are registry defects")
        elif r["exists"]:
            tok = ""
            if r["tokens_total"]:
                tok = (f"; declared-content tokens found {r['tokens_found']}/{r['tokens_total']} "
                       "(whole-word heuristic)")
                if r["tokens_found"] < r["tokens_total"]:
                    tok += "  [TOKEN GAP — declared content not fully reflected in the script]"
            lines.append(f"  [OK]      {r['claim_id']} -> {r['script']}" + tok)
        else:
            lines.append(f"  [MISSING] {r['claim_id']} -> {r['script']}  WITNESS: resolved path {base / r['script']} does not exist")
    for cid, n in duplicates.items():
        lines.append(f"  [DUPLICATE] claim_id {cid!r} appears {n} times  WITNESS: duplicate "
                     "claim identifiers are registry defects")
    if not rows or n_missing > 0 or duplicates:
        status = "FAIL"
    elif token_gaps:
        status = "PASS-WITH-WARNINGS"
    else:
        status = "PASS"
    lines.append(f"\nRESULT: {status} — {len(rows) - n_missing}/{len(rows)} pointed scripts exist "
                 f"({n_missing} missing/escaped); {len(duplicates)} duplicate claim_id(s); "
                 f"{token_gaps} token gap(s)")
    return "\n".join(lines) + "\n", {"status": status, "rows": rows,
                                     "n_missing": n_missing,
                                     "duplicates": duplicates,
                                     "token_gaps": token_gaps}


# --------------------------------------------------------------------------
# 3. lint_provenance
# --------------------------------------------------------------------------

_CLASS_RE = re.compile(
    r"^\s*#?\s*(paper-defined|cited-paper|cited-source|cited|control|"
    r"declared-assumption|arbitrary-representative)\s*:", re.M)
# The series also uses a per-binding bracket-tag style, e.g.
#   - Binary record, entries up/down   [paper-defined] Paper 12 S8
# Both styles are legitimate declarations; the lint reads both.
_CLASS_TAG_RE = re.compile(
    r"\[(paper-defined|cited-paper|cited-source|cited|control|"
    r"declared-assumption|arbitrary-representative)\]")

_PROV_HEADER = re.compile(r"INPUT_PROVENANCE\s*:")
_BLOCK_MAX_LINES = 200


def _docstrings(tree: ast.Module) -> list[str]:
    docs: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            doc = ast.get_docstring(node)
            if doc:
                docs.append(doc)
    return docs


def _comment_lines(text: str) -> list[str]:
    """Comment text (without the '#'), line by line, via the tokenizer —
    so '#' sequences inside string literals are NOT comments here."""
    import io
    import tokenize
    comments: dict[int, str] = {}
    try:
        toks = tokenize.generate_tokens(io.StringIO(text).readline)
        for tok in toks:
            if tok.type == tokenize.COMMENT:
                comments[tok.start[0]] = tok.string.lstrip("#")
    except Exception:
        return []
    if not comments:
        return []
    return [comments.get(i, "") for i in range(1, max(comments) + 1)]


def _block_from_lines(lines: list[str], stop_on_gap: bool = False) -> str | None:
    """Find the INPUT_PROVENANCE header in a candidate line list (comment
    lines or one docstring) and return the block: the header line plus the
    following lines of that same header region. For comment-derived lists,
    the region ends after two consecutive non-comment lines (the code has
    started) — the block is a bounded region of the header area, NOT a
    fixed-size window into the file body, so a binding's own assignment
    line later in the file can never 'classify' it by proximity."""
    for i, ln in enumerate(lines):
        if _PROV_HEADER.search(ln):
            out = [ln]
            gap = 0
            for nxt in lines[i + 1: i + 1 + _BLOCK_MAX_LINES]:
                if stop_on_gap:
                    if nxt.strip():
                        gap = 0
                    else:
                        gap += 1
                        if gap >= 2:
                            break
                out.append(nxt)
            return "\n".join(out)
    return None


def _provenance_block(text: str, tree: ast.Module | None) -> str | None:
    # Anchored search: the header counts only inside comments or
    # docstrings. A header string sitting in executable code (e.g. a
    # string constant) is data, not a declaration, and does not count.
    block = _block_from_lines(_comment_lines(text), stop_on_gap=True)
    if block is not None:
        return block
    if tree is not None:
        for doc in _docstrings(tree):
            block = _block_from_lines(doc.splitlines())
            if block is not None:
                return block
    return None


def _module_bindings(tree: ast.Module) -> list[str]:
    names: list[str] = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            value = node.value
            literalish = isinstance(value, (ast.Constant, ast.List, ast.Tuple,
                                            ast.Dict, ast.Set))
            if literalish:
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        names.append(t.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if isinstance(node.value, ast.Constant):
                names.append(node.target.id)
    return names


def lint_provenance(target: str) -> tuple[str, dict]:
    p = Path(target).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"lint target not found: {target}")
    files: list[Path] = []
    if p.is_dir():
        files = sorted(p.rglob("*.py"))
    elif p.is_file():
        files = [p]
    rows: list[dict] = []
    for f in files:
        text = f.read_text(encoding="utf-8", errors="replace")
        parse_error = None
        tree = None
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            parse_error = str(exc)
        block = _provenance_block(text, tree) if parse_error is None else None
        classes = (sorted(set(_CLASS_RE.findall(block))
                          | set(_CLASS_TAG_RE.findall(block)))
                   if block else [])
        bindings = _module_bindings(tree) if tree is not None else []
        unclassified = []
        if block:
            for name in bindings:
                if name not in block:
                    unclassified.append(name)
        rows.append({"file": str(f), "name": f.name, "has_block": block is not None,
                     "classes": classes, "bindings": bindings,
                     "unclassified": unclassified, "parse_error": parse_error})
    n_block = sum(1 for r in rows if r["has_block"])
    n_uncl = sum(len(r["unclassified"]) for r in rows)
    n_zero_class = sum(1 for r in rows if r["has_block"] and not r["classes"])
    lines = [header(
        "lint_provenance",
        "premise/provenance completeness of the named scripts (PROV-COMPLETE)",
        "presence of INPUT_PROVENANCE blocks (header anchored in comments or "
        "docstrings only), the provenance classes declared in them, and "
        "module-level literal bindings whose names do not appear in the "
        "block — a HEURISTIC scan",
        "script source -> comment/docstring extraction + AST scan of "
        "top-level literal assignments",
        "block presence, declared class labels, and name-level coverage",
        "whether a binding that IS named in the block is classified CORRECTLY; "
        "bindings built by expressions, function calls, or imports (not literal "
        "top-level assignments) are outside this scan; premise soundness. "
        "'Unclassified' below means 'not detected as classified by this "
        "heuristic', not 'proven unclassified'",
    ), f"target: {p}", f"scripts scanned: {len(rows)}", ""]
    for r in rows:
        if r["parse_error"]:
            lines.append(f"  [PARSE ERROR] {r['name']}  WITNESS: file does not parse "
                         f"({r['parse_error']}); it cannot be audited by this scan")
        elif not r["has_block"]:
            lines.append(f"  [NO BLOCK] {r['name']}  WITNESS: no INPUT_PROVENANCE header "
                         "detected in the file's comments or docstrings")
        else:
            lines.append(f"  [BLOCK]    {r['name']} — classes detected: {', '.join(r['classes']) or '(none parsed)'}; "
                         f"literal bindings: {len(r['bindings'])}; not detected in block: "
                         f"{', '.join(r['unclassified']) if r['unclassified'] else '(none)'}")
    if not rows:
        status = "FAIL"
    elif n_block < len(rows):
        status = "FAIL"
    elif n_uncl > 0 or n_zero_class > 0:
        status = "PASS-WITH-WARNINGS"
    else:
        status = "PASS"
    lines.append(f"\nRESULT: {status} — blocks detected in {n_block}/{len(rows)} scripts; "
                 f"{n_uncl} literal binding(s) not detected as classified (heuristic); "
                 f"{n_zero_class} block(s) with zero classes parsed")
    data = {"status": status, "rows": rows, "n_with_block": n_block,
            "n_scripts": len(rows), "n_unclassified": n_uncl,
            "n_zero_class": n_zero_class}
    return "\n".join(lines) + "\n", data

# --------------------------------------------------------------------------
# 4. param_prov — parameter provenance bookkeeping (verdict guard built in)
# --------------------------------------------------------------------------

_PARAM_CLASSES = [
    "derived-from-structure", "measured-input", "fitted",
    "declared-assumption", "arbitrary-representative",
    "paper-defined", "cited-source", "control", "unknown",
]

# Verdict-injection patterns: comparative conclusions drawn from totals.
# The guard scans the table's ENTIRE raw text (keys and values, after
# zero-width-character stripping) plus every parsed string, because the
# tool echoes the convention and entry names verbatim — a verdict riding
# in any of them would be printed by the tool itself under a PASS stamp.
# This remains a tripwire over known phrasings, NOT a semantic guarantee:
# verdicts encoded purely numerically, in other languages, or in
# vocabulary with no comparative marker can evade it. That limit is stated
# in the tool's disclosure and in the README; the substantive rule is the
# freeze's banned-constructions rule on human-written reports.
_VERDICT_PATTERNS = [
    re.compile(r"\btherefore\b[^.\n]{0,120}\b(preferab|superior|better|more honest|wins?|defeat|condemn)", re.I),
    re.compile(r"\b(is|are|proves?|demonstrates?|shows?|establishes?)\b[^.\n]{0,80}\b(more honest|superior|preferable|better)\b", re.I),
    re.compile(r"\bmachine-verified superiority\b", re.I),
    re.compile(r"\bfewer parameters\b[^.\n]{0,80}\b(therefore|so|hence|thus)\b", re.I),
    re.compile(r"\b(sm|standard model)\s+fails verification\b", re.I),
    re.compile(r"\bmore honest than\b", re.I),
    re.compile(r"\bsuperiority of\b", re.I),
    re.compile(r"\b\w+\s+(wins|beats|triumphs)\b", re.I),
    re.compile(r"\bcondemned by (the|these|those)\s+(checks|counts|numbers|results)\b", re.I),
    re.compile(r"\bhence\b[^.\n]{0,80}\b(superior|preferab|more honest)\b", re.I),
]
_ZWSP = dict.fromkeys([0x200B, 0x200C, 0x200D, 0xFEFF], None)


def _scan_text(s: str) -> str:
    return s.translate(_ZWSP)


def _all_strings(obj, prefix=""):
    if isinstance(obj, str):
        yield prefix, obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield from _all_strings(str(k), f"{prefix}.<key>" if prefix else "<key>")
            yield from _all_strings(v, f"{prefix}.{k}" if prefix else str(k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _all_strings(v, f"{prefix}[{i}]")


def param_prov(table_path: str) -> tuple[str, dict]:
    tp = Path(table_path).expanduser()
    raw_text = tp.read_text(encoding="utf-8")
    table = json.loads(raw_text)

    head = header(
        "param_prov",
        "free-parameter provenance accounting for the named table (PARAM-PROV)",
        "classification of the table's entries per provenance class under the "
        "table's OWN named counting convention, and counts per class",
        "JSON parameter table -> class validation + counting",
        "provenance structure of the declared entries, with the convention attached",
        "whether fewer or differently-classed inputs is a virtue (a theory-choice "
        "judgement, not bookkeeping); empirical adequacy; any total computed "
        "under a different convention. A count match or count advantage "
        "establishes nothing (FREEZE v1.0 \u00a72). The verdict guard is a "
        "tripwire over known phrasings (listed in the source), not a semantic "
        "guarantee: verdicts encoded purely numerically, in other languages, "
        "or without comparative vocabulary can evade it and are outside this "
        "check — the substantive rule is the freeze's banned-constructions "
        "rule on human-written reports",
    )

    # --- verdict-injection guard: scan the raw text and every string ------
    scan_targets = [("<raw file text>", _scan_text(raw_text))]
    scan_targets += [(where, _scan_text(s)) for where, s in _all_strings(table)]
    for where, s in scan_targets:
        for pat in _VERDICT_PATTERNS:
            if pat.search(s):
                lines = [head, f"table: {tp}", "",
                         "RESULT: REFUSED — verdict-injection detected (FREEZE v1.0 \u00a76 guard).",
                         f"WITNESS: field '{where}' contains: {s!r}",
                         f"matched pattern: {pat.pattern}",
                         "This tool classifies entries and prints counts per class under a",
                         "named convention. It does not emit comparative verdicts from totals.",
                         "Remove the verdict language and re-run for bookkeeping output."]
                return "\n".join(lines) + "\n", {"status": "REFUSED", "witness_field": where,
                                                 "witness_text": s}
    convention = table.get("convention")
    entries = table.get("entries", [])
    if not isinstance(convention, str) or not convention.strip():
        lines = [head, f"table: {tp}", "",
                 "RESULT: REFUSED — no counting convention named in the table.",
                 "WITNESS: field 'convention' is missing, empty, or not a string. A naked total without",
                 "its convention is a banned construction (FREEZE v1.0 \u00a75); name the",
                 "convention and re-run."]
        return "\n".join(lines) + "\n", {"status": "REFUSED", "witness_field": "convention",
                                         "witness_text": None}
    if not entries:
        lines = [head, f"table: {tp}", f"counting convention: {convention}", "",
                 "RESULT: FAIL — the table declares zero entries; nothing was "
                 "classified and a vacuous PASS is not emitted."]
        return "\n".join(lines) + "\n", {"status": "FAIL", "convention": convention,
                                         "counts": {}, "entries": []}
    counts: dict[str, int] = {}
    bad: list[str] = []
    rows = []
    for e in entries:
        name = str(e.get("name", "?"))
        cls = str(e.get("class", "unknown"))
        if cls not in _PARAM_CLASSES:
            bad.append(f"{name}: class {cls!r} not in the v1.0 class list")
            cls = "unknown"
        counts[cls] = counts.get(cls, 0) + 1
        rows.append((name, cls))
    lines = [head, f"table: {tp}", f"counting convention: {convention}",
             f"entries: {len(rows)}", "", "per-entry classification:"]
    for name, cls in rows:
        lines.append(f"  {name}: {cls}")
    lines.append("\ncounts per provenance class (under the convention named above):")
    for cls in _PARAM_CLASSES:
        if counts.get(cls):
            lines.append(f"  {cls}: {counts[cls]}")
    if bad:
        lines.append("\nclass warnings (counted as 'unknown'):")
        for b in bad:
            lines.append(f"  {b}")
    lines.append("\nGUARD: no comparative verdict is emitted from these totals "
                 "(FREEZE v1.0 \u00a72, \u00a76). Totals are bookkeeping under the named "
                 "convention only; counts change under other conventions — re-run "
                 "under each convention and report side by side.")
    status = "PASS" if not bad else "PASS-WITH-WARNINGS"
    lines.append(f"\nRESULT: {status} — {len(rows)} entries classified under convention {convention!r}")
    return "\n".join(lines) + "\n", {"status": status, "convention": convention,
                                     "counts": counts, "entries": rows}


# --------------------------------------------------------------------------
# 5. fence_and_listing_check
# --------------------------------------------------------------------------

_FENCE = re.compile(r"^\s*(`{3,})[^`]*$")
_FUSED_END = re.compile(r"```\s*$")


def _fence_map(raw_lines: list[str]) -> tuple[list[tuple[int, int]], list[int], bool]:
    """Pair fence lines into blocks. A fence is a line of >=3 backticks
    (optional info string, no further backticks). A block opened with n
    backticks closes at the next fence line with >= n backticks (the
    markdown rule, which also handles four-backtick wrappers around
    ```-containing scripts). Returns (blocks[(start_idx, end_idx)],
    unpaired_fence_indices, all_paired)."""
    blocks: list[tuple[int, int]] = []
    unpaired: list[int] = []
    open_idx: int | None = None
    open_ticks = 0
    for i, ln in enumerate(raw_lines):
        m = _FENCE.match(ln)
        if not m:
            continue
        ticks = len(m.group(1))
        if open_idx is None:
            open_idx, open_ticks = i, ticks
        elif ticks >= open_ticks:
            blocks.append((open_idx, i))
            open_idx = None
        else:
            unpaired.append(i)  # shorter fence inside a longer block: content
    if open_idx is not None:
        unpaired.append(open_idx)
    return blocks, unpaired, open_idx is None


def fence_and_listing_check(md_path: str, files_dir: str) -> tuple[str, dict]:
    mp = Path(md_path).expanduser()
    fd = Path(files_dir).expanduser()
    # read as bytes and decode manually: universal-newline translation
    # would silently erase the CRLF/LF distinction the match KIND reports
    text = mp.read_bytes().decode("utf-8", errors="replace")
    paper_crlf = "\r\n" in text
    raw_lines = text.splitlines()

    blocks_idx, unpaired, parity_ok = _fence_map(raw_lines)
    blocks: list[tuple[int, str]] = [(s + 1, "\n".join(raw_lines[s + 1:e]))
                                    for s, e in blocks_idx]
    in_block: set[int] = set()
    for s, e in blocks_idx:
        in_block.update(range(s, e + 1))

    # Glued/fused-fence suspects: a NON-fence line ENDING in ``` — the
    # signature of a closing fence fused onto a code line (the Paper 11
    # fence-glue corruption class), including the double-glue case where
    # total parity stays even. Lines merely CONTAINING ``` inside code
    # (e.g. a script's own fence-scanning string literals, which sit
    # mid-line) are not suspects.
    glued = [(i + 1, ln) for i, ln in enumerate(raw_lines)
             if _FUSED_END.search(ln) and not _FENCE.match(ln)]

    if fd.is_dir():
        candidates = sorted(fd.rglob("*.py"))
    else:
        candidates = [fd]

    def _norm(s: str) -> str:
        return s.replace("\r\n", "\n").strip()

    file_texts: list[tuple[str, str, bool]] = [
        (str(f), f.read_bytes().decode("utf-8", errors="replace"),
         "\r\n" in f.read_bytes().decode("utf-8", errors="replace"))
        for f in candidates]

    # markers: the first block-content line unique across ALL blocks;
    # falls back to a short content hash (shared header lines identify
    # nothing and are never used as the sole witness).
    line_counts: dict[str, int] = {}
    for _ln0, content in blocks:
        for ln in set(content.splitlines()):
            if ln.strip():
                line_counts[ln] = line_counts.get(ln, 0) + 1

    matched = 0
    n_exact = 0
    block_rows = []
    for start_line, content in blocks:
        exact_hits, norm_hits = [], []
        for fname, ftext, file_crlf in file_texts:
            if (content + "\n" == ftext or content == ftext) and paper_crlf == file_crlf:
                exact_hits.append(fname)
            elif _norm(content) == _norm(ftext):
                norm_hits.append(fname)
        hits = exact_hits or norm_hits
        kind = "EXACT" if exact_hits else ("NORMALIZED" if norm_hits else None)
        marker = next((ln for ln in content.splitlines()
                       if ln.strip() and line_counts.get(ln, 0) == 1), None)
        digest = hashlib.sha256(content.encode()).hexdigest()[:12]
        block_rows.append({"start_line": start_line, "marker": marker,
                           "sha": digest, "matched_files": hits, "kind": kind})
        if hits:
            matched += 1
            if kind == "EXACT":
                n_exact += 1

    lines = [header(
        "fence_and_listing_check",
        "identity between the paper's embedded listings and the standalone "
        "script files, plus fence integrity (BYTE-REPRO)",
        "fence pairing (>=3-backtick fences, markdown closing rule) and "
        "fused-fence scan over the named markdown file; content matching of "
        "each fenced block against the named files — matched by CONTENT, "
        "never by position or shared header lines",
        "markdown text -> fence map + per-block content comparison",
        "per-block identity with its KIND printed: EXACT (byte-identical up "
        "to one trailing newline) or NORMALIZED (equal only after "
        "whole-block leading/trailing-whitespace and line-ending "
        "normalization); fence structure; fused-fence suspects",
        "blocks that are not script listings (examples, shell snippets) "
        "report as unmatched and require human classification; whether the "
        "prose AROUND the listings describes them accurately; fused fences "
        "whose corruption leaves no line ending in ``` (a stated residual)",
    ), f"markdown: {mp}", f"files dir: {fd}",
       f"fence blocks paired: {len(blocks)}; unpaired fence lines: {len(unpaired)} "
       f"(parity {'OK' if parity_ok else 'BROKEN — FAIL'})", ""]
    for ln_no, ln in glued:
        lines.append(f"  [FUSED FENCE SUSPECT] line {ln_no}: {ln[:120]!r}  "
                     "WITNESS: non-fence line ending in ``` — a closing fence "
                     "fused onto code text")
    if not parity_ok:
        lines.append(f"  [PARITY FAIL] unpaired fence line(s) at: "
                     f"{', '.join(str(i + 1) for i in unpaired)}")
    lines.append(f"fenced blocks: {len(blocks)}; matched to a file by content: "
                 f"{matched} (EXACT: {n_exact}, NORMALIZED: {matched - n_exact})")
    for b in block_rows:
        ident = (f"marker: {b['marker'][:80]!r}" if b["marker"]
                 else f"no unique line; block sha {b['sha']}")
        if b["matched_files"]:
            files_str = ", ".join(b["matched_files"])
            amb = "  [AMBIGUOUS: multiple identical files]" if len(b["matched_files"]) > 1 else ""
            lines.append(f"  [MATCH-{b['kind']}] block at line {b['start_line']} -> {files_str}  ({ident}){amb}")
        else:
            lines.append(f"  [UNMATCHED] block at line {b['start_line']}  ({ident}) — not identical "
                         "to any file in the dir, exactly or normalized (human classification required)")
    if not parity_ok or glued:
        status = "FAIL"
    elif not blocks or matched == 0:
        status = "FAIL"
    elif matched < len(blocks):
        status = "PASS-WITH-WARNINGS"
    else:
        status = "PASS"
    lines.append(f"\nRESULT: {status} — fence parity {'OK' if parity_ok else 'BROKEN'}; "
                 f"{len(glued)} fused-fence suspect(s); {matched}/{len(blocks)} blocks matched "
                 f"by content (EXACT {n_exact}, NORMALIZED {matched - n_exact})")
    data = {"status": status, "fence_blocks": len(blocks),
            "parity_ok": parity_ok, "unpaired": [i + 1 for i in unpaired],
            "glued": [(n, l) for n, l in glued], "blocks": block_rows,
            "n_blocks": len(blocks), "n_matched": matched, "n_exact": n_exact}
    return "\n".join(lines) + "\n", data

# --------------------------------------------------------------------------
# 6. audit_dashboard
# --------------------------------------------------------------------------

def audit_dashboard(package_path: str, registry_path: str | None = None,
                    param_table: str | None = None,
                    run_suite: bool = False) -> tuple[str, dict]:
    root, tmp = _resolve_package(package_path)
    try:
        scripts_dir = _find_scripts_dir(root)
        paper = _find_paper(root)
        sections: list[tuple[str, str, dict]] = []

        if scripts_dir is not None:
            sections.append(("lint_provenance", *lint_provenance(str(scripts_dir))))
        else:
            skip_text = header(
                "lint_provenance (dashboard)",
                "premise/provenance completeness of the package's scripts",
                "nothing — no scripts directory detected in this package",
                "package path -> filesystem scan",
                "nothing",
                "everything about provenance in this package; the check did not run",
            ) + "\nRESULT: SKIP — no scripts detected.\n"
            sections.append(("lint_provenance", skip_text, {"status": "SKIP"}))

        if registry_path:
            sections.append(("check_registry_pointers",
                             *check_registry_pointers(registry_path, base_dir=str(root))))
        if paper is not None and scripts_dir is not None:
            sections.append(("fence_and_listing_check",
                             *fence_and_listing_check(str(paper), str(scripts_dir))))
        if param_table:
            sections.append(("param_prov", *param_prov(param_table)))
        if run_suite:
            sections.append(("run_verification_suite",
                             *run_verification_suite(package_path)))

        lines = [header(
            "audit_dashboard",
            "the comparative honesty dashboard for the named package",
            "the assembled outputs of the mechanical checks actually run, below; "
            "each keeps its own disclosure and its own verified domain",
            "package -> per-check tool runs -> per-check dashboard lines",
            "per-check counts exactly as each tool established them",
            "metrics M1–M5 (human-coding metrics — NOT scored by this instrument); "
            "any check not listed below was NOT run; empirical truth and every "
            "comparative conclusion. INPUT CONTRACTS: every input this "
            "instrument consumes is a house format (RB1-style runner tuples, "
            "INPUT_PROVENANCE blocks, this project's JSON schemas) — a corpus "
            "not already in those formats cannot be fed without a translation "
            "step that is itself unaudited (README: 'Input contracts')",
        ), f"package root: {root}", "",
            "DASHBOARD (per-check lines with counts; NO composite index is computed — FREEZE v1.0 \u00a73):"]
        summary = {}
        counts = {}
        for name, _text, data in sections:
            summary[name] = data.get("status", "?")
            if name == "lint_provenance":
                counts[name] = (f"{data.get('n_with_block', '?')}/{data.get('n_scripts', '?')} "
                                f"blocks, {data.get('n_unclassified', '?')} unclassified")
            elif name == "check_registry_pointers":
                counts[name] = f"{data.get('n_missing', '?')} missing of {len(data.get('rows', []))}"
            elif name == "fence_and_listing_check":
                counts[name] = (f"{data.get('n_matched', '?')}/{data.get('n_blocks', '?')} "
                                "blocks matched")
            elif name == "param_prov":
                counts[name] = f"{len(data.get('entries', []))} entries"
            elif name == "run_verification_suite":
                counts[name] = f"{data.get('n_pass', '?')}/{data.get('n_total', '?')} scripts"
            c = f"  [{counts[name]}]" if name in counts else ""
            lines.append(f"  {name}: {data.get('status', '?')}{c}")
        if not run_suite:
            lines.append("  run_verification_suite: NOT RUN in this dashboard "
                         "(re-run with run_suite=true to include it)")
        lines.append("\n----- full per-check reports -----\n")
        for name, text, _data in sections:
            lines.append(f"===== {name} =====\n{text}")
        bad = [n for n, s in summary.items() if s in ("FAIL", "REFUSED", "ERROR")]
        overall = "ASSEMBLED-WITH-FAILURES" if bad else "ASSEMBLED"
        if bad:
            lines.append(f"OVERALL: ASSEMBLED-WITH-FAILURES — failing constituent(s): "
                         f"{', '.join(bad)}. The dashboard does not flatten these into a pass.")
        return "\n".join(lines) + "\n", {"status": overall, "checks": summary,
                                         "counts": counts}
    finally:
        if tmp is not None:
            tmp.cleanup()


# --------------------------------------------------------------------------
# 7. validate_cards — claim-card validator (Annex v1.1 §A7)
# --------------------------------------------------------------------------

_CARD_FIELDS = [
    "card_id", "source_id", "quote", "location", "layer", "claim",
    "premises", "freedoms", "evidence", "bridges", "falsifier", "scope",
    "era_note", "carder",
]
_CARD_LAYERS = {"state-space", "measure", "dynamics", "statistics",
                "interpretation"}
_CARD_STRING_FIELDS = ["card_id", "source_id", "quote", "location", "claim",
                       "era_note", "carder"]

# Banned constructions for the claim field ONLY (FREEZE v1.0 §5, applied to
# the carder's own text per Annex §A7 check 5; the verbatim quote is NEVER
# scanned — the discipline binds the carder, not the source). The scan
# strips zero-width characters and collapses whitespace before matching,
# case-insensitively — the same tripwire discipline as param_prov's guard.
# It is a tripwire over these phrasings, not a semantic guarantee.
_CARD_BANNED = [
    "more honest than",
    "machine-verified superiority",
    "fails verification",
    "condemned by the checks",
    "proves that the ledger",
    "demonstrates that the ledger",
    "establishes that the ledger",
]


def _normalise_span(s: str) -> str:
    """Annex A2.1 normalisation, applied to source text and quote alike:
    hyphenation-at-line-break sequences ("-\\n", "-\\r\\n") are removed,
    then every whitespace run collapses to one space and the result is
    stripped. Nothing else is normalised — words, punctuation and notation
    must match exactly after that."""
    s = s.replace("-\r\n", "").replace("-\n", "")
    return re.sub(r"\s+", " ", s).strip()


def _is_none_form(v) -> bool:
    # v1.1.2 (Paper 12.5 v4 loop, RT4-2): the reason must carry substance —
    # at least one alphanumeric character — not punctuation alone.
    return (isinstance(v, dict) and v.get("none") is True
            and isinstance(v.get("reason"), str)
            and bool(re.search(r"[A-Za-z0-9]", v["reason"])))


def _is_string_list(v) -> bool:
    return (isinstance(v, list) and len(v) > 0
            and all(isinstance(x, str) and bool(x.strip()) for x in v))


_ERA_NOTE_PLACEHOLDERS = {"n/a", "na", "n.a.", "none", "-", "—"}
_CARDER_PLACEHOLDERS = {"anonymous", "anon", "unknown"}
_EVIDENCE_NONE_RE = re.compile(r"^none\s*([—–\-:])\s*(.*)$", re.I | re.S)


def _scan_claim(claim: str) -> list[str]:
    # v1.1.1 (EA-2): apply the SAME de-hyphenation as quote normalisation
    # (_normalise_span removes hyphen+newline sequences) before scanning,
    # so a banned phrase split at a line break is still caught. A
    # hyphen+newline at a word boundary reconstructs with a space instead
    # of without one (e.g. "more honest-\nthan"), so that reconstruction
    # is scanned as well; a phrase found under either reconstruction is
    # detected. Both variants also strip zero-width characters and
    # collapse whitespace, case-insensitively.
    raw = _scan_text(claim)
    cleaned = _normalise_span(raw).lower()
    spaced = re.sub(r"\s+", " ",
                    raw.replace("-\r\n", " ").replace("-\n", " ")
                    ).strip().lower()
    return [p for p in _CARD_BANNED if p in cleaned or p in spaced]


def validate_cards(cards_path: str, sources_dir: str,
                   sources_manifest: str | None = None) -> tuple[str, dict]:
    cp = Path(cards_path).expanduser()
    sd = Path(sources_dir).expanduser()
    raw = json.loads(cp.read_text(encoding="utf-8"))

    head = header_cards(
        "validate_cards",
        "fidelity of this card set to its named sources and the Annex A1 schema",
        "schema completeness, verbatim span presence after whitespace/hyphenation normalisation, layer-taxonomy membership, duplicate-id absence, and the banned-construction tripwire over claim fields \u2014 over the named files only",
        "cards JSON -> per-card field checks + normalised substring search in the source files named by the sources manifest",
        "the quote-source link and card-field discipline for every accepted card",
        "semantic support beyond lexical span presence; premise truth; layer correctness (only taxonomy membership is checked); location correctness (only membership in the named source file is checked, never position within it); card-set completeness for its source; era fairness of judgements",
    )

    sources_map: dict = {}
    cards: list | None = None
    if isinstance(raw, list):
        cards = raw
    elif isinstance(raw, dict) and isinstance(raw.get("cards"), list):
        cards = raw["cards"]
        if isinstance(raw.get("sources"), dict):
            sources_map = raw["sources"]
    if cards is None:
        text = "\n".join([head, f"cards file: {cp}", f"sources dir: {sd}", "",
                          "RESULT: FAIL \u2014 the cards file is neither a list of "
                          "cards nor an object with a 'cards' list; zero cards "
                          "were validated and a vacuous PASS is not emitted."]) + "\n"
        return text, {"status": "FAIL", "n_cards": 0, "n_ok": 0, "rejected": []}

    # (R5 / RT-6) duplicate detection compares whitespace-STRIPPED ids;
    # case-sensitivity is retained deliberately.
    id_counts: dict[str, int] = {}
    for c in cards:
        if isinstance(c, dict) and isinstance(c.get("card_id"), str):
            key = c["card_id"].strip()
            id_counts[key] = id_counts.get(key, 0) + 1

    # (R6 / EA-1, RT-5) sources binding: resolve each distinct source_id
    # once, in first-appearance order, and record its file's sha256 and
    # size so the output can print a SOURCE line per resolved source.
    # A source_id absent from the cards file's sources map resolves by
    # the {source_id}.txt FALLBACK, flagged as such.
    source_info: dict[str, dict] = {}
    source_order: list[str] = []
    for c in cards:
        if not isinstance(c, dict):
            continue
        sid = c.get("source_id")
        if not (isinstance(sid, str) and sid.strip()) or sid in source_info:
            continue
        if sid in sources_map:
            fname = str(sources_map[sid])
            fallback = False
        else:
            fname = f"{sid}.txt"
            fallback = True
        spath = sd / fname
        info: dict = {"source_id": sid, "filename": fname,
                      "path": spath, "fallback": fallback,
                      "resolved": spath.is_file(),
                      "sha256": None, "bytes": None}
        if info["resolved"]:
            data_bytes = spath.read_bytes()
            info["sha256"] = hashlib.sha256(data_bytes).hexdigest()
            info["bytes"] = len(data_bytes)
        source_info[sid] = info
        source_order.append(sid)

    # (R6c) optional sources-manifest verification: a sha256sum-format
    # file ("<sha256>  <basename>" per line). When provided, each
    # resolved source file's sha256 must equal the manifest entry for
    # its basename; a mismatch or a missing entry rejects every card
    # of that source, with expected/actual hashes as witness.
    manifest_map: dict[str, str] | None = None
    manifest_path: Path | None = None
    manifest_failures: dict[str, str] = {}
    manifest_verified = False
    if sources_manifest is not None:
        manifest_path = Path(sources_manifest).expanduser()
        if not manifest_path.is_file():
            raise FileNotFoundError(
                f"sources manifest not found: {sources_manifest}")
        manifest_map = {}
        for ln in manifest_path.read_text(
                encoding="utf-8", errors="replace").splitlines():
            parts = ln.split()
            if len(parts) >= 2:
                manifest_map[Path(parts[1].lstrip("*")).name] = \
                    parts[0].lower()
        manifest_verified = bool(source_order)
        for sid in source_order:
            info = source_info[sid]
            if not info["resolved"]:
                manifest_verified = False
                continue
            basename = Path(info["filename"]).name
            expected = manifest_map.get(basename)
            actual = info["sha256"]
            if expected is None:
                manifest_verified = False
                manifest_failures[sid] = (
                    f"sources manifest has no entry for {basename!r}; "
                    f"expected sha256 (missing entry), actual sha256 "
                    f"{actual}  WITNESS: source {sid!r} file "
                    f"{info['filename']}")
            elif expected != actual:
                manifest_verified = False
                manifest_failures[sid] = (
                    f"sources manifest sha256 mismatch for source "
                    f"{sid!r} (file {info['filename']}): expected "
                    f"sha256 {expected}, actual sha256 {actual}  "
                    f"WITNESS: expected {expected} != actual {actual}")

    source_cache: dict[str, str | None] = {}

    def _source_norm_text(path: Path) -> str | None:
        key = str(path)
        if key not in source_cache:
            try:
                source_cache[key] = _normalise_span(
                    path.read_text(encoding="utf-8", errors="replace"))
            except OSError:
                source_cache[key] = None
        return source_cache[key]

    rows: list[tuple[str, list[str], str | None]] = []
    rejected: list[dict] = []
    for i, card in enumerate(cards):
        reasons: list[str] = []
        span_witness: str | None = None
        if not isinstance(card, dict):
            cid = f"<card {i}>"
            reasons.append(f"card is not a JSON object (got {type(card).__name__})")
            rows.append((cid, reasons, span_witness))
            rejected.append({"card_id": cid, "reasons": reasons})
            continue
        cid_raw = card.get("card_id")
        cid = cid_raw if isinstance(cid_raw, str) and cid_raw.strip() else f"<card {i}>"

        # (a) schema completeness: all 14 Annex A1 fields present
        missing = [f for f in _CARD_FIELDS if f not in card]
        if missing:
            reasons.append("missing field(s): " + ", ".join(missing))
        for f in _CARD_STRING_FIELDS:
            if f in card and not (isinstance(card[f], str) and card[f].strip()):
                reasons.append(f"{f}: not a non-empty string")

        # (R2 / EA-4, RT-4) placeholder era_notes and anonymous carders
        # are not admitted (Annex A1: 'n/a' is not an era note;
        # anonymous cards are not admitted).
        if isinstance(card.get("era_note"), str) and \
                card["era_note"].strip().lower() in _ERA_NOTE_PLACEHOLDERS:
            reasons.append(f"era_note {card['era_note']!r} is not an era "
                           "note (Annex A1 placeholder, rejected)  "
                           f"WITNESS: era_note={card['era_note']!r}")
        if isinstance(card.get("carder"), str) and \
                card["carder"].strip().lower() in _CARDER_PLACEHOLDERS:
            reasons.append(f"carder {card['carder']!r}: anonymous cards "
                           "are not admitted (Annex A1)  "
                           f"WITNESS: carder={card['carder']!r}")

        # (b) layer taxonomy membership
        if "layer" in card and card["layer"] not in _CARD_LAYERS:
            reasons.append(f"layer {card['layer']!r} not in the Annex A1 taxonomy "
                           "(state-space, measure, dynamics, statistics, interpretation)")

        # (c) field forms: content form or NONE-form, per field
        for f in ("premises", "freedoms"):
            if f in card and not (_is_none_form(card[f]) or _is_string_list(card[f])):
                reasons.append(f"{f}: neither a list of non-empty strings nor a "
                               'NONE-form object ({"none": true, "reason": ...})')
        for f in ("falsifier", "scope"):
            if f in card and not (_is_none_form(card[f])
                                  or (isinstance(card[f], str) and card[f].strip())):
                reasons.append(f"{f}: neither a non-empty string nor a NONE-form "
                               'object ({"none": true, "reason": ...})')
        if "evidence" in card and not (isinstance(card["evidence"], str)
                                        and card["evidence"].strip()):
            reasons.append("evidence: not a non-empty string")
        elif isinstance(card.get("evidence"), str):
            # (R4 / EA-6) an evidence value beginning with NONE must be
            # NONE + separator (—, –, - or :) + a non-empty reason; a
            # bare NONE, or NONE + punctuation only, is rejected.
            ev = card["evidence"].strip()
            if ev.lower().startswith("none"):
                m = _EVIDENCE_NONE_RE.match(ev)
                reason_part = m.group(2).strip() if m else ""
                if not (m and any(ch.isalnum() for ch in reason_part)):
                    reasons.append(
                        "evidence: begins with NONE but is not in the "
                        "form 'NONE <separator> <reason>' (separator one "
                        "of —, –, -, :) with a non-empty reason  "
                        f"WITNESS: evidence={ev!r}")
        if "bridges" in card:
            b = card["bridges"]
            if not isinstance(b, list):
                reasons.append("bridges: not a list")
            else:
                for j, entry in enumerate(b):
                    if not isinstance(entry, dict):
                        reasons.append(f"bridges[{j}]: not an object")
                        continue
                    if entry.get("from_layer") not in _CARD_LAYERS:
                        reasons.append(f"bridges[{j}]: from_layer "
                                       f"{entry.get('from_layer')!r} not in the "
                                       "Annex A1 taxonomy")
                    if entry.get("to_layer") not in _CARD_LAYERS:
                        reasons.append(f"bridges[{j}]: to_layer "
                                       f"{entry.get('to_layer')!r} not in the "
                                       "Annex A1 taxonomy")
                    if not isinstance(entry.get("declared"), bool):
                        reasons.append(f"bridges[{j}]: declared is not a bool")
                    if not (isinstance(entry.get("support"), str)
                            and entry["support"].strip()):
                        reasons.append(f"bridges[{j}]: support is not a "
                                       "non-empty string")

        # (f) duplicate identity (R5: whitespace-stripped comparison,
        # case-sensitivity retained)
        if isinstance(cid_raw, str) and id_counts.get(cid_raw.strip(), 0) > 1:
            reasons.append(f"duplicate card_id {cid_raw.strip()!r} (appears "
                           f"{id_counts[cid_raw.strip()]} times in the set, "
                           "comparing whitespace-stripped ids)")

        # (R6c) sources-manifest failure rejects every card of the source
        sid_for_manifest = card.get("source_id")
        if isinstance(sid_for_manifest, str) \
                and sid_for_manifest in manifest_failures:
            reasons.append(manifest_failures[sid_for_manifest])

        # (e) banned constructions in the claim field only (never the quote)
        if isinstance(card.get("claim"), str):
            for phrase in _scan_claim(card["claim"]):
                reasons.append(f"banned construction detected in claim field: "
                               f"{phrase!r} (FREEZE v1.0 \u00a75; Annex \u00a7A7 check 5)")

        # (d) span traceability: quote found verbatim (normalised) in source
        sid = card.get("source_id")
        quote = card.get("quote")
        if (isinstance(sid, str) and sid.strip()
                and isinstance(quote, str) and quote.strip()):
            fname = sources_map.get(sid) if sources_map else None
            if fname is None:
                fname = f"{sid}.txt"
            attempted = sd / str(fname)
            norm_src = _source_norm_text(attempted) if attempted.is_file() else None
            if norm_src is None:
                reasons.append(f"source {sid!r} does not resolve to a file; "
                               f"attempted path: {attempted}")
            elif _normalise_span(quote) not in norm_src:
                reasons.append("quote not found verbatim (after "
                               "whitespace/hyphenation normalisation) in the "
                               "named source")
                span_witness = quote[:120]

        rows.append((cid, reasons, span_witness))
        if reasons:
            rejected.append({"card_id": cid, "reasons": reasons})

    lines = [head, f"cards file: {cp}", f"sources dir: {sd}",
             f"cards in set: {len(cards)}"]
    if manifest_path is not None:
        if manifest_verified:
            lines.append(f"sources manifest: {manifest_path} (verified)")
        else:
            lines.append(f"sources manifest: {manifest_path} "
                         "(VERIFICATION FAILED — see per-card rejections)")
    # (R6a/b) one SOURCE line per resolved source, before the per-card
    # lines; fallback resolutions are prefixed SOURCE-FALLBACK and carry
    # a warning sentence.
    for sid in source_order:
        info = source_info[sid]
        if not info["resolved"]:
            continue
        src_line = (f"SOURCE {sid} -> {info['filename']} "
                    f"sha256 {info['sha256']} ({info['bytes']} bytes)")
        if info["fallback"]:
            lines.append(f"SOURCE-FALLBACK {src_line}")
            lines.append(
                f"WARNING: source {sid!r} was resolved by the "
                f"{{{sid}}}.txt fallback — the fallback is a guess, "
                "not a manifest resolution.")
        else:
            lines.append(src_line)
    lines.append("")
    for cid, reasons, span_witness in rows:
        if reasons:
            line = f"  [REJECT] {cid} \u2014 " + "; ".join(reasons)
            if span_witness is not None:
                line += f"  WITNESS (quote, first 120 chars): {span_witness}"
            lines.append(line)
        else:
            lines.append(f"  [OK] {cid}")
    n_ok = len(cards) - len(rejected)
    status = "PASS" if cards and not rejected else "FAIL"
    lines.append(f"\nRESULT: {status} \u2014 {n_ok}/{len(cards)} card(s) accepted, "
                 f"{len(rejected)} rejected (detected by the Annex \u00a7A7 checks "
                 "named in the disclosure)")
    if not cards:
        lines.append("zero cards in the set: FAIL (no vacuous PASS)")
    return "\n".join(lines) + "\n", {
        "status": status, "n_cards": len(cards), "n_ok": n_ok,
        "rejected": rejected,
        "sources": [{"source_id": source_info[s]["source_id"],
                     "filename": source_info[s]["filename"],
                     "sha256": source_info[s]["sha256"],
                     "bytes": source_info[s]["bytes"],
                     "fallback": source_info[s]["fallback"],
                     "resolved": source_info[s]["resolved"]}
                    for s in source_order],
        "sources_manifest": str(manifest_path) if manifest_path else None,
        "sources_manifest_verified": (manifest_verified
                                      if manifest_path is not None else None),
        "manifest_failures": manifest_failures}


# --------------------------------------------------------------------------
# dispatch table (shared by CLI and MCP server — one registry, both faces)
# --------------------------------------------------------------------------

TOOL_SPECS = {
    "run_verification_suite": {
        "fn": run_verification_suite,
        "description": "Run a verification package's scripts RB1-style (suite "
                       "membership from its runner where present); per-script "
                       "pass/fail by exit code.",
        "properties": {
            "package_path": {"type": "string", "description": "Package directory or .zip"},
            "timeout_s": {"type": "integer", "description": "Per-script timeout seconds (default 420)"},
            "run_unlisted": {"type": "boolean", "description": "Opt-in: execute scripts even when no RB1-style runner suite list is detected (default false — the tool refuses rather than execute unvouched code)"},
        },
        "required": ["package_path"],
    },
    "check_registry_pointers": {
        "fn": check_registry_pointers,
        "description": "Check that each registry entry's pointed script exists "
                       "(v1: existence + declared-content token heuristic, NOT "
                       "full AST claim matching).",
        "properties": {
            "registry_path": {"type": "string", "description": "Registry JSON file"},
            "base_dir": {"type": "string", "description": "Base dir for relative script paths (default: registry's dir)"},
        },
        "required": ["registry_path"],
    },
    "lint_provenance": {
        "fn": lint_provenance,
        "description": "Find INPUT_PROVENANCE blocks in scripts; report coverage "
                       "and module-level literal bindings not detected in the "
                       "block (heuristic, disclosed).",
        "properties": {
            "target": {"type": "string", "description": "A .py file or a directory scanned recursively"},
        },
        "required": ["target"],
    },
    "param_prov": {
        "fn": param_prov,
        "description": "Parameter provenance bookkeeping: classify a JSON "
                       "parameter table per provenance class under its named "
                       "counting convention; REFUSES to emit comparative "
                       "verdicts from totals (guard built in).",
        "properties": {
            "table_path": {"type": "string", "description": "JSON table: {convention, entries:[{name, class}]}"},
        },
        "required": ["table_path"],
    },
    "fence_and_listing_check": {
        "fn": fence_and_listing_check,
        "description": "Fence integrity (pairing + fused-fence scan) of a "
                       "markdown file, and listing<->file identity matched by "
                       "content with the match kind printed (EXACT or "
                       "NORMALIZED; never by position or shared headers).",
        "properties": {
            "md_path": {"type": "string", "description": "Markdown file"},
            "files_dir": {"type": "string", "description": "Directory of standalone script files"},
        },
        "required": ["md_path", "files_dir"],
    },
    "audit_dashboard": {
        "fn": audit_dashboard,
        "description": "Assemble the mechanical checks for a package into the "
                       "dashboard format (per-check lines with counts; NO "
                       "composite index). Suite run only if run_suite=true.",
        "properties": {
            "package_path": {"type": "string", "description": "Package directory or .zip"},
            "registry_path": {"type": "string", "description": "Optional registry JSON"},
            "param_table": {"type": "string", "description": "Optional param_prov JSON table"},
            "run_suite": {"type": "boolean", "description": "Also run the verification suite (slow)"},
        },
        "required": ["package_path"],
    },
    "validate_cards": {
        "fn": validate_cards,
        "description": "Validate a claim-card set against Annex v1.1 §A7: "
                       "A1 schema completeness (NONE-forms where permitted), "
                       "verbatim quote spans found in the named source files "
                       "after whitespace/hyphenation normalisation only, "
                       "layer-taxonomy membership, duplicate card_id absence, "
                       "and the FREEZE §5 banned-construction tripwire over "
                       "claim fields (quotes are never scanned). Does NOT "
                       "check semantic support beyond lexical span presence, "
                       "premise truth, layer correctness (only taxonomy "
                       "membership), location correctness (only membership "
                       "in the named source file), card-set completeness "
                       "for its source, or era fairness of judgements.",
        "properties": {
            "cards_path": {"type": "string", "description": "Cards JSON file: a list of cards, or {cards: [...], sources: {source_id: filename}}"},
            "sources_dir": {"type": "string", "description": "Directory holding the source files named by the cards"},
            "sources_manifest": {"type": "string", "description": "Optional sha256sum-format sources manifest (lines '<sha256>  <basename>'); when provided, each resolved source file's sha256 must match its manifest entry (Annex A2.4 hash-pinning)"},
        },
        "required": ["cards_path", "sources_dir"],
    },
}


def error_report(tool: str, exc: BaseException) -> str:
    """A failed call still discloses: full five-part header + the error.
    Every surface (CLI, both MCP paths) routes failures through here.
    validate_cards failures carry the v1.1 cards header (Annex §A7); all
    other tools keep the v1.0 header."""
    args = (
        tool,
        "the result of the named tool call",
        "nothing — the call failed before or during its check; the error is "
        "the entire verified content of this report",
        "tool arguments -> the attempted check (aborted)",
        "the fact and text of the failure, with the freeze identity under "
        "which it was attempted",
        "the check itself; nothing about the target was established",
    )
    head = header_cards(*args) if tool == "validate_cards" else header(*args)
    return head + f"\nRESULT: ERROR — {type(exc).__name__}: {exc}\n"


def _call_tool_full(name: str, arguments: dict) -> tuple[str, bool]:
    """Dispatch; return (report_text, is_error). Never raises for tool-level
    failures — they come back as headered ERROR reports."""
    spec = TOOL_SPECS.get(name)
    if spec is None:
        return error_report(name, KeyError(f"unknown tool: {name}")), True
    kwargs = {k: v for k, v in (arguments or {}).items() if k in spec["properties"]}
    try:
        text, _data = spec["fn"](**kwargs)
        return text, False
    except Exception as exc:
        return error_report(name, exc), True


def call_tool(name: str, arguments: dict) -> str:
    """Dispatch one tool call; return the report text (errors in-band,
    headered — see error_report)."""
    text, _is_err = _call_tool_full(name, arguments)
    return text
