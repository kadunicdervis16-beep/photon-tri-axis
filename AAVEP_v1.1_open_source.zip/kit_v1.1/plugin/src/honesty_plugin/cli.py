"""Command-line face of honesty_plugin. Same tools, same reports as the
MCP server — the dispatch table in tools.py is the single registry.

Usage:
  python3 -m honesty_plugin suite <package> [--timeout 420]
  python3 -m honesty_plugin registry <registry.json> [--base DIR]
  python3 -m honesty_plugin provenance <file-or-dir>
  python3 -m honesty_plugin param <table.json>
  python3 -m honesty_plugin fence <paper.md> <files_dir>
  python3 -m honesty_plugin dashboard <package> [--registry R] [--param T] [--run-suite]
  python3 -m honesty_plugin cards <cards.json> --sources <sources_dir> [--sources-manifest <manifest.sha256>]

Exit code: 0 if the tool's RESULT is PASS / PASS-WITH-WARNINGS /
ASSEMBLED, 1 otherwise (FAIL / REFUSED / ASSEMBLED-WITH-FAILURES),
2 for usage errors and tool errors. Tool errors print the same
five-part disclosure header as any report (the failure discloses too).
"""
from __future__ import annotations

import argparse
import sys

from . import tools


def _emit(text: str, data: dict) -> int:
    sys.stdout.write(text)
    return 0 if data.get("status") in ("PASS", "PASS-WITH-WARNINGS", "ASSEMBLED") else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="honesty_plugin",
                                 description="Comparative Honesty Audit instrument, FREEZE v1.0")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("suite")
    p.add_argument("package_path")
    p.add_argument("--timeout", type=int, default=420)
    p.add_argument("--run-unlisted", action="store_true",
                   help="execute scripts even if no RB1-style runner suite list "
                        "is detected (they run with your privileges)")

    p = sub.add_parser("registry")
    p.add_argument("registry_path")
    p.add_argument("--base", dest="base_dir", default=None)

    p = sub.add_parser("provenance")
    p.add_argument("target")

    p = sub.add_parser("param")
    p.add_argument("table_path")

    p = sub.add_parser("fence")
    p.add_argument("md_path")
    p.add_argument("files_dir")

    p = sub.add_parser("dashboard")
    p.add_argument("package_path")
    p.add_argument("--registry", dest="registry_path", default=None)
    p.add_argument("--param", dest="param_table", default=None)
    p.add_argument("--run-suite", action="store_true")

    p = sub.add_parser("cards")
    p.add_argument("cards_path")
    p.add_argument("--sources", dest="sources_dir", required=True)
    p.add_argument("--sources-manifest", dest="sources_manifest", default=None)

    args = ap.parse_args(argv)
    try:
        if args.cmd == "suite":
            text, data = tools.run_verification_suite(
                args.package_path, timeout_s=args.timeout,
                run_unlisted=args.run_unlisted)
        elif args.cmd == "registry":
            text, data = tools.check_registry_pointers(args.registry_path, base_dir=args.base_dir)
        elif args.cmd == "provenance":
            text, data = tools.lint_provenance(args.target)
        elif args.cmd == "param":
            text, data = tools.param_prov(args.table_path)
        elif args.cmd == "fence":
            text, data = tools.fence_and_listing_check(args.md_path, args.files_dir)
        elif args.cmd == "dashboard":
            text, data = tools.audit_dashboard(args.package_path,
                                               registry_path=args.registry_path,
                                               param_table=args.param_table,
                                               run_suite=args.run_suite)
        elif args.cmd == "cards":
            text, data = tools.validate_cards(args.cards_path,
                                              sources_dir=args.sources_dir,
                                              sources_manifest=args.sources_manifest)
        else:  # pragma: no cover
            ap.error("unknown command")
            return 2
    except Exception as exc:
        tool_name = {"suite": "run_verification_suite",
                     "registry": "check_registry_pointers",
                     "provenance": "lint_provenance",
                     "param": "param_prov",
                     "fence": "fence_and_listing_check",
                     "dashboard": "audit_dashboard",
                     "cards": "validate_cards"}.get(args.cmd, args.cmd)
        sys.stdout.write(tools.error_report(tool_name, exc))
        return 2
    return _emit(text, data)


if __name__ == "__main__":
    raise SystemExit(main())
