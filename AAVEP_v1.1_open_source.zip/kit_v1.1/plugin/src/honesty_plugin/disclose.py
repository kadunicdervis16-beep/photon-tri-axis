"""Freeze-hash resolution and the five-part disclosure header.

FREEZE_v1.0.md §6: every tool output carries the criteria version, the
freeze hash (short form), and a five-part disclosure — (1) native domain,
(2) verified domain, (3) the map between them, (4) what the map preserves,
(5) what stays outside the check. An output missing any element fails the
run regardless of its result. This module is the single place that header
is built, so no tool can quietly ship without it.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from . import ANNEX_VERSION, CRITERIA_VERSION, FREEZE_DATE

# Fallback if the manifest cannot be found at runtime (e.g. the package was
# copied out of the repository tree). The value is the sha256 of
# FREEZE_v1.0.md as pinned at freeze time; the runtime prefers the manifest.
_FALLBACK_FREEZE_SHA256 = (
    "9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c"
)

# Same arrangement for the v1.1 annex: the sha256 of FREEZE_v1.1_ANNEX.md
# as pinned in FREEZE_MANIFEST_v1.1.sha256 at annex freeze time.
_FALLBACK_ANNEX_SHA256 = (
    "8ee2f8e9c7e2f7341c78b0eb8399e953757c95a3857e0ad597ee632a0564f3a6"
)
ANNEX_FREEZE_DATE = "2026-11-08"


def _plugin_root() -> Path:
    # src/honesty_plugin/disclose.py -> parents[2] is the repository root
    # (the directory holding FREEZE_v1.0.md and FREEZE_MANIFEST.sha256).
    return Path(__file__).resolve().parents[2]


def freeze_sha256() -> tuple[str, str]:
    """Return (full_sha256, source) for FREEZE_v1.0.md.

    Prefers recomputing the hash of the freeze document itself and
    cross-checking it against FREEZE_MANIFEST.sha256; a mismatch is
    reported, not hidden (the freeze is broken, per FREEZE §7, and outputs
    must say so).
    """
    root = _plugin_root()
    freeze_doc = root / "FREEZE_v1.0.md"
    manifest = root / "FREEZE_MANIFEST.sha256"
    pinned = None
    if manifest.exists():
        for line in manifest.read_text(encoding="utf-8").splitlines():
            parts = line.split()
            if len(parts) == 2 and parts[1].endswith("FREEZE_v1.0.md"):
                pinned = parts[0]
    if freeze_doc.exists():
        actual = hashlib.sha256(freeze_doc.read_bytes()).hexdigest()
        if pinned is not None and actual != pinned:
            return actual, "MANIFEST-MISMATCH (freeze document bytes differ from the pinned hash)"
        if pinned is not None:
            return actual, "manifest-verified"
        return actual, ("document-hash only (FREEZE_MANIFEST.sha256 absent at "
                        "runtime — NOT manifest-verified)")
    if pinned is not None:
        return pinned, "manifest (document not found at runtime)"
    return _FALLBACK_FREEZE_SHA256, "embedded fallback (manifest not found)"


def freeze_short() -> str:
    return freeze_sha256()[0][:12]


def annex_sha256() -> tuple[str, str]:
    """Return (full_sha256, source) for FREEZE_v1.1_ANNEX.md.

    Mirrors freeze_sha256(): recompute the hash of the annex document
    itself and cross-check it against FREEZE_MANIFEST_v1.1.sha256; a
    mismatch is reported, not hidden.
    """
    root = _plugin_root()
    annex_doc = root / "FREEZE_v1.1_ANNEX.md"
    manifest = root / "FREEZE_MANIFEST_v1.1.sha256"
    pinned = None
    if manifest.exists():
        for line in manifest.read_text(encoding="utf-8").splitlines():
            parts = line.split()
            if len(parts) == 2 and parts[1].endswith("FREEZE_v1.1_ANNEX.md"):
                pinned = parts[0]
    if annex_doc.exists():
        actual = hashlib.sha256(annex_doc.read_bytes()).hexdigest()
        if pinned is not None and actual != pinned:
            return actual, "MANIFEST-MISMATCH (annex document bytes differ from the pinned hash)"
        if pinned is not None:
            return actual, "manifest-verified"
        return actual, ("document-hash only (FREEZE_MANIFEST_v1.1.sha256 absent at "
                        "runtime \u2014 NOT manifest-verified)")
    if pinned is not None:
        return pinned, "manifest (document not found at runtime)"
    return _FALLBACK_ANNEX_SHA256, "embedded fallback (manifest not found)"


def annex_short() -> str:
    return annex_sha256()[0][:12]


def header(tool: str, native: str, verified: str, map_: str,
           preserves: str, outside: str) -> str:
    full, source = freeze_sha256()
    return (
        f"TOOL: {tool}\n"
        f"CRITERIA: comparative-honesty-audit v{CRITERIA_VERSION} | "
        f"FREEZE: {full[:12]} (full {full}; {source}; frozen {FREEZE_DATE})\n"
        "DISCLOSURE (FREEZE v1.0 \u00a76, five-part):\n"
        f"  native domain: {native}\n"
        f"  verified domain: {verified}\n"
        f"  map: {map_}\n"
        f"  preserves: {preserves}\n"
        f"  outside: {outside}\n"
    )


def header_cards(tool: str, native: str, verified: str, map_: str,
                 preserves: str, outside: str) -> str:
    """Five-part disclosure header for the v1.1 card validator (Annex §A7).

    Names criteria v1.1 (FREEZE v1.0 + Annex v1.1) and prints BOTH freeze
    hashes: the annex's and the incorporated v1.0 freeze's, each with its
    source label. The six v1.0 tools keep using header() above, unchanged.
    """
    afull, asource = annex_sha256()
    ffull, fsource = freeze_sha256()
    return (
        f"TOOL: {tool}\n"
        f"CRITERIA: comparative-honesty-audit v{ANNEX_VERSION} "
        f"(FREEZE v1.0 + Annex v1.1) | "
        f"ANNEX FREEZE: {afull[:12]} (full {afull}; {asource}; "
        f"annex frozen {ANNEX_FREEZE_DATE}) | "
        f"INCORPORATED FREEZE v1.0: {ffull[:12]} (full {ffull}; {fsource})\n"
        "DISCLOSURE (FREEZE v1.0 \u00a76 + Annex v1.1 \u00a7A7, five-part):\n"
        f"  native domain: {native}\n"
        f"  verified domain: {verified}\n"
        f"  map: {map_}\n"
        f"  preserves: {preserves}\n"
        f"  outside: {outside}\n"
    )
