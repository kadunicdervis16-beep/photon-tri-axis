# honesty_plugin v1 — the Comparative Honesty Audit instrument

**Criteria:** comparative-honesty-audit **v1.0**, frozen **2026-11-08**
(`FREEZE_v1.0.md`, hash-pinned in `FREEZE_MANIFEST.sha256`).
**Design of record:** `DESIGN_SYNTHESIS.md` (Valkyrie adjudication,
2026-11-08), also hash-pinned in the manifest.

## What v1 is

A working instrument, in two faces over one tool registry:

- **a CLI** (`python3 -m honesty_plugin …`), and
- **an MCP server** (`python3 -m honesty_plugin.mcp_server`, stdio) that
  uses the official `mcp` Python SDK when it is installed and otherwise
  falls back to a built-in minimal JSON-RPC implementation — stdlib only,
  no other dependencies either way.

It ships three things: the **frozen protocol** (the five metrics M1–M5,
the killed-metrics list, the corpus/strata rules, the pre-registered
counts-against list, the ceiling sentence and banned constructions), the
**mechanical checks** below, and a **self-test trial** of those checks
against a real verification package (`trial/TRIAL_RUN_v1.md`).

### The six v1 tools

| Tool | What it actually does |
|---|---|
| `run_verification_suite` | Runs a verification package's own scripts RB1-style (suite membership from the package's runner where one exists); per-script pass/fail by exit code. Refuses to execute scripts no runner lists unless `run_unlisted=true` is passed explicitly. |
| `check_registry_pointers` | Each registry entry's pointed script **exists inside the base dir** (absolute paths and traversal are flagged as defects, as are duplicate claim_ids); plus a whole-word declared-content token heuristic for entries that declare what they check (gaps are flagged, and downgrade the result to PASS-WITH-WARNINGS). |
| `lint_provenance` | Detects `INPUT_PROVENANCE` blocks anchored in comments or docstrings; lists declared classes; flags module-level literal bindings whose names are not detected in the block. A block that parses zero classes, or any undetected binding, downgrades the result to PASS-WITH-WARNINGS. |
| `param_prov` | Classifies a JSON parameter table per provenance class under its **named counting convention**; prints counts per class. **Refuses** to emit any comparative verdict from totals — the guard scans the whole input (keys, values, convention, entry names) and is mutant-tested. |
| `fence_and_listing_check` | Fence pairing (≥3-backtick fences, markdown closing rule) + fused-fence scan of a markdown file; fenced listings matched to standalone files **by content**, never by position or shared headers, with the match kind printed per block (EXACT, or NORMALIZED when equality holds only after whitespace/line-ending normalization). Zero matched blocks is a FAIL, not a pass. |
| `audit_dashboard` | Assembles the checks above into per-check dashboard lines with counts. **No composite index is computed** (frozen protocol §3). |

Every tool output carries the criteria version, the freeze hash, and the
five-part disclosure header (native domain / verified domain / map / what
it preserves / what stays outside) required by the freeze. Scan outputs say
"detected" — never an unqualified absence claim.

## What v1 is NOT

Read this before citing any output:

- **It does not score an SM corpus.** No comparative run has been performed
  with this instrument. The comparative pilot (ledger corpus vs standard
  corpus under M1–M5) is a later step, gated on the frozen protocol's own
  requirements (frozen corpora, blind coders, published coding manual).
- **It does not score metrics M1–M5 at all.** Those are human-coding
  metrics over claim corpora. v1 implements only the mechanical checks
  that support them.
- **`check_registry_pointers` does not verify that a script checks its
  claim's content.** v1 checks existence plus a token-overlap heuristic,
  and says so in its own output. Full claim↔script fidelity is the M4
  deep-audit task, not this tool.
- **`lint_provenance` is a heuristic.** It anchors on the
  `INPUT_PROVENANCE:` header inside comments or docstrings (a header
  string sitting in executable code does not count); it inspects top-level
  *literal* assignments only. Bindings built by expressions, calls, or
  imports are outside its scan, and "not detected as classified" means
  exactly that — not "proven unclassified".
- **The `param_prov` verdict guard is a tripwire, not a semantic
  guarantee.** It refuses known verdict phrasings anywhere in the input —
  but a verdict encoded purely numerically, in another language, or in
  vocabulary with no comparative marker can evade it. The substantive
  rule is the freeze's banned-constructions rule (§5) applied to
  human-written reports; the guard exists to stop the *instrument* from
  printing a verdict, and its limits are stated in the tool's own output.
- **SECURITY: `run_verification_suite` executes the target package's
  code with your privileges, unsandboxed.** That is what "run the
  package's scripts" means. Run only packages you trust, or run the tool
  inside a sandbox/VM. The `run_unlisted` opt-in exists so that executing
  scripts no runner vouches for is always an explicit decision.
- **A green suite run means the package's scripts exited 0 in this
  environment.** It does not mean their assertions check what their claims
  say, and it does not mean any premise is true.
- **Nothing this instrument prints can outrun the ceiling** (FREEZE §5):
  the strongest claim any run under this freeze may make is the frozen
  ceiling sentence, with its corpus scope attached. Outputs that say more
  are out of protocol, whoever produced them.

## Input contracts (v1) — read before dreaming of symmetry

Every input this instrument consumes is a **house format**: RB1-style
runner suite tuples, `INPUT_PROVENANCE` blocks in the series' two
declaration styles, and this project's JSON schemas (registry entries,
parameter tables). At the protocol level the freeze is corpus-agnostic;
at the instrument level v1 is not: **a corpus that does not already speak
these formats — a standard textbook's problem sets, another group's
verification package — cannot be fed to v1 without a translation step,
and that translation is itself unaudited work.** Any future comparative
run must therefore either bring the other corpus into these formats via
a disclosed, auditable adapter, or extend the instrument — and say which.
Claims of symmetry made on v1 outputs alone would outrun the instrument.

The three vocabularies in play, mapped (they are related, not identical):

| FREEZE M2 provenance classes (parameter audit) | Series INPUT_PROVENANCE classes (script lint) | `param_prov` classes |
|---|---|---|
| stipulated source | paper-defined | paper-defined |
| external source | cited-paper / cited-source / cited | cited-source |
| test control input | control | control |
| declared bridging assumption | declared-assumption | declared-assumption |
| arbitrary representative choice | arbitrary-representative | arbitrary-representative |
| — (not a script-input class) | — | measured-input, fitted, derived-from-structure, unknown |

## Adjudication status

This build's charges were adjudicated by the project's internal loop
pass (devil's advocate / evil auditor / red team, all internal agents;
see `LOOP_ADJUDICATION.md`). **Internal adversarial adjudication is not
external validation.** The frozen design's own openness condition (O5 in
the design synthesis) requires adjudication by a party with no stake in
the outcome before any *comparative* claim is published; the same
standard applied honestly says this instrument's current validation is
internal, and the trial in `trial/` is a smoke test on the author's own
corpus — plumbing evidence, not a comparative result.

## Install and run

No build step. Python 3.10+, standard library only for the CLI and the
fallback MCP path. For the SDK MCP path: `pip install mcp` (into a venv).

```bash
cd honesty_plugin
export PYTHONPATH=src

# CLI
python3 -m honesty_plugin suite     /path/to/verification_package.zip
python3 -m honesty_plugin registry  /path/to/registry.json --base /path/to/package
python3 -m honesty_plugin provenance /path/to/scripts_dir
python3 -m honesty_plugin param     /path/to/param_table.json
python3 -m honesty_plugin fence     /path/to/paper.md /path/to/scripts_dir
python3 -m honesty_plugin dashboard /path/to/package --registry R.json --param T.json

# MCP server (stdio)
python3 -m honesty_plugin.mcp_server
# force the stdlib fallback even when the SDK is installed:
HONESTY_PLUGIN_MCP_FORCE_FALLBACK=1 python3 -m honesty_plugin.mcp_server

# Self-test (43 cases: fixtures + all planted-mutant classes, incl. the v1.1 card mutants and the v1.1.1/v1.1.2 repair mutants)
python3 tests/selftest.py

# MCP proof (scripted raw-JSON-RPC client: initialize + tools/list + tools/call)
python3 tests/mcp_proof.py -- python3 -m honesty_plugin.mcp_server

# Trial run against the Paper 12.5 v3 verification package
python3 trial/run_trial.py /path/to/Paper_12_5_v3_verification_package.zip
```

Exit codes (CLI): 0 = PASS / PASS-WITH-WARNINGS / ASSEMBLED; 1 = FAIL,
REFUSED, or ASSEMBLED-WITH-FAILURES; 2 = usage error or tool error (tool
errors print the full disclosure header too — the failure discloses).

## Versioning policy

v1 is a first version and **will** evolve — that is expected and stated, in
the spirit of the commission ("version one as we get more; it develops").
Two different things version independently, and confusing them is out of
protocol:

- **Instrument versions** (this code: v1, v2, …) may add tools, improve
  heuristics, and fix defects. Every output names the criteria version and
  freeze hash it ran under.
- **Criteria versions** (the freeze: v1.0, v1.1, v2.0, …) change ONLY by
  issuing a new freeze document with its own hash and date, with the change
  and its reason recorded. **Criteria are never edited silently inside an
  existing freeze.** Any post-hoc criteria change voids any run in progress
  under the old version; a voided run may be reported only as voided.
- If `FREEZE_v1.0.md`'s bytes ever differ from the hash pinned in
  `FREEZE_MANIFEST.sha256`, the freeze is broken and must be re-issued —
  the plugin detects this at runtime and prints MANIFEST-MISMATCH in every
  header rather than proceeding quietly. Stated at full strength: the
  hash pin is a **tripwire and a record, not a constraint** — nothing in
  the tooling prevents an editor with write access from editing the
  freeze and the manifest together, and as of v1 (2026-11-08) the freeze
  is **not externally anchored** (no published timestamped copy).
  External anchoring — e.g. publishing the freeze hash with the paper
  series' records — is the author's action and remains open.

## v1.1 addendum (2026-11-08)

Criteria **v1.1** = FREEZE v1.0 plus Annex v1.1 (`FREEZE_v1.1_ANNEX.md`,
hash-pinned together with the incorporated v1.0 freeze hash in
`FREEZE_MANIFEST_v1.1.sha256`). FREEZE v1.0 itself is unchanged. The annex
is the translation step v1's "Input contracts" section said was missing:
it defines the claim-card schema (A1) by which a text that was never
written for this audit — a historical paper, a later textbook
presentation — enters the audit as governed, validated cards, and the
participation doors (A5) open to the parties whose texts are carded.

### The seventh tool: `validate_cards`

`validate_cards` (CLI: `python3 -m honesty_plugin cards <cards.json>
--sources <sources_dir>`; MCP tool of the same name) is the mechanical
limb of the annex (A7). Given a cards file and the run's sources, it
checks — and ONLY checks:

- **Schema completeness:** every card carries every A1 field in an
  admissible form (NONE-forms where the schema permits them; an omitted
  field or an empty string/list is not a NONE-form).
- **Span traceability:** every card's `quote` occurs in its named source
  file after whitespace/hyphenation normalisation only — words,
  punctuation, and notation must match exactly after that.
- **Layer membership:** every `layer` value is in the frozen five-value
  taxonomy (`state-space`, `measure`, `dynamics`, `statistics`,
  `interpretation`).
- **Duplicate identity:** no two cards share a `card_id`.
- **Banned constructions:** the `claim` field (the carder's own text)
  carries no FREEZE §5 banned construction. The verbatim `quote` is never
  scanned — the discipline binds the carder, not the source.

What it does NOT check is printed in its own output, per A7: whether a
claim is semantically supported beyond lexical span presence; whether
premises are true; whether the layer choice is right (only that it is in
the taxonomy); whether the card set is complete for its source; and era
fairness of judgements. Those belong to dual carding, adjudication, and
the loop pass (A3), not to this tool.

Output discipline: `validate_cards` reports under criteria **v1.1** and
prints BOTH freeze hashes (the annex's and the incorporated v1.0
freeze's) with the five-part disclosure. The six original tools' checks
and v1.0 disclosure headers are unchanged, and they still report
criteria **v1.0** under the v1.0 freeze hash; their source files
changed only to add the seventh tool and its plumbing.

### Worked example

`worked_example_dirac/` holds a worked example of carding under the
annex. Its scope label is **DEMONSTRATION** (Annex A6): one or few
sources, house carders, method illustration. A demonstration carries no
M1–M5 scores, supports no comparative claim, and may not be cited as
pilot evidence; its limits are printed in its own report.

### Version notes

- Instrument v1.1.0. Criteria v1.1 governs the card validator; criteria
  v1.0 governs the six original tools, exactly as frozen.
- File hashes for the v1.1 instrument set are recorded in
  `INSTRUMENT_MANIFEST_v1.1.sha256`. The v1 manifest
  (`INSTRUMENT_MANIFEST.sha256`) is retained unchanged as the historical
  record of the v1 instrument.

### v1.1.1 repair note (2026-11-08, loop pass)

Instrument v1.1.1 repairs `validate_cards` on adjudicated loop-pass
charges; the criteria and both freezes are unchanged.

- **The banned-construction tripwire is literal, and its phrases are
  enumerated.** The seven literal tripwire phrases scanned for are:
  "more honest than"; "machine-verified superiority"; "fails
  verification"; "condemned by the checks"; "proves that the ledger";
  "demonstrates that the ledger"; "establishes that the ledger".
  The scan covers the `claim` field only (Annex A7) and, after the
  v1.1.1 repair, de-hyphenates (hyphen+newline sequences are removed,
  as in quote normalisation) before scanning, so a phrase split at a
  line break is still detected.
- **The tripwire is a literal floor under FREEZE §5's semantic ban,
  not the ban itself.** Two §5 categories have NO tripwire and are
  checked by no tool: naked comparatives without a named convention
  or scope, and "full state space / all claims" bound-language.
  Those remain human/adjudication checks.
- **Unknown extra fields on a card are tolerated and NOT audited.**
  The validator checks the A1 fields it knows; an additional field is
  neither rejected nor inspected.
- **Bridge-entry type checks sit under A7 check 1 (schema
  completeness)** — including, after v1.1.1, that each entry's
  `support` is a non-empty string.
- **Sources binding is strengthened.** `validate_cards` output now
  prints, before the per-card lines, one `SOURCE <source_id> ->
  <filename> sha256 <full hash> (<n> bytes)` line per resolved
  source (`SOURCE-FALLBACK`-prefixed, with a warning that the
  fallback is a guess, not a manifest resolution, when the
  `{source_id}.txt` fallback resolved it). The optional
  `--sources-manifest <path>` (MCP: `sources_manifest`) enforces
  Annex A2.4 hash-pinning: each resolved source's sha256 must match
  the sha256sum-format manifest entry for its basename, or every
  card of that source is rejected with the expected/actual hashes
  as witness.
- **Other v1.1.1 tightenings:** placeholder `era_note` values
  (`n/a` and its kin) and anonymous `carder` values are rejected
  (Annex A1); an `evidence` value beginning with `NONE` must be
  `NONE` + a separator (—, –, -, or :) + a non-empty reason — a bare
  `NONE` is rejected with the value as witness; duplicate
  `card_id` detection compares whitespace-stripped ids
  (case-sensitivity retained).
- **House-practice notes.** Annex A5 Door-1 nominations are accepted
  only before a run's corpus freeze (FREEZE §3 governs on conflict).
  A6's ceiling reference is read as a bound, never a license
  (demonstrations print no comparative conclusions). Right-of-reply
  edits under Door 3 will be printed with the respondent's objection
  alongside.

### v1.1.2 repair note (2026-11-08, Paper 12.5 v4 loop pass)

Instrument v1.1.2 repairs two disclosure/substance gaps found by the
Paper 12.5 v4 build's red team (RT4-1, RT4-2); criteria and freezes
unchanged; no check was weakened.

- **Location correctness is named as outside the verified domain.**
  `validate_cards` checks that a quote occurs in the named source
  *file*; it does not verify the card's stated location (page,
  section) within that file. Locations are carder- and
  adjudicator-checked. The disclosure's `outside:` list and the tool
  description now say so explicitly (previously the omission was
  silent).
- **NONE-form reasons must carry substance.** A NONE-form whose
  `reason` is punctuation only (no alphanumeric character) is now
  rejected, matching the rule the evidence field already applied to
  its NONE form.
