# FREEZE v1.0 — Comparative Honesty Audit Protocol

**Freeze date:** 2026-11-08
**Criteria version:** v1.0
**Status:** FROZEN. This document is the protocol of record for the comparative
honesty audit commissioned by Dervis Kadunic on 2026-11-08 ("freeze" — his
word; plugin version one ordered the same day). Hash-pinned in
`FREEZE_MANIFEST.sha256` alongside the design synthesis it derives from
(`DESIGN_SYNTHESIS.md`, Valkyrie adjudication, 2026-11-08).

**What this freeze is.** A set of bookkeeping criteria, a comparison protocol,
and a machine-check instrument, fixed *before* any comparative scoring. It
measures **accounting fidelity** — the gap between a framework's public
self-presentation and what an independent audit finds about its premises,
freedoms, evidence, interpretive bridges, scope, and corrections. It does not
measure truth, parsimony, empirical success, or parameter count, and no output
produced under it may claim otherwise.

---

## 1. The five criteria (metrics M1–M5, ranked)

### M1 — Load-Bearing Premise Declaration Rate
Premises are identified by the **counterfactual-removal test**: a premise is
load-bearing if removing or materially changing it would make the derivation
or conclusion fail, weaken, or change scope. A premise counts as *declared*
when its epistemic status (postulate / assumption / definition / measured
input / convention / theorem-with-conditions) is identifiable at or before its
first load-bearing use.
*Anti-gaming guards:* keyword counting ("postulate", "assume", …) is NOT the
measure — it rewards house style. Functional declaration only. Declared
trivialities do not dilute the denominator: only load-bearing premises enter
it. Boilerplate ("we assume the model assumptions") earns no credit.

### M2 — Degree-of-Freedom Provenance Accuracy
Every freedom that can materially alter an output — named parameters,
cutoffs, windows, priors, representative choices, script constants, hardcoded
values — is traced to exactly one provenance class: **derived-from-structure /
measured-input / fitted / declared-assumption / arbitrary-representative /
unknown**. The metric is the *accuracy of the presented status against the
audited status*, not the count. A meticulously catalogued measured parameter
scores perfectly; a "derived" quantity whose chain terminates in a fitted
constant is reclassified by chain-tracing.
*Anti-gaming guards:* code and supplements are inside the census;
provenance cycles (a "derivation" that quietly uses the fitted value) are
detected and scored as not-derived; an item explicitly labelled "unknown"
scores as accurate when the audit confirms it is genuinely undocumented
upstream.

### M3 — Undeclared Bridge Density
A *bridge* is an inference from a formal, mathematical, computational, or
counted object to a claim about physical reality not logically contained in
the formal result (formal average → observed frequency; decomposition →
physical mixture; count → physical magnitude; fitted parameter → intrinsic
property). A bridge is *declared* only if the text both (a) marks the move as
interpretive/conditional/conjectural AND (b) supplies load-bearing support:
an explicit bridge premise, an argument, an empirical link, or an identified
conjecture status. Density = undeclared bridge events per 100 major claims;
lower is better; unweighted and severity-weighted figures both reported.
*Anti-gaming guards:* a label alone ("Stage P", "interpretation:") earns no
credit without content; a stipulative definition that performs the bridge is
coded as a bridge premise and audited under M1/M2; sampled bridge arguments
must state what would be different if the bridge were false.

### M4 — Claim–Evidence Traceability & Fidelity
Two subscores. *Completeness:* fraction of major claims carrying a specific
evidence locator (page, equation, theorem, dataset, primary paper, script +
run record, registry entry). *Fidelity:* for a deep-audited sample, whether
the cited artefact supports THIS claim at THIS strength — exact / partial /
adjacent / none. Adjacent support (a script checking a neighbouring
proposition) is a mislink, not verification. Format-neutral: a claim needs no
particular badge format, only a genuine trail.
*Anti-gaming guards:* random deep audits, not trust of every link; a script
that encodes its conclusion in its inputs fails fidelity (input-equals-output
ban); a confident claim explicitly marked "no evidence yet" counts as
traceable but NOT supported — the two subscores are never merged.

### M5 — Falsifier Coverage & Sharpness
Denominator: major claims presented as empirically or structurally
risk-bearing (pure definitions and labelled conjectures excluded — unless a
definition is used to make an empirical claim, which enters it). Each claim
scores **0** (no defeating condition), **1** (vague: "future evidence may
revise"), or **2** (concrete: an observable, comparison, threshold, structural
result, or decision rule that would require withdrawal or narrowing). A
**false-falsifier rate** is also reported: stated falsifiers that are
tautological, logically disconnected, or escape-claused.
*Anti-gaming guards:* the falsifier must be decidable in principle and must
discriminate the claim from at least one rival or null outcome; the headline
claim is scored, not a weakened restatement; post-hoc threshold changes are
scored under correction behaviour, not silently absorbed.

### Metrics repaired before use (not headline criteria in v1.0)
- **Layer separation:** score inference EDGES, not headings or vocabulary;
  functional roles, not required terms; implicit formal separation counts.
  Dropped from any headline comparison if blind coders cannot apply it
  reliably across both corpora (inter-rater κ ≲ 0.6).
- **Correction behaviour:** bounded accountable corpora only (a named text
  across editions, the PDG across editions, the paper series across
  versions); severity-weighted; acknowledgment and original-location linkage
  scored, never raw volume. If no comparable unit exists on a side, reported
  as parallel case studies and excluded from ranking.

## 2. Killed metrics — excluded entirely

The following are NOT criteria, evidence, tiebreakers, or scoring bonuses
under this freeze, in any run, in any wording:

- **Raw free-parameter count.** Parsimony is not honesty. Replaced by M2.
- **The 26-vs-27 count resemblance** (Standard Model free-parameter counts
  vs the ledger's 27-state inventory). Killed and excluded — it is
  numerology for the purposes of this audit and must not appear as evidence,
  a suggestive pattern, or a soft bonus anywhere in a run's outputs.
- **Raw badge / registry / "Level A" counts.** Possession of a house format
  is not honesty. Replaced by format-neutral M4.
- **"No probability postulate" as a point in itself.** Absence of an explicit
  postulate is a structural feature to be audited, not a virtue to be
  assumed; hidden measure-equivalents are scored under M1/M2/M3 wherever
  they occur, on either side.
- **Word-frequency counts of contested terms; raw machine-verified claim
  counts.** Lexical frequency proves nothing about honesty; trivial checks
  can be manufactured. Replaced by M3/M9-style contextual coding and M4.

## 3. Corpus and comparison protocol

- **Freeze before scoring.** Corpora are named by edition and hash-pinned
  before any scoring; claim-extraction rules, the coding manual, and
  severity weights are frozen with them. No favourable text is added, and no
  unfavourable edition quietly replaced, after preliminary results are seen.
- **Matched strata.** Formal is compared with formal (ledger side: Papers
  11/11.5/12/12.5 canonical texts + registries + scripts; standard side: a
  predeclared canonical corpus, e.g. the PDG review and named QFT /
  statistical-mechanics texts). Gloss is compared with gloss (cheat sheets
  and summaries vs textbook introductions and review glosses). **A result
  about a gloss is never reported as a result about the formal theory, and
  vice versa** (the H-series label discipline).
- **"Major claim" defined identically on both sides:** appears in an
  abstract, conclusion, registry, summary table, or headline result; OR is
  load-bearing for a later result; OR makes a quantitative empirical
  assertion; OR asserts a physical interpretation of a formal object; OR
  asserts that something has been derived, measured, verified, excluded, or
  falsified. Large populations: stratified random sample plus ALL headline
  claims; sample size and confidence intervals reported.
- **Blind duplicate coding** where feasible: identifiers stripped from claim
  cards, two independent coders, disagreements adjudicated under the frozen
  codebook, inter-rater reliability reported per metric. An adversarial
  re-annotation pass is instructed to find hidden premises, hidden freedoms,
  and undeclared bridges on BOTH sides.
- **Dashboard, not an index.** Every result is reported per metric with
  numerator/denominator (or events per 100 major claims), unweighted and
  severity-weighted figures, an interval for proportions, the stratum, and
  representative pass AND fail examples from both sides. **No single
  composite "Honesty Index" may be computed or printed.**
- **Adversarial metric nomination.** Reviewers from the standard side may
  nominate honesty metrics of their own; nominated metrics are scored on
  both corpora with equal weight and reported on the same dashboard.

## 4. Pre-registered counts-against list

The following findings are named IN ADVANCE as defeats. If a run returns
them, they are printed as defeats in the run's own report — not explained
away, not repaired mid-run:

1. **Cheat-sheet slide parity.** If blind coders rate the ledger's own
   cheat-sheet / summary prose as committing undeclared layer-crossings or
   bridges at a rate comparable to the standard side's textbook gloss, the
   comparative claim is **withdrawn** for the gloss stratum.
2. **Registry mislink.** If M4 deep-audit finds ledger registry entries
   whose backing scripts check adjacent content rather than the claim's
   actual content at a rate comparable to the standard corpus's mislink
   rate, the traceability advantage claim is withdrawn.
3. **Hidden freedom.** If M2 finds a ledger quantity presented as derived
   whose provenance chain terminates in a fitted or arbitrary input, that
   finding is printed at headline level, with the quantity named.
4. **Vacuity exposure.** If the ledger's headline claims, scored for
   discriminating content, prove materially less risky/specific than the
   standard corpus's headline claims, the dashboard must print the
   claim-yield rows beside the honesty rows and state that honesty-per-claim
   is confounded with claim boldness in this run.
5. **Metric unreliability.** Any metric whose blind-coder inter-rater
   reliability falls below the pre-registered floor (κ ≲ 0.6) is demoted to
   "exploratory" in that run's dashboard, whatever its result.
6. **Self-application failure.** If the audit's own instruments (the plugin
   of §6) fail their planted-mutant batteries on the frozen criteria, no
   comparative result from that instrument version may be published until
   the failure is fixed under a new instrument version and the run repeated.

## 5. The ceiling and banned constructions

**The ceiling — the strongest claim any run under this freeze may print,
and no stronger:**

> "Under one published set of bookkeeping criteria, applied symmetrically
> and open to return application, the ledger's texts declare more of what
> they assume than the cited standard texts declare of theirs — and here is
> the itemised account, the criteria, and the machine record, so the reader
> can check the account and dispute the criteria."

**Banned constructions** (in run reports, plugin outputs, READMEs, and
summaries produced under this freeze; the plugin's own outputs are held to
them):

- "proves / demonstrates / establishes that the ledger is more honest than
  the Standard Model" — or any unscoped equivalent;
- "machine-verified superiority"; "the SM fails verification"; "condemned by
  the checks";
- any naked comparative (e.g. a bare parameter total) without its counting
  convention AND corpus scope in the same sentence;
- any PASS reported without its five-part disclosure header (§6);
- "the full state space / all claims" for any bounded enumeration — the
  bound must be stated.

## 6. The instrument (plugin v1) and the disclosure rule

The plugin (`honesty_plugin`, v1) is the machine-check subset of this
protocol. **Scope honesty:** M1–M5 are human-coding metrics over claim
corpora; plugin v1 does NOT score them. Plugin v1 implements the mechanical
checks that support them — verification-suite running (RB1-style),
registry-pointer existence checking, INPUT_PROVENANCE linting,
parameter-provenance bookkeeping under a named convention, and
fence/listing byte-identity checking — each labelled with its v1 limits in
its own output. The comparative pilot (scoring an SM corpus against a ledger
corpus under M1–M5) is a later step and is NOT part of v1.

**Five-part disclosure rule.** Every tool output produced under this freeze
carries, in its header: (1) the native domain, (2) the verified domain,
(3) the map between them, (4) what the map preserves, (5) what stays
outside the check — plus the criteria version (v1.0) and this freeze's hash
(short form). An output missing any element fails the run regardless of its
result. Every scan-type output uses the word **"detected"** ("no detected
…"), never an unqualified absence claim.

**PARAM-PROV guard.** The parameter-bookkeeping tool classifies entries per
provenance class under a named counting convention and prints counts per
class with the convention attached. It must REFUSE to emit any comparative
verdict from totals; a request or template asking it to do so is a
verdict-injection attempt and is rejected with the request printed as the
witness.

## 7. Versioning rules

- This freeze is **v1.0**. The criteria, killed list, strata rules,
  counts-against list, ceiling, and banned constructions above may not be
  edited silently. Any change to any of them creates **v1.1, v2.0, …** as a
  NEW freeze document with its own hash and date, and the change recorded
  with its reason.
- **Any post-hoc criteria change voids any run in progress under the old
  version.** A voided run may be reported only as voided, with the reason.
- Instrument (plugin) versions evolve independently (v1, v2, …) but every
  instrument output names the criteria version and freeze hash it ran
  under; an instrument that implements changed criteria without a new
  freeze is out of protocol.
- The freeze hash of record is the sha256 of this file as pinned in
  `FREEZE_MANIFEST.sha256` at freeze time. If this file's bytes ever differ
  from the pinned hash, this freeze is broken and must be re-issued, not
  quietly repaired.
