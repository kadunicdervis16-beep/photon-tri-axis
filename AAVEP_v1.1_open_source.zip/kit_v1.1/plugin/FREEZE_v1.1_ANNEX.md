# FREEZE v1.1 ANNEX — Translation & Participation

**Annex date:** 2026-11-08
**Criteria version:** v1.1 (FREEZE v1.0 as extended by this annex)
**Status:** FROZEN as an annex. This document EXTENDS `FREEZE_v1.0.md`; it
does not amend, replace, or silently edit any part of it. `FREEZE_v1.0.md`
(sha256 `9abc91c9eee95c42044098b39a45bf25a4177f773e9fec41d98f38dbdbe8f33c`,
pinned in `FREEZE_MANIFEST.sha256`) is incorporated by reference, byte for
byte. This annex is hash-pinned, together with the v1.0 freeze hash, in
`FREEZE_MANIFEST_v1.1.sha256`. Where this annex and FREEZE v1.0 both speak,
the stricter reading governs; where they conflict, FREEZE v1.0 governs and
the conflict must be reported, not resolved silently.

**Why this annex exists.** FREEZE v1.0 §3 fixes the comparison protocol, and
the v1 instrument's own README records its limit: every input v1 consumes is
a house format, and a corpus that does not already speak those formats
cannot be fed to the instrument without a translation step that is itself
unaudited. This annex is that translation step, made auditable. Its subject
is how a text that was never written for this audit — a historical paper, a
bare equation with its literature, a modern textbook presentation — enters
the audit as **claim cards**, under governed, dual, machine-validated
carding, and how the parties whose texts are carded may participate.

---

## A1. The claim card — schema

One card per claim. A card is a JSON object with ALL of the following
fields; a card missing a field is not a card and the validator rejects the
set (see A7). Field forms marked NONE-form are the object
`{"none": true, "reason": "<why this field is empty for this claim>"}` —
an empty string, an empty list, or an omitted field is never an acceptable
substitute for a stated NONE-with-reason.

| Field | Form | Content |
|---|---|---|
| `card_id` | string | Unique within the card set. Convention: `<SOURCE>-<NN>` (e.g. `D28-03`). Duplicates are rejected mechanically. |
| `source_id` | string | Names the source text; must resolve to a file in the run's sources manifest (A2.4). |
| `quote` | string | A **verbatim span** of the named source (see A2.1). The card's anchor: everything else on the card is commentary on this span. |
| `location` | string | Where the span sits in the named edition: page, section, paragraph, equation number — precise enough for a stranger to find it unaided. |
| `layer` | enum | Exactly one of: `state-space`, `measure`, `dynamics`, `statistics`, `interpretation`. The layer the CLAIM operates at (not the layer of its evidence). |
| `claim` | string | The carder's statement of the claim, in the carder's words. Bounded by A2.2: it may assert no more than the card's spans support. This field — the carder's own text — is scanned for the FREEZE §5 banned constructions. |
| `premises` | list of strings, or NONE-form | The premises the text itself supplies or visibly relies on for this claim, each traceable to the source (quote them or locate them in `location`-style references). |
| `freedoms` | list of strings, or NONE-form | The choices that could have been otherwise and can move the result: ansatz forms, chosen representations, fitted or inserted constants, selected special cases, window/convention choices. |
| `evidence` | string | The evidence locator the TEXT offers for the claim: a derivation (located), a theorem with conditions, a dataset, an experiment, an authority citation — or `NONE — <reason>`. |
| `bridges` | list (may be empty) | Each entry: `{"from_layer": …, "to_layer": …, "declared": true/false, "support": "<what the text supplies, or NONE>"}`. An empty list is an explicit statement that the claim crosses no layer boundary. |
| `falsifier` | string, or NONE-form | What would defeat or narrow this claim, at the sharpness the text itself states; if the text states none, the NONE-form reason says so. Carders do not invent falsifiers on a text's behalf; an auditor-supplied candidate falsifier belongs in the adjudication log, labelled as such. |
| `scope` | string, or NONE-form | The domain, regime, and conditions the text attaches to the claim, in the text's own terms where it attaches any. |
| `era_note` | string | The era/context note: the source's date and milieu, the declaration forms available to its author (see A4.2), and anything a coder must know to judge declaration fairly. Mandatory for every card; "n/a" is not an era note. |
| `carder` | string | The carder identifier. Anonymous cards are not admitted; provenance of translation is part of the record. |

## A2. Carding rules

**A2.1 Verbatim-span requirement.** Every card's `quote` must occur
verbatim in the named source file, up to whitespace normalisation only
(spaces, line breaks, and hyphenation-at-line-break may be normalised;
words, punctuation, and notation may not). A card whose quote is altered,
conflated from two places, or drawn from the carder's memory of the text is
defective and the validator rejects it with the card printed as witness.
Long spans may be elided ONLY by splitting into multiple cards, never by
internal ellipsis: one card, one continuous span.

**A2.2 No more than the spans support.** The `claim` field may not assert
more than the card's `quote` (plus any further spans the card locates in
its `premises`/`evidence` fields) supports. A claim that needs a span the
card does not carry must either gain the span (as its own card or a located
premise) or be narrowed to what the carried spans establish. Lexical-level
enforcement is mechanical (A7); semantic enforcement is the adjudicator's
duty (A3) and the loop pass's.

**A2.3 Equation-entourage rule.** A bare equation is never audited alone —
equations make no declarations and hide no premises; the claims made *for*
them do. A mathematical result enters the audit through the claims in the
texts that present it: what its author said it assumes, derives, and means;
what later presenters say it established. Card the entourage, never the
symbols.

**A2.4 Sources manifest.** Every carding run carries a sources manifest
naming, per `source_id`: the edition, the retrieval source (URL or
archive), the retrieval date, and the sha256 of the source file as carded.
Cards are valid only against the manifest's hashes; re-carding against a
different edition is a new run.

**A2.5 One claim per card; claims, not topics.** If a span makes two
claims, it earns two cards sharing the span. A card that summarises a
chapter is not a card.

## A3. Dual carding and open adjudication

**A3.1 Two carders, independent.** Every source in a run is carded by TWO
carders working independently: no shared context beyond this annex, the
frozen criteria, and the sources manifest; no sight of each other's cards
before both sets are sealed (hash-recorded).

**A3.2 Adjudication with the source open.** A named adjudicator merges the
two sets with the source text open. Every disagreement is resolved against
the source, and the resolution is logged in a published **adjudication
log**: disagreement class (span dispute / layer dispute / premise-set
dispute / scope-or-falsifier dispute / card-existence dispute), both
positions, the source span that decides it, and the outcome. Cards that
survive in only one carder's set are not silently dropped or silently kept:
they are logged, with the reason.

**A3.3 The merged set is the run's data.** Tallies and scores are computed
only over the adjudicated merged set. Individual carder sets are retained
in the run record so the translation's sensitivity is itself inspectable.

## A4. Originals and glosses — the dual-audit rule

**A4.1 Separate audits.** Where a claim has both an original source and a
later presentation (textbook, lecture notes, review), the original and the
gloss are carded and tallied SEPARATELY. No merged "the field says" corpus
may be constructed. A result about a gloss is never reported as a result
about the original, and vice versa (FREEZE v1.0 §3, H-series discipline,
applied across time).

**A4.2 Era-relative declaration norms.** A text is judged on two scales,
both reported: (a) the frozen criteria as written; and (b) the declaration
forms available in its era. Definitions-and-axioms structure, explicitly
labelled postulates, stated hypotheses before propositions, and their era
equivalents count as declaration in any century. **Era shelter runs one
way only:** a historical text is not failed for lacking forms its era had
not developed; a MODERN presentation of that text receives no era shelter
at all and is judged wholly by the frozen criteria — and additionally by
A4.3.

**A4.3 Gloss-vs-original fidelity.** For every gloss card whose claim
concerns an original's result, the run records a fidelity entry: does the
gloss preserve, upgrade, or downgrade the original's own epistemic status
(postulate presented as derivation = upgrade; derived result presented as
assumption = downgrade; declared bridge presented as settled fact =
upgrade)? Each entry carries BOTH quotes (original span and gloss span).
The fidelity list is a first-class output of any original+gloss run.

## A5. Participation — the three doors

The audit is open to return application (FREEZE v1.0 §5, ceiling). A party
whose texts are audited, or who disputes a run, has three doors, all
recorded in the run's own report:

1. **Champion nomination.** The audited party (or any reviewer) may
   nominate the texts they judge their side's strongest — champion texts
   enter the corpus under the same freeze rules as any other text, and the
   nomination is printed in the run record. A run over house-chosen texts
   only must say so.
2. **Self-carding.** Any party may submit cards for any text, including
   their own, in the A1 schema. Submitted cards enter the record only by
   passing the validator (A7) and the A3 adjudication; validator failures
   are printed with witnesses, not negotiated away. Self-carded sets are
   labelled with their carder provenance exactly as house sets are.
3. **Right of reply.** Every published run carries the audited party's
   reply — counter-cards, disputed adjudications, nominated metrics
   (FREEZE v1.0 §3) — printed alongside the results, unedited except for
   the FREEZE §5 banned constructions, which bind all parties equally.

Refusal of all three doors by an audited party is itself a reportable fact
of the run, stated neutrally.

## A6. Scope labels — demonstration vs pilot

Every run under this annex carries exactly one scope label, in its header
and in every summary of it:

- **DEMONSTRATION.** A worked example: one or few sources, house carders,
  method illustration. A demonstration establishes that the method runs and
  shows its outputs on the example. It is NOT a comparative result: it
  carries no M1–M5 scores, supports no claim beyond the FREEZE v1.0 §5
  ceiling (and in practice far less), and may not be cited as pilot
  evidence. Its limits — single example, internal carders, externality
  still owed — are printed in its own report, not in a footnote.
- **PILOT.** A comparative run proper: frozen dual corpora, blind coders
  (FREEZE v1.0 §3), the full protocol. Only a pilot may print M1–M5
  dashboard figures, and only with its strata, intervals, and the §4
  counts-against list in force.

A demonstration that outruns its label voids itself, under the same rule
as a post-hoc criteria change (FREEZE v1.0 §7): it may be reported only as
voided, with the reason.

## A7. The validator contract (`validate_cards`, instrument v1.1)

The validator is the mechanical limb of this annex. Given a cards file
(A1 schema) and the run's sources (per A2.4), it checks — and ONLY checks:

1. **Schema completeness:** every card carries every A1 field in an
   admissible form (NONE-forms where the schema permits them).
2. **Span traceability:** every card's `quote` is found verbatim
   (whitespace-normalised) in its named source file. Failure rejects the
   card with the quote printed as witness.
3. **Layer membership:** every `layer` value is in the frozen five-value
   taxonomy.
4. **Duplicate identity:** no two cards share a `card_id`.
5. **Banned constructions:** the `claim` field (the carder's own text)
   carries no FREEZE v1.0 §5 banned construction. The verbatim `quote` is
   NOT scanned — a source may say what it says; the discipline binds the
   carder, not the dead.

What the validator does NOT check, and its output must say so: whether a
claim is *semantically* supported beyond lexical span presence (adjudication
and loop territory); whether premises are true; whether the layer choice is
*right* (only that it is in the taxonomy); whether the card set is complete
for its source (a carder can omit a claim — completeness is a dual-carding
and adjudication property, not a mechanical one). Scan outputs use
"detected" language throughout, per FREEZE v1.0 §6.

**Output discipline.** Validator output carries: criteria version **v1.1**,
this annex's freeze hash (short form) AND the incorporated v1.0 freeze
hash, and the five-part disclosure (FREEZE v1.0 §6) — native domain (the
fidelity of this card set to its sources and schema), verified domain
(schema + verbatim-span + taxonomy + tripwire checks over the named
files), the map, what it preserves, and what stays outside (A7 list above).

## A8. Versioning

This annex is part of criteria **v1.1**. FREEZE v1.0 is unchanged by it and
remains the protocol's base. Any change to this annex creates a new freeze
version (v1.2, v2.0, …) as a new document with its own hash and date, with
the change and its reason recorded, under FREEZE v1.0 §7. Runs in progress
under v1.1 are voided by any change to v1.1, as there defined.
