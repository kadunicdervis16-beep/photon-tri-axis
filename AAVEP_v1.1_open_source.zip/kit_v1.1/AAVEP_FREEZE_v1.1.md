# AAVEP FREEZE — v1.1

**Frozen:** 2026-11-12 (America/Toronto), at build, by the author's
commission. **License:** MIT, © Dervis Kadunic (see LICENSE).
**Self-status at freeze: DEMONSTRATION** (AAVEP_SPEC §1, SS-1) —
the kit has been exercised end-to-end by its own house (see
demo/DEMO_RECORD.md); it becomes CERTIFIED only when an external,
unaffiliated agent completes a full certified run. Nothing in this
freeze claims more. The v1.0 kit and its freeze are untouched by
this one; v1.0 artifacts verify under v1.1 tooling with their
LEGACY-CUSTODY / UNVERIFIED-ROOT labels printed.

## What is frozen

The AAVEP v1.1 kit: the base specification (AAVEP_SPEC.md,
byte-identical to v1.0's) plus the v1.1 delta specification
(AAVEP_SPEC_v1.1.md, §§D1–D11; the design's §17.3 amendments
B-1…B-38 govern), the AAVEP-CAL v2 battery and its spec
(cal/AAVEP_CAL_SPEC_v2.md, with the §1.1 canonical-serialization
repair recorded in its changelog), the tools in tools/ (CAL v2
custody, the single derive_all report pipeline, the confined
runner, the completeness gate, the Crucible adapter, the docs
conformance checker, the kit self-test), the claim cards
(AV-01…AV-08, carried from v1.0; AV-03's Gate 0 line is
superseded in print for v1.1 runs by §D1), the agent
instructions, governance (including the standing offer of an
external run), and the vendored packages — ESP v2.4 and the
honesty plugin, byte-identical to v1.0's — plus the
demonstration record and its evidence: both CAL v2
administrations (the first CONDITIONAL on a battery-spec
defect, disclosed; the second PASS 6/6 for all four operators)
and both demonstration targets (the synthetic package and
Paper 12.5 v10, run on a scratch extraction; the delivered
tree was never written).

The build's adversarial loop pass (devil's advocate, evil
auditor, red team — read-only benches, charges adjudicated
with evidence) repaired nine defects after the first
demonstrations ran; each is recorded in CHANGELOG.md's build
addenda with its regression case, and the synthetic
demonstration was re-run on the frozen kit (DEMO_RECORD.md
carries the re-run disclosure).

## Verification on the final tree (after the last edit)

- Kit self-test: **66/66 checks passed** (run by the
  coordinator on the final tree, and again from a fresh
  extraction of the shipped zip; covers CAL v2 custody and
  its attack surface, the report pipeline's recompute
  discipline, the runner's confinement set, the ledger
  verdict split, the completeness ladder's differential
  domain, docs conformance, and verification of both shipped
  demonstration bundles — including from a relocated copy of
  the kit).
- Demonstrations (demo/DEMO_RECORD.md): synthetic target —
  S1 FAILED (as predicted), S2 PASSED-DEGRADED, S3 PASSED,
  overall COMPLETE-DEGRADED, completeness gate PASS, report
  ENGINE-VALIDATED, finding F-SYN-1 SUSTAINED through its
  full lifecycle; Paper 12.5 v10 — RB1 and H6 FAILED (as
  predicted; H6 by the §9 non-conformance disclosed in the
  ledger), the remaining instruments PASSED or
  PASSED-DEGRADED, overall COMPLETE-DEGRADED, completeness
  gate PASS, report ENGINE-VALIDATED.
- Predictions for both targets were lodged before any run
  (demo/PREDICTIONS.md, unedited) and matched, with three
  deviations explained in the record (V-3a, V-8a, V-9a) —
  none edited away.

## Manifest rule

`AAVEP_MANIFEST.sha256` covers every file in this kit
**except** itself, the freeze records (`AAVEP_FREEZE*`),
`ANCHOR.txt`, and the demonstration evidence
(`demo/evidence/**` — bundles carry their own internal
verification). Cache paths (`__pycache__`, `*.pyc`) are
unmanifestable and absent from the shipped tree. The zip
(`AAVEP_v1.1_open_source.zip`) contains the whole tree
including those files; verify with
`sha256sum -c AAVEP_MANIFEST.sha256` from the kit root of a
fresh extraction. A demonstration bundle verifies only under
the kit manifest it was recorded against (§D9) — the shipped
bundles were built against this frozen manifest.

## Anchor

`ANCHOR.txt` in this kit records, computed at creation: the
sha256 of this freeze record, and the two demonstration
ledgers' genesis and head hashes. The anchor is local to the
kit. **No external anchoring or publication has been made**
— that remains the author's act.
