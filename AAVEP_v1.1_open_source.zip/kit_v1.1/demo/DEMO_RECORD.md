# AAVEP v1.1 — Demonstration record

**What this is.** The first full exercise of the AAVEP v1.1 kit,
run 2026-11-12 against the two targets the author ruled on: a
synthetic fixture package (scriptable negative cases) and the
delivered Paper 12.5 v10 verification package (manuscript sha256
`d8dc26a6b4eff1cc79021f2ea37b3b6baf20de497184d3f9f36a426b91de1254`;
package zip sha256
`32ac55dc65776f73a7b72c03a8264b6694424c727671d9607679bfc8114d8507`;
in-package MANIFEST.sha256 file hash
`435bf53cef7108842741cf73f352caf41ebf2c7a3510dc632fdbf03f056c113e`,
the D4 pin). Predictions were lodged in `PREDICTIONS.md` **before**
any demonstration run and are not edited; deviations are recorded
below, never edited away.

**Self-status.** This demonstration does not change the kit's
self-status: AAVEP remains **DEMONSTRATION** until an external,
unaffiliated agent completes a full certified run (spec §1, SS-1).
Every report's anchoring stamp is **UNANCHORED** — no external
anchor exists; anchoring is the author's act. The Crucible state
for Paper 12.5 v10 is **NOT RUN**; the demonstration does not
manufacture one. Confinement was attempted and printed on every
run: **os-sandbox: network-namespace** was achieved on this
machine (attempt-and-print, per the author's ruling).

**Evidence.** `demo/evidence/synthetic/` carries the synthetic
run's complete bundle (workspace, ledger, report, envelope,
published-form calibration material, `verify_args.json`); the kit
selftest re-verifies it end-to-end.
<!-- bundle-path: demo/evidence/synthetic/report.json -->
<!-- bundle-path: demo/evidence/synthetic/workspace/statuses.json -->
<!-- bundle-path: demo/evidence/synthetic/ledger.jsonl -->
<!-- bundle-path: demo/evidence/synthetic/envelope.json -->
<!-- bundle-path: demo/evidence/synthetic/verify_args.json -->
<!-- bundle-path: demo/evidence/v10/report.json -->
<!-- bundle-path: demo/evidence/v10/ledger.jsonl -->
<!-- bundle-path: demo/evidence/v10/envelope.json -->
<!-- bundle-path: demo/evidence/v10/workspace/statuses.json --> `demo/evidence/v10/` carries
the v10 run's ledger, report, envelope, and workspace artifacts
(statuses, event log, lock table, spill outputs, store listing);
its scratch package copy and store contents are **not** shipped —
the scratch is byte-identical to the delivered v10 package
(hash-pinned in the lock table), and the store's source entries
are the author's published papers, identified by hash and DOI in
the manifest. The v10 report's recompute claim is therefore
scoped: it reproduces given the delivered package presented at
`--package`, which is how it was verified in the build work area
(verify exit 0). Failed and refused pre-runs are preserved in the
build work area and described where they belong below; they are
not shipped, and nothing in this record depends on them.

## Gate 0 — two administrations (ruling 5: the gate binds everybody)

Prediction A-1/A-3 held in form for both administrations: an
administrator agent distinct from every subject held custody;
administrator trees lived outside every run workspace; keys were
published after scoring; report pipelines grade the demonstration
receipts **RESCORED**.

**Administration #1 (morning build) — prediction A-2 FAILED.**
All four operators tiered **CONDITIONAL 5/6**, not the predicted
PASS 6/6:

| operator | tier | transcript sha256 |
|---|---|---|
| d-auditor | CONDITIONAL 5/6 | `98a9dd7a16f3361a…` |
| d-filer | CONDITIONAL 5/6 | `5284e77c0013a4fe…` |
| d-reproducer | CONDITIONAL 5/6 | `6134a29a05353689…` |
| d-adjudicator | CONDITIONAL 5/6 | `04f52dc41dd1aeb5…` |

All four missed exactly one trap, T5, on the same two points:
the enclosing heading written without its markdown markers
(3 of 4), and `section_sha256` computed as the governing file's
whole-file hash (4 of 4) where the scorer's canonical form is
the span's lines joined by "\n" with no trailing newline. The
substantive handling was correct in all four packets (defect
affirmed, correct claim, line, quote, badges). Adjudication:
**the battery was under-specified** — the serialization existed
only in the scorer's source code; no shipped document stated it,
and the shipped protocol spec did not even name the field. A
trap whose correct form is not derivable from the presented
materials measures telepathy, not discipline. The receipts stand
as issued; Gate 0 (PASS-only in the v1.1 runner) refused the
first synthetic attempt on them, and that refusal is part of
this record.

**Repair.** The CAL v2 specification gained §1.1, stating the
T5 packet's canonical serialization exactly (heading verbatim
with markers; the section-hash rule, with its deliberate
divergence from the file hash). The scorer's rule did not
change; the document caught up with it. The repair is also in
CHANGELOG.md.

**Administration #2 (completion pass) — under the repaired
spec.** Fresh sessions (new secrets, new fixtures), four new
subject agents, same administrator principal:

| operator | tier | session | commitment |
|---|---|---|---|
| d-auditor | PASS 6/6 | `0ad4058c…` | `ddfe2f0a11a21dce…` |
| d-filer | PASS 6/6 | `54af74de…` | `892e3b6cc5cce0cf…` |
| d-reproducer | PASS 6/6 | `766a8d44…` | `bfca877e212f132e…` |
| d-adjudicator | PASS 6/6 | `aba1f79b…` | `5aed63ddbf87a79a…` |

All four receipts grade **RESCORED** from administrator custody
and from the published keys. The demonstration below ran on
administration #2's receipts. Both administrations are the
record: #1 is what an under-specified battery produced; #2 is
what the same operators' discipline produced once the packet's
form was stated in the open. Neither is edited away.

## Kit defects found by this demonstration (repaired, regression-cased)

The synthetic target's first executed run failed all three
instruments, and the report path then refused twice more. Each
failure was a kit defect, not a target defect; each was repaired
and pinned with a selftest regression case before the shipped
runs were made:

1. **Runner path resolution.** The v1.1 rewrite had dropped
   v1.0's entry-point resolution of `--workspace`/`--package`
   to absolute paths; with a relative workspace, instrument argv
   double-resolved against the child cwd
   (`scratch/work_v1.1/…/scratch/scripts/…`) and every instrument
   failed on its own bytes. Restored in `aavep_run.py`;
   regression case `run-relative-workspace`.
2. **Receipt-grading fallback.** `verify_receipt` returned
   UNVERIFIED whenever the administrator re-score errored —
   including the published-form case of a redacted admin record
   presented with published keys. A completed divergent
   re-score stays decisive; an administrator path that cannot
   run now falls through to the keys grading. Regression case
   `cal2-redacted-admin-fallback`.
3. **Lock-table path recording.** Recorded paths are now
   workspace-relative inside the workspace, `package/<rel>`
   inside the target package, absolute only for genuinely
   external files; `compute_lock_table` resolves its inputs at
   entry. A shipped bundle's lock table recomputes identically
   from any tree location. Regression case
   `report-relative-paths`.
4. **Completeness-gate statuses.** The gate read v1.0's flat
   statuses shape and counted no v1.1 instrument as executed;
   it now accepts both shapes and counts PASSED-DEGRADED as
   executed coverage. Regression case
   `completeness-degraded-executed`.

## Target 1 — synthetic fixture package

Predicted vs actual:

| item | predicted | actual |
|---|---|---|
| S1 | FAILED (planted SYN-2 badge mismatch) | FAILED ✓ |
| S2 | PASSED-DEGRADED (UNCHECKABLE marker) | PASSED-DEGRADED (PARTIAL-MARKER) ✓ |
| S3 | PASSED (3 registry rows) | PASSED ✓ |
| overall | COMPLETE-DEGRADED | COMPLETE-DEGRADED ✓ |
| F-SYN-1 | filed → REPRODUCED_SAME_HOUSE → SUSTAINED; ENGINE-VALIDATED | as predicted ✓ |
| report verify | recomputes byte-identically; GENESIS GROUNDED; BOUND · UNANCHORED-BOUND | as predicted ✓ |
| completeness gate | (not predicted) | PASS |
| confinement | (attempt-and-print) | os-sandbox: network-namespace |

Ledger: genesis `aabede404123ab4d…`, head
`f897dac29c6c0414…`, 6 entries, chain valid. The finding's
lifecycle ran exactly in the predicted roles — d-filer filed
with an SL-2 packet (registry row at line 19 under
`## Appendix A. Claim registry`, span [14, 20]), d-reproducer
committed a phase-1 reading hash before unblinding and recorded
REPRODUCED_SAME_HOUSE, d-adjudicator sustained with
d-auditor's countersignature.

**Re-run disclosure (loop pass).** The synthetic demonstration
was executed three times in total: a first run that exposed
the four kit defects listed below (its workspace and statuses
were discarded; the finding lifecycle was never filed under
it), a second run on the repaired kit whose shipped bundle the
loop pass then found relocation-fragile (its S1 source locator
was an absolute build-machine path), and this final run,
executed on the frozen kit against the package in its shipped
location with a `{kit}`-relative locator — the only run whose
bundle ships. The lodged predictions predate all three runs
and matched the final run exactly, as they matched the
second.

## Target 2 — Paper 12.5 v10 (scratch copy; delivered tree read-only)

Preflight first, as predicted (V-1): the package's manifested
`.pyc` entries (five: two under `aavep/tools/__pycache__/`, three
under `instruments/ontology/__pycache__/`) were recorded as
**manifest defects** — charged to the package manifest's author
process, not reported as target tampering — and the run
proceeded.

| item | predicted | actual |
|---|---|---|
| RB1 | FAILED (H6 fails inside it) | FAILED ✓ — 25 of 26 suite instruments PASSED; sole failure `H6_registry_walker.py` |
| H6 | FAILED (§9 non-conformance) | FAILED ✓ — mechanism note below |
| H11 | PASSED | PASSED ✓ |
| IDX1 | PASSED | PASSED ✓ |
| plugin-provenance | PASSED (27/27) | PASSED ✓ |
| esp-conformance | PASSED (283/283) | PASSED ✓ |
| crucible-adapter | PASSED as an instrument, state NOT RUN | **PASSED-DEGRADED**, state NOT RUN · anchor UNANCHORED — deviation V-8a |
| overall | INCOMPLETE (two FAILED) | **COMPLETE-DEGRADED** — deviation V-9a |
| findings against the paper | none; ledger NOTE + one observation | as predicted ✓ |
| completeness gate | (not predicted) | PASS |
| report | (not predicted) | ENGINE-VALIDATED; verify exit 0; receipts RESCORED; BOUND · UNANCHORED-BOUND; GENESIS GROUNDED (bundle-internal pins) |

**Deviation V-3a (mechanism, not outcome).** V-3 predicted H6
would fail through `Path.home()` resolution under the runner's
redirected HOME. The sources did lock from the real house tree,
hashes matching, exactly as predicted — but the failure that
fired is the one printed in the run output (`spill/H6-1.out`):
invoked bare, H6 seeks its default target
`history/Paper_12_5_v4.md` — an unshipped path — resolving it
against the scratch tree, and exits 1. Both behaviours are the
same §9 non-conformance (run-time resolution outside the store,
already disclosed in v10's own build record, where a bare run
under the operator's real HOME passes 10/10); the ledger NOTE
records the mechanism that actually fired.

**Deviation V-8a.** The adapter's status is PASSED-DEGRADED,
not PASSED: "NOT RUN" is itself a member of the protocol-default
marker set (§6.1/B-32), so an adapter that honestly reports the
NOT RUN state necessarily carries a PARTIAL-MARKER degradation.
The state it reports is the predicted one (NOT RUN, anchor
UNANCHORED, no freeze record — the adapter cannot manufacture
one). The collision between a state-reporting instrument and
the marker set is recorded here as a design tension for v1.2;
the status prints whole, shortened nowhere.

**Deviation V-9a.** The overall is COMPLETE-DEGRADED, not the
predicted INCOMPLETE. The prediction misapplied the ladder:
under §6, FAILED instruments are executed outcomes (the audit
completed; the failures are its findings), and INCOMPLETE is
reserved for BLOCKED/TIMEOUT/UNRESOLVED required instruments —
the same semantics the v1.0 demonstration's Setting H showed
(COMPLETE with a FAILED instrument). With one PASSED-DEGRADED
of seven executed (not a majority), the ladder computes
COMPLETE-DEGRADED. The run is right; the prediction was wrong,
and it stands unedited in PREDICTIONS.md.

Ledger: genesis `a8ee36df38a0a207…`, head
`15d7707c426f39c0…`, 5 entries, chain valid. Per V-10, **no
findings were filed against the paper**: the ledger carries the
§9 non-conformance NOTE, the observation that the package's
embedded example manifest still describes v9
(`aavep/manifest/example_manifest.json`, manifest_id
`paper-12.5-v9-demonstration`), and d-auditor's NO_FINDING for
the demo claim-section with its self-disconfirmation. The
paper-side remedies (an H.6 rewrite with byte-hash pins and
store-mediated consumption; the package manifest's cache
entries; the paper printing its package-manifest hash) ride
the next paper version, per the design's boundary.

## Loop-pass addendum (2026-11-12)

The build's adversarial loop pass (devil's advocate, evil
auditor, red team) adjudicated the kit after this demonstration
ran. Two findings touch this record directly:

1. The published demonstration receipts originally carried
   `key_disclosure: withheld` although their keys were
   published beside them — a constructor defect (nothing
   upgraded the field at publication). The published forms
   were re-issued with `key_disclosure: published` under the
   repaired constructor; the field sits outside the transcript
   core hash, every receipt re-grades **RESCORED**, and the
   custody transcripts are untouched. The ledgers' genesis
   copies retain the receipts as presented at run time.
2. The red team's extra-file probe found the scorer did not
   enumerate subject trees (CAL spec §2.4's extra-file clause
   unimplemented). All eight demonstration subject trees were
   re-enumerated under the repaired rule: no extra files in
   either administration; the receipts above stand as issued.
3. The evil auditor found the second synthetic bundle
   location-dependent (an absolute source locator). The repair
   surfaced a fifth demonstration-found defect: preflight
   validated `{kit}` as a placeholder root but never
   substituted it in source locators, so a `{kit}`-relative
   source locked ABSENT. Both are repaired (locator
   resolution; regression cases `preflight-kit-locator` and
   `demo-bundle-relocated`), and the demonstration was
   re-run on the frozen kit (see the re-run disclosure
   above).

Disclosures the loop pass required in plain words:

- Administration #2's PASS receipts were earned on
  re-administration, after the battery specification — not any
  operator's handling — was repaired (§1.1 of the CAL v2
  spec). The protocol now enforces the re-attempt cap the
  spec always stated (a PASS after a FAIL tiers CONDITIONAL).
- The synthetic target's planted classes re-skin the
  battery's own trap classes (a badge disagreement of the T1
  form, a witness of the T5 form); the demonstration shows
  the pipeline's mechanics end-to-end, not discovery against
  an unscripted defect class.
- ADMINISTERED in this demonstration names house-internal
  split custody: distinct agent sessions under one
  coordinator, principals declared as strings (CAL_SPEC_v2
  §6). It is not independence from the house.
- The synthetic finding lifecycle was appended by the
  coordinator in one scripted sequence within a single
  session; its phase-1 commitment demonstrates the format,
  and the sequence's order is hash-chained and correct — the
  runner's EVENT_LOG_HEAD note precedes the findings by
  construction, so phase-1 cannot have been blinded in the
  strong sense here.
- Erratum: PREDICTIONS.md V-1 cites "§7.1 of the v1.1 spec"
  for the manifest rules; that is the design document's
  numbering — the shipped spec's site is §D6. The lodged
  predictions are unedited, as lodged.

The full adjudication (including the probes re-executed on the
final tree) is in the build record shipped with the kit's
release notes.

## What this demonstration does not show

No unaffiliated agent has run this kit; every operator is a
house agent, and the receipts' ADMINISTERED grade certifies
custody separation between house principals, not independence
from the house. The synthetic target was authored by the house
to exercise the ladder; the v10 target's FAILED cells were
predicted because they were already disclosed in v10's own
record. Discovery power against an unknown defect rests, as in
v1.0, on blind-variant evidence this demonstration does not
add. The kit's standing remains **DEMONSTRATION**.
