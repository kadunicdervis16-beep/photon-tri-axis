# Synthetic Audit Target (AAVEP v1.1 demonstration fixture)

## 0. Governance

The registry in Appendix A governs. Where a section and the
registry disagree, the registry's entry is the claim of record.

## 1. Claims

SYN-1: the consistency checker passes on this manuscript.
SYN-2 wears badge [LEVEL A: PROOF] at this home site.
SYN-3: the count checker reports three registry claims.

## Appendix A. Claim registry

| claim | badge |
|---|---|
| SYN-1 | [LEVEL A: MACHINE] |
| SYN-2 | [LEVEL A: MACHINE] |
| SYN-3 | [LEVEL A: MACHINE] |
