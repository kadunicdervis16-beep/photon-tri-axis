#!/usr/bin/env python3
# INPUT_PROVENANCE:
#   manuscript.md  (paper-defined: the synthetic target's own text,
#                   shipped in this fixture package)
"""S2 — partial checker (synthetic demonstration instrument).

Evaluates the two badge-shaped claims and declines the third:
SYN-3's wording ("reports three registry claims") is a claim
about a checker, not a checkable property of the text, so this
instrument prints the protocol's UNCHECKABLE marker for it and
still exits 0 — the PASSED-DEGRADED demonstration case.
"""
from pathlib import Path

Path("manuscript.md").read_text(encoding="utf-8")
print("evaluated 2 of 3 claims; UNCHECKABLE: SYN-3 is a claim "
      "about a checker, not a textual property")
