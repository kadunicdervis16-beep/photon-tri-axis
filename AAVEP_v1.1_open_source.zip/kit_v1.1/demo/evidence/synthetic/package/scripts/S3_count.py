#!/usr/bin/env python3
# INPUT_PROVENANCE:
#   manuscript.md  (paper-defined: the synthetic target's own text,
#                   shipped in this fixture package)
"""S3 — count checker (synthetic demonstration instrument).

Counts the claim rows in the governing registry; exits 0 iff the
count is exactly three.
"""
import re
import sys
from pathlib import Path

rows = re.findall(r"^\| SYN-\d+ \|", Path("manuscript.md")
                  .read_text(encoding="utf-8"), re.M)
print(f"{len(rows)} registry rows")
sys.exit(0 if len(rows) == 3 else 1)
