#!/usr/bin/env python3
# INPUT_PROVENANCE:
#   manuscript.md  (paper-defined: the synthetic target's own text,
#                   shipped in this fixture package; consumed from
#                   the working directory at run time)
"""S1 — consistency checker (synthetic demonstration instrument).

Compares each claim's home-site badge against the governing
registry (manuscript §0: the registry governs). Exits 1 and
prints MISMATCH for every claim whose two badges differ.
"""
import re
import sys
from pathlib import Path

text = Path("manuscript.md").read_text(encoding="utf-8")
home = dict(re.findall(r"^(SYN-\d+) wears badge (\[[^\]]+\])",
                       text, re.M))
registry = dict(re.findall(r"^\| (SYN-\d+) \| (\[[^\]]+\]) \|$",
                           text, re.M))
bad = 0
for cid in sorted(registry):
    if home.get(cid) and home[cid] != registry[cid]:
        print(f"MISMATCH {cid} home {home[cid]} "
              f"registry {registry[cid]}")
        bad += 1
if bad:
    print(f"S1: {bad} badge mismatch(es) against the governing "
          f"registry")
    sys.exit(1)
print("S1: all home-site badges match the governing registry")
