## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L5.6-PX | The claim text for L5.6-PX. | [LEVEL A] | A.6 | FINAL |
| L9.0-PX | Filler claim 0. | [LEVEL A] | A.1 | FINAL |
| L9.1-PX | Filler claim 1. | [LEVEL A] | A.1 | FINAL |

## Changelog

Entry 12 (historical, superseded): L5.6-PX was carried at [LEVEL A: MACHINE / PROOF / AUTHOR — script A.2] before the registry correction; the current registry row above governs.
