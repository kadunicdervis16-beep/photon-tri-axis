## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L5.6-PX | The claim text for L5.6-PX. | [LEVEL