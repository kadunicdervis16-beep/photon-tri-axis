# Target excerpt

**B.1 — Inherited claim.** **Inheritance:** Source: Paper X §7 — badge carried at source: [LEVEL A: AUTHOR — declared definition] (claim L5.9-PX).
