## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L5.9-PX | The claim text for L5.9-PX. | [LEVEL