# Target excerpt

**B.1 — Inherited claim.** **Inheritance:** Source: Paper X §7 — badge carried at source: [LEVEL B] (claim L5.9-PX).
