# Target excerpt

**B.1 — Inherited claim.** **Inheritance:** Source: Paper X §7 — badge carried at source: [LEVEL A: MACHINE / AUTHOR — script A.6] (claim L3.9-PX).
