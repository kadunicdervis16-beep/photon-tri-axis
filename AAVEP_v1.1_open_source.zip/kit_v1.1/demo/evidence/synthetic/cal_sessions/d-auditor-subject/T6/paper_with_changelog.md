## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L3.9-PX | The claim text for L3.9-PX. | [LEVEL A: MACHINE / PROOF / AUTHOR — script A.2] | A.6 | FINAL |
| L9.0-PX | Filler claim 0. | [LEVEL A] | A.1 | FINAL |
| L9.1-PX | Filler claim 1. | [LEVEL A] | A.1 | FINAL |

## Changelog

Entry 12 (historical, superseded): L3.9-PX was carried at [LEVEL A] before the registry correction; the current registry row above governs.
