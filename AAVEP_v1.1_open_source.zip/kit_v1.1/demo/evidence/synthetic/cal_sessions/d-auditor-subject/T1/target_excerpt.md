# Target excerpt

**B.1 — Inherited claim.** **Inheritance:** Source: Paper X §7 — badge carried at source: [LEVEL A: MACHINE / PROOF / AUTHOR — script A.2] (claim L3.9-PX).
