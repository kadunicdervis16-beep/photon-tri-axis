## Appendix B. Claim registry (STAGING — do not cite)

| Claim | Text | Badge | Script | Status |
| L3.9-PX | The claim text for L3.9-PX. | [LEVEL B] | A.6 | FINAL |
| L9.0-PX | Filler claim 0. | [LEVEL A] | A.1 | FINAL |
| L9.1-PX | Filler claim 1. | [LEVEL A] | A.1 | FINAL |
