## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L3.9-PX | The claim text for L3.9-PX. | [LEVEL