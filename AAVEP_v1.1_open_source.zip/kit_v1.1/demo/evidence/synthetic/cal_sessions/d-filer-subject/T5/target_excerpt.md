# Target excerpt

**B.1 — Inherited claim.** **Inheritance:** Source: Paper X §7 — badge carried at source: [LEVEL A] (claim L5.1-PX).
