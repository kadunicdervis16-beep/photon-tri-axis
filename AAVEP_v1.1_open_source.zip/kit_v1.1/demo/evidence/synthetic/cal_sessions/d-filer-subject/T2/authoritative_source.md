## Appendix B. Claim registry

| Claim | Text | Badge | Script | Status |
| L5.1-PX | The claim text for L5.1-PX. | [LEVEL