# AAVEP v1.1 demonstration — predictions, lodged before any run

Written 2026-11-12, before the calibration sessions were opened
and before either target was run. Deviations from this page are
recorded as deviations in DEMO_RECORD.md, with reasons; this page
is not edited after the runs.

## Administration predictions (both targets)

- A-1. Four house operators (d-auditor, d-filer, d-reproducer,
  d-adjudicator) are calibrated under AAVEP-CAL v2 by an
  administrator agent who is a *different agent* from every
  subject; administrator trees live outside every run workspace.
  Predicted grade: **ADMINISTERED** for all four sessions
  (administrator principal ≠ operator principals).
- A-2. Predicted tiers: all four operators **PASS 6/6** on their
  first attempts. (The battery is the house's own; a FAIL would
  be recorded, not retried silently — a re-run after FAIL caps
  at CONDITIONAL.)
- A-3. The administrator publishes the per-trap keys after
  scoring; both demonstrations' report pipelines therefore grade
  every genesis receipt **RESCORED**.

## Target 1 — synthetic fixture package

Instruments: S1 consistency checker, S2 partial checker,
S3 count checker (see synthetic_package/).

- S-1. **S1 FAILED** — the manuscript's SYN-2 home site wears
  [LEVEL A: PROOF] while the governing registry records
  [LEVEL A: MACHINE]; the checker exits 1 and prints the
  mismatch. This is the package's planted defect, by design.
- S-2. **S2 PASSED-DEGRADED** — exit 0, hard expectation met, but
  its output carries the protocol-default marker UNCHECKABLE.
- S-3. **S3 PASSED** — the registry holds exactly three claims.
- S-4. **Overall COMPLETE-DEGRADED** (one degraded of three
  executed required instruments is not a majority).
- S-5. Finding **F-SYN-1** (FALSE-CLAIM, claim SYN-2) completes
  the lifecycle: filed by d-filer with an SL-2 witness packet →
  REPRODUCED_SAME_HOUSE by d-reproducer under the two-phase rule
  → SUSTAINED by d-adjudicator → report built after adjudication
  grades the finding's packet verified and the stamp
  ENGINE-VALIDATED.
- S-6. Report verify recomputes the record byte-identically;
  genesis GENESIS GROUNDED (bundle-internal pins only);
  event-log binding BOUND · UNANCHORED-BOUND.

## Target 2 — Paper 12.5 v10 (scratch copy; delivered tree
read-only)

Package pins: manuscript sha256 d8dc26a6…; package
MANIFEST.sha256's own sha256 435bf53c… (the D4 pin — it lives in
this demonstration's manifest, since no governed artifact of the
paper's carries it yet).

- V-1. Preflight records the package's manifested `.pyc` entries
  (in `__pycache__/` directories) as **manifest defects** under
  §7.1 of the v1.1 spec — charged to the package manifest's
  author process, *not* reported as target tampering — and the
  run proceeds.
- V-2. **RB1 FAILED** — the suite runner exits non-zero because
  H.6 fails inside it under the runner's redirected HOME (V-3).
- V-3. **H6 FAILED** — its declared sources lock from the real
  house tree (they exist, hashes match), but H.6 resolves them
  again at run time through `Path.home()`; under the runner's
  HOME redirect the resolution lands in the runner-owned home
  and the walker exits 1. Recorded as the §9 non-conformance it
  is: external content must be consumed through the store. Under
  a bare run with the operator's real HOME, v10's own record
  shows H.6 passing 10/10 — both facts print in the record.
- V-4. **H11 PASSED** — Appendix I's AAVEP listings verify
  against the embedded tree and its pins.
- V-5. **IDX1 PASSED** — its v10 defaults are package-relative.
- V-6. **plugin-provenance PASSED** — the vendored plugin's
  provenance check over the package's scripts (27/27 at the v10
  build).
- V-7. **esp-conformance PASSED** — the vendored ESP v2.4
  conformance battery prints 283 passed, 0 failed.
- V-8. **crucible-adapter PASSED as an instrument, state
  NOT RUN** — no Crucible round exists for Paper 12.5 v10 and
  the adapter says so; the demonstration does not manufacture
  one.
- V-9. **Overall INCOMPLETE** (two FAILED instruments).
- V-10. No findings are filed against the paper in this
  demonstration: H.6's failure is a *protocol* non-conformance
  of the instrument's consumption pattern, already disclosed in
  v10's own build record — the run ledger carries a NOTE
  recording it and one further observation (the package's
  embedded example manifest still describes v9). The paper-side
  remedies ride the next paper version, per the design's
  boundary.
