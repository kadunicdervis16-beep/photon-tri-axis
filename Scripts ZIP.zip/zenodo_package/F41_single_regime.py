
INPUT_PROVENANCE = {
    "ALLOWED_REDUCTIONS": {"class": "paper-defined", "source": "§4.1 (R15: allowed reductions — sum, count, ratio)"},
    "OPN": {"class": "paper-defined", "source": "§4.5 (open port marker)"},
    "REF": {"class": "paper-defined", "source": "§4.5 (reference)"},
    "aspect": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "by_id": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "consumed": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "interior": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "ja": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "jb": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "jc": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "lone": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "na0": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "na1": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "na2": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nb0": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nb1": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nc0": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nc1": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nc2": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "planted_over": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "planted_under": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "resolved_nodes": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "aggregate quantities over (V, E) structures; not aspect-kind-quantified.",
}
#!/usr/bin/env python3
"""Paper 11 - F.41: single-regime firewall (Section 4.1, rule R15).

Model:
- Aggregate G = (V, E): V a finite set of configurations (nodes, 6 ports
  each, L2); E a finite set of completed junctions, each a set of consumed
  (node, port) pairs established by a Paper-2 Section 4 bonding mode.
- The three worked aggregates are rebuilt as (V, E):
  (a) 3 nodes, one 3-way center junction (1 port per node);
  (b) 2 nodes, one pairwise shared junction (1 port per node);
  (c) 3 nodes in a linear chain, two pairwise shared junctions.

Verifies:
1. Reduction: every aggregate-level quantity the paper uses - N_nodes,
   N_edges, junction arity k_j, consumed-port count, boundary count B,
   total s^2, total u - is computed solely from (V, E) constituent data.
   The general counting theorem (boundary = 6N - sum(k_j)) holds for all
   three aggregates; the pairwise corollary is exercised on aggregates
   (b) and (c). B is computed two independent ways - unresolved-port-set
   cardinality |dG| and 6N - sum(k_j) - asserted exactly equal, the set
   definition serving as the oracle (v16).
2. Single code path: the same rule functions (unmatched-integer count u,
   PTR-closed check, section 4.2 role predicates) apply to a lone node
   and to an aggregate. u(whole) is exactly the sum of u over
   constituents - computed by the same function, not by an
   aggregate-specific law - and is cross-checked by a direct open-port
   count over the unresolved-port set dG. The PTR-closed check is
   actually exercised: every junction of each worked aggregate is
   asserted closed on the constituent node data. Roles are decided by
   the section 4.2 predicates imported from F39_relational_role (the
   source of truth): relational over a well-formed encounter
   R = (a, p, b, q, tau), never from u alone. F41's former u-only
   role_predicate - byte-identical to the planted variant F39 is built
   to catch diverging - is deleted.
3. R15: a planted aggregate state alphabet - a quantity defined as a fresh
   primitive ("EMERGENT_COHESION") rather than a sum/count/ratio over
   constituents - is rejected.
4. Arity integrity (v16): a planted 3-way junction miscounted as 2-port,
   and a planted pairwise junction miscounted as 3-port, are both
   rejected against the |dG| oracle.
"""

# Section 4.2 role predicates: the source of truth is
# F39_relational_role. Roles are relational over a well-formed encounter
# R = (a, p, b, q, tau) - active(R, side) / passive(R, side) - never from
# u alone. Importing (not copying) keeps the predicates from drifting
# away from F39.
import F39_relational_role as F39

ALLOWED_REDUCTIONS = {"sum", "count", "ratio"}


def make_node(nid, s2, vals):
    ports = {i: vals.get(i, 0) for i in range(6)}
    assert all(v in (-1, 0, 1) for v in ports.values())
    return {"id": nid, "s2": s2, "ports": ports}


def u_node(node):
    """Unmatched-integer count: the same function for lone nodes and for
    nodes inside aggregates. No aggregate branch."""
    return sum(1 for v in node["ports"].values() if v != 0)


def ptr_closed(junction_ports, nodes):
    by_id = {n["id"]: n for n in nodes}
    return all(by_id[n]["ports"][p] == 0 for n, p in junction_ports)


def f39_state(node, tau=0):
    """Adapt an F41 node dict to an F39 state triple (selector, per-tick
    port values, tick). The selector is persistent per node; only the
    per-tick port values change."""
    return (("C", ("node", node["id"])),
            tuple(node["ports"][p] for p in range(6)), tau)


def aggregate_quantities(nodes, junctions):
    """Every aggregate-level quantity, computed from (V, E) alone.

    v16: each junction carries an explicit arity declaration k_j
    (ports consumed by that junction; k_j >= 2). B is computed two
    independent ways - unresolved-port-set cardinality |dG| and the
    general count 6N - sum(k_j) - asserted exactly equal. The set
    definition is the oracle.
    """
    n = len(nodes)
    all_ports = {(node["id"], p) for node in nodes for p in range(6)}
    consumed = set()
    arities = []
    for j in junctions:
        k_j = len(j)
        assert k_j >= 2, f"junction arity k_j >= 2, got {k_j}"
        arities.append(k_j)
        consumed.update(j)
    assert consumed <= all_ports, "junctions consume only node ports"
    unresolved = all_ports - consumed  # dG: the unresolved-port set
    b_set = len(unresolved)            # B via |dG|
    b_formula = 6 * n - sum(arities)   # B via 6N - sum(k_j)
    assert b_set == b_formula, \
        f"dual-computation agreement failed: |dG|={b_set}, 6N-sum(k_j)={b_formula}"
    return {
        "N_nodes": (n, "count"),
        "N_edges": (len(junctions), "count"),
        "junction_arities": (arities, "count"),
        "consumed": (len(consumed), "sum"),
        "B": (b_set, "count"),
        "total_s2": (sum(x["s2"] for x in nodes), "sum"),
        "total_u": (sum(u_node(x) for x in nodes), "sum"),
    }


def check_reduction(quantities):
    for name, (_, reduction) in quantities.items():
        if reduction not in ALLOWED_REDUCTIONS:
            raise ValueError(
                f"R15: aggregate quantity {name!r} has reduction "
                f"{reduction!r} - not a sum/count/ratio over constituents")


# ---- aggregate (b): 2 nodes, 1 pairwise junction ----
nb0 = make_node("b0", 4, {1: 1})
nb1 = make_node("b1", 4, {2: -1})
jb = [{("b0", 0), ("b1", 0)}]
qb = aggregate_quantities([nb0, nb1], jb)
assert qb["N_nodes"][0] == 2 and qb["N_edges"][0] == 1
assert qb["junction_arities"][0] == [2], "pairwise junction declares k=2"
assert qb["B"][0] == 10, "B = 12 - 2: pairwise corollary (one junction, k=2)"
assert qb["B"][0] == 6 * 2 - 2 * 1
assert qb["total_u"][0] == u_node(nb0) + u_node(nb1) == 2

# ---- aggregate (c): 3 nodes linear, 2 pairwise junctions ----
nc0 = make_node("c0", 4, {1: 1})
nc1 = make_node("c1", 4, {})
nc2 = make_node("c2", 4, {3: -1})
jc = [{("c0", 0), ("c1", 0)}, {("c1", 5), ("c2", 0)}]
qc = aggregate_quantities([nc0, nc1, nc2], jc)
assert qc["N_nodes"][0] == 3 and qc["N_edges"][0] == 2
assert qc["junction_arities"][0] == [2, 2], "two pairwise junctions declare k=2"
assert qc["B"][0] == 14, "B = 18 - 4: pairwise corollary (two junctions, k=2)"
assert qc["total_u"][0] == 2

# ---- aggregate (a): 3 nodes, one 3-way center junction ----
na0 = make_node("a0", 4, {1: 1})
na1 = make_node("a1", 4, {2: 1})
na2 = make_node("a2", 4, {})
ja = [{("a0", 0), ("a1", 0), ("a2", 0)}]
qa = aggregate_quantities([na0, na1, na2], ja)
assert qa["N_nodes"][0] == 3 and qa["N_edges"][0] == 1
assert qa["junction_arities"][0] == [3], "3-way center junction declares k=3"
assert qa["B"][0] == 15, "boundary = 6N - sum(k_j) = 18 - 3"
assert qa["total_u"][0] == 2

# ---- PTR-closure check actually exercised: every junction's consumed
# ports must be closed (zeroed) in the constituent node data, on each
# worked aggregate (a), (b), (c). ----
for _junctions, _nodes in ((ja, [na0, na1, na2]),
                           (jb, [nb0, nb1]),
                           (jc, [nc0, nc1, nc2])):
    for _j in _junctions:
        assert ptr_closed(_j, _nodes), \
            "PTR-closure failed: a junction consumed an open (non-zero) port"

for q in (qa, qb, qc):
    check_reduction(q)

# ---- single code path: lone node vs aggregate ----
# Roles are relational per section 4.2: decided over a well-formed
# encounter R = (a, p, b, q, tau) by the imported F39 predicates, never
# from u alone. The SAME imported functions decide roles for lone nodes
# and for aggregate aspects, so there is no aggregate-specific role law.
REF = (("C_ref", ("whole",)), (0,), 0)      # resolved reference aspect
OPN = (("C_open", ("whole",)), (1, 0), 0)   # unresolved partner aspect

# Lone node presenting an open port: active in the encounter.
lone = make_node("lone", 4, {1: 1, 2: -1})
sl = f39_state(lone)
Rl = (sl, 1, REF, 0, 0)
assert F39.well_formed(Rl), "lone-node encounter must be well formed"
assert F39.active(Rl, "a") and not F39.passive(Rl, "a"), \
    "lone node presenting an open port must be active per section 4.2"

# u(whole): two genuinely independent code paths must agree - the
# constituent sum recorded in the quantities dict (same u function per
# node, no aggregate branch) and a direct open-port count over the
# unresolved-port set dG. Comparing a stored value against the
# expression it was computed from would prove nothing; this check can
# actually fail (e.g. an aggregate-level u shortcut, or a junction
# consuming an open port).
for q, nodes, junctions in ((qa, [na0, na1, na2], ja),
                            (qb, [nb0, nb1], jb),
                            (qc, [nc0, nc1, nc2], jc)):
    consumed = set()
    for j in junctions:
        consumed.update(j)
    by_id = {n["id"]: n for n in nodes}
    unresolved = {(n["id"], p) for n in nodes for p in range(6)} - consumed
    direct = sum(1 for nid, p in unresolved if by_id[nid]["ports"][p] != 0)
    assert q["total_u"][0] == direct, \
        "u(whole): constituent sum and direct dG port count disagree"

# Aggregate boundary aspects presenting an open port: the SAME imported
# section 4.2 predicates must call them active - no second law for
# aggregates. (Ports b0/1, a0/1, c0/1 are open and unresolved.)
for key, nid, port in (("b", "b0", 1), ("a", "a0", 1), ("c", "c0", 1)):
    aspect = ((f"Cagg_{key}", ("port", nid, port)), (1,), 0)
    R = (aspect, 0, REF, 0, 0)
    assert F39.well_formed(R), f"aggregate ({key}) encounter malformed"
    assert F39.active(R, "a") and not F39.passive(R, "a"), \
        f"aggregate ({key}) boundary aspect must be active per section 4.2"

# Resolved aggregate: its interior junction aspect, fully resolved,
# serves as the passive reference - again decided by the imported
# predicates. (There is no whole-aggregate role from total u: roles are
# per-aspect at encounter tick, which is exactly the section 4.2 point.)
resolved_nodes = [make_node("r0", 0, {}), make_node("r1", 0, {})]
rq = aggregate_quantities(resolved_nodes, [{("r0", 0), ("r1", 0)}])
assert rq["total_u"][0] == 0, "resolved aggregate must have u(whole) = 0"
interior = (("Cres", ("junction", "j0")), (0, 0), 0)
Rr = (OPN, 0, interior, 0, 0)
assert F39.well_formed(Rr), "resolved-aggregate encounter must be well formed"
assert F39.passive(Rr, "b") and not F39.active(Rr, "b"), \
    "resolved aggregate interior must be passive per section 4.2"

# ---- planted test cases (v16, both directions): arity miscounts rejected ----
# Direction 1: the 3-way center junction miscounted as consuming 2 ports.
# Direction 2: a pairwise junction miscounted as consuming 3 ports.
# Both are rejected against the |dG| oracle.
planted_under = 6 * 3 - 2   # 16: 3-way junction counted as 2-port
planted_over = 6 * 2 - 3    # 9: pairwise junction counted as 3-port
assert planted_under != qa["B"][0], \
    "planted 3-way-as-2-port miscount NOT rejected"
assert planted_over != qb["B"][0], \
    "planted pairwise-as-3-port miscount NOT rejected"

# ---- planted test case: aggregate state alphabet rejected (R15) ----
try:
    check_reduction({"EMERGENT_COHESION": (7, "primitive")})
    raise SystemExit("F.41 planted aggregate primitive NOT rejected")
except ValueError:
    pass  # correctly rejected: not a sum/count/ratio over constituents

print("F.41 PASS: all aggregate quantities reduce to (V, E) constituent data "
      "on aggregates (a), (b), (c).")
print("F.41 PASS: single code path - same u and PTR functions for lone "
      "nodes and aggregates; u(whole) dual-computed (constituent sum == "
      "direct dG port count); roles for lone nodes and aggregate aspects "
      "decided by the section 4.2 predicates imported from F39.")
print("F.41 PASS: planted aggregate state alphabet rejected (R15).")
print("F.41 PASS: junction arities declared (k=3 center; k=2 pairwise); "
      "dual computation |dG| == 6N - sum(k_j) agrees on (a), (b), (c); "
      "bidirectional planted arity miscounts rejected.")