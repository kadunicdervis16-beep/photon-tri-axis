#!/usr/bin/env python3
"""Paper 11 - F.34: symbolic per-aspect s^2 decomposition of aggregate (b),
branch-ready over both consumption conventions.

Aggregate (b): two nodes joined by one shared pairwise junction (Appendix
B.2). Two documented consumption conventions, and the paper's own premises
do not adjudicate between them -- so this script verifies BOTH branches
independently and gates the §5 battery's final assembly on an explicit
BRANCH selection.

  Branch A (consume-O, §9 normalized convention): the State-5 node minus one
  O (port 4) and the State-6 node minus one O (port 4) -- junction ports
  (n0,4),(n1,4) -- 8 positive symbols, B = 10, boundary count vector (4,4,2).
  Provenance: §9, "One consumption convention is normalized for aggregate (b)
  and stated exactly" -- the State-5 node minus one O, the State-6 node minus
  one O.

  Branch B (complementary pair, Appendix B.2): one Y-dominant port from
  State 5 (port 1), one X-dominant port from State 6 (port 0) -- junction
  ports (n0,1),(n1,0) -- 6 positive symbols, B = 10. Provenance: B.2, "one
  Y-dominant port from State 5, one X-dominant from State 6" -- the paper's
  documented construction choice (grounded in Paper 2 §11.6 convergence).

Run modes:
  BRANCH unset   -> independent per-branch runs ONLY: each branch's
                    decomposition identity verified on its own input +
                    each branch's full 9-mutant battery. No battery
                    assembly; no branch is silently chosen. The
                    Decision-Q status is printed.
  BRANCH=A | B   -> independent per-branch runs, then final assembly for
                    the selected
                    branch: decomposition identity re-verified + the §5
                    counterfactual battery (18 = 2 nodes x 9 source rows).
  BRANCH=<other> -> LOUD FAILURE (exit nonzero). Never silently choose.

Shared machinery (F.33/F.35 core): same symbolic contribution rule, same
Route-1 enumeration, same arithmetic audit, same tautology guard, same 9
named planted mutants per branch. Branch-B mutants run against the branch-B
input (no cross-contamination).

The paper's Decision Q (which convention is the paper's canonical
aggregate-(b) decomposition input -- Branch B, complementary-pair,
Appendix B.2; recorded per swarm recommendation 2026-09-26, confirmed by
the author's direct decision 2026-09-27) stays OUTSIDE the machine check; this
script verifies both branches independently and reports the paper's recorded
decision, it does not make it.

Coverage map (verification-rigor standard):
  (1) Native domain: Appendix B.2's per-aspect s^2 decomposition of aggregate
      (b) -- the native Stage-N claim that the two-node aggregate's s^2
      workload decomposes exactly over its aspects, under either consumption
      convention.
  (2) Verified domain: the finite formal model -- the section-2 contribution
      assignment applied to the paper-defined per-branch input (Table 5.1
      triples; §9 junction table for branch A; Appendix B.2 junction table
      for branch B), checked by enumeration (Route 1) plus an independent
      arithmetic audit, with both branches verified independently.
  (3) Map: native aspect (node / junction / boundary port) -> formal aspect in
      A(G); native "resolved" (§6.1; the Tracking-Cost Lemma §7.3 compels 0
      at port grain only -- the aspect-level 0-attribution is the declared
      partition rule, consistent with (not compelled by) the lemma) ->
      contribution exactly 0; native "open port presenting unmatched tilt"
      -> positive formal symbol u_(v,p); S^2(G) := sum_{a in A(G)} c(a)
      (R15, §4.1).
  (4) Preserved: the exact port partition (B = 6N - sum(k_j), dual-computed),
      the zero/nonnegative contribution pattern, the symbolic-sum identity,
      symbol distinctness, aspect coverage (every aspect exactly once).
  (5) Outside the machine check: physical s^2 magnitudes (Paper 8 cited, never
      reproduced); the premises themselves (Tracking-Cost Lemma, §6.1, the
      branch-convention choices, the declared rule-(ii) choice); WHICH branch
      is canonical (the Decision Q -- Branch B by author decision
      (recorded 2026-09-26, confirmed directly 2026-09-27); the machine verifies both branches regardless); content
      input errors -- including the sharp outcome-changing instance of the
      content-error residual: a junction-table CONTENT swap that is
      structurally valid (pairwise-disjoint, arity == port-list length,
      indices 0..5, node ids valid) but consumes the wrong ports --
      {(n0,0),(n1,4)} (an X-valued port) instead of the branch-A
      {(n0,4),(n1,4)} (consume-O) -- moves symbols_expected 8 -> 7 and
      port_zeros_expected 2 -> 3 with checks 1-7 all green; the only machine
      backstop is the hardcoded per-branch expectation literal in
      verify_branch; the hardcoded-script residual -- all caught only by the
      independent re-read, never by the machine.

Badge:
"Level A conditional on the Tracking-Cost Lemma (port-level composition), §6.1, §5.1 Table 5.1 and its
boundary-tuple stipulation, the R15 sum rule and Port Count Invariance (§4.3),
the junction arity >= 2 rule, and the Appendix B / §9 / F.41 construction
premises; the machine checks the counting, not the premises."
The State-9 contribution rule (ii) is a declared Tracking-Cost-consistent
disambiguation.

Method notes (§4 of the build plan):
- Route 1 ranges over boundary ports dG ONLY (the Route-1 boundary-only rule); a consumed port reaching
  the emitter is a hard error, never a zero term.
- The arithmetic audit predicts the term multiset's SHAPE by count-vector
  arithmetic (interior-zeros half a fixed point; symbol-count and
  port-zero halves independent predictions). Both routes share the full
  input; the plan no longer pretends otherwise. Plan-faithfulness note: the
  plan's check-3 text ('exactly zeros_expected integer-0 terms' with
  zeros_expected = N+|E|) is unsatisfiable as written, because §2 also emits
  integer 0 for O-valued boundary ports; the audit therefore predicts
  port_zeros_expected by count vectors as well; check 3 asserts the full
  shape.
- The tautology guard (check 7) is necessary-but-insufficient (mutant_4
  rejected by the guard; mutant_0 vacuity caught by checks 3+5).
- Analytic open-X/Y tight bounds are machine-verified per branch: branch A
  >= 3, branch B >= 2 open X/Y per (node, row). Branch B's tight bound is 2,
  not 3: substitutions s in {1e,1p,2,3} at either branch-B node leave exactly
  2 open X/Y (the consumed port carries the third); the machine's tally, not
  the looser draft figure, is the tight bound.
"""

import ast as _ast
import os as _os
import sys
from collections import Counter
from fractions import Fraction

# ---------------------------------------------------------------------------
# INPUT_PROVENANCE (P1/P2 interface): every module-level source name declared.
# Classes: paper-defined | cited-paper | declared-assumption | control |
#          arbitrary-representative. ast.literal_eval-able (self-checked below).
# NOTE: the Tracking-Cost Lemma (§7.3), Bonding-Reduces-Port-Openness (§6.1),
# the R15 exact-finite-sum rule (§4.1), and the State-9 rule-(ii)
# disambiguation are encoded in the contribution/summation logic below, not
# bound as module-level inputs; the Level-A conditionality on them is stated
# in the docstring's epistemic boundary, so they are not declared here.
# NOTE 2: the §9 branch-A anchors are omitted deliberately -- the normalized
# consumption-convention sentence lives in §9.3's "Aggregate-(b) completion"
# subsection (v55 renumbering: old §9.x); the source text names the convention
# exactly.
# ---------------------------------------------------------------------------
INPUT_PROVENANCE = {
    "STATE_ROWS": {"class": "paper-defined",
                   "source": "§5.1 Table 5.1 (Outside Content boundary tuples)",
                   "anchor": "Outside Content"},
    "AGG_B_A_TRIPLES": {"class": "paper-defined",
                        "source": "§9 normalized consumption convention "
                                  "(State-5 node minus one O; State-6 node minus one O)"},
    "AGG_B_A_JUNCTION": {"class": "paper-defined",
                         "source": "§9 normalized consumption convention (consume-O junction)"},
    "AGG_B_B_TRIPLES": {"class": "paper-defined",
                        "source": "Appendix B.2 complementary-pair construction",
                        "anchor": "one Y-dominant port from State 5, one X-dominant from State 6"},
    "AGG_B_B_JUNCTION": {"class": "paper-defined",
                         "source": "Appendix B.2 complementary-pair construction",
                         "anchor": "the shared outer-to-outer junction"},
    "BATTERY_ROWS": {"class": "paper-defined",
                     "source": "§5.1 Table 5.1 (source rows 1-8)",
                     "anchor": "Outside Content"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port', 'junction', 'node'],
    "notes": "per-aspect decomposition: contributions emitted over node/junction/port aspects; the whole kind is not exercised.",
}
_ast.literal_eval(repr(INPUT_PROVENANCE))  # interface self-check: literal-evaluable

STATE_ROWS = {
    "9":  ("X", "X", "X", "Y", "Y", "Y"),
    "1e": ("Y", "Y", "Y", "O", "O", "O"),
    "1p": ("X", "X", "X", "O", "O", "O"),
    "2":  ("X", "Y", "Y", "O", "O", "O"),
    "3":  ("X", "X", "Y", "O", "O", "O"),
    "4":  ("X", "X", "Y", "Y", "O", "O"),
    "5":  ("X", "Y", "Y", "Y", "O", "O"),
    "6":  ("X", "X", "X", "Y", "O", "O"),
    "7":  ("X", "X", "Y", "Y", "Y", "O"),
    "8":  ("X", "X", "X", "Y", "Y", "O"),
}
BATTERY_ROWS = ["1e", "1p", "2", "3", "4", "5", "6", "7", "8"]

# Branch A (consume-O): State-5 node minus one O (port 4), State-6 node minus
# one O (port 4) -- §9 normalized convention.
AGG_B_A_TRIPLES = {"n0": "5", "n1": "6"}
AGG_B_A_JUNCTION = {
    "j0": {"ports": [("n0", 4), ("n1", 4)], "arity": 2},
}
# Branch B (complementary pair): Y-dominant port from State 5 (port 1),
# X-dominant port from State 6 (port 0) -- Appendix B.2.
AGG_B_B_TRIPLES = {"n0": "5", "n1": "6"}
AGG_B_B_JUNCTION = {
    "j0": {"ports": [("n0", 1), ("n1", 0)], "arity": 2},
}


class CheckRejected(Exception):
    """A verification check rejected its input; carries the printed witness."""
    def __init__(self, witness):
        super().__init__(witness)
        self.witness = witness


class TermLedger(object):
    """An aspect-covering term multiset produced by a route's own per-aspect
    classification. The tautology guard (check 7) accepts ONLY TermLedgers: a
    fiat total (int/Fraction) has no per-aspect provenance and is rejected as
    a method, not as bad data."""
    def __init__(self, aspect_terms, source):
        aspects = [a for a, _ in aspect_terms]
        if len(set(aspects)) != len(aspects):
            dupes = sorted({a for a in aspects if aspects.count(a) > 1}, key=str)
            raise CheckRejected(
                "not aspect-covering: duplicate aspect emission %r" % (dupes,))
        self.aspect_terms = list(aspect_terms)
        self.aspects = frozenset(aspects)
        self.source = source

    def term_counter(self):
        return Counter(t for _, t in self.aspect_terms)


class Aggregate(object):
    """A bonded aggregate: node set V (node_id -> state-row key) + junction
    table E (junction_id -> {ports: [(node, idx)], arity: k})."""
    def __init__(self, name, triples, junctions):
        self.name = name
        self.triples = dict(triples)
        self.junctions = {j: {"ports": list(d["ports"]), "arity": d["arity"]}
                          for j, d in junctions.items()}
        self.nodes = sorted(self.triples)

    def all_ports(self):
        return {(v, p) for v in self.nodes for p in range(6)}

    def consumed(self):
        return {(v, p) for d in self.junctions.values() for (v, p) in d["ports"]}

    def boundary(self):
        return self.all_ports() - self.consumed()

    def aspect_set(self):
        A = {("node", v) for v in self.nodes}
        A |= {("junction", j) for j in self.junctions}
        A |= {("port", v, p) for (v, p) in self.boundary()}
        return A


def emit_contribution(agg, aspect, consumed):
    """c(a) for one aspect. consumed = the consumed-port set the route reads."""
    kind = aspect[0]
    if kind == "node":
        return 0
    if kind == "junction":
        return 0  # NO junction s^2 is ever introduced
    _, v, p = aspect
    if (v, p) in consumed:
        raise CheckRejected(
            "consumed port (%r,%d) reached the Route-1 emitter "
            "(Route-1 boundary-only hard error: consumed ports are not aspects of A(G))" % (v, p))
    row = agg.triples[v]
    val = STATE_ROWS[row][p]
    if val == "O":
        return 0  # disjunct (i)
    if row == "9":
        return 0  # disjunct (ii): declared Tracking-Cost-consistent choice
    return ("u", v, p)


def route1_enumerate(agg, consumed):
    """Route 1 (§4): enumerate every aspect of A(G); the port loop ranges over
    the boundary-port set ONLY."""
    terms = []
    for v in agg.nodes:
        terms.append((("node", v), emit_contribution(agg, ("node", v), consumed)))
    for j in sorted(agg.junctions):
        terms.append((("junction", j), emit_contribution(agg, ("junction", j), consumed)))
    for (v, p) in sorted(agg.all_ports() - consumed):
        a = ("port", v, p)
        terms.append((a, emit_contribution(agg, a, consumed)))
    return TermLedger(terms, source="route1")


def check2_input_validation(agg):
    """Input validation: junction port lists pairwise disjoint; arity
    declaration == port-list length; port index in 0..5; node id in V."""
    seen = {}
    for j in sorted(agg.junctions):
        d = agg.junctions[j]
        ports = d["ports"]
        if d["arity"] != len(ports):
            raise CheckRejected(
                "junction %r: arity declaration k=%d != port-list length %d"
                % (j, d["arity"], len(ports)))
        if d["arity"] < 2:
            raise CheckRejected("junction %r: arity %d < 2" % (j, d["arity"]))
        for (v, p) in ports:
            if v not in agg.triples:
                raise CheckRejected("junction %r names unknown node %r" % (j, v))
            if not (isinstance(p, int) and 0 <= p <= 5):
                raise CheckRejected("junction %r: port index %r outside 0..5" % (j, p))
            if (v, p) in seen:
                raise CheckRejected(
                    "port (%r,%d) listed in two junctions: %r and %r"
                    % (v, p, seen[(v, p)], j))
            seen[(v, p)] = j
    if not agg.consumed() <= agg.all_ports():
        raise CheckRejected("consumed port outside node port range")


def check6_port_invariants(agg):
    """|dG| = 6N - sum(k_j) (dual computation); consumed u dG partition."""
    N = len(agg.nodes)
    ksum = sum(d["arity"] for d in agg.junctions.values())
    B_set = len(agg.boundary())
    B_formula = N * 6 - ksum
    if B_set != B_formula:
        raise CheckRejected(
            "|dG|=%d != 6N-sum(k_j)=%d (dual computation disagrees)"
            % (B_set, B_formula))
    consumed, boundary, allp = agg.consumed(), agg.boundary(), agg.all_ports()
    if consumed & boundary:
        raise CheckRejected("consumed intersect dG nonempty: %r"
                            % sorted(consumed & boundary))
    if consumed | boundary != allp:
        raise CheckRejected("consumed union dG != all %d node ports" % len(allp))


def xy_count(row):
    return sum(1 for v in STATE_ROWS[row] if v in ("X", "Y"))


def o_count(row):
    return sum(1 for v in STATE_ROWS[row] if v == "O")


def arithmetic_audit(agg):
    """The arithmetic audit (§4): count-vector SHAPE prediction without
    per-port term emission. zeros_expected (interior) is a fixed point;
    symbols_expected and port_zeros_expected are the independent predictions.
    Plan-faithfulness note: the plan's check-3 text is unsatisfiable as
    written (§2 also emits 0 for O-valued boundary ports); the audit predicts
    port_zeros_expected by count vectors as well."""
    N = len(agg.nodes)
    E = len(agg.junctions)
    zeros_expected = N + E
    n_s = Counter(agg.triples.values())
    total_xy = sum(n * xy_count(s) for s, n in n_s.items())
    total_o = sum(n * o_count(s) for s, n in n_s.items())
    consumed_xy = sum(1 for (v, p) in agg.consumed()
                      if STATE_ROWS[agg.triples[v]][p] in ("X", "Y"))
    consumed_o = sum(1 for (v, p) in agg.consumed()
                     if STATE_ROWS[agg.triples[v]][p] == "O")
    state9_xy_boundary = sum(
        1 for (v, p) in agg.boundary()
        if agg.triples[v] == "9" and STATE_ROWS["9"][p] in ("X", "Y"))
    state9_o_boundary = sum(
        1 for (v, p) in agg.boundary()
        if agg.triples[v] == "9" and STATE_ROWS["9"][p] == "O")
    symbols_expected = total_xy - consumed_xy - state9_xy_boundary
    port_zeros_expected = (total_o - consumed_o - state9_o_boundary
                           + state9_xy_boundary)
    return {"zeros_expected": zeros_expected,
            "port_zeros_expected": port_zeros_expected,
            "symbols_expected": symbols_expected, "N": N, "E": E}


def check1_aspect_covering(ledger, agg):
    if ledger.aspects != agg.aspect_set():
        missing = sorted(agg.aspect_set() - ledger.aspects, key=str)
        extra = sorted(ledger.aspects - agg.aspect_set(), key=str)
        raise CheckRejected(
            "aspect coverage: missing=%r extra=%r" % (missing, extra))


def _is_int_zero(t):
    return type(t) is int and t == 0


def check3_audit_shape(ledger, audit, agg):
    interior_zeros = sum(1 for a, t in ledger.aspect_terms
                         if a[0] in ("node", "junction") and _is_int_zero(t))
    if interior_zeros != audit["zeros_expected"]:
        raise CheckRejected(
            "audit shape: %d integer-0 terms on interior aspects, audit "
            "expects %d (= N+|E|)" % (interior_zeros, audit["zeros_expected"]))
    port_zeros = sum(1 for a, t in ledger.aspect_terms
                     if a[0] == "port" and _is_int_zero(t))
    if port_zeros != audit["port_zeros_expected"]:
        raise CheckRejected(
            "audit shape: %d integer-0 terms on boundary ports, audit "
            "expects %d" % (port_zeros, audit["port_zeros_expected"]))
    tc = ledger.term_counter()
    symbols = [t for t in tc if t != 0]
    # No pairwise-distinctness assertion here: iterating a Counter yields
    # unique keys, so a distinctness comparison over `symbols` could never
    # fire (dead assertion removed; loop-back fix). Distinctness is enforced
    # solely by check5_symbol_hygiene, which iterates the raw term list.
    nsym = sum(tc[t] for t in symbols)
    if nsym != audit["symbols_expected"]:
        raise CheckRejected(
            "audit shape: %d positive-symbol occurrences, audit expects %d"
            % (nsym, audit["symbols_expected"]))


def check4_zero_audit(ledger, agg):
    for a, t in ledger.aspect_terms:
        kind = a[0]
        if kind in ("node", "junction"):
            if not _is_int_zero(t):
                raise CheckRejected(
                    "interior aspect %r carries non-zero term %r "
                    "(no fiat junction s^2)" % (a, t))
        else:
            _, v, p = a
            val = STATE_ROWS[agg.triples[v]][p]
            if (val == "O" or agg.triples[v] == "9") and not _is_int_zero(t):
                raise CheckRejected(
                    "port aspect %r (value %r, row %r) carries non-zero term %r"
                    % (a, val, agg.triples[v], t))


def check5_symbol_hygiene(ledger, agg):
    symbols = [t for _, t in ledger.aspect_terms if t != 0]
    # Term-shape assertion (loop-back fix for G1/G2): "positive formal
    # symbol" is a machine-checked shape, not prose. The emitter's
    # representation of an open tilt-presenting aspect is exactly the tuple
    # ("u", v, p). Distinct negative ints, distinct positive ints, and
    # distinct strings formerly passed checks 1,3,4,5,7 -- the machine only
    # checked "distinct nonzero terms" while the badge claimed "positive
    # formal symbols", and the prose S^2(G) >= S^2(G') corollary needs
    # nonnegativity.
    for t in symbols:
        if not (type(t) is tuple and len(t) == 3 and t[0] == "u"):
            raise CheckRejected(
                "symbol hygiene: nonzero term %r is not a positive formal "
                "symbol ('u', v, p) tuple" % (t,))
    if len(set(symbols)) != len(symbols):
        raise CheckRejected("symbol hygiene: positive symbols not pairwise distinct")
    tally = sum(1 for (v, p) in agg.boundary()
                if STATE_ROWS[agg.triples[v]][p] in ("X", "Y")
                and agg.triples[v] != "9")
    if len(symbols) != tally:
        raise CheckRejected(
            "symbol hygiene: %d positive symbols vs independently tallied %d "
            "open-X/Y-on-non-9 boundary ports" % (len(symbols), tally))


def check7_tautology_guard(ledger, agg, context=""):
    if not isinstance(ledger, TermLedger):
        witness = ("fiat total without per-aspect provenance -- round-trip "
                   "division is not a decomposition check")
        print("WITNESS check7/tautology-guard [%s]: %s" % (context, witness))
        raise CheckRejected(witness)
    check1_aspect_covering(ledger, agg)
    return True


def verify_decomposition(agg, label):
    check2_input_validation(agg)
    check6_port_invariants(agg)
    ledger = route1_enumerate(agg, agg.consumed())
    audit = arithmetic_audit(agg)
    check1_aspect_covering(ledger, agg)
    check3_audit_shape(ledger, audit, agg)
    check4_zero_audit(ledger, agg)
    check5_symbol_hygiene(ledger, agg)
    check7_tautology_guard(ledger, agg, label)
    return ledger, audit


# ---------------------------------------------------------------------------
# §5 counterfactual-robustness battery.
# ---------------------------------------------------------------------------
def positive_symbol_aspects(agg, triples):
    sub = Aggregate(agg.name, triples, agg.junctions)
    ledger = route1_enumerate(sub, sub.consumed())
    return {a for a, t in ledger.aspect_terms if t != 0}


def battery_tilt_removal(agg, pinned_nodes, f7_min):
    n = 0
    for v in pinned_nodes:
        for s in BATTERY_ROWS:
            G_s = dict(agg.triples)
            G_s[v] = s
            assert STATE_ROWS[G_s[v]] == STATE_ROWS[s], \
                "substitution did not take effect at node %r" % v
            U = positive_symbol_aspects(agg, G_s)
            sub = Aggregate(agg.name, G_s, agg.junctions)
            assert len(U) == arithmetic_audit(sub)["symbols_expected"], \
                "battery emission disagrees with the audit count vector"
            for w in sub.nodes:
                open_xy = sum(1 for (vv, p) in sub.boundary() if vv == w
                              and STATE_ROWS[G_s[w]][p] in ("X", "Y"))
                assert open_xy >= f7_min[w], \
                    "analytic open-X/Y bound violated at (%r, %r): %d" % (w, s, open_xy)
                assert open_xy >= 1, "precondition violated at (%r, %r)" % (w, s)
            G_9 = dict(G_s)
            G_9[v] = "9"
            U9 = positive_symbol_aspects(agg, G_9)
            assert U9 < U, "§5 strictness failed at (%r, %r)" % (v, s)
            assert len(U9) < len(U)
            n += 1
    return n


# ---------------------------------------------------------------------------
# §8 planted-mutant battery (per branch). EVERY planted-variant
# function/builder/fixture carries planted/mutant/witness in its name.
# ---------------------------------------------------------------------------
def mutant_0_all_zero_route(agg, witness_ctx_mutant_0):
    terms = [(a, 0) for a in sorted(agg.aspect_set(), key=str)]
    ledger = TermLedger(terms, source="mutant_0_all_zero_route")
    check7_tautology_guard(ledger, agg, witness_ctx_mutant_0)
    audit = arithmetic_audit(agg)
    try:
        check5_symbol_hygiene(ledger, agg)
    except CheckRejected:
        print("WITNESS mutant_0_all_zero_route [%s]: vacuous all-zero route "
              "rejected -- 0 positive symbols vs independently tallied %d "
              "open-X/Y-on-non-9 (tautology guard passed: it checks shape, "
              "not content)" % (witness_ctx_mutant_0, audit["symbols_expected"]))
        return True
    raise AssertionError("mutant_0 NOT rejected")


def mutant_1_invented_junction_s2(agg, witness_ctx_mutant_1):
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        if a[0] == "junction":
            terms.append((a, ("u_junction_mutant_1", a[1])))
        else:
            terms.append((a, t))
    ledger = TermLedger(terms, source="mutant_1_invented_junction_s2")
    try:
        check4_zero_audit(ledger, agg)
    except CheckRejected as e:
        print("WITNESS mutant_1_invented_junction_s2 [%s]: fiat junction "
              "s^2 rejected -- %s" % (witness_ctx_mutant_1, e.witness))
        return True
    raise AssertionError("mutant_1 NOT rejected")


def mutant_2_resolved_port_positive(agg, witness_port_mutant_2, witness_ctx_mutant_2):
    assert witness_port_mutant_2 in agg.consumed()
    variant_consumed = agg.consumed() - {witness_port_mutant_2}
    ledger = route1_enumerate(agg, variant_consumed)
    audit = arithmetic_audit(agg)
    try:
        check3_audit_shape(ledger, audit, agg)
    except CheckRejected as e:
        print("WITNESS mutant_2_resolved_port_positive [%s]: consumed port %r "
              "misclassified as open -- %s"
              % (witness_ctx_mutant_2, witness_port_mutant_2, e.witness))
        return True
    raise AssertionError("mutant_2 NOT rejected")


def mutant_3_table_double_count(agg, witness_fixture_mutant_3_table,
                                witness_ctx_mutant_3):
    variant = Aggregate(agg.name + "/mutant_3", agg.triples,
                        witness_fixture_mutant_3_table)
    try:
        check2_input_validation(variant)
    except CheckRejected as e:
        print("WITNESS mutant_3_table_double_count [%s]: %s"
              % (witness_ctx_mutant_3, e.witness))
        return True
    raise AssertionError("mutant_3 NOT rejected")


def mutant_4_legacy_proof(agg, witness_ctx_mutant_4):
    s2_total = Fraction(25)
    n = len(agg.nodes) + len(agg.junctions)
    try:
        check7_tautology_guard(s2_total / n * n, agg, witness_ctx_mutant_4)
    except CheckRejected:
        return True  # witness printed by the guard
    raise AssertionError("mutant_4 NOT rejected")


def mutant_5_order_violation(agg, witness_node_mutant_5, witness_ctx_mutant_5):
    v = witness_node_mutant_5
    G_1 = dict(agg.triples); G_1[v] = "1e"
    G_9 = dict(G_1); G_9[v] = "9"
    U1 = positive_symbol_aspects(agg, G_1)
    U9 = positive_symbol_aspects(agg, G_9)
    assert len(U9) < len(U1), "§5 strictness premise failed"
    variant_claim_holds = len(U9) >= len(U1)
    if not variant_claim_holds:
        print("WITNESS mutant_5_order_violation [%s]: State-1->State-9 "
              "substitution on node %r of %r strictly decreases positive "
              "symbols: |U(G)|=%d -> |U(G')|=%d; the 'does not decrease' "
              "claim is rejected (conditional on the declared rule (ii))"
              % (witness_ctx_mutant_5, v, agg.name, len(U1), len(U9)))
        return True
    raise AssertionError("mutant_5 NOT rejected")


def mutant_6_uniform_division(agg, witness_ctx_mutant_6):
    audit = arithmetic_audit(agg)
    S = audit["symbols_expected"]
    n_interior = len(agg.nodes) + len(agg.junctions)
    share = Fraction(S, n_interior)
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        terms.append((a, share) if a[0] in ("node", "junction") else (a, t))
    variant = TermLedger(terms, source="mutant_6_uniform_division")
    try:
        check4_zero_audit(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_6_uniform_division [%s]: uniform division "
              "rejected -- %s (divided share %s)"
              % (witness_ctx_mutant_6, e.witness, share))
        return True
    raise AssertionError("mutant_6 NOT rejected")


def mutant_7_o_port_positive(agg, witness_port_mutant_7, witness_ctx_mutant_7):
    v, p = witness_port_mutant_7
    assert (v, p) in agg.boundary()
    assert STATE_ROWS[agg.triples[v]][p] == "O"
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        terms.append((a, ("u_mutant_7", v, p))
                     if a == ("port", v, p) else (a, t))
    variant = TermLedger(terms, source="mutant_7_o_port_positive")
    try:
        check4_zero_audit(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_7_o_port_positive [%s]: %s"
              % (witness_ctx_mutant_7, e.witness))
        return True
    raise AssertionError("mutant_7 NOT rejected")


def mutant_8_negative_terms(agg, witness_ctx_mutant_8):
    """Positive-symbol SHAPE mutant (loop-back fix for G1/G2): emits DISTINCT
    NEGATIVE INTS on open X/Y ports in place of positive formal symbols.
    This variant passed checks 1, 3, 4, 5, and 7 on the old code -- the
    machine checked only 'distinct nonzero terms' while the badge claimed
    'positive formal symbols', and the prose S^2(G) >= S^2(G') corollary
    needs nonnegativity, so a negative-term variant passing silently is a
    genuine spec violation. Rejected by the check-5 term-shape assertion
    (every nonzero term must be a ('u', v, p) tuple); the witness prints the
    first offending term."""
    terms = []
    k = 0
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        if a[0] == "port" and t != 0:
            k += 1
            terms.append((a, -(1000 + k)))
        else:
            terms.append((a, t))
    variant = TermLedger(terms, source="mutant_8_negative_terms")
    try:
        check5_symbol_hygiene(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_8_negative_terms [%s]: %s"
              % (witness_ctx_mutant_8, e.witness))
        return True
    raise AssertionError("mutant_8 NOT rejected")


def selftest_arity_crosscheck_rejects(agg, witness_ctx_selftest):
    bad = {j: {"ports": list(d["ports"]), "arity": d["arity"]}
           for j, d in agg.junctions.items()}
    j0 = sorted(bad)[0]
    bad[j0] = {"ports": bad[j0]["ports"][:-1], "arity": bad[j0]["arity"]}
    variant = Aggregate(agg.name + "/selftest", agg.triples, bad)
    try:
        check2_input_validation(variant)
    except CheckRejected as e:
        print("selftest [%s]: arity cross-check rejects the miscount -- %s"
              % (witness_ctx_selftest, e.witness))
        return True
    raise AssertionError("arity cross-check did not reject")


# ---------------------------------------------------------------------------
# Per-branch independent verification.
# ---------------------------------------------------------------------------
BRANCH_CONFIG = {
    "A": {"triples": AGG_B_A_TRIPLES, "junction": AGG_B_A_JUNCTION,
          "label": "aggregate-(b)/branch-A(consume-O)",
          "expect_symbols": 8, "expect_port_zeros": 2,
          "f7_min": {"n0": 3, "n1": 3},
          "mutant_2_port": ("n0", 4), "mutant_7_port": ("n0", 5)},
    "B": {"triples": AGG_B_B_TRIPLES, "junction": AGG_B_B_JUNCTION,
          "label": "aggregate-(b)/branch-B(complementary-pair)",
          "expect_symbols": 6, "expect_port_zeros": 4,
          "f7_min": {"n0": 2, "n1": 2},
          "mutant_2_port": ("n0", 1), "mutant_7_port": ("n0", 5)},
}


def build_branch(branch_id):
    cfg = BRANCH_CONFIG[branch_id]
    return Aggregate(cfg["label"], cfg["triples"], cfg["junction"])


def verify_branch(branch_id):
    """Verify one branch on its own input: decomposition identity + the full
    9-mutant battery against that branch's input. Returns (agg, audit)."""
    cfg = BRANCH_CONFIG[branch_id]
    agg = build_branch(branch_id)
    ledger, audit = verify_decomposition(agg, cfg["label"])
    assert audit["zeros_expected"] == 3, audit  # 2 nodes + 1 junction
    assert audit["symbols_expected"] == cfg["expect_symbols"], audit
    assert audit["port_zeros_expected"] == cfg["expect_port_zeros"], audit
    assert len(agg.boundary()) == 10
    print("F.34 PASS [%s]: decomposition identity -- 3 interior aspects at "
          "exactly 0, %d positive symbols, B=10; checks 1-7 green."
          % (branch_id, cfg["expect_symbols"]))

    ctx = "branch-" + branch_id
    assert mutant_0_all_zero_route(agg, ctx)
    assert mutant_1_invented_junction_s2(agg, ctx)
    assert mutant_2_resolved_port_positive(agg, cfg["mutant_2_port"], ctx)
    witness_fixture_mutant_3_table = {
        # double-count stress: the branch's witness consumed port listed in
        # a second junction too
        "j0": {"ports": [cfg["mutant_2_port"], ("n1", 0)], "arity": 2},
        "j1": {"ports": [cfg["mutant_2_port"], ("n0", 0)], "arity": 2},
    }
    assert mutant_3_table_double_count(agg, witness_fixture_mutant_3_table, ctx)
    assert mutant_4_legacy_proof(agg, "mutant_4_legacy_proof/branch-" + branch_id)
    assert mutant_5_order_violation(agg, "n0", ctx)
    assert mutant_6_uniform_division(agg, ctx)
    assert mutant_7_o_port_positive(agg, cfg["mutant_7_port"], ctx)
    assert mutant_8_negative_terms(agg, ctx)
    assert selftest_arity_crosscheck_rejects(agg, ctx)
    print("F.34 PASS [%s]: 9/9 planted mutants rejected with printed "
          "witnesses (mutant_8 negative-term shape via check 5); arity "
          "cross-check rejects miscounts." % branch_id)
    return agg, audit


def assembled_branch_run(branch_id):
    """Final assembly for the SELECTED branch: decomposition identity
    re-verified + the §5 counterfactual battery (18 = 2 nodes x 9 rows)."""
    cfg = BRANCH_CONFIG[branch_id]
    agg = build_branch(branch_id)
    verify_decomposition(agg, cfg["label"])
    n_battery = battery_tilt_removal(agg, ["n0", "n1"], cfg["f7_min"])
    assert n_battery == 18, n_battery
    print("F.34 PASS [BRANCH=%s final assembly]: §5 counterfactual battery -- "
          "18/18 substitution inequalities strict (2 nodes x 9 source rows); "
          "substitution-effectiveness assertions and analytic open-X/Y bounds "
          "(>=%d per node-row) green."
          % (branch_id, min(cfg["f7_min"].values())))


# ---------------------------------------------------------------------------
# Main: BRANCH gating.
# ---------------------------------------------------------------------------
def main():
    branch = _os.environ.get("BRANCH")
    if branch is not None and branch not in BRANCH_CONFIG:
        print("F.34 LOUD FAILURE: BRANCH=%r is not a documented convention. "
              "Set BRANCH=A (consume-O, §9) or BRANCH=B (complementary pair, "
              "Appendix B.2), or unset it for independent per-branch runs only."
              % (branch,))
        sys.exit(2)

    # The independent per-branch runs ALWAYS run, for BOTH branches.
    for branch_id in ("A", "B"):
        verify_branch(branch_id)

    if branch is None:
        print("F.34 NO-BRANCH MODE: both branches verified independently; no "
              "branch was selected, so no §5 battery was assembled. Set "
              "BRANCH=A or BRANCH=B to assemble the §5 battery for one "
              "convention. Dervis's Decision Q -- which convention (if "
              "either) is canonical for aggregate (b) -- RESOLVED 2026-09-26: "
              "Branch B (complementary-pair, Appendix B.2) is the paper's "
              "stated convention; both branches remain machine-verified "
              "independently.")
        print("F.34 DONE: [LEVEL A] conditional on the Tracking-Cost Lemma (port-level composition), "
              "§6.1, §5.1 Table 5.1 and its boundary-tuple stipulation, the "
              "R15 sum rule and Port Count Invariance (§4.3), the junction "
              "arity >= 2 rule, and the Appendix B / §9 / F.41 construction "
              "premises; the machine checks the counting, not the premises. "
              "Rule (ii) is a declared Tracking-Cost-consistent "
              "disambiguation.")
        return

    assembled_branch_run(branch)
    print("F.34 DONE [BRANCH=%s]: [LEVEL A] conditional on the Tracking-Cost "
          "Lemma, §6.1, §5.1 Table 5.1 and its boundary-tuple stipulation, "
          "the R15 sum rule and Port Count Invariance (§4.3), the junction "
          "arity >= 2 rule, and the Appendix B / §9 / F.41 construction "
          "premises; the machine checks the counting, not the premises. "
          "Rule (ii) is a declared Tracking-Cost-consistent disambiguation. "
          "Dervis's Decision Q -- Branch B (complementary-pair, "
          "Appendix B.2) is the paper's stated convention "
          "(recorded 2026-09-26, confirmed directly 2026-09-27); both branches "
          "machine-verified independently." % branch)


if __name__ == "__main__":
    main()