
INPUT_PROVENANCE = {
    "AGG": {"class": "paper-defined", "source": "§8.2 (test aggregates)"},
    "A_even": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "A_odd": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "B6": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "ID_POOL": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "ID_POOL_SMALL": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "K": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "K_GRID": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "K_SCALES": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "MAX_N": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "N_GREEDY": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "N_LEMMA": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "N_RAND": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "N_RANDOM": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "OUTCOMES": {"class": "paper-defined", "source": "§§8.2–8.4 (interaction outcomes: attraction, repulsion, forced decay)"},
    "SEED": {"class": "control", "note": "random seed for reproducibility"},
    "TH": {"class": "declared-assumption", "prose": "§8.6 (TH=1 is Paper 14's locked debt)"},
    "THS_BIG": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "THS_SMALL": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "TH_LIVE": {"class": "declared-assumption", "prose": "§8.6 (TH=1 is Paper 14's locked debt)"},
    "VALUES": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "a_minus": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "a_plus": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "am": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "ap": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "asym": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "bad": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "band": {"class": "control", "note": "check counter / accumulator"},
    "bm": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "bp": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "cb": {"class": "control", "note": "test fixture / rejection counter"},
    "checked6": {"class": "control", "note": "check counter / accumulator"},
    "compared": {"class": "control", "note": "check counter / accumulator"},
    "cvecs": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "divergences": {"class": "control", "note": "test fixture / rejection counter"},
    "divergent": {"class": "control", "note": "test fixture / rejection counter"},
    "examples": {"class": "control", "note": "check counter / accumulator"},
    "expected": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "extremes": {"class": "control", "note": "check counter / accumulator"},
    "good": {"class": "control", "note": "check counter / accumulator"},
    "groups": {"class": "control", "note": "check counter / accumulator"},
    "ids_seen": {"class": "control", "note": "check counter / accumulator"},
    "ka": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "kb": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "n0_groups": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nF2": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nF3": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "nS": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "n_big": {"class": "control", "note": "check counter / accumulator"},
    "n_lemma": {"class": "control", "note": "check counter / accumulator"},
    "n_opt": {"class": "control", "note": "check counter / accumulator"},
    "n_pairs": {"class": "control", "note": "check counter / accumulator"},
    "n_partial": {"class": "control", "note": "check counter / accumulator"},
    "n_refused": {"class": "control", "note": "check counter / accumulator"},
    "n_small": {"class": "control", "note": "check counter / accumulator"},
    "n_wit": {"class": "control", "note": "check counter / accumulator"},
    "o0": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "o2": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "order": {"class": "control", "note": "check counter / accumulator"},
    "perm_mismatch": {"class": "control", "note": "test fixture / rejection counter"},
    "present": {"class": "control", "note": "check counter / accumulator"},
    "prs_a": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "prs_d": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "rAB_d": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "rBA_d": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "r_a": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "r_b": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "r_e1": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "r_e3": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "ref": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "rejected": {"class": "control", "note": "test fixture / rejection counter"},
    "rejectedV": {"class": "control", "note": "test fixture / rejection counter"},
    "sa6": {"class": "control", "note": "test fixture / rejection counter"},
    "skipped": {"class": "control", "note": "check counter / accumulator"},
    "small": {"class": "control", "note": "check counter / accumulator"},
    "specGuardless": {"class": "control", "note": "test fixture / rejection counter"},
    "ta_b": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "tb_a": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "tb_b": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "tb_d": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "theft": {"class": "control", "note": "test fixture / rejection counter"},
    "total": {"class": "control", "note": "check counter / accumulator"},
    "viable": {"class": "control", "note": "check counter / accumulator"},
    "viol": {"class": "control", "note": "test fixture / rejection counter"},
    "w1": {"class": "control", "note": "test fixture / rejection counter"},
    "w2": {"class": "control", "note": "test fixture / rejection counter"},
    "w5": {"class": "control", "note": "test fixture / rejection counter"},
    "wFuse": {"class": "control", "note": "test fixture / rejection counter"},
    "wGuardless": {"class": "control", "note": "test fixture / rejection counter"},
    "wInverted": {"class": "control", "note": "test fixture / rejection counter"},
    "wReduction": {"class": "control", "note": "test fixture / rejection counter"},
    "wSymmetric": {"class": "control", "note": "test fixture / rejection counter"},
    "witnesses": {"class": "control", "note": "test fixture / rejection counter"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "count-vector model over port values; backing claims quantify over no aspect kinds.",
}
#!/usr/bin/env python3
"""Paper 11 -- F36_interaction_taxonomy: coverage of the section 8.6
interaction-taxonomy selection rule through machine-label count vectors, plus
the encounter tension analysis (definitions D1-D3, Lemma, Theorems
S/N/G/A/F).

CATEGORICAL READING (binding): port values are categorical -- X-dominant,
Y-dominant, O-neutral. The integers {-1, 0, +1} in this script are MACHINE
LABELS for those categories (X-dominant -> +1, Y-dominant -> -1, O-neutral
-> 0). They carry no ordering, no signed arithmetic, and no net sums.
"Count vector" means the (n+, n-) counts of machine labels. Residue,
tension, and matched-pair counts are pure counts over the labels.

SELECTION RULE (paper sections 8.2/8.4/8.6; live spec, TH=1 (Paper 14's locked debt -- declared assumption),
rule stated parametrically -- TH=1 is the weakest fuse that keeps all three
outcomes realized on the k>=2 domain):
    residue = (a+ + a-) - min(a+, b-) - min(a-, b+)   [A's unresolvable load]
    residue >  TH  -> forced_decay
    residue == 0   -> attraction      (full complementary cover <=> res == 0)
    else           -> repulsion      (on the physical domain: 0 < res <= TH)

TENSION ANALYSIS (paper section 8.6; machine-checked in SECTION 9):
    D1  presented tension  T(A,B) := sum x^2 over both presented tuples
        (definitional application of tau(sigma), section 7.5: the same
        count, relocated to the pre-junction encounter; by the Identity,
        section 7.1, shear tension IS the unmatched-integer count).
    D2  candidate junction: a set of m disjoint complementary-category
        (p, q) pairs, p a non-neutral port of A, q a non-neutral port of B
        of the complementary category; establishing it pairs the ports off
        (resolved) to (0, 0).
    D3  completion (for A): every non-neutral port of A paired off
        <=> m = u_A <=> res(A,B) = 0 (full complementary cover, 8.6).
    Lemma (tension bookkeeping): T_after = T_before - 2m in the model
        (each paired-off pair removes two nonzero labels).
    Theorem S: res = 0 and u_A >= 1  =>  the cover pairing strictly
        reduces T.
    Theorem N: strict T reduction does NOT imply res = 0 (partial-matching
        witness) -- attraction additionally requires full complementary cover.
    Theorem G: u_A = 0  =>  res = 0 with zero T reduction; the u_A >= 1
        guard is necessary -- A-all-neutral encounters are outside the
        taxonomy.
    Theorem A: res(A,B) = 0 with res(B,A) > 0 leaves B's unmatched labels
        presented (paired off, not consumed); T_after = u_B - u_A; the
        attraction verdict is A's verdict.
    Theorem F: the fuse branch structure is coherent with T --
        res = 0 -> completable strict decrease (attraction);
        0 < res <= TH -> irreducible residual res > 0, rejection (repulsion);
        res > TH -> boundary transition (forced decay).
        A T_before-fuse misclassifies full-cover cases (rejected 'total-tension fuse' variant).

COVERAGE MAP (per the verification-rigor staple):
  Native domain: finite encounters (A, B) of configurations presenting
    finite tuples of categorical port values (X-dominant, Y-dominant,
    O-neutral) -- Stage N native. The taxonomy domain additionally requires
    the incoming side A to present at least one non-neutral port (u_A >= 1).
  Verified domain: the {-1, 0, +1} machine-label model (section 8.6) --
    exhaustive enumeration over in-domain tuple pairs (k = 1..5), factored
    through machine-label count vectors (same-count encounters select
    identically; the script states its enumeration bound explicitly).
  Map: category labeling X-dominant -> +1, Y-dominant -> -1, O-neutral -> 0
    (a labeling of categories, not an extraction of signs from quantities).
    Complementarity = complementary categories (X-dominant with Y-dominant;
    the paper's "complementary partner", section 8.6).
  What the map preserves:
    (1) res(A,B) exactly -- it depends only on categories and counts;
    (2) the guard u_A >= 1 -- non-neutrality is labeling-faithful;
    (3) strict-decrease verdicts -- each paired-off pair removes two nonzero
        labels, exactly the model's 2, so the model's strict inequality
        transfers for the same pairing;
    (4) irreducibility of res -- a category-count argument, no magnitudes;
    (5) witness arithmetic -- all witnesses are labeling-faithful.
  What stays outside the machine check:
    (1) exact native T magnitudes (abstracted by the labeling -- only
        inequality directions are claimed);
    (2) positional alignment -- the shove's job, abstracted per the coverage
        theorem (outcome invariance under permutation);
    (3) the Level B premise that real boundary ports present categorical
        values faithfully as {-1,0,+1} machine labels (section 8.6 epistemic
        split);
    (4) native pairing semantics beyond complementary categories -- if native
        complementarity is stricter, the sufficiency transfer holds for
        natively complementary pairs; the paper's text fixes complementarity
        via "complementary partner" (residue) and the section 7.5 operator;
    (5) the dynamics of the shove establishing the pairing -- the script
        proves the tension bookkeeping GIVEN a pairing, not the mechanical
        act of pairing.

PAIRING READING (grounded in the paper, not an unstated assumption): the
min(a+, b-) + min(a-, b+) term is the maximum complementary-category pairing
count. Paper section 8.6 defines the residue as "the number of A's non-neutral
ports with no complementary-category partner in B"; section 8.4 as A's
"unmatched integers with no complementary-category partner in the encounter";
section 8.2's mechanism has the neighbor present values complementing A's
unmatched integers. An X-dominant (+1) port can only pair with a Y-dominant
(-1) port (and vice versa), so at most min(a+, b-) of A's X-dominant ports
and min(a-, b+) of A's Y-dominant ports can be paired, and the two pairings
use disjoint port sets -- hence the maximum number of A's ports WITH a
complementary-category partner is the sum of the mins. SECTION 7b
machine-checks this reading against an independent greedy per-port pairing
implementation.
Domain: encounters in which the incoming configuration A presents at least
one non-neutral port (u_A >= 1 -- Theorem G guard). An encounter whose incoming
side is all-neutral, including the (empty, empty) pair, is refused
(ValueError in select_counts/select_native, naming the incoming side; None
in select_values).

THE COVERAGE THEOREM (machine-checked by this script):
  1. Every in-domain native encounter E = (A_ports, B_ports) -- A with at
     least one non-neutral port, each side a list of (port_id, label) with
     label in {-1, 0, +1}, port ids arbitrary (int/str/tuple, mixed) --
     maps via M to a count-vector pair (cA, cB).
  2. Selection is preserved through M: select_native(E) == select_model(M(E))
     (0 divergences over the preservation checks below; out-of-domain
     encounters refused identically by both).
  3. The trichotomy is exhaustive over ALL count vectors: the rule is a pure
     function of (a+, a-, b+, b-) with 0 <= res <= a+ + a- (proved
     algebraically, machine-checked over random vectors to 10^9), and the
     if/elif/else branch structure fires exactly one branch for every
     integer residue (machine-checked over -10^6..10^6 + extremes).
Therefore every in-domain native encounter gets exactly one outcome: the
coverage gap is closed at the native-structure level, not just at the
ordered-tuple level.

EPISTEMIC STATUS:
  [LEVEL A] (machine-checked here): factorization of the rule through count
  vectors (element-order / port-identity / neutral-port blindness);
  preservation through M; totality + mutual exclusivity over the full
  count-vector domain; bounds 0 <= res <= a+ + a-; TH band exactly [1, k-1]
  for k >= 2 and empty at k=1 (enumeration k=1..8 in SECTION 7, parametric
  witness families for every k >= 2 in SECTION 7b); the B-enumeration bound
  lemma -- section 7's cap of B at k nonzero ports loses no residue
  (machine-checked in SECTION 7b, constructive reduction); grounding on the
  paper's own aggregates (a), (b), (c); the tension analysis D1-D3, Lemma,
  Theorems S/N/G/A/F over the {-1,0,+1} model (SECTION 9), with the
  native transfer argued in the coverage map above; the u_A >= 1 domain
  guard (Theorem G); rejection of 12 planted variants (7 taxonomy + 5
  tension-analysis) with witnesses.
  [LEVEL B] (explicitly NOT checked here): whether physical encounters
  present categorical port values faithfully as {-1, 0, +1} machine labels
  -- the section 8.6 epistemic split. This script proves the conditional:
  IF an encounter is faithfully presented as (port_id, label) structures
  with the incoming side presenting at least one non-neutral port, THEN
  selection through M is exhaustive and preserved, and the tension theorems
  hold.

Self-contained: inlines the verified logic of the earlier development
parts 1-4 (no imports from the part files). Exits 0 with PASS lines iff
everything holds.
"""

from itertools import product, permutations
import random

TH_LIVE = 1   # declared assumption: exact TH is Paper 14's locked debt (§8.6); paper proves 0 < TH < k natively
VALUES = (-1, 0, +1)
OUTCOMES = ("attraction", "repulsion", "forced_decay")


# ------------------------------------------------------------------ live spec
def counts_of(seq):
    """Category counts (n+, n-) of a label sequence. Neutral labels drop out."""
    return (sum(1 for v in seq if v == 1), sum(1 for v in seq if v == -1))


def residue_vec(ca, cb):
    """Residue as a pure function of count vectors (reads ca[0],ca[1] only)."""
    return (ca[0] + ca[1]) - (min(ca[0], cb[1]) + min(ca[1], cb[0]))


def branch(r, TH=TH_LIVE):
    """The branch structure itself, faithful to if/elif/else."""
    if r > TH:
        return "forced_decay"
    if r == 0:
        return "attraction"
    return "repulsion"


def select_counts(ca, cb, TH=TH_LIVE):
    """decide() over count vectors. ca/cb: (n+, n-) or (n+, n-, n0).

    Domain guard (Theorem G): the INCOMING side A must present at least one
    nonzero port (u_A >= 1), regardless of B.
    """
    if ca[0] + ca[1] == 0:
        raise ValueError("incoming side presents no unmatched integers -- "
                         "outside taxonomy domain")
    return branch(residue_vec(ca, cb), TH)


def select_native(A_ports, B_ports, TH=TH_LIVE):
    """select() over native structures: lists of (port_id, label).

    Port ids are carried but never read -- selection may only see labels.
    Domain guard (Theorem G): the incoming side must present a nonzero port.
    """
    A = list(A_ports)
    B = list(B_ports)
    for _pid, s in A + B:
        if s not in VALUES:
            raise ValueError("label %r outside machine domain {-1,0,+1}" % (s,))
    if not any(s != 0 for _, s in A):
        raise ValueError("incoming side presents no unmatched integers -- "
                         "outside taxonomy domain")
    ca = (sum(1 for _, s in A if s == 1),
          sum(1 for _, s in A if s == -1),
          sum(1 for _, s in A if s == 0))
    cb = (sum(1 for _, s in B if s == 1),
          sum(1 for _, s in B if s == -1),
          sum(1 for _, s in B if s == 0))
    return select_counts(ca, cb, TH)


def M(side):
    """Coverage map: native (port_id, label) structure -> count vector."""
    n_p = n_m = n_z = 0
    for _pid, s in side:
        if s == 1:
            n_p += 1
        elif s == -1:
            n_m += 1
        elif s == 0:
            n_z += 1
        else:
            raise ValueError("label %r outside machine domain {-1,0,+1}" % (s,))
    return (n_p, n_m, n_z)


print("=" * 70)
print("F36_interaction_taxonomy: coverage of the section 8.6")
print("selection rule through machine-label count vectors + tension analysis.")
print("TH=%d (Paper 14's debt, declared assumption)." % TH_LIVE)
print("=" * 70)


# ================================================== SECTION 1: factorization
print("=" * 70)
print("SECTION 1: count-factorization over in-domain ordered tuple pairs, k = 1..5")
tuples = [t for k in range(1, 6) for t in product(VALUES, repeat=k)]
assert len(tuples) == 3 + 9 + 27 + 81 + 243 == 363
# in-domain: the INCOMING side A must present at least one nonzero port
# (Theorem G guard). The 5 all-zero tuples (one per k) are out as A.
tuples_A = [t for t in tuples if any(v != 0 for v in t)]
assert len(tuples_A) == 363 - 5 == 358
pairs = [(A, B) for A in tuples_A for B in tuples]
assert len(pairs) == 358 * 363 == 129954


def counts3(t):
    p = t.count(1)
    m = t.count(-1)
    return (p, m, len(t) - p - m)


def decide_tuple(A, B):
    ap, am, _ = counts3(A)
    bp, bm, _ = counts3(B)
    return branch(residue_vec((ap, am), (bp, bm)))


def decide_counts(ap, am, bp, bm):
    """Same rule computed DIRECTLY from count vectors -- never builds a tuple."""
    return branch(residue_vec((ap, am), (bp, bm)))


groups = {}
for A, B in pairs:
    key = counts3(A) + counts3(B)          # (a+, a-, a0, b+, b-, b0)
    groups.setdefault(key, []).append((A, B))
assert len(groups) == 50 * 55 == 2750, len(groups)   # 50 in-domain A vectors x 55 B

divergent = []
perm_mismatch = 0
asym = 0  # (A,B)<->(B,A) flips: directional per section 8.6, OUTSIDE the
          # factorization claim (incoming A vs neighbor B). Pure-function
          # comparison only -- (B,A) may lie outside the taxonomy domain.
for key, members in groups.items():
    outs = {decide_tuple(A, B) for (A, B) in members}
    if len(outs) != 1:
        divergent.append((key, outs, members[:2]))   # premise failure: kills Option A
    for (A, B) in members:
        if decide_tuple(tuple(sorted(A)), tuple(sorted(B))) != decide_tuple(A, B):
            perm_mismatch += 1
        if decide_tuple(B, A) != decide_tuple(A, B):
            asym += 1

assert not divergent, "PREMISE FAILURE (Option A dead): %r" % (divergent[:3],)
assert perm_mismatch == 0, perm_mismatch
print("  tuples enumerated    : 363  (3^1 + ... + 3^5); in-domain A: 358")
print("  ordered pairs        : 129954 (A in-domain x all B)")
print("  count-vector groups  : 2750 (50 x 55)")
print("  divergent groups     : 0  (identical outcome inside every group)")
print("  permutation leaks    : 0  (sorted canonical form always agrees)")
print("  (A,B)<->(B,A) flips  : %d of 129954 -- directional per section 8.6"
      % asym)
print("PASS 1a: outcome factors through the count vector; element order inert.")

# ---- port-identity blindness (identity-carrying re-implementation)
print("SECTION 1b: port-identity blindness")


def decide_ports(portsA, portsB):
    """Independent re-implementation over (port_id, value) pairs.

    Port ids key the dicts but the outcome is computed from the VALUE
    multiset only. Any id influence surfaces below as a mismatch.
    """
    dA = {pid: v for pid, v in portsA}
    dB = {pid: v for pid, v in portsB}
    return decide_counts(sum(1 for v in dA.values() if v == 1),
                         sum(1 for v in dA.values() if v == -1),
                         sum(1 for v in dB.values() if v == 1),
                         sum(1 for v in dB.values() if v == -1))


def make_ports(vals, scheme):
    n = len(vals)
    if scheme == 0:
        ids = list(range(n))
    elif scheme == 1:
        ids = list(range(n - 1, -1, -1))
    elif scheme == 2:
        ids = [1000 + 7 * i for i in range(n)]
    else:
        ids = ["p%d@node7" % i for i in range(n)]
    return list(zip(ids, vals))


items = [(vals, make_ports(vals, 0), make_ports(vals, 2))
         for n in range(0, 5) for vals in product(VALUES, repeat=n)]
assert len(items) == 1 + 3 + 9 + 27 + 81 == 121
# in-domain A items: drop the 5 all-zero assignments (one per n)
items_A = [(vals, p0, p2) for (vals, p0, p2) in items
           if any(v != 0 for v in vals)]
assert len(items_A) == 121 - 5 == 116

compared = 0
for valsA, pA0, pA2 in items_A:
    for valsB, pB0, pB2 in items:
        ref = decide_tuple(valsA, valsB)
        o0 = decide_ports(pA0, pB0)
        o2 = decide_ports(pA2, pB2)
        assert o0 == ref, ("id-scheme-0 leak", valsA, valsB, o0, ref)
        assert o2 == ref, ("id-scheme-2 leak", valsA, valsB, o0, ref)
        compared += 1
assert compared == 116 * 121 == 14036, compared

for n in range(0, 5):
    for vals in product(VALUES, repeat=n):
        outs = {decide_ports(make_ports(vals, s), make_ports(vals, s))
                for s in range(4)}
        assert len(outs) == 1, ("id-scheme disagreement", vals, outs)

print("  port-sets per side        : 121 (all label assignments, sizes 0..4)")
print("  in-domain A port-sets     : 116")
print("  pair comparisons vs tuple : %d (%d pairs x 2 id schemes = %d comparisons)"
      % (compared, compared, compared * 2))
print("  4-scheme agreement        : all 121 assignments")
print("PASS 1b: port identity never affects the outcome.")


# ============================================ SECTION 2: count-vector domain
print("=" * 70)
print("SECTION 2: direct count-vector enumeration, n+ + n- + n0 <= 12 (A in-domain)")
K = 12
vecs = [(p, m, s - p - m)
        for s in range(K + 1)
        for p in range(s + 1)
        for m in range(s + 1 - p)]
assert len(vecs) == 455, len(vecs)  # sum_{s=0..12} C(s+2,2) = C(15,3) = 455
# in-domain A vectors: drop the 13 all-zero vectors (one per size 0..12)
vecs_A = [v for v in vecs if v[0] + v[1] > 0]
assert len(vecs_A) == 455 - 13 == 442

n_pairs = 0
tally = {o: 0 for o in OUTCOMES}
for (ap, am, _a0) in vecs_A:
    for (bp, bm, _b0) in vecs:
        o = decide_counts(ap, am, bp, bm)
        assert o in OUTCOMES, o                                   # total
        r = residue_vec((ap, am), (bp, bm))
        b1, b2, b3 = (r > TH_LIVE), (r == 0), not (r > TH_LIVE or r == 0)
        assert (b1 + b2 + b3) == 1, r                             # mutually exclusive
        assert (o == "forced_decay") == b1                        # outcome == branch
        assert (o == "attraction") == b2
        assert (o == "repulsion") == b3
        A = (1,) * ap + (-1,) * am                                # canonical witness
        B = (1,) * bp + (-1,) * bm
        assert decide_tuple(A, B) == o, (ap, am, bp, bm)
        assert 0 <= r <= ap + am, (ap, am, bp, bm, r)             # bounds (TEST 4)
        tally[o] += 1
        n_pairs += 1
assert n_pairs == 442 * 455 == 201110, n_pairs
assert all(tally[o] > 0 for o in OUTCOMES), tally                # all realized

# neutral-port blindness: the rule never reads a0/b0
checked6 = 0
for ap in range(K + 1):
    for am in range(K + 1 - ap):
        if ap + am == 0:
            continue   # A all-zero: outside the taxonomy domain
        for bp in range(K + 1):
            for bm in range(K + 1 - bp):
                o = decide_counts(ap, am, bp, bm)
                for a0 in range(K + 1 - ap - am):
                    for b0 in range(K + 1 - bp - bm):
                        # Real blindness test: neutral 0-ports appended to the
                        # canonical witness tuples must not change the outcome.
                        A0 = (1,) * ap + (-1,) * am + (0,) * a0
                        B0 = (1,) * bp + (-1,) * bm + (0,) * b0
                        assert decide_tuple(A0, B0) == o, (ap, am, a0, bp, bm, b0)
                        checked6 += 1
assert checked6 == 442 * 455 == 201110, checked6

print("  count vectors            : 455 (C(15,3)); in-domain A: 442")
print("  ordered pairs            : 201110")
print("  outcome tally            : %s" % (tally,))
print("  neutral-port variants    : %d checked -- all agree" % checked6)
print("  bounds 0 <= res <= a++a- : hold on all 201110 pairs")
print("PASS 2: decide(a+,a-,b+,b-) total and mutually exclusive; agrees with")
print("        the tuple implementation; a0/b0 never read.")


# ======================================= SECTION 3: analytic trichotomy+bounds
print("=" * 70)
print("SECTION 3: analytic trichotomy -- every integer residue fires one branch")

# (a) The branch structure is exhaustive over ALL integers by construction of
# if/elif/else. Machine-checked over -10^6..10^6 plus extremes.
lo, hi = -10**6, 10**6
for r in range(lo, hi + 1):
    b1, b2, b3 = (r > TH_LIVE), (r == 0), not (r > TH_LIVE or r == 0)
    assert (b1 + b2 + b3) == 1, r
extremes = [10**18, -10**18, 2**63 - 1, -(2**63),
            2**100, -(2**100), 10**1000, -(10**1000)]
for r in extremes:
    b1, b2, b3 = (r > TH_LIVE), (r == 0), not (r > TH_LIVE or r == 0)
    assert (b1 + b2 + b3) == 1, r
    if r >= 0:
        assert (not b1 and not b2) == (0 < r <= TH_LIVE), r
n_branch = (hi - lo + 1) + len(extremes)

# (b) Bounds 0 <= res <= a+ + a- for ALL count vectors (unbounded).
# ALGEBRAIC REASON (the loops are the machine check):
#   max_pairs = min(a+, b-) + min(a-, b+), a+,a-,b+,b- >= 0.
#   min(a+, b-) <= a+ and min(a-, b+) <= a- => max_pairs <= a+ + a-,
#   so res = (a+ + a-) - max_pairs >= 0; and max_pairs >= 0 => res <= a+ + a-.
# So res is always a nonnegative integer; with TH=1 the line splits into
# {r > 1} | {r == 0} | {r == 1} = forced_decay | attraction | repulsion.
random.seed(11)
N_RAND = 200000
for _ in range(N_RAND):
    ap = random.randrange(0, 10**9)
    am = random.randrange(0, 10**9)
    bp = random.randrange(0, 10**9)
    bm = random.randrange(0, 10**9)
    r = residue_vec((ap, am), (bp, bm))
    assert 0 <= r <= ap + am, (ap, am, bp, bm, r)

print("  branch checks : %d integer residues (-10^6..10^6 + %d extremes)"
      % (n_branch, len(extremes)))
print("  bound checks  : %d random count vectors (counts up to 10^9) + 201110 in SEC 2"
      % N_RAND)
print("  algebraic     : min(a+,b-) <= a+, min(a-,b+) <= a- => max_pairs <= a++a-")
print("                  => res >= 0; max_pairs >= 0 => res <= a++a-.")
print("PASS 3: exactly one branch fires for every integer r; 0 <= res <= a++a- always.")


# ================================== SECTION 4: preservation through the map M
print("=" * 70)
print("SECTION 4: select_native(E) == select_model(M(E)) -- preservation")

ID_POOL_SMALL = [0, "a", "zz", (3, "q")]        # int, str, str, tuple ids, mixed
ID_POOL = [0, 1, 2, 3, "a", "b", "c", "d", (7, "x"), "port-9", 10, ("k",)]

divergences = []


def has_nonzero(side):
    return any(s != 0 for _, s in side)


# 4a: exhaustive over all native structures to small sizes.
def all_structures(max_len):
    opts = [(pid, s) for pid in ID_POOL_SMALL for s in VALUES]
    structs = [[]]
    for L in range(1, max_len + 1):
        structs.extend([list(t) for t in product(opts, repeat=L)])
    return structs


small = all_structures(2)
assert len(small) == 1 + 12 + 144 == 157
THS_SMALL = [0, 1, 2, 3, 4]
n_small = 0
for A in small:
    nzA = has_nonzero(A)
    cA = M(A)
    for B in small:
        if not nzA:
            # incoming side presents no unmatched integers: both must refuse
            # (Theorem G guard), regardless of B
            for TH in THS_SMALL:
                try:
                    select_native(A, B, TH)
                    divergences.append(("native failed to refuse", A, B, TH))
                except ValueError:
                    pass
                try:
                    select_counts(cA, M(B), TH)
                    divergences.append(("model failed to refuse", A, B, TH))
                except ValueError:
                    pass
            continue
        cB = M(B)
        for TH in THS_SMALL:
            n_small += 1
            o1, o2 = select_native(A, B, TH), select_counts(cA, cB, TH)
            if o1 != o2:
                divergences.append(("TH=%d" % TH, A, B, o1, o2))
print("  4a: %d native structures/side (%d pairs, mixed int/str/tuple ids,"
      " duplicates allowed); %d selection checks at TH in %s"
      % (len(small), len(small) ** 2, n_small, THS_SMALL))

# 4b: count-vector-complete domain to total size 12, realized with scrambled ids.
def realize(cvec):
    """Realize a count vector as a native structure with scrambled mixed ids."""
    n_p, n_m, n_z = cvec
    sur = [1] * n_p + [-1] * n_m + [0] * n_z
    m = len(sur)
    base = [ID_POOL[i % len(ID_POOL)] for i in range(m)]
    off = (n_p * 7 + n_m * 11 + n_z * 13) % max(m, 1)
    ids = base[off:] + base[:off]
    if (n_p + n_m) % 2:
        ids = ids[::-1]
    return list(zip(ids, sur))


def count_vectors(max_total):
    return [(n_p, n_m, n_z)
            for n_p in range(max_total + 1)
            for n_m in range(max_total + 1 - n_p)
            for n_z in range(max_total + 1 - n_p - n_m)]


cvecs = count_vectors(12)
assert len(cvecs) == 455
realized = [realize(c) for c in cvecs]
for c, E in zip(cvecs, realized):
    assert M(E) == c, "M roundtrip failed on %r" % (c,)   # realization faithful

THS_BIG = [0, 1, 2]
n_big = 0
for i, cA in enumerate(cvecs):
    EA = realized[i]
    nzA = cA[0] + cA[1] > 0
    for j, cB in enumerate(cvecs):
        EB = realized[j]
        if not nzA:
            for TH in THS_BIG:   # incoming side all-zero: both must refuse
                try:
                    select_native(EA, EB, TH)
                    divergences.append(("native failed to refuse", cA, cB, TH))
                except ValueError:
                    pass
                try:
                    select_counts(cA, cB, TH)
                    divergences.append(("model failed to refuse", cA, cB, TH))
                except ValueError:
                    pass
            continue
        for TH in THS_BIG:
            n_big += 1
            o1, o2 = select_native(EA, EB, TH), select_counts(cA, cB, TH)
            if o1 != o2:
                divergences.append(("TH=%d" % TH, cA, EA, cB, o1, o2))
print("  4b: %d count vectors/side (total size <= 12, complete: %d pairs,"
      " scrambled mixed-type ids); %d selection checks at TH in %s"
      % (len(cvecs), len(cvecs) ** 2, n_big, THS_BIG))

assert not divergences, \
    "PRESERVATION FAILED -- Option A is dead. First witnesses: %r" % (divergences[:5],)
n_pres = n_small + n_big
assert n_pres == 710090, n_pres
print("PASS 4: select_native(E) == select_model(M(E)) over %d checks; "
      "0 divergences; A-all-zero encounters refused identically by both." % n_pres)


# ============================================ SECTION 5: native witnesses
print("=" * 70)
print("SECTION 5: realization witnesses on native structures (TH=1)")


def ports_of(k, label, id_start=0):
    ids = [ID_POOL[(id_start + i) % len(ID_POOL)] for i in range(k)]
    return list(zip(ids, [label] * k))


K_SCALES = [1, 2, 3, 6, 12]
ids_seen = set()
for k in K_SCALES:
    A = ports_of(k, +1, 0)
    ids_seen.update(pid for pid, _ in A)
    # attraction: full complementary cover -> residue 0
    B_attr = ports_of(k, -1, 3)
    ids_seen.update(pid for pid, _ in B_attr)
    o = select_native(A, B_attr)
    assert o == "attraction" == select_counts(M(A), M(B_attr)), (k, o)
    print("  k=%2d  attraction   A=%dx+1    B=%dx-1    -> %s" % (k, k, k, o))
    # repulsion: residue exactly 1 (0 < 1 <= TH)
    B_rep = ports_of(k - 1, -1, 5) if k >= 2 else []
    ids_seen.update(pid for pid, _ in B_rep)
    o = select_native(A, B_rep)
    assert o == "repulsion" == select_counts(M(A), M(B_rep)), (k, o)
    print("  k=%2d  repulsion    A=%dx+1    B=%s -> %s"
          % (k, k, ("%dx-1" % (k - 1)) if k >= 2 else "empty".ljust(4), o))
    # forced_decay: no complementary ports -> residue = k > TH (needs k >= 2)
    if k >= 2:
        o = select_native(A, [])
        assert o == "forced_decay" == select_counts(M(A), M([])), (k, o)
        print("  k=%2d  forced_decay A=%dx+1    B=empty    -> %s" % (k, k, o))

assert any(isinstance(i, int) and not isinstance(i, bool) for i in ids_seen)
assert any(isinstance(i, str) for i in ids_seen)

# k=1: machine proof that forced_decay is unrealizable (single-port boundary
# cannot saturate: residue <= 1 <= TH for every B, so the fuse never fires).
for cA in [(1, 0, z) for z in range(3)] + [(0, 1, z) for z in range(3)]:
    for cB in cvecs:
        assert select_counts(cA, cB, TH_LIVE) != "forced_decay", (cA, cB)
print("PASS 5: every outcome realized at k=2,3,6,12 on native structures;")
print("        k=1 realizes attraction+repulsion only; forced_decay provably")
print("        unrealizable at k=1 (residue <= 1 <= TH for all B).")


# ====================================== SECTION 6: real-aggregate grounding
print("=" * 70)
print("SECTION 6: grounding on the paper's own aggregates (a), (b), (c)")


def build_aggregate(name, N, junctions):
    """junctions: list of {node: port}; each consumes one port per node,
    so arity k_j == len(junction)."""
    consumed = set()
    for j in junctions:
        for node, port in j.items():
            assert 0 <= node < N and 0 <= port < 6, (name, node, port)
            assert (node, port) not in consumed, "%s: port double-consumed" % name
            consumed.add((node, port))
    ports = ["%s:n%dp%d" % (name, node, port)
             for node in range(N) for port in range(6)
             if (node, port) not in consumed]
    arity_sum = sum(len(j) for j in junctions)
    expected = 6 * N - arity_sum                       # paper boundary rule
    assert len(ports) == expected, (name, len(ports), expected)
    return {"name": name, "N": N, "ports": ports,
            "arities": [len(j) for j in junctions], "B": expected}


AGG = {
    "a": build_aggregate("a", 3, [{0: 0, 1: 0, 2: 0}]),
    "b": build_aggregate("b", 2, [{0: 0, 1: 0}]),
    "c": build_aggregate("c", 3, [{0: 0, 1: 0}, {1: 1, 2: 1}]),
}

for nm, g in AGG.items():
    print("PASS boundary %s: N=%d, junction arities=%s, B=%d == 6*%d - %d"
          % (nm, {"a": 3, "b": 2, "c": 3}[nm], g["arities"], g["B"],
             {"a": 3, "b": 2, "c": 3}[nm], 6 * {"a": 3, "b": 2, "c": 3}[nm] - g["B"]))
assert AGG["a"]["B"] == 15 and AGG["b"]["B"] == 10 and AGG["c"]["B"] == 14


def select_values(A, B, TH=TH_LIVE):
    """Rule computed from bare port-ordered value tuples; None outside domain."""
    if not any(v != 0 for v in A):
        return None
    r = residue_vec(counts_of(A), counts_of(B))
    assert r >= 0, (A, B, r)
    return branch(r, TH), r


def count_classes(k):
    return [(np_, nn, k - np_ - nn)
            for np_ in range(k + 1) for nn in range(k - np_ + 1)]


def class_rep(np_, nn, n0):
    return (1,) * np_ + (-1,) * nn + (0,) * n0


SEED = 20260924
N_RANDOM = 200   # fixed-seed random sample per aggregate (part2 used 400)


def make_pool(agg, rng):
    k = agg["B"]
    reps = [class_rep(np_, nn, n0) for (np_, nn, n0) in count_classes(k)]
    rand = [tuple(rng.choice(VALUES) for _ in range(k))
            for _ in range(N_RANDOM)]
    return reps + rand


rng = random.Random(SEED)
pools = {nm: make_pool(g, rng) for nm, g in AGG.items()}
for nm, g in AGG.items():
    nclass = len(count_classes(g["B"]))
    print("PASS pool %s: k=%d, %d count-class reps + %d random = %d assignments"
          % (nm, g["B"], nclass, N_RANDOM, len(pools[nm])))

# (b) is small enough for FULL enumeration: 3^10 = 59049.
b_full = list(product(VALUES, repeat=AGG["b"]["B"]))
assert len(b_full) == 3 ** AGG["b"]["B"] == 59049
present = set()
for a in b_full:
    present.add((a.count(1), a.count(-1), a.count(0)))
assert present == set(count_classes(AGG["b"]["B"])), "count-class coverage gap"
print("PASS full enumeration (b): all 59049 assignments, every count class present")

# identity-carrying no-crash spot check: [(port_id, value)] form
for nm, g in AGG.items():
    vals = next(v for v in pools[nm] if any(x != 0 for x in v))
    idmap = [(pid, v) for pid, v in zip(g["ports"], vals)]
    o = select_native(idmap, idmap)
    assert o == select_counts(counts_of(vals), counts_of(vals)), (nm, o)
    # the all-neutral incoming side must be refused, exactly like F36's edge
    zidmap = [(pid, 0) for pid in g["ports"]]
    try:
        select_native(zidmap, zidmap)
        raise AssertionError("select_native failed to refuse A-all-zero encounter")
    except ValueError:
        pass
print("PASS identity-carrying structures: no crash on [(port_id, value)] form;")

total = 0
skipped = 0
tally6 = {o: 0 for o in OUTCOMES}
witnesses = {}


def run_encounter(xname, yname, A, B):
    global total, skipped
    first = select_values(A, B)
    if first is None:
        skipped += 1
        return
    out1, r1 = first
    out2 = select_counts(counts_of(A), counts_of(B))     # count-vector spec
    assert out1 == out2, "factorization mismatch on %sx%s" % (xname, yname)
    out3, r3 = select_values(A, B)                        # determinism
    assert (out1, r1) == (out3, r3), "nondeterministic encounter"
    total += 1
    tally6[out1] += 1
    if out1 not in witnesses:
        witnesses[out1] = (xname, yname, counts_of(A), counts_of(B), r1)


order = ["a", "b", "c"]
for x in order:
    for y in order:
        for A in pools[x]:
            for B in pools[y]:
                run_encounter(x, y, A, B)
print("PASS 9 ordered aggregate-pair grids: factorization + determinism hold")

# dense check over the FULL (b) enumeration: fixed-seed subset against all
# count-class partners of every aggregate, in both directions
partners = {nm: [class_rep(*cc) for cc in count_classes(g["B"])]
            for nm, g in AGG.items()}
n_partners = sum(len(p) for p in partners.values())
rng2 = random.Random(SEED + 1)
sub = [b_full[i] for i in rng2.sample(range(len(b_full)), 1200)]
for s in sub:
    for nm in order:
        for p in partners[nm]:
            run_encounter("b", nm, s, p)
            run_encounter(nm, "b", p, s)
print("PASS dense full-enumeration sample (b): 1200 assignments x %d partners, "
      "both directions" % n_partners)

assert all(tally6[o] > 0 for o in OUTCOMES), tally6
assert all(o in witnesses for o in OUTCOMES)

print("PASS encounters checked: %d (skipped %d out-of-domain: incoming side"
      " all-zero, outside the taxonomy)" % (total, skipped))
print("PASS outcome tally on real aggregates: %s" % (tally6,))
for o in OUTCOMES:
    x, y, ca, cb, r = witnesses[o]
    print("PASS witness %-12s: %s x %s  A counts (+%d,-%d)  B counts (+%d,-%d)"
          "  residue=%d" % (o, x, y, ca[0], ca[1], cb[0], cb[1], r))
print("PASS 6: all three outcomes realized by real-aggregate encounters; no")
print("        divergence from the sandbox count-model on real boundaries.")


# ============================================ SECTION 7: TH-band verification
print("=" * 70)
print("SECTION 7: TH-band re-verification on the count-vector domain")


def A_vecs(k):
    # A presents exactly k nonzero ports; n0 in 0..2 (zeros must not matter)
    return [(a, k - a, z) for a in range(k + 1) for z in range(3)]


def B_vecs(k):
    # B arbitrary: at most k nonzero ports (more adds no new residues --
    # the B-reduction lemma, machine-checked in SECTION 7b), n0 0..2
    return [(b, tot - b, z)
            for tot in range(k + 1) for b in range(tot + 1) for z in range(3)]


band = {}
for k in range(1, 9):
    viable = []
    for TH in range(0, k + 1):
        tally7 = {o: 0 for o in OUTCOMES}
        n0_groups = {}
        theft = viol = 0
        for cA in A_vecs(k):
            for cB in B_vecs(k):
                o = select_counts(cA, cB, TH)          # never raises: A has k>=1 nonzero
                tally7[o] += 1
                r = residue_vec((cA[0], cA[1]), (cB[0], cB[1]))
                if (o == "forced_decay") != (r > TH):
                    viol += 1                          # fuse must hold both directions
                if r == 0 and o == "forced_decay":
                    theft += 1                         # no cover theft
                key = (cA[0], cA[1], cB[0], cB[1])
                n0_groups.setdefault(key, set()).add(o)
        # zero ports must never leak into selection
        assert all(len(v) == 1 for v in n0_groups.values()), \
            "n0 leaked into selection at k=%d TH=%d" % (k, TH)
        ok = all(tally7[o] > 0 for o in OUTCOMES) and theft == 0 and viol == 0
        if ok:
            viable.append(TH)
        print("  k=%d TH=%d: decay=%5d attr=%5d rep=%5d -> %s"
              % (k, TH, tally7["forced_decay"], tally7["attraction"],
                 tally7["repulsion"], "VIABLE" if ok else "reject"))
    band[k] = viable

expected = {1: []}
expected.update({k: list(range(1, k)) for k in range(2, 9)})
assert band == expected, "TH-band mismatch: got %r, expected %r" % (band, expected)
print("PASS 7: viable TH band is exactly [1, k-1] for k>=2 and empty at k=1;")
print("        TH<=0 kills repulsion, TH>=k makes decay vacuous; selection")
print("        provably independent of n0.")


# ============================ SECTION 7b: parametric TH-band bridge
print("=" * 70)
print("SECTION 7b: parametric witnesses -- the band holds for every k >= 2")

# ---- 7b.1: the pairing reading is the paper's definition, operationalized.
# Paper section 8.6: residue = "the number of A's nonzero ports with no
# opposite-sign partner in B". Paper section 8.4: A's "unmatched integers with
# no opposite-sign partner in the encounter". Paper section 8.2 mechanism: the
# neighbor presents values complementing A's unmatched integers. A +1 port can
# only pair with a -1 port (and vice versa), so at most min(a+, b-) of A's +
# ports and min(a-, b+) of A's - ports can be paired; the two pairings consume
# disjoint port sets. Hence the maximum number of A's ports WITH an
# opposite-sign partner is the sum of the mins. Independent machine check: a
# greedy per-port pairing (no counts, no mins) agrees with the formula.


def residue_greedy(A_vals, B_vals):
    """Per-port opposite-sign pairing: each nonzero A port in order consumes
    the first still-free opposite-sign B port; returns the unmatched A count."""
    Bfree = list(B_vals)
    unmatched = 0
    for a in A_vals:
        if a == 0:
            continue
        for j, b in enumerate(Bfree):
            if b == -a:                       # nonzero b of opposite sign
                Bfree[j] = 0                  # consume the partner
                break
        else:
            unmatched += 1
    return unmatched


random.seed(77)
N_GREEDY = 6000
for _ in range(N_GREEDY):
    ka = random.randrange(0, 24)
    kb = random.randrange(0, 24)
    tA = [random.choice(VALUES) for _ in range(ka)]
    tB = [random.choice(VALUES) for _ in range(kb)]
    g = residue_greedy(tA, tB)
    f = residue_vec(counts_of(tA), counts_of(tB))
    assert g == f, (tA, tB, g, f)
    assert 0 <= g <= sum(1 for a in tA if a != 0)
print("  greedy per-port pairing agrees with the sum-of-mins formula on %d"
      " random tuple pairs" % N_GREEDY)
print("  (pairing reading grounded in the paper: §8.2 mechanism, §8.4 residue,")
print("   §8.6 residue definition -- opposite-sign partners)")

# ---- 7b.2: parametric witness families, valid for symbolic k >= 2.
# Closed-form residues (verified below over a wide k grid, no particular k):
#   attraction : ca=(k,0), cb=(0,k)    -> r = k - min(k,k)   - min(0,0) = 0
#   repulsion  : ca=(k,0), cb=(0,k-1)  -> r = k - min(k,k-1) - min(0,0) = 1
#   decay      : ca=(k,0), cb=(0,0)    -> r = k - min(k,0)   - min(0,0) = k
# The branch outcome for r in {0, 1, k} then reduces to band inequalities:
#   r=0 -> attraction always; r=1 -> repulsion iff TH >= 1; r=k -> decay iff TH < k.
# So every TH with 1 <= TH <= k-1 realizes all three outcomes, for EVERY k>=2,
# without enumerating k. The band edges are tight on these same families:
# TH=0 turns the repulsion witness into decay; TH=k turns the decay witness
# into repulsion (and r <= k always, so TH >= k makes decay vacuous in general).


def parametric_witnesses(k):
    return {"attraction":   ((k, 0), (0, k)),
            "repulsion":    ((k, 0), (0, k - 1)),
            "forced_decay": ((k, 0), (0, 0))}


K_GRID = list(range(2, 2001)) + [10**6, 10**9, 10**12, 10**18]
for k in K_GRID:
    w = parametric_witnesses(k)
    assert residue_vec(*w["attraction"]) == 0, k
    assert residue_vec(*w["repulsion"]) == 1, k
    assert residue_vec(*w["forced_decay"]) == k, k
print("  witness residues exactly {0, 1, k} for %d k values (2..2000 plus"
      " 10^6, 10^9, 10^12, 10^18)" % len(K_GRID))

# outcome checks: full band for k=2..200; band edges for the huge k values
n_wit = 0
for k in range(2, 201):
    w = parametric_witnesses(k)
    for TH in range(1, k):
        assert select_counts(*w["attraction"], TH) == "attraction", (k, TH)
        assert select_counts(*w["repulsion"], TH) == "repulsion", (k, TH)
        assert select_counts(*w["forced_decay"], TH) == "forced_decay", (k, TH)
        n_wit += 1
for k in [10**6, 10**9, 10**12, 10**18]:
    w = parametric_witnesses(k)
    for TH in (1, k // 2, k - 1):          # band interior + both edges
        assert select_counts(*w["attraction"], TH) == "attraction", (k, TH)
        assert select_counts(*w["repulsion"], TH) == "repulsion", (k, TH)
        assert select_counts(*w["forced_decay"], TH) == "forced_decay", (k, TH)
        n_wit += 1
# band tightness on the same families: TH=0 kills repulsion, TH=k kills decay
for k in K_GRID:
    w = parametric_witnesses(k)
    assert select_counts(*w["repulsion"], 0) == "forced_decay", k
    assert select_counts(*w["forced_decay"], k) != "forced_decay", k
print("  all three outcomes realized for every TH in [1, k-1]: %d (k, TH) checks"
      % n_wit)
print("  band edges tight: TH=0 kills the repulsion witness; TH=k kills the decay"
      " witness")

# ---- 7b.3: the B-enumeration bound lemma (section 7's B cap is complete).
# Lemma: for ca with a+ + a- = k and ANY cb, the reduced vector
#   cb* = (min(a-, b+), min(a+, b-))
# satisfies residue_vec(ca, cb*) = residue_vec(ca, cb) and b+* + b-* <= k.
# Proof: min(a+, b-*) = min(a+, min(a+, b-)) = min(a+, b-), and likewise for
# the other term; and b+* + b-* = min(a-, b+) + min(a+, b-) <= a- + a+ = k.
# Hence every B reduces to at most k nonzero ports with identical residue, so
# capping the enumeration at k nonzero ports loses no residue. (Neutral ports
# are already handled: selection is n0-blind, checked in SECTION 7.)


def reduce_B(ca, cb):
    return (min(ca[1], cb[0]), min(ca[0], cb[1]))


random.seed(78)
N_LEMMA = 50000
for _ in range(N_LEMMA):
    a_plus = random.randrange(0, 10**6)
    a_minus = random.randrange(0, 10**6)
    if a_plus + a_minus == 0:
        a_plus = 1
    ca = (a_plus, a_minus)
    cb = (random.randrange(0, 10**9), random.randrange(0, 10**9))
    cbs = reduce_B(ca, cb)
    assert cbs[0] + cbs[1] <= ca[0] + ca[1], (ca, cb, cbs)
    assert residue_vec(ca, cbs) == residue_vec(ca, cb), (ca, cb, cbs)
    # the reduced B also selects identically (outcome is a pure function of residue)
    for TH in (0, 1, 2):
        assert select_counts(ca, cbs, TH) == select_counts(ca, cb, TH), (ca, cb, TH)
print("  B-reduction lemma: %d random (ca, cb) pairs -- reduced B has <= k nonzero"
      " ports, identical residue and identical outcome at TH in {0,1,2}" % N_LEMMA)
print("PASS 7b: parametric witnesses realize all three outcomes across the whole")
print("        band [1, k-1] for every k >= 2 (analytic: residues {0,1,k}, outcomes")
print("        reduce to the band inequalities); B cap at k nonzero ports complete.")


# ============================================ SECTION 8: planted-variant suite
print("=" * 70)
print("SECTION 8: planted-variant suite -- 7 taxonomy variants, 0 survivors")


def spec(ca, cb):
    return select_counts(ca, cb)      # TH=TH_LIVE


def res(ca, cb):
    return residue_vec(ca, cb)


MAX_N = 5
COUNTS = [(p, t - p) for t in range(MAX_N + 1) for p in range(t + 1)]
assert len(COUNTS) == 21, len(COUNTS)  # C(7,2)
# the taxonomy domain requires the incoming side to present a nonzero port
# (Theorem G guard): all ca == (0, 0) rows are out
PAIRS = [(ca, cb) for ca in COUNTS for cb in COUNTS if ca != (0, 0)]
assert len(PAIRS) == 441 - 21 == 420

# ---- spec assertions: deterministic, total, mutually exclusive, realized
tally8 = {o: 0 for o in OUTCOMES}
examples = {}
for ca, cb in PAIRS:
    o1 = spec(ca, cb)
    o2 = spec(ca, cb)
    assert o1 == o2, "nondeterministic on %r" % ((ca, cb),)
    assert o1 in OUTCOMES, "non-outcome on %r" % ((ca, cb),)
    assert (o1 == "forced_decay") == (res(ca, cb) > TH_LIVE), \
        "fuse break on %r" % ((ca, cb),)
    if res(ca, cb) == 0:
        assert o1 != "forced_decay", "cover theft on %r" % ((ca, cb),)
    tally8[o1] += 1
    examples.setdefault(o1, (ca, cb))
assert all(tally8[o] > 0 for o in OUTCOMES), tally8

print("PASS SPEC: deterministic, total, mutually exclusive over %d count-vector pairs"
      % len(PAIRS))
print("PASS SPEC: fuse holds in both directions; no cover theft over %d pairs"
      % len(PAIRS))
for o in OUTCOMES:
    print("PASS SPEC: outcome '%s' realized, e.g. ca=%s, cb=%s"
          % (o, examples[o][0], examples[o][1]))

rejected = 0


def reject(name, witness, spec_out, var_out, note):
    assert var_out != spec_out, "%s: no divergence at %r!" % (name, witness)
    print("PASS %s REJECTED -- witness %s: spec=%s, variant=%s -- %s"
          % (name, witness, spec_out, var_out, note))


# ---- variant_1: external-Boolean flag ----
def variant_1(ca, cb, flag):
    if flag:
        return "forced_decay"
    return spec(ca, cb)


w1 = ((1, 0), (0, 1), True)  # full cover: residue 0 -> attraction under spec
reject("variant_1 external-Boolean flag", w1, spec(w1[0], w1[1]), variant_1(*w1),
       "flag forces decay regardless of residue (void input, rejected)")
rejected += 1


# ---- variant_2: off-by-one fuse, decay iff residue >= TH ----
def variant_2(ca, cb):
    r = res(ca, cb)
    if r >= TH_LIVE:
        return "forced_decay"
    return spec(ca, cb)


w2 = ((2, 0), (0, 1))  # residue 1 == TH -> repulsion under spec
reject("variant_2 off-by-one (>= TH)", w2, spec(*w2), variant_2(*w2),
        "decays at residue==TH; spec holds the fuse at >TH (kills repulsion)")
rejected += 1


# ---- variant_3: fuseless, any residue > 0 decays (kills repulsion) ----
def variant_3(ca, cb):
    if res(ca, cb) > 0:
        return "forced_decay"
    return spec(ca, cb)


t3 = {o: 0 for o in OUTCOMES}
for ca, cb in PAIRS:
    t3[variant_3(ca, cb)] += 1
assert t3["repulsion"] == 0, t3
print("PASS variant_3 fuseless REJECTED -- repulsion unrealized over %d pairs: %s"
      % (len(PAIRS), t3))
rejected += 1


# ---- variant_4: total-tension, decay iff tau(A)+tau(B) > TH (steals cover) ----
def variant_4(ca, cb):
    if (ca[0] + ca[1]) + (cb[0] + cb[1]) > TH_LIVE:
        return "forced_decay"
    return spec(ca, cb)


theft = [(ca, cb) for ca, cb in PAIRS
         if res(ca, cb) == 0 and variant_4(ca, cb) == "forced_decay"]
assert theft, "variant_4 stole nothing -- check design"
w4 = theft[0]
reject("variant_4 total-tension", w4, spec(*w4), variant_4(*w4),
        "steals %d full-cover cases from attraction (e.g. %s)" % (len(theft), w4))
rejected += 1


# ---- variant_5: order-dependent variant.
# Reads tuple ORDER: decays iff the first port of A is +1 and the first port
# of B is -1, else falls back to the spec. Rejection: a SAME-COUNT pair of
# orderings -- identical count vectors, identical spec outcomes, but
# different variant outcomes.
def variant_5(tup_a, tup_b):
    if tup_a and tup_b and tup_a[0] == 1 and tup_b[0] == -1:
        return "forced_decay"
    return spec(counts_of(tup_a), counts_of(tup_b))


def distinct_orderings(ca):
    ports = [1] * ca[0] + [-1] * ca[1]
    return sorted(set(permutations(ports)))


w5 = None
for ca in COUNTS:
    if ca == (0, 0):
        continue   # incoming side all-zero: outside the taxonomy domain
    for cb in COUNTS:
        sa = spec(ca, cb)
        bad = good = None
        for oa in distinct_orderings(ca):
            for ob in distinct_orderings(cb):
                mo = variant_5(oa, ob)
                if mo != sa and bad is None:
                    bad = (oa, ob, mo)
                if mo == sa and good is None:
                    good = (oa, ob, mo)
        if bad and good:
            w5 = (ca, cb, sa, bad, good)
            break
    if w5:
        break
assert w5, "variant_5 never splits on orderings -- check design"
ca5, cb5, sa5, bad5, good5 = w5
assert counts_of(bad5[0]) == ca5 and counts_of(good5[0]) == ca5
assert counts_of(bad5[1]) == cb5 and counts_of(good5[1]) == cb5
print("PASS variant_5 order-dependent REJECTED -- same counts ca=%s, cb=%s, spec=%s on both:"
      % (ca5, cb5, sa5))
print("     ordering A=%s B=%s -> variant=%s (spec=%s)" % (bad5[0], bad5[1], bad5[2], sa5))
print("     ordering A=%s B=%s -> variant=%s (spec=%s)" % (good5[0], good5[1], good5[2], sa5))
print("     variant outcome depends on tuple order; spec does not (count vectors only)")
rejected += 1


# ---- variant_6: topology-smuggling variant.
# Reads PORT IDENTITY: decays iff any port_id presented by A is even, else
# falls back to the spec. Rejection: same-count, DIFFERENT-IDENTITY
# structures -- identical count vectors, identical spec outcomes, but
# different variant outcomes.
def counts_of_struct(struct):  # [(port_id, label), ...]
    return counts_of([s for _, s in struct])


def variant_6(struct_a, struct_b):
    if any(pid % 2 == 0 for pid, _ in struct_a):
        return "forced_decay"
    return spec(counts_of_struct(struct_a), counts_of_struct(struct_b))


ca6, cb6 = (1, 1), (1, 1)
sa6 = spec(ca6, cb6)
A_even = [(0, 1), (1, -1)]   # carries an even port_id
A_odd = [(1, 1), (3, -1)]    # all-odd port_ids, same labels
B6 = [(2, -1), (4, 1)]
assert counts_of_struct(A_even) == counts_of_struct(A_odd) == ca6
assert counts_of_struct(B6) == cb6
var6_even, var6_odd = variant_6(A_even, B6), variant_6(A_odd, B6)
assert var6_even != var6_odd and var6_even != sa6
print("PASS variant_6 topology-smuggling REJECTED -- same counts ca=%s, cb=%s, spec=%s on both:"
      % (ca6, cb6, sa6))
print("     ids A=%s -> variant=%s (spec=%s)" % ([i for i, _ in A_even], var6_even, sa6))
print("     ids A=%s -> variant=%s (spec=%s)" % ([i for i, _ in A_odd], var6_odd, sa6))
print("     variant outcome depends on port identity; spec does not (counts only)")
rejected += 1


# ---- variant_7: non-total variant (totality check). Returns None on a valid
# input (residue == 1) instead of one of the three outcomes.
def variant_7(ca, cb):
    if res(ca, cb) == 1:
        return None
    return spec(ca, cb)


holes = [(ca, cb) for ca, cb in PAIRS if variant_7(ca, cb) not in OUTCOMES]
assert holes, "variant_7 total everywhere -- check design"
w7 = holes[0]
assert res(*w7) == 1 and variant_7(*w7) is None
print("PASS variant_7 non-total REJECTED -- totality check: %d inputs map outside the three outcomes"
      % len(holes))
print("     e.g. ca=%s, cb=%s (residue 1) -> variant=None, spec=%s"
      % (w7[0], w7[1], spec(*w7)))
rejected += 1

assert rejected == 7, "only %d/7 taxonomy variants rejected" % rejected
print("PASS SUITE: %d/7 taxonomy variants rejected; zero survivors over %d count-vector pairs"
      % (rejected, len(PAIRS)))


# ============================ SECTION 9: encounter tension analysis
print("=" * 70)
print("SECTION 9: encounter tension analysis -- D1-D3, Lemma, Thms S/N/G/A/F")


def presented_tension(A, B):
    """D1: T(A,B) = sum x^2 over both presented tuples (definitional
    application of tau(sigma), section 7.5). In the model this is u_A + u_B."""
    return sum(x * x for x in A) + sum(y * y for y in B)


def greedy_pairing(A, B):
    """D2: candidate junction as a list of (i, j) opposite-sign index pairs.
    Each nonzero A port in order consumes the first still-free opposite-sign
    B port. m = len(pairs). (Independent of residue_vec: no counts, no mins.)"""
    Bfree = list(range(len(B)))
    pairs = []
    for i, a in enumerate(A):
        if a == 0:
            continue
        for j in Bfree:
            if B[j] == -a:                      # nonzero b of opposite sign
                pairs.append((i, j))
                Bfree.remove(j)
                break
    return pairs


def tension_after(A, B, pairs):
    """Tension after establishing the pairing: paired ports consumed to 0."""
    ca = {i for i, _ in pairs}
    cb = {j for _, j in pairs}
    return (sum(a * a for i, a in enumerate(A) if i not in ca)
            + sum(b * b for j, b in enumerate(B) if j not in cb))


def u_of(t):
    return sum(1 for v in t if v != 0)


def max_pairing(A, B):
    """Exhaustive maximum A-port pairing (D2, independent of the greedy)."""
    a_idx = [i for i, a in enumerate(A) if a != 0]
    b_idx = [j for j, b in enumerate(B) if b != 0]
    best = [0]

    def rec(k, used, count):
        if k == len(a_idx):
            if count > best[0]:
                best[0] = count
            return
        if count + (len(a_idx) - k) <= best[0]:
            return
        rec(k + 1, used, count)          # leave A[k] unpaired
        i = a_idx[k]
        for j in b_idx:
            if j not in used and B[j] == -A[i]:
                used.add(j)
                rec(k + 1, used, count + 1)
                used.discard(j)

    rec(0, set(), 0)
    return best[0]


# ---- Lemma (tension bookkeeping): T_after = T_before - 2m, all in-domain pairs
n_lemma = 0
for A in tuples_A:
    for B in tuples:
        prs = greedy_pairing(A, B)
        m = len(prs)
        tb = presented_tension(A, B)
        ta = tension_after(A, B, prs)
        assert ta == tb - 2 * m, (A, B, prs)
        n_lemma += 1
print("  Lemma: T_after = T_before - 2m over %d in-domain pairs" % n_lemma)

# ---- greedy is optimal: exhaustive max pairing agrees (k = 1..4)
tuples4 = [t for k in range(1, 5) for t in product(VALUES, repeat=k)]
tuples4_A = [t for t in tuples4 if any(v != 0 for v in t)]
n_opt = 0
for A in tuples4_A:
    for B in tuples4:
        assert len(greedy_pairing(A, B)) == max_pairing(A, B), (A, B)
        n_opt += 1
print("  greedy pairing optimal: agrees with exhaustive max on %d pairs (k=1..4)"
      % n_opt)

# ---- Theorems S, F(i)-(iii): branch structure coherent with T (TH = TH_LIVE)
nS = nF2 = nF3 = 0
for A in tuples_A:
    uA = u_of(A)
    for B in tuples:
        ca = counts_of(A)
        cb = counts_of(B)
        r = residue_vec(ca, cb)
        prs = greedy_pairing(A, B)
        m = len(prs)
        # irreducibility core: exactly u_A - res A-ports are pairable, so at
        # least res stay unconsumed under EVERY pairing (greedy optimal)
        assert m == uA - r, (A, B, m, uA, r)
        tb = presented_tension(A, B)
        ta = tension_after(A, B, prs)
        assert ta == tb - 2 * m
        if r == 0:
            # Theorem S: cover consumes all u_A ports; strict decrease
            assert m == uA >= 1 and ta == tb - 2 * uA < tb
            assert select_values(A, B)[0] == "attraction"
            nS += 1
        elif r <= TH_LIVE:
            # Theorem F(ii): residual res > 0 irreducible; junction rejected
            assert ta == tb - 2 * (uA - r)
            assert select_values(A, B)[0] == "repulsion"
            nF2 += 1
        else:
            # Theorem F(iii): no pairing discharges; boundary transition
            assert select_values(A, B)[0] == "forced_decay"
            nF3 += 1
print("  Thm S : res=0 + u_A>=1 -> completable strict decrease on %d pairs" % nS)
print("  Thm F : 0<res<=TH -> irreducible residual, repulsion on %d pairs" % nF2)
print("          res>TH -> forced_decay on %d pairs" % nF3)

# ---- Theorem S witness W-a (printed): sufficiency with the arithmetic shown
A_a, B_a = (+1, -1), (-1, +1, +1)
uA_a, uB_a = u_of(A_a), u_of(B_a)
tb_a = presented_tension(A_a, B_a)                        # 5
r_a = residue_vec(counts_of(A_a), counts_of(B_a))        # 0
prs_a = greedy_pairing(A_a, B_a)
ta_a = tension_after(A_a, B_a, prs_a)                     # 1
assert (uA_a, uB_a, tb_a, r_a) == (2, 3, 5, 0)
assert len(prs_a) == uA_a == 2 and ta_a == 1 == uB_a - uA_a
assert select_values(A_a, B_a)[0] == "attraction"
print("  Thm S : W-a A=(+1,-1) B=(-1,+1,+1): u_A=2, u_B=3, T_before=5, res=0;")
print("          cover pairing m=2: T_after = 5 - 2*2 = 1 < 5 = u_B - u_A (strict)")

# ---- Theorem N: strict T reduction does NOT imply res = 0 (witness W-b)
A_b, B_b = (+1, +1), (-1, 0)
tb_b = presented_tension(A_b, B_b)                       # 3
ta_b = tension_after(A_b, B_b, greedy_pairing(A_b, B_b))  # 1
r_b = residue_vec(counts_of(A_b), counts_of(B_b))        # 1
assert ta_b < tb_b and r_b == 1
assert select_values(A_b, B_b)[0] == "repulsion"
n_partial = 0
for A in tuples_A:
    for B in tuples:
        if residue_vec(counts_of(A), counts_of(B)) != 0 and \
           tension_after(A, B, greedy_pairing(A, B)) < presented_tension(A, B):
            n_partial += 1
print("  Thm N : W-b A=(+1,+1) B=(-1,0): T 3 -> 1 but res=1 -> repulsion;")
print("          %d in-domain pairs reduce T without cover (partial matching)" % n_partial)

# ---- Theorem G: u_A = 0 is degenerate; the guard is necessary (witness W-c)
A_c, B_c = (0, 0), (+1, -1)
assert presented_tension(A_c, B_c) == 2
assert residue_vec(counts_of(A_c), counts_of(B_c)) == 0
assert greedy_pairing(A_c, B_c) == []
assert tension_after(A_c, B_c, []) == presented_tension(A_c, B_c) == 2
assert select_values(A_c, B_c) is None
try:
    select_counts(counts_of(A_c), counts_of(B_c))
    raise AssertionError("guard failed: A-all-zero accepted by select_counts")
except ValueError:
    pass
try:
    select_native([(0, 0), (1, 0)], [(2, 1), (3, -1)])
    raise AssertionError("guard failed: A-all-zero accepted by select_native")
except ValueError:
    pass
n_refused = 0
for A in tuples:
    if any(v != 0 for v in A):
        continue
    for B in tuples:
        try:
            select_counts(counts_of(A), counts_of(B))
            raise AssertionError("guard failed on %r x %r" % (A, B))
        except ValueError:
            n_refused += 1
print("  Thm G : W-c A=(0,0) B=(+1,-1): res=0, m=0, T 2 -> 2 (no reduction);")
print("          guard refuses all %d A-all-zero pairs (ValueError/None)" % n_refused)

# ---- Theorem A: asymmetric labels -- B's unmatched labels stay presented (W-d)
A_d, B_d = (+1,), (-1, -1, +1)
uA_d, uB_d = u_of(A_d), u_of(B_d)
tb_d = presented_tension(A_d, B_d)                        # 4
prs_d = greedy_pairing(A_d, B_d)
ta_d = tension_after(A_d, B_d, prs_d)                     # 2
rAB_d = residue_vec(counts_of(A_d), counts_of(B_d))      # 0
rBA_d = residue_vec(counts_of(B_d), counts_of(A_d))      # 2
assert ta_d == uB_d - uA_d == 2 and tb_d == 4
assert rAB_d == 0 and rBA_d == 2
assert select_values(A_d, B_d)[0] == "attraction"
consumed_b = {j for _, j in prs_d}
leftovers = [b for j, b in enumerate(B_d) if j not in consumed_b]
assert leftovers == [-1, +1] and all(b != 0 for b in leftovers)
print("  Thm A : W-d A=(+1,) B=(-1,-1,+1): res(A,B)=0, res(B,A)=2 -> attraction;")
print("          T 4 -> 2 = u_B - u_A; B leftovers (-1,+1) unconsumed, still presented")

# ---- Theorem F witnesses W-e: the fuse bands
# E1: decay band
A_e1, B_e1, TH_e = (+1, +1, -1), (-1, 0, 0), 1
r_e1 = residue_vec(counts_of(A_e1), counts_of(B_e1))
assert r_e1 == 2 > TH_e and select_values(A_e1, B_e1, TH_e)[0] == "forced_decay"
# E2: repulsion band (same tuples as W-b)
assert select_values(A_b, B_b, 1)[0] == "repulsion"
# E3: the total-tension-fuse variant rejection is below; record the spec side
A_e3, B_e3 = (+1,), (-1,) * 60
r_e3 = residue_vec(counts_of(A_e3), counts_of(B_e3))
assert r_e3 == 0 and select_values(A_e3, B_e3, 1)[0] == "attraction"
assert presented_tension(A_e3, B_e3) == 61
assert tension_after(A_e3, B_e3, greedy_pairing(A_e3, B_e3)) == 59
print("  Thm F : W-e E1 res=2>TH=1 -> forced_decay; E2 res=1 -> repulsion;")
print("          E3 res=0, T 61 -> 59 -> attraction (see the total-tension-fuse variant below)")

print("PASS 9: D1-D3, Lemma, and Theorems S/N/G/A/F machine-checked;")
print("        irreducibility (exactly u_A - res A-ports pairable) holds on")
print("        all %d in-domain pairs." % n_lemma)

# branch-vs-T summary (in-domain, u_A >= 1):
print("  res(A,B) | branch       | T-analysis")
print("  0        | attraction   | completable; T strictly decreases by 2*u_A (Thm S)")
print("  0<res<=TH| repulsion    | no completion; residual res>0 irreducible (Thm F(ii))")
print("  res>TH   | forced_decay | no pairing discharges; boundary transition (Thm F(iii))")


# ============================ SECTION 9b: tension-analysis planted variants
print("=" * 70)
print("SECTION 9b: tension-analysis planted variants (5) -- 0 survivors")

rejectedV = 0


def rejectV(name, witness, spec_out, var_out, note):
    assert var_out != spec_out, "%s: no divergence at %r!" % (name, witness)
    print("PASS %s REJECTED -- witness %s: spec=%s, variant=%s -- %s"
          % (name, witness, spec_out, var_out, note))


# ---- guardless attraction: attraction without the guard (res = 0 -> attraction, no u_A >= 1 check)
def guardless_rule(A, B):
    if residue_vec(counts_of(A), counts_of(B)) == 0:
        return "attraction"
    return select_values(A, B)[0]


wGuardless = ((0, 0), (+1, -1))   # W-c: res = 0, but A presents nothing
try:
    select_counts(counts_of(wGuardless[0]), counts_of(wGuardless[1]))
    specGuardless = "no-refusal (BUG)"
except ValueError:
    specGuardless = "refused (ValueError)"
assert presented_tension(*wGuardless) == tension_after(wGuardless[0], wGuardless[1], []) == 2
rejectV("guardless-attraction", wGuardless, specGuardless, guardless_rule(*wGuardless),
        "variant emits attraction with m=0, T 2->2, vacuous mechanism")
rejectedV += 1


# ---- reduction-sufficient: tension reduction as sufficient for attraction
def reduction_sufficient_rule(A, B):
    if tension_after(A, B, greedy_pairing(A, B)) < presented_tension(A, B):
        return "attraction"
    return select_values(A, B)[0]


wReduction = ((+1, +1), (-1, 0))  # W-b: T 3 -> 1, res = 1 -> spec says repulsion
rejectV("reduction-sufficient", wReduction, select_values(*wReduction)[0],
        reduction_sufficient_rule(*wReduction),
        "partial matching reduces T without cover; attraction needs completion")
rejectedV += 1


# ---- inverted functional: inverted tension functional (sum x^2 over MATCHED ports)
def tau_tilde(A, B, pairs):
    return (sum(A[i] * A[i] for i, _ in pairs)
            + sum(B[j] * B[j] for _, j in pairs))


wInverted = ((+1,), (-1,))
prsInverted = greedy_pairing(*wInverted)
t_before, t_after = presented_tension(*wInverted), tension_after(wInverted[0], wInverted[1], prsInverted)
tt_before, tt_after = 0, tau_tilde(wInverted[0], wInverted[1], prsInverted)
assert (t_before, t_after) == (2, 0)      # correct T: 2 -> 0 (Relief: Delta tau < 0)
assert (tt_before, tt_after) == (0, 2)    # inverted: 0 -> 2 (INCREASE)
print("PASS inverted-functional REJECTED -- witness %s:" % (wInverted,))
print("     correct T: 2 -> 0 (decrease, Relief theorem); inverted tau-tilde:")
print("     0 -> 2 (increase -- contradicts the Relief theorem's Delta tau < 0")
print("     per action)")
rejectedV += 1


# ---- total-tension fuse: forced_decay iff T_before > TH
def total_tension_fuse_rule(A, B, TH=TH_LIVE):
    if presented_tension(A, B) > TH:
        return "forced_decay"
    return select_values(A, B, TH)[0]


wFuse = ((+1,), (-1,) * 60)   # W-e E3: res = 0 -> attraction, T 61 -> 59
specFuse = select_values(*wFuse, 1)[0]
varFuse = total_tension_fuse_rule(*wFuse, 1)
assert (specFuse, varFuse) == ("attraction", "forced_decay")
rejectV("total-tension-fuse", "A=(+1,) B=sixty(-1) TH=1", specFuse, varFuse,
        "steals a full-cover case from attraction (T 61 -> 59, strict decrease);"
        " the fuse must watch res, not T")
rejectedV += 1


# ---- symmetric residue: attraction iff res both ways is 0
def symmetric_residue_rule(A, B):
    ca, cb = counts_of(A), counts_of(B)
    return ("attraction"
            if residue_vec(ca, cb) == 0 and residue_vec(cb, ca) == 0
            else "repulsion")


wSymmetric = ((+1,), (-1, -1, +1))  # W-d: res(A,B)=0, res(B,A)=2 -> spec says attraction
rejectV("symmetric-residue", wSymmetric, select_values(*wSymmetric)[0], symmetric_residue_rule(*wSymmetric),
        "directional encounter: B's labels are B's inventory, not A's load")
rejectedV += 1

assert rejectedV == 5, "only %d/5 tension variants rejected" % rejectedV
print("PASS SUITE: %d/5 tension-analysis variants rejected; zero survivors"
      % rejectedV)


# ------------------------------------------------------------------ summary
print("=" * 70)
print("ALL PASS: interaction-taxonomy coverage + encounter tension analysis --")
print("every in-domain native encounter gets exactly one outcome via the")
print("coverage map M (select_native == select_model o M), and the tension")
print("theorems S/N/G/A/F hold over the model with native transfer per the")
print("coverage map.")
print("  domains : 129,954 in-domain tuple pairs in 2,750 count-vector groups")
print("            (factorization; A presents >= 1 nonzero port);")
print("            201,110 count-vector pairs enumerated (totality/mutex/bounds);")
print("            %d preservation checks through M (0 divergences);" % n_pres)
print("            %d real-aggregate encounters (0 mismatches);" % total)
print("            420 count-vector pairs in the taxonomy variant suite;")
print("            %d in-domain pairs in the tension bookkeeping sweep." % n_lemma)
print("  variants: 12/12 rejected (7 taxonomy: external-Boolean, off-by-one,")
print("            fuseless, total-tension, order-dependent,")
print("            topology-smuggling, non-total; 5 tension-analysis:")
print("            guardless-attraction, reduction-sufficient, inverted")
print("            functional, total-tension fuse, symmetric residue);")
print("            0 survivors.")
print("  band    : enumeration k=1..8 plus parametric witnesses (residues {0,1,k})")
print("            verified over %d k values incl. 10^18; B-reduction lemma over"
      " %d pairs." % (len(K_GRID), N_LEMMA))
print("  guard   : %d A-all-zero pairs refused (Theorem G)." % n_refused)
print("=" * 70)