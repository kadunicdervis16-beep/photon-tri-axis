#!/usr/bin/env python3
"""Paper 11 - F.37: complexity-ordering derivation (rebuilt from first principles).

Derives the section 12.1 complexity ordering from UNORDERED structural
records with an instrumented symbolic lexicographic comparator over
(node count, tilt count, resolution status), least to most complex.
The previous version of this script hardcoded the six classes in claim
order with 10**6 sentinels and checked only that its own list was
sorted -- the conclusion baked into the input. This rebuild computes
all 15 pairwise comparisons, asserts totality (every pair comparable,
strict, no ties) and transitivity, reads off the linear order, and only
then checks it against the section 12.1 enumerated sequence (the test
oracle).

[LEVEL B] backing for registry claim COMPLEXITY_ORDERING ("structural
ordering by departure"). Badge stays B: the machine check covers the
finite key algebra over the declared records, not physical
realizability.

"Precedes" is an enumeration position only -- no temporal order, no
continuous progress, no purpose, no degree of resolvedness. Resolution
status is a discrete class marker with exact domain {0, 1}; the
validator rejects anything else (a float status would smuggle a scalar
degree into the key). Node counts are affine triples (c, m, s)
denoting c + m*u + s*v with u, v >= 0 integers; a node difference
decides only when its sign is determined for every admissible (u, v).
Paper-silent slots carry the PAPER_SILENT token; consulting one raises
Underdetermined -- the driver prints the witness instead of guessing.

Coverage map:
  native domain .... section 12.1's six exemplar classes
  verified domain .. the finite lexicographic key over the six declared
                     records (symbolic node counts where the paper says
                     "many")
  the map ......... row by row (printed on every run)
  preserved ....... the strict chain, CONDITIONALLY: given M > 3,
                    S >= 1, and tilt-equality of the two 3-node rows;
                    the resolution tie-break for any shared tilt value;
                    tilt-independence of the nuclei/atoms steps
  outside ......... record contents beyond the cited words; Paper 2
                    construction details; boundary-port counts
                    (descriptive in section 12.1, not part of the key --
                    section 12.3 names only node count, tilt count,
                    resolution status); class exhaustiveness;
                    ordering extension beyond atoms (molecules,
                    macro-matter -- Paper 12's declared scope, section 16
                    of the paper); physical realizability
"""

import copy
import random
import sys
from functools import cmp_to_key


INPUT_PROVENANCE = {
    "PHOTON": {
        "class": "paper-defined",
        "source": "§12.1 item 1",
        "anchor": "zero internal nodes",
        "gloss": "nodes=(0,0,0) 'zero internal nodes'; tilt=0 'zero departure'; res=PAPER_SILENT (paper-silent; consulting it raises Underdetermined)",
    },
    "OPEN_TILTED": {
        "class": "paper-defined",
        "source": "§12.1 item 2",
        "anchor": "single-axis departure",
        "gloss": "nodes=(1,0,0) 'one internal node'; tilt=1 records the gloss 'single-axis departure' as one tilt axis; res=PAPER_SILENT (paper-silent)",
    },
    "MESON_LIKE": {
        "class": "paper-defined",
        "source": "§12.1 item 3; §12.4",
        "anchor": "transient",
        "gloss": "nodes=(3,0,0) 'three nodes' (§12.1); res=0 'transient' via the §12.4 mapping (transient = 0); tilt carries the shared token (declared-assumption -- see TILT_TOKEN)",
    },
    "BARYON_LIKE": {
        "class": "paper-defined",
        "source": "§12.1 item 4; §12.4",
        "anchor": "resolution",
        "gloss": "nodes=(3,0,0) 'three nodes' (§12.1); res=1 'resolution achieved' via the §12.4 mapping (resolution-achieved = 1); tilt carries the same shared token (declared-assumption -- see TILT_TOKEN)",
    },
    "TILT_TOKEN": {
        "class": "declared-assumption",
        "prose": "§12.1: tilt-equality of the two 3-node rows is an interpretive bridge -- §12.1 states only 'three nodes' per row, under the shared 'Tri-Axis' construction names. Paper 2 sections 11.4 and 11.5 were inspected with the text open: no numeric tilt count is stated there ('all three axes engaged' is descriptive geometry, not a count datum), so the equality stays a thin declared assumption; the tie-break is verified for ANY shared tilt value.",
    },
    "NUCLEI": {
        "class": "declared-assumption",
        "prose": "§12.1 item 5: 'many nodes' is read as strictly more than the 3-node rows, i.e. nodes M = 4+u with u >= 0 integer. That strict inequality is an interpretive bridge from the paper's 'many', FLAGGED as such. res=1 'resolved interiors' (§12.1); tilt is PAPER_SILENT.",
    },
    "ATOMS": {
        "class": "declared-assumption",
        "prose": "§12.1 item 6: 'nuclei plus incorporated simple states' / 'many more nodes' is encoded as the NET inequality S >= 1, nodes M+S = 5+u+v with u, v >= 0 integers. No per-incorporated-state node claim is made. tilt and res are PAPER_SILENT.",
    },
    "ORACLE": {
        "class": "paper-defined",
        "source": "§12.1",
        "anchor": "The complexity ordering of the paper's six canonical exemplar classes",
        "gloss": "test oracle: the §12.1 enumerated sequence, the prediction under test (legitimate expected-value input).",
    },
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "pairwise ordering comparisons; not aspect-kind-quantified.",
}


# ---------------------------------------------------------------------------
# Structural records. Each is a self-contained literal: nodes is an affine
# triple (const, m_coeff, s_coeff) = const + m*u + s*v (u, v >= 0 integers);
# tilt is an int count, a shared opaque token, or PAPER_SILENT; res is 0/1
# or PAPER_SILENT. The records never appear in claim order at module level.
# ---------------------------------------------------------------------------
PHOTON = {"nodes": (0, 0, 0), "tilt": 0, "res": "PAPER_SILENT"}
OPEN_TILTED = {"nodes": (1, 0, 0), "tilt": 1, "res": "PAPER_SILENT"}
MESON_LIKE = {"nodes": (3, 0, 0), "tilt": "TRI_AXIS_SHARED", "res": 0}
BARYON_LIKE = {"nodes": (3, 0, 0), "tilt": "TRI_AXIS_SHARED", "res": 1}
NUCLEI = {"nodes": (4, 1, 0), "tilt": "PAPER_SILENT", "res": 1}
ATOMS = {"nodes": (5, 1, 1), "tilt": "PAPER_SILENT", "res": "PAPER_SILENT"}

TILT_TOKEN = "TRI_AXIS_SHARED"

ORACLE = ["photon", "open_tilted", "meson_like", "baryon_like", "nuclei", "atoms"]


class Underdetermined(Exception):
    """A comparison consulted a paper-silent slot or met a node difference
    whose sign is not determined for all u, v >= 0. The driver catches
    this and prints FAIL -- <witness>; it never escapes as a traceback."""


# Symbolic engine spec (auditable):
#  1. A node value is an affine triple (c, m, s) = c + m*u + s*v, u,v >= 0 integers.
#  2. A node difference d = a - b is the componentwise triple (dc, dm, ds).
#  2b. The zero difference (0,0,0) is an exact tie, not an undecided
#      difference: the comparator moves to the next component.
#  3. A nonzero d decides +1 iff dc > 0 and dm >= 0 and ds >= 0.
#  4. d decides -1 iff dc < 0 and dm <= 0 and ds <= 0.
#  5. Otherwise d is not sign-determined -> raise Underdetermined.
#  6. Tilt: int/int compares numerically; equal opaque tokens tie; a
#     PAPER_SILENT slot or two distinct opaque values -> Underdetermined.
#  7. Resolution: int/int compares numerically (validator enforces {0,1});
#     a PAPER_SILENT slot -> Underdetermined.
#  8. Lexicographic order: nodes, then tilt, then resolution.
#  9. compare() returns (sign, decider); sign 0 with decider "tie" only
#     when all three components tie.
# 10. Underdetermined is caught by the driver and printed as
#     FAIL -- <witness>; it never escapes as a traceback.
def _cmp_nodes(na, nb):
    dc, dm, ds = na[0] - nb[0], na[1] - nb[1], na[2] - nb[2]
    if dc == 0 and dm == 0 and ds == 0:
        return 0  # exact tie: move to the next lexicographic component
    if dc > 0 and dm >= 0 and ds >= 0:
        return 1
    if dc < 0 and dm <= 0 and ds <= 0:
        return -1
    raise Underdetermined(
        "nodes: difference (%d, %d, %d) not sign-determined for u, v >= 0"
        % (dc, dm, ds))


def _cmp_tilt(ta, tb):
    if type(ta) is int and type(tb) is int:
        return (ta > tb) - (ta < tb)
    if ta == "PAPER_SILENT" or tb == "PAPER_SILENT":
        raise Underdetermined("tilt: paper-silent slot consulted")
    if ta == tb:
        return 0
    raise Underdetermined("tilt: distinct opaque values %r vs %r" % (ta, tb))


def _cmp_res(ra, rb):
    if type(ra) is int and type(rb) is int:
        return (ra > rb) - (ra < rb)
    raise Underdetermined("resolution: paper-silent slot consulted")


def compare(ra, rb):
    """Instrumented lexicographic comparator. Returns (sign, decider)."""
    d = _cmp_nodes(ra["nodes"], rb["nodes"])
    if d:
        return d, "nodes"
    d = _cmp_tilt(ra["tilt"], rb["tilt"])
    if d:
        return d, "tilt"
    d = _cmp_res(ra["res"], rb["res"])
    if d:
        return d, "resolution"
    return 0, "tie"


def validate(rec, name):
    """Key validator: genuine ints only (bool excluded by type-is-int),
    node const >= 0, resolution status exactly in {0, 1} unless
    paper-silent. A float status would smuggle a scalar degree of
    resolvedness into the key; it is rejected here, not rounded."""
    n = rec["nodes"]
    if not (type(n) is tuple and len(n) == 3
            and all(type(x) is int for x in n)):
        raise AssertionError(
            "validation: %s nodes %r is not an int affine triple" % (name, n))
    if n[0] < 0:
        raise AssertionError(
            "validation: %s has negative node count %r" % (name, n))
    t = rec["tilt"]
    if not ((type(t) is int and t >= 0) or type(t) is str):
        raise AssertionError(
            "validation: %s has non-integer tilt %r" % (name, t))
    r = rec["res"]
    if not (r == "PAPER_SILENT" or (type(r) is int and r in (0, 1))):
        raise AssertionError(
            "validation: %s has resolution %r outside {0,1}" % (name, r))


def derive(records):
    """Compute all pairwise comparisons; return (order, pairs, deciders).

    Pair keys are name-sorted so the result is independent of input order.
    Raises Underdetermined when a comparison cannot be decided; asserts
    strictness (no ties) -- together, completion of this function over all
    pairs is the totality check.
    """
    for name, rec in records.items():
        validate(rec, name)
    names = sorted(records)
    pairs = {}
    deciders = {}
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            sign, decider = compare(records[a], records[b])
            assert sign != 0, (
                "tie: %s vs %s indistinguishable on (nodes, tilt, resolution)"
                % (a, b))
            pairs[(a, b)] = sign
            deciders[(a, b)] = decider

    def _cmp_names(x, y):
        key = (x, y) if x < y else (y, x)
        s = pairs[key]
        return s if x < y else -s

    order = sorted(names, key=cmp_to_key(_cmp_names))
    return order, pairs, deciders


def check_transitivity(order, pairs):
    """Diagnostic: the read-off linear order must agree with every pair."""
    pos = {name: i for i, name in enumerate(order)}
    for (a, b), sign in pairs.items():
        expect = -1 if pos[a] < pos[b] else 1
        assert expect == sign, (
            "transitivity: pair (%s, %s) sign %d disagrees with the linear order"
            % (a, b, sign))


def _print_assumptions():
    print("declared assumptions (INPUT_PROVENANCE; printed on every run):")
    for name, entry in INPUT_PROVENANCE.items():
        if entry["class"] == "declared-assumption":
            print("  - %s [%s]: %s" % (name, entry["class"], entry["prose"]))


def _print_coverage_map():
    rows = [
        ("photon",      "(0,0,0)",       "0",            "PAPER_SILENT", "least"),
        ("open_tilted", "(1,0,0)",       "1",            "PAPER_SILENT", ""),
        ("meson_like",  "(3,0,0)",       "shared token", "0",            ""),
        ("baryon_like", "(3,0,0)",       "shared token", "1",            ""),
        ("nuclei",      "(4,1,0) = 4+u", "PAPER_SILENT", "1",            ""),
        ("atoms",       "(5,1,1)=5+u+v", "PAPER_SILENT", "PAPER_SILENT", "most"),
    ]
    print("coverage map:")
    print("  native domain ....: section 12.1's six exemplar classes")
    print("  verified domain ..: finite lexicographic key (nodes, tilt, resolution)")
    print("                      over the declared records")
    for name, nodes, tilt, res, tag in rows:
        print("  map: %-12s nodes=%-15s tilt=%-12s res=%-12s %s"
              % (name, nodes, tilt, res, tag))
    print("  preserved ........: strict chain GIVEN M>3, S>=1, tilt-equality;")
    print("                      resolution tie-break for any shared tilt value;")
    print("                      tilt-independence of the nuclei/atoms steps")
    print("  outside ..........: record contents beyond the cited words; Paper 2")
    print("                      construction details; boundary-port counts")
    print("                      (descriptive, not in the key); class")
    print("                      exhaustiveness; physical realizability")


def _attempt(records):
    """One derivation attempt for the mutant harness.

    Returns (kind, witness, deciders-or-None); kind is one of 'ok',
    'underdetermined', 'assert', 'oracle-mismatch'.
    """
    try:
        order, pairs, deciders = derive(records)
    except Underdetermined as exc:
        return ("underdetermined", str(exc), None)
    except AssertionError as exc:
        return ("assert", str(exc), None)
    if list(order) != list(ORACLE):
        return ("oracle-mismatch",
                "computed %s vs oracle %s" % (list(order), list(ORACLE)),
                deciders)
    return ("ok", "order %s matches oracle" % (list(order),), deciders)


def run_mutants(records):
    """Mutants must print REJECTED + witness, never PASS. Diagnostics print
    DIAGNOSTIC; they exercise designed behavior, not rejections."""
    def _set(path, value):
        def go(r):
            tgt = r
            for key in path[:-1]:
                tgt = tgt[key]
            tgt[path[-1]] = value
        return go

    cases = [
        ("M1 float resolution",
         _set(("meson_like", "res"), 1/2),
         lambda kind, wit, dec: (
             kind == "assert" and wit.startswith("validation:")
             and "resolution" in wit, wit)),
        ("M2 negative node count",
         _set(("photon", "nodes"), (-1, 0, 0)),
         lambda kind, wit, dec: (
             kind == "assert" and wit.startswith("validation:")
             and "node" in wit, wit)),
        ("M3 S=0 (atoms==nuclei nodes; chain not strict)",
         _set(("atoms", "nodes"), (4, 1, 0)),
         lambda kind, wit, dec: (
             kind == "underdetermined",
             "S=0 makes atoms/nuclei node triples identical; "
             "comparator Underdetermined (%s)" % wit)),
        ("M4 M bound broken (M=3)",
         _set(("nuclei", "nodes"), (3, 0, 0)),
         lambda kind, wit, dec: (kind == "underdetermined", wit)),
        ("M5 non-integer tilt",
         _set(("open_tilted", "tilt"), 3/2),
         lambda kind, wit, dec: (
             kind == "assert" and wit.startswith("validation:")
             and "tilt" in wit, wit)),
        ("M6 baryon res 1->0 (tie-break destroyed)",
         _set(("baryon_like", "res"), 0),
         lambda kind, wit, dec: (
             kind == "assert" and wit.startswith("tie:"), wit)),
        ("M7 meson nodes 3->4 (reorders)",
         _set(("meson_like", "nodes"), (4, 0, 0)),
         lambda kind, wit, dec: (kind == "underdetermined", wit)),
        ("M8 distinct tilt tokens (tilt-equality load-bearing)",
         _set(("meson_like", "tilt"), "TRI_AXIS_OTHER"),
         lambda kind, wit, dec: (
             kind == "underdetermined" and "opaque" in wit, wit)),
        ("M9 dropped class",
         lambda r: r.pop("atoms"),
         lambda kind, wit, dec: (kind == "oracle-mismatch", wit)),
        ("M10 extra class",
         _set(("extra7",), {"nodes": (2, 0, 0), "tilt": 0, "res": 0}),
         lambda kind, wit, dec: (kind == "oracle-mismatch", wit)),
    ]
    # Diagnostics, not mutants: designed behavior the battery demonstrates
    # rather than rejects. D2 documents the known honest limit -- an
    # order-preserving wrong input passes silently, because content errors
    # evade automated hygiene (code review is the stated backstop).
    diagnostics = [
        ("D1 open nodes 1->0 (decider flips nodes->tilt)",
         _set(("open_tilted", "nodes"), (0, 0, 0)),
         lambda kind, wit, dec: (
             kind == "ok" and dec[("open_tilted", "photon")] == "tilt",
             "decider(photon, open_tilted) flipped nodes->tilt; the paper's "
             "'one internal node' is load-bearing for the decider pattern; "
             "order unchanged")),
        ("D2 meson/baryon nodes 3->2 (order-preserving wrong input passes)",
         lambda r: (r["meson_like"].__setitem__("nodes", (2, 0, 0)),
                    r["baryon_like"].__setitem__("nodes", (2, 0, 0))),
         lambda kind, wit, dec: (
             kind == "ok",
             "order-preserving wrong input passes silently: automated "
             "hygiene cannot catch content errors; code review is the "
             "stated backstop")),
    ]
    n_ok = 0
    for label, mutate, check in cases:
        trial = copy.deepcopy(records)
        mutate(trial)
        kind, wit, dec = _attempt(trial)
        if kind == "underdetermined":
            print("UNDERDETERMINED -- %s" % wit)
        passed, witness = check(kind, wit, dec)
        if passed:
            print("REJECTED -- %s: %s" % (label, witness))
            n_ok += 1
        else:
            print("UNEXPECTED -- %s: kind=%s witness=%r" % (label, kind, wit))
    n_diag = 0
    for label, mutate, check in diagnostics:
        trial = copy.deepcopy(records)
        mutate(trial)
        kind, wit, dec = _attempt(trial)
        passed, witness = check(kind, wit, dec)
        if passed:
            print("DIAGNOSTIC -- %s: %s" % (label, witness))
            n_diag += 1
        else:
            print("UNEXPECTED -- %s: kind=%s witness=%r" % (label, kind, wit))
    print("mutants: %d/%d rejected as designed; diagnostics: %d/%d as "
          "designed" % (n_ok, len(cases), n_diag, len(diagnostics)))
    return n_ok == len(cases) and n_diag == len(diagnostics)


def _truth_table():
    """C4: comparator truth table, including the Underdetermined cases."""
    cases = [
        ("nodes const decides",
         lambda: _cmp_nodes((0, 0, 0), (1, 0, 0)), ("sign", -1)),
        ("nodes symbolic M>3 decides",
         lambda: _cmp_nodes((4, 1, 0), (3, 0, 0)), ("sign", 1)),
        ("nodes M vs M+S decides",
         lambda: _cmp_nodes((4, 1, 0), (5, 1, 1)), ("sign", -1)),
        ("nodes zero const never decides",
         lambda: _cmp_nodes((4, 1, 0), (4, 0, 0)), ("raise",)),
        ("nodes disagreeing signs never decide",
         lambda: _cmp_nodes((5, 1, 0), (4, 2, 0)), ("raise",)),
        ("tilt int compares",
         lambda: _cmp_tilt(0, 1), ("sign", -1)),
        ("tilt shared token ties",
         lambda: _cmp_tilt("TRI_AXIS_SHARED", "TRI_AXIS_SHARED"), ("sign", 0)),
        ("tilt distinct tokens Underdetermined",
         lambda: _cmp_tilt("TRI_AXIS_SHARED", "TRI_AXIS_OTHER"), ("raise",)),
        ("tilt silent slot Underdetermined",
         lambda: _cmp_tilt("PAPER_SILENT", 0), ("raise",)),
        ("resolution 0<1",
         lambda: _cmp_res(0, 1), ("sign", -1)),
        ("resolution silent slot Underdetermined",
         lambda: _cmp_res(1, "PAPER_SILENT"), ("raise",)),
        ("lexicographic: nodes outrank tilt",
         lambda: compare({"nodes": (0, 0, 0), "tilt": 9, "res": 0},
                         {"nodes": (1, 0, 0), "tilt": 0, "res": 0}),
         ("pair", -1, "nodes")),
    ]
    ok = True
    for label, thunk, expected in cases:
        try:
            raw = thunk()
        except Underdetermined:
            raw = "RAISED"
        if expected[0] == "raise":
            good = (raw == "RAISED")
        elif expected[0] == "sign":
            good = (raw == expected[1])
        else:
            good = (raw == (expected[1], expected[2]))
        print("    C4 %-40s %s" % (label, "ok" if good else "MISMATCH got=%r" % (raw,)))
        ok = ok and good
    return ok


def run_controls(records, base_order):
    n_ok = 0
    n_total = 0

    def report(cid, passed, detail):
        print("CONTROL %s %s -- %s" % (cid, "PASS" if passed else "FAIL", detail))
        return passed

    # C1: shuffle-invariance (seeded).
    rng = random.Random(20260927)
    names = list(records.keys())
    rng.shuffle(names)
    shuffled = {n: records[n] for n in names}
    o1, _, _ = derive(shuffled)
    n_total += 1
    n_ok += report("C1", list(o1) == list(base_order),
                   "shuffle-invariance (seed 20260927): input %s -> %s"
                   % (names, list(o1)))

    # C2: concrete instantiations cross-check the symbolic engine.
    for m_val, s_val in ((4, 1), (10 ** 6, 10 ** 6)):
        trial = copy.deepcopy(records)
        trial["nuclei"]["nodes"] = (m_val, 0, 0)
        trial["atoms"]["nodes"] = (m_val + s_val, 0, 0)
        o2, _, _ = derive(trial)
        n_total += 1
        n_ok += report("C2", list(o2) == list(base_order),
                       "concrete M=%d S=%d cross-checks symbolic engine -> %s"
                       % (m_val, s_val, list(o2)))

    # C3: token relabeling.
    trial = copy.deepcopy(records)
    trial["meson_like"]["tilt"] = "RELABELED_TOKEN"
    trial["baryon_like"]["tilt"] = "RELABELED_TOKEN"
    o3, _, d3 = derive(trial)
    n_total += 1
    n_ok += report("C3", list(o3) == list(base_order)
                   and d3[("baryon_like", "meson_like")] == "resolution",
                   "token relabeling: order and resolution tie-break unchanged")

    # C4: comparator truth table.
    n_total += 1
    n_ok += report("C4", _truth_table(),
                   "comparator truth table incl. Underdetermined cases")

    print("controls: %d/%d passed" % (n_ok, n_total))
    return n_ok == n_total


def main():
    print("F.37 complexity-ordering derivation -- Paper 11 section 12.1 [LEVEL B]")
    _print_assumptions()
    _print_coverage_map()

    # Unordered input: alphabetical insertion, never claim order.
    records = {
        "atoms": ATOMS,
        "baryon_like": BARYON_LIKE,
        "meson_like": MESON_LIKE,
        "nuclei": NUCLEI,
        "open_tilted": OPEN_TILTED,
        "photon": PHOTON,
    }
    assert MESON_LIKE["tilt"] == TILT_TOKEN == BARYON_LIKE["tilt"], \
        "records do not carry the declared shared tilt token"

    try:
        order, pairs, deciders = derive(records)
    except Underdetermined as exc:
        print("FAIL -- %s" % exc)
        sys.exit(1)

    print("pairwise comparisons (%d):" % len(pairs))
    for key in sorted(pairs):
        print("  %-12s vs %-12s : %+d  decider=%s"
              % (key[0], key[1], pairs[key], deciders[key]))
    print("computed order: %s" % (list(order),))

    # HEADLINE asserts -- failure means the records and the paper are inconsistent.
    assert len(pairs) == 15, \
        "totality: expected 15 pairwise comparisons, got %d" % len(pairs)
    assert list(order) == list(ORACLE), \
        "HEADLINE order: computed %s != oracle %s" % (list(order), list(ORACLE))
    print("HEADLINE PASS: totality (15/15 comparable, strict, no ties); "
          "computed order matches the section 12.1 oracle")

    # DIAGNOSTIC asserts -- failure means investigate, not "the paper is wrong".
    assert deciders[("baryon_like", "nuclei")] == "nodes", "decider pattern"
    assert deciders[("atoms", "nuclei")] == "nodes", "decider pattern"
    assert deciders[("baryon_like", "meson_like")] == "resolution", "decider pattern"
    print("DIAGNOSTIC PASS: nuclei/atoms steps decided at nodes; "
          "meson/baryon step decided at resolution")
    check_transitivity(order, pairs)
    print("DIAGNOSTIC PASS: transitivity (linear order consistent with all 15 pairs)")

    # Tilt-independence: the nuclei/atoms steps must not consult tilt at all.
    masked = copy.deepcopy(records)
    masked["nuclei"]["tilt"] = "MASKED"
    masked["atoms"]["tilt"] = "MASKED"
    masked_order, _, _ = derive(masked)
    assert list(masked_order) == list(order), "tilt-independence"
    print("DIAGNOSTIC PASS: tilt-independence "
          "(order unchanged with nuclei/atoms tilt masked)")

    # Tie-break robustness: meson/baryon decided at resolution for ANY shared tilt.
    for shared in ("TRI_AXIS_SHARED", "ALT_TOKEN", 3, 0):
        trial = copy.deepcopy(records)
        trial["meson_like"]["tilt"] = shared
        trial["baryon_like"]["tilt"] = shared
        t_order, _, t_deciders = derive(trial)
        assert list(t_order) == list(ORACLE), "tilt-robustness"
        assert t_deciders[("baryon_like", "meson_like")] == "resolution", \
            "tilt-robustness"
    print("DIAGNOSTIC PASS: meson/baryon tie-break at resolution "
          "for any shared tilt value")

    mutants_ok = run_mutants(records)
    controls_ok = run_controls(records, order)

    if mutants_ok and controls_ok:
        print("F.37 SUMMARY: headline + diagnostic checks green; "
              "10/10 mutants rejected with witnesses; diagnostics 2/2 as "
              "designed; controls 5/5 passed (C1, C2x2, C3, C4).")
        sys.exit(0)
    print("F.37 SUMMARY: failures present -- see UNEXPECTED lines above.")
    sys.exit(1)


if __name__ == "__main__":
    main()
