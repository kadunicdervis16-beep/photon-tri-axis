#!/usr/bin/env python3
"""Paper 11 - F.33 check-2 probe battery (controls only).

Three genuine specification violations against F.33's check-2 input
validation (pairwise-disjoint port lists, arity cross-check, port-index
and node-id bounds): (i) a k=1 junction (violates k_j >= 2); (ii) a
port index outside 0..5; (iii) a junction naming an unknown node id.
Each must be REJECTED with a printed witness. These shapes are enforced
by check-2 but were never probed; this battery closes that gap. No
registry claim is badged on these probes -- they are controls.
"""

INPUT_PROVENANCE = {
    "PROBE_K1": {"class": "control",
                 "note": "probe fixture: k=1 junction (violates k_j >= 2)"},
    "PROBE_BAD_PORT": {"class": "control",
                       "note": "probe fixture: port index 6 outside 0..5"},
    "PROBE_BAD_NODE": {"class": "control",
                       "note": "probe fixture: junction naming unknown node id"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "controls-only probe battery; backs no claim.",
}

import F33_aggregate_a as _f33

PROBE_K1 = ("probe/k1-junction",
            {"n0": "4", "n1": "4"},
            {"j0": {"ports": [("n0", 0)], "arity": 1}})
PROBE_BAD_PORT = ("probe/bad-port-index",
                  {"n0": "4", "n1": "4"},
                  {"j0": {"ports": [("n0", 0), ("n1", 6)], "arity": 2}})
PROBE_BAD_NODE = ("probe/unknown-node",
                  {"n0": "4", "n1": "4"},
                  {"j0": {"ports": [("n0", 0), ("nx", 0)], "arity": 2}})


def _probe(label, name, triples, junctions):
    agg = _f33.Aggregate(name, triples, junctions)
    try:
        _f33.check2_input_validation(agg)
    except _f33.CheckRejected as e:
        print("REJECTED %s: %s" % (label, e.witness))
        return
    raise AssertionError("probe %s NOT rejected" % label)


def main():
    for label, (name, triples, junctions) in (
            ("k1-junction", PROBE_K1),
            ("bad-port-index", PROBE_BAD_PORT),
            ("unknown-node-id", PROBE_BAD_NODE)):
        _probe(label, name, triples, junctions)
    print("F.33-check2-probes PASS: 3/3 genuine spec violations rejected "
          "with printed witnesses.")


if __name__ == "__main__":
    main()
