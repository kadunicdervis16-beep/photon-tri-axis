#!/usr/bin/env python3
"""
F.46-categorical -- Case A ladder: CATEGORICAL re-run of the nine worked
==========================================================================
Section 9 encounters (V14 blitz, Workstream 1).
STAGED. NOT WIRED INTO THE PAPER. A discussion gate with Dervis precedes
any wiring-in or v30 build. This script checks the worked encounters of the
staged Section 9 draft (v14_phase3_section9_draft.md) with CATEGORICAL port
values throughout; it does not modify the paper or any existing script.

LABEL-ISOMORPHISM STATEMENT
---------------------------
Port values are CATEGORICAL: X-dominant, Y-dominant, O (neutral). There is
no "+1 of X" and no "-1 of X". Complementarity is the categorical X<->Y
pairing; O pairs with nothing. The machine labels {+1, -1, 0} are
IMPLEMENTATION LABELS ONLY, related to the native categories by the
bijection
    +1 <-> X,   -1 <-> Y,   0 <-> O
with ZERO SEMANTIC CONTENT: no code path in this script -- and no code path
in the E0 run it re-checks -- adds, orders, multiplies, or squares label
values. Every residue, verdict, tension value, and ledger identity is a
function of category-membership COUNTS alone (how many X, how many Y);
counts are natural numbers, not port values. The bijection appears in
exactly one clearly-marked adapter section below, used solely for the
mechanical outcome-isomorphism check against the E0 run. Relabeling changes
no verdict: the isomorphism is exact, verified case-by-case in this run.

NATIVE DOMAIN
-------------
Section 8.6 encounters between a simple state's presented boundary ports
(categorical values X/Y/O) and a complex configuration's presented
boundary; the residue res(A,B) = #{X in A with no Y-partner in B} + #{Y in
A with no X-partner in B}; presented tension T = count of non-O
presentations on both sides (this is the paper's T = sum x^2, since a port
contributes 1 iff it is non-O); the selection rule
    res(A,B) > TH  -> forced decay
    res(A,B) = 0   -> attraction (the completed junction strictly reduces T)
    otherwise      -> repulsion
with the domain guard "incoming A presents at least one non-O port" (an
all-O incoming side is REFUSED, never scored); and the Section 9.6
incorporation ledger (N, J, B, s^2) via B(G) = 6N - sum(k_j), checked two
ways.

VERIFIED DOMAIN
---------------
Exact categorical pairing logic over category-membership counts: the
residue formula, the branch trichotomy at the illustrative TH = 1, matched-
pair counts, tension strict-decrease, permutation (zero-leak) invariance,
the ledger identities B_new = 6(N+1) - (sum_k + 2m) with the dual
port-decomposition check B_new = (B - m) + (6 - m), and the mechanical
outcome-isomorphism with the E0 run via the label bijection.

MAP (native -> verified)
------------------------
  1. Documented table letters -> native categories directly: X, Y, O are
     read off Table 5.1's Outside Content as categories (no integer
     encoding step exists in this script).
  2. Presented tuple -> category count vector (nX, nY). The Section 8.6
     rule factors through counts (F.36 coverage theorem); this script
     independently checks order invariance on every worked tuple by
     permutation (zero-leak): shuffling port order never changes counts,
     residue, or verdict.
  3. Nucleus (a) boundary -> category count vector under three documented
     single-port consumption choices (consume one O / X / Y per node).
     Nucleus (b) boundary -> category count vector under the workers'
     documented consumption choices.
  4. Section 9.6 incorporation -> one new junction aspect of arity 2m
     (working geometry, documented; the paper gives no fixed incorporation
     rule). The ledger is then pure port accounting, checked two ways.
  5. E0 machine run -> categorical run via the label bijection (adapter
     section only): every E0 integer tuple is translated to categories and
     re-scored; counts, residues, and verdicts must agree exactly.

WHAT THE MAP PRESERVES
----------------------
Category counts, residue values, selection-branch outcomes, tension strict-
decrease, and the ledger identities. A wrong boundary tuple, a swapped
outcome label, an off-by-one junction arity, a guardless all-O incoming,
or a residue that smuggles arithmetic semantics (the "net-sum" mutant M5)
each break a preserved identity and are REJECTED below with printed
witnesses (planted mutants M1-M5).

TOTALITY
--------
Analytic, not enumerative: for any nonnegative integer res (a count) and
any TH with 0 < TH < k, exactly one of the three branches fires
(trichotomy over the nonnegative integers). The encounter space here is
bounded and stated honestly: 9 states x 3 nucleus-(a) constructions =
27 runs, the positron mirror, and the 15 aggregate-(b) stretch cases the
workers ran (12 attraction under documented constructions + 3 marginal
repulsion cases, res = TH = 1, under non-documented consumption choices;
State 5 x (b) was not run by the workers and is not invented here).
Exhaustiveness is claimed over the worked set, not over the encounter
space. The TH band [1, k-1] is held by F.36, not re-proved here.

WHAT STAYS OUTSIDE THE MACHINE CHECK
------------------------------------
The physical premises the categorical logic is conditional on: the
Outside-Content = boundary-tuple equation (Level B inference, H4), the
nucleus consumption-value choices (Level B, H3), the State-1 boundary
instantiation with >= 1 non-O port required for the attraction branch
(Level B, H1; the all-O alternative is guard-refused, not repulsion), the
illustrative TH = 1 (exact TH is Paper 14's locked debt), and the s^2
redistribution (symbolic; per-state values are Paper 8's table, cited not
reproduced). The script verifies the categorical logic GIVEN the
premises; it does not verify the premises. NO ENCOUNTER VERDICT IS BADGED
LEVEL A.

BADGE DISCIPLINE (stated explicitly)
------------------------------------
Encounter verdicts stay Level B: the H2/H4 premises are UNCHANGED BY
RELABELING. The categorical script reads categories X/Y/O directly off
the documented table -- no integer encoding step exists -- so the Level B
illustration premises are identical in content to the E0 run's; only the
machine representation changed. What is Level A given the premises: the
categorical residue trichotomy, tension strict-decrease, permutation
invariance, ledger identities, mutant rejections, and the mechanical
outcome-isomorphism with the E0 run.

Sanitation: no auditor/vulnerability grading language anywhere in this
script. The e.S(d) term, where the paper's standing terminology applies,
is "engagement-weighted scan allocation" (it does not arise in this
computation).
"""

import os
import random
import sys

TH = 1  # illustrative; exact TH is Paper 14's locked debt (labeled)

# ---------------------------------------------------------------------------
# Documented premises, printed (Phase-1 policy: the category tables printed)
# ---------------------------------------------------------------------------
# Table 5.1 Outside Content (native categories), paper lines 446-457.
# Read directly as categories -- no integer encoding step.
OUTSIDE = {
    1: ('Y', 'Y', 'Y', 'O', 'O', 'O'),  # electron
    2: ('X', 'Y', 'Y', 'O', 'O', 'O'),
    3: ('X', 'X', 'Y', 'O', 'O', 'O'),
    4: ('X', 'X', 'Y', 'Y', 'O', 'O'),
    5: ('X', 'Y', 'Y', 'Y', 'O', 'O'),
    6: ('X', 'X', 'X', 'Y', 'O', 'O'),
    7: ('X', 'X', 'Y', 'Y', 'Y', 'O'),
    8: ('X', 'X', 'X', 'Y', 'Y', 'O'),
    9: ('X', 'X', 'X', 'Y', 'Y', 'Y'),  # photon
}
POSITRON_OUTSIDE = ('X', 'X', 'X', 'O', 'O', 'O')  # State-1 mirror

STATE4_OUTSIDE = ('X', 'X', 'Y', 'Y', 'O', 'O')  # per node of nucleus (a), App. B.1
STATE5_OUTSIDE = ('X', 'Y', 'Y', 'Y', 'O', 'O')  # App. B.2
STATE6_OUTSIDE = ('X', 'X', 'X', 'Y', 'O', 'O')  # App. B.2

CATEGORIES = ('X', 'Y', 'O')  # the native alphabet; X pairs with Y; O pairs with nothing


class OutsideDomain(Exception):
    """Theorem G refusal: incoming side presents no non-O port."""


# ===========================================================================
# MACHINE-LABEL ADAPTER -- the single confined section where {+1,-1,0} appear
# ---------------------------------------------------------------------------
# The machine labels {+1, -1, 0} are IMPLEMENTATION LABELS ONLY, related to
# the native categories by the bijection
#       +1 <-> X (X-dominant),  -1 <-> Y (Y-dominant),  0 <-> O (neutral)
# with ZERO SEMANTIC CONTENT. Nothing in this script's computation logic
# (or in the E0 run) adds, orders, multiplies, or squares label values;
# every residue, verdict, and ledger identity is a function of
# category-membership counts alone. This adapter exists for ONE purpose:
# the mechanical outcome-isomorphism check against the E0 run (section [7]).
# No computation logic below this line reads these labels as numbers.
# ===========================================================================
LABEL_OF_CATEGORY = {'X': +1, 'Y': -1, 'O': 0}
CATEGORY_OF_LABEL = {+1: 'X', -1: 'Y', 0: 'O'}


def to_machine_labels(cat_tuple):
    """Adapter: categories -> machine labels (isomorphism check only)."""
    return tuple(LABEL_OF_CATEGORY[ch] for ch in cat_tuple)


def to_categories(label_tuple):
    """Adapter: machine labels -> categories (isomorphism check only)."""
    return tuple(CATEGORY_OF_LABEL[x] for x in label_tuple)


# ===========================================================================
# Pure categorical selection machinery (no integer labels in the logic)
# ---------------------------------------------------------------------------
# Ports are the strings 'X', 'Y', 'O'. Counts below are natural numbers of
# category membership -- they are not port values.
# ===========================================================================
def cat_counts(tup):
    """Category count vector {'X': nX, 'Y': nY}. O ports carry no tension:
    never read, never paired."""
    assert all(ch in CATEGORIES for ch in tup), "non-categorical port value"
    return {'X': tup.count('X'), 'Y': tup.count('Y')}


def residue_cat(ca, cb):
    """res(A,B): #{X in A with no Y-partner in B} + #{Y in A with no
    X-partner in B}. Complementarity is the categorical X<->Y pairing."""
    return max(0, ca['X'] - cb['Y']) + max(0, ca['Y'] - cb['X'])


def select_cat(res, th):
    if res > th:
        return 'forced_decay'
    if res == 0:
        return 'attraction'
    return 'repulsion'


def encounter_cat(a_tup, cb, th=TH):
    """Directional encounter: A incoming against neighbor B (counts cb).

    Domain guard (line 650; Theorem G): an all-O incoming side is REFUSED
    -- never scored as repulsion, never scored as attraction.
    """
    if not any(ch in ('X', 'Y') for ch in a_tup):
        raise OutsideDomain(
            "incoming side presents no non-O port -- outside taxonomy domain")
    ca = cat_counts(a_tup)
    r = residue_cat(ca, cb)
    ua = ca['X'] + ca['Y']
    return select_cat(r, th), r, ca, ua


def matched_cat(ca, cb):
    """Completed X<->Y pairs: min(nX_A, nY_B) + min(nY_A, nX_B)."""
    return min(ca['X'], cb['Y']) + min(ca['Y'], cb['X'])


def tension_cat(ua, ub):
    """T(A,B): count of non-O presentations on both sides. This is the
    paper's T = sum x^2 over the presented tuples: a port contributes 1
    iff it is non-O, 0 iff it is O."""
    return ua + ub


# ---------------------------------------------------------------------------
# Nucleus constructions (documented P3 / stretch choices), categorical
# ---------------------------------------------------------------------------
def nucleus_a_cat(consumed):
    """Aggregate (a): 3 x State-4 node minus one consumed port per node.
    consumed is a category ('O', 'X', or 'Y')."""
    per_node = list(STATE4_OUTSIDE)
    per_node.remove(consumed)          # the documented value choice
    c = cat_counts(tuple(per_node))
    nX, nY = 3 * c['X'], 3 * c['Y']
    nO = 15 - nX - nY
    assert nX + nY + nO == 15, "B must be 15"
    return {'X': nX, 'Y': nY}         # count vector; O ports never read


def nucleus_b_cat(consumed5, consumed6):
    """Aggregate (b): State-5 + State-6 minus one consumed port each."""
    s5 = list(STATE5_OUTSIDE); s5.remove(consumed5)
    s6 = list(STATE6_OUTSIDE); s6.remove(consumed6)
    c5, c6 = cat_counts(tuple(s5)), cat_counts(tuple(s6))
    nX = c5['X'] + c6['X']
    nY = c5['Y'] + c6['Y']
    assert nX + nY + (len(s5) + len(s6) - nX - nY) == 10, "B must be 10"
    return {'X': nX, 'Y': nY}

# ---------------------------------------------------------------------------
# Witness tables from the workers' runs (what the script checks against)
# ---------------------------------------------------------------------------
# Nucleus (a), primary construction: (state -> (res, m, B_new, verdict)).
# B_new = 6*4 - (3 + 2m) = 21 - 2m; m = u_A when res = 0 (full cover).
A_WITNESS = {
    1: dict(res=0, m=3, B_new=15, verdict='attraction'),
    2: dict(res=0, m=3, B_new=15, verdict='attraction'),
    3: dict(res=0, m=3, B_new=15, verdict='attraction'),
    4: dict(res=0, m=4, B_new=13, verdict='attraction'),
    5: dict(res=0, m=4, B_new=13, verdict='attraction'),
    6: dict(res=0, m=4, B_new=13, verdict='attraction'),
    7: dict(res=0, m=5, B_new=11, verdict='attraction'),
    8: dict(res=0, m=5, B_new=11, verdict='attraction'),
    9: dict(res=0, m=6, B_new=9,  verdict='attraction'),
}

# Aggregate-(b) stretch cases the workers ran.
# (state, consumed5, consumed6, expected_res, expected_m, expected_B_new, expected_verdict)
B_CASES = [
    (1, 'Y', 'X', 0, 3, 10, 'attraction'),   # documented complementary pair
    (2, 'O', 'O', 0, 3, 10, 'attraction'),
    (2, 'X', 'X', 0, 3, 10, 'attraction'),
    (3, 'Y', 'X', 0, 3, 10, 'attraction'),   # documented complementary pair
    (4, 'O', 'O', 0, 4, 8,  'attraction'),
    (4, 'Y', 'X', 0, 4, 8,  'attraction'),   # B.2-complementary reading
    # State 5 x (b): NOT RUN by the workers -- not invented here.
    (6, 'Y', 'X', 0, 4, 8,  'attraction'),   # documented complementary pair
    (7, 'O', 'O', 0, 5, 6,  'attraction'),
    (7, 'X', 'Y', 0, 5, 6,  'attraction'),   # complementary pair (count-identical)
    (8, 'Y', 'X', 0, 5, 6,  'attraction'),   # documented complementary pair
    (8, 'O', 'O', 0, 5, 6,  'attraction'),
    (9, 'O', 'O', 0, 6, 4,  'attraction'),
]
# Assumption-sensitive (b) cases: non-documented consumption choices.
# Marginal: res = TH = 1 (below the fuse -> repulsion).
B_SENSITIVE = [
    (6, 'Y', 'Y', 1, 'repulsion'),   # S5 consumes Y AND S6 consumes Y
    (9, 'X', 'X', 1, 'repulsion'),   # consume X per node
    (9, 'Y', 'Y', 1, 'repulsion'),   # consume Y per node
]


def check_ledger_a(m, B_new_expected):
    """Section 9.6 ledger for nucleus (a): N 3->4; dual computation of B_new.
    m is the count of completed X<->Y pairs (a count, not a label)."""
    N_new, sum_k_new = 4, 3 + 2 * m
    b_formula = 6 * N_new - sum_k_new
    b_decomp = (15 - m) + (6 - m)      # (B - m) consumed + (6 - m) surviving
    assert b_formula == B_new_expected, (b_formula, B_new_expected)
    assert b_decomp == B_new_expected, (b_decomp, B_new_expected)
    assert N_new == 4 and sum_k_new >= 3 + 2
    return b_formula


def check_ledger_b(m, B_new_expected):
    """Section 9.6 ledger for nucleus (b): N 2->3; dual computation of B_new."""
    N_new, sum_k_new = 3, 2 + 2 * m
    b_formula = 6 * N_new - sum_k_new
    b_decomp = (10 - m) + (6 - m)
    assert b_formula == B_new_expected, (b_formula, B_new_expected)
    assert b_decomp == B_new_expected, (b_decomp, B_new_expected)
    return b_formula


def main():
    failures = []
    n_checks = 0

    def ok(msg):
        print("  PASS  " + msg)

    def fail(msg):
        failures.append(msg)
        print("  FAIL  " + msg)

    print("F.46-categorical -- Case A ladder, CATEGORICAL re-run (STAGED, not wired in)")
    print("Premises: ports are native categories X/Y/O; boundary tuple :=")
    print("Outside Content read as categories (Level B inference, H4); nucleus")
    print("constructions as documented (Level B, H3); State-1 boundary with >= 1")
    print("non-O port (Level B, H1); TH = 1 illustrative (Paper 14's debt).")
    print("Machine labels {+1,-1,0} appear ONLY in the confined adapter for the")
    print("E0 isomorphism check -- zero semantic content.")
    print()

    # ---- 1. Nine states x three (a) constructions: tuple -> counts -> res
    #         -> selection -> tension -> ledger ---------------------------
    print("[1] Nucleus (a): 9 states x 3 consumption constructions (categorical)")
    for s in range(1, 10):
        a_tup = OUTSIDE[s]
        w = A_WITNESS[s]
        for consumed in ('O', 'X', 'Y'):
            cb = nucleus_a_cat(consumed)
            n_checks += 1
            try:
                verdict, r, ca, ua = encounter_cat(a_tup, cb)
                m = matched_cat(ca, cb)
                ub = cb['X'] + cb['Y']
                t_before = tension_cat(ua, ub)
                t_after = t_before - 2 * m
                # witness agreement (primary construction carries the table)
                assert r == 0, "res=%d, expected 0" % r
                assert verdict == 'attraction', verdict
                # res = 0 (full cover) analytically implies m = u_A
                assert m == ua, "m=%d != u_A=%d under full cover" % (m, ua)
                assert t_after < t_before, "tension did not strictly decrease"
                # ledger, dual computation
                b_new = check_ledger_a(m, w['B_new'])
                assert m == w['m'] and b_new == w['B_new']
                ok("state %d x (a)/consume-%s: res=0 m=%d T %d->%d B_new=%d attraction"
                   % (s, consumed, m, t_before, t_after, b_new))
            except AssertionError as e:
                fail("state %d x (a)/consume-%s: %s" % (s, consumed, e))
            except OutsideDomain as e:
                fail("state %d x (a)/consume-%s: wrongly refused: %s" % (s, consumed, e))

    # ---- 2. Permutation invariance (zero-leak order test, categorical) -------
    print("[2] Order invariance: shuffling tuple order changes nothing")
    rng = random.Random(20260925)
    for s in range(1, 10):
        a_tup = OUTSIDE[s]
        cb = nucleus_a_cat('O')
        base = encounter_cat(a_tup, cb)
        n_checks += 1
        try:
            for _ in range(5):
                sh = list(a_tup); rng.shuffle(sh); sh = tuple(sh)
                assert cat_counts(sh) == cat_counts(a_tup), "counts leaked order"
                assert encounter_cat(sh, cb)[:2] == base[:2], "verdict leaked order"
            ok("state %d: 5 shuffles, counts/residue/verdict identical" % s)
        except AssertionError as e:
            fail("state %d order invariance: %s" % (s, e))

    # ---- 3. Positron mirror -------------------------------------------------
    print("[3] Positron mirror (State-1 charge mirror)")
    n_checks += 1
    try:
        p_tup = POSITRON_OUTSIDE
        cb = nucleus_a_cat('O')
        verdict, r, ca, ua = encounter_cat(p_tup, cb)
        m = matched_cat(ca, cb)
        assert (r, verdict, m) == (0, 'attraction', 3)
        assert check_ledger_a(m, 15) == 15
        ok("positron: res=0 m=3 T 15->9 B_new=15 attraction (mirror of electron)")
    except AssertionError as e:
        fail("positron mirror: %s" % e)

    # ---- 4. Theorem G: all-O incoming is REFUSED -----------------------------
    print("[4] Domain guard (Theorem G): all-O incoming is refused")
    n_checks += 1
    try:
        encounter_cat(('O', 'O', 'O', 'O', 'O', 'O'), nucleus_a_cat('O'))
        fail("all-O incoming was scored instead of refused")
    except OutsideDomain as e:
        ok("refused, not scored: %s" % e)

    # ---- 5. Aggregate-(b) stretch --------------------------------------------
    print("[5] Aggregate-(b) stretch: documented constructions")
    for (s, c5, c6, er, em, eb, ev) in B_CASES:
        a_tup = OUTSIDE[s]
        cb = nucleus_b_cat(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = encounter_cat(a_tup, cb)
            m = matched_cat(ca, cb)
            ub = cb['X'] + cb['Y']
            assert r == er, "res=%d expected %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            assert m == em, "m=%d expected %d" % (m, em)
            assert tension_cat(ua, ub) - 2 * m < tension_cat(ua, ub), \
                "tension did not decrease"
            b_new = check_ledger_b(m, eb)
            ok("state %d x (b)/(%s,%s): res=%d m=%d B_new=%d %s"
               % (s, c5, c6, r, m, b_new, verdict))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s): %s" % (s, c5, c6, e))

    print("[6] Aggregate-(b): assumption-sensitive marginal cases (res = TH = 1)")
    for (s, c5, c6, er, ev) in B_SENSITIVE:
        a_tup = OUTSIDE[s]
        cb = nucleus_b_cat(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = encounter_cat(a_tup, cb)
            assert r == er == TH, "res=%d, expected marginal %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            ok("state %d x (b)/(%s,%s): res=1=TH -> repulsion (marginal, disclosed)"
               % (s, c5, c6))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s) sensitive: %s" % (s, c5, c6, e))
    print("  NOTE  state 5 x (b): not run by the workers -- not invented here")

    # ---- 7. Mechanical outcome-isomorphism with the E0 run --------------------
    print("[7] Outcome-isomorphism with the E0 run via the label bijection")
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import v14_f46_caseA_ladder as e0
    except ImportError as e:
        fail("could not import the E0 module read-only: %s" % e)
        e0 = None
    if e0 is not None:
        # the documented tables must be letter-identical (shared Table 5.1 source)
        n_checks += 1
        try:
            for s in range(1, 10):
                assert to_categories(e0.encode(e0.OUTSIDE[s])) == OUTSIDE[s]
            ok("Table 5.1 letter tables identical between E0 and categorical runs")
        except AssertionError as e:
            fail("table mismatch: %s" % e)
        # every (a) case: E0 integer tuple -> categories -> identical outcome
        for s in range(1, 10):
            for consumed in ('O', 'X', 'Y'):
                n_checks += 1
                try:
                    a_cat = to_categories(e0.encode(e0.OUTSIDE[s]))
                    cb_cat = nucleus_a_cat(consumed)
                    cb_e0 = e0.nucleus_a(consumed)      # (n+, n-) counts
                    assert (cb_cat['X'], cb_cat['Y']) == cb_e0
                    v_c, r_c, cc_c, u_c = encounter_cat(a_cat, cb_cat)
                    v_e, r_e, cc_e, u_e = e0.encounter(
                        e0.encode(e0.OUTSIDE[s]), cb_e0)
                    assert (v_c, r_c) == (v_e, r_e), \
                        "verdict/residue diverged: %s/%s vs %s/%s" % (v_c, r_c, v_e, r_e)
                    assert (cc_c['X'], cc_c['Y'], u_c) == (cc_e[0], cc_e[1], u_e)
                    ok("state %d x (a)/consume-%s: E0 (%s,res=%d) == categorical (%s,res=%d)"
                       % (s, consumed, v_e, r_e, v_c, r_c))
                except AssertionError as e:
                    fail("state %d x (a)/consume-%s isomorphism: %s" % (s, consumed, e))
        # every (b) case, including the marginal ones
        iso_b = ([(s, c5, c6) for (s, c5, c6, _er, _em, _eb, _ev) in B_CASES]
                 + [(s, c5, c6) for (s, c5, c6, _er, _ev) in B_SENSITIVE])
        for (s, c5, c6) in iso_b:
            n_checks += 1
            try:
                a_cat = to_categories(e0.encode(e0.OUTSIDE[s]))
                cb_cat = nucleus_b_cat(c5, c6)
                cb_e0 = e0.nucleus_b(c5, c6)
                assert (cb_cat['X'], cb_cat['Y']) == cb_e0
                v_c, r_c, cc_c, u_c = encounter_cat(a_cat, cb_cat)
                v_e, r_e, cc_e, u_e = e0.encounter(
                    e0.encode(e0.OUTSIDE[s]), cb_e0)
                assert (v_c, r_c) == (v_e, r_e), \
                    "verdict/residue diverged: %s/%s vs %s/%s" % (v_c, r_c, v_e, r_e)
                ok("state %d x (b)/(%s,%s): E0 (%s,res=%d) == categorical (%s,res=%d)"
                   % (s, c5, c6, v_e, r_e, v_c, r_c))
            except AssertionError as e:
                fail("state %d x (b)/(%s,%s) isomorphism: %s" % (s, c5, c6, e))
        # positron mirror + Theorem G refusal agree across runs
        n_checks += 1
        try:
            v_c, r_c, cc_c, u_c = encounter_cat(
                to_categories(e0.encode(e0.POSITRON_OUTSIDE)), nucleus_a_cat('O'))
            v_e, r_e, cc_e, u_e = e0.encounter(
                e0.encode(e0.POSITRON_OUTSIDE), e0.nucleus_a('O'))
            assert (v_c, r_c) == (v_e, r_e)
            for mod, fn in ((e0, e0.encounter), (None, encounter_cat)):
                try:
                    fn(('O',) * 6 if mod is None else (0,) * 6,
                       nucleus_a_cat('O') if mod is None else e0.nucleus_a('O'))
                    raise AssertionError("all-O/all-zero scored, not refused")
                except (OutsideDomain, e0.OutsideDomain):
                    pass
            ok("positron mirror and Theorem G refusal identical across both runs")
        except AssertionError as e:
            fail("mirror/guard isomorphism: %s" % e)

    # ---- 8. Planted mutants: each must be REJECTED with a printed witness ----
    print("[8] Planted mutants (each must be rejected with a printed witness)")
    mutants_rejected = 0

    # M1: wrong boundary tuple (one category flipped vs Table 5.1).
    n_checks += 1
    try:
        genuine = OUTSIDE[1]
        mutant_tup = ('Y', 'Y', 'X', 'O', 'O', 'O')  # flipped category
        assert cat_counts(mutant_tup) != cat_counts(genuine), "mutant not actually wrong"
        if cat_counts(mutant_tup) == cat_counts(genuine):
            raise AssertionError("mutant tuple accepted as genuine")
        print("  MUTANT M1 (wrong boundary tuple): REJECTED -- witness: supplied "
              "counts %s != Table-5.1-derived counts %s"
              % (cat_counts(mutant_tup), cat_counts(genuine)))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M1 not rejected: %s" % e)

    # M2: swapped outcome label (res=0 relabeled 'repulsion').
    n_checks += 1
    try:
        verdict, r, ca, ua = encounter_cat(OUTSIDE[4], nucleus_a_cat('O'))
        mutant_label = 'repulsion'
        assert r == 0 and verdict == 'attraction'
        if mutant_label == verdict:
            raise AssertionError("swapped label accepted")
        print("  MUTANT M2 (swapped outcome label): REJECTED -- witness: res=%d "
              "selects '%s', mutant label '%s' disagrees"
              % (r, verdict, mutant_label))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M2 not rejected: %s" % e)

    # M3: off-by-one junction count (arity 2m+1 instead of 2m).
    n_checks += 1
    try:
        m = 4  # state 4..6 witness
        b_true = 6 * 4 - (3 + 2 * m)          # 13
        b_mut = 6 * 4 - (3 + 2 * m + 1)       # 12, off by one
        b_decomp = (15 - m) + (6 - m)         # 13, dual computation
        assert b_true == b_decomp == 13
        if b_mut == b_decomp:
            raise AssertionError("off-by-one ledger accepted")
        print("  MUTANT M3 (off-by-one junction count): REJECTED -- witness: "
              "B_new=%d with arity 2m+1 vs dual computation B_new=%d"
              % (b_mut, b_decomp))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M3 not rejected: %s" % e)

    # M4: guardless all-O incoming (must be refused, not attracted).
    n_checks += 1
    try:
        def mutant_guardless(a_tup, cb, th=TH):
            # spec violation: skips the Theorem G domain guard
            ca = cat_counts(a_tup)
            return select_cat(residue_cat(ca, cb), th), residue_cat(ca, cb)
        all_o = ('O', 'O', 'O', 'O', 'O', 'O')
        mutant_out = mutant_guardless(all_o, nucleus_a_cat('O'))
        try:
            encounter_cat(all_o, nucleus_a_cat('O'))
            genuine_out = 'scored'
        except OutsideDomain:
            genuine_out = 'refused'
        assert mutant_out[0] == 'attraction' and genuine_out == 'refused'
        print("  MUTANT M4 (guardless all-O incoming): REJECTED -- witness: "
              "mutant returns '%s' for the all-O tuple; the guarded rule "
              "refuses it (Theorem G)" % mutant_out[0])
        mutants_rejected += 1
    except AssertionError as e:
        fail("M4 not rejected: %s" % e)

    # M5: "net-sum" residue -- smuggles arithmetic semantics into the labels.
    # The mutant reads the machine labels as signed NUMBERS (X=+1, Y=-1) and
    # computes res as |net_A + net_B|, letting surplus CANCEL deficit. The
    # native rule forbids this: complementarity is a PAIRING relation, not
    # a sum; the labels carry zero semantic content.
    n_checks += 1
    try:
        def mutant_netsum_res(a_tup, b_tup):
            # spec violation: additive cancellation on implementation labels
            net = lambda t: t.count('X') - t.count('Y')
            return abs(net(a_tup) + net(b_tup))
        a_w, b_w = ('X', 'X', 'Y'), ('Y',)
        mut_r = mutant_netsum_res(a_w, b_w)          # |(+1) + (-1)| = 0
        genuine_r = residue_cat(cat_counts(a_w), cat_counts(b_w))
        # genuine: X-unmatched = max(0, 2-1) = 1; Y-unmatched = max(0, 1-0) = 1
        genuine_v = select_cat(genuine_r, TH)
        mutant_v = select_cat(mut_r, TH)
        assert (mut_r, mutant_v) == (0, 'attraction'), "mutant not actually divergent"
        assert (genuine_r, genuine_v) == (2, 'forced_decay'), "witness miscomputed"
        print("  MUTANT M5 (net-sum residue): REJECTED -- witness: A=('X','X','Y'), "
              "B=('Y',): mutant computes |net_A + net_B| = |(+1)+(-1)| = 0 -> "
              "'attraction'; the categorical rule computes #{X in A with no "
              "Y-partner} = 1 plus #{Y in A with no X-partner} = 1, res = 2 -> "
              "'forced_decay'. The mutant lets a Y CANCEL an X additively; the "
              "native rule only PAIRS X with Y. (The mutant even passes the "
              "net-balanced worked cases, e.g. S4 x (a): net 0 = res 0 -- a "
              "genuine spec violation, not a strawman.)")
        mutants_rejected += 1
    except AssertionError as e:
        fail("M5 not rejected: %s" % e)

    print()
    print("checks run: %d | mutants rejected: 5/%d" % (n_checks, mutants_rejected))
    if failures or mutants_rejected != 5:
        print("F.46-categorical RESULT: FAIL")
        for f in failures:
            print("  - " + f)
        sys.exit(1)
    print("F.46-categorical RESULT: ALL CHECKS PASSED (exit 0)")
    print("Badge: categorical logic Level A given the documented premises; the nine")
    print("encounter verdicts remain Level B illustration -- the H2/H4 premises are")
    print("unchanged by relabeling. No Level-A encounter badges issued.")


if __name__ == '__main__':
    main()
