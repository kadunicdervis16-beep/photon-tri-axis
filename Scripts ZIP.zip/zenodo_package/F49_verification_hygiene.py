#!/usr/bin/env python3
"""Paper 11 - F.49: verification-hygiene sweep (the F.33-F.35 placeholder pattern).

Never-again machinery for the defect family that hid inside F.33-F.35:
placeholder wording ("illustrative", "placeholder", ...) attached to
invented quantities, plus round-trip identities (divide-then-multiply,
split-then-recombine, ...) that launder those quantities into passing
asserts. This script makes both families machine-detectable, and adds an
input-provenance declaration surface so every script input is legible.

Level A, backing its own honest slice: the sweep's existence and its
whitelist behavior (not the physics).

This script's Level-A check power comes from a small, explicit coverage
map, stated honestly here:

    (a) Native domain. Script sources: the Python verification files backing
        Level-A claims. The claim domain is whatever those scripts verify -
        reduced models, exact-rational certificates, permutation sweeps -
        already pinned down by each script's own registry entry and the
        machine-check prose that badges it.
    (b) Verified domain. Two defect families, and only these two:
        (1) placeholder/illustrative language smuggling invented quantities
            into Level-A-backed scripts (WORD_SCAN);
        (2) round-trip identities - expressions divided then multiplied,
            summed then re-totaled, or otherwise inverted back to their
            inputs - that launder invented values into passing asserts
            (RT_SCAN over RT1-RT6).
    (c) The map. WORD_SCAN covers defect (1) wherever it appears outside
        machinery regions in Level-A-backed scripts; RT_SCAN covers defect
        (2) wherever an Eq-compare's operands round-trip, with RT1/RT2
        tried on defs-substituted forms first and RT4 tried after single-
        return function inlining, all levels scanned for RT1-RT6 with the
        W1-W4 whitelist for genuine checks. PROVENANCE_SCAN covers the
        input-declaration surface: every covered source name must carry a
        declared class and a resolvable section citation where one is
        required.
    (d) What the map preserves. Exactness of the scan: every flagged
        WORD/ROUND_TRIP/PROVENANCE item is a real instance of the defect
        family, not a guess - the worker classifies shapes, it does not
        invent content.
    (e) What stays outside the machine check. Physics soundness (does the
        check verify the claim's actual content?), semantic honesty of
        Level-B/C prose, and whether a declared assumption is legitimate -
        all human-audit territory. A declared-assumption input passes this
        sweep by design: the sweep forces the declaration into the open,
        the auditor judges it. The legibility mandate applies: laundering
        through a legible declaration does not pass the hard gates - the
        sweep rejects laundering regardless of what the declaration says.
        Legibility is not permission: a legible lie is still a defect,
        caught at the next human audit; the hard gates reject laundering
        regardless of what the declaration says.

    Check 5 (domain cross-check) is a separate, narrower check with its own
    coverage statement: its native domain is the R23 domain declarations
    (each backing script's DOMAIN block beside INPUT_PROVENANCE); its
    verified domain is the record equality -- the union of the backing
    scripts' DOMAIN["proved"] kind-lists equals the registry row's
    proved_domain; what it preserves is exactness of the comparison (both
    sides parsed, never imported or executed); what stays outside is
    whether the declared kinds are the true kinds the script exercises
    (wrong-but-well-typed declarations stay human-audit territory -- the
    F.51-style disclosure), and whether the claimed domain is honest
    (F.38's R23 rule, not this check).

Scope honesty: this is a known-shape + default-deny scanner, not a general
tautology detector. It catches the RT1-RT6 identity shapes and refuses to
bless anything it cannot classify (UNCLASSIFIED_ASSERT) inside
Level-A-backed scripts. Novel laundering shapes are caught only by the
default-deny clause - the sweep says "I cannot classify this", never "this
is fine".

Contract (import-cycle safety): this module's top level never imports or
executes F.38. It receives the registry only through the `reg`, `root`,
and `sections` parameters. A standalone __main__ guard may execute F.38
(to obtain the real registry for a live sweep); termination is guaranteed
because an F.49 executed by F.38 has a passive top level - the guard only
fires when F.49 is the main program, so no cycle exists.

hygiene_violations(reg, root) runs Checks 1, 2, and 4 only. Check 3
(provenance) is reported separately via provenance_violations(path,
sections) - see the R22 wiring notes in F.38. Check 5 (domain
cross-check) is reported separately via domain_violations(reg, root):
every backing script's DOMAIN["proved"] block must equal its registry
row's proved_domain (the R23 record half; F.38's R23 rule is the claim
half). prose_badge_census is
reporting only: remaining badge sites are printed as PROSE_BADGE_CENSUS
lines, never as violations.

F.38's REGISTRY provenance block is validated under Check 3 (the machinery
exemption does not cover F.38's own input declarations). F.38 self-
grounding for BRIDGE_LEDGER_P11 is disclosed honestly: that claim is
registry-internal bookkeeping, and the sweep says so rather than
pretending a script checked it.

Sanitation: no auditor/vulnerability grading language (V-numbers, "relic",
"convicted") appears in this script's text. The defect is named only as
"the F.33-F.35 placeholder pattern".
"""

import ast
import copy
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "paper_11.md"

# R23 domain declaration (2026-10-05): aspect kinds this script's checks
# exercise. F.49 is gate machinery backing no registry claim; it quantifies
# over no aspect kinds. (Check 5 reads other scripts' DOMAIN blocks; this
# block declares F.49's own empty domain for uniformity.)
DOMAIN = {
    "proved": [],
    "notes": "gate machinery: no aspect kinds exercised; backs no claim.",
}

# MACHINERY-START: hygiene WORD_SCAN pattern definitions.
# (Machinery region: skipped by this script's own WORD_SCAN and by F.42's
#  vocabulary sweeps, which skip MACHINERY-START..MACHINERY-END lines.)
PROVENANCE_CLASSES = frozenset({
    "paper-defined",          # value comes from a numbered paper section; needs "source"
    "cited-paper",            # value imported from a cited paper; needs "source"
    "control",                # enumeration bound / sanity constant / sweep input; needs "note"
    "declared-assumption",    # openly declared open debt; needs "prose" with a section marker
    "arbitrary-representative",  # arbitrary representative value; needs "independence"
})
PLACEHOLDER_WORD_RES = [
    re.compile(r"\billustrative\b", re.IGNORECASE),
    re.compile(r"\bplaceholder\b", re.IGNORECASE),
    re.compile(r"\binvented\b", re.IGNORECASE),
    re.compile(r"\bmade[\s_-]*up\b", re.IGNORECASE),
    re.compile(r"\bfictitious\b", re.IGNORECASE),
    re.compile(r"\bdummy\b", re.IGNORECASE),
    re.compile(r"\bnotional\b", re.IGNORECASE),
    re.compile(r"\bsynthetic input\b", re.IGNORECASE),
    # The noun "stand-in" (a substitute value), hyphenated or underscored.
    # The bare verb phrase "stand in" (e.g. "stand in relations") is not it.
    re.compile(r"\bstand[-_]in\b", re.IGNORECASE),
]
# MACHINERY-END


# ---------------------------------------------------------------------------
# Registry contact: Level-A script map. Registry enters only via parameters.
# ---------------------------------------------------------------------------

EXEMPT_STEMS = {"F38_claim_registry", "F42_stageN_firewall", "F49_verification_hygiene"}
# Exclusion notes (not an exemption list to evade):
# - F49 excludes itself: the gate cannot scan its own hygiene without
#   recursing; it is gate machinery, not a claim script.
# - F38 (the registry) and F42 (the vocabulary firewall) are machinery:
#   their sources legitimately contain the tokens the sweeps ban
#   elsewhere, so Checks 1/2 do not apply to them.
# - DOMAIN blocks are declaration blocks (R23), not check inputs:
#   covered_source_names excludes DOMAIN exactly as it excludes
#   INPUT_PROVENANCE, so Check 3 never demands a provenance entry for it.
#   Check 5 reads DOMAIN instead.
# - F33_check2_probes is NOT exempt: it is scanned by Checks 1/2 like any
#   other script. It simply backs no Level-A registry claim (controls-only
#   probe battery), so it is absent from the Level-A map below -- not
#   exempted, just unbacked -- and Check 3 does not apply to it.


def level_a_backed_scripts(reg):
    """Map full script stem -> set of Level-A claim ids it backs.

    A script entry may be a list of stems (e.g. ["F32_gate",
    "F33_aggregate_a"]) or several stems separated by '+' in one string
    (e.g. "F.36 + F.46"); "F.38", "F.39", ..., ".py" suffixes, and
    whitespace are all normalized. Only rows with level "A" and lineage
    "script" count.
    """
    out = {}
    for row in reg:
        if row.get("level") != "A" or row.get("lineage") != "script":
            continue
        field = row.get("script") or ""
        if isinstance(field, (list, tuple)):
            parts = [str(p) for p in field]
        else:
            parts = str(field).split("+")
        for part in parts:
            stem = part.strip()
            if not stem:
                continue
            if stem.endswith(".py"):
                stem = stem[:-3]
            if stem.startswith("F."):
                stem = "F" + stem[2:]
            # Accept full on-disk stems ("F33_aggregate_a") and short
            # number stems ("F33", resolved against the disk later).
            if re.fullmatch(r"F\d+(?:_.*)?", stem):
                out.setdefault(stem, set()).add(row["id"])
    # Re-key short "F33" stems to the full on-disk stem when unique.
    return out


def _full_stem_map(root):
    """Map short "F33" style stems to the full on-disk stem (unique match)."""
    m = {}
    for p in Path(root).glob("F*.py"):
        short = re.match(r"(F\d+)", p.stem)
        if short:
            m.setdefault(short.group(1), p.stem)
    return m


def resolve_stems(short_map, root):
    """Resolve a short-stem Level-A map against the real files on disk."""
    full = _full_stem_map(root)
    out = {}
    for stem, ids in short_map.items():
        out[full.get(stem, stem)] = ids
    return out


def scanned_scripts(root):
    """All F*.py scripts except the machinery-exempt F.38/F.42/F.49."""
    return sorted(
        p for p in Path(root).glob("F*.py") if p.stem not in EXEMPT_STEMS
    )


# ---------------------------------------------------------------------------
# Check 1: WORD_SCAN - placeholder language in Level-A-backing scripts.
# ---------------------------------------------------------------------------

def check1_word_scan(path, text, claim_ids):
    """Flag illustrative/placeholder wording outside MACHINERY regions.

    Applies only to Level-A-backing scripts (the caller gates on claim_ids).
    """
    label = Path(path).name
    ids = ",".join(sorted(claim_ids))
    violations = []
    in_machinery = False
    for lineno, line in enumerate(text.splitlines(), 1):
        if "MACHINERY-START" in line:
            in_machinery = True
            continue
        if "MACHINERY-END" in line:
            in_machinery = False
            continue
        if in_machinery:
            continue
        for rx in PLACEHOLDER_WORD_RES:
            m = rx.search(line)
            if m:
                # Exemption: the sanctioned defect name "the F.33-F.35
                # placeholder pattern" is not a WORD hit.
                if m.group(0).lower() == "placeholder" and "F.33" in line and "F.35" in line:
                    continue
                violations.append(
                    "F49: %s:%d WORD: placeholder language %r in Level-A-backing "
                    "script (claims: %s)" % (label, lineno, m.group(0), ids)
                )
                break
    return violations


# ---------------------------------------------------------------------------
# Check 2: RT_SCAN + default-deny - AST Eq-assert classification.
# ---------------------------------------------------------------------------

MUTANT_KEYWORDS = ("planted", "mutant", "witness")

_RT_DESCRIPTIONS = {
    "RT1": "divide-then-multiply round trip (Mult(Div(X, n), n) == X)",
    "RT2": "multiply-then-divide round trip (Div(Mult(X, n), n) == X)",
    "RT3": "split-recombine round trip (sum of Div(X, k) terms == X)",
    "RT4": "function-mediated divide-then-multiply round trip",
    "RT5": "add-subtract round trip (Add(Sub(X, c), c) == X)",
    "RT6": "divmod-decompose round trip (Add(Mult(FloorDiv(X, n), n), Mod(X, n)) == X)",
}


class _Normalize(ast.NodeTransformer):
    """Normalize 2-arg Fraction(a, b) calls into Div(a, b) so exact-rational
    round trips classify identically whether or not the Fraction import is
    spelled out."""

    def visit_Call(self, node):
        self.generic_visit(node)
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "Fraction"
            and len(node.args) == 2
            and not node.keywords
        ):
            return ast.BinOp(left=node.args[0], op=ast.Div(), right=node.args[1])
        return node


def _dump(node):
    return ast.dump(node)


def _is_div(n):
    return isinstance(n, ast.BinOp) and isinstance(n.op, ast.Div)


def _names_in(node):
    return any(isinstance(x, ast.Name) for x in ast.walk(node))


# -- banned-shape matchers: try both Eq orientations; P is the candidate
# -- round-trip construction, Q the candidate original value. -------------

def _match_rt1(P, Q):
    if isinstance(P, ast.BinOp) and isinstance(P.op, ast.Mult):
        for a, b in ((P.left, P.right), (P.right, P.left)):
            if _is_div(a):
                X, n1 = a.left, a.right
                if _dump(b) == _dump(n1) and _dump(Q) == _dump(X):
                    return _RT_DESCRIPTIONS["RT1"]
    return None


def _match_rt2(P, Q):
    if _is_div(P):
        X, n = P.left, P.right
        if isinstance(X, ast.BinOp) and isinstance(X.op, ast.Mult):
            for a, b in ((X.left, X.right), (X.right, X.left)):
                if _dump(b) == _dump(n) and _dump(Q) == _dump(a):
                    return _RT_DESCRIPTIONS["RT2"]
    return None


def _flatten_add(node):
    terms = []

    def rec(n):
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add):
            rec(n.left)
            rec(n.right)
        else:
            terms.append(n)

    rec(node)
    return terms


def _match_rt3(P, Q):
    # Generator/list/set-comprehension form: sum(<Div(X, k) for ...>) with
    # the comprehension count equal to k.
    if (
        isinstance(P, ast.Call)
        and isinstance(P.func, ast.Name)
        and P.func.id == "sum"
        and len(P.args) == 1
    ):
        gen = P.args[0]
        if (
            isinstance(gen, (ast.GeneratorExp, ast.ListComp, ast.SetComp))
            and len(gen.generators) == 1
        ):
            comp = gen.generators[0]
            if _is_div(gen.elt):
                X, k = gen.elt.left, gen.elt.right
                it = comp.iter
                count = None
                if (
                    isinstance(it, ast.Call)
                    and isinstance(it.func, ast.Name)
                    and it.func.id == "range"
                    and len(it.args) == 1
                ):
                    count = it.args[0]
                if (
                    count is not None
                    and _dump(count) == _dump(k)
                    and _dump(Q) == _dump(X)
                ):
                    return _RT_DESCRIPTIONS["RT3"]
    # Add-chain form: Add/sum(...) over k ast.dump-equal Div(X, k) terms.
    if isinstance(P, ast.BinOp):
        terms = _flatten_add(P)
        if len(terms) >= 2 and all(_is_div(t) for t in terms):
            X, k = terms[0].left, terms[0].right
            if all(
                _dump(t.left) == _dump(X) and _dump(t.right) == _dump(k)
                for t in terms
            ):
                if (
                    isinstance(k, ast.Constant)
                    and isinstance(k.value, int)
                    and len(terms) == k.value
                    and _dump(Q) == _dump(X)
                ):
                    return _RT_DESCRIPTIONS["RT3"]
    return None


def _match_rt5(P, Q):
    if isinstance(P, ast.BinOp) and isinstance(P.op, ast.Add):
        for a, b in ((P.left, P.right), (P.right, P.left)):
            if isinstance(a, ast.BinOp) and isinstance(a.op, ast.Sub):
                X, c = a.left, a.right
                if _dump(b) == _dump(c) and _dump(Q) == _dump(X):
                    return _RT_DESCRIPTIONS["RT5"]
    return None


def _match_rt6(P, Q):
    if isinstance(P, ast.BinOp) and isinstance(P.op, ast.Add):
        for a, b in ((P.left, P.right), (P.right, P.left)):
            if isinstance(a, ast.BinOp) and isinstance(a.op, ast.Mult):
                for f, nn in ((a.left, a.right), (a.right, a.left)):
                    if isinstance(f, ast.BinOp) and isinstance(f.op, ast.FloorDiv):
                        X, n1 = f.left, f.right
                        if (
                            _dump(nn) == _dump(n1)
                            and isinstance(b, ast.BinOp)
                            and isinstance(b.op, ast.Mod)
                            and _dump(b.left) == _dump(X)
                            and _dump(b.right) == _dump(n1)
                            and _dump(Q) == _dump(X)
                        ):
                            return _RT_DESCRIPTIONS["RT6"]
    return None


_RT_MATCHERS = (
    ("RT1", _match_rt1),
    ("RT2", _match_rt2),
    ("RT3", _match_rt3),
    ("RT5", _match_rt5),
    ("RT6", _match_rt6),
)


def _banned_match(Ls, Rs):
    """Return (shape, description) or None. Both Eq orientations tried."""
    for P, Q in ((Ls, Rs), (Rs, Ls)):
        for shape, fn in _RT_MATCHERS:
            hit = fn(P, Q)
            if hit:
                return shape, hit
    return None


# -- scope collection: module defs, per-function defs, single-return funcs. --

def _collect_value_assigns(stmts, defs):
    """First-wins Name -> value map over module-level statements, recursing
    into For/If/While/Try/With bodies but never into function/class defs."""
    for node in stmts:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id not in defs:
                    defs[t.id] = node.value
        elif isinstance(node, ast.AnnAssign):
            if (
                isinstance(node.target, ast.Name)
                and node.value is not None
                and node.target.id not in defs
            ):
                defs[node.target.id] = node.value
        else:
            for field in ("body", "orelse", "finalbody"):
                block = getattr(node, field, None)
                if isinstance(block, list):
                    _collect_value_assigns(block, defs)


def _function_returns(fn):
    out = []
    stack = list(fn.body)
    while stack:
        node = stack.pop()
        if isinstance(node, ast.Return):
            out.append(node)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            continue
        else:
            stack.extend(ast.iter_child_nodes(node))
    return out


def _inlinable_single_return(fn, params):
    """Return (params, return_expr) if fn is safely one-step inlinable:
    exactly one Return with a value, no parameter reassignment, and the
    return expression references no function-local names (assigned in the
    body but not parameters). Without this, inlining can capture or dangle
    names and manufacture false dump-equality."""
    rets = _function_returns(fn)
    if len(rets) != 1 or rets[0].value is None:
        return None
    assigned = set()
    for n in ast.walk(fn):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            assigned.add(n.id)
    if any(p in assigned for p in params):
        return None
    locals_only = assigned - set(params)
    for n in ast.walk(rets[0].value):
        if isinstance(n, ast.Name) and n.id in locals_only:
            return None
    return params, rets[0].value


def _parent_map(tree):
    pmap = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            pmap[child] = parent
    return pmap


def _iter_asserts(tree):
    """Yield (assert_node, defs, funcs) with correct scoping, skipping asserts
    inside functions whose names contain planted/mutant/witness keywords."""
    module_defs = {}
    _collect_value_assigns(tree.body, module_defs)
    single_return = {}
    fn_locals = {}
    fn_bound = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            params = [a.arg for a in node.args.args]
            if not node.args.vararg and not node.args.kwarg:
                inlined = _inlinable_single_return(node, params)
                if inlined is not None:
                    single_return[node.name] = inlined
            local = {}
            bound = set(params)
            stack = list(node.body)
            while stack:
                sub = stack.pop()
                if isinstance(
                    sub, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
                ):
                    continue
                if isinstance(sub, ast.Assign):
                    for t in sub.targets:
                        for n in ast.walk(t):
                            if isinstance(n, ast.Name):
                                bound.add(n.id)
                        if isinstance(t, ast.Name) and t.id not in local:
                            local[t.id] = sub.value
                elif isinstance(sub, ast.AnnAssign):
                    for n in ast.walk(sub.target):
                        if isinstance(n, ast.Name):
                            bound.add(n.id)
                    if (
                        isinstance(sub.target, ast.Name)
                        and sub.value is not None
                        and sub.target.id not in local
                    ):
                        local[sub.target.id] = sub.value
                elif isinstance(sub, (ast.For, ast.AsyncFor)):
                    for n in ast.walk(sub.target):
                        if isinstance(n, ast.Name):
                            bound.add(n.id)
                stack.extend(ast.iter_child_nodes(sub))
            fn_locals[node.name] = local
            fn_bound[node.name] = bound
    pmap = _parent_map(tree)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assert):
            continue
        # Innermost enclosing function, if any.
        fn = None
        p = pmap.get(node)
        while p is not None:
            if isinstance(p, (ast.FunctionDef, ast.AsyncFunctionDef)):
                fn = p
                break
            p = pmap.get(p)
        if fn is not None and any(
            kw in fn.name.lower() for kw in MUTANT_KEYWORDS
        ):
            continue
        if fn is None:
            yield node, module_defs, single_return, frozenset()
        else:
            defs = dict(module_defs)
            defs.update(fn_locals.get(fn.name, {}))
            yield node, defs, single_return, fn_bound.get(fn.name, frozenset())


# -- substitution: one full recursive defs/funcs pass, tracked. -----------

def _replace_names(node, mapping):
    """Replace Name(id) with a deep copy of mapping[id], recursively."""
    if isinstance(node, ast.Name) and node.id in mapping:
        return copy.deepcopy(mapping[node.id])
    for field, val in ast.iter_fields(node):
        if isinstance(val, ast.AST):
            setattr(node, field, _replace_names(val, mapping))
        elif isinstance(val, list):
            setattr(
                node,
                field,
                [
                    _replace_names(v, mapping) if isinstance(v, ast.AST) else v
                    for v in val
                ],
            )
    return node


def _substitute(node, defs, funcs, consulted, use_funcs, depth):
    """One full recursive pass. Names consult defs; single-return function
    calls consult funcs (one-step inline) when use_funcs is set. Every
    consulted defs/funcs key is recorded. Recursion is depth-bounded."""
    if depth > 5:
        return node
    if isinstance(node, ast.Name):
        if node.id in defs:
            consulted.add(node.id)
            return _substitute(
                copy.deepcopy(defs[node.id]), defs, funcs, consulted, use_funcs, depth + 1
            )
        return node
    if (
        use_funcs
        and isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id in funcs
        and not node.keywords
        and not any(isinstance(a, ast.Starred) for a in node.args)
    ):
        params, ret = funcs[node.func.id]
        if len(params) == len(node.args):
            consulted.add(node.func.id)
            inlined = _replace_names(
                copy.deepcopy(ret), dict(zip(params, node.args))
            )
            return _substitute(
                inlined, defs, funcs, consulted, use_funcs, depth + 1
            )
    for field, val in ast.iter_fields(node):
        if isinstance(val, ast.AST):
            setattr(
                node, field, _substitute(val, defs, funcs, consulted, use_funcs, depth)
            )
        elif isinstance(val, list):
            setattr(
                node,
                field,
                [
                    _substitute(v, defs, funcs, consulted, use_funcs, depth)
                    if isinstance(v, ast.AST)
                    else v
                    for v in val
                ],
            )
    return node


def _subst_copy(operand, defs, funcs, use_funcs):
    """Substitute a deep copy of operand; return (new_node, consulted)."""
    consulted = set()
    new = _substitute(
        copy.deepcopy(operand), defs, funcs, consulted, use_funcs, 0
    )
    return new, consulted


def _value_names_in(node):
    """Names used as values, skipping Compare subtrees.

    A name that appears only inside a Compare (e.g. a filter predicate like
    `p['status'] == OPEN`) is predicate-use, not value-use: selecting by a
    criterion does not smuggle the criterion's value into the construction.
    The exclusion targets value-smuggling (arithmetic/construction), so
    predicate-use names are not counted.
    """
    names = set()
    stack = [node]
    while stack:
        n = stack.pop()
        if isinstance(n, ast.Compare):
            # Do not descend: operand names here are predicate-use.
            # (The compared values themselves are already accounted for
            #  by the enclosing expression's other names.)
            continue
        if isinstance(n, ast.Name):
            names.add(n.id)
        stack.extend(ast.iter_child_nodes(n))
    return names


def _def_use_closure(substituted, consulted, defs, funcs):
    """Names in the substituted form plus every name reachable through the
    consulted defs/funcs entries (transitive). Compare-subtree names are
    excluded (predicate-use, not value-use)."""
    names = _value_names_in(substituted)
    seen = set()
    stack = list(consulted)
    while stack:
        key = stack.pop()
        if key in seen:
            continue
        seen.add(key)
        expr = defs.get(key)
        if expr is None and key in funcs:
            expr = funcs[key][1]
        if expr is None:
            continue
        for nid in _value_names_in(expr):
            names.add(nid)
            if nid in defs or nid in funcs:
                stack.append(nid)
    return names


# -- whitelist -------------------------------------------------------------

def _w1(L_orig, R_orig):
    """One side of the Eq contains no Name nodes in the original assert,
    before any substitution."""
    return not _names_in(L_orig) or not _names_in(R_orig)


def _resolve_to_literal_name(name, defs):
    """Follow defs transitively; return the terminal value node or None."""
    seen = set()
    cur = name
    while isinstance(cur, ast.Name) and cur.id in defs and cur.id not in seen:
        seen.add(cur.id)
        cur = defs[cur.id]
    return cur if not isinstance(cur, ast.Name) else None


def _is_literal_structure(node):
    """Constant, or Tuple/List/Dict/Set composed of literals (recursive)."""
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, (ast.Tuple, ast.List, ast.Set)):
        return all(_is_literal_structure(e) for e in node.elts)
    if isinstance(node, ast.Dict):
        return all(
            _is_literal_structure(k) and _is_literal_structure(v)
            for k, v in zip(node.keys, node.values)
            if k is not None
        )
    return False


def _w2_shape(L_orig, R_orig, defs):
    """One operand is a Name resolving (via defs) to a module-level literal;
    the other side is any computation (any expression)."""
    for name_side, other_side in ((L_orig, R_orig), (R_orig, L_orig)):
        if isinstance(name_side, ast.Name):
            resolved = _resolve_to_literal_name(name_side, defs)
            if resolved is not None and _is_literal_structure(resolved):
                return True
    return False


def _w3_structural(Ls, Rs):
    """Both sides are arbitrary expressions with ast.dump-different
    normalized forms, and neither side is an inverse-op construction on the
    other (re-runs the banned matchers with X fixed)."""
    if _dump(Ls) == _dump(Rs):
        return False
    return _banned_match(Ls, Rs) is None


def _w4(Ls, Rs, src_line):
    """Analytic identity with proof pointer: the W3 structural condition
    holds and the assert line carries an inline '# analytic: <docstring
    proof location>' comment. W4 overrides the exclusion."""
    return (
        src_line is not None
        and "# analytic:" in src_line
        and _w3_structural(Ls, Rs)
    )


def _exclusion_fires(L_orig, R_orig, Ls, Rs, consulted_L, consulted_R,
                     covered, defs, funcs, shadowed=frozenset()):
    """The covered-source-name exclusion: if one Eq operand is a bare Name
    that is a covered source name (and not shadowed by a function-local
    binding in the assert's scope), and that name appears anywhere in the
    other operand's def-use closure (substituted form plus every defs/funcs
    entry consulted during substitution), the whitelist is refused even for
    W2/W3-shaped pairs."""
    for orig, other_sub, other_consulted in (
        (L_orig, Rs, consulted_R),
        (R_orig, Ls, consulted_L),
    ):
        if (
            isinstance(orig, ast.Name)
            and orig.id in covered
            and orig.id not in shadowed
        ):
            closure = _def_use_closure(other_sub, other_consulted, defs, funcs)
            if orig.id in closure:
                return True
    return False


def _eq_pairs(test):
    """All (L, R) Eq operand pairs inside an assert test."""
    pairs = []
    for node in ast.walk(test):
        if isinstance(node, ast.Compare):
            for op, comp in zip(node.ops, node.comparators):
                if isinstance(op, ast.Eq):
                    pairs.append((node.left, comp))
    return pairs


def classify_eq_pair(L_orig, R_orig, defs, funcs, covered, in_level_a,
                     src_line, shadowed=frozenset()):
    """Classify one Eq pair. Returns (verdict, detail) where verdict is one
    of "banned", "ok", "unclassified"."""
    # Pass 1: substitute defs only; RT1/RT2/RT3/RT5/RT6 banned.
    Ls1, cL1 = _subst_copy(L_orig, defs, funcs, use_funcs=False)
    Rs1, cR1 = _subst_copy(R_orig, defs, funcs, use_funcs=False)
    hit = _banned_match(Ls1, Rs1)
    if hit:
        return "banned", hit
    # Pass 2: substitute defs + single-return function inlining.
    Ls2, cL2 = _subst_copy(L_orig, defs, funcs, use_funcs=True)
    Rs2, cR2 = _subst_copy(R_orig, defs, funcs, use_funcs=True)
    hit = _banned_match(Ls2, Rs2)
    if hit:
        shape, desc = hit
        if shape == "RT1":
            shape, desc = "RT4", _RT_DESCRIPTIONS["RT4"]
        return "banned", (shape, desc)
    # Banned shapes are rejected at every level; non-Level-A scripts stop
    # here (no default-deny, no whitelist needed).
    if not in_level_a:
        return "ok", None
    # Pass 3: whitelist W1-W4 for Level-A-backed scripts.
    if _w1(L_orig, R_orig):
        return "ok", None
    if _w2_shape(L_orig, R_orig, defs):
        if not _exclusion_fires(L_orig, R_orig, Ls2, Rs2, cL2, cR2,
                                covered, defs, funcs, shadowed):
            return "ok", None
    if _w3_structural(Ls2, Rs2):
        if not _exclusion_fires(L_orig, R_orig, Ls2, Rs2, cL2, cR2,
                                covered, defs, funcs, shadowed):
            return "ok", None
    if _w4(Ls2, Rs2, src_line):
        return "ok", None
    return "unclassified", None


def check2_rt_scan(path, tree, text, in_level_a, claim_ids, covered):
    """AST Eq-assert scan with default-deny for Level-A-backed scripts."""
    label = Path(path).name
    lines = text.splitlines()
    violations = []
    norm_tree = _Normalize().visit(copy.deepcopy(tree))
    for node, defs, funcs, shadowed in _iter_asserts(norm_tree):
        src_line = lines[node.lineno - 1] if 1 <= node.lineno <= len(lines) else None
        for L_orig, R_orig in _eq_pairs(node.test):
            verdict, detail = classify_eq_pair(
                L_orig, R_orig, defs, funcs, covered, in_level_a, src_line,
                shadowed
            )
            if verdict == "banned":
                shape, desc = detail
                violations.append(
                    "F49: %s:%d ROUND_TRIP(%s): %s (claims: %s)"
                    % (label, node.lineno, shape, desc, ",".join(sorted(claim_ids)))
                )
            elif verdict == "unclassified":
                violations.append(
                    "F49: %s:%d UNCLASSIFIED_ASSERT: Eq-compare matches no "
                    "banned shape (RT1-RT6) and no whitelist entry (W1-W4); "
                    "default-deny in Level-A-backed script (claims: %s)"
                    % (label, node.lineno, ",".join(sorted(claim_ids)))
                )
    return violations


# ---------------------------------------------------------------------------
# Check 3: PROVENANCE_SCAN - INPUT_PROVENANCE declaration surface.
# ---------------------------------------------------------------------------

_CLASS_REQUIRED_KEY = {
    "paper-defined": "source",
    "cited-paper": "source",
    "control": "note",
    "declared-assumption": "prose",
    "arbitrary-representative": "independence",
}
_CLASSES_NEEDING_SECTION = {"paper-defined", "cited-paper", "declared-assumption"}
_SECTION_MARKER_RE = re.compile(r"§\d+(?:\.\d+)*")
# Explicit external-document citations ("Paper 10, §5.3.1"): the § marker
# addresses the other document, not this paper, so the Paper-11-local
# heading check must not resolve it -- resolving it here produced a false
# pass (Paper 10 §5.3 matched this paper's §5.3 by coincidence). External
# citations are on-trust, human-verified against the canonical document.
_EXTERNAL_CITE_RE = re.compile(r"Paper\s+\d+(?:\.\d+)?\s*,?\s*§\d+(?:\.\d+)*")


def _local_markers_in(citation):
    """Section markers addressing this paper: external-document citations
    are stripped before extraction, since this paper's headings cannot
    resolve another document's sections."""
    text = _EXTERNAL_CITE_RE.sub("", citation or "")
    return _markers_in(text)


def covered_source_names(tree):
    """Names bound at module level (first-wins) that are covered source
    names: their defining expression references no other module-level
    value-name (self-contained inputs). For-targets over literal iterables
    also count. INPUT_PROVENANCE and DOMAIN are excluded (they are
    declaration blocks, not inputs). Function and class bodies are never
    module level.
    """
    assigned = {}
    for_targets = []  # (name, iter_node)

    def visit_block(stmts):
        for node in stmts:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if (
                        isinstance(t, ast.Name)
                        and t.id not in ("INPUT_PROVENANCE", "DOMAIN")
                        and t.id not in assigned
                    ):
                        assigned[t.id] = node.value
            elif isinstance(node, ast.AnnAssign):
                if (
                    isinstance(node.target, ast.Name)
                    and node.value is not None
                    and node.target.id not in ("INPUT_PROVENANCE", "DOMAIN")
                    and node.target.id not in assigned
                ):
                    assigned[node.target.id] = node.value
            elif isinstance(node, ast.For):
                if isinstance(node.target, ast.Name) and node.target.id != "_":
                    for_targets.append((node.target.id, node.iter))
                visit_block(node.body)
                visit_block(node.orelse)
            else:
                for field in ("body", "orelse", "finalbody"):
                    block = getattr(node, field, None)
                    if isinstance(block, list):
                        visit_block(block)

    visit_block(tree.body)
    value_names = set(assigned) | {t for t, _ in for_targets}

    def refs_other_value_name(expr, self_name):
        for n in ast.walk(expr):
            if (
                isinstance(n, ast.Name)
                and n.id in value_names
                and n.id != self_name
            ):
                return True
        return False

    covered = set()
    for name, expr in assigned.items():
        if not refs_other_value_name(expr, name):
            covered.add(name)
    for tname, it in for_targets:
        # Literal module-level loop iterables only: the target is a source
        # name when the iterable itself is a literal (Tuple/List of
        # constants). A range() call or a module-name iterable is not.
        if _is_literal_structure(it):
            covered.add(tname)
    return covered


def read_provenance(path):
    """Return the INPUT_PROVENANCE dict, or None if absent/unparseable."""
    tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "INPUT_PROVENANCE"
            for t in node.targets
        ):
            try:
                val = ast.literal_eval(node.value)
            except Exception:
                return None
            return val if isinstance(val, dict) else None
    return None


def paper_sections(paper_md):
    """Paper heading lines (markdown headings only), R18-compatible: a
    heading is a line whose first non-space characters are 1-6 '#' followed
    by whitespace. No F.38 import needed."""
    sections = []
    for line in Path(paper_md).read_text(encoding="utf-8").splitlines():
        s = line.lstrip()
        if re.match(r"#{1,6}\s", s):
            sections.append(s)
    return sections


def _heading_numbers(sections):
    nums = set()
    for h in sections or []:
        m = re.match(r"#{1,6}\s+(§\d+(?:\.\d+)*)", h)
        if m:
            nums.add(m.group(1).rstrip("."))
    return nums


def _markers_in(citation):
    return {m.rstrip(".") for m in _SECTION_MARKER_RE.findall(citation or "")}


def provenance_violations(path, sections):
    """Check 3 for one script: every covered source name must carry a
    declared class; stale keys are rejected; section citations must resolve
    to real paper headings (R18-compatible heading semantics); declared-
    assumption prose must carry a section marker; optional anchor phrases
    must appear in the cited section's text."""
    label = Path(path).name
    text = Path(path).read_text(encoding="utf-8")
    tree = ast.parse(text)
    covered = covered_source_names(tree)
    block = read_provenance(path)
    violations = []
    if block is None:
        return [
            "F49: %s PROVENANCE: missing or unparseable INPUT_PROVENANCE "
            "block (%d covered source names: %s)"
            % (label, len(covered), ",".join(sorted(covered)))
        ]
    if not isinstance(block, dict):
        return [
            "F49: %s PROVENANCE: INPUT_PROVENANCE is not a dict" % label
        ]
    heading_numbers = _heading_numbers(sections)
    paper_lines = (
        Path(PAPER).read_text(encoding="utf-8").splitlines()
        if PAPER.exists()
        else []
    )
    for key, entry in block.items():
        if key not in covered:
            violations.append(
                "F49: %s PROVENANCE: stale key %r names no covered source "
                "name (rejected)" % (label, key)
            )
            continue
        if not isinstance(entry, dict):
            violations.append(
                "F49: %s PROVENANCE: key %r entry is not a dict" % (label, key)
            )
            continue
        cls = entry.get("class")
        if cls not in PROVENANCE_CLASSES:
            violations.append(
                "F49: %s PROVENANCE: key %r has unknown class %r"
                % (label, key, cls)
            )
            continue
        req = _CLASS_REQUIRED_KEY[cls]
        if not entry.get(req):
            violations.append(
                "F49: %s PROVENANCE: key %r class %r missing required key %r"
                % (label, key, cls, req)
            )
            continue
        citation = entry.get(req)
        if cls == "declared-assumption" and not _markers_in(citation):
            violations.append(
                "F49: %s PROVENANCE: key %r declared-assumption prose carries "
                "no section marker" % (label, key)
            )
            continue
        if cls in _CLASSES_NEEDING_SECTION:
            markers = _local_markers_in(citation)
            for mk in sorted(markers):
                if mk not in heading_numbers:
                    violations.append(
                        "F49: %s PROVENANCE: key %r cites unresolvable "
                        "section %r" % (label, key, mk)
                    )
            anchor = entry.get("anchor")
            if anchor:
                for mk in sorted(markers):
                    sec_text = _section_text(paper_lines, mk)
                    if sec_text is not None and anchor not in sec_text:
                        violations.append(
                            "F49: %s PROVENANCE: key %r anchor phrase not "
                            "found in %s" % (label, key, mk)
                        )
    for name in sorted(covered):
        if name not in block:
            violations.append(
                "F49: %s PROVENANCE: source name %r has no provenance "
                "declaration" % (label, name)
            )
    return violations


def _section_text(paper_lines, marker):
    """Text of the section whose heading starts with the marker, up to the
    next markdown heading. None if the heading is not found."""
    start = None
    for i, line in enumerate(paper_lines):
        s = line.lstrip()
        if re.match(r"#{1,6}\s", s):
            m = re.match(r"#{1,6}\s+(§\d+(?:\.\d+)*)\.?", s)
            if m and m.group(1).rstrip(".") == marker:
                start = i
                break
    if start is None:
        return None
    out = []
    for line in paper_lines[start + 1:]:
        if re.match(r"#{1,6}\s", line.lstrip()):
            break
        out.append(line)
    return "\n".join(out)


def provenance_census(reg, root=HERE):
    """One line per declared input: '<stem>: <key>: <class> (<citation>)',
    plus '(no INPUT_PROVENANCE block)' / '(script file missing)' markers.
    Reporting only - never a violation."""
    short_map = level_a_backed_scripts(reg)
    stems = resolve_stems(short_map, root)
    lines = []
    for stem in sorted(stems):
        path = Path(root) / (stem + ".py")
        if not path.exists():
            lines.append("%s: (script file missing)" % stem)
            continue
        block = read_provenance(path)
        if block is None:
            lines.append("%s: (no INPUT_PROVENANCE block)" % stem)
            continue
        if not block:
            lines.append("%s: (empty INPUT_PROVENANCE block: zero declared inputs)" % stem)
            continue
        for key in block:
            entry = block[key]
            if isinstance(entry, dict):
                cls = entry.get("class", "?")
                cite = (
                    entry.get("source")
                    or entry.get("prose")
                    or entry.get("note")
                    or entry.get("independence")
                    or ""
                )
            else:
                cls, cite = "?", ""
            lines.append("%s: %s: %s (%s)" % (stem, key, cls, cite))
    return lines


# ---------------------------------------------------------------------------
# Check 4: paper tripwires + prose badge census (reporting only).
# ---------------------------------------------------------------------------

_TABLE_HEADER = "| ID | Level | Kind | Axioms | Deps | Deferred | Script | Text |"
_F_RANGE_RE = re.compile(r"F\.(\d+)\s*[-\u2013]\s*F\.(\d+)")
_F_NUM_RE = re.compile(r"F\.(\d+)")


def _expand_f_numbers(field):
    """F-numbers named in a Script field: expand F.33-F.35 ranges, split on
    '+', strip; skip '-', 'prose ...', and bare 'F.38' machinery rows."""
    nums = set()
    for part in str(field).split("+"):
        part = part.strip()
        if not part or part == "-" or part.lower().startswith("prose"):
            continue
        for m in _F_RANGE_RE.finditer(part):
            lo, hi = int(m.group(1)), int(m.group(2))
            nums.update(str(n) for n in range(min(lo, hi), max(lo, hi) + 1))
        part = _F_RANGE_RE.sub("", part)
        for m in _F_NUM_RE.finditer(part):
            nums.add(m.group(1))
    return nums


def check4_table(paper_text, reg):
    """Tripwire 1: for each claim-table row whose Script field names F-stems,
    the row's Level must equal the registry's level for that claim ID.
    Returns (violations, table_start, table_end)."""
    lines = paper_text.splitlines()
    hidx = next(
        (i for i, l in enumerate(lines) if l.strip() == _TABLE_HEADER), None
    )
    if hidx is None:
        return ["F49: paper TABLE: claim-table header row not found"], None, None
    by_id = {r["id"]: r for r in reg}
    violations = []
    rows = []
    i = hidx + 1
    while i < len(lines):
        s = lines[i].strip()
        if not s.startswith("|"):
            break
        if set(s) <= set("|-: "):
            i += 1
            continue
        rows.append((i + 1, s))
        i += 1
    for lineno, row in rows:
        cells = [c.strip() for c in row.strip().strip("|").split("|")]
        if len(cells) < 8:
            continue
        cid, level, script_field = cells[0], cells[1], cells[6]
        if not _expand_f_numbers(script_field):
            continue
        reg_row = by_id.get(cid)
        if reg_row is None:
            violations.append(
                "F49: paper:%d TABLE: claim %s has no registry row" % (lineno, cid)
            )
        elif reg_row.get("level") != level:
            violations.append(
                "F49: paper:%d TABLE: claim %s row level %r != registry level %r"
                % (lineno, cid, level, reg_row.get("level"))
            )
    return violations, (hidx + 1), i


def check4_machine_check(paper_text, reg):
    """Tripwire 2: every '**Machine check.**' paragraph carrying a
    [LEVEL A] badge must name >= 1 F-stem that backs a Level-A claim
    in the registry. Returns (violations, machine_check_lines)."""
    short_map = level_a_backed_scripts(reg)
    backed_nums = set()
    for stem in short_map:
        # Stems may be full (F39_relational_role) or short (F39); extract the number.
        m = re.match(r"F(\d+)", stem)
        if m:
            backed_nums.add(m.group(1))
    violations = []
    mc_lines = []
    in_fence = False
    for lineno, line in enumerate(paper_text.splitlines(), 1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if line.startswith("**Machine check.**"):
            mc_lines.append(lineno)
            if "[LEVEL A" in line:
                if not (_expand_f_numbers(line) & backed_nums):
                    violations.append(
                        "F49: paper:%d MACHINE_CHECK: [LEVEL A] paragraph "
                        "names no Level-A-backing script" % lineno
                    )
    return violations, mc_lines


def prose_badge_census(paper_md, table_line_range, machine_check_lines):
    """Every [LEVEL A/B/C] badge site in the paper outside fenced code
    blocks, excluding the claim-table rows and the **Machine check.**
    paragraphs. Reporting only - printed as PROSE_BADGE_CENSUS, never a
    violation."""
    path = Path(paper_md)
    lines = path.read_text(encoding="utf-8").splitlines()
    tstart, tend = table_line_range or (None, None)
    mc = set(machine_check_lines or [])
    in_fence = False
    out = []
    for lineno, line in enumerate(lines, 1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if tstart is not None and tstart <= lineno <= tend:
            continue
        if lineno in mc:
            continue
        if re.search(r"\[LEVEL [ABC]", line):
            excerpt = line.strip()[:100]
            out.append("paper:%d: %s" % (lineno, excerpt))
    return out


def hygiene_violations(reg, root=HERE):
    """Checks 1, 2, and 4 only.

    Check 3 (provenance) is deliberately excluded here: it is reported
    separately via provenance_violations / provenance_census (and wired
    into the registry's R22 half of that name). When the paper file is
    absent, Check 4 contributes nothing (documented skip: the tripwires
    need the paper text).
    """
    root = Path(root)
    short_map = level_a_backed_scripts(reg)
    stems = resolve_stems(short_map, root)
    violations = []
    for path in scanned_scripts(root):
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text)
        ids = stems.get(path.stem, set())
        in_level_a = bool(ids)
        covered = covered_source_names(tree)
        if in_level_a:
            violations.extend(check1_word_scan(path, text, ids))
        violations.extend(
            check2_rt_scan(path, tree, text, in_level_a, ids, covered)
        )
    paper = root.parent / "paper_11.md"
    if paper.exists():
        paper_text = paper.read_text(encoding="utf-8")
        tv, tstart, tend = check4_table(paper_text, reg)
        violations.extend(tv)
        mv, _mc_lines = check4_machine_check(paper_text, reg)
        violations.extend(mv)
    return violations


# ---------------------------------------------------------------------------
# Check 5: DOMAIN cross-check - script DOMAIN["proved"] == registry
# proved_domain (the R23 record half; F.38's R23 is the claim half).
# ---------------------------------------------------------------------------

def read_domain_from_text(text):
    """Parse a script's DOMAIN block via AST (never import: a script under
    test must not be executed). Returns the dict, or None if absent or
    unparseable."""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "DOMAIN" for t in node.targets
        ):
            try:
                val = ast.literal_eval(node.value)
            except Exception:
                return None
            return val if isinstance(val, dict) else None
    return None


def domain_violations(reg, root=HERE):
    """Check 5: the R23 domain-declaration record check.

    For every Level-A script-lineage claim: every backing script file must
    carry a DOMAIN block beside INPUT_PROVENANCE, and the union of the
    backing scripts' DOMAIN["proved"] kind-lists must equal the row's
    proved_domain. A mismatch means the registry's proved-domain record
    does not describe the scripts' actual checks -- the F.44 defect class
    at the record level. (A row missing proved_domain entirely is R23's
    complaint inside F.38, not Check 5's.)
    """
    root = Path(root)
    short_map = level_a_backed_scripts(reg)
    stems = resolve_stems(short_map, root)
    # Parse every backing script's DOMAIN block once (AST; never import).
    dom_proved = {}
    for stem in stems:
        path = root / (stem + ".py")
        if not path.exists():
            continue
        dom = read_domain_from_text(path.read_text(encoding="utf-8"))
        if dom is None:
            dom_proved[stem] = None
        else:
            proved = dom.get("proved")
            dom_proved[stem] = (
                proved
                if isinstance(proved, list)
                and all(isinstance(k, str) for k in proved)
                else "MALFORMED"
            )
    violations = []
    by_id = {r.get("id"): r for r in reg}
    claim_stems = {}
    for stem, ids in stems.items():
        for cid in ids:
            claim_stems.setdefault(cid, set()).add(stem)
    for cid in sorted(claim_stems):
        row = by_id.get(cid)
        if row is None:
            continue
        if row.get("level") != "A" or row.get("lineage") != "script":
            continue
        if "proved_domain" not in row:
            continue
        union = set()
        ok = True
        for stem in sorted(claim_stems[cid]):
            dp = dom_proved.get(stem)
            if dp is None:
                violations.append(
                    "F49: %s DOMAIN: missing or unparseable DOMAIN block "
                    "(backs Level-A claim %s)" % (stem + ".py", cid)
                )
                ok = False
            elif dp == "MALFORMED":
                violations.append(
                    "F49: %s DOMAIN: 'proved' is not a list of kind names "
                    "(backs %s)" % (stem + ".py", cid)
                )
                ok = False
            else:
                union.update(dp)
        if not ok:
            continue
        if set(union) != set(row["proved_domain"]):
            violations.append(
                "F49: claim %s DOMAIN: backing scripts' proved %s != "
                "registry proved_domain %s"
                % (cid, sorted(union), sorted(row["proved_domain"]))
            )
    return violations


# ---------------------------------------------------------------------------
# Mutant suite: 8 planted mutants + passing controls, one line each.
# ---------------------------------------------------------------------------

# Each entry: (label, source, level_a_backed, expected_signals).
# expected_signals is a list of violation-substring requirements, or the
# single token "PASS" (no violations at all).

_M1 = ("M1", '''"""M1: placeholder wording with a real round trip behind Level A."""
s2_total = Fraction(50)  # illustrative workload placeholder
n = 3
assert (s2_total / n) * n == s2_total
''', True, ["WORD", "ROUND_TRIP(RT1)", "PROVENANCE"])

_M2 = ("M2", '''"""M2: round-trip identity with declared inputs, every value genuine."""
INPUT_PROVENANCE = {
    "X": {"class": "control", "note": "synthetic sweep input"},
    "n": {"class": "control", "note": "synthetic sweep divisor"},
}
X = 10
n = 2
q = X / n
assert q * n == X
''', True, ["ROUND_TRIP(RT1)"])

_M3 = ("M3", '''"""M3: undeclared source name behind Level A."""
K_FACT = 7
assert K_FACT * 6 == 42
''', True, ["PROVENANCE"])

_M4 = ("M4", '''"""M4: laundered placeholder chain (not a clean divide-multiply)."""
INPUT_PROVENANCE = {
    "workload_value": {"class": "paper-defined", "source": "§5.1"},
}
workload = 50  # representative workload value
n_aspects = 4
per_aspect = workload // n_aspects
parts = [per_aspect] * n_aspects
parts[-1] = parts[-1] + (workload % n_aspects)
assert sum(parts) == workload
''', True, ["UNCLASSIFIED_ASSERT", "PROVENANCE"])

_M5 = ("M5", '''"""M5: honest Level-B placeholder use - must pass."""
s2_demo = 50  # illustrative workload placeholder (Level B illustration)
assert s2_demo == 50
''', False, ["PASS"])

_M6 = ("M6", '''"""M6: the F.33-F.35 placeholder pattern, verbatim shape."""
NOTE = "s2 values below are illustrative workload placeholders"
s2_total = Fraction(90)  # illustrative placeholder
interior_count = 4
s2_interior_per_aspect = s2_total / interior_count
assert s2_interior_per_aspect * interior_count == s2_total
''', True, ["WORD", "ROUND_TRIP(RT1)", "PROVENANCE"])

_M7 = ("M7", '''"""M7: round trip behind a Level-B-only script - must still fail."""
x = 10
n = 2
assert (x / n) * n == x
''', False, ["ROUND_TRIP(RT1)"])

_M8 = ("M8", '''"""M8: declared-assumption remediation pattern - must pass."""
INPUT_PROVENANCE = {
    "TH": {"class": "declared-assumption",
           "prose": "§8.6 (exact TH is Paper 14's locked debt; "
                    "fuse shape verified at TH=1)"},
}
TH = 1  # declared assumption: exact TH is Paper 14's locked debt (§8.6)
assert TH == 1
assert TH + 0 == 1
''', True, ["PASS"])

MUTANTS = [_M1, _M2, _M3, _M4, _M5, _M6, _M7, _M8]

# Passing controls: shapes the whitelist must not flag (Check 2 only).
_CONTROLS = [
    ("C-W3-NameEqName", '''
def check():
    out1 = len([1, 2])
    out2 = sum([1, 1])
    assert out1 == out2
'''),
    ("C-W1-literal", '''
def check():
    assert n_pairs == 442 * 455
'''),
    ("C-W4-analytic", '''
INPUT_PROVENANCE = {
    "x": {"class": "control", "note": "synthetic base value"},
}
x = 3
def check():
    assert x == x + 0  # analytic: additive identity, docstring proof sketch
'''),
    ("C-W1-trichotomy", '''
def check():
    assert (b1 + b2 + b3) == 1
'''),
    ("C-W3-CallEqCall", '''
def check():
    assert tension(s) == sum(1 for st in A if st != 0)
'''),
    ("C-W3-BinOpEqBinOp", '''
def check():
    assert N(d + 1) - N(d) == 8 * d + 4
'''),
    ("C-W3-TupleEqTuple", '''
def check():
    assert (out1, r1) == (out3, r3)
'''),
]


def _sweep_source(label, src, in_level_a, claim_ids, sections):
    """Run Checks 1-3 over one synthetic source. Returns violations."""
    text = src
    tree = ast.parse(text)
    violations = []
    if in_level_a:
        violations.extend(check1_word_scan(label, text, claim_ids))
    covered = covered_source_names(tree)
    violations.extend(check2_rt_scan(label, tree, text, in_level_a, claim_ids, covered))
    if in_level_a:
        block = read_provenance_from_text(text)
        violations.extend(
            _provenance_violations_tree(label, text, tree, block, covered, sections)
        )
    return violations


def read_provenance_from_text(text):
    tree = ast.parse(text)
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "INPUT_PROVENANCE"
            for t in node.targets
        ):
            try:
                val = ast.literal_eval(node.value)
            except Exception:
                return None
            return val if isinstance(val, dict) else None
    return None


def _provenance_violations_tree(label, text, tree, block, covered, sections):
    """provenance_violations for an in-memory source (mutant suite)."""
    violations = []
    if block is None:
        return [
            "F49: %s PROVENANCE: missing or unparseable INPUT_PROVENANCE "
            "block (%d covered source names: %s)"
            % (label, len(covered), ",".join(sorted(covered)))
        ]
    heading_numbers = _heading_numbers(sections)
    for key, entry in block.items():
        if key not in covered:
            violations.append(
                "F49: %s PROVENANCE: stale key %r names no covered source "
                "name (rejected)" % (label, key)
            )
            continue
        if not isinstance(entry, dict):
            violations.append(
                "F49: %s PROVENANCE: key %r entry is not a dict" % (label, key)
            )
            continue
        cls = entry.get("class")
        if cls not in PROVENANCE_CLASSES:
            violations.append(
                "F49: %s PROVENANCE: key %r has unknown class %r"
                % (label, key, cls)
            )
            continue
        req = _CLASS_REQUIRED_KEY[cls]
        if not entry.get(req):
            violations.append(
                "F49: %s PROVENANCE: key %r class %r missing required key %r"
                % (label, key, cls, req)
            )
            continue
        citation = entry.get(req)
        if cls == "declared-assumption" and not _markers_in(citation):
            violations.append(
                "F49: %s PROVENANCE: key %r declared-assumption prose carries "
                "no section marker" % (label, key)
            )
            continue
        if cls in _CLASSES_NEEDING_SECTION:
            for mk in sorted(_markers_in(citation)):
                if mk not in heading_numbers:
                    violations.append(
                        "F49: %s PROVENANCE: key %r cites unresolvable "
                        "section %r" % (label, key, mk)
                    )
    for name in sorted(covered):
        if name not in block:
            violations.append(
                "F49: %s PROVENANCE: source name %r has no provenance "
                "declaration" % (label, name)
            )
    return violations


def run_mutants(sections):
    """Run the 8 mutants; return [(label, ok, violations)]. One line per
    mutant is printed by the __main__ driver."""
    results = []
    for label, src, in_level_a, expected in MUTANTS:
        violations = _sweep_source(
            label, src, in_level_a, {"MUTANT"}, sections
        )
        if expected == ["PASS"]:
            ok = not violations
        else:
            ok = all(
                any(sig in v for v in violations) for sig in expected
            )
        results.append((label, ok, violations))
    return results


def run_controls():
    """Check-2-only pass over the passing controls; return [(label, ok)]."""
    results = []
    for label, src in _CONTROLS:
        text = src
        tree = ast.parse(text)
        covered = covered_source_names(tree)
        violations = check2_rt_scan(label, tree, text, True, {"CONTROL"}, covered)
        results.append((label, not violations, violations))
    return results


# ---------------------------------------------------------------------------
# Standalone driver. The F.38 import below fires ONLY when this file is the
# main program. When F.38 itself executes this file (R22's re-run), the top
# level stays passive - the fresh module's __name__ is not "__main__" - so
# the import chain terminates after one hop.
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import importlib.util
    import sys

    spec = importlib.util.spec_from_file_location(
        "f38_live", HERE / "F38_claim_registry.py"
    )
    f38 = importlib.util.module_from_spec(spec)
    sys.modules["f38_live"] = f38
    spec.loader.exec_module(f38)  # Direction 1 + Direction 2 incl. the R22 gate
    reg = f38.REGISTRY

    sections = paper_sections(PAPER) if PAPER.exists() else None

    print("=== F.49 standalone sweep: Checks 1+2+4 over scripts ===")
    violations = hygiene_violations(reg, root=HERE)
    print("hygiene violations: %d" % len(violations))
    for v in violations:
        print("  " + v)

    print("=== F.49 standalone: Check 5 (domain cross-check) ===")
    dv = domain_violations(reg, root=HERE)
    print("domain violations: %d" % len(dv))
    for v in dv:
        print("  " + v)

    print("=== F.49 standalone: Check 3 over F.38's own provenance block ===")
    pv = provenance_violations(HERE / "F38_claim_registry.py", sections)
    print("F.38 provenance violations: %d" % len(pv))
    for v in pv:
        print("  " + v)

    print("=== provenance census ===")
    for line in provenance_census(reg, root=HERE):
        print("  " + line)

    print("=== mutant suite (8 mutants) ===")
    results = run_mutants(sections)
    for label, ok, vs in results:
        sigs = sorted({v.split(":")[2].split("(")[0].strip() for v in vs})
        print("%s: %s [%s]" % (label, "OK" if ok else "UNEXPECTED", ", ".join(sigs)))
        for v in vs:
            print("    " + v)
    print("=== passing controls ===")
    for label, ok, vs in run_controls():
        print("%s: %s" % (label, "OK" if ok else "UNEXPECTED"))
        for v in vs:
            print("    " + v)

    n_ok = sum(1 for _, ok, _ in results if ok)
    n_ctrl = sum(1 for _, ok, _ in run_controls() if ok)
    print("mutants: %d/8 as designed; controls: %d/%d clean"
          % (n_ok, n_ctrl, len(_CONTROLS)))
    if not PAPER.exists():
        print("F49 NOTE: Check 4 skipped (paper_11.md absent)")
    sys.exit(0 if (n_ok == 8 and n_ctrl == len(_CONTROLS)
                   and not violations and not dv and not pv) else 1)
