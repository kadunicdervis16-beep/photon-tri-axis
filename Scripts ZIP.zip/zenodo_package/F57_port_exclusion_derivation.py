#!/usr/bin/env python3
"""
F.57 — Port-Exclusion Derivation Attempt (DERIVATION, not verification).

Goal: prove or refute natively:
    NO port is consumed by two distinct completed junctions.
    Formally: ~exists p, j1 != j2: Consumes(j1,p) & Consumes(j2,p).

Method: proof by contradiction from NATIVE premises only.
Each inference step cites its exact native source. Any step needing a
premise outside the native list is flagged NON-NATIVE and the avenue
bottoms out there.

Native premise list (exact wording from the paper / cited papers):
  A1  (L411, Port Status binary):
      "At any tick, a port is open if the junction at that port is
       unresolved, and closed if the junction is resolved.
       Every port is exactly one of these two."
  A2  (Sec 6.1 bonding-mode premise) [Depends: Paper 2 Sec 11.1]:
      "Each bonding mode establishes a junction that consumes the open
       status of at least one port at each participating configuration."
  A3  (Sec 6.1 Lemma, Bonding Reduces Port Openness):
      "Establishing a junction at a port renders that port closed."
      Proof: "A port whose open status is consumed is no longer open;
      by the Port Status binary (Sec 4.3) every port is exactly one of
      open/closed, so it is closed."
  A4  (L429 / Sec 4.3, unresolved-port set):
      "dG = {(v,p) | p is not consumed by a completed interior junction}."
      Hence: consumed(p) -> p not in dG. (Consumed ports are closed;
      open ports are exactly the unconsumed ones.)
  A5  (Sec 4.1, Junction Arity):
      "For a completed junction j, the junction arity k_j is the number
       of ports consumed by j: k_j >= 2."
      P_j = {p : j consumed p}; |P_j| = k_j.
  A6  (Sec 4.1, Bonded Aggregate, junction individuation):
      "each junction in E exists if and only if a bonding mode of
       Paper 2 Sec 11.1 has completed it among two or more ports."
  A7  (Paper 6 Sec 3 — used ONLY as written):
      "The offset is a complete, indivisible ledger entry."
      "a quantized geometric deficit cannot bleed into a medium that
       cannot record it."
      Context (p.5): the "offset" is "the directional offset cut into
      [a mass configuration's] ledger", i.e. a quantized geometric
      deficit representing the configuration's motion/asymmetry.
      It is NOT stated to be a port's open status.
  A8  (Paper 5 Sec 2 — used ONLY as written):
      "A configuration is stable if and only if its inner identity
       scan can lock -- that is, if and only if its three center
       values present a single, unambiguous identity."
      "Closed means locked; locked means stable."
      (About three-position cores, not one-integer ports.)
  A9  (Paper 5 Sec 6 — used ONLY as written):
      "Bonds close when joints complete triplets; a joint with a
       remainder is an open search."
      (About joints/bonds, not port exclusivity.)

INPUT_PROVENANCE (F.49 regime):
  paper-defined : A1..A6 (Paper 11 native text, sections cited)
  cited-paper   : A7 (Paper 6 Sec 3), A8 (Paper 5 Sec 2), A9 (Paper 5 Sec 6)
  control       : none
  declared-assumption : none in this script (that is the point)
"""

from dataclasses import dataclass, field

# ---------------------------------------------------------------- proof trace

@dataclass
class Step:
    n: int
    claim: str
    basis: str          # native axiom id, or "NON-NATIVE: ..."
    native: bool = True

@dataclass
class AvenueResult:
    name: str
    steps: list = field(default_factory=list)
    verdict: str = ""        # "DERIVED" or "BOTTOMS OUT"
    bottom_at: str = ""      # step description if bottomed out
    missing: str = ""        # the exact missing premise

    def step(self, claim, basis, native=True):
        self.steps.append(Step(len(self.steps) + 1, claim, basis, native))
        return self

# ---------------------------------------------------------------- Avenue (a)
# The "taking" argument:
#   j1 consumed p's open status -> p closed -> j2 finds no open status.

def avenue_taking():
    r = AvenueResult("Avenue (a): the taking argument")
    r.step(
        "Assume for contradiction: p in P_j1 and p in P_j2, j1 != j2.",
        "assumption for reductio", True)
    r.step(
        "j1 consumed p  =>  j1's bonding mode consumed p's OPEN STATUS.",
        "A2 (Sec 6.1): bonding modes establish junctions 'by consuming "
        "the open status of ports'; A5: P_j = ports j consumed.", True)
    r.step(
        "A port whose open status is consumed is CLOSED.",
        "A3 (Sec 6.1 lemma): 'Establishing a junction at a port renders "
        "that port closed.'", True)
    r.step(
        "Hence after j1's consumption, p is closed; by A1, p is NOT open.",
        "A3 + A1 (binary: every port is exactly one of open/closed).", True)
    r.step(
        "j2 consumed p  =>  j2's bonding mode consumed p's OPEN STATUS.",
        "A2 + A5 (same as step 2, applied to j2).", True)
    # --- the critical step ---
    r.step(
        "j2's consumption requires p to HAVE open status at j2's tick; "
        "but p was closed (step 4), so p had no open status. Contradiction.",
        "NON-NATIVE: requires 'a port closed at tick t1 has no open status "
        "at tick t2' for t2 >= t1, i.e. a temporal persistence / "
        "no-reopening rule, OR requires t1 < t2 (ordered consumptions).",
        False)
    r.verdict = "BOTTOMS OUT"
    r.bottom_at = ("step 6: from 'p closed after j1' to 'p has no open status "
                   "when j2 consumes'")
    r.missing = (
        "No native premise orders the two consumptions in time, and no "
        "native premise states that a closed port cannot become open again "
        "(no-reopening rule).\n"
        "  - A1 defines status PER TICK ('At any tick, a port is open if...').\n"
        "  - Same-tick case: at tick t, p is open; j1 and j2 BOTH consume "
        "p's open status at t; after t, p is closed. A1-A6 are all satisfied: "
        "each consumption found open status (p was open at t), each "
        "rendered p closed (A3). No axiom is violated.\n"
        "  - Different-tick case (t1 < t2): needs 'closed at t1 => not open "
        "at t2'. A1 is per-tick and silent across ticks; A3 ('renders that "
        "port closed') states the post-consumption status, not permanence.\n"
        "  - The 5th-loop record already establishes: tick atomicity only "
        "eliminates within-tick ordering; it does not supply cross-tick "
        "persistence."
    )
    return r

# ---------------------------------------------------------------- Avenue (b)
# The ledger-indivisibility argument:
#   p's open status is a ledger entry -> indivisible -> cannot be split.

def avenue_ledger():
    r = AvenueResult("Avenue (b): ledger-indivisibility argument")
    r.step(
        "Assume for contradiction: p in P_j1 and p in P_j2, j1 != j2.",
        "assumption for reductio", True)
    r.step(
        "p's open status is a 'complete, indivisible ledger entry' "
        "(so it cannot be split between j1 and j2).",
        "NON-NATIVE: TYPE MISMATCH. A7 (Paper 6 Sec 3) states indivisibility "
        "of 'the offset' = 'the directional offset cut into [a mass "
        "configuration's] ledger', i.e. a quantized geometric deficit "
        "representing the configuration's motion/asymmetry (Newton's-first-"
        "law context, p.5). No native sentence identifies 'a port's open "
        "status' with Paper 6's 'offset' or 'quantized geometric deficit'. "
        "Paper 11's Declared Constraint ASSERTS this identification, but "
        "assertion is not derivation.",
        False)
    r.verdict = "BOTTOMS OUT"
    r.bottom_at = ("step 2: identifying 'p's open status' with Paper 6's "
                   "'offset / quantized geometric deficit'")
    r.missing = (
        "A native bridging premise of the form: 'a port's open status is "
        "an offset (Paper 6 sense)' or 'a port's open status is a quantized "
        "geometric deficit'.\n"
        "  - A7's 'cannot bleed' is about a motion-offset vs. the baseline "
        "medium ('cannot bleed into a medium that cannot record it'), not "
        "about two junctions sharing one port.\n"
        "  - Even granted the identification, 'indivisible' would need the "
        "further reading 'cannot be consumed by two junctions' — A7 says "
        "'transferred in full', which is about transfer, not consumption "
        "exclusivity.\n"
        "  - Dervis's instruction ('because of the ledger') authorizes the "
        "DECLARED constraint; it does not supply the missing native bridge."
    )
    return r

# ---------------------------------------------------------------- Avenue (c)
# The Sec 4.1 iff argument:
#   does junction-individuation already forbid shared ports?

def avenue_iff():
    r = AvenueResult("Avenue (c): Sec 4.1 individuation-iff argument")
    r.step(
        "Assume for contradiction: p in P_j1 and p in P_j2, j1 != j2.",
        "assumption for reductio", True)
    r.step(
        "By A6, j1 exists iff a bonding mode completed j1 'among two or "
        "more ports'; likewise j2.",
        "A6 (Sec 4.1): 'each junction in E exists if and only if a bonding "
        "mode ... has completed it among two or more ports.'", True)
    r.step(
        "Both j1 and j2 satisfy the iff (each was completed by a bonding "
        "mode). The iff constrains junction EXISTENCE, not port "
        "exclusivity: nothing in A6 forbids two distinct completed "
        "junctions from sharing a port.",
        "A6 (read exactly: the biconditional is over existence/completion, "
        "with no uniqueness clause over ports).", True)
    r.step(
        "By A5, k_j counts 'the number of ports consumed by j'. If p is "
        "consumed by both, p counts toward both k_j1 and k_j2. A5 does not "
        "forbid double counting across junctions.",
        "A5 (Sec 4.1 arity definition: a count, not an exclusivity rule).",
        True)
    r.verdict = "BOTTOMS OUT"
    r.bottom_at = ("step 3: the iff yields no contradiction — it is "
                   "satisfied by the assumed configuration")
    r.missing = (
        "A native premise of the form: 'no port belongs to two junctions' "
        "or 'P_j are pairwise disjoint' stated as a DEFINITION (not as the "
        "lemma under proof).\n"
        "  - A6's iff would need an additional clause such as '...completed "
        "it among two or more ports, no port shared between distinct "
        "junctions' — absent.\n"
        "  - Note: the 1st-loop 'single-event dissolution' attempt tried to "
        "read exclusivity into individuation and was HELD (it contradicted "
        "the iff: two completing modes = two junctions)."
    )
    return r

# ---------------------------------------------------------------- driver

def main():
    print("=" * 70)
    print("F.57 — PORT-EXCLUSION DERIVATION ATTEMPT")
    print("Target: ~exists p, j1 != j2: p in P_j1 and p in P_j2")
    print("Method: reductio from NATIVE premises only.")
    print("=" * 70)
    results = [avenue_taking(), avenue_ledger(), avenue_iff()]
    derived = 0
    for r in results:
        print()
        print("-" * 70)
        print(r.name)
        print("-" * 70)
        for s in r.steps:
            tag = "[native]" if s.native else "[NON-NATIVE]"
            print(f"  {s.n}. {tag} {s.claim}")
            print(f"       basis: {s.basis}")
        print(f"  => VERDICT: {r.verdict}")
        if r.verdict == "DERIVED":
            derived += 1
        else:
            print(f"  BOTTOMS OUT AT: {r.bottom_at}")
            print(f"  MISSING PREMISE:\n    " +
                  r.missing.replace("\n", "\n    "))
    print()
    print("=" * 70)
    if derived == len(results):
        print("OVERALL: DERIVED")
    elif derived > 0:
        print(f"OVERALL: PARTIAL ({derived}/{len(results)} avenues derived)")
    else:
        print("OVERALL: BOTTOMS OUT — port exclusion does NOT follow from "
              "the native premises.")
        print()
        print("Native-vs-nonnative boundary:")
        print("  (a) taking argument: needs cross-tick persistence of "
              "'closed' or an ordering of consumptions — not native")
        print("       (A1 is per-tick; same-tick double consumption violates "
              "no axiom).")
        print("  (b) ledger argument: needs 'port open-status = Paper 6 "
              "offset/deficit' bridge — not native (A7 is about motion).")
        print("  (c) iff argument: A6 governs existence, not exclusivity — "
              "no contradiction derivable.")
        print()
        print("Honest null result: the Declared Structural Constraint "
              "(Port Exclusion, Sec 6.1) cannot be replaced by a derived "
              "theorem on the current native basis. Dervis's authorization "
              "of the declaration stands as the honest basis, per his "
              "2026-10-07 instruction.")
    print("=" * 70)

if __name__ == "__main__":
    main()
