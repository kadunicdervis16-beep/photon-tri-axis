# Paper 11 — Verification Scripts

**Departure From the Photon Baseline: Paper 11 — Simple States and Complex Configurations**
By Dervis Kadunic — v69 (2026-10-07)

## Contents

28 verification scripts (F.32–F.57) plus F.46's two draft-root dependencies.

| Script | Purpose |
|--------|---------|
| F32_gate.py | Bonded-aggregate domain certification |
| F32_simple_state.py | Simple-state structural checks |
| F33_aggregate_a.py | Aggregate (a) s² decomposition |
| F33_check2_probes.py | Aggregate (a) mutant probes |
| F34_aggregate_b.py | Aggregate (b) s² decomposition |
| F35_aggregate_c.py | Aggregate (c) s² decomposition |
| F36_interaction_taxonomy.py | Residue model for §8.6 taxonomy |
| F37_complexity_ordering.py | Complexity ordering from unordered records |
| F38_claim_registry.py | Claim registry verifier (57 claims, R1–R23) |
| F39_relational_role.py | Relational role theorem witness |
| F40_aspect_inventory.py | Aspect inventory exhaustiveness |
| F41_single_regime.py | Single-regime proof |
| F42_stageN_firewall.py | Stage-N vocabulary firewall (24 sweep groups) |
| F43_shove_transition.py | Shove transition operator checks |
| F44_tracking_cost.py | Tracking-cost lemma (port-level) |
| F45_proximity_scaling.py | Proximity shell profile |
| F46_caseA_ladder.py | Case-A ladder first-encounter check |
| F47_engagement_separation.py | Engagement–alteration separation |
| F48_consolidation_paths.py | Consolidation path counting |
| F49_verification_hygiene.py | Verification hygiene gate (INPUT_PROVENANCE, round-trip) |
| F50_port_partition_status.py | Port partition status checks |
| F51_registry_e2_drift.py | Registry ↔ E.2 drift detection |
| F52_theorem_map.py | Theorem-map (Appendix J) generator |
| F53_caseB_two_regime.py | Case-B two-regime audit |
| F54_proof_registry_crosscheck.py | Proof↔registry crosscheck (staged) |
| F55_alignment_correspondence.py | Alignment correspondence (staged) |
| F56_scale_fidelity.py | Scale-fidelity N-threshold sweep |
| F57_port_exclusion_derivation.py | Port-exclusion derivation record (null result) |

**Dependencies:** `v14_blitz_f46_categorical.py` and `v14_f46_caseA_ladder.py` are
F.46's draft-root dependencies, embedded as listings in the paper and SHA256-pinned
in `draft_root_dependency_manifest.txt`. They are included here as independent files.

## Running

All scripts are self-contained Python 3 (standard library only, plus fellow scripts
in this directory). Each script exits 0 on success and prints its verdicts.

```bash
python3 F38_claim_registry.py   # registry verifier
python3 F42_stageN_firewall.py # vocabulary firewall
```

## License & Citation

© 2026 Dervis Kadunic. Part of the *Departure From the Photon Baseline* series.
Cite as: Kadunic, D. (2026). Paper 11: Simple States and Complex Configurations —
The Active and Passive Roles in Resolution-Seeking. v69.
