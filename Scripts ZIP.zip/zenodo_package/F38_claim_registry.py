
INPUT_PROVENANCE = {
    "AGG_PAT": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "AGG_REDUCTIONS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "ASPECT_INVENTORY": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "DEFERRED": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "DERIVED": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "DIM_WORDS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "FORBIDDEN_NATIVE": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "HERE": {"class": "control", "note": "script directory path (not an input)"},
    "LEVELS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "LINEAGE_KINDS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "P11_TERMS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "PRIMITIVE": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "R19_OBJECT_PHRASES": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "REGISTRY": {"class": "paper-defined", "source": "Appendix E (claim-graph registry table)"},
    "ROLE_CUT_DEFINITIONAL": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "SCALE_TOKENS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "TOKENS": {"class": "control", "note": "rule table / audit constant (not an input)"},
    "_INHERITED_SOURCE_RE": {"class": "control", "note": "R3 inherited-source section-specificity citation shape (not an input)"},
    "_LAB_NOTE_RE": {"class": "control", "note": "R3 lab-note citation ban shape (not an input)"},
    "_R21_SUBJECTS": {"class": "control", "note": "R21 subject-term table / audit constant (not an input)"},
    "_R3_BANNER_CACHE": {"class": "control", "note": "R3 pointer-topicality banner-text cache (not an input)"},
    "_R3_POINTER_STOPWORDS": {"class": "control", "note": "R3 pointer-topicality stopword table / audit constant (not an input)"},
    "_diag_claim": {"class": "control", "note": "labeled-diagnostic synthetic claim tokens (not an input; passes by design)"},
    "_diag_banner": {"class": "control", "note": "labeled-diagnostic synthetic well-worded-but-wrong banner tokens (not an input; passes by design)"},
    "rejected": {"class": "control", "note": "planted-test rejection counter"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's checks
# exercise. F.38 audits the registry's own bookkeeping; it quantifies over
# no aspect kinds (BRIDGE_LEDGER_P11: "imports and exports audited").
DOMAIN = {
    "proved": [],
    "notes": "registry machinery: no aspect kinds exercised; backs "
             "BRIDGE_LEDGER_P11 with an empty domain, honestly.",
}
#!/usr/bin/env python3
"""Paper 11 - F.38: claim-graph and bridge-ledger registry audit (rules R1-R23).

Direction 1: the clean registry must pass every rule.
Direction 2: thirty-seven planted test classes must all be rejected. A planted
test case that passes undetected voids the
verification (not the theorems - the verification).

Rule set: R1-R8 formalize the bridge-ledger design of Paper 10.5 Appendix H
(cf. F.31's ten planted-breach classes R1-R10); R9-R23 new in Paper 11:
R9-R12 new in Paper 11; R13 new in v3; R14 new in v4; R15 new in v5; R16 new in v6;
R22 new in v17/P2 (F.49 verification-hygiene gate); R23 new in 2026-10-05
(quantified-domain coverage: a script-lineage Level-A claim's claimed aspect
kinds must be proved by its backing script(s) or admitted by a valid
coverage map -- the never-again gate for the F.44 defect class).
R21 new in v21.
R19 new in v14; R20 new in v15. R12 is refined relative to the v1 draft: it flags
whole-configuration identity patterns ("simple states are passive" /
"complex configurations are active"). R21 (new in v21) extends the
detector to aspect- and part-level intrinsic role assignments
("complex boundary ports are active", "every boundary port is
intrinsically active"): under the relational role theorem, even
aspect-level roles are encounter-relative; the paper's legitimate
per-aspect content is the seeking/resolved standing-state partition
(§6.2), encounter-indexed role claims, and modal-attachment language.
R21 is tightened relative to its first cut: subject terms are
word-bounded (bare "boundary" included); a subject-free "plays the *
role" trigger is added; encounter indexing requires a word-boundary
"encounter" or "in R"; modal attachment is admitted only in
capability-marked modal forms ("can play the * role", "is capable of
playing/being the *", "is eligible for the *"); "seeking" stays an
admitted standing-state term as a whole word. The old and new verdict
functions are kept side by side (_r21_old_verdict/_r21_new_verdict) so
the tightening stays mechanically re-verifiable.

v3 change: L5-P11 is demoted from axiom to derived theorem (the relational
role theorem); L6-P11/L7-P11 are definitions. AXIOMS is partitioned into
PRIMITIVE (Papers 1-10) and DERIVED (Paper 11 definitions/theorem, each with
a recorded derivation). R11 now requires the operational definitions
(L7-P11) rather than the old axiom label. R13 requires every cited derived
label to have its derivation registered and rejects unregistered labels.

version 11 change: R18 makes the derivation records machine-checked, not just
recorded. Every DERIVED entry carries derives_from (exact label set),
section (must be a real heading in paper_11.md), and script (must exist).
The transitive closure of derives_from must bottom out in PRIMITIVE and be
acyclic; theorem-kind labels must have non-empty derives_from. Five planted
test classes cover the failure modes; the self-test now runs 21 classes.

v4 change: R14 requires every aspect cited in a claim to resolve to the
four-kind inventory of §4.2 (port / junction / node / whole). Claims whose
text mentions "aspect" must declare their selector kinds; any kind outside
the inventory (a free-floating aspect) is rejected as a hidden primitive.
The defined-token table is audited alongside: "aspect" is NOT_A_PRIMITIVE
and derives only from L1, L2, and the Paper-2 bonding modes.

v14 change: R19 makes the boundary-as-object prohibition registry-level.
No claim's text may reify the boundary into an object, substance, or
primitive; boundary language in a claim text must resolve to the defined
senses (the Aggregate Boundary set of §4.3, boundary ports as open ports,
the B = 6N − 2J count). One new planted test class; the self-test now
runs 22 classes.

v15 change: R20 makes resolution-status integrity registry-level.
"resolution status" is a defined token: exactly the third F.37
ordering-key component, integer-valued, native domain exactly {0,1},
meaning supplied only by the finite §12 classification - not
observer-assigned, not a scalar degree, not an independent ledger
quantity, not a physical primitive. One new planted test class; the
self-test now runs 23 classes.

v21 change: R21 makes the relational role theorem registry-level. No
claim's text may assign the active/passive roles intrinsically - to a
whole configuration or to an aspect/part - outside an
encounter-indexed formulation ("in R", "encounter") or
capacity/seeking language ("seeking", "capable", "eligible",
"can play"). Bare "X are active/passive" over parts, and
"intrinsically active/passive", are rejected. One new planted test
class; the self-test now runs 24 classes.

v31 change: new derived labels L8-P11 (engagement predicate) and L9-P11
(alteration predicate), new REGISTRY claim ENGAGEMENT_ALTERATION_SEPARATION
(Level A, script F47_engagement_separation), new defined tokens
"engagement"/"alteration". The R13 planted test's unregistered-label
specimen is re-pointed from L9-P11 to L10-P11 (L9-P11 is now registered;
the plant must remain a genuine unregistered-label violation).

v27 change: lineage categories. Every claim now carries a "lineage" field
with exactly one of three values: "script" (a machine check exists and is
named), "inherited" (the claim's content is inherited from a prior paper,
named in "inherited_from"), or "prose" (the claim is established by a
definitional proof in the paper, named in "section"). R3 is now the
honest-basis rule: a "script" claim must name an existing script file; an
"inherited"/"prose" claim must name its source and must NOT carry a script
pointer. An inherited source must be section-specific ("Paper N §M(.K)"
in every semicolon-separated chunk) so the badge's basis resolves to a
locatable passage. Pointing a claim at a script that does not check its content is a
misassignment, not a verification. Script pointers use exact filename stems
(e.g. "F39_relational_role"). Re-pointings: PROXIMITY_SCALING -> F.45,
RESOLUTION_VERB/SHOVE_DIRECTION -> F.43, AGGREGATE_B_DECOMPOSITION -> F.34,
ROLE_CUT_INDEPENDENCE/SIMPLE_STATE_REFERENCE_ROLE -> F.39,
COMPLEX_BOUNDARY_ACTIVE and COMPOUND_CLOSED_LOOP_COHERENCE split into port
half (F.33) + role half (F.39). DUAL_RESPONSE_MODES drops the F.34 pointer:
no script checks the two-channel conclusion, so its basis is the
definitional §6.3 derivation from L6-P11/L7-P11. FALSIFICATION_C19_C22 is
split per condition: C21 -> F.39, C22 -> F.33-F.35, C19/C20 recorded as
observationally falsifiable (Level C). PORT_COUNT_INVARIANCE is inherited
(Paper 10 §2.4.1) and SIMPLE_STATE_INSULATION is inherited (Paper 2 §1).
Six orphaned Level-A items are registered with honest bases: PHOTON_BASELINE
(inherited: Paper 2 §5, Paper 10 §2.1), ROLE_PERMANENCE_PROHIBITION (prose
§3.3), BOUNDARY_PORT_CHARACTERIZATION (prose §4.3),
SIMPLE_STATE_ENUMERATION (F.32's 27-enumeration), ASPECT_INVENTORY (F.40),
SINGLE_REGIME (F.41). TRACKING_COST_LEMMA records Paper 8 §2 as the content
source with F.44 checking the composition.

R3 pointer-topicality: R3's honest-basis rule was named but never
enforced -- "pointing at a script that does not check the claim's content is
a misassignment, not a verification" -- while the machine checked only that
the named file exists. This rule extends R3: for every "script"-lineage
claim, each pointed script's self-description (module banner strings) must
share a significant token with the claim id or claim text, or name the
claim's paper section. KNOWN-SHAPE LIMITATION, stated plainly: this is a
topicality comparison between the claim's identity tokens and the
script's own description of what it checks -- hence "topicality", not
"semantics". It catches gross misassignment -- a pointer at an existing
script whose description never mentions the claim (the CASE_B_COLLIDER
shape) -- not subtle coverage gaps, and it cannot see a banner that
overclaims what the code does: a well-worded-but-wrong banner (topic
mentioned, content unchecked) passes this rule by design, and banner
fidelity stays human-audit territory (a labeled diagnostic in Direction 2
demonstrates the boundary). Boilerplate
tokens ("paper", "machine", "check", "claim", "registry", ...) never
constitute a reference. Three new planted classes cover the misassignment
shape (single repoint, multi-script list with one unrelated member, and a
distinct claim/script pair as the anti-round-trip mutant); the converse is
pinned by asserting the exact flagged set on the real registry.

v50 change: new derived label L10-P11 (encounter geometry, definition,
§3.2; derives_from [L2, L3, L8-P11]; script F47_engagement_separation.py),
new REGISTRY claim ENCOUNTER_GEOMETRY_DEFINITION (Level A, prose lineage
§3.2), new defined token "encounter geometry", the "engagement" token's
definition re-worded to cite the §3.2 definition and its derived_from
gaining L10-P11, and L10-P11 added to the axioms of the 17 Level-A claims
whose paper proofs load the encounter-geometry relation (R-tuple
colocation / §8.5 shells / §8.6 selection / engagement): the certainty
case ENGAGEMENT_ALTERATION_SEPARATION, plus RELATIONAL_ROLE_THEOREM,
CAPABILITY_ACTUALITY_SEPARATION, ROLE_PERMANENCE_PROHIBITION (§3.3 proof
names encounter geometry explicitly), COMPLEX_BOUNDARY_ACTIVE,
COMPOUND_CLOSED_LOOP_COHERENCE, SIMPLE_STATE_REFERENCE_ROLE,
INTERACTION_TAXONOMY, SATURATION_FUSE, ENCOUNTER_TENSION_ANALYSIS,
PROXIMITY_SCALING, PROXIMITY_SHELL_PROFILE,
CONSUMPTION_CONSTRUCTION_ROBUSTNESS, TH_INDEPENDENCE,
DOMAIN_GUARD_DISJUNCTION, CROSS_NUCLEUS_ROBUSTNESS, FALSIFICATION_C21.
Excluded after reading each proof: DUAL_RESPONSE_MODES (§6.3's "engaged"
is the standing seeking state, explicitly glossed as NOT the tick-indexed
predicate), SHOVE_TRANSITION_OPERATOR (the operator acts on junction
states σ; the R-indexing is application context, not proof load), the
aggregate decompositions and consolidation-path claims (finite
combinatorics; §8.6-taxonomy load enters via deps), and all Level-B/C
claims (out of scope). The R13 and R18 planted specimens are re-pointed
from L10-P11 to L11-P11 (L10-P11 is now registered; the plants must remain
genuine violations), same convention as v31's L9→L10 re-point. Registry
moves 51 → 52 claims (A44/B4/C3 → A45/B4/C3); the 28 planted classes are
unchanged in count.

2026-10-04: R3 inherited-source specificity. Any carried inherited_from
must match "Paper N §M(.K)" in every semicolon-separated chunk (a
sectionless "Paper 10" or an emptied source is rejected; the live
multi-source "Paper 2 §5; Paper 10 §2.1" passes). Two new planted
classes; battery 28 → 30.

2026-10-04: R3 lab-note ban + basis completeness; new registry claim
TRIPLE_CONVERGENCE_RESOLUTION (ChatGPT HIGH claim "binary transition
operator vs non-binary junctions": INHERIT, not invent — the
triple-convergence transformation from Paper 2 §8.1/§11.1 and Paper 3
§7/§8.5; Level A, lineage inherited, axioms [L1], deps [],
stated at §7.6; no Paper-11 script pointer). Registry 53 → 54 claims
(A46/B4/C3 → A47/B4/C3). R3 gains two sub-rules: (a) lab-note ban — lab
notes are never a valid inherited basis (deleted relic, never cited); a
parenthetical smuggle ("Paper 3 §8.5 (lab notes)") passes the
section-specificity .search() shape, so the ban is a separate rule;
(b) basis completeness — a multi-source inherited basis must not
silently narrow: the complete cited set is pinned from the pristine
registry (derived, never hardcoded per claim) and a strict subset is
rejected with an ID-naming witness. Two new planted classes (dropped
source token; lab-note citation smuggle); battery 30 → 32.
2026-10-04 (loop repair): R3 lab-note ban gains a text-field arm (a
"per the lab notes" sentence inside a claim's text cell evaded the
inherited-source arm) and the underscore spelling ("lab_note") joins
the banned char class. One new planted class (lab-note string in a
text field, underscore spelling); battery 32 → 33.
"""
import ast
import re
import shutil
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER_MD = (HERE.parent / "paper_11.md").read_text(encoding="utf-8")

PRIMITIVE = {"L1", "L2", "L3", "L4", "PTR", "BUDGET", "DSC", "S3"}
# R18 (version 11): every derived label carries a machine-checked derivation
# record. derives_from is the exact label set the derivation may use
# (the §3.1 heading states L5-P11's closure in prose as
# "depends L1·L2·PTR·BUDGET·L7-P11·L10-P11·tick" — tick is the Stage-N event
# serialization the proof runs over, not a premise label, so it is not
# a derives_from entry); section must be a real section heading in
# paper_11.md; script must be an existing verification script. The
# transitive closure of derives_from must bottom out in PRIMITIVE and be
# acyclic — a derived label that cannot be resolved to primitives is an
# axiom in disguise (the v1 sin: L5 signed as an axiom).
DERIVED = {
    "L5-P11": {"kind": "theorem", "name": "RELATIONAL_ROLE_THEOREM",
               "section": "§3.1",
               "derives_from": ["L1", "L2", "PTR", "BUDGET"],
               "script": "F39_relational_role.py"},
    "L6-P11": {"kind": "definition", "name": "structural cut",
               "section": "§4.1",
               "derives_from": ["L1", "L2"],
               "script": "F32_simple_state.py"},
    "L7-P11": {"kind": "definition", "name": "operational role cut",
               "section": "§4.2",
               "derives_from": ["L1", "L2", "L6-P11"],
               "script": "F36_interaction_taxonomy.py"},
    # v31: engagement / alteration predicates (§4.6). The Paper-2 §11.1
    # bonding modes are not AXIOM labels (P2-BONDING lives in
    # DERIVATION_SOURCES); L9's derivation runs through L6-P11's §4.1
    # record, the same way L7-P11's F.36 script pointer covers content L7
    # does not re-derive.
    "L8-P11": {"kind": "definition", "name": "engagement predicate",
               "section": "§4.6",
               "derives_from": ["L2", "L5-P11", "L6-P11", "L7-P11"],
               "script": "F47_engagement_separation.py"},
    "L9-P11": {"kind": "definition", "name": "alteration predicate",
               "section": "§4.6",
               "derives_from": ["L1", "L2", "L6-P11"],
               "script": "F47_engagement_separation.py"},
    # v50: encounter-geometry definition (§3.2, L10-P11). The genus is
    # unified by its role as the encounter-geometry conjunct of the §4.6
    # engagement definiens, hence the L8-P11 derivation citation (a
    # forward reference, discharged where L8 is defined at §4.6); L2
    # (ports) and L3 (taxicab relay-hop distance) supply the remaining
    # defined terms. No cycle: L8-P11 derives from L2/L5/L6/L7, none of
    # which is L10-P11. R18 section check: "§3.2" matches the real
    # "### §3.2 The Photon Baseline as Universal Ruler ..." heading;
    # script F47_engagement_separation.py exists.
    "L10-P11": {"kind": "definition", "name": "encounter geometry",
                "section": "§3.2",
                "derives_from": ["L2", "L3", "L8-P11"],
                "script": "F47_engagement_separation.py"},
    # Registration of the §4.1 Structural Insulation Theorem (authorized
    # 2026-10-01; F.54 REGISTRY_INCOMPETENESS finding). The theorem is a
    # theorem of the §4.1 structural content: its proof leans on L6-P11's
    # nine-position matrix/loop internal geometry plus inherited Paper 2
    # §1 (the identity scan at every tick) and Paper 2 §11.1 (the bonding
    # modes behind "shared junction"). Paper-2 content is not an AXIOM
    # label (P2-BONDING lives in DERIVATION_SOURCES; cf. the L8/L9
    # comment), so derives_from names only the Paper-11 label; the
    # inherited premises are recorded on the registry claim. No script
    # pointer: no script checks the insulation theorem's content — F.47
    # leans on it (the ¬(ii) disjunct) but does not check it, and pointing
    # at F.47 would be the v10 misassignment (an adjacent check). The
    # basis is the §4.1 definitional proof, honestly labeled. R18 section
    # check: "§4.1" matches the real "### §4.1 ..." heading.
    "L12-P11": {"kind": "theorem", "name": "structural insulation",
                "section": "§4.1",
                "derives_from": ["L6-P11"],
                "script": ""},
}
AXIOMS = PRIMITIVE | set(DERIVED)
DEFERRED = {"P12", "P13", "P14", "P15", "P16", "P23", "P24"}
LEVELS = {"A", "B", "C"}
# v27: honest-basis lineage for every claim. "script" = a machine check
# exists and is named in the claim's "script" field (a string, or a list
# of strings when the claim's content splits across checks, e.g. a port
# half and a role half). "inherited" = the claim's content is inherited
# from a prior paper, named in "inherited_from"; no script pointer.
# "prose" = the claim is established by a definitional proof in the
# paper, named in "section"; no script pointer.
LINEAGE_KINDS = {"script", "inherited", "prose"}
# R3 inherited-source specificity: a named inherited source must be
# section-specific -- "Paper N §M(.K)" in every semicolon-separated chunk --
# so the badge's basis resolves to a locatable passage, not a whole paper.
_INHERITED_SOURCE_RE = re.compile(r"Paper \d+ §[\d.]+")
# R3 lab-note ban (2026-10-04): lab notes are never a valid inherited
# basis (deleted relic — never cited). The specificity shape above is a
# .search(), so a parenthetical smuggle ("Paper 3 §8.5 (lab notes)")
# passes it; the ban is a separate rule. The underscore form ("lab_note")
# evaded the old char class; the text-field arm catches "per the lab
# notes" sentences inside claim text cells.
_LAB_NOTE_RE = re.compile(r"lab[\s\-_]?notes?", re.I)
# R3 pointer-topicality: stopword table for the claim/banner
# keyword comparison. Two groups: plain English function words, and corpus
# boilerplate -- words true of nearly every banner and many claim texts
# ("paper", "machine", "check", "claim", "registry", "section", "level",
# "audit", "rule", "verification", ...). A pointer whose only shared
# tokens are boilerplate is not a reference; the table makes that a
# mechanical rule rather than a judgment call. The table is generic: it
# names no claim, no script, and no expected verdict.
_R3_POINTER_STOPWORDS = frozenset({
    "the", "a", "an", "of", "and", "or", "in", "on", "to", "for", "is",
    "are", "by", "with", "at", "as", "from", "that", "this", "it", "its",
    "be", "not", "no", "does", "do", "than", "into", "over", "under",
    "all", "any", "each", "both", "between", "among", "within", "without",
    "when", "where", "which", "what", "how", "can", "cannot", "will",
    "would", "should", "could", "may", "might", "must", "shall", "have",
    "has", "had", "having", "been", "being", "was", "were", "if", "else",
    "such", "only", "also", "just", "more", "most", "other", "some",
    "these", "those", "their", "there", "here", "out", "about", "after",
    "before", "during", "above", "below", "once", "two", "one", "three",
    "first", "second", "new", "old", "own", "same", "too", "very", "well",
    "much", "many", "few", "nor", "but", "yet", "so", "up", "down", "off",
    "again", "further", "per", "via", "then",
    "paper", "machine", "script", "scripts", "check", "checks", "checked",
    "checking", "claim", "claims", "registry", "section", "sections",
    "level", "levels", "audit", "audited", "rule", "rules", "theorem",
    "definition", "proof", "verified", "verifies", "verify",
    "verification", "proves", "stated", "states", "given", "using", "used",
    "use", "uses", "based", "part", "half", "content", "work", "worked",
    "exactly", "exact",
})
# Banner-text cache: stem -> the script's self-description. Scripts on disk
# never change during a run (poisoned registries mutate the registry, not
# the files), so caching across check() calls is sound.
_R3_BANNER_CACHE = {}
FORBIDDEN_NATIVE = {"metric", "tensor", "field", "curvature", "manifold",
                    "vacuum", "geodesic", "integral", "continuum"}
P11_TERMS = {"active", "passive", "simple", "complex", "role", "aspect",
             "resolution", "port", "boundary", "interior"}
ROLE_CUT_DEFINITIONAL = {"ROLE_CUT_INDEPENDENCE"}

# MACHINERY-START: R19 object-positing phrase list (v14).
# The phrases below are the rule's own patterns, never claim content.
R19_OBJECT_PHRASES = [
    "boundary is a positive", "boundary as a positive",
    "boundary substance", "boundary is an entity",
    "boundary membrane", "boundary container",
    "positive boundary object", "the boundary acts",
    "boundary exerts",
]
# MACHINERY-END

# MACHINERY-START: R20 resolution-status token metadata (v15).
# The metadata below audits the "resolution status" defined token; it is the
# rule's own machinery, never claim content.
# MACHINERY-END

# R14 (v4): the aspect inventory of §4.2. Every aspect cited in a claim must
# resolve to one of these four selector kinds. Anything else is a
# free-floating aspect — a hidden primitive.
ASPECT_INVENTORY = {"port", "junction", "node", "whole"}

# R14 (v4): defined-token table. "aspect" is NOT a primitive; it is derived
# from L1 (configurations, nodes), L2 (relay ports), and the Paper-2 bonding
# modes (junctions). The derivation sources must stay inside the primitive
# set plus the bonding modes — no new ontology.
DERIVATION_SOURCES = PRIMITIVE | {"P2-BONDING"}
TOKENS = {
    "aspect": {
        "definition": "(C, s): C a configuration, "
                      "s in Ports(C) | Junctions(C) | Nodes(C) | {C}",
        "not_a_primitive": True,
        "derived_from": {"L1", "L2", "P2-BONDING"},
    },
    # R20 (v15): "resolution status" is a defined token, not a primitive. It
    # is exactly the third F.37 ordering-key component, integer-valued, with
    # native domain exactly {0, 1}. Its meaning is supplied only by the
    # finite §12 class definition: not observer-assigned, not a scalar
    # degree, not an independent ledger quantity, not a physical primitive.
    "resolution status": {
        "definition": "third F.37 ordering-key component (index 3), "
                      "finite §12 class marker",
        "not_a_primitive": True,
        "derived_from": {"§12-CLASSIFICATION", "F.37"},
        "ordering_component": 3,
        "integer_valued": True,
        "domain": {0, 1},
        "definition_source": "finite §12 classification",
        "observer_assigned": False,
        "scalar_degree": False,
        "independent_ledger_quantity": False,
        "physical_primitive": False,
    },
    # v31: engagement / alteration are predicates over existing structure
    # (§4.6), not primitives.
    "engagement": {
        "definition": "predicate E(A->B, tau): A and B in encounter geometry "
                      "(§3.2, L10-P11) at tick tau, A presenting at least one "
                      "non-O boundary port toward B (§8.6 domain guard; §4.6)",
        "not_a_primitive": True,
        "derived_from": {"L2", "L5-P11", "L6-P11", "L7-P11", "L10-P11"},
    },
    "alteration": {
        "definition": "predicate Alteration(C, tau): (i) port-status change "
                      "open->closed by a completed Paper 2 §11.1 bonding-mode "
                      "junction (§4.1, §6.1), or (ii) nine-position rewrite by "
                      "direct geometric occlusion (§4.1)",
        "not_a_primitive": True,
        "derived_from": {"L1", "L2", "L6-P11"},
    },
    # v50: "encounter geometry" is a defined token, not a primitive. It is
    # the L10-P11 disjunctive genus (§3.2): the port-pair disjunct (a §3.2
    # resolution relationship R = (a,p,b,q,tau) with a an aspect of X, b an
    # aspect of Y) or the shell disjunct (d >= 1 the least relay-hop shell
    # at which Y presents a port to X's scan at tau — the §8.5 engagement
    # shell); undirected iff >=1 direction holds; tick-free uses name the
    # tau-abstracted admissibility relation (Level B reading gloss). The
    # d >= 1 bound is contingent on the parked §8.5 d>=1 ruling; the
    # disjunct-(i) naming is contingent on the parked tier-(i) wording
    # ruling. Like every defined token it derives only from registered
    # labels — no new ontology.
    "encounter geometry": {
        "definition": "X, Y occupy encounter geometry at tick tau (X->Y) iff "
                      "(i) some §3.2 R = (a,p,b,q,tau) with a an aspect of X, "
                      "b an aspect of Y (encounter distance = ambient L3 "
                      "relay-hop distance, a defined quantity), or (ii) d >= 1 "
                      "is the least shell at which Y presents a port to X's "
                      "scan at tau (§8.5 engagement shell); undirected iff "
                      ">=1 direction holds; d >= 1 contingent on the parked "
                      "§8.5 d>=1 ruling, disjunct-(i) naming contingent on "
                      "the parked tier-(i) wording ruling",
        "not_a_primitive": True,
        "derived_from": {"L2", "L3", "L8-P11"},
    },
    # v32: §11.2 consolidation-path vocabulary (Vulnerability-16
    # remediation). Finite-sequence data over already-defined ports;
    # no new primitives, no new native quantities.
    "consolidation path": {
        "definition": "finite non-empty sequence of pairwise "
                      "junction-completion events over candidate contacts "
                      "of (G, E), no port reused (§6.1 closure); each event "
                      "strictly reduces the unmatched-integer count",
        "not_a_primitive": True,
        "derived_from": {"L6-P11"},
    },
    "candidate contact": {
        "definition": "pair (p, q) with p in the aggregate's boundary port "
                      "set, q in the environment E, values complementary "
                      "X<->Y (O pairs with nothing; §8.6 taxonomy)",
        "not_a_primitive": True,
        "derived_from": {"L6-P11"},
    },
    "path set": {
        "definition": "P(G;E): the set of all consolidation paths of G in "
                      "environment E; environment-relative, not intrinsic "
                      "to G",
        "not_a_primitive": True,
        "derived_from": {"L6-P11"},
    },
    "boundary-extension": {
        "definition": "G2 boundary-extends G1 relative to fixed E iff an "
                      "injection iota maps each boundary port of G1 to a "
                      "distinct boundary port of G2 carrying the same "
                      "categorical value",
        "not_a_primitive": True,
        "derived_from": {"L6-P11"},
    },
}


def r20_resolution_status_check():
    """R20 (v15): resolution-status token integrity. The audited metadata of
    the 'resolution status' defined token must keep it a discrete class
    marker: third ordering-key component, integer-valued, domain exactly
    {0, 1}, defined only by the finite §12 classification. Any drift - a
    scalar domain, an observer assignment, a physical-primitive claim - is
    a defect."""
    v = []
    meta = TOKENS.get("resolution status")
    if meta is None:
        v.append("R20: 'resolution status' token missing from defined-token table")
        return v
    if not meta.get("not_a_primitive"):
        v.append("R20: 'resolution status' registered as primitive")
    if meta.get("ordering_component") != 3:
        v.append("R20: 'resolution status' is not the third ordering-key component")
    if not meta.get("integer_valued"):
        v.append("R20: 'resolution status' not integer-valued (hidden scalar)")
    if set(meta.get("domain", ())) != {0, 1}:
        v.append("R20: 'resolution status' domain is not exactly {0,1}")
    if meta.get("observer_assigned"):
        v.append("R20: 'resolution status' observer-assigned")
    if meta.get("scalar_degree"):
        v.append("R20: 'resolution status' carries a scalar degree")
    if meta.get("independent_ledger_quantity"):
        v.append("R20: 'resolution status' is an independent ledger quantity")
    if meta.get("physical_primitive"):
        v.append("R20: 'resolution status' claimed as physical primitive")
    if meta.get("definition_source") != "finite §12 classification":
        v.append("R20: 'resolution status' definition source is not the finite §12 classification")
    return v

# R15 (v5): the aggregate-reduction rule of §4.1. Any aggregate-level
# quantity cited in a claim must be recorded as an exact finite sum,
# count, or rational ratio over constituent data. Anything else - a fresh
# "primitive" quantity, an aggregate state alphabet, an emergence term -
# is a second regime and is rejected.
AGG_PAT = re.compile(r"aggregat|decomposition|boundary|closed-loop")
AGG_REDUCTIONS = {"sum", "count", "ratio"}

# R16 (v6): Stage-N token firewall (§0.5.x terminology firewall, machine form).
# No Level-A text may carry a physical-scale token or dimensional-content
# word. Any claim that does carry one must be Level B/C with a Level-A
# transitive ancestor: Stage P consumes Stage N output, never the reverse.
SCALE_TOKENS = {"ℓ₀", "ℓ0", "l_0", "ell_0", "t₀", "t0", "m₀", "m0",
                "κ", "kappa", "c_phys", "γ", "gamma", "Γ"}
DIM_WORDS = re.compile(r"\b(length|duration|mass)\b")


def has_scale_token(text):
    t = text.lower()
    if any(tok in t for tok in SCALE_TOKENS):
        return True
    return DIM_WORDS.search(t) is not None


def r16_violations(reg):
    """R16 as a standalone function so F.42 can reuse the exact rule."""
    v = []
    by_id = {r["id"]: r for r in reg}
    for r in reg:
        i = r["id"]
        if not has_scale_token(r["text"]):
            continue
        if r["level"] == "A":
            v.append(f"R16: {i} Level-A text carries a physical-scale token")
            continue
        seen, stack, found = set(), list(r["deps"]), False
        while stack:
            d = stack.pop()
            if d in seen or d not in by_id:
                continue
            seen.add(d)
            if by_id[d]["level"] == "A":
                found = True
                break
            stack.extend(by_id[d]["deps"])
        if not found:
            v.append(f"R16: {i} scale-token claim has no Level-A ancestor")
    return v


def r22_violations(reg, root=HERE):
    """R22 as a standalone function: verification-hygiene gate.

    Delegates all predicates to F.49 (never-again mechanism for the
    F.33-F.35 placeholder pattern). R22 fails if F.49 reports any
    WORD/round-trip/unclassified/provenance/domain violation in the
    Level-A-backing scripts.
    """
    import importlib.util
    from pathlib import Path
    spec = importlib.util.spec_from_file_location(
        "F49_verification_hygiene", str(Path(root) / "F49_verification_hygiene.py")
    )
    f49 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f49)
    violations = []
    # Checks 1, 2, 4 (hygiene)
    for v in f49.hygiene_violations(reg, root=root):
        violations.append("R22: " + v)
    # Check 5 (domain cross-check): each backing script's DOMAIN["proved"]
    # block must equal its registry row's proved_domain.
    for v in f49.domain_violations(reg, root=root):
        violations.append("R22: " + v)
    # Check 3 (provenance) -- skip if the paper file is absent (Check 4
    # tripwires need it; the test fixture may not have one).
    if not f49.PAPER.exists():
        return violations
    sections = f49.paper_sections(f49.PAPER)
    short_map = f49.level_a_backed_scripts(reg)
    stems = f49.resolve_stems(short_map, root)
    for stem in stems:
        path = Path(root) / (stem + ".py")
        if path.exists():
            for v in f49.provenance_violations(str(path), sections):
                violations.append("R22: " + v)
    return violations


REGISTRY = [
    {"id": "RELATIONAL_ROLE_THEOREM", "level": "A",
     # v50: +L10-P11 — the §3.1 proof implements the §4.2 role predicates
     # over well-formed encounters R = (a,p,b,q,τ) (genus disjunct i).
     "axioms": ["L1", "L2", "PTR", "BUDGET", "L7-P11", "L10-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F39_relational_role", "obs": False,
     "aspects": ["port"],
     "text": "roles are operational labels on aspect-port states at a tick",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": ['port'],
     "coverage_maps": [],},
    # Derived separation: capability vs actuality, machine-checked via the
    # F.39 relationality witness (no new script, no new primitives).
    {"id": "CAPABILITY_ACTUALITY_SEPARATION", "level": "A",
     # v50: +L10-P11 — the §3.1 corollary's capability is the existential
     # over well-formed encounters R (genus disjunct i).
     "axioms": ["L7-P11", "L10-P11"],
     "deps": ["RELATIONAL_ROLE_THEOREM", "SIMPLE_STATE_REFERENCE_ROLE"],
     "deferred": [], "lineage": "script",
     "script": "F39_relational_role", "obs": False,
     "text": "Capability–actuality separation (derived): passive-capability "
              "(u = 0 at tick τ) does not entail the passive role in a given "
              "encounter; capability is the existential (a well-formed "
              "encounter R exists with passive(b,R)), actuality the indexed "
              "predicate at an encounter R. The F.39 relationality witness proves "
              "the strongest form: the same selector W plays the active role "
              "in R₁ at τ₁ and the passive role in R₂ at τ₂. Derived via the "
              "F.39 relationality witness; no new primitives, no new quantities",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "ROLE_CUT_INDEPENDENCE", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F39_relational_role", "obs": False,
     "text": "structural and role cuts are independent",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v27: inherited - Paper 10 §2.4.1 (L2) is the content source; no
    # script pointer (F.33 assumes the six-port count, it does not
    # check it).
    {"id": "PORT_COUNT_INVARIANCE", "level": "A",
     "axioms": ["L2", "L6-P11"],
     "deps": [], "deferred": [], "lineage": "inherited",
     "inherited_from": "Paper 10 §2.4.1 (L2)", "script": "", "obs": False,
     "text": "every configuration has exactly six ports"},
    # v27: split port half + role half. Workspace (2026-09-27): the port
    # half (exact port partition; the seeking/non-seeking per-port content)
    # is checked by all three aggregate scripts, one per worked aggregate;
    # the role half (roles attaching per-aspect in R) by F.39.
    {"id": "COMPLEX_BOUNDARY_ACTIVE", "level": "A",
     # v50: +L10-P11 — the §6.2 proof assigns roles "in any resolution
     # relationship R" (genus disjunct i).
     "axioms": ["L6-P11", "L7-P11", "L10-P11"],
     "deps": ["PORT_COUNT_INVARIANCE"], "deferred": [],
     "lineage": "script",
     "script": ["F33_aggregate_a", "F34_aggregate_b", "F35_aggregate_c",
                "F39_relational_role"], "obs": False,
     "aspects": ["port"],
     "text": "complex non-O boundary ports are seeking aspects "
              "(O-valued open boundary ports are unresolved but present zero "
              "unmatched integers); in any encounter R the seeking aspects "
              "play the active role",
     "agg": [{"name": "B", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port'],
     "coverage_maps": [],},
    # v27: split port half + role half. Workspace (2026-09-27): the port
    # half (exact boundary/interior port partition over the worked
    # aggregates) is checked by all three aggregate scripts, one per
    # worked aggregate; the role half (roles attaching per-aspect in R)
    # by F.39.
    {"id": "COMPOUND_CLOSED_LOOP_COHERENCE", "level": "A",
     # v50: +L10-P11 — the §4.4 proof attaches roles per-aspect "in any
     # encounter R" (genus disjunct i).
     # V6 correction (loop): the staged +L5-P11 is reverted. "Neither role
     # attaches without the encounter" is L7 encounter-indexedness — the
     # same sentence species as §3.3's premise (ruled L7 in remedy (b)) and
     # §6.2's closing sentence (ruled L7 gloss in this changelog). §3.1's own
     # corollary cites §4.4 ("No role attaches without the encounter
     # (§4.4)"), so modeling §4.4 as downstream of L5 recreates the
     # V6-class circularity the remediation exists to remove.
     "axioms": ["L6-P11", "L7-P11", "L10-P11"],
     "deps": ["COMPLEX_BOUNDARY_ACTIVE"], "deferred": [],
     "lineage": "script",
     "script": ["F33_aggregate_a", "F34_aggregate_b", "F35_aggregate_c",
                "F39_relational_role"], "obs": False,
     "aspects": ["port", "junction", "node"],
     "text": "per-aspect roles dissolve the compound closed-loop paradox",
     "agg": [{"name": "interior/boundary aspect partition",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port', 'junction', 'node'],
     "coverage_maps": [],},
    # Registration of the §4.1 Structural Insulation Theorem (authorized
    # 2026-10-01; F.54 REGISTRY_INCOMPETENESS finding). Axioms: the proof
    # leans on L6-P11's nine-position matrix/loop content ("to alter the
    # configuration's matrix, the incoming geometry must occupy at least
    # one of the configuration's nine positions") plus inherited Paper 2
    # §1 (the identity scan at every tick; "inherited_from") and Paper 2
    # §11.1 (the bonding modes behind "shared junction" — not an AXIOM
    # label; cf. the L8/L9 DERIVED comment). Deps: none — it is a theorem
    # of the structural label; nothing it depends on depends on its
    # dependents (SIMPLE_STATE_INSULATION, ENGAGEMENT_ALTERATION_SEPARATION
    # both gain it as a dep below). Lineage "prose": established by the
    # §4.1 definitional proof; no script pointer (see the L12-P11 comment).
    {"id": "STRUCTURAL_INSULATION_THEOREM", "level": "A",
     "axioms": ["L6-P11"], "deps": [], "deferred": [],
     "lineage": "prose", "section": "§4.1",
     "inherited_from": "Paper 2 §1; Paper 2 §11.1", "script": "", "obs": False,
     "text": "a simple state's internal geometry can be altered only by "
              "direct geometric occlusion (collision); no configuration can "
              "rewrite another's loop through proximity alone"},
    # v27: inherited - Paper 2 §1 is the content source; no script
    # pointer. Registration update: the §5.2 proof is "Direct application
    # of the Structural Insulation Theorem (§4.1)", so the claim now deps
    # on STRUCTURAL_INSULATION_THEOREM and cites its label L12-P11; the
    # lineage is "prose" (established by the §5.2 proof in the paper),
    # with Paper 2 §1 kept as the ultimate inherited source.
    {"id": "SIMPLE_STATE_INSULATION", "level": "A",
     "axioms": ["L6-P11", "L12-P11"],
     "deps": ["STRUCTURAL_INSULATION_THEOREM"], "deferred": [],
     "lineage": "prose", "section": "§5.2",
     "inherited_from": "Paper 2 §1", "script": "", "obs": False,
     "text": "simple state insulation against non-occlusion"},
    # v27: the 4-witness role-cut check lives in F.39 (State-1/9 passive
    # witnesses, per-port u-partition).
    # Rework (2026-10-06): the §5.3 proof's u=0 ground is the inherited
    # saturated-center premise ([Depends: Paper 2 §11.1], verified #109).
    {"id": "SIMPLE_STATE_REFERENCE_ROLE", "level": "A",
     # v50: +L10-P11 — the §5.3 capability is "a well-formed encounter
     # exists in which the role cut assigns it the passive role".
     "axioms": ["L7-P11", "L10-P11"], "deps": ["SIMPLE_STATE_INSULATION"],
     "deferred": [], "lineage": "script",
     "script": "F39_relational_role", "obs": False,
     "text": "a simple state with a saturated center (States 1 and 9) can play the passive role as a reference",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v27: the F.34 pointer is dropped. F.34 checks the aggregate-B
    # decomposition, not the two-channel conclusion - an adjacent check,
    # i.e. a misassignment. No script checks the two-channel conclusion;
    # its basis is the definitional §6.3 derivation from L6-P11/L7-P11,
    # built on the machine-checked COMPLEX_BOUNDARY_ACTIVE chain and the
    # inherited insulation theorem.
    {"id": "DUAL_RESPONSE_MODES", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["COMPLEX_BOUNDARY_ACTIVE", "SIMPLE_STATE_INSULATION"],
     "deferred": [], "lineage": "prose", "section": "§6.3",
     "script": "", "obs": False,
     "text": "complex configurations have proximity and collision channels"},
    # v31: engagement-alteration separation. Deps are all Level A (R10);
    # axioms cite the new L8/L9 derived labels plus L6/L7 (R9: "boundary"/
    # "port" are P11 terms; R13: all labels registered). Text avoids
    # active/passive (R11), the role-cut collapse pattern (R12), intrinsic
    # role assignment (R21), forbidden native words (R8), boundary
    # object-positing phrases (R19), and scale tokens (R16). "boundary" in
    # text triggers R15: the presented boundary-port set is recorded as a
    # count reduction.
    {"id": "ENGAGEMENT_ALTERATION_SEPARATION", "level": "A",
     # v50: +L10-P11 — the §4.6 engagement definiens is "encounter geometry
     # plus a presented non-O boundary port at a tick" (certainty case).
     # Registration update: the §4.6 proof leans on the Structural
     # Insulation Theorem (§4.1) for the ¬(ii) disjunct ("by the Structural
     # Insulation Theorem (§4.1) ... it occupies no nine-position"), so
     # the claim now deps on STRUCTURAL_INSULATION_THEOREM and cites its
     # label L12-P11.
     "axioms": ["L6-P11", "L7-P11", "L8-P11", "L9-P11", "L10-P11",
                "L12-P11"],
     "deps": ["SIMPLE_STATE_INSULATION", "DUAL_RESPONSE_MODES",
              "INTERACTION_TAXONOMY", "STRUCTURAL_INSULATION_THEOREM"],
     "deferred": [], "lineage": "script",
     "script": "F47_engagement_separation", "obs": False,
     "aspects": ["port"],
     "text": "engagement (proximity encounter geometry at a tick) does not "
             "entail alteration (junction completion or occlusion): scoring "
             "a proximity encounter under the taxonomy changes no port "
             "status and no nine-position content; incorporation is the "
             "distinct junction-completion step, closing ports per the "
             "bonding lemma while every node's 27-state identity is "
             "preserved",
     "agg": [{"name": "presented boundary-port set", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": ['port'],
     "coverage_maps": [],},
    # v50: encounter-geometry definition claim (L10-P11). Level A, prose
    # lineage: the §3.2 definition is established by the paper's own
    # disjunctive proof text, so no script pointer (R3). R9 satisfied:
    # "port"/"aspect"/"resolution" are P11 terms and L8-P11 is a DERIVED
    # label in axioms. R14 satisfied: "aspect" cited, all four selector
    # kinds declared. Text avoids active/passive (R11), role-cut collapse
    # (R12), intrinsic role assignment (R21), forbidden native words
    # (R8), boundary object-positing (R19), and scale tokens (R16); no
    # aggregate-level content (R15 clean). The contingencies are
    # disclosed in the text, not wired.
    {"id": "ENCOUNTER_GEOMETRY_DEFINITION", "level": "A",
     "axioms": ["L2", "L3", "L8-P11"],
     "deps": [], "deferred": [], "lineage": "prose", "section": "§3.2",
     "script": "", "obs": False,
     "aspects": ["port", "junction", "node", "whole"],
     "text": "encounter geometry (definition): configurations X and Y occupy "
             "encounter geometry at tick tau (X->Y direction) iff (i) a §3.2 "
             "resolution relationship R = (a,p,b,q,tau) holds with a an aspect "
             "of X and b an aspect of Y (encounter distance = ambient L3 "
             "relay-hop distance, a defined quantity over existing data), or "
             "(ii) d >= 1 is the least relay-hop shell at which Y presents a "
             "port to X's scan at tau (the §8.5 engagement shell); undirected "
             "iff the directed relation holds in at least one direction; "
             "tick-free uses name the tau-abstracted admissibility relation "
             "(Level B reading gloss); d >= 1 contingent on the parked §8.5 "
             "d>=1 ruling, disjunct-(i) naming contingent on the parked "
             "tier-(i) wording ruling"},
    {"id": "RESOLUTION_VERB", "level": "A", "axioms": ["L1"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F43_shove_transition", "obs": False,
     "text": "unmatched integers are the shear-tension count itself "
             "(definitional unfolding per the §7.1 Identity, not a produced "
             "quantity)",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # Author-authorized native definition (Dervis 2026-10-05; staged as a
    # candidate in #129, asserted in #130). Defines "alignment" natively:
    # aligned iff τ_J = 0; toward-alignment iff strict per-tick τ_J
    # decrease. No native sentence derives it and no script proves it —
    # F.55 (staged, unlisted) audits the correspondence this definition
    # states. Lineage "prose" (R3): names the defining section, carries
    # no script pointer.
    {"id": "ALIGNMENT_DEFINITION", "level": "A",
     "axioms": ["L1"],
     "deps": [], "deferred": [],
     "lineage": "prose", "section": "§7.2",
     "script": "", "obs": False,
     "text": "alignment (author-authorized definition): a junction is "
             "aligned iff τ_J = 0 (all integers matched; PTR-compatible); "
             "a transition is toward alignment iff it strictly decreases "
             "τ_J per tick; \"toward\" names per-tick direction, not "
             "guaranteed arrival"},
    {"id": "SHOVE_DIRECTION", "level": "A", "axioms": ["L1"],
     # V6 correction (loop): the §7.2 proof's "the resolution transition T
     # reduces τ_J by exactly 2 per tick (§7.5)" is definitional unfolding of
     # the §7.5 operator definition (T zeroes the canonically-first
     # admissible pair; τ_J = Σx²; zeroing (±1,∓1)→(0,0) removes exactly 2
     # — three lines of arithmetic), NOT the Transition Properties
     # theorem's derived content (totality, determinism, τ/2 bound,
     # confluence). The staged reversal manufactured dependence and
     # contradicted the G3 doctrine. Edge DELETED, not reversed: the two
     # claims are siblings under the §7.5 operator definition at L1; the
     # §7.2→§7.5 citation is SATISFIED via shared L1 labels — no spurious
     # edge is kept to force SATISFIED.
     "deps": ["RESOLUTION_VERB"],
     "deferred": [], "lineage": "script",
     "script": "F43_shove_transition", "obs": False,
     "text": "shove pushes toward alignment",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v27: content lineage is Paper 8 §2 (the mechanism constraints);
    # F.44 machine-checks the composition dTau_J < 0 => dS2 <= 0 at the
    # port-value grain.
    {"id": "TRACKING_COST_LEMMA", "level": "A",
     # V6 (staged): +L6-P11 — the proof leans on "the total s² is the sum
     # of the per-port contributions (R15's exact-finite-sum rule, §4.1)":
     # §4.1/R15 is L6-P11 content, previously unmodeled. 2026-10-05: the
     # aspect-level additivity sentence is withdrawn with the lemma's
     # narrowing to the port-level claim F.44 checks (R23); the
     # aspect-level reading is asserted as Lemma 2 (Aspect Aggregation)
     # in §7.3 — author-authorized 2026-10-05 (#128), registered below
     # as ASPECT_AGGREGATION (prose lineage, no script pointer).
     "axioms": ["L1", "L6-P11", "L7-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F44_tracking_cost", "obs": False,
     "content_source": "Paper 8 §2",
     "aspects": ["port"],
     # R23 (2026-10-05): narrowed to the port-level lemma F.44 checks.
     # The pre-fix aspect-level registration (claimed over all four kinds)
     # is the R23 battery's live-regression mutant.
     "text": "port s² contribution is the temporal-scan cost of tracking "
             "its departure: exactly 0 when the port is resolved (value 0), "
             "a nonnegative diverted budget share otherwise",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": ['port'],
     "coverage_maps": [],},
    # 2026-10-05 (#128): author-authorized native definitional content —
    # the port→aspect s² attribution map. Basis: Dervis's 2026-10-05
    # authorization (staged as a candidate in #127). No native sentence
    # derives it and no script proves it — F.33–F.35 implement and audit
    # the partition rule the lemma states. Lineage "prose" (R3): names
    # the defining section, carries no script pointer.
    {"id": "ASPECT_AGGREGATION", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["TRACKING_COST_LEMMA"], "deferred": [],
     "lineage": "prose", "section": "§7.3",
     "script": "", "obs": False,
     "aspects": ["port", "junction", "node", "whole"],
     "text": "aspect aggregation (author-authorized definition): each port's "
             "tracking-cost contribution is attributed to exactly one aspect — "
             "interior node- and junction-aspects carry 0; each boundary "
             "port-aspect carries its port's contribution (State-9 boundary "
             "ports carry 0 by the declared rule-ii disambiguation); total s² "
             "is the sum of the attributed aspect contributions; one T-action "
             "changes only the attributed contributions of the aspects owning "
             "the two touched ports",
     "agg": [{"name": "total s² over attributed aspects",
              "reduction": "sum"}]},
    {"id": "TENSION_RELIEF", "level": "A", "axioms": ["L1", "PTR"],
     "deps": ["SHOVE_DIRECTION", "SHOVE_TRANSITION_OPERATOR",
              "TRACKING_COST_LEMMA"], "deferred": [], "lineage": "script",
     "script": "F44_tracking_cost", "obs": False,
     "text": "tension relief does not increase total departure "
             "(dTau_J<0 => dS2<=0)",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v30: native ledger conservation withdrawn; vsum is machine-encoding
    # consistency only (F.43 disclosure).
    {"id": "SHOVE_TRANSITION_OPERATOR", "level": "A",
     "axioms": ["L1", "L5-P11"],
     # V6 (staged): the SHOVE_DIRECTION dep is removed — the operator's
     # machine-checked proof (F.43 enumeration + certificates) never uses
     # the direction theorem; the genuine direction is the reverse (the
     # §7.2 proof cites the operator's τ-reduction property).
     "deps": ["RESOLUTION_VERB"],
     "deferred": [], "lineage": "script",
     "script": "F43_shove_transition",
     "obs": False,
     "text": "the resolution transition operator is total, deterministic, "
              "tension-reducing and machine-encoding-consistent (vsum invariant; "
              "not a native conservation law)",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "TENSION_MEASURE_IDENTITY", "level": "A",
     "axioms": ["L1", "L5-P11"],
     # V6 correction (loop): deps stripped to [] — the §7.1 Identity
     # paragraph ("No derivation step from 'unmatched' to 'tension' is
     # claimed, because none exists: the step is definitional unfolding")
     # is definitional, not derived; a definition carries no logical
     # premise order. Consistent with RESOLUTION_VERB's []. F.43 keeps
     # machine-checking the content via the script pointer regardless
     # (E.1's rule: claim-dependence records logical premise order;
     # machine-coverage direction is carried separately by script
     # pointers).
     "deps": [],
     "deferred": [], "lineage": "script",
     "script": "F43_shove_transition",
     "obs": False,
     "text": "shear tension is the unmatched-integer count τ_J; "
              "τ_J = 0 iff PTR-compatible",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # Registration (2026-10-04, ChatGPT HIGH claim "binary transition
    # operator vs non-binary junctions", staged): INHERIT, not invent.
    # The triple-convergence event is inherited from the four cited
    # passages; the electron/positron-X-dominant/Y-dominant naming is
    # Paper 11's native State-1 tilt usage (§5.1), confirmed by the
    # author's binding identification (2026-10-04) -- not carried by the
    # four passages. Deps [] (not derived from other Paper-11 claims);
    # lineage "inherited" with no Paper-11 script pointer (R3); stated
    # at §7.6. Schema mirrors PHOTON_BASELINE (field order: id, level,
    # axioms, deps, deferred, lineage, inherited_from, script, obs,
    # text).
    {"id": "TRIPLE_CONVERGENCE_RESOLUTION", "level": "A",
     "axioms": ["L1"], "deps": [], "deferred": [],
     # 2026-10-04 (loop): L5-P11 (RELATIONAL_ROLE_THEOREM) removed — the
     # claim's content carries no role vocabulary and leans on nothing in
     # L5-P11; per the V6 doctrine spurious label edges are deleted, not kept.
     "lineage": "inherited",
     "inherited_from": "Paper 2 §8.1; Paper 2 §11.1; Paper 3 §7; Paper 3 §8.5",
     "script": "", "obs": False,
     "text": "three State-4 configurations converging center-to-center "
              "resolve as a single-tick event; on completion they release, "
              "enclosed, three products — a photon (State 9, (0,0,0), the "
              "photon baseline), an X-axis-dominant configuration (the "
              "electron), a Y-axis-dominant configuration (the positron) — "
              "the \"photon/electron/positron\" and "
              "\"photon/X-dominant/Y-dominant\" wordings naming the same "
              "products; after that tick the products are their own stable "
              "identities; State 4 is special only in that three State-4s "
              "make three different things, all enclosed — nine X, nine Y, "
              "nine O in, nine X, nine Y, nine O out, balanced to the "
              "letter, nothing created or destroyed"},
    {"id": "INTERACTION_TAXONOMY", "level": "A",
     # v50: +L10-P11 — §8.1/§8.6: the three outcomes classify scored
     # encounters; the §8.6 selection rule scores encounters.
     "axioms": ["L6-P11", "L7-P11", "L10-P11"],
     "deps": ["RESOLUTION_VERB", "ENCOUNTER_TENSION_ANALYSIS"],
     "deferred": [], "lineage": "script",
     "script": "F36_interaction_taxonomy", "obs": False,
     "text": "three outcomes distinguished by port geometry",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "SATURATION_FUSE", "level": "A", "axioms": ["L1", "L10-P11"],
     # v50: +L10-P11 — the fuse is the §8.6 selection rule's third branch
     # over scored encounters (res > TH → forced decay).
     "deps": ["RESOLUTION_VERB", "ENCOUNTER_TENSION_ANALYSIS"],
     "deferred": [], "lineage": "script",
     "script": "F36_interaction_taxonomy",
     "obs": False,
     "text": "the taxonomy's saturation fuse: residue past TH selects forced "
             "decay, zero residue gives attraction, otherwise repulsion -- "
             "saturation derived from presented tuples, no external input",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v28: the encounter tension analysis (Theorems S/N/G/A/F, F.36 SECTION 9).
    # T(A,B) is the definitional application of tau(sigma) (section 7.5) to the
    # presented pair -- no new primitive. INTERACTION_TAXONOMY and
    # SATURATION_FUSE record it as a dep (the taxonomy's tension language is
    # grounded here, closing the G5 dependency-graph gap).
    {"id": "ENCOUNTER_TENSION_ANALYSIS", "level": "A",
     # v50: +L10-P11 — T(A,B) is summed over the presented tuple pair of a
     # native encounter.
     "axioms": ["L1", "L5-P11", "L10-P11"],
     "deps": ["TENSION_MEASURE_IDENTITY", "RESOLUTION_VERB"],
     "deferred": [], "lineage": "script",
     "script": "F36_interaction_taxonomy",
     "obs": False,
     "text": "encounter tension analysis: T(A,B) = sum x^2 over both presented "
             "tuples; complementary cover plus the incoming-side guard strictly "
             "reduces T; strict T reduction does not imply cover (partial "
             "matching is repulsion); A-all-zero encounters are refused; B's "
             "unmatched labels stay presented (paired off, not consumed) with "
             "the verdict unaffected; the residue fuse watches the unresolvable "
             "load, not the presented load",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v27: re-pointed from F.36 to F.45 (the proximity-scaling script).
    {"id": "PROXIMITY_SCALING", "level": "A", "axioms": ["L6-P11", "L10-P11"],
     # v50: +L10-P11 — §8.5: "a mixed encounter ... at encounter distance d
     # — the engagement shell" (genus disjunct ii).
     "deps": ["INTERACTION_TAXONOMY", "PROXIMITY_SHELL_PROFILE"],
     "deferred": [], "lineage": "script",
     "script": "F45_proximity_scaling", "obs": False,
     "text": "proximity scaling from shell count",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v47: Kimi-V2 remediation — the per-shell met-position profile is now
    # machine-derived (F.45 checks (d)/(e)): D-invariant engagement counts
    # on the canonical encounter family, e(d) <= B(G) on every shell.
    # The aggregate-extension half of PROXIMITY_SCALING depends on this
    # claim; the native tier (R-tuple, e=1 by definition) does not.
    {"id": "PROXIMITY_SHELL_PROFILE", "level": "A",
     # v50: +L10-P11 — e(d) is "derived from presented port geometry" on the
     # canonical encounter family (§8.5 shell machinery).
     "axioms": ["L6-P11", "L10-P11"],
     "deps": ["PORT_PARTITION_EXACTNESS"], "deferred": [], "lineage": "script",
     "script": "F45_proximity_scaling", "obs": False,
     "text": "per-shell met-position profile: e(d) is derived from presented port geometry — engagement counts D-independent on the canonical encounter family (3 for (a), 1 for (b), 1 for (c)), e(d) <= B(G) on every shell, port-vs-position coincidences exact",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v30: re-pointed F33 -> F46 (first-encounter machine check); Level-A
    # encounter claims split out below; the ladder generalization stays B.
    # v30-recon: full content spec of the unified F.46 final (471 checks,
    # 7 planted mutants; Phase-C numbers authoritative). Badge: counting and
    # chain arithmetic Level A given premises; verdicts Level B.
    {"id": "CASE_A_LADDER", "level": "B", "axioms": ["L6-P11", "L7-P11"],
     "deps": ["INTERACTION_TAXONOMY", "CONSUMPTION_CONSTRUCTION_ROBUSTNESS",
              "CROSS_NUCLEUS_ROBUSTNESS"], "deferred": ["P16"],
     "lineage": "script", "script": "F46_caseA_ladder",
     "obs": False,
     "agg": [{"name": "ladder count quantities", "reduction": "count"}],
     "text": "nucleus to atom ladder as illustration. F.46 content spec: "
              "(i) 27 first-encounter runs (nine states x three nucleus-(a) "
              "constructions, State 9 first as rung 1) plus aggregate-(b) runs "
              "under the normalized (4,4,2) convention including State 5, "
              "the State-1 positron mirror, the all-zero incoming refusal "
              "guard, and permutation/identity zero-leak checks; "
              "(ii) sequential chain: the count-deterministic incorporation "
              "update (Lemmas 1-3 machine-checked), the distinguished "
              "departure-order chain, and the full 9! order-robustness sweep "
              "(1,088,640 chain runs over three seeds); (iii) seven planted "
              "mutants rejected including the net-sum specimen. Badge: "
              "categorical counting and chain arithmetic are Level A given "
              "the documented premises; the encounter verdicts and the chain "
              "protocol's physical reading stay Level B",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v30: four Level-A promotion claims for the §9 first encounters (F.46/F.36).
    # v30-recon: D.2 -- the Level-A content is the counting, machine-checked
    # by F.46 given the documented premises; the encounter verdicts stay
    # Level B (Phase-C badge discipline). Seven mutants, not five.
    {"id": "CONSUMPTION_CONSTRUCTION_ROBUSTNESS", "level": "A",
     # v50: +L10-P11 — "the categorical counting of all 27 first encounters"
     # (§9.2 scored encounters).
     "axioms": ["L1", "L5-P11", "L10-P11"],
     "deps": ["INTERACTION_TAXONOMY", "ENCOUNTER_TENSION_ANALYSIS"],
     "deferred": [], "lineage": "script",
     "script": "F46_caseA_ladder", "obs": False,
     "text": "Level A given the documented premises: the categorical counting "
              "of all 27 first encounters (nine states x three nucleus-(a) "
              "constructions) -- res=0 with strictly decreasing presented "
              "tension; consumption and construction readings agree on "
              "counts; permutation/identity zero-leak; positron-mirror "
              "counts identical; all-zero incoming refused. The attraction "
              "verdicts stay Level B. Seven planted mutants rejected, "
              "including the net-sum specimen",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "TH_INDEPENDENCE", "level": "A",
     # v50: +L10-P11 — §8.6 TH-independence of the scored outcome label on
     # res = 0 encounters.
     "axioms": ["L1", "L5-P11", "L10-P11"],
     "deps": ["INTERACTION_TAXONOMY"],
     "deferred": [], "lineage": "script",
     "script": "F36_interaction_taxonomy", "obs": False,
     "text": "res=0 formal outcome label independent of TH over the viable band "
              "(0, k); viable band exactly [1, k-1] for k>=2, empty at k=1",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "DOMAIN_GUARD_DISJUNCTION", "level": "A",
     # v50: +L10-P11 — the §8.6 domain guard decides encounter admissibility
     # (the engagement definiens' in-domain conjunct).
     "axioms": ["L1", "L5-P11", "L10-P11"],
     "deps": ["INTERACTION_TAXONOMY"],
     "deferred": [], "lineage": "script",
     # v30-recon repair 2026-09-25: the nine-state in-domain clause is
     # grounded in F.46 [1] + the Paper-3 row verification, not F.36 alone.
     "script": ["F36_interaction_taxonomy", "F46_caseA_ladder"], "obs": False,
     "text": "all-O incoming refused (not scored); >=1 non-O incoming in-domain; "
              "all nine simple states in-domain per verified Outside Content "
              "(A2 Paper-3 row verification; F.46 [1] runs all nine states, "
              "none refused); the two cases exhaust the guard",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v30-recon: D.2 -- the Level-A content is the count arithmetic
    # (normalized (4,4,2) convention; 81-case enumeration 74/7/0); the
    # attraction/repulsion verdicts stay Level B (Phase-C badge discipline).
    {"id": "CROSS_NUCLEUS_ROBUSTNESS", "level": "A",
     # v50: +L10-P11 — "the 81-case marginal enumeration" of scored
     # encounters (§9.5).
     "axioms": ["L1", "L5-P11", "L10-P11"],
     "deps": ["INTERACTION_TAXONOMY", "ENCOUNTER_TENSION_ANALYSIS"],
     "deferred": [], "lineage": "script",
     "script": "F46_caseA_ladder", "obs": False,
     "text": "Level A given the documented premises: the aggregate-(b) "
              "categorical counting -- normalized (4,4,2) convention with "
              "B=10; all nine states including State 5 run with res=0; the "
              "81-case marginal enumeration: 74 cases res=0, seven marginal "
              "cases res=TH=1, zero cases res>1. The attraction/repulsion "
              "verdicts stay Level B",
     "agg": [{"name": "documented construction encounter count", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # staged V3 remediation (2026-10-01; no version built): this row pointed at F.34 (aggregate-(b)
    # per-aspect s^2 decomposition), which never mentions colliders --
    # a misassignment, not a verification. The claim is re-texted to the
    # proposition §10.3 actually states and re-pointed at F.53, which
    # machine-audits the two-regime partition through the §8.6 residue
    # model. Inherited premises (cited, not checked here): Paper 10 §7.1
    # (geometric-sorting logic, via §10.1) and Paper 2.5 §13.5
    # (Forced-vs-Free discipline, via §10.2). Deferred P15 = collider
    # correspondence (presented tuples read as collider encounter
    # geometry); P16 = bridge legitimacy (the tick-tau rendering of
    # "a single-tick resolution to simple states exists"). L7-P11
    # RESTORED (devil's-advocate loop, 2026-10-01): the staged-remediation
    # L7 drop was
    # unjustified. The claim reads the §8.6 residue trichotomy, whose
    # branch definitions (§8.2/§8.3/§8.4) carry L5-P11·L7-P11 badges,
    # whose §8.6 domain guard is the §4.2 role cut (L7's definitional
    # content: active iff u(A, τ) > 0), and whose dep
    # INTERACTION_TAXONOMY carries ["L6-P11", "L7-P11"]. The re-texted
    # claim evades R11's keyword trigger ("active"/"passive") by
    # vocabulary choice ("clean-resolution"/"trapped") while remaining
    # L7-dependent in content; dropping the label would understate the
    # claim's conditionality.
    {"id": "CASE_B_COLLIDER", "level": "B", "axioms": ["L6-P11", "L7-P11"],
     "deps": ["INTERACTION_TAXONOMY"], "deferred": ["P15", "P16"],
     "lineage": "script", "script": "F53_caseB_two_regime", "obs": False,
     "text": "collider outputs under forcing: the §10.3 two-regime "
              "partition is decidable through the §8.6 residue model "
              "(Level B reading of presented geometry): an encounter is "
              "clean-resolution iff tick-tau full complementary cover "
              "(res = 0), else trapped; the trapped band splits under the "
              "§8.6 rule into the saturated band (res > TH → forced decay) "
              "and the middle band (0 < res ≤ TH → repulsion); the §10.3 "
              "'selects forced decay' holds "
              "per-tick exactly on the saturated band (the multi-tick "
              "sequence is deferred to Paper 13 -- inter-tick residue evolution not "
              "natively specified)",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "CASE_C_STRUCTURAL", "level": "B", "axioms": ["L6-P11"],
     "deps": ["INTERACTION_TAXONOMY", "PATH_UPPER_BOUND",
              "MONOTONICITY_REFUTATION", "BOUNDARY_EXTENSION_INCLUSION",
              "NODE_ADDITION_FORMULA", "NODES_PORTS_NONMONOTONICITY",
              "BOUNDARY_EXTENSION_CAVEAT"], "deferred": [],
     "lineage": "script", "script": "F48_consolidation_paths",
     "obs": False,
     # v32: re-texted after the monotonicity refutation. The monotone
     # nodes->paths claim is withdrawn, not re-badged. The claim's
     # environment-relative conditional structure is machine-checked by
     # F.48 at Level A (formal domain); the physical reading stated here
     # stays Level B.
     "text": "the environment-relative conditional structure of "
              "consolidation paths: path counts are bounded by (B, "
              "boundary values, environment); monotone non-decreasing only "
              "under boundary-extension (valued boundary-port-set inclusion, "
              "non-strict); node count does not control boundary-port "
              "count; the monotone nodes->paths claim is withdrawn",
     "agg": [{"name": "environment-relative path counts",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "COMPLEXITY_ORDERING", "level": "B", "axioms": ["L6-P11"],
     "deps": [], "deferred": ["P16"],
     "lineage": "script", "script": "F37_complexity_ordering", "obs": False,
     "text": "structural ordering by departure",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # staged V3 remediation (2026-10-01; no version built): completes changelog #91, whose "pointer F.37 ->
    # prose §11.3" repair was recorded but never landed in this source.
    # The chemistry mapping stays outside any machine check (§11 prose).
    {"id": "LITHIUM_SODIUM_ILLUSTRATION", "level": "C", "axioms": [],
     "deps": ["CASE_C_STRUCTURAL"], "deferred": [],
     "lineage": "prose", "section": "§11.3", "script": "",
     "obs": True, "text": "lithium versus sodium as correspondence"},
    {"id": "AGGREGATE_A_DECOMPOSITION", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["COMPOUND_CLOSED_LOOP_COHERENCE", "TRACKING_COST_LEMMA"],
     "deferred": [],
     "lineage": "script", "script": "F33_aggregate_a",
     "obs": False, "aspects": ["port", "junction", "node"],
     "text": "per-aspect decomposition of three-node State-4 composite: "
              "exact port partition (B = 6N - sum(k_j), dual-computed), "
              "symbolic per-aspect s^2 contributions consistent with Lemma 2 (Aspect Aggregation) "
              "(resolved -> 0 exactly; open tilt ports -> positive formal "
              "symbols; junctions contribute no s^2), symbolic-sum identity "
              "via enumeration plus an independent arithmetic audit. "
              "[LEVEL A] conditional on the Tracking-Cost Lemma, 6.1, and "
              "Appendix B premises; the machine checks the counting, not the "
              "premises. The State-9 contribution rule (ii) is a declared "
              "disambiguation (rule ii of Lemma 2 (Aspect Aggregation)), load-bearing for the "
              "(c) sweep's State-9 rows and the section-5 battery",
     "agg": [{"name": "per-aspect port partition", "reduction": "count"},
             {"name": "aggregate s^2", "reduction": "sum"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port', 'junction', 'node'],
     "coverage_maps": [],},
    {"id": "AGGREGATE_B_DECOMPOSITION", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["COMPOUND_CLOSED_LOOP_COHERENCE", "TRACKING_COST_LEMMA"],
     "deferred": [],
     "lineage": "script", "script": "F34_aggregate_b",
     "obs": False, "aspects": ["port", "junction", "node"],
     "text": "per-aspect decomposition of two-node State-5/6 pair, "
              "branch-ready over both documented consumption conventions "
              "(branch A consume-O, section 9: 8 positive symbols; branch B "
              "complementary pair, Appendix B.2: 6 positive symbols), each "
              "branch verified independently; Decision Q: branch B the paper's "
              "stated convention (recorded 2026-09-26, confirmed by the "
              "author's direct decision 2026-09-27): exact port partition "
              "(B = 6N - sum(k_j), dual-computed), symbolic per-aspect s^2 contributions consistent with Lemma 2 (Aspect Aggregation) "
              "(resolved -> 0 exactly; "
              "open tilt ports -> positive formal symbols; junctions "
              "contribute no s^2), symbolic-sum identity via enumeration "
              "plus an independent arithmetic audit. [LEVEL A] conditional "
              "on the Tracking-Cost Lemma, 6.1, and Appendix B premises; the "
              "machine checks the counting, not the premises. The State-9 "
              "contribution rule (ii) is a declared disambiguation (rule ii of Lemma 2 "
              "(Aspect Aggregation)), load-bearing for the section-5 battery",
     "agg": [{"name": "per-aspect port partition", "reduction": "count"},
             {"name": "aggregate s^2", "reduction": "sum"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port', 'junction', 'node'],
     "coverage_maps": [],},
    {"id": "AGGREGATE_C_DECOMPOSITION", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["COMPOUND_CLOSED_LOOP_COHERENCE", "TRACKING_COST_LEMMA"],
     "deferred": [],
     "lineage": "script", "script": "F35_aggregate_c",
     "obs": False, "aspects": ["port", "junction", "node"],
     "text": "per-aspect decomposition of linear three-node chain: exact "
              "port partition (B = 6N - sum(k_j), dual-computed), "
              "symbolic per-aspect s^2 contributions consistent with Lemma 2 (Aspect Aggregation) "
              "(resolved -> 0 exactly; open tilt ports -> positive formal "
              "symbols; junctions contribute no s^2), symbolic-sum identity "
              "via enumeration plus an independent arithmetic audit; the "
              "decomposition identity holds for all 10^3 state-row "
              "assignments on F.41's documented indices (Electron/Positron "
              "rows verified separately; outcomes identical); the sweep's "
              "universality is over formal row assignments for the "
              "bookkeeping identity -- physical junction-admissibility per "
              "pairing is a Paper-2 question not badged here. [LEVEL A] "
              "conditional on the Tracking-Cost Lemma, 6.1, and Appendix B "
              "premises; the machine checks the counting, not the premises. "
              "The State-9 contribution rule (ii) is a declared "
              "disambiguation (rule ii of Lemma 2 (Aspect Aggregation)), load-bearing for the "
              "(c) sweep's State-9 rows and the section-5 battery",
     "agg": [{"name": "per-aspect port partition", "reduction": "count"},
             {"name": "aggregate s^2", "reduction": "sum"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port', 'junction', 'node'],
     "coverage_maps": [],},
    {"id": "BRIDGE_LEDGER_P11", "level": "A", "axioms": [],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F38_claim_registry", "obs": False,
     "text": "imports and exports audited",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v27: FALSIFICATION_C19_C22 split per condition. C21 is the
    # machine-checkable half (F.39's encounter-indexed role audit);
    # C22 is the three-aggregate decomposition check (F.33-F.35);
    # C19/C20 are observationally falsifiable (Level C, prose §14.3).
    {"id": "FALSIFICATION_C19", "level": "C", "axioms": ["L6-P11"],
     "deps": ["SIMPLE_STATE_INSULATION"], "deferred": [],
     "lineage": "prose", "section": "§14.3", "script": "", "obs": True,
     "text": "C19: a simple state observed to alter its geometry without "
              "direct geometric occlusion falsifies the insulation claim; "
              "testable by a tabletop collision experiment"},
    {"id": "FALSIFICATION_C20", "level": "C",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["COMPLEX_BOUNDARY_ACTIVE"], "deferred": [],
     "lineage": "prose", "section": "§14.3", "script": "", "obs": True,
     "text": "C20: complex-configuration boundary ports showing no "
              "proximity response distinguishable from collision-only "
              "response falsify the boundary-seeking claim; testable by a "
              "proximity-response measurement",
     "agg": [{"name": "boundary-port response count",
               "reduction": "count"}]},
    {"id": "FALSIFICATION_C21", "level": "A",
     # v50: +L10-P11 — "the audit is encounter-indexed" (F.39 over the
     # finite encounter space).
     "axioms": ["L5-P11", "L7-P11", "L10-P11"],
     "deps": ["RELATIONAL_ROLE_THEOREM"], "deferred": [],
     "lineage": "script", "script": "F39_relational_role", "obs": False,
     "text": "C21: any active/passive assignment in the paper's domain "
              "that requires entity-intrinsic labels falsifies the "
              "relational role theorem; the audit is encounter-indexed",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port'],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "FALSIFICATION_C22", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["AGGREGATE_A_DECOMPOSITION", "AGGREGATE_B_DECOMPOSITION",
              "AGGREGATE_C_DECOMPOSITION", "COMPOUND_CLOSED_LOOP_COHERENCE"],
     "deferred": [], "lineage": "script",
     "script": ["F33_aggregate_a", "F34_aggregate_b", "F35_aggregate_c",
                "F50_port_partition_status"],
     "obs": False,
     "text": "C22: an exact structural trigger condition (a port "
              "double-counted, or the symbolic ledger identity broken). A "
              "trigger fails the port-partition half of the "
              "compound-closed-loop machine check and voids that half's "
              "Level-A badge support; the §4.4 definition-based proof and "
              "F.39's role half are untouched. The scripts' planted-mutant "
              "battery (all-zero vacuity, invented junction s², "
              "resolved-port-positive, table double-count, fiat-total "
              "method, order-violation, uniform division, O-port-positive, "
              "negative-terms) is rejected with printed witnesses. "
              "mutant_5's rejection is conditional on the declared State-9 "
              "contribution rule (ii) — without (ii) the §5 inequality "
              "reverses and the variant's claim becomes true, so 'all 9 "
              "mutants rejected' would be false",
     "aspects": ["port", "junction", "node"],
     "agg": [{"name": "per-aggregate port partition", "reduction": "count"},
             {"name": "ledger balance", "reduction": "sum"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": ['port', 'junction', 'node'],
     "coverage_maps": [],},
    # v27: six orphaned Level-A items registered with honest bases.
    {"id": "PHOTON_BASELINE", "level": "A", "axioms": ["L5-P11"],
     "deps": [], "deferred": [], "lineage": "inherited",
     "inherited_from": "Paper 2 §5; Paper 10 §2.1", "script": "",
     "obs": False,
     "text": "the photon baseline (State 9, O,O,O) is the single reference "
              "against which all resolution is defined; every other "
              "configuration's identity is its departure from this state"},
    {"id": "ROLE_PERMANENCE_PROHIBITION", "level": "A",
     # v50: +L10-P11 — the §3.3 proof: the role side "is fixed by the
     # encounter geometry", τ-indexed by the §3.2 definition (the
     # "re-evaluated every tick" bridge re-grounded as definitional unfolding).
     # V6 remedy (staged): the §3.3 proof never uses the relational role
     # theorem — it runs on the Circa budget axiom (BUDGET), the §4.2
     # operational role predicates (L7-P11), and encounter geometry
     # (L10-P11). The RELATIONAL_ROLE_THEOREM dep was spurious: the §3.1
     # proof's "By §3.3" cited §3.3's budget sentence (a shortcut for the
     # budget axiom), not the prohibition. Siblings under shared premises.
     "axioms": ["L7-P11", "BUDGET", "L10-P11"],
     "deps": [], "deferred": [],
     "lineage": "prose", "section": "§3.3", "script": "", "obs": False,
     "text": "no configuration retains a role across tick boundaries "
              "without re-establishing the role in the new tick"},
    {"id": "BOUNDARY_PORT_CHARACTERIZATION", "level": "A",
     "axioms": ["L6-P11"],
     "deps": [], "deferred": [], "lineage": "prose", "section": "§4.3",
     "script": "", "obs": False,
     "text": "a complex configuration, defined as a bonded aggregate "
              "carrying open ports, has B >= 1 open boundary ports",
     "agg": [{"name": "B >= 1", "reduction": "count"}]},
    {"id": "SIMPLE_STATE_ENUMERATION", "level": "A",
     "axioms": ["L1", "L6-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F32_simple_state", "obs": False,
     "text": "the simple states are exactly the 27 tilt-triple "
              "configurations of the Paper 3 §2 / Appendix A classification, taken "
              "individually",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "ASPECT_INVENTORY", "level": "A",
     "axioms": ["L1", "L2", "L6-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F40_aspect_inventory", "obs": False,
     "aspects": ["port", "junction", "node", "whole"],
     "text": "every aspect resolves to exactly one of port, junction, "
              "node, whole",
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node', 'whole'],
     "claimed_domain": ['port', 'junction', 'node', 'whole'],
     "coverage_maps": [],},
    {"id": "SINGLE_REGIME", "level": "A", "axioms": ["L6-P11"],
     "deps": [], "deferred": [], "lineage": "script",
     "script": "F41_single_regime", "obs": False,
     "text": "every aggregate-level quantity is an exact finite sum, "
              "count, or ratio over constituent node/junction data; one "
              "rule set covers the lone node and the aggregate",
     "agg": [{"name": "aggregate s^2", "reduction": "sum"},
             {"name": "boundary count B", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # v32: six consolidation-path claims (Vulnerability-16 remediation,
    # §11.2). All Level A: finite combinatorics over the §4.1/§4.3/§6.1
    # definitions plus the categorical complementarity of
    # INTERACTION_TAXONOMY. Machine-checked by F.48 (3,947 checks, 12/12
    # planted mutants rejected with printed witnesses); the physical
    # readings stay Level B/C and do not enter any Level-A chain.
    {"id": "PATH_UPPER_BOUND", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["BOUNDARY_PORT_CHARACTERIZATION", "INTERACTION_TAXONOMY"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "consolidation paths are environment-relative; with "
              "C = X_G·Y_E + Y_G·X_E complementary (boundary, partner) "
              "port pairs, |P(G;E)| ≤ Σ_{k=1..C} C!/(C−k)!; the bound is "
              "a function of (B, boundary values, environment), not "
              "monotone in B alone",
     "agg": [{"name": "consolidation-path count |P(G;E)|",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "MONOTONICITY_REFUTATION", "level": "A",
     "axioms": ["L6-P11", "L7-P11"],
     "deps": ["PATH_UPPER_BOUND", "INTERACTION_TAXONOMY"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "unconditional 'B1<B2 => |P1|<|P2|' is false: an all-O B=10 "
              "boundary yields |P|=0 in any environment (O pairs with "
              "nothing); an all-X B=10 boundary in a Y-free environment "
              "yields |P|=0 while an all-X B=6 boundary in a Y-rich "
              "environment yields |P|=6",
     "agg": [{"name": "witness path counts", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "BOUNDARY_EXTENSION_INCLUSION", "level": "A",
     "axioms": ["L6-P11"],
     "deps": ["BOUNDARY_PORT_CHARACTERIZATION", "INTERACTION_TAXONOMY"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "boundary-extension (valued boundary-port-set inclusion, "
              "fixed environment) implies consolidation-path-set "
              "inclusion and the non-strict path-count inequality",
     "agg": [{"name": "transported path-count comparison",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "NODE_ADDITION_FORMULA", "level": "A",
     "axioms": ["L6-P11"],
     "deps": ["BOUNDARY_PORT_CHARACTERIZATION"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "adding one node while keeping old junctions, new junctions "
              "of total arity Σk_new over all consumed ports: "
              "ΔB = 6 − Σk_new (signed: positive, negative, or zero)",
     "agg": [{"name": "boundary-port count B = 6N − Σk_j",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "NODES_PORTS_NONMONOTONICITY", "level": "A",
     "axioms": ["L6-P11"],
     "deps": ["NODE_ADDITION_FORMULA"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "node count is not monotone in boundary-port count: an "
              "explicit two-node eight-port-consumed aggregate has "
              "N=2, B=4 against one-node N=1, B=6",
     "agg": [{"name": "node/boundary counts of the witness",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    {"id": "BOUNDARY_EXTENSION_CAVEAT", "level": "A",
     "axioms": ["L6-P11"],
     "deps": ["BOUNDARY_EXTENSION_INCLUSION", "NODE_ADDITION_FORMULA"],
     "deferred": [], "lineage": "script",
     "script": "F48_consolidation_paths", "obs": False,
     "text": "physical node-addition (bonding consumes ports per §6.1) "
              "does not in general yield boundary-extension: a valid "
              "path using port p is destroyed when a new junction "
              "closes p",
     "agg": [{"name": "destroyed-path count", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
    # Workspace (2026-09-28): the §4.3 "each port consumed at most once"
    # lemma (PORT_PARTITION_EXACTNESS) is prose-proved from the §6.1
    # bonding-mode premise ([Depends: Paper 2 §11.1]) plus the Port Status
    # binary — not from the B(G) = |∂G| = 6N − Σ_j k_j identity.
    # staged V3 remediation (2026-10-01; no version built): the pointer named F32_gate alongside F.33-F.35, but
    # F32_gate's own check is the §4.1 structural gate (its banner says so
    # and attributes pairwise-disjoint validation to F.33-F.35's check-2):
    # domain certification of the worked aggregates, not the lemma's
    # at-most-once content. Per the registry-honesty staple the leg is
    # dropped -- this claim's pointer names only the scripts checking the
    # content (F.33-F.35 check-2). F32_gate still runs in the battery as
    # domain certification. Level A conditional on the Port Status binary
    # (as amended: at most one completed junction per port), the §6.1
    # bonding-mode premise, Port Count Invariance, a_k-ordered ledger entries
    # (Paper 2 §4.1, Paper 2 §12.5), and the derivation scope note; the scripts
    # check the enforcement, not the lemma's proof.
    {"id": "PORT_PARTITION_EXACTNESS", "level": "A",
     "axioms": ["L6-P11"],
     "deps": ["PORT_COUNT_INVARIANCE", "TRIPLE_CONVERGENCE_RESOLUTION"], "deferred": [],
     "lineage": "script",
     "script": ["F32_gate", "F33_aggregate_a", "F34_aggregate_b", "F35_aggregate_c"],
     "obs": False,
     "text": "each port of a bonded aggregate is consumed by at most one "
              "junction: the worked aggregates' junction port lists are "
              "pairwise disjoint and exhaustive over the consumed set",
     "agg": [{"name": "per-aggregate port partition (disjoint, exhaustive)",
               "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration.
     "proved_domain": ['port', 'junction', 'node'],
     "claimed_domain": [],
     "coverage_maps": [],},
    # 2026-10-05 (#131): scale-fidelity hybrid claim for the §0.5.v.3
    # Universality claim. Machine half (F.56): 6N strict monotonicity over
    # all positive integers (pure integer arithmetic); the N-threshold sweep
    # over native definition sources (zero unadjudicated hits); the
    # exactness composition (R15 finite sums over exact ops; F.42's float
    # sweep cited, not re-implemented). Author-authorized half: the
    # identification fidelity := extent × exactness (Dervis 2026-10-05),
    # asserted not machine-proved -- stated in the text below, never
    # presented as machine-checked. Deps: PORT_COUNT_INVARIANCE (the 6N
    # anchor) and SINGLE_REGIME (the no-regime side); both are dep-free,
    # so no cycle is introduced.
    {"id": "SCALE_FIDELITY", "level": "A",
     "axioms": ["L2", "L6-P11"],
     "deps": ["PORT_COUNT_INVARIANCE", "SINGLE_REGIME"],
     "deferred": [], "lineage": "script",
     "script": "F56_scale_fidelity", "obs": False,
     "text": "scale fidelity (author-authorized identification: fidelity "
             ":= extent × exactness): at node count N the same rule set "
             "executes 6N ledger entries with zero formal error — 6N "
             "strictly increasing in N over all positive integers (F.56, "
             "pure integer arithmetic); no N-case-split regime in "
             "native definition sources (F.56 sweep); finite composition "
             "of exact integer/rational operations is exact (R15; F.42 "
             "float sweep), so zero formal error at every finite N. The "
             "identification itself is author-authorized (2026-10-05), "
             "asserted not machine-proved",
     "agg": [{"name": "6N ledger entries", "reduction": "count"}],
     # R23 (2026-10-05): quantified-domain coverage declaration. This
     # claim is about N/scale, not aspect kinds: both lists are vacuous
     # by design (adjudicated, changelog #131) -- not force-fit.
     "proved_domain": [],
     "claimed_domain": [],
     "coverage_maps": [],},
]


def word_in(text, word):
    return re.search(r"\b" + re.escape(word) + r"\b", text.lower()) is not None


def r18_violations():
    """R18 (version 11): derivation closure for derived labels. A derived label
    is only as honest as its derivation record. Every entry must satisfy:
    (a) every derives_from label is in AXIOMS — no dangling references;
    (b) the transitive closure of derives_from bottoms out in PRIMITIVE
        and is acyclic — a cycle, or a leaf that is not a primitive, is
        an axiom in disguise;
    (c) theorem-kind labels have non-empty derives_from — a theorem with
        no derivation is an axiom wearing a theorem's badge;
    (d) the section pointer matches a real section heading in paper_11.md;
    (e) the script file exists in scripts/.
    """
    v = []
    for label, rec in DERIVED.items():
        dfs = rec.get("derives_from", [])
        for d in dfs:
            if d not in AXIOMS:
                v.append(f"R18: {label} derives_from dangling label {d}")
        if rec.get("kind") == "theorem" and not dfs:
            v.append(f"R18: {label} theorem with empty derives_from")
        # Transitive closure: walk derives_from through DERIVED; every
        # path must terminate in PRIMITIVE, and no path may return to
        # the label itself.
        visited, frontier, cyclic = set(), list(dfs), False
        while frontier:
            cur = frontier.pop()
            if cur in visited:
                continue
            visited.add(cur)
            if cur == label:
                v.append(f"R18: {label} derivation cycle")
                cyclic = True
                break
            if cur in DERIVED:
                frontier.extend(DERIVED[cur].get("derives_from", []))
        if not cyclic:
            leaves = {c for c in visited if c not in DERIVED}
            bad = sorted(leaves - PRIMITIVE)
            if bad:
                v.append(f"R18: {label} closure leaks to non-primitive {bad}")
        sec = rec.get("section", "")
        if sec and not any(
                re.match(r"^#{2,4} " + re.escape(sec) + r"(?=\s)", l)
                for l in PAPER_MD.splitlines()):
            v.append(f"R18: {label} section pointer {sec} matches no heading")
        script = rec.get("script", "")
        if script and not (HERE / script).exists():
            v.append(f"R18: {label} script {script} missing")
    return v


# R21 old/new verdict helpers (R21 modal-attachment tightening). _r21_old_verdict reproduces
# the original v21 logic exactly (loose substring allowances); _r21_new_verdict
# is the tightened rule the check() body calls. Both are kept so the
# tightening can be re-verified mechanically against every registry claim:
# no genuine claim may newly fail. They are rule logic (control), not inputs.
_R21_SUBJECTS = (r"simple state|complex configuration|boundary port|port|"
                 r"boundary|aspect|junction|interior junction")


def _r21_old_verdict(text):
    """Original v21 R21 verdict (loose): substring allowances."""
    txt = text.lower()
    role_assign = re.search(
        r"\b(simple state|complex configuration|port|boundary port|"
        r"aspect|junction|interior junction)s?\s+(are|is)\s+"
        r"(active|passive)\b", txt)
    intrinsic_word = re.search(
        r"\bintrinsically\s+(active|passive)\b", txt)
    encounter_indexed = ("encounter" in txt) or ("in r" in txt)
    capacity = any(w in txt for w in
                   ("seeking", "capable", "eligible", "can play"))
    if (role_assign or intrinsic_word) and not (
            encounter_indexed or capacity):
        return "R21: intrinsic role assignment without encounter"
    return None


def _r21_new_verdict(text):
    """Tightened R21 verdict: word-boundary subjects (now including bare
    "boundary"); a subject-free "plays the * role" trigger; encounter
    indexing requires a word-boundary "encounter" or "in R" (not the loose
    substring); modal attachment is admitted only in capability-marked
    modal forms ("can play the * role", "is capable of playing/being
    the *", "is eligible for the *"); "seeking" remains an admitted
    standing-state term but only as a whole word."""
    txt = text.lower()
    role_assign = re.search(
        r"\b(" + _R21_SUBJECTS + r")s?\s+(are|is)\s+(active|passive)\b", txt)
    plays_assign = re.search(
        r"\bplays?\s+the\s+(active|passive)\s+role\b", txt)
    intrinsic_word = re.search(
        r"\bintrinsically\s+(active|passive)\b", txt)
    encounter_indexed = bool(re.search(r"\bencounter\b", txt)) or bool(
        re.search(r"\bin\s+r\b", txt))
    modal_attach = bool(re.search(
        r"\b(can play|is capable of (playing|being)|is eligible for)"
        r"\s+the\s+(active|passive)\b", txt))
    seeking = bool(re.search(r"\bseeking\b", txt))
    if (role_assign or plays_assign or intrinsic_word) and not (
            encounter_indexed or modal_attach or seeking):
        return "R21: intrinsic role assignment without encounter"
    return None


# ---- R3 pointer-topicality ----
# R3's honest-basis rule was named but never enforced: the machine checked
# only that the named file exists. These helpers enforce the named rule:
# each "script"-lineage pointer must reference the claim's content.
# KNOWN-SHAPE LIMITATION (stated plainly, also in the module docstring):
# this is a keyword/shape comparison between the claim's identity tokens
# (id + text) and the script's own description of what it checks -- not a
# semantic proof of coverage. It catches gross misassignment (a pointer at
# an existing script whose description never mentions the claim -- the
# CASE_B_COLLIDER shape), not subtle coverage gaps; banner fidelity
# (description matches code) stays human-audit territory. Nothing here
# encodes any expected verdict: the stopword table is generic, the claim
# keywords are derived from the registry row itself, and the banners are
# read off disk. Delete-the-assertion holds (remove the violation appends
# and real tokenization/intersection computation over two independent
# corpora remains); premise-perturbation holds (repointing a claim breaks
# the intersection -- the planted classes prove it).
def _r3_normalize_stems(field):
    """Split a script-pointer field into filename stems.

    Handles the pointer shapes F.49 documents as legal: a plain stem, a
    list of stems, several stems joined by "+", an "F."-style number
    prefix, and a trailing ".py". Empty parts are dropped (the R3
    empty-script rule reports those).
    """
    if isinstance(field, (list, tuple)):
        parts = [str(p) for p in field]
    else:
        parts = str(field).split("+")
    out = []
    for part in parts:
        s = part.strip()
        if s.endswith(".py"):
            s = s[:-3]
        if s.startswith("F."):
            s = "F" + s[2:]
        if s:
            out.append(s)
    return out


def _r3_tokens(text):
    """Significant tokens of a text: lowercase alphanumerics of length >= 3,
    minus the stopword table, with a light plural fold (aspects -> aspect).
    Single letters and digits never constitute a reference on their own."""
    out = set()
    for t in re.findall(r"[a-z0-9]+", text.lower()):
        if len(t) < 3 or t in _R3_POINTER_STOPWORDS:
            continue
        if t.endswith("s") and len(t) > 4 and not t.endswith("ss"):
            t = t[:-1]
        out.add(t)
    return out


def _r3_banner(stem):
    """The script's self-description: its module-level banner strings.

    Every F-script states what it checks as module-level bare string
    literals (a docstring, or a banner after the INPUT_PROVENANCE block).
    Returns "" when the file carries none -- a script that does not say
    what it checks cannot reference a claim.
    """
    if stem in _R3_BANNER_CACHE:
        return _R3_BANNER_CACHE[stem]
    path = HERE / (stem + ".py")
    text = ""
    if path.exists():
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            tree = None
        if tree is not None:
            parts = []
            for node in tree.body:
                if (isinstance(node, ast.Expr)
                        and isinstance(node.value, ast.Constant)
                        and isinstance(node.value.value, str)):
                    parts.append(node.value.value)
            text = "\n".join(parts)
    _R3_BANNER_CACHE[stem] = text
    return text


def _r3_section_refs(text):
    """Paper-section numbers mentioned in text, normalized ("§8.6" and
    "section 8.6" both -> "8.6")."""
    refs = set()
    for m in re.finditer(r"§\s*(\d+(?:\.\d+)*)", text):
        refs.add(m.group(1))
    for m in re.finditer(r"[Ss]ection\s+(\d+(?:\.\d+)*)", text):
        refs.add(m.group(1))
    return refs


def _r23_via_topical(via_path, claim_id):
    """R23 topicality arm (2026-10-05): the via script's text must mention
    the claim id, case- and separator-insensitive ("TRACKING_COST_LEMMA"
    matches "tracking-cost lemma"). Mechanical claim-id mention -- not
    semantic verification of the map (see the M2c diagnostic)."""
    try:
        text = via_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return False
    norm = lambda s: re.sub(r"[_\-\s]+", " ", s.lower()).strip()
    return norm(claim_id) in norm(text)


def _r3_sections_topical(row_secs, banner_secs):
    """Section hierarchy is a tree: a banner section is topical for a row
    section when they are equal or one contains the other at a section
    boundary (e.g. row §10 with banner §10.3, or row §10.3 with banner §10).
    Exact-set matching alone would flag the broader/narrower shape as a
    misassignment -- a false positive, since the banner is about (a part of)
    the claim's section either way."""
    for a in row_secs:
        for b in banner_secs:
            if a == b or a.startswith(b + ".") or b.startswith(a + "."):
                return True
    return False


def _r3_pointer_row_violations(r):
    """R3 pointer-topicality for one registry row.

    For each pointed script that exists on disk, the script's banner must
    share at least one significant token with the claim (id + text), or --
    when the row carries a paper section -- the banner must mention that
    section or a (sub)section of it at a section boundary. A pointer naming
    an existing file whose description does not reference the claim is a
    misassignment, not a verification. Pointers at missing files are skipped
    here; the R3 existence rule reports those.
    """
    v = []
    rid = r["id"]
    claim_toks = _r3_tokens(rid.replace("_", " ") + " " + r.get("text", ""))
    row_sections = (_r3_section_refs(r.get("section") or "")
                    if r.get("section") else set())
    for stem in _r3_normalize_stems(r.get("script", "")):
        if not (HERE / (stem + ".py")).exists():
            continue
        banner = _r3_banner(stem)
        if not banner.strip():
            v.append(f"R3: {rid} pointer {stem} carries no self-description; "
                     f"reference unverifiable")
            continue
        if claim_toks & _r3_tokens(banner):
            continue
        if row_sections and _r3_sections_topical(row_sections,
                                                 _r3_section_refs(banner)):
            continue
        if not claim_toks:
            v.append(f"R3: {rid} pointer {stem}: claim carries no significant "
                     f"keywords; pointer unverifiable")
            continue
        v.append(
            f"R3: {rid} pointer {stem} does not reference the claim "
            f"(misassignment, not a verification) -- claim keywords: "
            f"{', '.join(sorted(claim_toks))}; script banner head: "
            f"{banner.strip().splitlines()[0][:120]!r}")
    return v


def check(reg):
    """Return the list of violation strings; empty means the registry passes."""
    v = []
    v.extend(r18_violations())
    ids = [r["id"] for r in reg]
    if len(ids) != len(set(ids)):
        v.append("duplicate id")
    by_id = {r["id"]: r for r in reg}

    for r in reg:
        i = r["id"]
        if r["level"] not in LEVELS:
            v.append(f"invalid-level: {i}")
        # R3 (v27): honest-basis rule. Every claim carries a lineage:
        # "script" names the machine check (one filename stem, or a list
        # when the claim's content splits across checks, e.g. a port half
        # and a role half); "inherited" names the prior-paper source in
        # "inherited_from"; "prose" names the defining section in
        # "section". A "script" claim must name an existing script file.
        # An "inherited"/"prose" claim must NOT carry a script pointer -
        # pointing at a script that does not check the claim's content is
        # a misassignment, not a verification.
        lineage = r.get("lineage", "script")
        if lineage not in LINEAGE_KINDS:
            v.append(f"R3: {i} unknown lineage kind {lineage!r}")
        elif lineage == "script":
            scripts = (r["script"] if isinstance(r["script"], list)
                       else [r["script"]])
            if not scripts or not all(scripts):
                v.append(f"R3: {i} empty script")
            for s in scripts:
                if s and not (HERE / (s + ".py")).exists():
                    v.append(f"R3: {i} script {s}.py missing")
        else:
            if r["script"]:
                v.append(f"R3: {i} {lineage} claim carries a script pointer")
            if lineage == "inherited" and not r.get("inherited_from"):
                v.append(f"R3: {i} inherited lineage with no source")
            if lineage == "prose" and not r.get("section"):
                v.append(f"R3: {i} prose lineage with no section")
        # R3 inherited-source specificity: any carried inherited_from must
        # be section-specific ("Paper N §M(.K)") in every semicolon-
        # separated chunk, so the badge's basis resolves to a locatable
        # passage. Applies to inherited-lineage rows (which must name a
        # source) and to prose-lineage rows that keep the ultimate
        # inherited source alongside their proof section.
        src = r.get("inherited_from", "")
        if src:
            chunks = [c.strip() for c in src.split(";")]
            if not all(_INHERITED_SOURCE_RE.search(c) for c in chunks):
                v.append(
                    f"R3: {i} inherited source not section-specific: {src!r}")
            # R3 lab-note ban: lab notes are never a valid inherited basis.
            if _LAB_NOTE_RE.search(src):
                v.append(
                    f"R3: {i} inherited source cites lab notes: {src!r}")
            # R3 basis completeness: a multi-source inherited basis must not
            # silently narrow. The complete cited set is pinned from the
            # pristine registry (module level); a strict subset is a
            # basis-narrowing defect with an ID-naming witness.
            pinned = _PINNED_SOURCE_SETS.get(i)
            if pinned is not None:
                live = _inherited_source_chunks(src)
                if live < pinned:
                    v.append(
                        f"R3: {i} inherited basis narrowed "
                        f"(dropped {sorted(pinned - live)}): {src!r}")
        # R3 lab-note ban, text-field arm (2026-10-04 loop repair): a
        # "per the lab notes" sentence inside a claim's text cell evaded
        # the inherited-source arm. Applies to every lineage kind.
        _text = r.get("text", "")
        if _LAB_NOTE_RE.search(_text):
            v.append(
                f"R3: {i} claim text cites lab notes: {_text[:80]!r}")
        # R3 pointer-topicality: naming an existing file is not
        # enough. Each pointed script's self-description must reference the
        # claim -- via the claim id, distinctive claim-text keywords, or
        # the claim's paper section. Known-shape heuristic, not a semantic
        # proof; see the helpers' limitation note.
        if lineage == "script":
            v.extend(_r3_pointer_row_violations(r))
        for a in r["axioms"]:
            if a not in AXIOMS:
                # R13 (v3): an unregistered Paper-11-style label is a hidden
                # postulate, not a mere unknown axiom.
                if re.fullmatch(r"L\d+-P11", a):
                    v.append(f"R13: {i} unregistered Paper-11 label {a}")
                else:
                    v.append(f"R7: {i} unknown label")
        # R13: every cited derived label must have its derivation registered.
        for a in r["axioms"]:
            if a in DERIVED:
                rec = DERIVED[a]
                if not (rec.get("kind") and rec.get("name")
                        and rec.get("section")):
                    v.append(f"R13: {i} derived label {a} has no recorded derivation")
        # R14 (v4): every aspect cited in a claim must resolve to the
        # four-kind inventory. A claim mentioning "aspect" must declare
        # its selector kinds; any kind outside the inventory is a
        # free-floating aspect - a hidden primitive.
        if word_in(r["text"], "aspect"):
            kinds = r.get("aspects", [])
            if not kinds:
                v.append(f"R14: {i} cites aspects but declares no selector kinds")
            for k in kinds:
                if k not in ASPECT_INVENTORY:
                    v.append(f"R14: {i} free-floating aspect kind {k!r}")
        # R15 (v5): aggregate-level content must record its reduction to
        # constituent data; an irreducible quantity is a second regime.
        if AGG_PAT.search(r["text"]):
            agg = r.get("agg", [])
            if not agg:
                v.append(f"R15: {i} cites aggregate-level content with no recorded reduction")
            for q in agg:
                if q.get("reduction") not in AGG_REDUCTIONS:
                    v.append(f"R15: {i} quantity {q.get('name')!r} has reduction "
                             f"{q.get('reduction')!r} - not reducible to constituents")
        for d in r["deps"]:
            if d not in by_id:
                v.append(f"R7: {i} dangling dep {d}")
        for t in r["deferred"]:
            if t not in DEFERRED:
                v.append(f"R5: {i} unknown deferred target {t}")
        if r["obs"] and r["level"] not in ("B", "C"):
            v.append(f"R6: {i} observational flag on level A")
        if r["level"] == "A":
            for t in r["deferred"]:
                v.append(f"R1: {i} level A carries deferred {t}")
            # R10: transitive closure of a Level A claim must be all Level A.
            seen, stack = set(), list(r["deps"])
            while stack:
                d = stack.pop()
                if d in seen or d not in by_id:
                    continue
                seen.add(d)
                if by_id[d]["level"] != "A":
                    v.append(f"R10: {i} reaches non-A {d}")
                stack.extend(by_id[d]["deps"])
            # R9: Paper 11 defined terms require a Paper 11 dependency label.
            if any(word_in(r["text"], t) for t in P11_TERMS):
                if not (set(r["axioms"]) & set(DERIVED)):
                    v.append(f"R9: {i} uses P11 terms without P11 dependency label")
            # R11 (v3): active/passive assignments require the operational
            # role-cut definitions (L7-P11), not the old axiom label.
            if word_in(r["text"], "active") or word_in(r["text"], "passive"):
                if "L7-P11" not in r["axioms"]:
                    v.append(f"R11: {i} active/passive assignment without L7-P11")
            # R12 (refined): whole-configuration identity patterns only.
            if re.search(
                r"\b(simple state|complex configuration)s?\s+(are|is)\s+"
                r"(active|passive)\b", r["text"].lower()
            ):
                v.append(f"R12: {i} role-cut collapse pattern")
            # R21 (tightened modal attachment): roles are encounter-relative (§3.1). A claim
            # text that assigns active/passive to a configuration or a
            # part/aspect without encounter-indexing or modal/seeking
            # language is an intrinsic role assignment and is rejected.
            # The verdict logic lives in _r21_new_verdict (kept beside
            # _r21_old_verdict so the tightening stays mechanically
            # re-verifiable against every registry claim).
            r21v = _r21_new_verdict(r["text"])
            if r21v:
                v.append(f"R21: {i} intrinsic role assignment without encounter")
            # R8: forbidden Register-2 words in Level A text.
            if any(word_in(r["text"], w) for w in FORBIDDEN_NATIVE):
                v.append(f"R8: {i} forbidden native word")
            # R19 (v14): no claim's text may reify the boundary into an
            # object, substance, or primitive. The object-positing phrases
            # live in R19_OBJECT_PHRASES; they are never claim content.
            if any(ph in r["text"].lower() for ph in R19_OBJECT_PHRASES):
                v.append(f"R19: {i} boundary-as-object language in claim text")
            # R23 (2026-10-05): quantified-domain coverage -- the never-again
            # gate for the F.44 defect class (badge/claim domain D vs the
            # script's verified domain S). Every script-lineage Level-A claim
            # declares claimed_domain (aspect kinds its text/badge quantifies
            # over), proved_domain (aspect kinds its backing script(s) actually
            # exercise), and coverage_maps (aspect transfers, each
            # {from, to, via, preserves}). Every claimed kind must be proved
            # or be the target of a valid map: from ⊆ proved_domain,
            # preserves non-empty, via naming an existing script file whose
            # text mentions the claim (pointer-topicality, R3's arm extended
            # to map vias -- an existing but claim-unrelated script cannot
            # launder to-kinds; red-team V2/V7, 2026-10-05). Honest ceiling:
            # topicality is claim-id mention, not semantic verification -- a
            # topical but vacuous map passes by design (the M2c diagnostic).
            # The violation names the uncovered kinds.
            if r.get("lineage") == "script":
                for dk in ("claimed_domain", "proved_domain", "coverage_maps"):
                    if dk not in r:
                        v.append(f"R23: {i} missing domain declaration {dk!r}")
                claimed = r.get("claimed_domain", []) or []
                proved = r.get("proved_domain", []) or []
                for k in list(claimed) + list(proved):
                    if k not in ASPECT_INVENTORY:
                        v.append(f"R23: {i} domain kind {k!r} outside the "
                                 f"aspect inventory")
                covered = set(proved)
                for m in r.get("coverage_maps", []) or []:
                    mfrom = m.get("from", []) or []
                    mto = m.get("to", []) or []
                    via = m.get("via", "") or ""
                    preserves = m.get("preserves", "") or ""
                    via_stem = via[:-3] if via.endswith(".py") else via
                    via_path = HERE / (via_stem + ".py")
                    # Topicality arm (2026-10-05): the via script must exist
                    # AND its text must mention the claim id (case- and
                    # separator-insensitive) -- an existing but unrelated
                    # script cannot launder to-kinds (red-team V2/V7).
                    via_ok = (bool(via_stem) and via_path.exists()
                              and _r23_via_topical(via_path, i))
                    if (set(mfrom) <= set(proved) and mto and via_ok
                            and preserves.strip()):
                        covered.update(mto)
                uncovered = [k for k in claimed if k not in covered]
                if uncovered:
                    v.append(f"R23: {i} claims aspect kinds {uncovered} with no "
                             f"proved coverage or valid coverage map")

    # R16 (v6): Stage-N token firewall + one-way translation (see
    # r16_violations; F.42 reuses it for the dependency half).
    v.extend(r16_violations(reg))

    # R22 (v17/P2): verification-hygiene gate -- the F.33-F.35 placeholder
    # pattern never-again mechanism (F.49). Delegates to F.49.
    v.extend(r22_violations(reg))

    # R14 (v4): defined-token table - "aspect" must be NOT_A_PRIMITIVE and
    # derive only from the primitive set plus the Paper-2 bonding modes.
    # The aspect-specific derivation-source check applies to "aspect" only;
    # "resolution status" is audited by R20 with its own metadata schema.
    for tok, meta in TOKENS.items():
        if not meta["not_a_primitive"]:
            v.append(f"R14: token {tok} registered as primitive")
    if not set(TOKENS["aspect"]["derived_from"]) <= DERIVATION_SOURCES:
        v.append("R14: token 'aspect' derives from outside the primitive set")

    # R20 (v15): resolution-status token integrity.
    v.extend(r20_resolution_status_check())

    # R4: dependency graph must be acyclic.
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {i: WHITE for i in ids}

    def dfs(u, path):
        color[u] = GRAY
        for d in by_id[u]["deps"]:
            if d not in color:
                continue
            if color[d] == GRAY:
                v.append(f"R4: cycle {' -> '.join(path + [d])}")
            elif color[d] == WHITE:
                dfs(d, path + [d])
        color[u] = BLACK

    for i in ids:
        if color[i] == WHITE:
            dfs(i, [i])

    # R2: a Level B claim must propagate its ancestors' deferred targets.
    for r in reg:
        if r["level"] == "B":
            seen, stack, anc_def = set(), list(r["deps"]), set()
            while stack:
                d = stack.pop()
                if d in seen or d not in by_id:
                    continue
                seen.add(d)
                anc_def.update(by_id[d]["deferred"])
                stack.extend(by_id[d]["deps"])
            if not anc_def.issubset(set(r["deferred"])):
                v.append(f"R2: {r['id']} missing propagated deferred target")

    return v


def get(cid, reg):
    for r in reg:
        if r["id"] == cid:
            return r
    raise KeyError(cid)


def _inherited_source_chunks(src):
    """Normalized cited-source chunk set of an inherited_from string."""
    return frozenset(c.strip() for c in src.split(";") if c.strip())


# R3 basis-completeness pin (2026-10-04): for every registry row carrying a
# multi-source inherited_from, the complete cited basis is pinned from the
# pristine REGISTRY (derived, never hardcoded per claim; inherited and prose
# lineages alike). check() rejects a strict subset as silent basis
# narrowing. Single-source rows cannot narrow by dropping and are skipped.
_PINNED_SOURCE_SETS = {
    r["id"]: _inherited_source_chunks(r["inherited_from"])
    for r in REGISTRY
    if r.get("inherited_from")
    and len(_inherited_source_chunks(r["inherited_from"])) > 1
}


# ---- Direction 1: clean registry must pass ----
clean_violations = check(REGISTRY)
assert not clean_violations, f"clean registry failed: {clean_violations}"
print("F.38 PASS: clean registry (%d claims) satisfies R1-R23." % len(REGISTRY))

# ---- Direction 2: thirty-three planted test classes must all be rejected ----
rejected = 0

def poisoned(mutate, expect):
    global rejected
    reg = deepcopy(REGISTRY)
    mutate(reg)
    vs = check(reg)
    assert vs, "planted test case passed undetected"
    assert any(expect in s for s in vs), f"expected {expect}, got {vs}"
    rejected += 1

poisoned(lambda r: get("RELATIONAL_ROLE_THEOREM", r).update(deferred=["P16"]), "R1")
poisoned(lambda r: get("SIMPLE_STATE_INSULATION", r).update(obs=True), "R6")
poisoned(lambda r: get("ROLE_CUT_INDEPENDENCE", r).update(deps=["MISSING"]), "R7")
poisoned(lambda r: get("PORT_COUNT_INVARIANCE", r).update(axioms=["UNKNOWN"]), "R7")
poisoned(lambda r: get("COMPLEX_BOUNDARY_ACTIVE", r).update(script=""), "R3")
# R3 inherited-source specificity: a sectionless inherited source is not
# a resolvable basis -- "Paper 10" names a whole paper, no passage.
poisoned(lambda r: get("PORT_COUNT_INVARIANCE", r).update(
    inherited_from="Paper 10"), "R3")
# R3: an emptied inherited source is rejected (the no-source rule fires).
poisoned(lambda r: get("PORT_COUNT_INVARIANCE", r).update(
    inherited_from=""), "R3")
# R3 basis completeness (2026-10-04): dropping one cited passage from a
# multi-source inherited basis is silent basis narrowing, not a
# simplification. The live four-source basis of
# TRIPLE_CONVERGENCE_RESOLUTION is pinned from the pristine registry; the
# three-source mutant must be rejected with an ID-naming witness.
poisoned(lambda r: get("TRIPLE_CONVERGENCE_RESOLUTION", r).update(
    inherited_from="Paper 2 §8.1; Paper 2 §11.1; Paper 3 §7"), "R3")
# R3 lab-note ban (2026-10-04): lab notes are never a valid inherited
# basis. The parenthetical smuggle passes the section-specificity shape
# (a .search()), so only the ban catches it -- the mutant is silent
# pre-ban and rejected post-ban, with an ID-naming witness.
poisoned(lambda r: get("TRIPLE_CONVERGENCE_RESOLUTION", r).update(
    inherited_from="Paper 2 §8.1; Paper 2 §11.1; Paper 3 §7; "
                   "Paper 3 §8.5 (lab notes)"), "R3")
# R3 lab-note ban, text-field arm (2026-10-04 loop repair): a lab-note
# string smuggled into a claim's text cell evaded the inherited-source
# arm. The underscore spelling ("lab_note") evaded the old char class
# too -- this mutant exercises both arms at once, and is rejected with
# an ID-naming witness.
poisoned(lambda r: get("TRIPLE_CONVERGENCE_RESOLUTION", r).update(
    text=get("TRIPLE_CONVERGENCE_RESOLUTION", r)["text"]
         + " Per the lab_note records, the products resolve this way."),
    "R3")
# R3 specificity positive control: multi-source inherited rows pass --
# PHOTON_BASELINE's live "Paper 2 §5; Paper 10 §2.1" is section-specific
# in every chunk, so the clean registry stays green.
assert all(_INHERITED_SOURCE_RE.search(c)
           for c in "Paper 2 §5; Paper 10 §2.1".split(";")), \
    "R3 specificity control broken: live multi-source shape rejected"
assert not _INHERITED_SOURCE_RE.search("Paper 10"), \
    "R3 specificity mutant shape broken: sectionless source matched"
# R3 pointer-topicality: a pointer naming an EXISTING script
# whose self-description does not reference the claim is a misassignment,
# not a verification.
# Plant 1: repoint COMPLEXITY_ORDERING (§12.1 ordering) at F.34
# (aggregate-(b) per-aspect s^2 decomposition) -- the CASE_B_COLLIDER
# shape. F.34's banner shares no significant token with the claim; the
# rejection must carry a printed witness.
poisoned(lambda r: get("COMPLEXITY_ORDERING", r).update(
    script="F34_aggregate_b"), "R3")
# Plant 2: multi-script pointer with one unrelated member.
# COMPLEX_BOUNDARY_ACTIVE is honestly checked by F.33/F.34/F.35/F.39;
# appending F.51 (registry<->E.2 drift sweep -- nothing about boundary
# roles) must be rejected even though the other four members pass.
def _plant_r3_multiscript(r):
    row = get("COMPLEX_BOUNDARY_ACTIVE", r)
    row["script"] = list(row["script"]) + ["F51_registry_e2_drift"]
poisoned(_plant_r3_multiscript, "R3")
# Plant 3 (anti-round-trip mutant, a different claim/script pair from the
# plants above): SHOVE_DIRECTION (§7 shove) repointed at F.40 (aspect
# inventory). The check must catch repointings in general, not just the
# planted shape -- premise-perturbation holds.
poisoned(lambda r: get("SHOVE_DIRECTION", r).update(
    script="F40_aspect_inventory"), "R3")
poisoned(lambda r: r.append(deepcopy(get("RESOLUTION_VERB", r))), "duplicate")
poisoned(lambda r: get("CASE_A_LADDER", r).update(deferred=["UNKNOWN_TARGET"]), "R5")
poisoned(lambda r: get("SHOVE_DIRECTION", r).update(level="Z"), "invalid-level")
poisoned(lambda r: get("TENSION_RELIEF", r).update(text="continuum metric leakage"), "R8")
# v27: still the R4 cycle test - PROXIMITY_SCALING (now checked by
# F.45) still depends on INTERACTION_TAXONOMY (F.36), so appending the
# reverse edge closes a 2-cycle and must be rejected.
poisoned(lambda r: get("INTERACTION_TAXONOMY", r)["deps"].append("PROXIMITY_SCALING"), "R4")
poisoned(lambda r: get("COMPLEX_BOUNDARY_ACTIVE", r).update(axioms=["L6-P11"]), "R11")
poisoned(lambda r: get("DUAL_RESPONSE_MODES", r).update(text="simple states are passive"), "R12")
# MACHINERY-START: planted R21 test case (independent literal R21 plant).
# The string below is the test's mutation, never registry content: a bare
# intrinsic role assignment must be rejected by R21 on its own, not only
# via the R12-adjacent case above.
poisoned(lambda r: get("COMPLEX_BOUNDARY_ACTIVE", r).update(
    text="every boundary port is intrinsically active"), "R21")
# MACHINERY-END
# v50: L10-P11 is now registered, so the R13 plant's unregistered-label
# specimen is re-pointed from L10-P11 to L11-P11 (the plant must remain a
# genuine unregistered-label violation).
poisoned(lambda r: get("RESOLUTION_VERB", r).update(axioms=["L11-P11"]), "R13")
poisoned(lambda r: get("COMPOUND_CLOSED_LOOP_COHERENCE", r).update(aspects=["port", "facet"]), "R14")
poisoned(lambda r: get("AGGREGATE_A_DECOMPOSITION", r).update(
    agg=[{"name": "EMERGENT_COHESION", "reduction": "primitive"}]), "R15")
poisoned(lambda r: get("RELATIONAL_ROLE_THEOREM", r).update(
    text="roles are operational labels on aspect-port states at a tick with step length ℓ₀"), "R16")

def poisoned_derived(mutate, expect):
    """Planted test case against the DERIVED table itself (R18): mutate the
    derivation records, run r18_violations, restore."""
    global rejected
    saved = deepcopy(DERIVED)
    mutate(DERIVED)
    vs = r18_violations()
    DERIVED.clear()
    DERIVED.update(saved)
    assert vs, "planted test case passed undetected"
    assert any(expect in s for s in vs), f"expected {expect}, got {vs}"
    rejected += 1


# R18 (version 11): five planted derivation-record test cases.
# A theorem with no derivation is an axiom in disguise (the v1 sin).
poisoned_derived(lambda d: d["L5-P11"].update(derives_from=[]), "R18")
# v50: L10-P11 is now registered, so the R18 plant's nowhere-resolving
# derives_from entry is re-pointed from L10-P11 to L11-P11 (the plant
# must remain a genuine dangling-reference violation).
poisoned_derived(lambda d: d["L5-P11"]["derives_from"].append("L11-P11"), "R18")
# A section pointer to a section that does not exist.
poisoned_derived(lambda d: d["L5-P11"].update(section="§99.9"), "R18")
# A derivation cycle: L6 -> L7 -> L6 (L7 already derives from L6).
poisoned_derived(lambda d: d["L6-P11"]["derives_from"].append("L7-P11"), "R18")
# A script pointer to a script that does not exist.
poisoned_derived(lambda d: d["L7-P11"].update(script="F99_missing.py"), "R18")

# MACHINERY-START: planted R19 test case (v14). The string
# below is the test's mutation, never registry content.
poisoned(lambda r: get("COMPLEX_BOUNDARY_ACTIVE", r).update(
    text="the boundary is a positive aggregate surface"), "R19")
# MACHINERY-END

def poisoned_token(mutate, expect):
    """Planted test case against the TOKENS table itself (R20): mutate the
    audited resolution-status metadata, run the R20 check, restore."""
    global rejected
    saved = deepcopy(TOKENS)
    mutate(TOKENS)
    vs = r20_resolution_status_check()
    TOKENS.clear()
    TOKENS.update(saved)
    assert vs, "planted test case passed undetected"
    assert any(expect in s for s in vs), f"expected {expect}, got {vs}"
    rejected += 1

# MACHINERY-START: planted R20 test case (v15). The mutation
# below is the test's, never registry content: a scalar degree smuggled into
# the audited resolution-status domain must be rejected.
poisoned_token(lambda t: t["resolution status"].update(domain={0, 1, 2}), "R20")
# MACHINERY-END

# MACHINERY-START: planted R22 test case (v17/P2). The mutation below is
# the test's, never registry content: a temporary directory is built
# containing the REAL F.49 plus a poisoned Level-A-backing script carrying
# a WORD violation; r22_violations must reject it. This proves R22 is not
# vacuous (it delegates to a working F.49, not a stub).
import tempfile
def _poisoned_r22():
    global rejected
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        # Copy the real F.49 into the temp dir.
        shutil.copy(str(HERE / "F49_verification_hygiene.py"),
                    str(tmp / "F49_verification_hygiene.py"))
        # Poisoned script: claims a Level-A badge but uses placeholder language.
        # It carries a DOMAIN block and the row carries domain fields, so
        # Check 5 (domain cross-check) passes on the fixture -- the R22
        # violation must come from Check 1 (WORD), proving R22 delegates to
        # a working F.49 rather than firing on missing declarations.
        poisoned_script = tmp / "F99_poisoned.py"
        poisoned_script.write_text(
            '"""Poisoned."""\n'
            'INPUT_PROVENANCE = {"x": {"class": "control", "note": "x"}}\n'
            'DOMAIN = {"proved": [], "notes": "fixture: no aspect kinds"}'
            '\n'
            'x = 1\n'
            '# illustrative placeholder: this is an invented magnitude\n'
            'assert x == 1\n'
        )
        # Minimal registry pointing at the poisoned script.
        reg = [{"id": "POISONED_CLAIM", "level": "A", "axioms": [], "deps": [],
                "deferred": [], "lineage": "script", "script": "F99_poisoned",
                "obs": False, "text": "poisoned",
                "claimed_domain": [], "proved_domain": [],
                "coverage_maps": []}]
        vs = r22_violations(reg, root=tmp)
        assert vs, "R22 planted test case passed undetected"
        assert any("R22" in s for s in vs), f"expected R22, got {vs}"
        rejected += 1
_poisoned_r22()
# MACHINERY-END

# R23 (2026-10-05): quantified-domain coverage battery. The never-again gate
# for the F.44 defect class: a claim badged over aspect kinds its script
# never exercises must be rejected, and a genuine coverage map must pass.
# M1: the F.44 shape -- claimed over all four aspect kinds, proved ["port"],
# no coverage maps. Must be REJECTED with the uncovered kinds named.
poisoned(lambda r: get("TRACKING_COST_LEMMA", r).update(
    claimed_domain=["port", "junction", "node", "whole"]), "R23")
# M2a (passing control, not counted): a shape-valid, topical coverage map --
# from ⊆ proved, non-empty preserves, via an existing script whose text
# mentions the claim (topicality arm) -- admits the to-kinds. Must PASS with
# no R23 violation. Ceiling note: claim-id mention is mechanical, not semantic
# verification of the map (see M2c).
def _r23_m2a_control():
    reg = deepcopy(REGISTRY)
    row = get("TRACKING_COST_LEMMA", reg)
    row.update(
        claimed_domain=["port", "junction"],
        coverage_maps=[{"from": ["port"],
                        "to": ["junction"],
                        "via": "F44_tracking_cost",
                        "preserves": "port-level cost summed over the "
                                     "junction's consumed ports"}])
    vs = check(reg)
    assert not any("R23" in s for s in vs), f"R23 M2a control failed: {vs}"
    print("F.38 R23 M2a control PASS: topical coverage map admits to-kinds.")
_r23_m2a_control()
# M2b (counted rejection): via an existing but claim-unrelated script -- the
# red-team V2/V7 laundering shape (2026-10-05). F40_aspect_inventory exists
# but its text never mentions TRACKING_COST_LEMMA, so the topicality arm
# rejects the map and names the uncovered kind.
poisoned(lambda r: get("TRACKING_COST_LEMMA", r).update(
    claimed_domain=["port", "junction"],
    coverage_maps=[{"from": ["port"], "to": ["junction"],
                    "via": "F40_aspect_inventory",
                    "preserves": "port-level cost attribution over the "
                                 "inventory model"}]), "R23")
# M2c (labeled diagnostic, passes by design -- NOT counted as a rejection):
# a shape-valid, topical map whose preserves string is vacuous hand-waving.
# It passes because the gate checks shape (claim-id mention), not semantic
# genuineness. The honest ceiling, demonstrated -- never printed as REJECTED
# or counted among rejections (V18 diagnostic-labeling staple).
def _r23_m2c_diagnostic():
    reg = deepcopy(REGISTRY)
    row = get("TRACKING_COST_LEMMA", reg)
    row.update(
        claimed_domain=["port", "junction"],
        coverage_maps=[{"from": ["port"], "to": ["junction"],
                        "via": "F44_tracking_cost",
                        "preserves": "the transfer holds as the via script "
                                     "shows"}])
    vs = check(reg)
    r23_vs = [s for s in vs if "R23" in s]
    assert not r23_vs, f"M2c diagnostic unexpectedly rejected: {r23_vs}"
    print("F.38 R23 M2c diagnostic (passes by design): topical-but-vacuous "
          "map admitted -- the shape/semantic ceiling, demonstrated not "
          "declared.")
_r23_m2c_diagnostic()
# M3: empty preserves -- a map stating nothing it preserves is not a
# coverage map. Must be REJECTED.
poisoned(lambda r: get("TRACKING_COST_LEMMA", r).update(
    claimed_domain=["port", "junction"],
    coverage_maps=[{"from": ["port"], "to": ["junction"],
                    "via": "F40_aspect_inventory", "preserves": ""}]), "R23")
# M4: via a nonexistent script -- a map checked by nothing is not a
# coverage map. Must be REJECTED.
poisoned(lambda r: get("TRACKING_COST_LEMMA", r).update(
    claimed_domain=["port", "junction"],
    coverage_maps=[{"from": ["port"], "to": ["junction"],
                    "via": "F99_no_such_script",
                    "preserves": "nothing machine-checks this"}]), "R23")
# R23 LIVE REGRESSION (2026-10-05): the pre-fix TRACKING_COST_LEMMA
# registration -- the aspect-level lemma ("An aspect's s^2 contribution
# ...", claimed over all four aspect kinds) backed by the port-level
# script (proved ["port"]), with no coverage map -- run through R23 must
# FAIL loudly, naming the three uncovered kinds. This is the exact shape
# the auditor's HIGH claim identified; the gate must catch it.
_pre_fix = deepcopy(get("TRACKING_COST_LEMMA", REGISTRY))
_pre_fix.update(claimed_domain=["port", "junction", "node", "whole"],
                proved_domain=["port"],
                coverage_maps=[],
                text="aspect s^2 contribution is the temporal-scan cost of "
                     "tracking its departure: exactly 0 when resolved, "
                     "nonnegative otherwise")
_reg_pre = [r for r in deepcopy(REGISTRY)
            if r["id"] != "TRACKING_COST_LEMMA"] + [_pre_fix]
_pre_vs = check(_reg_pre)
assert any("R23" in s and "TRACKING_COST_LEMMA" in s and "junction" in s
           for s in _pre_vs), \
    "R23 live regression failed: pre-fix registration not rejected"
print("F.38 R23 LIVE REGRESSION PASS: pre-fix aspect-level registration "
      "rejected, uncovered kinds named.")

# R3 pointer-topicality converse control: honestly pointed rows must pass.
# Pinned against the real registry -- after the V3 remediation (2026-10-01; the
# CASE_B_COLLIDER re-point at F.53 and the LITHIUM_SODIUM_ILLUSTRATION prose
# repair completing #91; the staged PORT_PARTITION_EXACTNESS F32_gate leg drop
# was REVERTED per the author's ruling in changelog #112 -- the leg stays
# pending his word) no row flags. Any flag is a misassignment and fails loudly here.
_flagged = sorted(r["id"] for r in REGISTRY
                  if r.get("lineage") == "script"
                  and _r3_pointer_row_violations(r))
assert _flagged == [], _flagged

# R3 pointer-topicality unit probes (direct helper tests, not poisoned
# registries). Boilerplate alone never constitutes a reference...
assert _r3_tokens(
    "Paper 11 machine check claim registry section level audit") == set()
assert _r3_tokens("collider outputs under forcing") == {
    "collider", "output", "forcing"}
# ...and the section channel works when keywords miss (dormant on the real
# registry: no script-lineage row carries a section). F.45's banner names
# Section 8.5, so a keyword-empty row citing §8.5 is referenced; §99.9 is
# not. The probe dicts are inline literals, not module-level bindings.
assert not _r3_pointer_row_violations(
    {"id": "SEC_PROBE", "lineage": "script",
     "script": "F45_proximity_scaling", "text": "zzz qqq",
     "section": "§8.5", "obs": False}), "section channel misfired"
assert _r3_pointer_row_violations(
    {"id": "SEC_PROBE", "lineage": "script",
     "script": "F45_proximity_scaling", "text": "zzz qqq",
     "section": "§99.9", "obs": False}), "wrong section passed undetected"

# Labeled diagnostic (passes BY DESIGN -- not a rejection, never counted):
# the rule's boundary. A well-worded-but-wrong banner -- the claim's topic
# mentioned, the claim's content unchecked -- shares topical tokens and
# passes this rule. Banner fidelity (description matches code) stays
# human-audit territory. Reported as a diagnostic, never as a rejection.
_diag_claim = _r3_tokens("CASE_B_COLLIDER collider outputs under forcing")
_diag_banner = _r3_tokens(
    "Collider outputs under forcing: a case-B regime study. "
    "This script enumerates junction arity histograms for aggregate (b).")
assert _diag_claim & _diag_banner, "diagnostic setup broken"
print("F.38 diagnostic (passes by design): well-worded-but-wrong banner "
      "shares topical tokens %s -- the rule is topicality, not semantic "
      "coverage; banner fidelity stays human-audit territory."
      % sorted(_diag_claim & _diag_banner))

assert rejected == 37, rejected
print("F.38 PASS: all 37 planted test classes rejected.")

# R3 section-hierarchy regression test (red-team 2026-10-01): the section
# channel respects the section tree -- a banner naming a (sub)section of the
# row's section at a section boundary is topical, not a misassignment.
# Both directions must pass; a banner naming an unrelated section must fail.
assert _r3_sections_topical({"§10"}, {"§10.3"})
assert _r3_sections_topical({"§10.3"}, {"§10"})
assert _r3_sections_topical({"§8.6"}, {"§8.6"})
assert not _r3_sections_topical({"§10"}, {"§11.3"})
assert not _r3_sections_topical({"§10"}, {"§1"})
assert not _r3_sections_topical({"§10.3"}, {"§10.30"})
print("F.38 PASS: R3 section-hierarchy topicality (6/6 probes).")
