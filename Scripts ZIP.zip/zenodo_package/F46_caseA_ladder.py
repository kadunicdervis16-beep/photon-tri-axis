
INPUT_PROVENANCE = {
    "AGG_VECS": {"class": "paper-defined", "source": "§9.4 (consumption-construction robustness)"},
    "CATEGORIES": {"class": "paper-defined", "source": "§8.6 (categorical taxonomy: X<->Y complementary, O pairs with nothing)"},
    "E0_OK": {"class": "control", "note": "test fixture: E0-OK flag"},
    "OUTSIDE": {"class": "paper-defined", "source": "§5.1 Table 5.1 (Outside Content boundary tuples)"},
    "OutsideDomain": {"class": "control", "note": "exception class for domain errors"},
    "RUNG_ORDER": {"class": "paper-defined", "source": "§9.7 (ladder generalization)"},
    "SEEDS": {"class": "control", "note": "random seeds for reproducibility"},
    "TH": {"class": "declared-assumption", "prose": "§8.6 (TH=1 is Paper 14's locked debt)"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "categorical counting; backing claims quantify over no aspect kinds.",
}
#!/usr/bin/env python3
"""
F.46-final -- Case A ladder, complete: base checks + sequential chain +
==========================================================================
9! order-robustness sweep + aggregate-(b) completion. CATEGORICAL throughout.
WIRED IN as F.46 (scripts/F46_caseA_ladder.py) for the v30 build. The
discussion gate with Dervis (2026-09-25) preceded wiring-in. This script
checks the Section 9 ladder work; it does not modify the paper or any
existing script.

RUNNER NOTE (2026-09-25): the script inserts the draft root (parent of
scripts/) into sys.path at import time, so it runs from any cwd with no
PYTHONPATH; its two staged dependencies are v14_blitz_f46_categorical.py
and v14_f46_caseA_ladder.py (E0 reference), both in the draft root.

LABEL-ISOMORPHISM STATEMENT
---------------------------
Port values are CATEGORICAL: X-dominant, Y-dominant, O (neutral). There is
no "+1 of X" and no "-1 of X". Complementarity is the categorical X<->Y
pairing; O pairs with nothing. The machine labels {+1, -1, 0} are
IMPLEMENTATION LABELS ONLY, related to the native categories by the
bijection
    +1 <-> X,   -1 <-> Y,   0 <-> O
with ZERO SEMANTIC CONTENT: no code path in this script adds, orders,
multiplies, or squares label values. Every residue, verdict, tension value,
ledger identity, and chain-trajectory value is a function of
category-membership COUNTS alone (how many X, how many Y); counts are
natural numbers, not port values. The bijection appears in exactly one
clearly-marked adapter section of the imported base module, used solely for
the mechanical outcome-isomorphism check against the E0 run. Relabeling
changes no verdict: the isomorphism is exact, verified case-by-case.

NATIVE DOMAIN
-------------
Section 8.6 encounters between a simple state's presented boundary ports
(categorical values X/Y/O) and a complex configuration's presented
boundary; the residue res(A,B) = #{X in A with no Y-partner in B} + #{Y in
A with no X-partner in B}; presented tension T = count of non-O
presentations on both sides (the paper's T = sum x^2, since a port
contributes 1 iff it is non-O); the selection rule
    res(A,B) > TH  -> forced decay
    res(A,B) = 0   -> attraction (the completed junction strictly reduces T)
    otherwise      -> repulsion
with the domain guard "incoming A presents at least one non-O port" (an
all-O incoming side is REFUSED, never scored); the Section 9.7
incorporation ledger (N, J, B, s^2) via B(G) = 6N - sum(k_j); and the
Phase-C SEQUENTIAL CHAIN: the first-encounter rule applied step by step as
states incorporate into a growing aggregate, under the disclosed chain
protocol below.

VERIFIED DOMAIN
---------------
Exact categorical pairing logic over category-membership counts: the
residue formula, the branch trichotomy at TH = 1 (Paper 14's locked debt -- declared assumption),
matched-pair counts, tension strict-decrease, permutation (zero-leak)
invariance, the ledger identities, the mechanical outcome-isomorphism with
the E0 run, the chain-update factorization (proved below, checked in [9]),
the distinguished chain trajectory, the 9! x 3-seed order-robustness sweep
(1,088,640 chain runs), the aggregate-(b) completion (normalized
convention, all nine states including State 5, 81-case marginal
enumeration), and the planted-mutant rejections M1-M7.

MAP (native -> verified)
------------------------
  1. Documented table letters -> native categories directly: X, Y, O are
     read off Table 5.1's Outside Content as categories (no integer
     encoding step exists in this script).
  2. Presented tuple -> category count vector (nX, nY). The Section 8.6
     rule factors through counts (F.36 coverage theorem); this script
     independently checks order invariance on every worked tuple by
     permutation (zero-leak): shuffling port order never changes counts,
     residue, or verdict -- and the chain trajectory with it ([9d]).
  3. Nucleus (a) boundary -> category count vector under three documented
     single-port consumption choices (consume one O / X / Y per node).
     Nucleus (b) boundary -> category count vector under the workers'
     documented consumption choices, plus the Phase-C NORMALIZED
     consume-O-per-node convention (stated exactly in [13]).
  4. Section 9.7 incorporation -> one new junction aspect of arity 2m
     (working geometry, documented; the paper gives no fixed incorporation
     rule). The ledger is then pure port accounting, checked two ways.
  5. Sequential chain -> count-vector update (proved below): the aggregate
     is carried as a count vector (xN, yN, oN); each step's res, m,
     outcome, and post-step counts are pure functions of count vectors.
  6. E0 machine run -> categorical run via the label bijection (adapter
     section of the base module only): every E0 integer tuple is
     translated to categories and re-scored; counts, residues, and
     verdicts must agree exactly.

MARGINAL-REPULSION REPRODUCTION NOTE (side of consumption)
---------------------------------------------------------
The 81-case marginal enumeration (9 states x 9 (c5,c6) consumption
choices) yields exactly 7 marginal cases (res = TH = 1 -> repulsion),
all published with full disclosure: state 1 with (X,X); state 5 with
(X,X); state 6 with (Y,Y); state 7 with (X,X); state 8 with (Y,Y); state
9 with (X,X); state 9 with (Y,Y) -- the remaining 74 cases attract and 0
force-decay (the 74/7/0 distribution is machine-asserted, not merely
printed). To reproduce: for each (c5,c6), build the nucleus boundary as
base.nucleus_b_cat(c5, c6) -- exactly one port of the named category
consumed from each of States 5 and 6 by the aggregate's OWN junction --
while the incoming state presents its verified Outside Content WHOLE
(base.OUTSIDE[s], unmodified); score with base.encounter_cat. The
workers' (X,X) consumption choice yields the nucleus boundary tuple
(2,4): one X-valued port consumed from each of States 5 and 6, four
Y-valued ports remaining presented. This (2,4) is the verified correct
tuple: nucleus_b_cat returns only the (X,Y) count vector -- O ports are
never read, so there is no O-component to carry. A three-component
reading such as (2,4,2) misreads the O-component (it is not 2; it is
absent). The implementation is unambiguous: nucleus_b_cat removes
exactly the named consumed port from each of STATE5_OUTSIDE and
STATE6_OUTSIDE and counts what remains; the incoming side is
base.OUTSIDE[s] whole. Consult the wrong slot (a consumption choice the
workers never made) and you get a different verdict -- the note states
which slot was used.

WHAT THE MAP PRESERVES
----------------------
Category counts, residue values, selection-branch outcomes, tension strict-
decrease, the ledger identities, the chain trajectories, the sweep
distributions, and the mutant rejections. A wrong boundary tuple, a
swapped outcome label, an off-by-one junction arity, a guardless all-O
incoming, a net-sum residue (M5), an order-dependent positional pairing
(M6), or a net-sum chain residue (M7) each break a preserved identity and
are REJECTED below with printed witnesses (planted mutants M1-M7).

CHAIN FACTORIZATION (C2a -- proved here, machine-checked in [9])
---------------------------------------------------------------
Claim: the entire sequential-chain trajectory (every step's res, m,
outcome, counts, tension, B) is a pure function of the initial count
vector and the incorporation order -- no tuple order, no port labels, no
other structure enters.

Lemma 1 (res factors through counts).
res(A,B) = max(0,xA-yB) + max(0,yA-xB) reads only the count vectors
(xA,yA), (xB,yB): the count of A's X-ports with no Y-partner in B is
max(0, xA - yB), because each of B's yB Y-ports claims at most one of A's
xA X-ports -- a cardinality statement, never arithmetic on labels -- and
symmetrically for Y. The permutation zero-leak tests ([2]) confirm port
order is never read: the count-vector formula and explicit tuple pairing
agree on every worked tuple and every shuffle. Hence res(I,N) is a pure
function of the two count vectors.

Lemma 2 (the update maps count vectors to count vectors).
m = min(xN,yI) + min(yN,xI) is a pure function of the count vectors, so
the post-incorporation triple (xN+xI-m, yN+yI-m, oN+oI) is a pure function
of the two input count vectors. It is a VALID count vector: m <= xN+xI
(because min(xN,yI) <= xN and min(yN,xI) <= xI) gives xN+xI-m >= 0, and
m <= yN+yI (because min(xN,yI) <= yI and min(yN,xI) <= yN) gives
yN+yI-m >= 0. Checked against explicit greedy pairing on 300 random
multiset pairs in [9b].

Lemma 3 (res + m = u_I). max(0,a-b) + min(a,b) = a for all nonnegative
integers a, b; applying twice, res(I,N) + m = xI + yI = u_I, the incoming
side's non-O count. Checked over 9 states x 4 aggregate vectors in [9a].

Theorem (induction). Let C_0 be the initial count vector and I_1..I_k the
incorporated states' count vectors in order. Step t applies Lemmas 1-2 to
(C_{t-1}, I_t): the outcome (attraction / repulsion / forced decay) is a
pure function of (C_{t-1}, I_t) via res, and C_t is either the count-vector
update of (C_{t-1}, I_t) (attraction) or C_{t-1} unchanged (repulsion /
forced decay). Hence C_t, and every step's res/m/outcome/tension/B, is a
pure function of (C_0, I_1..I_t). By induction the FULL trajectory is
determined by the initial counts plus the incorporation order. QED.

What the proof does NOT claim: that the incorporation update is the
paper's rule (the paper states no fixed incorporation rule -- the update
is a disclosed working construction, Level B); that the chain's physical
reading is derived (it is an illustration of the counting); or that TH's
exact value is known (Paper 14's locked debt). The machine check covers
the arithmetic trajectory GIVEN the premises; the premises stay Level B.

CHAIN PROTOCOL (C2b -- defined explicitly, disclosed)
-----------------------------------------------------
At each step the incoming state I, count vector (xI,yI,oI) with
u_I = xI+yI >= 1 for all nine states (the domain guard never fires inside
the chain -- asserted in the runner), meets the current aggregate N,
count vector (xN,yN,oN). Compute res = res(I,N) and m = matched pairs.
  res = 0      -> ATTRACTION: incorporate via the update
                  (xN+xI-m, yN+yI-m, oN+oI); the junction closes 2m ports;
                  node count Nn += 1; junction-arity sum Sk += 2m; continue.
  0 < res <= TH -> REPULSION: NO incorporation; aggregate, Nn, Sk
                  unchanged; continue with the next state.
  res > TH     -> FORCED DECAY: recorded (step, state, res); NO
                  incorporation; aggregate unchanged; continue.
TH = 1 (Paper 14's debt, declared assumption); RAW res values are recorded at every
step so TH-sensitivity is exactly analyzable (the max_res histogram in
[12] gives the complete TH-sensitivity picture: attraction is res = 0,
hence TH-INDEPENDENT; only the repulsion/decay split among non-attraction
steps moves with TH). Termination: at most 9 incorporations -- trivial,
stated and asserted.

Chain tension: T_before = u_N + u_I (presented tension of the encounter);
on attraction T_after = T_before - 2m = u of the new aggregate (strictly
less: res = 0 gives m = u_I >= 1 by Lemma 3); on repulsion/forced decay
T_after = T_before. Boundary invariant per step: B = x+y+o = 6*Nn - Sk.

TOTALITY
--------
Analytic, not enumerative: for any nonnegative integer res (a count) and
any TH with 0 < TH, exactly one of the three branches fires (trichotomy
over the nonnegative integers). The encounter space here is bounded and
stated honestly: 9 states x 3 nucleus-(a) constructions = 27 runs, the
positron mirror, the aggregate-(b) cases (workers' 12 documented + 3
marginal + Phase-C 9 normalized including State 5 + 81-case marginal
enumeration), the distinguished chain, and the 9! x 3-seed sweep
(1,088,640 chain runs, every incorporation order, per-order outcomes and
final aggregates recorded). Exhaustiveness is claimed over the worked set
and over the full order space of the chain -- not over the encounter
space. The TH band [1, k-1] is held by F.36, not re-proved here.

WHAT STAYS OUTSIDE THE MACHINE CHECK
------------------------------------
The physical premises the categorical logic is conditional on: that real
simple-state boundaries present X/Y/O-valued tuples at all (Level B -- the
math-to-physics map; the Outside-Content equation itself is a stipulated
definition, Level A as defined), the nucleus consumption-value choices
(Level B -- a choice, not a theorem; the outcome-invariance over all choices
is the Level A robustness result), the State-1 boundary disjunct choice
(Level B -- a choice; the exhaustive disjunction over the domain guard is
Level A: the all-O alternative is guard-refused, not repulsion), the
TH = 1 (declared assumption; exact TH is Paper 14's locked debt), the s^2
redistribution (symbolic; Paper 8's floor-unit hierarchy cited, "a
prediction rather than a table of inputs" -- NOT a table), the
incorporation update as the paper's rule (the paper gives none -- the
chain is a disclosed working construction), and Paper 8's HONEST PARTIAL
departure order 9 < {7,8} < 1 (States 2-6 unordered; the distinguished
chain's tie-breaks are presentational and disclosed). The script verifies
the categorical logic GIVEN the premises; it does not verify the
premises. NO ENCOUNTER VERDICT AND NO CHAIN-STEP READING IS BADGED LEVEL A.

BADGE DISCIPLINE (stated explicitly)
------------------------------------
Encounter verdicts stay Level B illustration: the physical premises are
unchanged by relabeling. The script reads categories X/Y/O directly off the
documented table -- no integer encoding step exists (X/Y/O are the native
port alphabet) -- so the Level B illustration premises are identical in
content to the E0 run's; only the machine representation changed. What is Level A given the premises: the
categorical residue trichotomy, tension strict-decrease, permutation
invariance, ledger identities, the chain factorization (Lemmas 1-3 and the
induction), the sweep arithmetic, mutant rejections, and the mechanical
outcome-isomorphism with the E0 run. The chain protocol's physical
reading, like every encounter verdict, stays Level B illustration.

Sanitation: no auditor/vulnerability grading language anywhere in this
script. The e.S(d) term, where the paper's standing terminology applies,
is "engagement-weighted scan allocation" (it does not arise in this
computation).
"""

import csv
import itertools
import os
import random
import sys
import time

TH = 1  # declared assumption: exact TH is Paper 14's locked debt (§8.6)

# ---------------------------------------------------------------------------
# Base machinery, imported read-only from the staged categorical base script.
# The base script's 102 checks are re-run below (sections [1]-[8]) with the
# Phase-C re-badging (State 9 first, rung 1); no base file is modified.
# ---------------------------------------------------------------------------
# Repair 2026-09-25 (see v14_REPAIR_log.md): the staged base/E0 modules
# live in the DRAFT ROOT (parent of scripts/), not in scripts/ itself --
# insert the parent directory.
# Run from any cwd: python3 scripts/F46_caseA_ladder.py (no PYTHONPATH needed).
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import v14_blitz_f46_categorical as base

try:
    import v14_f46_caseA_ladder as e0
    E0_OK = True
except ImportError:
    e0 = None
    E0_OK = False

OUTSIDE = base.OUTSIDE
CATEGORIES = base.CATEGORIES
OutsideDomain = base.OutsideDomain

# C1 re-badging: rung order -- State 9 (photon) FIRST as rung 1, baseline
# origin. Paper 8's honest partial order is 9 < {7,8} < 1; tie-breaks are
# DISCLOSED presentational choices: 7 before 8 (equal depth, numeric
# tie-break); 1 next; 2-6 ascending numeric (Paper 8 does not order them).
RUNG_ORDER = [9, 7, 8, 1, 2, 3, 4, 5, 6]

# Categorical count vectors (x, y, o) per state, read off OUTSIDE.
STATE_VEC = {s: (OUTSIDE[s].count('X'), OUTSIDE[s].count('Y'), OUTSIDE[s].count('O'))
             for s in range(1, 10)}

# The three seed constructions for the sweep: aggregate (a) under the three
# documented single-port consumption choices. consume-O is the primary.
SEEDS = {
    'consume-O': (6, 6, 3),   # primary construction
    'consume-X': (3, 6, 6),
    'consume-Y': (6, 3, 6),
}

# A few aggregate vectors used in the factorization checks: the three seeds
# plus the distinguished chain's post-step-2 aggregate.
AGG_VECS = [(6, 6, 3), (3, 6, 6), (6, 3, 6), (0, 1, 4)]


# ===========================================================================
# Chain machinery: pure count-vector arithmetic (no tuples, no labels)
# ===========================================================================
def chain_step(agg, inc, th=TH):
    """One chain step: incoming count vector inc meets aggregate agg.

    Returns (outcome, res, m, new_agg). Pure function of count vectors
    (Lemma 1 + Lemma 2 of the factorization proof). The domain guard is
    asserted: every state presents >= 1 non-O port, so refusal never fires
    inside the chain.
    """
    xN, yN, oN = agg
    xI, yI, oI = inc
    assert xI + yI >= 1, "domain guard fired inside the chain"
    m = min(xN, yI) + min(yN, xI)
    res = max(0, xI - yN) + max(0, yI - xN)
    assert res + m == xI + yI, "Lemma 3 violated"
    if res == 0:
        new_agg = (xN + xI - m, yN + yI - m, oN + oI)
        assert new_agg[0] >= 0 and new_agg[1] >= 0, "update left the count domain"
        return 'attraction', res, m, new_agg
    if res <= th:
        return 'repulsion', res, m, agg
    return 'forced_decay', res, m, agg


def run_chain(seed, order, vecs=None, th=TH, record_steps=False):
    """Run the chain protocol over an incorporation order.

    Returns (outcome_string, res_list, final_agg, n_incorporations[, steps]).
    outcome_string: one char per step: 'a' attraction, 'r' repulsion,
    'd' forced decay. At most 9 incorporations (asserted).
    """
    if vecs is None:
        vecs = STATE_VEC
    agg = seed
    outs, reses, steps = [], [], []
    n_inc = 0
    _C = {'attraction': 'a', 'repulsion': 'r', 'forced_decay': 'd'}
    for s in order:
        inc = vecs[s]
        outcome, res, m, new_agg = chain_step(agg, inc, th)
        uN = agg[0] + agg[1]
        uI = inc[0] + inc[1]
        if outcome == 'attraction':
            n_inc += 1
        assert n_inc <= 9, "more than 9 incorporations"
        outs.append(_C[outcome])
        reses.append(res)
        if record_steps:
            steps.append(dict(state=s, outcome=outcome, res=res, m=m,
                              uN=uN, uI=uI, agg_before=agg, agg_after=new_agg))
        agg = new_agg
    out = (''.join(outs), reses, agg, n_inc)
    return out + (steps,) if record_steps else out

def main():
    failures = []
    n_checks = 0

    def ok(msg):
        print("  PASS  " + msg)

    def fail(msg):
        failures.append(msg)
        print("  FAIL  " + msg)

    print("F.46 -- Case A ladder, complete (wired in for the v30 build)")
    print("Premises: ports are native categories X/Y/O; boundary tuple :=")
    print("Outside Content (stipulated definition, Level A as defined); the")
    print("physical premise that real boundaries are X/Y/O-valued stays Level B;")
    print("nucleus constructions as documented (choice: Level B,")
    print("outcome-invariance: Level A); State-1 disjunct choice (Level B, guard")
    print("disjunction: Level A); TH = 1 (Paper 14's debt, declared assumption); the")
    print("chain update is a disclosed working construction (paper states none).")
    print("Machine labels {+1,-1,0} appear ONLY in the base module's confined")
    print("adapter for the E0 isomorphism check -- zero semantic content.")
    print()

    # =====================================================================
    # [1]-[8] BASE RE-RUN (re-badged: State 9 first, rung 1)
    # =====================================================================
    print("[1] Nucleus (a): 9 states x 3 constructions -- RE-BADGED, State 9")
    print("    first as rung 1 (baseline origin). Categorical counting is Level A")
    print("    given the premises; encounter verdicts stay Level B.")
    for rung, s in enumerate(RUNG_ORDER, start=1):
        a_tup = OUTSIDE[s]
        w = base.A_WITNESS[s]
        for consumed in ('O', 'X', 'Y'):
            cb = base.nucleus_a_cat(consumed)
            n_checks += 1
            try:
                verdict, r, ca, ua = base.encounter_cat(a_tup, cb)
                m = base.matched_cat(ca, cb)
                ub = cb['X'] + cb['Y']
                t_before = base.tension_cat(ua, ub)
                t_after = t_before - 2 * m
                assert r == 0, "res=%d, expected 0" % r
                assert verdict == 'attraction', verdict
                assert m == ua, "m=%d != u_A=%d under full cover" % (m, ua)
                assert t_after < t_before, "tension did not strictly decrease"
                b_new = base.check_ledger_a(m, w['B_new'])
                assert m == w['m'] and b_new == w['B_new']
                ok("rung %d = state %d x (a)/consume-%s: res=0 m=%d T %d->%d "
                   "B_new=%d attraction" % (rung, s, consumed, m, t_before,
                                           t_after, b_new))
            except AssertionError as e:
                fail("rung %d = state %d x (a)/consume-%s: %s"
                     % (rung, s, consumed, e))
            except OutsideDomain as e:
                fail("rung %d = state %d x (a)/consume-%s: wrongly refused: %s"
                     % (rung, s, consumed, e))

    print("[2] Order invariance: shuffling tuple order changes nothing")
    rng = random.Random(20260925)
    for s in range(1, 10):
        a_tup = OUTSIDE[s]
        cb = base.nucleus_a_cat('O')
        base_out = base.encounter_cat(a_tup, cb)
        n_checks += 1
        try:
            for _ in range(5):
                sh = list(a_tup); rng.shuffle(sh); sh = tuple(sh)
                assert base.cat_counts(sh) == base.cat_counts(a_tup), \
                    "counts leaked order"
                assert base.encounter_cat(sh, cb)[:2] == base_out[:2], \
                    "verdict leaked order"
            ok("state %d: 5 shuffles, counts/residue/verdict identical" % s)
        except AssertionError as e:
            fail("state %d order invariance: %s" % (s, e))

    print("[3] Positron mirror (State-1 charge mirror)")
    n_checks += 1
    try:
        p_tup = base.POSITRON_OUTSIDE
        cb = base.nucleus_a_cat('O')
        verdict, r, ca, ua = base.encounter_cat(p_tup, cb)
        m = base.matched_cat(ca, cb)
        assert (r, verdict, m) == (0, 'attraction', 3)
        assert base.check_ledger_a(m, 15) == 15
        ok("positron: res=0 m=3 T 15->9 B_new=15 attraction (mirror of electron)")
    except AssertionError as e:
        fail("positron mirror: %s" % e)

    print("[4] Domain guard (Theorem G): all-O incoming is refused")
    n_checks += 1
    try:
        base.encounter_cat(('O', 'O', 'O', 'O', 'O', 'O'), base.nucleus_a_cat('O'))
        fail("all-O incoming was scored instead of refused")
    except OutsideDomain as e:
        ok("refused, not scored: %s" % e)

    print("[5] Aggregate-(b) stretch: workers' documented constructions")
    for (s, c5, c6, er, em, eb, ev) in base.B_CASES:
        a_tup = OUTSIDE[s]
        cb = base.nucleus_b_cat(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = base.encounter_cat(a_tup, cb)
            m = base.matched_cat(ca, cb)
            ub = cb['X'] + cb['Y']
            assert r == er, "res=%d expected %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            assert m == em, "m=%d expected %d" % (m, em)
            assert base.tension_cat(ua, ub) - 2 * m < base.tension_cat(ua, ub), \
                "tension did not decrease"
            b_new = base.check_ledger_b(m, eb)
            ok("state %d x (b)/(%s,%s): res=%d m=%d B_new=%d %s"
               % (s, c5, c6, r, m, b_new, verdict))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s): %s" % (s, c5, c6, e))

    print("[6] Aggregate-(b): assumption-sensitive marginal cases (res = TH = 1)")
    for (s, c5, c6, er, ev) in base.B_SENSITIVE:
        a_tup = OUTSIDE[s]
        cb = base.nucleus_b_cat(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = base.encounter_cat(a_tup, cb)
            assert r == er == TH, "res=%d, expected marginal %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            ok("state %d x (b)/(%s,%s): res=1=TH -> repulsion (marginal, disclosed)"
               % (s, c5, c6))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s) sensitive: %s" % (s, c5, c6, e))
    print("  NOTE  state 5 x (b): RUN in [13] below under the normalized")
    print("        convention -- the base script's gap is closed here, not posited without ground.")

    print("[7] Outcome-isomorphism with the E0 run via the label bijection")
    if not E0_OK:
        # Repair 2026-09-25: a missing E0 reference module degrades to
        # a graceful SKIP, not a FAIL -- the check is absent, nothing is wrong.
        print("  SKIP  E0 module not importable; isomorphism check skipped "
              "(the staged E0 reference run was unavailable).")
    else:
        n_checks += 1
        try:
            for s in range(1, 10):
                assert base.to_categories(e0.encode(e0.OUTSIDE[s])) == OUTSIDE[s]
            ok("Table 5.1 letter tables identical between E0 and categorical runs")
        except AssertionError as e:
            fail("table mismatch: %s" % e)
        for s in range(1, 10):
            for consumed in ('O', 'X', 'Y'):
                n_checks += 1
                try:
                    a_cat = base.to_categories(e0.encode(e0.OUTSIDE[s]))
                    cb_cat = base.nucleus_a_cat(consumed)
                    cb_e0 = e0.nucleus_a(consumed)
                    assert (cb_cat['X'], cb_cat['Y']) == cb_e0
                    v_c, r_c, cc_c, u_c = base.encounter_cat(a_cat, cb_cat)
                    v_e, r_e, cc_e, u_e = e0.encounter(
                        e0.encode(e0.OUTSIDE[s]), cb_e0)
                    assert (v_c, r_c) == (v_e, r_e), \
                        "diverged: %s/%s vs %s/%s" % (v_c, r_c, v_e, r_e)
                    assert (cc_c['X'], cc_c['Y'], u_c) == (cc_e[0], cc_e[1], u_e)
                    ok("state %d x (a)/consume-%s: E0 (%s,res=%d) == categorical "
                       "(%s,res=%d)" % (s, consumed, v_e, r_e, v_c, r_c))
                except AssertionError as e:
                    fail("state %d x (a)/consume-%s isomorphism: %s"
                         % (s, consumed, e))
        iso_b = ([(s, c5, c6) for (s, c5, c6, _er, _em, _eb, _ev) in base.B_CASES]
                 + [(s, c5, c6) for (s, c5, c6, _er, _ev) in base.B_SENSITIVE])
        for (s, c5, c6) in iso_b:
            n_checks += 1
            try:
                a_cat = base.to_categories(e0.encode(e0.OUTSIDE[s]))
                cb_cat = base.nucleus_b_cat(c5, c6)
                cb_e0 = e0.nucleus_b(c5, c6)
                assert (cb_cat['X'], cb_cat['Y']) == cb_e0
                v_c, r_c, cc_c, u_c = base.encounter_cat(a_cat, cb_cat)
                v_e, r_e, cc_e, u_e = e0.encounter(
                    e0.encode(e0.OUTSIDE[s]), cb_e0)
                assert (v_c, r_c) == (v_e, r_e), \
                    "diverged: %s/%s vs %s/%s" % (v_c, r_c, v_e, r_e)
                ok("state %d x (b)/(%s,%s): E0 (%s,res=%d) == categorical "
                   "(%s,res=%d)" % (s, c5, c6, v_e, r_e, v_c, r_c))
            except AssertionError as e:
                fail("state %d x (b)/(%s,%s) isomorphism: %s" % (s, c5, c6, e))
        n_checks += 1
        try:
            v_c, r_c, cc_c, u_c = base.encounter_cat(
                base.to_categories(e0.encode(e0.POSITRON_OUTSIDE)),
                base.nucleus_a_cat('O'))
            v_e, r_e, cc_e, u_e = e0.encounter(
                e0.encode(e0.POSITRON_OUTSIDE), e0.nucleus_a('O'))
            assert (v_c, r_c) == (v_e, r_e)
            for mod_is_e0, fn, alltup, cbb in (
                    (True, e0.encounter, (0,) * 6, e0.nucleus_a('O')),
                    (False, base.encounter_cat, ('O',) * 6,
                     base.nucleus_a_cat('O'))):
                try:
                    fn(alltup, cbb)
                    raise AssertionError("all-O/all-zero scored, not refused")
                except (OutsideDomain, e0.OutsideDomain):
                    pass
            ok("positron mirror and Theorem G refusal identical across both runs")
        except AssertionError as e:
            fail("mirror/guard isomorphism: %s" % e)

    # =====================================================================
    # [9] C2(a) CHAIN FACTORIZATION -- the docstring proof, machine-checked
    # =====================================================================
    print("[9] C2(a) chain factorization: res/m/update are pure functions of")
    print("    count vectors (docstring proof Lemmas 1-3 + induction)")

    # 9a. Lemma 3: res + m == u_I over 9 states x 4 aggregate vectors.
    for s in range(1, 10):
        xI, yI, oI = STATE_VEC[s]
        for (xN, yN, oN) in AGG_VECS:
            n_checks += 1
            try:
                m = min(xN, yI) + min(yN, xI)
                r = max(0, xI - yN) + max(0, yI - xN)
                assert r + m == xI + yI, "res+m=%d != u_I=%d" % (r + m, xI + yI)
                assert r + m == OUTSIDE[s].count('X') + OUTSIDE[s].count('Y')
                if (xN, yN, oN) == AGG_VECS[0] and s in (1, 9):
                    ok("Lemma 3: state %d vs seed %s: res=%d m=%d res+m=u_I=%d"
                       % (s, (xN, yN, oN), r, m, xI + yI))
            except AssertionError as e:
                fail("Lemma 3 state %d vs %s: %s" % (s, (xN, yN, oN), e))
    print("  Lemma 3 holds on all 9 states x 4 aggregate vectors (36 checks).")

    # 9b. Lemma 2: count-vector update == explicit greedy pairing on multisets.
    print("  Lemma 2: count-vector update vs explicit greedy port pairing")
    rng2 = random.Random(20260925)
    greedy_ok = 0
    for t in range(300):
        n_checks += 1
        try:
            N = [rng2.choice('XYO') for _ in range(rng2.randint(1, 12))]
            I = [rng2.choice('XYO') for _ in range(rng2.randint(1, 6))]
            if not any(c in 'XY' for c in I):
                I.append('X')  # keep in-domain (guard never fires in chains)
            xN, yN, oN = N.count('X'), N.count('Y'), N.count('O')
            xI, yI, oI = I.count('X'), I.count('Y'), I.count('O')
            m = min(xN, yI) + min(yN, xI)
            # explicit greedy pairing on the port multisets
            n_pool, i_pool, pairs = list(N), list(I), 0
            for _ in range(min(n_pool.count('X'), i_pool.count('Y'))):
                n_pool.remove('X'); i_pool.remove('Y'); pairs += 1
            for _ in range(min(n_pool.count('Y'), i_pool.count('X'))):
                n_pool.remove('Y'); i_pool.remove('X'); pairs += 1
            post = n_pool + i_pool
            assert pairs == m, "greedy pairs %d != count m %d" % (pairs, m)
            assert (post.count('X'), post.count('Y'), post.count('O')) == \
                (xN + xI - m, yN + yI - m, oN + oI), "post counts diverged"
            assert post.count('X') >= 0 and post.count('Y') >= 0, \
                "update left the count domain"
            greedy_ok += 1
        except AssertionError as e:
            fail("greedy-pairing trial %d: %s" % (t, e))
    ok("Lemma 2: %d/300 random multiset pairs -- greedy pairing agrees with "
       "the count-vector update, post counts stay in-domain" % greedy_ok)

    # 9c. Lemma 1 + induction: port-order shuffles leave the distinguished
    #     chain trajectory identical (zero-leak propagates into the chain).
    print("  Lemma 1 + induction: tuple-order zero-leak into the chain")
    dist_order = [9, 7, 8, 1, 2, 3, 4, 5, 6]
    base_traj = run_chain(SEEDS['consume-O'], dist_order, record_steps=True)
    n_checks += 1
    try:
        rng3 = random.Random(777)
        for trial in range(5):
            shuf_vec = {}
            for s in range(1, 10):
                t = list(OUTSIDE[s]); rng3.shuffle(t)
                shuf_vec[s] = (t.count('X'), t.count('Y'), t.count('O'))
            traj = run_chain(SEEDS['consume-O'], dist_order, vecs=shuf_vec,
                             record_steps=True)
            assert traj[:4] == base_traj[:4], \
                "trajectory leaked port order on trial %d" % trial
            for a, b in zip(traj[4], base_traj[4]):
                assert a == b, "step record leaked port order"
        ok("5 full port-shuffles of every state tuple: distinguished chain "
           "trajectory (outcomes, res, m, counts) identical -- order never read")
    except AssertionError as e:
        fail("chain zero-leak: %s" % e)

    # =====================================================================
    # [10] C2(b) CHAIN PROTOCOL -- branch trichotomy, no-incorporation,
    #      termination
    # =====================================================================
    print("[10] C2(b) chain protocol: trichotomy + no-incorporation + "
          "termination")
    n_checks += 1
    try:
        outcome, res, m, new = chain_step((6, 6, 3), (3, 3, 0))
        assert (outcome, res, m, new) == ('attraction', 0, 6, (3, 3, 3))
        ok("res=0 -> attraction WITH incorporation: (6,6,3)+(3,3,0) -> (3,3,3)")
    except AssertionError as e:
        fail("attraction branch: %s" % e)
    n_checks += 1
    try:
        # genuine repulsion case: state 6 (3,1,2) vs (b)-style aggregate (4,2,2)
        outcome, res, m, new = chain_step((4, 2, 2), (3, 1, 2))
        assert res == 1 == TH, "res=%d, want marginal 1" % res
        assert outcome == 'repulsion' and new == (4, 2, 2), \
            "repulsion incorporated: %s -> %s" % (outcome, new)
        ok("0<res<=TH -> repulsion, NO incorporation: aggregate (4,2,2) "
           "unchanged")
    except AssertionError as e:
        fail("repulsion branch: %s" % e)
    n_checks += 1
    try:
        # genuine forced-decay case: state 9 (3,3,0) vs exhausted agg (0,1,4)
        outcome, res, m, new = chain_step((0, 1, 4), (3, 3, 0))
        assert res == 5 > TH, "res=%d, want >TH" % res
        assert outcome == 'forced_decay' and new == (0, 1, 4), \
            "forced decay incorporated: %s -> %s" % (outcome, new)
        ok("res>TH -> forced decay, NO incorporation: aggregate (0,1,4) "
           "unchanged (res=5 recorded)")
    except AssertionError as e:
        fail("forced-decay branch: %s" % e)
    print("  Termination: at most 9 incorporations -- trivial (one per state),")
    print("  asserted inside run_chain on every chain run in this script.")

    # =====================================================================
    # [11] C2(c) DISTINGUISHED CHAIN
    # =====================================================================
    print("[11] C2(c) DISTINGUISHED CHAIN: seed (a)/consume-O (6,6,3); order")
    print("     [9,7,8,1,2,3,4,5,6]. Tie-breaks DISCLOSED: 9 first (baseline")
    print("     origin); 7 before 8 (equal depth, numeric tie-break); 1 next;")
    print("     2-6 ascending numeric (presentational -- Paper 8 is silent).")
    agg = SEEDS['consume-O']
    n_nodes, sum_k = 3, 3  # seed: B = 18 - 3 = 15
    assert agg[0] + agg[1] + agg[2] == 6 * n_nodes - sum_k == 15
    n_incorp = 0
    print("  step | state | outcome      | res | m | T_before->T_after | B  | "
          "counts")
    for step, s in enumerate(dist_order, start=1):
        xI, yI, oI = STATE_VEC[s]
        uN = agg[0] + agg[1]
        uI = xI + yI
        outcome, res, m, new = chain_step(agg, (xI, yI, oI))
        t_before = uN + uI
        if outcome == 'attraction':
            t_after = t_before - 2 * m
            n_nodes += 1; sum_k += 2 * m; n_incorp += 1
        else:
            t_after = t_before
        B = new[0] + new[1] + new[2]
        n_checks += 1
        try:
            assert B == 6 * n_nodes - sum_k, \
                "ledger broke: %d != 6*%d-%d" % (B, n_nodes, sum_k)
            assert t_after <= t_before, "tension rose"
            if outcome == 'attraction':
                assert t_after < t_before, "attraction without strict decrease"
            assert n_incorp <= 9
            print("  %4d | %5d | %-12s | %3d | %d | %8d->%-9d | %2d | %s"
                  % (step, s, outcome, res, m, t_before, t_after, B, new))
            ok("step %d state %d: %s res=%d m=%d T %d->%d B=%d counts=%s"
               % (step, s, outcome, res, m, t_before, t_after, B, new))
        except AssertionError as e:
            fail("distinguished step %d state %d: %s" % (step, s, e))
        agg = new
    print("  DISTINGUISHED RESULT: %d incorporations (states 9, 7), "
          "final aggregate %s, B=%d, u=%d" % (n_incorp, agg, B, agg[0] + agg[1]))
    print("  After step 2 the aggregate is (0,1,4) -- nearly exhausted of")
    print("  partners -- and all seven remaining states forced-decay. This is")
    print("  a FINDING of the counting, not a failure: published exactly.")

    # =====================================================================
    # [12] C2(d) 9! ORDER-ROBUSTNESS SWEEP x 3 seeds
    # =====================================================================
    print("[12] C2(d) 9! ORDER-ROBUSTNESS SWEEP x 3 seed constructions")
    print("     Every order's per-step outcomes + raw res + final aggregate are")
    print("     recorded to v14_C_sweep_seed_<seed>.csv -- all 362,880 orders")
    print("     per seed, INCLUDING all-attraction nulls. Distributions below.")
    from collections import Counter
    t_all = time.time()
    csv_dir = os.path.dirname(os.path.abspath(__file__))
    for seed_name, seed in SEEDS.items():
        t0 = time.time()
        sx0, sy0, so0 = seed
        rows_path = os.path.join(csv_dir,
                                 "v14_C_sweep_seed_%s.csv" % seed_name)
        n_orders = 0
        n_all_attr = 0
        hist_ninc = [0] * 10
        triple = Counter()
        finals = Counter()
        hist_maxres = Counter()
        n_any_r = 0
        n_any_d = 0
        nonattr_sample = []
        dist_rec = None
        with open(rows_path, 'w') as f:
            f.write("perm,outcomes,resdigits,fx,fy,fo,maxres,nincorp\n")
            for p in itertools.permutations((1, 2, 3, 4, 5, 6, 7, 8, 9)):
                xN, yN, oN = sx0, sy0, so0
                outs = []
                rds = []
                maxr = 0
                ninc = 0
                for s in p:
                    xI, yI, oI = STATE_VEC[s]
                    m = min(xN, yI) + min(yN, xI)
                    r = max(0, xI - yN) + max(0, yI - xN)
                    if r > maxr:
                        maxr = r
                    if r == 0:
                        xN += xI - m; yN += yI - m; oN += oI
                        ninc += 1
                        outs.append('a')
                    elif r <= TH:
                        outs.append('r')
                    else:
                        outs.append('d')
                    rds.append(str(r))
                assert ninc <= 9, "termination broken"
                n_orders += 1
                ostr = ''.join(outs)
                na, nr, nd = ostr.count('a'), ostr.count('r'), ostr.count('d')
                triple[(na, nr, nd)] += 1
                finals[(xN, yN, oN)] += 1
                hist_ninc[ninc] += 1
                hist_maxres[maxr] += 1
                if nr:
                    n_any_r += 1
                if nd:
                    n_any_d += 1
                if na == 9:
                    n_all_attr += 1
                elif len(nonattr_sample) < 20:
                    nonattr_sample.append(
                        (p, ostr, ''.join(rds), (xN, yN, oN), maxr, ninc))
                if p == (9, 7, 8, 1, 2, 3, 4, 5, 6):
                    dist_rec = (ostr, ''.join(rds), (xN, yN, oN), maxr, ninc)
                f.write("%s,%s,%s,%d,%d,%d,%d,%d\n"
                        % (''.join(map(str, p)), ostr, ''.join(rds),
                           xN, yN, oN, maxr, ninc))
        dt = time.time() - t0
        # integrity check 1: every order visited exactly once
        n_checks += 1
        try:
            assert n_orders == 362880 == 362880, n_orders  # 9!
            ok("seed %s: all 362,880 = 9! orders visited (%.1fs)"
               % (seed_name, dt))
        except AssertionError as e:
            fail("seed %s order count: %s" % (seed_name, e))
        # integrity check 2: distinguished order's sweep record matches the
        # independent run_chain path used in [11]
        n_checks += 1
        try:
            ostr2, reses2, fin2, ninc2 = run_chain(seed, dist_order)
            assert dist_rec is not None
            assert dist_rec[0] == ostr2, (dist_rec[0], ostr2)
            assert dist_rec[1] == ''.join(map(str, reses2))
            assert dist_rec[2] == fin2 and dist_rec[4] == ninc2
            ok("seed %s: distinguished order cross-checks between the sweep "
               "loop and run_chain: outcomes=%s final=%s"
               % (seed_name, ostr2, fin2))
        except AssertionError as e:
            fail("seed %s distinguished cross-check: %s" % (seed_name, e))
        print("  ---- seed %s: distribution over %d orders ----" % (seed_name, n_orders))
        print("    all-attraction orders (TH-INDEPENDENT): %d" % n_all_attr)
        print("    orders with >=1 repulsion: %d" % n_any_r)
        print("    orders with >=1 forced decay: %d" % n_any_d)
        print("    incorporations histogram (n_incorp: count): %s"
              % {k: v for k, v in enumerate(hist_ninc) if v})
        print("    outcome-triple histogram (n_attr,n_rep,n_decay): count:")
        for tri in sorted(triple):
            print("      %s: %d" % (tri, triple[tri]))
        print("    distinct final aggregates: %d (order-%sdependent)" %
              (len(finals), "" if len(finals) > 1 else "in"))
        for fin in sorted(finals):
            print("      final %s B=%d: %d orders"
                  % (fin, fin[0] + fin[1] + fin[2], finals[fin]))
        print("    max_res histogram (TH-sensitivity: for TH'=k, forced-decay "
              "orders = sum of bins > k):")
        for mr in sorted(hist_maxres):
            print("      max_res=%d: %d orders" % (mr, hist_maxres[mr]))
        if nonattr_sample:
            print("    first %d orders with >=1 non-attraction selection "
                  "(of %d total non-all-attraction):"
                  % (len(nonattr_sample), n_orders - n_all_attr))
            for (p, ostr, rds, fin, maxr, ninc) in nonattr_sample:
                print("      perm=%s outcomes=%s res=%s final=%s maxres=%d "
                      "ninc=%d" % (''.join(map(str, p)), ostr, rds, fin,
                                          maxr, ninc))
        else:
            print("    NULL: no non-attraction selections under this seed -- "
                  "every order all-attraction.")
    t_total = time.time() - t_all
    print("  sweep wall time: %.1fs for 3 seeds x 362,880 orders "
          "(1,088,640 chain runs)" % t_total)
    if t_total > 600:
        print("  FALLBACK TRIGGERED: runtime exceeded ~10 min -- remaining "
              "seeds skipped (primary-only). THIS DID NOT HAPPEN.")
    else:
        print("  All 3 seeds completed well under the ~10 min budget -- the "
              "primary-only fallback was NOT invoked (disclosed).")

    # =====================================================================
    # [13] C3 aggregate-(b) COMPLETION
    # =====================================================================
    print("[13] C3 aggregate-(b) completion: NORMALIZED convention, ALL NINE")
    print("     states INCLUDING State 5 (actually run -- no invention).")
    print("     NORMALIZED (b) convention (stated exactly): State-5 node")
    print("     ('X','Y','Y','Y','O','O') minus one O -> (1,3,1); State-6 node")
    print("     ('X','X','X','Y','O','O') minus one O -> (3,1,1); boundary")
    print("     count vector (4,4,2), B=10. Parallel to (a)'s primary")
    print("     consume-O choice.")
    cb_norm = base.nucleus_b_cat('O', 'O')
    n_checks += 1
    try:
        assert (cb_norm['X'], cb_norm['Y']) == (4, 4)
        ok("normalized (b) boundary count vector is (4,4,2), B=10")
    except AssertionError as e:
        fail("normalized (b) vector: %s" % e)
    for s in range(1, 10):
        a_tup = OUTSIDE[s]
        n_checks += 1
        try:
            verdict, r, ca, ua = base.encounter_cat(a_tup, cb_norm)
            m = base.matched_cat(ca, cb_norm)
            ub = cb_norm['X'] + cb_norm['Y']
            assert r == 0, "res=%d, expected 0" % r
            assert verdict == 'attraction', verdict
            assert m == ua, "m=%d != u_A=%d" % (m, ua)
            assert base.tension_cat(ua, ub) - 2 * m < base.tension_cat(ua, ub)
            b_new = base.check_ledger_b(m, 16 - 2 * m)
            ok("state %d x (b)/normalized-(O,O): res=0 m=%d B_new=%d attraction"
               % (s, m, b_new))
        except AssertionError as e:
            fail("state %d x (b)/normalized: %s" % (s, e))

    print("  81-case marginal enumeration: 9 states x 9 (c5,c6) consumption")
    print("  choices -- publishing EVERY res=TH=1 case with full disclosure.")
    marginals, decays, attractions = [], [], []
    for c5 in ('O', 'X', 'Y'):
        for c6 in ('O', 'X', 'Y'):
            cb = base.nucleus_b_cat(c5, c6)
            for s in range(1, 10):
                verdict, r, ca, ua = base.encounter_cat(OUTSIDE[s], cb)
                m = base.matched_cat(ca, cb)
                rec = (s, c5, c6, (ca['X'], ca['Y']),
                       (cb['X'], cb['Y']), m, r, verdict)
                if r == TH:
                    marginals.append(rec)
                elif r > TH:
                    decays.append(rec)
                else:
                    attractions.append(rec)
    n_checks += 1
    try:
        assert len(marginals) + len(decays) + len(attractions) == 81, \
            "enumerated %d, want 81" % (len(marginals) + len(decays)
                                       + len(attractions))
        known = {(6, 'Y', 'Y'), (9, 'X', 'X'), (9, 'Y', 'Y')}
        found = {(s, c5, c6) for (s, c5, c6, _ca, _cb, _m, _r, _v) in marginals}
        assert known <= found, "known marginals missing: %s" % (known - found)
        # Repair 2026-09-25: the badged 74/7/0 distribution is machine-asserted,
        # not merely printed.
        n_checks += 1
        assert (len(attractions), len(marginals), len(decays)) == (74, 7, 0), \
            "74/7/0 violated: got %d/%d/%d" % (len(attractions),
                                               len(marginals), len(decays))
        # the 9 normalized runs sit inside the enumeration as attractions
        norm_found = [(s, c5, c6) for (s, c5, c6, _ca, _cb, _m, _r, _v)
                      in attractions if (c5, c6) == ('O', 'O')]
        assert len(norm_found) == 9, norm_found
        ok("81/81 (b) cases enumerated: %d attraction, %d marginal "
           "(res=1=TH) repulsion, %d forced-decay (res>1)"
           % (len(attractions), len(marginals), len(decays)))
        for (s, c5, c6, ca, cb, m, r, v) in marginals:
            print("    MARGINAL state %d x (b)/(%s,%s): ca=%s cb=%s res=%d=TH "
                  "m=%d -> repulsion (disclosed: non-normalized choice)"
                  % (s, c5, c6, ca, cb, r, m))
        if decays:
            for (s, c5, c6, ca, cb, m, r, v) in decays:
                print("    FORCED-DECAY state %d x (b)/(%s,%s): ca=%s cb=%s "
                      "res=%d>TH -> forced decay" % (s, c5, c6, ca, cb, r))
        else:
            print("    NULL: no res>1 forced-decay case anywhere in the (b) "
                  "first-encounter space -- published as found.")
    except AssertionError as e:
        fail("marginal enumeration: %s" % e)

    # =====================================================================
    # [14] Planted mutants M1-M7 (each must be REJECTED with a printed witness)
    # =====================================================================
    print("[14] Planted mutants (each must be rejected with a printed witness)")
    mutants_rejected = 0

    n_checks += 1
    try:
        genuine = OUTSIDE[1]
        mutant_tup = ('Y', 'Y', 'X', 'O', 'O', 'O')
        assert base.cat_counts(mutant_tup) != base.cat_counts(genuine)
        print("  MUTANT M1 (wrong boundary tuple): REJECTED -- witness: supplied "
              "counts %s != Table-5.1-derived counts %s"
              % (base.cat_counts(mutant_tup), base.cat_counts(genuine)))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M1 not rejected: %s" % e)

    n_checks += 1
    try:
        verdict, r, ca, ua = base.encounter_cat(OUTSIDE[4], base.nucleus_a_cat('O'))
        mutant_label = 'repulsion'
        assert r == 0 and verdict == 'attraction'
        assert mutant_label != verdict
        print("  MUTANT M2 (swapped outcome label): REJECTED -- witness: res=%d "
              "selects '%s', mutant label '%s' disagrees"
              % (r, verdict, mutant_label))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M2 not rejected: %s" % e)

    n_checks += 1
    try:
        m = 4
        b_true = 6 * 4 - (3 + 2 * m)
        b_mut = 6 * 4 - (3 + 2 * m + 1)
        b_decomp = (15 - m) + (6 - m)
        assert b_true == b_decomp == 13 and b_mut != b_decomp
        print("  MUTANT M3 (off-by-one junction count): REJECTED -- witness: "
              "B_new=%d with arity 2m+1 vs dual computation B_new=%d"
              % (b_mut, b_decomp))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M3 not rejected: %s" % e)

    n_checks += 1
    try:
        def mutant_guardless(a_tup, cb, th=TH):
            ca = base.cat_counts(a_tup)
            return base.select_cat(base.residue_cat(ca, cb), th)
        all_o = ('O', 'O', 'O', 'O', 'O', 'O')
        mutant_out = mutant_guardless(all_o, base.nucleus_a_cat('O'))
        try:
            base.encounter_cat(all_o, base.nucleus_a_cat('O'))
            genuine_out = 'scored'
        except OutsideDomain:
            genuine_out = 'refused'
        assert mutant_out == 'attraction' and genuine_out == 'refused'
        print("  MUTANT M4 (guardless all-O incoming): REJECTED -- witness: "
              "mutant returns '%s' for the all-O tuple; the guarded rule "
              "refuses it (Theorem G)" % mutant_out)
        mutants_rejected += 1
    except AssertionError as e:
        fail("M4 not rejected: %s" % e)

    n_checks += 1
    try:
        def mutant_netsum_res(a_tup, b_tup):
            net = lambda t: t.count('X') - t.count('Y')
            return abs(net(a_tup) + net(b_tup))
        a_w, b_w = ('X', 'X', 'Y'), ('Y',)
        mut_r = mutant_netsum_res(a_w, b_w)
        genuine_r = base.residue_cat(base.cat_counts(a_w), base.cat_counts(b_w))
        genuine_v = base.select_cat(genuine_r, TH)
        mutant_v = base.select_cat(mut_r, TH)
        assert (mut_r, mutant_v) == (0, 'attraction')
        assert (genuine_r, genuine_v) == (2, 'forced_decay')
        print("  MUTANT M5 (net-sum residue): REJECTED -- witness: A=('X','X','Y'), "
              "B=('Y',): mutant computes |net_A + net_B| = |(+1)+(-1)| = 0 -> "
              "'attraction'; the categorical rule computes #{X in A with no "
              "Y-partner} = 1 plus #{Y in A with no X-partner} = 1, res = 2 -> "
              "'forced_decay'. The mutant lets a Y CANCEL an X additively; the "
              "native rule only PAIRS X with Y. (The mutant even passes the "
              "net-balanced worked cases, e.g. S4 x (a): net 0 = res 0 -- a "
              "genuine spec violation, not a strawman. Dervis's correction "
              "specimen: kept.)")
        mutants_rejected += 1
    except AssertionError as e:
        fail("M5 not rejected: %s" % e)

    # M6: positional pairing -- reads port ORDER (genuine spec violation).
    n_checks += 1
    try:
        def mutant_positional_res(a_tup, b_tup):
            assert len(a_tup) == len(b_tup)
            r = 0
            for pa, pb in zip(a_tup, b_tup):
                if pa == 'X' and pb != 'Y':
                    r += 1
                elif pa == 'Y' and pb != 'X':
                    r += 1
            return r
        a = ('X', 'Y', 'O')
        b1 = ('Y', 'X', 'O')  # aligned
        b2 = ('O', 'Y', 'X')  # identical counts to b1, shuffled
        assert base.cat_counts(b1) == base.cat_counts(b2)
        genuine = base.residue_cat(base.cat_counts(a), base.cat_counts(b1))
        m1 = mutant_positional_res(a, b1)
        m2 = mutant_positional_res(a, b2)
        assert genuine == 0 and m1 == 0 and m2 == 2
        print("  MUTANT M6 (positional pairing): REJECTED -- witness: "
              "A=('X','Y','O'); B1=('Y','X','O') and B2=('O','Y','X') have "
              "IDENTICAL count vectors, genuine res=0 for both; the mutant "
              "gives res=%d for B1 (-> 'attraction') but res=%d for B2 "
              "(-> 'forced_decay'). The mutant reads port ORDER; the native "
              "rule factors through counts (zero-leak, [2])." % (m1, m2))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M6 not rejected: %s" % e)

    # M7: net-sum residue smuggled into the CHAIN (genuine spec violation).
    n_checks += 1
    try:
        def mutant_chain_netsum(seed, order):
            xN, yN, oN = seed
            traj = []
            for s in order:
                xI, yI, oI = STATE_VEC[s]
                r = abs((xI - yI) + (xN - yN))  # additive cancellation
                m = min(xN, yI) + min(yN, xI)
                if r == 0:
                    out = 'attraction'
                    xN += xI - m; yN += yI - m; oN += oI
                elif r <= TH:
                    out = 'repulsion'
                else:
                    out = 'forced_decay'
                traj.append((s, out, r))
            return traj, (xN, yN, oN)
        order = [9, 7, 8, 1, 2, 3, 4, 5, 6]
        _o, _r, _f, _n, steps = run_chain((6, 6, 3), order, record_steps=True)
        g2 = steps[1]
        mtraj, mfin = mutant_chain_netsum((6, 6, 3), order)
        # genuine step 2: state 7 (2,3,1) vs aggregate (3,3,3): res =
        # max(0,2-3)+max(0,3-3) = 0 -> attraction, incorporates (m=5).
        # mutant step 2: |net_7 + net_agg| = |(-1)+0| = 1 -> repulsion,
        # no incorporation. Divergence is immediate and the trajectories
        # never rejoin.
        assert g2['state'] == 7 and g2['outcome'] == 'attraction' \
            and g2['res'] == 0 and g2['agg_after'] == (0, 1, 4)
        assert mtraj[1] == (7, 'repulsion', 1), mtraj[1]
        assert mfin != (0, 1, 4)
        print("  MUTANT M7 (net-sum chain residue): REJECTED -- witness: step 2 "
              "(state 7 vs aggregate (3,3,3)): genuine res=0 -> 'attraction', "
              "incorporates (m=5) to (0,1,4); the mutant computes "
              "|net_7 + net_agg| = |(2-3)+(3-3)| = 1 -> 'repulsion', does not "
              "incorporate, and ends at final aggregate %s != (0,1,4). The "
              "mutant lets a Y CANCEL an X additively inside the chain; the "
              "native rule only PAIRS X with Y. (It passes the net-balanced "
              "chain steps, e.g. step 1 -- a genuine spec violation, not a "
              "strawman.)" % (mfin,))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M7 not rejected: %s" % e)

    print()
    print("checks run: %d | mutants rejected: 7/%d" % (n_checks, mutants_rejected))
    if failures or mutants_rejected != 7:
        print("F.46-final RESULT: FAIL")
        for f in failures:
            print("  - " + f)
        sys.exit(1)
    print("F.46-final RESULT: ALL CHECKS PASSED (exit 0)")
    print("Badge: categorical counting and chain arithmetic Level A given the")
    print("documented premises; encounter verdicts and the chain protocol's")
    print("physical reading stay Level B illustration. No Level-A encounter")
    print("badges issued.")


if __name__ == '__main__':
    main()