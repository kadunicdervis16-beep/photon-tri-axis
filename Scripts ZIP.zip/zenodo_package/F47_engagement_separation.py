INPUT_PROVENANCE = {
    "AMBIENT": {"class": "control", "note": "declared ambient-L3 fixture scheme (reference spacing, node offsets); the taxicab metric is native L3, the positions are not"},
    "CLOSED": {"class": "paper-defined", "source": "§4.3 (closed port status)"},
    "CONSUME": {"class": "paper-defined", "source": "§9.3 (consumption convention: consume-O/X/Y)"},
    "OPEN": {"class": "paper-defined", "source": "§4.3 (open port status — Definition (Port Status))"},
    "PORT_DIR_MAP": {"class": "control", "note": "declared port-index to unit-direction map placing presented ports in the ambient array"},
    "PROBE_PAIR": {"class": "control", "note": "colocated probe fixtures for the d=0 admission mutant"},
    "PUBLISHED_MARGINALS": {"class": "paper-defined", "source": "§9.3 (published aggregate-(b) marginal set)"},
    "PUBLISHED_PRIMARY": {"class": "paper-defined", "source": "§9.3 (published distinguished-chain trajectory, primary seed)"},
    "RUNG_ORDER": {"class": "paper-defined", "source": "§9.7 (ladder generalization)"},
    "SEEDS": {"class": "control", "note": "random seeds for reproducibility"},
    "STATE_VEC": {"class": "paper-defined", "source": "§5.1 (state vectors)"},
    "TABLE51": {"class": "paper-defined", "source": "§5.1 Table 5.1"},
    "TH": {"class": "declared-assumption", "prose": "§8.6 (TH=1 is Paper 14's locked debt)"},
    "failures": {"class": "control", "note": "test fixture / rejection counter"},
    "mutants_rejected": {"class": "control", "note": "test fixture / rejection counter"},
    "n_checks": {"class": "control", "note": "check counter / accumulator"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port'],
    "notes": "predicate separation over encounters; port-status checks: the port kind only.",
}
#!/usr/bin/env python3
"""F.47: engagement-alteration separation (Sections 3.2, 4.6; registry claim
ENGAGEMENT_ALTERATION_SEPARATION).

Machine-checks the Engagement-Alteration Separation theorem: for all
configurations A, B and all ticks tau, E(A->B, tau) does not entail
Alteration(A, tau) and does not entail Alteration(B, tau) -- with the
encounter-geometry conjunct of E computed from the native Definition
(Encounter Geometry) [L10-P11] (§3.2) as an explicit disjunctive genus.

NATIVE DOMAIN
-------------
- Definition (Encounter Geometry) [L10-P11] (§3.2): configurations X and
  Y occupy encounter geometry at tick tau (in the X->Y direction) iff at
  least one of: (i) port-pair disjunct -- some resolution relationship
  R = (a, p, b, q, sigma) (§3.2) with a an aspect of X, b an aspect of Y,
  sigma = tau; the encounter distance of this disjunct is the relay-hop
  distance (L3 taxicab metric) between the presenting aspects at tau -- a
  defined quantity over existing ledger data; (ii) shell disjunct --
  d >= 1 is the least relay-hop shell at which Y presents a port to X's
  scan at tau -- the §8.5 engagement shell d*(D) for the pair's ambient
  separation at tau. Undirected closure: X and Y occupy encounter
  geometry at tau (undirected) iff the directed relation holds in at
  least one direction. Direction is the §8.6 incoming-against-neighbor
  orientation. The tau-abstraction reading gloss is Level B (not a third
  disjunct); "neighbor" is a non-restrictive gloss. The d >= 1 bound is
  contingent on the parked §8.5 ruling (BREAK 1); the naming of disjunct
  (i) is contingent on the parked tier-(i) wording ruling (BREAK 2) --
  both disclosed in §3.2, the bound enforced here as written.
- Definition (Engagement) [L8-P11] (§4.6): E(A->B, tau) -- at tick tau,
  A and B occupy encounter geometry (directed, L10), and A presents at
  least one non-O boundary port toward B (the §8.6 domain guard).
  Relational: a predicate over (configurations, tick), re-derived every
  tick; it changes nothing structural.
- Definition (Alteration) [L9-P11] (§4.6): Alteration(C, tau) -- at tick
  tau, (i) a port-status change open->closed at C by a completed junction
  in one of Paper 2 §11.1's bonding modes (§§4.1, 6.1: "Establishing a
  junction at a port renders that port closed"); or (ii) a nine-position
  rewrite of C by direct geometric occlusion (Structural Insulation
  Theorem, §4.1; Simple State Insulation, §5.2). Structural: it changes
  what the identity scan reads.
- The §8.5 engagement shell: d*(D) = min{d' : e(D; d') > 0}, where
  e(D; d') is the number of distinct array positions of taxicab norm d'
  coinciding with at least one presented port of B -- the first shell at
  which B presents a port to A's scan.
- The §8.6 selection rule: residue res(A, B), the domain guard (incoming
  presents at least one non-O port; the all-O incoming tuple is refused,
  never scored), the branch trichotomy at TH = 1 (Paper 14's locked debt
  -- declared assumption).
- The §9.2 first-encounter pattern: 27 proximity encounters (nine simple
  states x three documented nucleus-(a) constructions), each scored under
  the §8.6 rule with res = 0.
- The §9.3 chain protocol: res(I, N) = max(0, xI - yN) + max(0, yI - xN),
  m = min(xN, yI) + min(yN, xI); attraction incorporates via
  (xN + xI - m, yN + yI - m, oN + oI), the junction closing 2m ports; the
  distinguished chain trajectory; the aggregate-(b) 81-case enumeration
  (9 states x 9 consumption choices).

INHERITED PREMISES (named, not machine-derived)
-----------------------------------------------
- [L10-P11] §3.2 Definition (Encounter Geometry): the disjunctive genus,
  the §8.5 shell construction, the §8.6 directional orientation, the
  undirected closure, the d >= 1 bound (contingent on the parked §8.5
  ruling -- disclosed, enforced as written).
- [L8-P11] §4.6 Definition (Engagement); [L9-P11] §4.6 Definition
  (Alteration); L3 taxicab relay-hop distance; the §8.5 shell definition
  d*(D) = min{d' : e(D; d') > 0}.
- The Structural Insulation Theorem's Paper 2 §1 content; the Paper 2
  §11.1 bonding modes; the physical premise that real boundary ports
  present X/Y/O-valued tuples (§8.6); the exact TH value (the script
  verifies the fuse shape at TH = 1 (declared assumption); TH-independence
  is F.36's result); the chain protocol as a disclosed working
  construction (the paper states no fixed incorporation rule).

VERIFIED DOMAIN
---------------
- A finite encounter space: 13 configurations (the nine simple states of
  Table 5.1; aggregate (a) under the three documented single-port
  consumption choices; one fully-resolved all-O-presenting node that
  presents no port) x ordered pairs (A != B) x ticks {0, 1, 2}.
- Declared ambient-L3 fixtures (control): configuration reference
  positions on a spacing-3 lattice, per-node offsets, and a port-index to
  unit-direction map placing presented ports in the ambient array. The
  taxicab metric is native L3; the positions are not native.
- The genus G as machine data: an R-tuple event log generated by the
  stated presentation rule (audited for §3.2 well-formedness: p in
  ports(a), q in ports(b), presented ports open, d_rel recomputed), the
  directed genus relation from the disjunction, and the undirected
  closure -- all computed, nothing hardcoded.
- Dual oracles: alpha (record-driven port-pair disjunct + analytic shell
  minimum) and beta (fixture-direct port-pair disjunct + brute-force
  shell enumeration with the N(d) = 4d^2+2 shell-count cross-check);
  agreement verified on all 468 ordered-pair ticks.
- The E∧¬Alt witness, re-exhibited inside G: 396 empty-event E-encounters
  (12 guard-admissible incomings x 11 port-presenting neighbors x 3
  ticks), each with no junction completion and no occlusion on either
  side. The 36 ordered pairs whose neighbor presents no port are excluded
  by the shell disjunct's presentation requirement -- the old
  complete-geometry model admitted them; the genus does not.
- Nine planted mutants M1-M9.

MAP (native -> verified)
------------------------
1. Native configuration -> node record: nine-position content matrix,
   tilt triple, six port statuses with categorical labels; plus a
   declared ambient position (control fixture).
2. Native resolution relationship R -> R-tuple event record
   (a, p, b, q, tau) with the §3.2 well-formedness audit; native
   relay-hop distance -> taxicab distance over the fixture coordinates
   (computed -- a defined quantity over existing ledger data).
3. Native engagement shell -> d*(D) computed by both oracles from
   presented-port positions, the d >= 1 bound enforced by construction.
4. Native encounter-geometry verdict -> the computed genus relation G:
   directed disjunction plus undirected closure; native E -> G_dir and
   the §8.6 domain guard.
5. Native presented boundary tuple -> category count vector (x, y, o);
   the §8.6 rule factors through counts (the F.36 coverage result, reused
   here as a premise of the encoding).
6. Native completed junction -> a recorded junction event flipping the
   port open->closed, per the §6.1 lemma.
7. Native occlusion -> a recorded content-flip event on one
   nine-position entry, per the Structural Insulation Theorem.
8. Native incorporation step -> the node-level update: pair m X/Y ports,
   close 2m ports, append the incoming node; B = 6N - sum(k_j)
   reconciled against the counted open ports.

WHAT THE MAP PRESERVES
----------------------
Disjunct membership, engagement-shell values d*, directed and undirected
encounter verdicts, engagement/admissibility verdicts, selection-rule
outcomes, residue and matched-pair counts, port-status patterns,
nine-position content identity, per-node tilt triples, aggregate node
inventories, the B = 6N - sum(k_j) ledger identity, the E/Alteration
predicate separation, and all nine mutant rejections.

WHAT STAYS OUTSIDE THE MACHINE CHECK
-------------------------------------
- The ambient coordinates themselves (control fixtures -- the L3 taxicab
  metric is native, the positions are not); the d >= 1 bound's
  contingency on the parked §8.5 ruling and the tier-(i) naming
  contingency (both disclosed in §3.2; the bound is enforced as written).
- The tau-abstraction reading gloss and the physical reading of every
  encounter verdict (Level B illustration). This script verifies the
  LOGIC of the predicates given the paper's definitions -- Level A as a
  theorem of the definitions -- not the physics.
- The exact TH value (fuse shape verified at TH = 1, declared
  assumption); the chain protocol as a disclosed working construction.

BADGE NOTE
----------
Level A for the predicate separation and the counting/chain arithmetic
given the documented premises; the encounter verdicts' physical reading
stays Level B illustration. No new native quantity (engagement and
alteration are predicates, not quantities; d* is the §8.5 defined
quantity, not a new one); no new primitives (the genus resolves to
R-tuples, ports, L3 distance, and ticks -- L10-P11 is a derived label).

Exact integer/category arithmetic only; no floats. Deterministic: no
randomness anywhere. Self-contained: imports only the standard library
(copy, sys); no imports from other scripts; runs from any working
directory.
"""

import copy
import sys

OPEN = 'open'
CLOSED = 'closed'
TH = 1  # declared assumption: exact TH is Paper 14's locked debt (§8.6)

# Table 5.1 -- Simple State Inventory (read off the paper verbatim).
# Inside Content = the node's tilt triple; Outside Content = the presented
# boundary tuple (six categorical labels).
TABLE51 = {
    9: {'inside': ('O', 'O', 'O'), 'outside': ('X', 'X', 'X', 'Y', 'Y', 'Y')},
    1: {'inside': ('X', 'X', 'X'), 'outside': ('Y', 'Y', 'Y', 'O', 'O', 'O')},
    2: {'inside': ('X', 'X', 'Y'), 'outside': ('X', 'Y', 'Y', 'O', 'O', 'O')},
    3: {'inside': ('Y', 'Y', 'X'), 'outside': ('X', 'X', 'Y', 'O', 'O', 'O')},
    4: {'inside': ('X', 'Y', 'O'), 'outside': ('X', 'X', 'Y', 'Y', 'O', 'O')},
    5: {'inside': ('X', 'X', 'O'), 'outside': ('X', 'Y', 'Y', 'Y', 'O', 'O')},
    6: {'inside': ('Y', 'Y', 'O'), 'outside': ('X', 'X', 'X', 'Y', 'O', 'O')},
    7: {'inside': ('X', 'O', 'O'), 'outside': ('X', 'X', 'Y', 'Y', 'Y', 'O')},
    8: {'inside': ('Y', 'O', 'O'), 'outside': ('X', 'X', 'X', 'Y', 'Y', 'O')},
}

# Independent hardcoded count vectors (implementation check of the table).
STATE_VEC = {1: (0, 3, 3), 2: (1, 2, 3), 3: (2, 1, 3), 4: (2, 2, 2),
             5: (1, 3, 2), 6: (3, 1, 2), 7: (2, 3, 1), 8: (3, 2, 1),
             9: (3, 3, 0)}

# The three documented nucleus-(a) constructions (single-port consumption
# choice per node; consume-O is the primary). Aggregate (a) = three
# State-4 nodes converged center-to-center with a shared k_j = 3 junction.
SEEDS = {'consume-O': (6, 6, 3), 'consume-X': (3, 6, 6), 'consume-Y': (6, 3, 6)}
CONSUME = {'consume-O': 'O', 'consume-X': 'X', 'consume-Y': 'Y'}

# Distinguished chain: rung order (tie-breaks disclosed in §9.3).
RUNG_ORDER = [9, 7, 8, 1, 2, 3, 4, 5, 6]

# §9.3 published distinguished-chain trajectory, primary seed
# (consume-O): (state, outcome, res, m, B-after, counts-after).
PUBLISHED_PRIMARY = [
    (9, 'attraction',   0, 6, 9, (3, 3, 3)),
    (7, 'attraction',   0, 5, 5, (0, 1, 4)),
    (8, 'forced decay', 4, 1, 5, (0, 1, 4)),
    (1, 'forced decay', 3, 0, 5, (0, 1, 4)),
    (2, 'forced decay', 2, 1, 5, (0, 1, 4)),
    (3, 'forced decay', 2, 1, 5, (0, 1, 4)),
    (4, 'forced decay', 3, 1, 5, (0, 1, 4)),
    (5, 'forced decay', 3, 1, 5, (0, 1, 4)),
    (6, 'forced decay', 3, 1, 5, (0, 1, 4)),
]

# §9.3 published aggregate-(b) marginal set: the seven res = TH = 1
# cases, each under a non-normalized consumption choice.
PUBLISHED_MARGINALS = {(1, 'X', 'X'), (5, 'X', 'X'), (7, 'X', 'X'),
                       (9, 'X', 'X'), (6, 'Y', 'Y'), (8, 'Y', 'Y'),
                       (9, 'Y', 'Y')}

# Declared ambient-L3 fixtures (control): reference spacing between
# configurations and the per-node offset. The taxicab metric is native
# L3; these positions are not.
AMBIENT = {'ref_spacing': 3, 'node_step': (0, 1, 0)}

# Declared port-index to unit-direction map (control): places each open
# port's presented position in the ambient array.
PORT_DIR_MAP = {0: (1, 0, 0), 1: (-1, 0, 0), 2: (0, 1, 0),
                3: (0, -1, 0), 4: (0, 0, 1), 5: (0, 0, -1)}

# Colocated probe fixtures (control) for the d=0 admission mutant: P and Q
# share one reference position (ambient separation D = 0); Q presents a
# single open port AT the scan origin (declared embedding).
PROBE_PAIR = {'P': {'state': 1, 'ref': (0, 0, 0)},
              'Q': {'state': 9, 'ref': (0, 0, 0),
                    'port_positions': [(0, 0, 0)]}}


# ===========================================================================
# Model: configurations, ports, content, ticks, events
# ===========================================================================
def content_matrix(state):
    """Nine-position categorical content matrix, balanced 3/3/3 (Paper 2
    §1). Deterministic per state; categories only ever counted."""
    base = ['X'] * 3 + ['Y'] * 3 + ['O'] * 3
    r = (state - 1) % 9
    rot = tuple(base[r:] + base[:r])
    assert rot.count('X') == 3 and rot.count('Y') == 3 and rot.count('O') == 3
    return rot


def make_node(node_id, state, consumed=None):
    """One configuration-node: tilt triple, content matrix, exactly six
    ports (§4.3 Port Count Invariance). `consumed` names the label
    of the port taken by an interior junction (that port is closed)."""
    outside = list(TABLE51[state]['outside'])
    closed_label = None
    if consumed is not None:
        outside.remove(consumed)  # deterministic: first occurrence
        closed_label = consumed
    ports = [{'node': node_id, 'idx': i, 'label': lab, 'status': OPEN}
             for i, lab in enumerate(outside)]
    if consumed is not None:
        ports.append({'node': node_id, 'idx': 5, 'label': closed_label,
                      'status': CLOSED})
    node = {'id': node_id, 'state': state,
            'tilt': TABLE51[state]['inside'],
            'content': content_matrix(state), 'ports': ports}
    assert len(node['ports']) == 6, "port count invariance"
    return node


def simple_config(name, state):
    return {'name': name, 'kind': 'simple',
            'nodes': [make_node((name, 0), state)], 'junctions': []}


def aggregate_a_config(name, seed):
    nodes = [make_node((name, i), 4, consumed=CONSUME[seed]) for i in range(3)]
    cfg = {'name': name, 'kind': 'aggregate', 'nodes': nodes,
           'junctions': [{'arity': 3, 'note': 'shared center junction'}]}
    assert boundary_vec(cfg) == SEEDS[seed], "seed boundary mismatch"
    return cfg


def resolved_config(name):
    """Fully-resolved node: all six ports closed, presenting all-O. The
    nine-position content is untouched (insulation object intact); only
    the presentation is resolved. Presents no port: exercises the shell
    disjunct's presentation requirement."""
    node = make_node((name, 0), 9)
    for p in node['ports']:
        p['status'] = CLOSED
        p['label'] = 'O'
    return {'name': name, 'kind': 'resolved', 'nodes': [node], 'junctions': []}


def aggregate_b_config(name, c5, c6):
    """Aggregate (b): State-5 + State-6 nodes with one pairwise junction
    (arity 2) consuming one port of category c5 / c6 respectively."""
    n5 = make_node((name, 5), 5, consumed=c5)
    n6 = make_node((name, 6), 6, consumed=c6)
    return {'name': name, 'kind': 'aggregate', 'nodes': [n5, n6],
            'junctions': [{'arity': 2, 'note': 'pairwise junction'}]}


def boundary_vec(cfg):
    """Category count vector (x, y, o) over the OPEN ports."""
    x = y = o = 0
    for n in cfg['nodes']:
        for p in n['ports']:
            if p['status'] == OPEN:
                if p['label'] == 'X':
                    x += 1
                elif p['label'] == 'Y':
                    y += 1
                else:
                    o += 1
    return (x, y, o)


def open_port_count(cfg):
    return sum(1 for n in cfg['nodes'] for p in n['ports']
               if p['status'] == OPEN)


def presents_open(cfg):
    """Whether the configuration presents at least one open port."""
    return any(p['status'] == OPEN
               for n in cfg['nodes'] for p in n['ports'])


def presents_nonO(cfg):
    """The §8.6 domain-guard condition on the incoming side."""
    return any(p['status'] == OPEN and p['label'] != 'O'
               for n in cfg['nodes'] for p in n['ports'])


def aspect_u_list(cfg):
    """u per port-aspect at the contact (§4.2): the count of
    unmatched integers at the aspect's ports -- categorical: 1 iff the
    port is open and non-O, else 0. Exact integers."""
    return [1 if (p['status'] == OPEN and p['label'] != 'O') else 0
            for n in cfg['nodes'] for p in n['ports']]


def snapshot(cfg):
    """The full structural record: tilts, contents, labels, statuses."""
    return tuple(
        (n['id'], n['state'], n['tilt'], n['content'],
         tuple((p['idx'], p['label'], p['status']) for p in n['ports']))
        for n in cfg['nodes'])


# ===========================================================================
# Genus machinery: ambient positions, R-tuple log, the L10-P11 disjunction
# ===========================================================================
def taxicab(p, q):
    """L3 relay-hop distance (native metric) over ambient positions."""
    return abs(p[0] - q[0]) + abs(p[1] - q[1]) + abs(p[2] - q[2])


def assign_positions(configs):
    """Declared ambient fixtures (control): reference positions on the
    spacing lattice, per-node offsets. The metric is native L3; the
    positions are not."""
    s = AMBIENT['ref_spacing']
    dx, dy, dz = AMBIENT['node_step']
    for k, cfg in enumerate(configs):
        ref = (s * k, 0, 0)
        cfg['ref'] = ref
        for j, node in enumerate(cfg['nodes']):
            node['pos'] = (ref[0] + j * dx, ref[1] + j * dy, ref[2] + j * dz)


def presented_positions(cfg):
    """Ambient positions of the configuration's presented (open) ports.
    The PROBE_PAIR override is a declared embedding control."""
    if 'port_positions' in cfg:
        return set(cfg['port_positions'])
    out = set()
    for node in cfg['nodes']:
        px, py, pz = node['pos']
        for p in node['ports']:
            if p['status'] == OPEN:
                ddx, ddy, ddz = PORT_DIR_MAP[p['idx'] % 6]
                out.add((px + ddx, py + ddy, pz + ddz))
    return out


def open_ports(cfg):
    """(node_idx, port_idx) of every open port, deterministic order."""
    return [(ni, pi) for ni, n in enumerate(cfg['nodes'])
            for pi, p in enumerate(n['ports']) if p['status'] == OPEN]


def build_R_records(configs, ticks):
    """The R-tuple event log (control data, generated -- not hardcoded).
    Stated presentation rule: for each ordered pair (A, B), A != B, and
    each tick, if A presents at least one open port and B presents at
    least one open port, record one canonical R = (a, p, b, q, tau) with
    the deterministically-first such ports. The port-pair disjunct is
    existential, so the canonical witness suffices; oracle beta
    re-derives the existential condition from the fixtures directly."""
    records = []
    for A in configs:
        for B in configs:
            if A['name'] == B['name']:
                continue
            aa = open_ports(A)
            bb = open_ports(B)
            if aa and bb:
                ani, api = aa[0]
                bni, bpi = bb[0]
                pa = A['nodes'][ani]['pos']
                pb = B['nodes'][bni]['pos']
                for t in ticks:
                    records.append({'a': (A['name'], ani, api), 'p': api,
                                    'b': (B['name'], bni, bpi), 'q': bpi,
                                    'tau': t, 'd_rel': taxicab(pa, pb)})
    return records


def audit_R_records(records, configs, ticks):
    """§3.2 well-formedness audit of the R-tuple log: for port-aspects,
    ports(a) is the port itself -- p must be that port, open (presented);
    likewise q; the recorded relay-hop distance is recomputed."""
    by_name = {c['name']: c for c in configs}
    for r in records:
        an, ani, api = r['a']
        bn, bni, bpi = r['b']
        chk(an != bn, "R-record with a, b in one configuration")
        chk(r['tau'] in ticks, "R-record tick out of range")
        na = by_name[an]['nodes'][ani]
        nb = by_name[bn]['nodes'][bni]
        chk(0 <= r['p'] < len(na['ports']) and r['p'] == api,
            "R-record p not the a-aspect's own port")
        chk(0 <= r['q'] < len(nb['ports']) and r['q'] == bpi,
            "R-record q not the b-aspect's own port")
        chk(na['ports'][api]['status'] == OPEN, "R-record p not presented")
        chk(nb['ports'][bpi]['status'] == OPEN, "R-record q not presented")
        chk(r['d_rel'] == taxicab(na['pos'], nb['pos']),
            "R-record d_rel not the aspect relay-hop distance")
        chk(r['d_rel'] >= 0, "negative relay-hop distance")


def shell_alpha(A, B):
    """Oracle-alpha shell path (analytic): d*(D) as the minimum, over
    B's presented ports, of the relay-hop distance from A's reference,
    restricted to d' >= 1 -- the d >= 1 bound enforced by construction.
    Returns None iff no presented port of B sits at distance >= 1."""
    ax, ay, az = A['ref']
    best = None
    for (px, py, pz) in presented_positions(B):
        d = abs(px - ax) + abs(py - ay) + abs(pz - az)
        if d >= 1 and (best is None or d < best):
            best = d
    return best


def shell_positions(center, d):
    """All integer ambient positions at taxicab norm exactly d from
    center -- the brute-force shell for oracle beta."""
    cx, cy, cz = center
    out = set()
    for dx in range(-d, d + 1):
        adx = abs(dx)
        for dy in range(-(d - adx), d - adx + 1):
            dz = d - adx - abs(dy)
            out.add((cx + dx, cy + dy, cz + dz))
            if dz:
                out.add((cx + dx, cy + dy, cz - dz))
    return out


def shell_beta(A, B):
    """Oracle-beta shell path (brute force): the least d' >= 1 whose
    taxicab shell about A's reference meets a presented port of B.
    Independent code path from shell_alpha over the same fixtures."""
    presented = presented_positions(B)
    D = taxicab(A['ref'], B['ref'])
    for d in range(1, D + 4):
        if shell_positions(A['ref'], d) & presented:
            return d
    return None


def genus_alpha(A, B, t, record_keys):
    """Oracle alpha: directed genus from the R-tuple log (port-pair
    disjunct) and the analytic shell minimum (shell disjunct)."""
    i = (A['name'], B['name'], t) in record_keys
    ds = shell_alpha(A, B)
    held = i or (ds is not None)
    return held, {'port-pair': i, 'shell': ds is not None, 'd*': ds}


def genus_beta(A, B, t):
    """Oracle beta: directed genus re-derived from the fixtures
    directly -- existential port presentation (port-pair disjunct) and
    brute-force shell enumeration (shell disjunct). Never consults the
    R-tuple log."""
    i = bool(open_ports(A)) and bool(open_ports(B))
    ds = shell_beta(A, B)
    held = i or (ds is not None)
    return held, {'port-pair': i, 'shell': ds is not None, 'd*': ds}


def build_genus(configs, ticks):
    """Constructs the genus G as machine data and cross-checks the two
    oracles on every ordered pair x tick: held verdict, disjunct
    membership, and d* must all agree. Returns (G_DIR, G_UND)."""
    records = build_R_records(configs, ticks)
    audit_R_records(records, configs, ticks)
    record_keys = {(r['a'][0], r['b'][0], r['tau']) for r in records}
    chk(len(records) == len(record_keys),
        "R-tuple log has duplicate (A, B, tau) entries")
    G_DIR_A, G_DIR_B = {}, {}
    for A in configs:
        for B in configs:
            if A['name'] == B['name']:
                continue
            for t in ticks:
                ha, ia = genus_alpha(A, B, t, record_keys)
                hb, ib = genus_beta(A, B, t)
                chk(ha == hb and ia == ib,
                    "oracle disagreement at %s->%s t=%d: alpha=%s beta=%s"
                    % (A['name'], B['name'], t, (ha, ia), (hb, ib)))
                if ia['d*'] is not None:
                    chk(ia['d*'] >= 1,
                        "shell disjunct admitted d*=0 at %s->%s t=%d"
                        % (A['name'], B['name'], t))
                chk(ha == (ia['port-pair'] or ia['shell']),
                    "genus verdict not the disjunction at %s->%s t=%d"
                    % (A['name'], B['name'], t))
                G_DIR_A[(A['name'], B['name'], t)] = (ha, ia)
                G_DIR_B[(A['name'], B['name'], t)] = (hb, ib)
    chk(G_DIR_A == G_DIR_B, "directed genus dicts differ")
    # Per-tick re-derivation stability (§3.3): the builders recompute
    # from the records every tick; with tick-static fixtures (disclosed)
    # the verdicts agree across ticks.
    stable = all(G_DIR_A[(a, b, 0)][0] == G_DIR_A[(a, b, 1)][0] ==
                 G_DIR_A[(a, b, 2)][0]
                 for a in [c['name'] for c in configs]
                 for b in [c['name'] for c in configs] if a != b)
    chk(stable, "genus verdicts not stable under per-tick re-derivation")
    # Undirected closure: at least one directed verdict holds.
    G_UND = {}
    names = [c['name'] for c in configs]
    for x in names:
        for y in names:
            if x >= y:
                continue
            for t in ticks:
                held = G_DIR_A[(x, y, t)][0] or G_DIR_A[(y, x, t)][0]
                chk(held == (G_DIR_A[(x, y, t)][0] or
                             G_DIR_A[(y, x, t)][0]),
                    "undirected closure malformed at {%s,%s} t=%d" % (x, y, t))
                G_UND[(x, y, t)] = held
    return G_DIR_A, G_UND


# --- Predicates ------------------------------------------------------------
def E(A, B, tau, G_DIR):
    """Engagement [L8-P11]: directed encounter geometry at tau (the L10
    genus), and A presents at least one non-O boundary port toward B
    (the §8.6 domain guard). In the proximity channel the whole open
    boundary is presented toward the neighbor."""
    return G_DIR[(A['name'], B['name'], tau)][0] and presents_nonO(A)


def alteration_i(cfg, tick, events):
    """Alteration disjunct (i): port-status change open->closed by a
    completed junction (§§4.1, 6.1)."""
    return any(ev[0] == 'junction'
               for ev in events.get((cfg['name'], tick), []))


def alteration_ii(cfg, tick, events):
    """Alteration disjunct (ii): nine-position rewrite by direct
    geometric occlusion (Structural Insulation Theorem)."""
    return any(ev[0] == 'occlusion'
               for ev in events.get((cfg['name'], tick), []))


def alteration(cfg, tick, events):
    return alteration_i(cfg, tick, events) or alteration_ii(cfg, tick, events)


def score(inc_vec, agg_vec, th=TH):
    """The §8.6 selection rule as a PURE function over immutable
    count vectors: no mutation, no reads of tuple order or port labels."""
    xI, yI, oI = inc_vec
    xN, yN, oN = agg_vec
    assert xI + yI >= 1, "domain guard fired"
    m = min(xN, yI) + min(yN, xI)
    res = max(0, xI - yN) + max(0, yI - xN)
    assert res + m == xI + yI, "Lemma 3 identity"
    if res > th:
        outcome = 'forced decay'
    elif res == 0:
        outcome = 'attraction'
    else:
        outcome = 'repulsion'
    return outcome, res, m


# ===========================================================================
# Check harness
# ===========================================================================
n_checks = 0
failures = []
mutants_rejected = 0


def chk(cond, msg):
    global n_checks
    n_checks += 1
    if not cond:
        failures.append(msg)


def section(title):
    print()
    print("[" + title + "]")


# ===========================================================================
# Section 0 -- shell-count cross-check (Paper 10 N(d) = 4d^2+2)
# ===========================================================================
def section0_shell_counts():
    section("0 shell-count cross-check: oracle beta's enumeration is exact")
    for d in range(1, 41):
        chk(len(shell_positions((0, 0, 0), d)) == 4 * d * d + 2,
            "shell count != 4d^2+2 at d=%d" % d)
    print("  ok: brute-force shell enumeration matches N(d) = 4d^2+2 for "
          "d = 1..40")


# ===========================================================================
# Section 1 -- the genus G, dual-oracle agreement, the E∧¬Alt witness
# ===========================================================================
def build_space():
    configs = []
    for s in range(1, 10):
        configs.append(simple_config('state-%d' % s, s))
    for seed in ('consume-O', 'consume-X', 'consume-Y'):
        configs.append(aggregate_a_config('agg-a/%s' % seed, seed))
    configs.append(resolved_config('resolved-all-O'))
    assign_positions(configs)
    ticks = (0, 1, 2)
    return configs, ticks


def section1_genus_and_witness():
    section("1 genus G: dual-oracle agreement; E∧¬Alt witness inside G")
    configs, ticks = build_space()
    chk(len(configs) == 13, "space has 13 configurations, got %d" % len(configs))
    G_DIR, G_UND = build_genus(configs, ticks)
    n_pairs = 13 * 12 * 3
    chk(len(G_DIR) == n_pairs, "G_DIR has %d entries, want %d"
        % (len(G_DIR), n_pairs))

    # Asymmetry is genuine: pairs whose only directed evidence runs one
    # way exist (the resolved configuration presents no port, so the
    # shell disjunct fires only toward it, never from it).
    names = [c['name'] for c in configs]
    asym = [(x, y, t) for x in names for y in names if x != y for t in ticks
            if G_DIR[(x, y, t)][0] != G_DIR[(y, x, t)][0]]
    chk(len(asym) > 0, "no asymmetric directed encounters in the genus")
    print("  ok: dual oracles agree on all %d ordered-pair ticks "
          "(verdict, disjunct membership, d*); %d asymmetric directed "
          "encounters (direction is load-bearing)"
          % (n_pairs, len(asym)))

    # Undirected closure: every undirected pair has a directed witness;
    # the resolved configuration's pairs are undirected via the single
    # incoming direction alone.
    n_und = sum(1 for v in G_UND.values() if v)
    chk(n_und == 78 * 3, "undirected encounters %d, want 234" % n_und)
    res = next(c for c in configs if c['name'] == 'resolved-all-O')
    s1 = next(c for c in configs if c['name'] == 'state-1')
    chk(G_UND[('resolved-all-O', 'state-1', 0)] and
        G_DIR[('resolved-all-O', 'state-1', 0)][0] and
        not G_DIR[('state-1', 'resolved-all-O', 0)][0],
        "resolved/state-1 not undirected-via-one-direction")
    print("  ok: undirected closure holds on all 234 unordered-pair ticks; "
          "{resolved-all-O, state-1} is undirected via the resolved->state-1 "
          "direction alone (shell disjunct: state-1 presents a port to the "
          "resolved scan at d*=%s)"
          % (G_DIR[('resolved-all-O', 'state-1', 0)][1]['d*'],))

    # The witness, re-exhibited inside G: E with an empty event record
    # entails no alteration of either side.
    events = {}  # proximity encounters: no junction completions, no occlusions
    n_w = n_gdir_noE = n_noG = 0
    for A in configs:
        for B in configs:
            if A['name'] == B['name']:
                continue
            for t in ticks:
                held, info = G_DIR[(A['name'], B['name'], t)]
                if not held:
                    n_noG += 1
                    # The only genus exclusions: the neighbor presents no
                    # port, so neither disjunct can fire.
                    chk(not presents_open(B),
                        "genus exclusion with a presenting neighbor: %s->%s"
                        % (A['name'], B['name']))
                    continue
                # At least one disjunct fires, by construction.
                chk(info['port-pair'] or info['shell'],
                    "held genus verdict with no disjunct: %s->%s t=%d"
                    % (A['name'], B['name'], t))
                e = E(A, B, t, G_DIR)
                if e:
                    n_w += 1
                    # The theorem: E(A->B,t) with no completion and no
                    # occlusion entails no alteration of either side.
                    chk(not alteration(A, t, events),
                        "Alteration(A) under E: %s->%s t=%d"
                        % (A['name'], B['name'], t))
                    chk(not alteration(B, t, events),
                        "Alteration(B) under E: %s->%s t=%d"
                        % (A['name'], B['name'], t))
                    # Domain-guard admissibility (§8.6): the incoming
                    # side presents at least one non-O port.
                    chk(presents_nonO(A),
                        "domain guard failed on E-encounter %s->%s t=%d"
                        % (A['name'], B['name'], t))
                    # Role-assignment protocol (§4.5): u readable per
                    # aspect at the contact; roles re-derived at this tick.
                    uas = aspect_u_list(A)
                    ubs = aspect_u_list(B)
                    chk(all(u in (0, 1) for u in uas + ubs),
                        "u not an exact 0/1 integer at %s->%s t=%d"
                        % (A['name'], B['name'], t))
                    uA, uB = sum(uas), sum(ubs)
                    chk(uA >= 1, "uA < 1 on E-encounter")
                    # No caching: a fresh read of the ports re-derives u.
                    chk(sum(aspect_u_list(A)) == uA and
                        sum(aspect_u_list(B)) == uB,
                        "role inputs not re-derivable at %s->%s t=%d"
                        % (A['name'], B['name'], t))
                    chk((uA > 0) is True, "active(A) not determinate")
                    # Role assignment is F.39's domain, not this script's:
                    # a u-only role predicate (active iff u > 0, passive
                    # iff u == 0) is the exact surrogate F.39 plants and
                    # rejects, so it is not bound or checked here. This
                    # script verifies engagement/alteration separation over
                    # u and port status only.
                else:
                    n_gdir_noE += 1
                    # Genus holds but E fails only via the guard: the
                    # incoming side presents no non-O port.
                    chk(not presents_nonO(A),
                        "non-guard E-failure inside G: %s->%s t=%d"
                        % (A['name'], B['name'], t))
    # The witness count, computed two ways: from the genus builders and
    # from the fixture predicates directly (independent code paths).
    expected_w = sum(1 for A in configs for B in configs for t in ticks
                     if A['name'] != B['name'] and presents_nonO(A)
                     and presents_open(B))
    chk(n_w == expected_w,
        "witness count %d != fixture-derived %d" % (n_w, expected_w))
    chk(n_w + n_gdir_noE + n_noG == n_pairs,
        "witness partition %d+%d+%d != %d"
        % (n_w, n_gdir_noE, n_noG, n_pairs))
    print("  ok: witness re-exhibited inside G: %d empty-event E-encounters, "
          "zero alteration violations" % n_w)
    print("  ok: %d genus-held pairs refused by the guard (all-O incoming); "
          "%d ordered pairs excluded from the genus (neighbor presents no "
          "port)" % (n_gdir_noE, n_noG))
    print("  ok: every E-encounter admissible for the §8.6 domain guard "
          "and the §4.5 role protocol (u re-derived per tick)")
    return configs, ticks, G_DIR, G_UND


# ===========================================================================
# Section 2 -- First-encounter scoring invariance (realizability witness)
# ===========================================================================
def genus_membership(A, B):
    """Genus verdict for a freshly-built pair (oracle beta, direct):
    temporary ambient fixtures -- distinct references at D = 3 -- then
    the disjunction. Used for scored pairs built outside the main
    13-configuration space."""
    A['ref'] = (0, 0, 0)
    B['ref'] = (3, 0, 0)
    for j, n in enumerate(A['nodes']):
        n['pos'] = (0, j, 0)
    for j, n in enumerate(B['nodes']):
        n['pos'] = (3, j, 0)
    held, _info = genus_beta(A, B, 0)
    return held


def section2_scoring_invariance(G_DIR):
    section("2 first-encounter scoring invariance: scoring changes nothing")
    # 27 proximity encounters: nine simple states x three constructions.
    # Each scored pair occupies the genus (both sides present ports).
    n_attr = 0
    for s in range(1, 10):
        chk(boundary_vec(simple_config('probe', s)) == STATE_VEC[s],
            "state %d vector mismatch" % s)
    for s in range(1, 10):
        for seed in ('consume-O', 'consume-X', 'consume-Y'):
            A = simple_config('state-%d' % s, s)
            B = aggregate_a_config('agg-a/%s' % seed, seed)
            chk(genus_membership(A, B),
                "scored pair state-%d x %s outside the genus" % (s, seed))
            before = (snapshot(A), snapshot(B))
            outcome, res, m = score(boundary_vec(A), boundary_vec(B))
            chk((snapshot(A), snapshot(B)) == before,
                "state-%d x %s: structure changed by scoring" % (s, seed))
            chk(outcome in ('attraction', 'repulsion', 'forced decay'),
                "state-%d x %s: no verdict" % (s, seed))
            chk(outcome == 'attraction' and res == 0,
                "state-%d x %s: want attraction/res=0, got %s/res=%d"
                % (s, seed, outcome, res))
            # Strict presented-tension decrease (§9.2): the scored
            # attraction resolves 2m non-O presentations.
            xI, yI, _oI = boundary_vec(A)
            xN, yN, _oN = boundary_vec(B)
            t_before = (xI + yI) + (xN + yN)
            chk(t_before - 2 * m < t_before,
                "state-%d x %s: tension not strictly decreased" % (s, seed))
            n_attr += 1
    chk(n_attr == 27, "scored %d, want 27" % n_attr)
    print("  ok: 27/27 first encounters score attraction/res=0 as PURE "
          "functions; every (inside, outside) pair and every port status "
          "bit-identical before/after; strict tension decrease; all 27 "
          "pairs inside the genus")

    # 81-case aggregate-(b) enumeration: 9 states x 9 consumption choices.
    # Exercises the attraction, marginal-repulsion, and (null) forced-decay
    # branches; the distinguished chain (§4) exercises forced decay.
    section("2b aggregate-(b) 81-case enumeration: all verdict branches")
    n_a = n_m = n_d = 0
    marginals = []
    for c5 in ('O', 'X', 'Y'):
        for c6 in ('O', 'X', 'Y'):
            B = aggregate_b_config('agg-b/(%s,%s)' % (c5, c6), c5, c6)
            if (c5, c6) == ('O', 'O'):
                chk(boundary_vec(B) == (4, 4, 2), "normalized (b) not (4,4,2)")
                chk(open_port_count(B) == 10, "normalized (b) B != 10")
            for s in range(1, 10):
                A = simple_config('state-%d' % s, s)
                chk(genus_membership(A, B),
                    "scored pair b/(%s,%s) state-%d outside the genus"
                    % (c5, c6, s))
                before = (snapshot(A), snapshot(B))
                outcome, res, m = score(boundary_vec(A), boundary_vec(B))
                chk((snapshot(A), snapshot(B)) == before,
                    "b/(%s,%s) state-%d: changed by scoring" % (c5, c6, s))
                if res == TH:
                    n_m += 1
                    marginals.append((s, c5, c6))
                    chk(outcome == 'repulsion', "res=TH not repulsion")
                elif res > TH:
                    n_d += 1
                else:
                    n_a += 1
                    chk(outcome == 'attraction', "res=0 not attraction")
    chk(n_a + n_m + n_d == 81, "enumerated %d, want 81" % (n_a + n_m + n_d))
    chk((n_a, n_m, n_d) == (74, 7, 0),
        "want 74/7/0, got %d/%d/%d" % (n_a, n_m, n_d))
    chk(set(marginals) == PUBLISHED_MARGINALS,
        "marginal set mismatch: %s" % (set(marginals) ^ PUBLISHED_MARGINALS,))
    print("  ok: 81/81 cases enumerated: %d attraction, %d marginal "
          "(res=TH) repulsion, %d forced decay -- scoring pure throughout; "
          "all 81 pairs inside the genus" % (n_a, n_m, n_d))


# ===========================================================================
# Section 3 -- The disjuncts are structural, not entailed by E
# ===========================================================================
def apply_junction_completion(cfg, tick, events, node_idx=0):
    """Genuine Alteration-(i): complete a junction at an open port --
    the port flips open->closed, the content is untouched (§6.1)."""
    cfg = copy.deepcopy(cfg)
    node = cfg['nodes'][node_idx]
    port = next(p for p in node['ports'] if p['status'] == OPEN)
    assert port['status'] == OPEN
    port['status'] = CLOSED
    events.setdefault((cfg['name'], tick), []).append(
        ('junction', node['id'], port['idx']))
    return cfg, (node['id'], port['idx'])


def apply_occlusion(cfg, tick, events, node_idx=0, pos=0):
    """Genuine Alteration-(ii): direct geometric occlusion rewrites one
    nine-position entry (Structural Insulation Theorem); ports untouched."""
    cfg = copy.deepcopy(cfg)
    node = cfg['nodes'][node_idx]
    old = node['content'][pos]
    flip = {'X': 'Y', 'Y': 'O', 'O': 'X'}
    lst = list(node['content'])
    lst[pos] = flip[old]
    node['content'] = tuple(lst)
    events.setdefault((cfg['name'], tick), []).append(
        ('occlusion', node['id'], pos))
    return cfg, (node['id'], pos, old, lst[pos])


def section3_disjuncts_structural(G_DIR):
    section("3 disjuncts are structural: junction completion and occlusion")
    A = simple_config('state-1', 1)
    B = aggregate_a_config('agg-a/consume-O', 'consume-O')
    chk(E(A, B, 0, G_DIR), "witness encounter not engaged")
    held, info = G_DIR[('state-1', 'agg-a/consume-O', 0)]
    print("  witness encounter: state 1 -> agg-a/consume-O at tick 0, "
          "E holds (incoming presents 3 non-O open ports); genus disjuncts: "
          "port-pair=%s, shell=%s (d*=%s)"
          % (info['port-pair'], info['shell'], info['d*']))

    # (i) Junction completion flips a port status open->closed; the
    # nine-position content is unchanged; the neighbor is untouched.
    ev = {}
    A2, closed = apply_junction_completion(A, 0, ev)
    chk(alteration_i(A2, 0, ev), "Alteration-(i) not recorded")
    chk(not alteration_ii(A2, 0, ev), "Alteration-(ii) spuriously recorded")
    chk(A2['nodes'][0]['content'] == A['nodes'][0]['content'],
        "junction completion changed content")
    others = [p['status'] for n in A2['nodes'] for p in n['ports']]
    chk(others.count(CLOSED) == 1, "more than one port flipped")
    chk(not alteration(B, 0, ev), "neighbor altered by A's junction")
    print("  ok: junction completion closes exactly one port (node %s "
          "port %d); content bit-identical; neighbor untouched"
          % (closed[0], closed[1]))

    # (ii) Occlusion flips one nine-position entry; ports are untouched.
    ev2 = {}
    B2, occ = apply_occlusion(B, 0, ev2)
    chk(alteration_ii(B2, 0, ev2), "Alteration-(ii) not recorded")
    chk(not alteration_i(B2, 0, ev2), "Alteration-(i) spuriously recorded")
    b_ports = [p['status'] for n in B2['nodes'] for p in n['ports']]
    chk(b_ports == [p['status'] for n in B['nodes'] for p in n['ports']],
        "occlusion changed a port status")
    n_changed = sum(1 for a, b in zip(B2['nodes'][0]['content'],
                                     B['nodes'][0]['content']) if a != b)
    chk(n_changed == 1, "occlusion changed %d entries, want 1" % n_changed)
    chk(not alteration(A, 0, ev2), "A altered by B's occlusion")
    print("  ok: occlusion rewrites exactly one nine-position entry "
          "(%s -> %s); all port statuses unchanged" % (occ[2], occ[3]))

    # Neither transition is reachable from the engagement predicate alone:
    # over the whole genus, E fired with an EMPTY event record, so no
    # genuine transition ever fired on engagement alone.
    fired = 0
    n_e = 0
    configs, ticks = build_space()
    for X in configs:
        for Y in configs:
            if X['name'] == Y['name']:
                continue
            for t in ticks:
                if E(X, Y, t, G_DIR):
                    n_e += 1
                    if alteration(X, t, {}) or alteration(Y, t, {}):
                        fired += 1
    chk(n_e > 0, "no E-encounters in the genus")
    chk(fired == 0, "%d transitions fired from engagement alone" % fired)
    print("  ok: %d E-encounters inside G with empty event record -> 0 "
          "genuine transitions; engagement alone reaches neither disjunct"
          % n_e)


# ===========================================================================
# Section 4 -- Incorporation preserves node identity (distinguished chain)
# ===========================================================================
def pair_and_close(agg, inc, need_ax, need_ay):
    """Pair need_ax aggregate-X with incoming-Y ports and need_ay
    aggregate-Y with incoming-X ports; close all paired ports. Returns
    the number of ports closed (2m). Deterministic port order."""
    def open_ports(cfg, label):
        return [p for n in cfg['nodes'] for p in n['ports']
                if p['status'] == OPEN and p['label'] == label]
    ax, iy = open_ports(agg, 'X')[:need_ax], open_ports(inc, 'Y')[:need_ax]
    chk(len(ax) == need_ax and len(iy) == need_ax, "pairing shortfall X/Y")
    ay, ix = open_ports(agg, 'Y')[:need_ay], open_ports(inc, 'X')[:need_ay]
    chk(len(ay) == need_ay and len(ix) == need_ay, "pairing shortfall Y/X")
    pairs = list(zip(ax, iy)) + list(zip(ay, ix))
    for p, q in pairs:
        p['status'] = CLOSED
        q['status'] = CLOSED
    return 2 * len(pairs)


def ledger_B(agg):
    """B = 6N - sum(k_j): the aggregate boundary count from the paper's
    general (arbitrary-arity) form -- the pairwise corollary is never used."""
    N = len(agg['nodes'])
    return 6 * N - sum(j['arity'] for j in agg['junctions'])


def run_distinguished_chain(seed, check_table):
    agg = aggregate_a_config('agg-a/%s' % seed, seed)
    counts = SEEDS[seed]
    chk(open_port_count(agg) == 15, "seed %s: open ports != 15" % seed)
    chk(ledger_B(agg) == 15, "seed %s: B != 15" % seed)
    for step, s in enumerate(RUNG_ORDER):
        inc = simple_config('inc-%d' % step, s)
        new_id = ('inc', step)
        inc['nodes'][0]['id'] = new_id
        iv = STATE_VEC[s]
        xN, yN, oN = counts
        xI, yI, oI = iv
        m = min(xN, yI) + min(yN, xI)
        res = max(0, xI - yN) + max(0, yI - xN)
        chk(res + m == xI + yI, "step %d: Lemma 3 identity" % step)
        if res > TH:
            outcome = 'forced decay'
        elif res == 0:
            outcome = 'attraction'
        else:
            outcome = 'repulsion'
        B_now = ledger_B(agg)
        before_ids = [n['id'] for n in agg['nodes']]
        before_tilts = {n['id']: n['tilt'] for n in agg['nodes']}
        before_snap = snapshot(agg)
        if outcome == 'attraction':
            # Incorporation = Alteration-(i): a completed junction closes
            # 2m ports; every node's tilt triple (its 27-state identity)
            # is preserved; the inventory is the disjoint union.
            closed = pair_and_close(agg, inc, min(xN, yI), min(yN, xI))
            chk(closed == 2 * m, "step %d: closed %d != 2m" % (step, closed))
            agg['junctions'].append({'arity': 2 * m,
                                    'note': 'incorporation junction'})
            agg['nodes'].append(inc['nodes'][0])
            counts = (xN + xI - m, yN + yI - m, oN + oI)
            chk(counts[0] >= 0 and counts[1] >= 0,
                "step %d: update left the count domain" % step)
            after_ids = [n['id'] for n in agg['nodes']]
            chk(after_ids == before_ids + [new_id],
                "step %d: inventory not prior + incorporated" % step)
            chk(new_id not in before_ids,
                "step %d: incorporated node not disjoint" % step)
            chk(len(set(map(str, after_ids))) == len(after_ids),
                "step %d: node ids not unique" % step)
            after_tilts = {n['id']: n['tilt'] for n in agg['nodes']}
            chk(all(after_tilts[i] == before_tilts[i] for i in before_tilts),
                "step %d: a tilt triple changed" % step)
            new_node = agg['nodes'][-1]
            n_closed = sum(1 for p in new_node['ports']
                           if p['status'] == CLOSED)
            chk(n_closed == m and len(new_node['ports']) - n_closed == 6 - m,
                "step %d: incorporated node port bookkeeping" % step)
            # B reconciles three ways: ledger, counted open ports, counts.
            B_ledger = ledger_B(agg)
            chk(B_ledger == open_port_count(agg),
                "step %d: B != counted open ports" % step)
            chk(B_ledger == sum(counts),
                "step %d: B != x+y+o" % step)
            if check_table:
                chk(B_ledger == PUBLISHED_PRIMARY[step][4],
                    "step %d: B mismatch" % step)
        else:
            # Repulsion / forced decay: no incorporation; aggregate unchanged.
            chk(snapshot(agg) == before_snap,
                "step %d: aggregate changed without incorporation" % step)
            chk(counts == (xN, yN, oN), "step %d: counts drifted" % step)
        if check_table:
            want = PUBLISHED_PRIMARY[step]
            got = (s, outcome, res, m, ledger_B(agg), counts)
            chk(got == want,
                "step %d: trajectory %s != published %s" % (step, got, want))
    return counts


def section4_incorporation_identity():
    section("4 incorporation preserves node identity (distinguished chain)")
    for seed in ('consume-O', 'consume-X', 'consume-Y'):
        final = run_distinguished_chain(seed, check_table=(seed == 'consume-O'))
        print("  ok: seed %s chain complete; per-attraction: tilt triples "
              "identical, inventory = prior + incorporated (disjoint), "
              "B = 6N - sum(k_j) reconciles open ports and x+y+o; "
              "final counts %s" % (seed, final))
    print("  ok: primary-seed trajectory matches the §9.3 published "
          "table step-for-step (2 incorporations, then 7 forced decays)")


# ===========================================================================
# Section 5 -- Nine planted mutants, each rejected with a printed witness
# ===========================================================================
def planted_m1_close_on_engagement(A, B, tau, G_DIR):
    """M1: engagement entails port closure (E => Alteration-(i))."""
    A2 = copy.deepcopy(A)
    hit = None
    if E(A2, B, tau, G_DIR):
        for n in A2['nodes']:
            for p in n['ports']:
                if p['status'] == OPEN:
                    p['status'] = CLOSED
                    hit = (n['id'], p['idx'])
                    break
            if hit:
                break
    return A2, hit


def planted_m2_rewrite_on_engagement(A, B, tau, G_DIR):
    """M2: engagement entails nine-position rewrite (E => Alteration-(ii))."""
    A2 = copy.deepcopy(A)
    hit = None
    if E(A2, B, tau, G_DIR):
        node = A2['nodes'][0]
        flip = {'X': 'Y', 'Y': 'O', 'O': 'X'}
        lst = list(node['content'])
        old = lst[0]
        lst[0] = flip[old]
        node['content'] = tuple(lst)
        hit = (node['id'], 0, old, lst[0])
    return A2, hit


def planted_m3_collapsed_E(A, B, tau, events):
    """M3: predicate collapse -- engagement defined as junction
    completion (E <=> Alteration-(i))."""
    return alteration_i(A, tau, events) or alteration_i(B, tau, events)


def planted_m4_alteration_by_proximity(cfg, tick, events, encounters):
    """M4: alteration-by-proximity -- an alteration rule whose disjuncts
    include bare proximity (undirected encounter geometry)."""
    if alteration(cfg, tick, events):
        return True
    return any(t == tick and (a == cfg['name'] or b == cfg['name']) and g_flag
               for (a, b, t, g_flag) in encounters)


def planted_m5_simple_only(A, B, tau, G_DIR):
    """M5: simple-state-only content alteration on engagement."""
    A2 = copy.deepcopy(A)
    hit = None
    if E(A2, B, tau, G_DIR) and A2['kind'] == 'simple':
        node = A2['nodes'][0]
        flip = {'X': 'Y', 'Y': 'O', 'O': 'X'}
        lst = list(node['content'])
        old = lst[0]
        lst[0] = flip[old]
        node['content'] = tuple(lst)
        hit = (node['id'], 0, old, lst[0])
    return A2, hit


def shell_d0_mutant(A, B):
    """M6: d=0 admission mutant -- the shell construction with the d >= 1
    bound dropped (minimum over d' >= 0)."""
    ax, ay, az = A['ref']
    best = None
    for (px, py, pz) in presented_positions(B):
        d = abs(px - ax) + abs(py - ay) + abs(pz - az)
        if best is None or d < best:
            best = d
    return best


def build_probe_pair():
    """The colocated probe pair (control fixtures): P and Q share one
    reference position (D = 0); Q presents a single open port AT the scan
    origin (declared embedding)."""
    P = simple_config('probe-P', PROBE_PAIR['P']['state'])
    P['ref'] = PROBE_PAIR['P']['ref']
    P['nodes'][0]['pos'] = PROBE_PAIR['P']['ref']
    Q = simple_config('probe-Q', PROBE_PAIR['Q']['state'])
    Q['ref'] = PROBE_PAIR['Q']['ref']
    Q['nodes'][0]['pos'] = PROBE_PAIR['Q']['ref']
    Q['port_positions'] = list(PROBE_PAIR['Q']['port_positions'])
    return P, Q


def genus_flip_mutant(A, B, t):
    """M7: direction-flip mutant -- computes the OPPOSITE orientation's
    genus verdict and labels it as this orientation's."""
    return genus_beta(B, A, t)


def gund_no_closure_mutant(x, y, t, G_DIR):
    """M8: dropped-undirected-closure mutant -- the "undirected" verdict
    is just the directed x->y verdict; the other-direction step is
    dropped."""
    return G_DIR[(x, y, t)][0]


def genus_collapsed_mutant(A, B, t, record_keys):
    """M9: engagement-collapse mutant -- the genus collapsed to the
    port-pair disjunct alone; the shell disjunct is dropped."""
    i = (A['name'], B['name'], t) in record_keys
    return i, {'port-pair': i}


def section5_planted_mutants(G_DIR):
    global mutants_rejected
    section("5 planted mutants M1-M9: each rejected with a printed witness")

    # The genuine record: the 27 §2 encounters, scored as pure
    # functions -- zero port changes, zero content changes anywhere.
    pairs27 = []
    for s in range(1, 10):
        for seed in ('consume-O', 'consume-X', 'consume-Y'):
            pairs27.append((simple_config('state-%d' % s, s),
                            aggregate_a_config('agg-a/%s' % seed, seed)))

    # M1: engagement entails port closure.
    m1_hits = 0
    witness = None
    for A, B in pairs27:
        A2, hit = planted_m1_close_on_engagement(A, B, 0, G_DIR)
        if hit:
            m1_hits += 1
            if witness is None:
                witness = (A['name'], B['name'], hit)
        chk(snapshot(A2) != snapshot(A) or hit is None, "M1 bookkeeping")
    chk(m1_hits == 27, "M1 fired %d/27" % m1_hits)
    chk(witness is not None, "M1 witness missing")
    print("  MUTANT M1 (engagement entails port closure): REJECTED -- "
          "witness: %s -> %s at tick 0: E holds inside G (both disjuncts "
          "fire); genuine record over the 27 first encounters: 0 "
          "port-status changes; the mutant closes port %d of the incoming "
          "node here, 27 ports across the 27 encounters. E => "
          "Alteration-(i) does not hold."
          % (witness[0], witness[1], witness[2][1]))
    mutants_rejected += 1

    # M2: engagement entails nine-position rewrite.
    m2_hits = 0
    witness = None
    for A, B in pairs27:
        A2, hit = planted_m2_rewrite_on_engagement(A, B, 0, G_DIR)
        if hit:
            m2_hits += 1
            if witness is None:
                witness = (A['name'], B['name'], hit)
    chk(m2_hits == 27, "M2 fired %d/27" % m2_hits)
    print("  MUTANT M2 (engagement entails nine-position rewrite): "
          "REJECTED -- witness: %s -> %s at tick 0: E holds inside G; "
          "genuine record: every nine-position content bit-identical on "
          "all 27 encounters; the mutant flips position 0 of the incoming "
          "node's matrix (%s -> %s). E => Alteration-(ii) does not hold."
          % (witness[0], witness[1], witness[2][2], witness[2][3]))
    mutants_rejected += 1

    # M3: predicate collapse E <=> Alteration-(i).
    events = {}
    e_true = sum(1 for A, B in pairs27 if E(A, B, 0, G_DIR))
    collapsed = sum(1 for A, B in pairs27
                    if planted_m3_collapsed_E(A, B, 0, events))
    chk(e_true == 27, "genuine E holds %d/27" % e_true)
    chk(collapsed == 0, "collapsed predicate holds %d/27" % collapsed)
    A0, B0 = pairs27[0]
    print("  MUTANT M3 (engagement defined as junction completion): "
          "REJECTED -- witness: %s -> %s at tick 0: genuine E holds "
          "inside G (domain guard satisfied, scored under the §8.6 rule), "
          "Alteration-(i) false on both sides, so the collapsed "
          "predicate is false. 27/27 scored encounters satisfy E with "
          "no completion -- the biconditional fails on every one."
          % (A0['name'], B0['name']))
    mutants_rejected += 1

    # M4: alteration-by-proximity -- bare proximity as a disjunct.
    configs, ticks = build_space()
    _G2, U2 = build_genus(configs, ticks)
    prox = [(a, b, t, U2[(a, b, t)])
            for a in [c['name'] for c in configs]
            for b in [c['name'] for c in configs] if a < b for t in (0,)]
    genuine = sum(1 for c in configs if alteration(c, 0, {}))
    mutant = sum(1 for c in configs
                 if planted_m4_alteration_by_proximity(c, 0, {}, prox))
    chk(genuine == 0, "genuine alteration fired %d" % genuine)
    chk(mutant == len(configs),
        "M4 fired %d/%d" % (mutant, len(configs)))
    wit = next(c['name'] for c in configs if c['kind'] == 'simple')
    print("  MUTANT M4 (alteration rule with bare proximity as a "
          "disjunct): REJECTED -- witness: %s at tick 0: the mutant "
          "claims Alteration with neither disjunct (i) nor (ii) present "
          "(no junction completions, no occlusions anywhere in the "
          "genus); genuine record: 0 alterations. Rejected against the "
          "§4.1 / §5.2 insulation encoding." % wit)
    mutants_rejected += 1

    # M5: simple-state-only content alteration on engagement.
    m5_hits = 0
    witness = None
    for A, B in pairs27:
        A2, hit = planted_m5_simple_only(A, B, 0, G_DIR)
        if hit:
            m5_hits += 1
            if witness is None:
                witness = (A['name'], B['name'], hit)
    chk(m5_hits == 27, "M5 fired %d/27" % m5_hits)
    # The mutant's complex-configuration exemption, shown on an
    # aggregate->aggregate E-encounter (E holds; the mutant spares it).
    AX = aggregate_a_config('agg-a/consume-X', 'consume-X')
    AO = aggregate_a_config('agg-a/consume-O', 'consume-O')
    chk(E(AX, AO, 0, G_DIR), "aggregate E-encounter not engaged")
    AX2, hit_agg = planted_m5_simple_only(AX, AO, 0, G_DIR)
    chk(hit_agg is None and snapshot(AX2) == snapshot(AX),
        "M5 altered a complex configuration")
    print("  MUTANT M5 (simple-state-only content alteration on "
          "engagement): REJECTED -- witness: %s -> %s at tick 0: the "
          "mutant flips the simple state's matrix position 0 (%s -> "
          "%s) while sparing complex configurations on engaged "
          "encounters (agg-a/consume-X -> agg-a/consume-O: E holds "
          "inside G, mutant alters nothing). Genuine record: 0 content "
          "changes on all encounters, simple or complex. The mutant "
          "makes simple states strictly less insulated than complex "
          "configurations, contradicting the §5.2 encoding."
          % (witness[0], witness[1], witness[2][2], witness[2][3]))
    mutants_rejected += 1

    # M6: d=0 admission mutant -- the shell construction with the d >= 1
    # bound dropped. d >= 1 is definitional (§3.2, L10-P11); the live
    # d* = 0 case is the parked §8.5 contingency, outside this genus.
    P, Q = build_probe_pair()
    chk(taxicab(P['ref'], Q['ref']) == 0, "probe pair not colocated")
    genuine_shell = shell_alpha(P, Q)
    chk(genuine_shell is None,
        "genuine shell disjunct fired on the colocated probe pair")
    chk(shell_beta(P, Q) is None, "oracle beta disagrees on the probe pair")
    mutant_shell = shell_d0_mutant(P, Q)
    chk(mutant_shell == 0, "M6 did not admit d=0 (got %s)" % (mutant_shell,))
    print("  MUTANT M6 (d=0 admission: shell minimum over d' >= 0): "
          "REJECTED -- witness: the colocated probe pair (D = 0; Q "
          "presents one open port AT the scan origin): the genuine "
          "construction (minimum over d' >= 1) admits no shell disjunct "
          "(both oracles agree: None); the mutant admits a shell-disjunct "
          "encounter at d* = 0. d >= 1 is definitional in L10-P11; the "
          "mutant's d = 0 encounter geometry is rejected.")
    mutants_rejected += 1

    # M7: direction-flip mutant -- the opposite orientation's genus
    # verdict presented as this orientation's.
    R = next(c for c in configs if c['name'] == 'resolved-all-O')
    S1 = next(c for c in configs if c['name'] == 'state-1')
    g_RS1, info_RS1 = G_DIR[('resolved-all-O', 'state-1', 0)]
    g_S1R, _info_S1R = G_DIR[('state-1', 'resolved-all-O', 0)]
    chk(g_RS1 and not g_S1R, "M7 setup: genus not asymmetric here")
    f_RS1, _ = genus_flip_mutant(R, S1, 0)
    f_S1R, _ = genus_flip_mutant(S1, R, 0)
    chk(f_RS1 != g_RS1 and f_S1R != g_S1R,
        "M7 did not diverge on the asymmetric pair")
    print("  MUTANT M7 (direction-flip: opposite orientation's verdict): "
          "REJECTED -- witness: resolved-all-O -> state-1 at tick 0: "
          "genuine directed genus HOLDS (shell disjunct: state-1 presents "
          "a port to the resolved scan at d*=%s); the mutant, reading the "
          "flipped orientation (resolved-all-O presents nothing to "
          "state-1's scan), reports NO encounter geometry -- dropping a "
          "genuine directed encounter. In the reverse direction the "
          "mutant FABRICATES one: genuine state-1 -> resolved-all-O is "
          "False, the mutant reports True. Direction (§8.6 "
          "incoming-against-neighbor) is load-bearing."
          % (info_RS1['d*'],))
    mutants_rejected += 1

    # M8: dropped-undirected-closure mutant -- "undirected" defined as
    # the directed x->y verdict alone. An undirected relation must be
    # symmetric in its arguments; dropping the closure step makes the
    # verdict order-sensitive.
    names = [c['name'] for c in configs]
    bad = [(x, y, t) for x in names for y in names if x != y for t in ticks
           if (G_DIR[(x, y, t)][0] or G_DIR[(y, x, t)][0]) !=
           gund_no_closure_mutant(x, y, t, G_DIR)]
    chk(len(bad) > 0, "M8 did not diverge anywhere")
    asym = [(x, y, t) for (x, y, t) in bad
            if gund_no_closure_mutant(x, y, t, G_DIR) !=
            gund_no_closure_mutant(y, x, t, G_DIR)]
    chk(len(asym) > 0, "M8's 'undirected' verdict is symmetric?!")
    x0, y0, t0 = bad[0]
    print("  MUTANT M8 (dropped undirected closure): REJECTED -- witness: "
          "{%s, %s} at tick %d: genuinely undirected (the directed genus "
          "holds %s->%s); the mutant, evaluating the dropped-closure "
          "'undirected' verdict in the %s->%s order, reports False. The "
          "mutant's verdict is not even symmetric -- True in one argument "
          "order, False in the other -- because the at-least-one-direction "
          "closure step is dropped. %d ordered evaluations diverge."
          % (x0, y0, t0, y0, x0, x0, y0, len(bad)))
    mutants_rejected += 1

    # M9: engagement-collapse mutant -- the genus collapsed to the
    # port-pair disjunct alone (shell disjunct dropped).
    rec_keys = {(r['a'][0], r['b'][0], r['tau'])
                for r in build_R_records(configs, ticks)}
    missed = [(a, b, t) for a in names for b in names if a != b
              for t in ticks
              if G_DIR[(a, b, t)][0] and
              not genus_collapsed_mutant(
                  next(c for c in configs if c['name'] == a),
                  next(c for c in configs if c['name'] == b),
                  t, rec_keys)[0]]
    chk(len(missed) > 0, "M9 did not diverge anywhere")
    # Every missed pair is shell-only: the port-pair disjunct genuinely
    # fails there.
    chk(all(not G_DIR[(a, b, t)][1]['port-pair'] and
            G_DIR[(a, b, t)][1]['shell'] for (a, b, t) in missed),
        "M9 missed a non-shell-only pair")
    a0, b0, t0 = missed[0]
    print("  MUTANT M9 (engagement-collapse: port-pair disjunct only): "
          "REJECTED -- witness: %s -> %s at tick %d: genuine directed "
          "genus HOLDS via the shell disjunct alone (port-pair disjunct "
          "fails: %s presents no open port, so no R-tuple exists); the "
          "collapsed genus reports NO encounter geometry. %d directed "
          "encounters are shell-only; collapsing the disjunction drops "
          "every one." % (a0, b0, t0, a0, len(missed)))
    mutants_rejected += 1


# ===========================================================================
# Main
# ===========================================================================
def main():
    print("F.47 engagement-alteration separation: machine check")
    print("genus G from the L10-P11 definition (§3.2); dual oracles; "
          "exact integer/category arithmetic; deterministic; self-contained")
    section0_shell_counts()
    configs, ticks, G_DIR, G_UND = section1_genus_and_witness()
    section2_scoring_invariance(G_DIR)
    section3_disjuncts_structural(G_DIR)
    section4_incorporation_identity()
    section5_planted_mutants(G_DIR)
    print()
    print("checks run: %d | mutants rejected: %d/9"
          % (n_checks, mutants_rejected))
    if failures or mutants_rejected != 9:
        print("F.47 RESULT: FAIL")
        for f in failures[:20]:
            print("  - " + f)
        if len(failures) > 20:
            print("  ... (%d more)" % (len(failures) - 20))
        sys.exit(1)
    print("F.47 RESULT: ALL CHECKS PASSED (exit 0)")
    print("Badge: predicate separation and counting Level A given the "
          "documented premises (L10-P11/§3.2 named among the inherited "
          "premises); the physical reading of every encounter verdict "
          "stays Level B illustration. No Level-A encounter badges issued.")


if __name__ == '__main__':
    main()
