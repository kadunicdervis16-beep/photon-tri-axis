#!/usr/bin/env python3
"""
F.46 -- Case A ladder: machine check of the nine worked §9 encounters.
=======================================================================
STAGED. NOT WIRED INTO THE PAPER. A discussion gate with Dervis precedes
any wiring-in or v30 build. This script checks the worked encounters of the
staged §9 draft (v14_phase3_section9_draft.md); it does not modify the paper
or any existing script.

NATIVE DOMAIN
-------------
Section 8.6 encounters between a simple state's presented boundary ports
(integer surpluses in {-1, 0, +1}) and a complex configuration's presented
boundary; the residue res(A,B); the selection rule
    res(A,B) > TH  -> forced decay
    res(A,B) = 0   -> attraction
    otherwise      -> repulsion
with the domain guard "incoming A presents at least one nonzero port";
and the §9.6 incorporation ledger (N, J, B, s^2) via B(G) = 6N - sum(k_j).

VERIFIED DOMAIN
---------------
Exact integer arithmetic on surplus count vectors (n+, n-) over the
{-1,0,+1} model domain: the residue formula, the branch trichotomy at the
illustrative TH = 1, matched-pair counts, tension values, and the ledger
identities B_new = 6(N+1) - (sum_k + 2m) with the dual port-decomposition
check B_new = (B - m) + (6 - m).

MAP (native -> verified)
------------------------
  1. Letters -> integers by the documented illustration encoding E0:
         X -> +1 (surplus),  Y -> -1 (deficit),  O -> 0 (neutral).
     (Level B premise: the paper states no X/Y/O -> integer mapping.)
  2. Presented tuple -> count vector. The §8.6 rule factors through counts
     (F.36 coverage theorem); this script independently checks order
     invariance on every worked tuple by permutation (zero-leak): shuffling
     port order never changes counts, residue, or verdict.
  3. Nucleus (a) boundary -> count vector under three documented
     single-port consumption choices (consume one O / X / Y per node).
     Nucleus (b) boundary -> count vector under the workers' documented
     consumption choices.
  4. §9.6 incorporation -> one new junction aspect of arity 2m (working
     geometry, documented; the paper gives no fixed incorporation rule).
     The ledger is then pure port accounting, checked two ways.

WHAT THE MAP PRESERVES
----------------------
Residue values, selection-branch outcomes, tension strict-decrease, and the
ledger identities. A wrong boundary tuple, a swapped outcome label, an
off-by-one junction arity, or a guardless all-zero incoming each break a
preserved identity and are REJECTED below with printed witnesses
(planted mutants M1-M4).

TOTALITY
--------
Analytic, not enumerative: for any nonnegative integer res and any TH with
0 < TH < k, exactly one of the three branches fires (trichotomy over the
nonnegative integers). The encounter space here is bounded and stated
honestly: 9 states x 3 nucleus-(a) constructions = 27 runs, the positron
mirror, and the 15 aggregate-(b) stretch cases the workers ran (12
attraction under documented constructions + 3 marginal repulsion cases,
res = TH = 1, under non-documented consumption choices). Exhaustiveness is
claimed over the worked set, not over the encounter space. The TH band
[1, k-1] is held by F.36, not re-proved here.

WHAT STAYS OUTSIDE THE MACHINE CHECK
------------------------------------
The physical premises the arithmetic is conditional on: the E0 encoding
choice (Level B), the Outside-Content = boundary-tuple equation (Level B
inference), the nucleus consumption-value choices (Level B), the
illustrative TH = 1 (exact TH is Paper 14's locked debt), and the s^2
redistribution (symbolic; per-state values are Paper 8's table, cited not
reproduced). The script verifies the arithmetic GIVEN the premises; it does
not verify the premises. NO ENCOUNTER VERDICT IS BADGED LEVEL A.

Sanitation: no auditor/vulnerability grading language anywhere in this
script. The e.S(d) term, where the paper's standing terminology applies, is
"engagement-weighted scan allocation" (it does not arise in this
computation).
"""

import itertools
import random
import sys

TH = 1  # illustrative; exact TH is Paper 14's locked debt (labeled)

# ---------------------------------------------------------------------------
# Documented premises, printed (Phase-1 policy: the encoding table is printed)
# ---------------------------------------------------------------------------
E0 = {'X': +1, 'Y': -1, 'O': 0}

# Table 5.1 Outside Content (letters), paper lines 446-457.
OUTSIDE = {
    1: ('Y', 'Y', 'Y', 'O', 'O', 'O'),  # electron
    2: ('X', 'Y', 'Y', 'O', 'O', 'O'),
    3: ('X', 'X', 'Y', 'O', 'O', 'O'),
    4: ('X', 'X', 'Y', 'Y', 'O', 'O'),
    5: ('X', 'Y', 'Y', 'Y', 'O', 'O'),
    6: ('X', 'X', 'X', 'Y', 'O', 'O'),
    7: ('X', 'X', 'Y', 'Y', 'Y', 'O'),
    8: ('X', 'X', 'X', 'Y', 'Y', 'O'),
    9: ('X', 'X', 'X', 'Y', 'Y', 'Y'),  # photon
}
POSITRON_OUTSIDE = ('X', 'X', 'X', 'O', 'O', 'O')  # State-1 mirror

STATE4_OUTSIDE = ('X', 'X', 'Y', 'Y', 'O', 'O')  # per node of nucleus (a), App. B.1
STATE5_OUTSIDE = ('X', 'Y', 'Y', 'Y', 'O', 'O')  # App. B.2
STATE6_OUTSIDE = ('X', 'X', 'X', 'Y', 'O', 'O')  # App. B.2


class OutsideDomain(Exception):
    """Theorem G refusal: incoming side presents no unmatched integers."""


# ---------------------------------------------------------------------------
# Pure selection machinery (the §8.6 model over the {-1,0,+1} domain)
# ---------------------------------------------------------------------------
def encode(letters):
    return tuple(E0[ch] for ch in letters)


def counts(tup):
    """Surplus count vector (n+, n-). Zeros carry no tension: never read."""
    return (sum(1 for x in tup if x == +1), sum(1 for x in tup if x == -1))


def residue(ca, cb):
    """res(A,B): A's nonzero ports with no opposite-sign partner in B."""
    return max(0, ca[0] - cb[1]) + max(0, ca[1] - cb[0])


def select(res, th):
    if res > th:
        return 'forced_decay'
    if res == 0:
        return 'attraction'
    return 'repulsion'


def encounter(a_tup, cb, th=TH):
    """Directional encounter: A incoming against neighbor B (counts cb).

    Domain guard (line 650; Theorem G): an all-zero incoming side is
    REFUSED -- never scored as repulsion, never scored as attraction.
    """
    ua = sum(1 for x in a_tup if x != 0)
    if ua == 0:
        raise OutsideDomain(
            "incoming side presents no unmatched integers -- outside taxonomy domain")
    ca = counts(a_tup)
    r = residue(ca, cb)
    return select(r, th), r, ca, ua


def matched(ca, cb):
    return min(ca[0], cb[1]) + min(ca[1], cb[0])


# ---------------------------------------------------------------------------
# Nucleus constructions (documented P3 / stretch choices)
# ---------------------------------------------------------------------------
def nucleus_a(consumed):
    """Aggregate (a): 3 x State-4 node minus one consumed port per node."""
    per_node = list(encode(STATE4_OUTSIDE))
    per_node.remove(E0[consumed])          # the documented value choice
    c = counts(tuple(per_node))
    zeros = len(per_node) - c[0] - c[1]
    total = (3 * c[0], 3 * c[1], 3 * zeros)
    assert sum(total) == 15, "B must be 15"
    return total[0], total[1]              # (n+, n-) counts


def nucleus_b(consumed5, consumed6):
    """Aggregate (b): State-5 + State-6 minus one consumed port each."""
    s5 = list(encode(STATE5_OUTSIDE)); s5.remove(E0[consumed5])
    s6 = list(encode(STATE6_OUTSIDE)); s6.remove(E0[consumed6])
    c5, c6 = counts(tuple(s5)), counts(tuple(s6))
    total_plus = c5[0] + c6[0]
    total_minus = c5[1] + c6[1]
    total_zero = (len(s5) + len(s6)) - total_plus - total_minus
    assert total_plus + total_minus + total_zero == 10, "B must be 10"
    return total_plus, total_minus


# ---------------------------------------------------------------------------
# Witness tables from the workers' runs (what the script checks against)
# ---------------------------------------------------------------------------
# Nucleus (a), primary construction: (state -> (res, m, B_new, verdict)).
# B_new = 6*4 - (3 + 2m) = 21 - 2m; m = u_A when res = 0 (full cover).
A_WITNESS = {
    1: dict(res=0, m=3, B_new=15, verdict='attraction'),
    2: dict(res=0, m=3, B_new=15, verdict='attraction'),
    3: dict(res=0, m=3, B_new=15, verdict='attraction'),
    4: dict(res=0, m=4, B_new=13, verdict='attraction'),
    5: dict(res=0, m=4, B_new=13, verdict='attraction'),
    6: dict(res=0, m=4, B_new=13, verdict='attraction'),
    7: dict(res=0, m=5, B_new=11, verdict='attraction'),
    8: dict(res=0, m=5, B_new=11, verdict='attraction'),
    9: dict(res=0, m=6, B_new=9,  verdict='attraction'),
}

# Aggregate-(b) stretch cases the workers ran.
# (state, consumed5, consumed6, expected_res, expected_m, expected_B_new, expected_verdict)
B_CASES = [
    (1, 'Y', 'X', 0, 3, 10, 'attraction'),   # documented complementary pair
    (2, 'O', 'O', 0, 3, 10, 'attraction'),
    (2, 'X', 'X', 0, 3, 10, 'attraction'),
    (3, 'Y', 'X', 0, 3, 10, 'attraction'),   # documented complementary pair
    (4, 'O', 'O', 0, 4, 8,  'attraction'),
    (4, 'Y', 'X', 0, 4, 8,  'attraction'),   # B.2-complementary reading
    # State 5 x (b): NOT RUN by the workers -- not invented here.
    (6, 'Y', 'X', 0, 4, 8,  'attraction'),   # documented complementary pair
    (7, 'O', 'O', 0, 5, 6,  'attraction'),
    (7, 'X', 'Y', 0, 5, 6,  'attraction'),   # complementary pair (count-identical)
    (8, 'Y', 'X', 0, 5, 6,  'attraction'),   # documented complementary pair
    (8, 'O', 'O', 0, 5, 6,  'attraction'),
    (9, 'O', 'O', 0, 6, 4,  'attraction'),
]
# Assumption-sensitive (b) cases: non-documented consumption choices.
# Marginal: res = TH = 1 (below the fuse -> repulsion).
B_SENSITIVE = [
    (6, 'Y', 'Y', 1, 'repulsion'),   # S5 consumes Y AND S6 consumes Y
    (9, 'X', 'X', 1, 'repulsion'),   # consume X per node
    (9, 'Y', 'Y', 1, 'repulsion'),   # consume Y per node
]


def check_ledger_a(m, B_new_expected):
    """§9.6 ledger for nucleus (a): N 3->4; dual computation of B_new."""
    N_new, sum_k_new = 4, 3 + 2 * m
    b_formula = 6 * N_new - sum_k_new
    b_decomp = (15 - m) + (6 - m)      # (B - m) consumed + (6 - m) surviving
    assert b_formula == B_new_expected, (b_formula, B_new_expected)
    assert b_decomp == B_new_expected, (b_decomp, B_new_expected)
    assert N_new == 4 and sum_k_new >= 3 + 2
    return b_formula


def check_ledger_b(m, B_new_expected):
    """§9.6 ledger for nucleus (b): N 2->3; dual computation of B_new."""
    N_new, sum_k_new = 3, 2 + 2 * m
    b_formula = 6 * N_new - sum_k_new
    b_decomp = (10 - m) + (6 - m)
    assert b_formula == B_new_expected, (b_formula, B_new_expected)
    assert b_decomp == B_new_expected, (b_decomp, B_new_expected)
    return b_formula


def main():
    failures = []
    n_checks = 0

    def ok(msg):
        print("  PASS  " + msg)

    def fail(msg):
        failures.append(msg)
        print("  FAIL  " + msg)

    print("F.46 -- Case A ladder machine check (STAGED, not wired into the paper)")
    print("Premises: E0 = {X:+1, Y:-1, O:0} (Level B); boundary tuple := Outside")
    print("Content under E0 (Level B inference); nucleus constructions as")
    print("documented; TH = 1 illustrative (exact TH is Paper 14's debt).")
    print()

    # ---- 1. Nine states x three (a) constructions: tuple -> counts -> res
    #         -> selection -> tension -> ledger ---------------------------
    print("[1] Nucleus (a): 9 states x 3 consumption constructions")
    for s in range(1, 10):
        a_tup = encode(OUTSIDE[s])
        w = A_WITNESS[s]
        for consumed in ('O', 'X', 'Y'):
            cb = nucleus_a(consumed)
            n_checks += 1
            try:
                verdict, r, ca, ua = encounter(a_tup, cb)
                m = matched(ca, cb)
                ub = cb[0] + cb[1]
                t_before = ua + ub
                t_after = t_before - 2 * m
                # witness agreement (primary construction carries the table)
                assert r == 0, "res=%d, expected 0" % r
                assert verdict == 'attraction', verdict
                # res = 0 (full cover) analytically implies m = u_A
                assert m == ua, "m=%d != u_A=%d under full cover" % (m, ua)
                assert t_after < t_before, "tension did not strictly decrease"
                # ledger, dual computation
                b_new = check_ledger_a(m, w['B_new'])
                assert m == w['m'] and b_new == w['B_new']
                ok("state %d x (a)/consume-%s: res=0 m=%d T %d->%d B_new=%d attraction"
                   % (s, consumed, m, t_before, t_after, b_new))
            except AssertionError as e:
                fail("state %d x (a)/consume-%s: %s" % (s, consumed, e))
            except OutsideDomain as e:
                fail("state %d x (a)/consume-%s: wrongly refused: %s" % (s, consumed, e))

    # ---- 2. Permutation invariance (zero-leak order test) ------------------
    print("[2] Order invariance: shuffling tuple order changes nothing")
    rng = random.Random(20260925)
    for s in range(1, 10):
        a_tup = encode(OUTSIDE[s])
        cb = nucleus_a('O')
        base = encounter(a_tup, cb)
        n_checks += 1
        try:
            for _ in range(5):
                sh = list(a_tup); rng.shuffle(sh); sh = tuple(sh)
                assert counts(sh) == counts(a_tup), "counts leaked order"
                assert encounter(sh, cb)[:2] == base[:2], "verdict leaked order"
            ok("state %d: 5 shuffles, counts/residue/verdict identical" % s)
        except AssertionError as e:
            fail("state %d order invariance: %s" % (s, e))

    # ---- 3. Positron mirror ------------------------------------------------
    print("[3] Positron mirror (State-1 charge mirror)")
    n_checks += 1
    try:
        p_tup = encode(POSITRON_OUTSIDE)
        verdict, r, ca, ua = encounter(p_tup, nucleus_a('O'))
        m = matched(ca, nucleus_a('O'))
        assert (r, verdict, m) == (0, 'attraction', 3)
        assert check_ledger_a(m, 15) == 15
        ok("positron: res=0 m=3 T 15->9 B_new=15 attraction (mirror of electron)")
    except AssertionError as e:
        fail("positron mirror: %s" % e)

    # ---- 4. Theorem G: all-zero incoming is REFUSED ------------------------
    print("[4] Domain guard (Theorem G): all-zero incoming is refused")
    n_checks += 1
    try:
        encounter((0, 0, 0, 0, 0, 0), nucleus_a('O'))
        fail("all-zero incoming was scored instead of refused")
    except OutsideDomain as e:
        ok("refused, not scored: %s" % e)

    # ---- 5. Aggregate-(b) stretch ------------------------------------------
    print("[5] Aggregate-(b) stretch: documented constructions")
    for (s, c5, c6, er, em, eb, ev) in B_CASES:
        a_tup = encode(OUTSIDE[s])
        cb = nucleus_b(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = encounter(a_tup, cb)
            m = matched(ca, cb)
            ub = cb[0] + cb[1]
            assert r == er, "res=%d expected %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            assert m == em, "m=%d expected %d" % (m, em)
            assert (ua + ub) - 2 * m < ua + ub, "tension did not decrease"
            b_new = check_ledger_b(m, eb)
            ok("state %d x (b)/(%s,%s): res=%d m=%d B_new=%d %s"
               % (s, c5, c6, r, m, b_new, verdict))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s): %s" % (s, c5, c6, e))

    print("[6] Aggregate-(b): assumption-sensitive marginal cases (res = TH = 1)")
    for (s, c5, c6, er, ev) in B_SENSITIVE:
        a_tup = encode(OUTSIDE[s])
        cb = nucleus_b(c5, c6)
        n_checks += 1
        try:
            verdict, r, ca, ua = encounter(a_tup, cb)
            assert r == er == TH, "res=%d, expected marginal %d" % (r, er)
            assert verdict == ev, "verdict=%s expected %s" % (verdict, ev)
            ok("state %d x (b)/(%s,%s): res=1=TH -> repulsion (marginal, disclosed)"
               % (s, c5, c6))
        except AssertionError as e:
            fail("state %d x (b)/(%s,%s) sensitive: %s" % (s, c5, c6, e))
    print("  NOTE  state 5 x (b): not run by the workers -- not invented here")

    # ---- 7. Planted mutants: each must be REJECTED with a printed witness --
    print("[7] Planted mutants (each must be rejected with a printed witness)")
    mutants_rejected = 0

    # M1: wrong boundary tuple (one letter flipped vs Table 5.1).
    n_checks += 1
    try:
        genuine = encode(OUTSIDE[1])
        mutant_tup = encode(('Y', 'Y', 'X', 'O', 'O', 'O'))  # flipped letter
        assert counts(mutant_tup) != counts(genuine), "mutant not actually wrong"
        # the verifier derives the tuple from the documented table; a
        # supplied tuple that disagrees is rejected, not silently used:
        if counts(mutant_tup) == counts(genuine):
            raise AssertionError("mutant tuple accepted as genuine")
        print("  MUTANT M1 (wrong boundary tuple): REJECTED -- witness: supplied "
              "counts %s != Table-5.1-derived counts %s"
              % (counts(mutant_tup), counts(genuine)))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M1 not rejected: %s" % e)

    # M2: swapped outcome label (res=0 relabeled 'repulsion').
    n_checks += 1
    try:
        verdict, r, ca, ua = encounter(encode(OUTSIDE[4]), nucleus_a('O'))
        mutant_label = 'repulsion'
        assert r == 0 and verdict == 'attraction'
        if mutant_label == verdict:
            raise AssertionError("swapped label accepted")
        print("  MUTANT M2 (swapped outcome label): REJECTED -- witness: res=%d "
              "selects '%s', mutant label '%s' disagrees"
              % (r, verdict, mutant_label))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M2 not rejected: %s" % e)

    # M3: off-by-one junction count (arity 2m+1 instead of 2m).
    n_checks += 1
    try:
        m = 4  # state 4..6 witness
        b_true = 6 * 4 - (3 + 2 * m)          # 13
        b_mut = 6 * 4 - (3 + 2 * m + 1)       # 12, off by one
        b_decomp = (15 - m) + (6 - m)         # 13, dual computation
        assert b_true == b_decomp == 13
        if b_mut == b_decomp:
            raise AssertionError("off-by-one ledger accepted")
        print("  MUTANT M3 (off-by-one junction count): REJECTED -- witness: "
              "B_new=%d with arity 2m+1 vs dual computation B_new=%d"
              % (b_mut, b_decomp))
        mutants_rejected += 1
    except AssertionError as e:
        fail("M3 not rejected: %s" % e)

    # M4: guardless all-zero incoming (must be refused, not attracted).
    n_checks += 1
    try:
        def mutant_guardless(a_tup, cb, th=TH):
            # spec violation: skips the Theorem G domain guard
            ca = counts(a_tup)
            return select(residue(ca, cb), th), residue(ca, cb)
        zeros = (0, 0, 0, 0, 0, 0)
        mutant_out = mutant_guardless(zeros, nucleus_a('O'))
        try:
            encounter(zeros, nucleus_a('O'))
            genuine_out = 'scored'
        except OutsideDomain:
            genuine_out = 'refused'
        assert mutant_out[0] == 'attraction' and genuine_out == 'refused'
        print("  MUTANT M4 (guardless all-zero incoming): REJECTED -- witness: "
              "mutant returns '%s' for the all-zero tuple; the guarded rule "
              "refuses it (Theorem G)" % mutant_out[0])
        mutants_rejected += 1
    except AssertionError as e:
        fail("M4 not rejected: %s" % e)

    print()
    print("checks run: %d | mutants rejected: 4/%d" % (n_checks, mutants_rejected))
    if failures or mutants_rejected != 4:
        print("F.46 RESULT: FAIL")
        for f in failures:
            print("  - " + f)
        sys.exit(1)
    print("F.46 RESULT: ALL CHECKS PASSED (exit 0)")
    print("Badge: arithmetic Level A given the documented premises; the nine")
    print("encounter verdicts remain Level B illustration. No Level-A")
    print("encounter badges issued.")


if __name__ == '__main__':
    main()
