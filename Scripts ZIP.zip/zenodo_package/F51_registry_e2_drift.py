#!/usr/bin/env python3
"""Paper 11 - F.51: registry<->E.2 drift sweep.

The claim registry source (F.38's REGISTRY) and the canonical E.2 claim
table in the paper are two renderings of the same 55 claim texts. The
V4 remediation corrected three registry texts to match E.2 byte-exactly
and inspected the remaining differences as deliberate condensations
(registry-full vs E.2-condensed); no gate re-checked the correspondence
afterwards. This script is that gate: it parses the E.2 table from the
paper, compares every registry text against its E.2 cell in both
directions, and fails loudly on any drift.

Method. The E.2 table is located by its header row and parsed with a
maxsplit parser: Text is the last of 8 columns, so literal "|"
characters inside Text cells (e.g. "|P(G;E)|") are preserved; rows
with the wrong column count or duplicate IDs are rejected loudly.
No pipe-guard on the early columns is claimed: Text legitimately
contains pipes, so no syntactic test on the parsed cells can
distinguish an intruding pipe from a Text pipe -- the safety is
downstream, in the per-ID text comparison (an asymmetric pipe
corruption fails loudly there). Checks: (1) the ID
sets match in both directions (57/57); (2) each registry text is
byte-exact against its E.2 cell, or the E.2 cell equals the pinned
deliberate rendering in DELIBERATE_RENDERINGS; anything else is drift
and raises DriftRejected with a witness naming the ID. The script
asserts the inspected state: 44 byte-exact, 13 deliberate renderings.

The 13 allowlist entries pin the renderings a human inspected as
deliberate (typographic condensation, dropped articles, condensed
content specs). Pinning is a regression gate, not a proof of
deliberateness -- the deliberateness was established by inspection; the
machine enforces that neither side moves without the pin being
consciously updated.

A planted control injects three synthetic drifts (a corrupted E.2 cell,
a dropped registry ID, a corrupted deliberate rendering) and requires
each to be rejected with a witness naming the ID, proving the sweep can
fail.

The lineage gates (2026-10-04). The §0.5.v rule requires every badge to
declare a lineage -- script, inherited, or prose -- and name a basis that
resolves. Two further machine checks close the correspondence: (i) every
prose-lineage registry row's section must resolve to a real paper heading
(a phantom "§9.99" is rejected); (ii) the E.2 Script cell's marker must
agree with the registry row's lineage -- kind (script/inherited/prose)
plus the source/section token sets (F.39 against a prose row, a dropped
inherited source token, and a kind flip are each rejected); (iii) every
F-number named by a script-lineage marker must have an embedded listing
in the paper (the listed set is derived from the paper's own listing
headings, never hardcoded -- a row naming the unlisted F.54 is rejected).
Five planted lineage controls prove these gates can fail; all 55 live rows
pass all three. Presence + type + resolution only: whether the named check,
source, or section actually establishes the claim stays human-audit territory.

No registry claim is badged on this machinery: it is process
machinery guarding the registry<->prose correspondence the paper
already claims.
"""

INPUT_PROVENANCE = {
    "HERE": {"class": "control",
             "note": "runtime path to this script's directory"},
    "PAPER": {"class": "control",
              "note": "runtime path to the paper file under test"},
    "EXPECTED_TOTAL": {"class": "control",
                       "note": "registry claim count (57)"},
    "EXPECTED_EXACT": {"class": "control",
                       "note": "inspected byte-exact registry<->E.2 count (43)"},
    "EXPECTED_DELIBERATE": {"class": "control",
                            "note": "inspected deliberate-rendering count (13)"},
    "DELIBERATE_RENDERINGS": {"class": "control",
                              "note": "pinned E.2 renderings for the 13 "
                                      "inspected deliberate condensations "
                                      "(ID -> expected E.2 text + note)"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "registry<->E.2 correspondence machinery; backs no claim.",
}

from pathlib import Path
import re
from copy import deepcopy

import F38_claim_registry as _f38

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "paper_11.md"

EXPECTED_TOTAL = 57
EXPECTED_EXACT = 44
EXPECTED_DELIBERATE = 13

DELIBERATE_RENDERINGS = {
    "ENGAGEMENT_ALTERATION_SEPARATION": {
        "e2": "engagement (proximity encounter geometry at a tick) does not entail alteration (junction completion or occlusion); scoring a proximity encounter changes no port status and no nine-position content; incorporation is the distinct junction-completion step, closing ports per the bonding lemma while every node's 27-state identity is preserved",
        "note": "condensed: ';'-joined clauses; incorporation clause shortened",
    },
    "ENCOUNTER_TENSION_ANALYSIS": {
        "e2": "encounter tension analysis: T(A,B) = \u03a3x\u00b2 over both presented tuples; complementary cover plus the incoming-side guard strictly reduces T; strict reduction without cover is repulsion; A-all-zero encounters refused; B's unmatched labels stay presented (paired off, not consumed); the residue fuse watches the unresolvable load",
        "note": "typographic: \u03a3x\u00b2 for 'sum x^2'; clause rephrased",
    },
    "CASE_A_LADDER": {
        "e2": 'nucleus to atom ladder as illustration; F.46 content: (i) 27 first-encounter runs + (b) runs incl. State 5 + positron mirror + refusal guard + permutation checks, (ii) sequential chain + 9! sweep (1,088,640 chain runs), (iii) 7 planted mutants incl. the net-sum specimen; counting/chain arithmetic Level A given premises, encounter verdicts and physical reading Level B',
        "note": "condensed F.46 content spec; 'encounter verdicts' wording",
    },
    "CONSUMPTION_CONSTRUCTION_ROBUSTNESS": {
        "e2": 'Level A given premises: categorical counting of all 27 first encounters (9 states x 3 nucleus-(a) constructions) -- res=0, strictly decreasing presented tension, consumption/construction readings agree on counts, permutation/identity zero-leak, positron-mirror counts identical, all-zero refused; attraction verdicts stay Level B; 7 planted mutants rejected incl. the net-sum specimen',
        "note": "'Level A given premises' for 'Level A given the documented premises'; numerals for number-words",
    },
    "CROSS_NUCLEUS_ROBUSTNESS": {
        "e2": 'Level A given premises: aggregate-(b) categorical counting -- normalized (4,4,2), B=10; all 9 states incl. State 5 run with res=0; 81-case enumeration: 74 cases res=0, 7 marginal res=TH=1, 0 cases res>1; verdicts stay Level B',
        "note": "same condensation pattern; 'verdicts stay Level B'",
    },
    "CASE_C_STRUCTURAL": {
        "e2": 'the environment-relative conditional structure of consolidation paths: path counts bounded by (B, boundary values, environment); monotone non-decreasing only under boundary-extension (valued boundary-port-set inclusion, non-strict); node count does not control boundary-port count; the monotone nodes\u2192paths claim withdrawn',
        "note": "clause condensation; withdrawal clause retained",
    },
    "AGGREGATE_A_DECOMPOSITION": {
        "e2": 'per-aspect decomposition of three-node State-4 composite: exact port partition (B = 6N \u2212 \u03a3k_j, dual-computed), symbolic per-aspect s\u00b2 contributions consistent with Lemma 2 (Aspect Aggregation) (resolved \u2192 0 exactly; open tilt ports \u2192 positive formal symbols; junctions contribute no s\u00b2), symbolic-sum identity via enumeration plus an independent arithmetic audit',
        "note": "typographic: \u2212 \u03a3k_j for '- sum(k_j)'; \u00b2 for '^2'; \u2192 for '->'",
    },
    "AGGREGATE_B_DECOMPOSITION": {
        "e2": "per-aspect decomposition of two-node State-5/6 pair, branch-ready over both documented consumption conventions (branch A consume-O, \u00a79: 8 positive symbols; branch B complementary pair, Appendix B.2: 6 positive symbols), each branch verified independently; Decision Q: branch B the paper's stated convention (recorded 2026-09-26, confirmed by the author's direct decision 2026-09-27): exact port partition, symbolic contributions consistent with Lemma 2 (Aspect Aggregation), symbolic-sum identity via enumeration plus an independent arithmetic audit",
        "note": "'\u00a79' for 'section 9'; Decision Q clause retained",
    },
    "AGGREGATE_C_DECOMPOSITION": {
        "e2": "per-aspect decomposition of linear three-node chain: exact port partition, symbolic contributions consistent with Lemma 2 (Aspect Aggregation), symbolic-sum identity via enumeration plus an independent arithmetic audit; the identity holds for all 10\u00b3 state-row assignments on F.41's documented indices (Electron/Positron rows verified separately; outcomes identical); the sweep's universality is over formal row assignments for the bookkeeping identity \u2014 physical junction-admissibility per pairing is a Paper-2 question not badged here",
        "note": "condensed sweep-universality clause; Paper-2 caveat retained",
    },
    "SIMPLE_STATE_ENUMERATION": {
        "e2": 'the simple states are exactly the 27 tilt-triple configurations of the Paper 3 \u00a72 classification (full 27-configuration inventory, Appendix A), taken individually',
        "note": "parenthetical reorder: '(full 27-configuration inventory, Appendix A)'",
    },
    "MONOTONICITY_REFUTATION": {
        'e2': 'unconditional "B\u2081<B\u2082 \u21d2 |P\u2081|<|P\u2082|" is false: an all-O B=10 boundary yields |P|=0 in any environment (O pairs with nothing); an all-X B=10 boundary in a Y-free environment yields |P|=0 while an all-X B=6 boundary in a Y-rich environment yields |P|=6',
        "note": "typographic: subscripted B\u2081<B\u2082 \u21d2 |P\u2081|<|P\u2082|; curly quotes",
    },
    "BOUNDARY_EXTENSION_INCLUSION": {
        "e2": 'boundary-extension (valued boundary-port-set inclusion, fixed environment) implies consolidation-path-set inclusion and non-strict path-count inequality',
        "note": "article drop: 'the non-strict' -> 'non-strict'",
    },
    "NODES_PORTS_NONMONOTONICITY": {
        "e2": 'node count is not monotone in boundary-port count: explicit two-node eight-port-consumed aggregate has N=2, B=4 against one-node N=1, B=6',
        "note": "article drop: 'an explicit' -> 'explicit'",
    },
}


class DriftRejected(Exception):
    """Raised when registry<->E.2 drift is detected."""

    def __init__(self, witness):
        super().__init__(witness)
        self.witness = witness


def parse_e2_table(md_text):
    """Parse the E.2 claim table from the paper markdown.

    Return {id: (text, script_cell)} -- the Text column and the Script
    (checker-marker) column.

    The table is located by its header row. Each row is split with
    maxsplit=7 so the 8th (Text) column keeps its literal "|"
    characters (live rows use them as math notation); rows with the
    wrong column count or duplicate IDs are rejected loudly. No
    pipe-guard on the early columns is claimed: Text legitimately
    contains pipes, so no syntactic test on the parsed cells can
    distinguish an intruding pipe from a Text pipe -- the safety is
    downstream, in the per-ID text comparison (an asymmetric pipe
    corruption fails loudly there).
    """
    rows = {}
    in_table = False
    for lineno, line in enumerate(md_text.splitlines(), 1):
        if line.startswith("| ID | Level |"):
            in_table = True
            continue
        if not in_table:
            continue
        if line.startswith("|---"):
            continue
        if not line.startswith("|"):
            break
        body = line.strip()
        if not (body.startswith("|") and body.endswith("|")):
            raise DriftRejected(
                "E.2 line %d: not a well-formed table row" % lineno)
        cells = [c.strip() for c in body[1:-1].split("|", 7)]
        if len(cells) != 8:
            raise DriftRejected(
                "E.2 line %d: expected 8 columns, got %d"
                % (lineno, len(cells)))
        rid = cells[0]
        if rid in rows:
            raise DriftRejected("E.2 duplicate ID: %r" % rid)
        rows[rid] = (cells[7], cells[6])
    if not rows:
        raise DriftRejected("E.2 table not found in the paper")
    return rows


def drift_check(registry_texts, e2_texts):
    """Compare registry texts against E.2 cells.

    Returns (n_exact, n_deliberate, failures): byte-exact matches,
    deliberate-rendering matches, and a list of witness strings for
    genuine drift (ID missing either direction, or text matching
    neither the registry nor the pinned rendering).
    """
    failures = []
    for rid in registry_texts:
        if rid not in e2_texts:
            failures.append(
                "drift: registry ID %r missing from the E.2 table" % rid)
    for rid in e2_texts:
        if rid not in registry_texts:
            failures.append(
                "drift: E.2 ID %r missing from the registry" % rid)
    n_exact = 0
    n_deliberate = 0
    for rid in sorted(set(registry_texts) & set(e2_texts)):
        rt, et = registry_texts[rid], e2_texts[rid]
        if rt == et:
            n_exact += 1
        elif (rid in DELIBERATE_RENDERINGS
                and DELIBERATE_RENDERINGS[rid]["e2"] == et):
            n_deliberate += 1
        else:
            failures.append(
                "drift: text mismatch on %r (registry %d chars vs E.2 "
                "%d chars; not byte-exact and not the pinned deliberate "
                "rendering)" % (rid, len(rt), len(et)))
    return n_exact, n_deliberate, failures


class LineageMarkerRejected(Exception):
    """Raised when a lineage marker is undeclared or unresolvable."""

    def __init__(self, witness):
        super().__init__(witness)
        self.witness = witness


def paper_headings(md_text):
    """Leading §-tokens of the paper's real headings (fence-aware).

    Embedded script listings contain heading-like strings inside fenced
    code blocks; those are not paper headings and are skipped.
    """
    toks = set()
    in_fence = False
    for line in md_text.splitlines():
        s = line.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m = re.match(r"#{1,6}\s+(§[\d.]+)", line)
        if m:
            toks.add(m.group(1))
    return toks


def prose_section_check(registry, headings):
    """Every prose-lineage row's section must be a real paper heading.

    Presence + resolution only: the machine never checks the cited
    section's prose actually proves the claim (human-audit territory,
    the same ceiling as F.52's address check). An empty section is
    F.38 R3's territory and is not double-reported here.
    """
    failures = []
    for row in registry:
        if row.get("lineage") != "prose":
            continue
        sec = (row.get("section") or "").strip()
        if sec and sec not in headings:
            failures.append(
                "prose section unresolved on %r: %r names no paper heading"
                % (row["id"], sec))
    return failures


def parse_e2_marker(cell):
    """Classify an E.2 Script cell into (kind, tokens).

    kind is "script" (F-numbers, en/hyphen ranges expanded), "inherited"
    (semicolon-separated source chunks), or "prose" (the section token).
    A cell declaring no marker is rejected loudly -- an undeclared
    lineage is conjecture under the §0.5.v rule.
    """
    c = cell.strip()
    if c.startswith("prose "):
        sec = c[len("prose "):].strip()
        if not sec:
            raise LineageMarkerRejected(
                "E.2 cell %r: prose marker with no section" % cell)
        return ("prose", frozenset([sec]))
    if c.startswith("inh.:") or c.startswith("inh."):
        src = c.split(":", 1)[1] if ":" in c else c[len("inh."):]
        chunks = frozenset(x.strip() for x in src.split(";") if x.strip())
        if not chunks:
            raise LineageMarkerRejected(
                "E.2 cell %r: inherited marker with no source" % cell)
        return ("inherited", chunks)
    nums = set()
    for m in re.finditer(r"F\.(\d+)\s*[-\u2013\u2014]\s*F?\.?(\d+)", c):
        lo, hi = sorted((int(m.group(1)), int(m.group(2))))
        nums.update(range(lo, hi + 1))
    for m in re.finditer(r"F\.(\d+)", c):
        nums.add(int(m.group(1)))
    if not nums:
        raise LineageMarkerRejected(
            "E.2 cell %r declares no lineage marker" % cell)
    return ("script", frozenset(nums))


def registry_marker(row):
    """The registry side of the marker agreement: (kind, tokens)."""
    lin = row.get("lineage")
    if lin == "script":
        scr = row.get("script") or []
        stems = scr if isinstance(scr, list) else [scr]
        nums = frozenset(int(m.group(1)) for s in stems
                         for m in [re.match(r"F(\d+)", s)] if m)
        return ("script", nums)
    if lin == "inherited":
        chunks = frozenset(
            x.strip() for x in (row.get("inherited_from") or "").split(";")
            if x.strip())
        return ("inherited", chunks)
    if lin == "prose":
        return ("prose", frozenset([(row.get("section") or "").strip()]))
    raise LineageMarkerRejected(
        "registry row %r has unknown lineage %r" % (row.get("id"), lin))


def lineage_marker_check(registry, e2_markers, e2_ids):
    """E.2 Script-cell marker <-> registry lineage agreement.

    Kind (script/inherited/prose) plus the source/section token sets
    must agree in both directions. Presence + type + resolution only:
    whether the named check, source, or section actually establishes
    the claim stays human-audit territory.
    """
    failures = []
    reg_ids = {r["id"] for r in registry}
    for row in registry:
        rid = row["id"]
        if rid not in e2_ids:
            failures.append(
                "marker: registry ID %r missing from the E.2 table" % rid)
            continue
        if rid not in e2_markers:
            # Unparseable cell: already reported as a parse failure.
            continue
        rk, rt = registry_marker(row)
        ek, et = e2_markers[rid]
        if rk != ek:
            failures.append(
                "marker: kind mismatch on %r (registry %s vs E.2 %s)"
                % (rid, rk, ek))
        elif rt != et:
            failures.append(
                "marker: token mismatch on %r (registry %s %s vs E.2 %s)"
                % (rid, rk, sorted(rt), sorted(et)))
    for rid in e2_ids:
        if rid not in reg_ids:
            failures.append(
                "marker: E.2 ID %r missing from the registry" % rid)
    return failures


def listed_scripts(md_text):
    """F-numbers with embedded listings in the paper (fence-aware).

    Scans the COMPUTATIONAL VERIFICATION section for the two listing
    heading shapes ("### F32_..." and "**F.46 — ..."). The set is derived
    from the paper itself, never hardcoded.
    """
    nums = set()
    in_section = False
    in_fence = False
    for line in md_text.splitlines():
        s = line.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if line.startswith("## COMPUTATIONAL VERIFICATION"):
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if in_section:
            m = re.match(r"### F(\d+)_", line)
            if m:
                nums.add(int(m.group(1)))
                continue
            m = re.match(r"\*\*F\.(\d+)\s+—", line)
            if m:
                nums.add(int(m.group(1)))
    return nums


def named_scripts(registry, e2_markers):
    """All F-numbers named by script-lineage markers on either side."""
    named = set()
    for row in registry:
        k, t = registry_marker(row)
        if k == "script":
            named |= set(t)
    for _rid, (k, t) in e2_markers.items():
        if k == "script":
            named |= set(t)
    return named


def planted_lineage_controls(registry, e2_cells, headings, md_text):
    """Prove the lineage gates can fail: five synthetic defects, each
    rejected with a witness naming the ID."""
    # (i) prose section naming no paper heading.
    bad_reg = deepcopy(registry)
    victim = next(r for r in bad_reg if r["id"] == "SIMPLE_STATE_INSULATION")
    victim["section"] = "§9.99"
    fails = prose_section_check(bad_reg, headings)
    assert any("SIMPLE_STATE_INSULATION" in f and "§9.99" in f for f in fails), \
        "lineage control (i) FAILED: phantom prose section not detected: %r" \
        % (fails,)
    # (ii-a) E.2 script marker against a prose-lineage row (kind mismatch).
    bad = dict(e2_cells)
    bad["ROLE_PERMANENCE_PROHIBITION"] = "F.39"
    m = {k: parse_e2_marker(v) for k, v in bad.items()}
    fails = lineage_marker_check(registry, m, set(bad))
    assert any("ROLE_PERMANENCE_PROHIBITION" in f and "kind mismatch" in f
               for f in fails), \
        "lineage control (ii-a) FAILED: %r" % (fails,)
    # (ii-b) dropped inherited source token.
    bad2 = dict(e2_cells)
    bad2["PHOTON_BASELINE"] = "inh.: Paper 2 §5"
    m2 = {k: parse_e2_marker(v) for k, v in bad2.items()}
    fails = lineage_marker_check(registry, m2, set(bad2))
    assert any("PHOTON_BASELINE" in f and "token mismatch" in f for f in fails), \
        "lineage control (ii-b) FAILED: %r" % (fails,)
    # (ii-c) kind flip: inherited row rendered as prose.
    bad3 = dict(e2_cells)
    bad3["PORT_COUNT_INVARIANCE"] = "prose §4.3"
    m3 = {k: parse_e2_marker(v) for k, v in bad3.items()}
    fails = lineage_marker_check(registry, m3, set(bad3))
    assert any("PORT_COUNT_INVARIANCE" in f and "kind mismatch" in f
               for f in fails), \
        "lineage control (ii-c) FAILED: %r" % (fails,)
    # (ii-d) script named by both sides but with no embedded listing.
    # R3 passes (the file exists) and marker agreement passes (both name
    # F.54) -- only the listed-set gate catches it.
    bad4_reg = deepcopy(registry)
    v4 = next(r for r in bad4_reg if r["id"] == "SIMPLE_STATE_ENUMERATION")
    v4["script"] = "F54_proof_registry_crosscheck"
    bad4 = dict(e2_cells)
    bad4["SIMPLE_STATE_ENUMERATION"] = "F.54"
    m4 = {k: parse_e2_marker(v) for k, v in bad4.items()}
    assert not lineage_marker_check(bad4_reg, m4, set(bad4)), \
        "lineage control (ii-d) setup broken: kind/token gates fired"
    unlisted4 = sorted(named_scripts(bad4_reg, m4) - listed_scripts(md_text))
    assert unlisted4 == [54], \
        "lineage control (ii-d) FAILED: unlisted script not detected: %r" \
        % (unlisted4,)
    print("WITNESS planted_lineage_controls: 5 synthetic lineage defects "
          "(phantom prose section, script-vs-prose kind mismatch, dropped "
          "inherited source token, inherited-vs-prose kind flip, script "
          "named but not listed); each rejected with a witness naming "
          "the ID.")
    return True


def planted_control(registry_texts, e2_texts):
    """Prove the sweep can fail: three synthetic drifts, each rejected
    with a witness naming the ID."""
    # Control 1: corrupt one byte-exact E.2 cell.
    bad_e2 = dict(e2_texts)
    victim = "RELATIONAL_ROLE_THEOREM"
    assert victim not in DELIBERATE_RENDERINGS, \
        "control setup: victim must be byte-exact"
    bad_e2[victim] = bad_e2[victim] + " [SYNTHETIC DRIFT]"
    _, _, failures = drift_check(registry_texts, bad_e2)
    assert len(failures) == 1 and victim in failures[0], \
        "control 1 FAILED: synthetic E.2 corruption not detected: %r" \
        % (failures,)
    # Control 2: drop one registry ID (direction: registry -> E.2).
    bad_reg = dict(registry_texts)
    del bad_reg[victim]
    _, _, failures2 = drift_check(bad_reg, e2_texts)
    assert any("missing from the registry" in f and victim in f
               for f in failures2), \
        "control 2 FAILED: synthetic missing registry ID not detected: %r" \
        % (failures2,)
    # Control 3: corrupt a deliberate rendering (the pin is exact-match).
    bad_e2b = dict(e2_texts)
    dv = "CASE_A_LADDER"
    bad_e2b[dv] = bad_e2b[dv].replace("encounter verdicts", "verdicts")
    assert bad_e2b[dv] != e2_texts[dv], "control 3 setup: no change made"
    _, _, failures3 = drift_check(registry_texts, bad_e2b)
    assert len(failures3) == 1 and dv in failures3[0], \
        "control 3 FAILED: corrupted deliberate rendering not detected: %r" \
        % (failures3,)
    print("WITNESS planted_control: 3 synthetic drifts injected "
          "(corrupted E.2 cell, dropped registry ID, corrupted deliberate "
          "rendering); each rejected with a witness naming the ID.")
    return True


def main():
    registry_texts = {c["id"]: c["text"] for c in _f38.REGISTRY}
    md = PAPER.read_text(encoding="utf-8")
    e2_rows = parse_e2_table(md)
    e2_texts = {rid: text for rid, (text, _cell) in e2_rows.items()}
    e2_cells = {rid: cell for rid, (_text, cell) in e2_rows.items()}
    assert len(registry_texts) == EXPECTED_TOTAL, \
        "registry holds %d claims, expected %d" \
        % (len(registry_texts), EXPECTED_TOTAL)
    n_exact, n_deliberate, failures = drift_check(registry_texts, e2_texts)
    assert not failures, \
        "F.51 DRIFT DETECTED: %s" % ("; ".join(failures),)
    assert n_exact == EXPECTED_EXACT, \
        "byte-exact count moved: %d (expected %d)" % (n_exact, EXPECTED_EXACT)
    assert n_deliberate == EXPECTED_DELIBERATE, \
        "deliberate-rendering count moved: %d (expected %d)" \
        % (n_deliberate, EXPECTED_DELIBERATE)
    assert planted_control(registry_texts, e2_texts)
    # Lineage gates (2026-10-04): (i) prose-lineage sections resolve to
    # real paper headings; (ii) E.2 Script-cell markers agree with the
    # registry lineage (kind + source/section token sets); (iii) every
    # F-number named by a script-lineage marker has an embedded listing.
    headings = paper_headings(md)
    sec_failures = prose_section_check(_f38.REGISTRY, headings)
    assert not sec_failures, \
        "F.51 PROSE-SECTION UNRESOLVED: %s" % ("; ".join(sec_failures),)
    e2_markers = {}
    marker_failures = []
    for rid, cell in e2_cells.items():
        try:
            e2_markers[rid] = parse_e2_marker(cell)
        except LineageMarkerRejected as e:
            marker_failures.append(
                "marker: E.2 cell for %r: %s" % (rid, e.witness))
    marker_failures.extend(
        lineage_marker_check(_f38.REGISTRY, e2_markers, set(e2_cells)))
    listed = listed_scripts(md)
    unlisted = sorted(named_scripts(_f38.REGISTRY, e2_markers) - listed)
    if unlisted:
        marker_failures.append(
            "marker: script-lineage names F-number(s) with no embedded "
            "listing: %s" % ", ".join("F.%d" % n for n in unlisted))
    assert not marker_failures, \
        "F.51 LINEAGE-MARKER DRIFT: %s" % ("; ".join(marker_failures),)
    assert planted_lineage_controls(_f38.REGISTRY, e2_cells, headings, md)
    n_prose = sum(1 for c in _f38.REGISTRY if c.get("lineage") == "prose")
    print("F.51 PASS: registry<->E.2 %d/%d IDs match both directions; "
          "%d byte-exact, %d pinned deliberate renderings; 3/3 planted "
          "drift controls rejected; %d/%d prose sections resolve to real "
          "paper headings; %d/%d E.2 markers agree with registry lineage; "
          "every named script has an embedded listing (%d listed); "
          "5/5 planted lineage controls rejected."
          % (len(registry_texts), len(e2_rows),
             n_exact, n_deliberate, n_prose, n_prose,
             len(registry_texts), len(e2_rows), len(listed)))


if __name__ == "__main__":
    main()
