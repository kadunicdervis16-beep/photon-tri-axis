#!/usr/bin/env python3
"""Paper 11 - F.42: Stage-N vocabulary firewall (Section 0.5.x, rule R16;
register-token sweep, rule R17).

This is the machine check for the v6 scale-token correction: the defect site was
prose, not the registry, so the verification must scan prose.

Verifies:
1. Prose: the Section 0.5.x POSITIVE DERIVATION vocabulary list, extracted
   from paper_11.md, contains zero physical-scale tokens. (The defect was
   "step length l0" sitting in the native list.)
2. Scripts: in all F*.py sources, a physical-scale token may appear
   only inside the firewall machinery itself (the denylist definition and
   its tests) - never in a derivation. No float() call and no float
   literal outside a print() display line (the Section 0.5.v.1 protocol,
   machine-checked). The number of script sources swept is computed at
   run time from the F*.py glob - the script never hardcodes the count,
   so the reported total cannot drift out of sync with the tree.
3. Registry: R16's dependency half holds over the F.38 registry - every
   scale-token claim is Level B/C with a Level-A transitive ancestor
   (reuses the exact rule function from F.38).
4. Occurrence principle (v7): EVERY physical-scale token in the paper's
   prose (outside fenced code blocks) is extracted with its section
   context and checked against a curated justification list. Any
   unlisted occurrence - or any listed justification that matches
   nothing (stale) - fails the build. The justification patterns are
   deliberately content-specific: the audit's job is to force every
   token occurrence to be individually looked at and justified, not to
   be a perfect semantic judge.
5. Gradient sweep (v8): the continuum-vocabulary token
   "gradient" is swept across the paper's prose (outside code fences)
   and all script sources. Prose occurrences must match the curated
   GRADIENT_JUSTIFICATIONS list (the §0.5.x terminology lock, the
   registry description, the changelog); script sources must be clean
   except F.42's own sweep machinery.
6. Boundary-object sweep (v9): the phantom list-verb and
   reified-boundary vocabulary are swept across the paper's prose (outside
   code fences) and all script sources. Prose occurrences must match the
   curated BOUNDARY_JUSTIFICATIONS list (the §4.3 non-substance rule, the
   registry description, the changelog); script sources must be clean
   except this script's own marked sweep machinery. v14 extends the sweep
   from banned nouns to object-positing phrase patterns (the R19
   machinery); a planted phrase test case joins the planted test cases.
7. Register-token sweep (paper v10): R register tokens (the
   deprecated alias for the reconstruction register) are swept across
   the paper's prose (outside code fences) and all script sources. Prose
   occurrences must match the curated REGISTER_JUSTIFICATIONS list (the
   §0.5.aa reconciliation note, the R17 description, the registry
   description, the changelog); script sources must be clean except this
   script's own marked sweep machinery.
8. Planted test cases: (a) a Level-A claim text containing l0 is rejected;
   (b) a Level-B scale-token claim with no Level-A ancestor is rejected;
   (c) a Level-A theorem block carrying l0 is flagged by the occurrence
   audit; (d) a Level-A prose sentence carrying m0 on the v4 Section 5.1
   pattern ("fixes the mass of each state at N.m0") is flagged;
   (e) a "gradient-biased" sentence smuggled into native prose is
   flagged by the gradient sweep; (f) a boundary-as-created-object
   sentence smuggled into native prose is flagged by the boundary sweep;
   (g) an R-token sentence smuggled into native prose is flagged by the
   register sweep, while the alias-declaration sentence passes.
9. Kinematics sweep (v12): differential-kinematics
   vocabulary is swept across the paper's prose (outside code fences)
   and all script sources. Prose occurrences must match the curated
   KINEMATICS_JUSTIFICATIONS list (the §0.5.x terminology lock, the
   registry description, the changelog); script sources must be clean
   except this script's own marked sweep machinery. Planted test cases:
   (h) a differential-kinematics sentence smuggled into native prose is
   flagged by the kinematics sweep, while the lock sentence passes.
10. Thermo sweep (v13): thermodynamic vocabulary is swept
    across the paper's prose (outside code fences) and all script sources.
    Prose occurrences must match the curated THERMO_JUSTIFICATIONS list (the
    §0.5.x terminology lock, the Paper-12 firewall and deferral sections,
    the registry description, the changelog); script sources must be clean
    except this script's own marked sweep machinery. Planted test cases:
    (i) a thermodynamic sentence smuggled into native prose is flagged by
    the thermo sweep, while the lock sentence passes.
11. Teleology sweep (v15): scalar, process, and
    teleological readings of the ordering key are swept across the paper's
    prose (outside code fences) and all script sources - v14(a) extends the
    family with purpose-ascribing infinitival shapes ("designed to",  # MACHINERY-OK
    "intended to", "in order to") in native prose. Prose occurrences  # MACHINERY-OK
    must match the curated TELEO_JUSTIFICATIONS list (the §12
    Canonical-Ordering Firewall, the changelog); script sources must be
    clean except this script's own marked sweep machinery. Planted
    test cases: (j) a teleological sentence smuggled into native prose is
    flagged by the teleology sweep, while the firewall sentence passes.
12. Arity sweep (v16): unqualified binary-junction
    assumptions are swept across the paper's prose (outside code fences)
    and all script sources. Prose occurrences of the pairwise formula
    6N − 2J (admitted only as the pairwise corollary)
    and of "between two ports" (admitted only in the
    changelog) must match the curated ARITY_JUSTIFICATIONS list (the
    §4.3 pairwise corollary, the registry descriptions, the changelog -
    pre-v16 occurrences are dated historical records); script sources
    must be clean except this script's own marked sweep machinery and
    descriptive mentions (pairwise corollary /
    planted / changelog). Planted test cases: (k) a "between two ports"
    sentence smuggled into native prose is flagged by the arity sweep,
    while the repaired §4.1 sentence ("among two or more ports") passes;
    (l) a universal "B = 6N − 2J" sentence (planted test case) smuggled into
    native prose is flagged, while the scoped pairwise-corollary sentence
    passes.
13. Magnitude bridge-word sweep: the Stage P-reserved bridge word is swept
    across the paper's prose (outside code fences) and all script sources.
    Prose occurrences must match the curated BRIDGE_MAGNITUDE_JUSTIFICATIONS
    list (the §8.5 bridge-reservation sentence, this description, the changelog); script
    sources must be clean except this script's own marked sweep machinery.
    A companion consistency check asserts every native use of the renamed
    term resolves to the single definition line binding it to e·S(d).
    Planted test cases: (m) a bridge-word sentence smuggled into native prose
    is flagged by the magnitude sweep, while the reservation sentence passes.
14. Label-terminology sweep: the misapplication of "axiom" to Paper-11
    dependency labels (L5-P11 is a derived theorem of section 3.1;
    L6/L7/L8/L9-P11 are definitions), and the stale v2 root phrase for
    Paper-11's role machinery, are swept across the paper's prose (outside
    code fences) and all script sources. Prose occurrences must match the
    curated LABEL_JUSTIFICATIONS list (the changelog remediation-history
    entry); script sources must be clean except this script's own marked
    sweep machinery. This sweep's badge covers terminology consistency
    only - it certifies that the paper calls each label what the
    architecture says it is, nothing about the physics.
    Planted test cases: (n) a sentence calling Paper-11 labels axioms is
    flagged by the label-terminology sweep, while the changelog history
    sentence passes; (o) a sentence using the stale v2 root phrase is
    flagged; (p) a fresh "L5-P11 axiom" sentence is flagged.
    15. Modal-collapse sweep (role-capability vs role-actuality): the covered
    collapse pattern families - P1 (play-verb role assignment:
    plays/takes/assumes, present and past), P1b (the gerund form), P1p (the
    passive-voice form: "the X role is played by"), P1part (the participial
    form: "(having) played the X role"), P2 (copula assignment: is/are/was/
    were, with comparative and curated-adverb interruptions), P3adj/P3par
    (adjectival and parenthetical forms, the parenthetical in plain and
    participial form), P3x (extended adjectival over the junction, node,
    port, configuration, state, aggregate, selector noun list), P4
    (copula-free verbs: stays/remains/becomes), and P5 (contrastive not-but)
    - are swept across the paper's prose (outside code fences) and all script
    sources, one physical line to a unit. The hyphen guards keep
    *-capable forms from matching, and the patterns are case-insensitive
    (sentence-initial forms are covered). Exempt by construction: the modal
    capability forms ("can"/"could" immediately before a P1/P1b match only),
    hyphen-guarded *-capable forms, negated assertions (except P5, whose
    "not" is part of the defect shape), and encounter-indexed forms (the
    index tokens are "encounter R", "in R", R with digits, R_1/R_2, and the
    subscript R forms; a bare "encounter" with no R, temporal clauses,
    deictic tokens, and bare "at tick" are not index tokens). The index
    exemption is verb-sensitive: it covers P1/P1b/P1p/P1part/P2/P3adj/
    P3par/P3x, never P4 or P5. Justification pins are span-scoped: a pin
    admits a trigger only if the pin's literal string covers the trigger's
    matched span, so a pin never launders a defect in another clause; every
    pin is probed with a genuine defect wearing that pin. Prose occurrences
    must match the curated MODAL_JUSTIFICATIONS list (the section 4.2 role
    definitions, the section 3.1 forbidden-list counter-examples, the
    section 3.1 relational-thesis gloss, the section 4.5 protocol's
    attaches-to marker, the section 3.1 capability-actuality corollary, the
    section 4.3 B=0 counterfactual, the Abstract's operational definition of
    the labels, and the section 3 standard-physics foil); script sources
    must be clean except
    this script's own marked sweep machinery and the machine-message class
    (assert/print messages, planted-test invocations, rule-description
    quotes). This sweep's badge covers the covered pattern families only -
    it does not certify the absence of every upgrade of a proved "can play"
    into actuality. Human-audit territory: encounter-indexed but modally
    unearned sentences; adjectival nouns outside the covered lists; quoted
    counter-examples beyond the admitted list; cross-sentence anaphora
    (coreference is out of scope by design); adverbs outside the curated
    adverb list; the modal guard's P1/P1b-only scope; and index-token
    line-sharing (the tightened index token still exempts line-wide - a bare
    assertion sharing its line with "encounter R" elsewhere is missed; pin
    laundering is span-scoped since the hardening pass, so that half is
    resolved). Planted test cases: (q)
    the old section 4.2 unindexed sentences are flagged; (r) an adjectival
    collapse is flagged; (s)-(u) temporal-clause, deictic-clause, and
    bare-at-tick collapses are flagged; (v) copula-free collapses are
    flagged; (w) a gerund collapse is flagged; (x) extended-adjectival
    collapses are flagged; (y) a contrastive collapse is flagged; the
    hardening battery - participial-parenthetical, past-tense copula,
    adverb-interrupted copula, and line-wide-scope-killer collapses, plus
    one granularity probe per justification pin - is flagged; the modal,
    R3-indexed, gerund-indexed, R-indexed (plain, passive-voice, and
    participial), hyphen-guarded, negated, and W-witness controls pass, and
    the "can" + copula-free diagnostic flags by design.
    16. Continuum-adverb sweep: the tokens "continuously" and "continuous"
    are swept across the paper's prose (outside code fences) and all script
    sources. Prose occurrences must match the curated CONTINUUM_JUSTIFICATIONS
    list (terminology locks, firewalls, register definitions, comparison
    contexts, this description, the changelog); script sources must be clean
    script's own marked sweep machinery and two curated docstring ban
    statements (the F37 and F48 restatements of paper firewalls), each probed
    with a defect wearing the ban phrase. This sweep's badge covers the two
    tokens only. Planted test cases: (s) a "continuously" sentence smuggled
    into native prose is flagged; (t) a "continuous" sentence smuggled into
    native prose is flagged; the Stage N forbidden-list sentence passes, the
    two docstring ban statements pass, and the ban-phrase exemption probe is
    flagged.
    17. Particle-language sweep (complexity-ordering particle leakage): bare
    "meson"/"baryon" forms outside the hyphenated "-like" hedge (P1;
    unhyphenated spellings such as "baryonlike" match nothing and stay
    human-audit territory), mass-derivation shapes (P2:
    "mass hierarchy"/"mass sequence"/"mass spectrum"/"mass ladder" language,
    "derives the mass", "mass from the ordering", "ordering predicts/fixes
    mass", "mass fixes the ordering", "more complex ... heavier" - bare
    "heavier" is deliberately unpatterned so the section 12.3 firewall witness
    ("a nucleus can be heavier than an atom with fewer nodes") passes unpinned;
    bare comparatives outside the "more complex ... heavier" coupling stay
    human-audit territory), and ladder phrases (P3: "particle ladder", "mass
    sequence", "particle hierarchy", "complexity ladder") are swept across the
    paper's prose (outside code fences) and all script sources, one physical
    line to a unit. The P1 lookahead excludes "-like" forms ("meson-like" is
    the paper's sanctioned structural descriptor); "photon", "open tilted
    states", and "nucleus"/"nuclei"/"atom(s)" are the paper's own section 12.1
    class names and are not fenced; "electron" is dual-use native vocabulary,
    out of scope by design. Justification pins are span-scoped: a pin admits a
    trigger only if the pin's literal string covers the trigger's matched span,
    so a pin never launders a defect in another clause; every pin is probed
    with a genuine defect wearing that pin. Prose occurrences must match the
    curated PARTICLE_JUSTIFICATIONS list (the section 12.2 firewall's quoted
    list, the section 12.2 register table, the Paper-16 bridge-scope
    deferrals, this description, the changelog); script sources must be clean
    except this script's own marked sweep machinery and the F37 class-name
    phrases (the F.37 ordering-key class names in mutant and diagnostic
    strings, each phrase content-specific). This sweep's badge covers the three
    pattern families only - it does not certify the absence of every
    particle-ontology leak. Planted test cases: (p1)-(p5), (p5b)
    particle-language mutants (bare-name, mass-derivation, and ladder-phrase
    defects) are flagged with printed witnesses; a pin-wearing defect is
    flagged; one granularity probe per justification pin is flagged; the
    "-like", deferral-pinned, firewall-witness, and firewall-sentence controls
    pass.
    18. Sequential-attraction sweep (universal-quantifier ladder claims):
    residual "the whole chain attracts" language - a universal
    sequential-attraction claim the paper's own section 9.3 results falsify -
    is swept across the paper's prose (outside code fences) and all script
    sources, one physical line to a unit. The covered pattern families: Q1
    (the explicit "all-attraction" / "all attraction" / "all-attracting"
    compound), Q2 (a universal quantifier "all"/"every"/"each"
    grammatically joined to a chain-noun
    ("rung"/"step"/"chain"/"sequence"/"order"/"ladder"/"series") and the
    attraction verb, either word order, within a 60-character clause - the
    clause bound keeps distant cross-sentence joins out of scope), Q3
    (sequential-narration shapes: "then attracts", "next, attraction",
    "attractions happen in sequence", the chain attracting "at every
    step"), and Q4 (an incorporation arrow-chain carrying a chain-noun and
    an attraction word, the attraction word within 80 characters of the
    chain; the Q4 noun set excludes "step"/"order" so the section 8.6
    selection rule is not in scope, and the Q1 lookbehind keeps the
    compound from firing as Q4). Justification pins are span-scoped: a pin
    admits a trigger only if the pin's literal string covers the trigger's
    matched span, so a pin never launders a defect in another clause; every
    pin is probed with a genuine defect wearing that pin. Prose occurrences
    must match the curated SEQATTR_JUSTIFICATIONS list (the section 9.6
    falsification statements, the Appendix H (H.4) claim-impact statement,
    the section 9.3 sweep-result machinery, the
    section 4.6 incorporation-mechanics sentence, this description, the
    changelog); script sources must be clean except this
    script's own marked sweep machinery and the F46 result-reporting
    phrases (each content-specific). This sweep's badge covers the covered
    pattern families only - it does not certify the absence of every
    universal-sequential-attraction assertion. Human-audit territory:
    sequential attraction implied without a covered quantifier or
    sequential phrase; cross-sentence narration; compact abstract ladder
    pointers carrying no covered trigger. Planted test cases: (u1)-(u3)
    residual sequential-attraction sentences (bare-rung, hostile-reader,
    and arrow-caption shapes, plus the Q1-compound and Q3-shape mutants)
    are flagged with printed witnesses; (u4) the falsification-statement
    control passes; (u5) the first-encounter controls pass; (u6) a
    pin-wearing defect is flagged; (u7) one granularity probe per
    justification pin is flagged; the F46 phrase lines pass and a
    phrase-wearing defect is flagged.
    19. Encounter-geometry sweep (V5 remediation: the new native Definition
    (Encounter Geometry) [L10-P11], section 3.2): the dropped token "relay
    position" (and the "relay-position"/"relayposition" variants), the
    direction-flip sentence shape, and "encounter geometry" usage
    consistency are swept across the paper's prose (outside code fences)
    and all script sources. (a) The dropped token: the design replaced it
    with met positions, presented ports, and taxicab-norm positions; any
    prose occurrence outside the changelog's historical record of the drop
    is rejected. Zero live prose occurrences exist, so the prose pin list
    is empty until the changelog records the drop. (b) Direction-flip:
    within an X->Y orientation context, the sentence shape "X presents a
    port to Y's scan" contradicts the defined direction clause ("Y
    presents a port to X's scan" within the X->Y orientation). Section
    4.6's "A presents a non-O boundary port toward B" names the
    presented-port posture - a different clause, and "toward" never
    matches the scan-direction pattern, so it is not flagged. A
    presents-clause whose entities match no orientation token on its line
    is shape-consistent (it states the defined clause for its own
    orientation) and stays human-audit territory. (c) "encounter geometry"
    consistency: every prose occurrence must avoid the blocked shapes -
    pinning the term to d = 1 exclusively (the blocked "iff" shape) or
    treating it as a primitive ("the primitive encounter geometry",
    "encounter geometry is assumed") - and must match a curated
    justification pin (the section 3.2 definition block, the section
    0.5.x/0.5.w entries, the section 3.3 proof, the section 4.5/4.6 usage
    block, the section 8.5 shell-profile line, the section 11.2
    environment line, the Appendix E registry and defined-token rows, the
    Appendix H falsification statement, the Appendix J theorem-map row,
    the changelog entries, this description). A pin admits only the line
    carrying the pin's literal string; the blocked shapes are checked
    first, so a pin never launders a defect in another clause, and every
    pin is probed with a genuine defect-shaped sentence wearing that pin.
    "direction" throughout means the section 8.6 incoming-against-neighbor
    orientation, never directional step-choice (v8 terminology lock). This
    sweep's badge covers sweep consistency only - it certifies token
    discipline, not the physics, and not that a given use satisfies either
    definitional disjunct: a well-worded but substantively wrong usage can
    pass the pins, so human review remains necessary (the same known limit
    as the R3 topicality rule). Script sources are scanned for the dropped
    token, the direction-flip shape, and the blocked consistency shapes on
    lines carrying the term; this script's own sweep machinery, the
    INPUT_PROVENANCE notes, and the planted mutants are exempt. Planted
    test cases: (eg-r1)-(eg-r3) dropped-token sentences ("relay position",
    "relay-position", "relayposition") are flagged with printed witnesses
    while the "relay-hop" control passes; (eg-d1)-(eg-d2) direction-flip
    sentences are flagged with printed witnesses while the defined
    direction clause, the section 4.6 posture clause, and an
    orientation-free presents-clause pass; (eg-c1)-(eg-c3) d=1-iff,
    d=1-exclusive, and primitive-treatment sentences are flagged with
    printed witnesses, the pin-wearing probes are flagged, the
    negation-guard control passes, and the definition's own "iff" sentence
    plus a pinned usage pass.
    20. Canonical-enumeration sweep (#120 remediation: the V8 false
    pointer - the section 7.5 operator definition and the section 11.2
    consolidation-path definition pointed at section 12.4 for the
    position-enumeration order, but section 12.4 defines only the
    six-class ordering key): every prose occurrence (outside code
    fences) of "canonically-first", "canonical enumeration order", or
    "canonical positions" must be anchored to the section 7.5
    definition - admitted in the section 7.x definition home, on lines
    carrying an explicit section-7.5 pointer, or in the changelog's
    historical record; the stale section-12.4 pointer shape on the
    concept is rejected wherever it appears, and any other section
    pointer (or no pointer outside the definition home) is rejected as
    unanchored. Script sources are scanned for the stale pointer shape
    on concept lines. The anti-vacuity assertions require the section
    7.5 definition line and the section 11.2 anchor line to exist, so
    the sweep cannot pass by the definition going missing. This
    sweep's badge covers pointer discipline only - a well-worded but
    substantively wrong ordering claim passes it, and novel wrong
    section pointers outside the covered shapes stay human-audit
    territory. Pointer attribution is sentence-scoped (a section pointer
    is attributed to the concept only inside the sentence carrying it;
    the stale section-12.4 shape is rejected line-wide). Planted test
    cases: (ce-1) a "canonical enumeration order" sentence carrying the
    stale pointer is flagged; (ce-2) a "canonically-first" sentence
    carrying a wrong-section pointer is flagged; (ce-3) a bare
    unanchored "canonical enumeration order" sentence is flagged;
    (ce-4) a wrong-section pointer inside the section-7.x home is
    flagged; the section 7.5 definition, the section 11.2 anchored
    pointer, and the section 7.3 proof use pass.
    21. Triple-convergence scope gates (ChatGPT HIGH-claim remediation,
    group 21): the arity-3 dynamics are the inherited
    triple-convergence transformation (section 7.6; Paper 2 8.1,
    11.1; Paper 3 7, 8.5) - never T, which is pairwise-scoped by the
    section 7.5 Scope note. Three never-again gates over live prose
    (fenced listings and the Appendix-I changelog excluded as dated
    historical record): (i) "arbitrary finite k" / "complete (native)
    transition rule" must carry explicit pairwise scope in the same
    paragraph, or a span-scoped scope pin admits the trigger (the
    section 7.5 Proof. F.43 sentence is pinned under its Scope note);
    (ii) every "triple-convergence" occurrence must name Paper 2
    section 8.1 -- the sole native product source per the author's
    2026-10-04 ruling -- or carry a section-7.6 pointer in the same
    paragraph (the section 7.6 heading carries its own pointer);
    (iii) sigma is never generalized beyond (A, B) -- subscript,
    plain-spelling, unicode-subscript, and plain-word three-component forms
    (sigma = (A, B, C), T(A, B, C), sigma_123, "the sigma triple" / "sigma
    as a triple of port tuples" near sigma/T -- the sanctioned
    "triple-convergence" term is convergence-guarded out) are rejected.
    Gate (i)
    is case-insensitive ("Arbitrary finite k" is caught); gate (ii)
    requires a Paper-2-8.1-naming citation or a section-7.6 pointer --
    a paragraph omitting Paper 2 section 8.1 is rejected. A lab-note prose sub-gate
    (2026-10-04 loop repair) rejects unpinned lab-note spellings
    (/lab[\\s\\-_]?notes?/, matching F.38's R3 ban) in live prose under
    seven span-scoped pins (the section-1 ban, the section-1 quarantine,
    the section-1 exclusion-box quarantine, the section-15 restatement,
    the Appendix-F F.3 banned-imports list, the section-14.2 F.38 bullet's
    ban description, the section-14.2 F.38 bullet's planted-battery names).
    Markdown list
    items start new paragraphs, since the section-14.2 bullets and
    the Appendix-H numbered list run without blank lines. The
    anti-vacuity assertions require the section 7.5 Scope note, the
    section 7.6 heading, and the section 7.5 sigma=(A, B) definition
    to exist. Planted test cases: an unscoped completeness sentence
    is flagged while the pairwise-scoped control passes; an uncited
    triple-convergence sentence is flagged while the section-7.6
    pointed control passes; a triple-convergence sentence omitting
    Paper 2 section 8.1 is flagged while the section-8.1-naming and
    four-source controls pass; a
    capitalized completeness sentence is flagged; plain-spelling, unicode,
    and plain-word three-component sigma sentences are flagged while the
    two-tuple and T(sigma) controls pass and the sanctioned
    "triple-convergence" term passes gate (iii); unpinned lab-note,
    lab_note, and lab-note spellings are flagged while the pinned ban
    control passes, and an extra mention appended outside a pin's span is
    flagged.
"""
import hashlib
import importlib.util
import io
import re
import sys
import tokenize
import ast as _ast
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "paper_11.md"

spec = importlib.util.spec_from_file_location(
    "f38", HERE / "F38_claim_registry.py")
f38 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f38)

SCALE_TOKENS = f38.SCALE_TOKENS
# A scale token is legal in script source only inside the firewall
# machinery that defines and tests the ban - never in a derivation.
FIREWALL_CONTEXT = re.compile(
    r"SCALE_TOKENS|R16|r16_violations|has_scale_token|denylist|firewall|"
    r"Stage-N|physical-scale|step length")

TOKEN_RE = re.compile(r"ℓ₀|ℓ0|t₀|m₀|κ|c_phys|Γ")

# ---------------------------------------------------------------------------
# INPUT_PROVENANCE (P1/P2 interface): every module-level source name declared.
# Classes: paper-defined | cited-paper | declared-assumption | control |
#          arbitrary-representative. ast.literal_eval-able (self-checked below).
# This script is sweep machinery, not a claim derivation: every binding but
# two is control (banned-token patterns, curated justification lists,
# runtime paths, fence handling). The two paper-defined bindings are the
# renamed term and its single definition line from §8.5, which the
# bridge-word sweep (group 13) uses to check that every native use of the
# renamed term resolves to the definition binding it to e·S(d).
# ---------------------------------------------------------------------------
INPUT_PROVENANCE = {
    "ESD_TERM": {"class": "paper-defined",
                 "source": "§8.5",
                 "anchor": "engagement-weighted scan allocation",
                 "note": "the sanctioned renamed term; the group-13 sweep checks "
                         "every native use resolves to ESD_DEFINITION_LINE"},
    "ESD_DEFINITION_LINE": {"class": "paper-defined",
                            "source": "§8.5",
                            "anchor": "The engagement-weighted scan allocation is "
                                      "therefore e·S(d) = e·s²/(4d² + 2).",
                            "note": "the single definition line binding the term to e·S(d)"},
    "TOKEN_RE": {"class": "control",
                 "note": "scale-token denylist pattern; the token inventory itself "
                         "comes from F38.SCALE_TOKENS"},
    "FIREWALL_CONTEXT": {"class": "control",
                         "note": "marks firewall-machinery context: a scale token is "
                                 "legal in script sources only inside the ban's own "
                                 "machinery, never in a derivation"},
    "JUSTIFICATIONS": {"class": "control",
                       "note": "group-4 occurrence-principle curated list: every prose "
                               "scale-token occurrence must match one justification; "
                               "every justification must match an occurrence"},
    "GRADIENT_RE": {"class": "control",
                    "note": "group-5 sweep pattern: the continuum-vocabulary token"},
    "GRADIENT_JUSTIFICATIONS": {"class": "control",
                                "note": "group-5 curated list (§0.5.x terminology lock, "
                                        "registry description, changelog)"},
    "CONTINUUM_RE": {"class": "control",
                     "note": "continuum-adverb sweep pattern: the two "
                             "continuum-vocabulary tokens 'continuously' and "
                             "'continuous'"},
    "CONTINUUM_JUSTIFICATIONS": {"class": "control",
                                 "note": "continuum-adverb sweep curated list "
                                         "(terminology locks, firewalls, register "
                                         "definitions, comparison contexts, "
                                         "changelog)"},
    "SCRIPT_CONTINUUM_BAN": {"class": "control",
                             "note": "continuum-adverb sweep curated script "
                                     "exemptions: the two docstring ban "
                                     "statements (F37, F48) restating paper "
                                     "firewalls, with a ban-phrase probe"},
    "PARTICLE_BARE_RE": {"class": "control",
                         "note": "group-17 sweep pattern P1: bare meson/baryon "
                                 "forms outside the hyphenated '-like' hedge "
                                 "(unhyphenated spellings unpatterned, "
                                 "human-audit territory)"},
    "PARTICLE_MASS_RES": {"class": "control",
                          "note": "group-17 sweep patterns P2: mass-derivation "
                                  "shapes (mass hierarchy/sequence/spectrum/"
                                  "ladder language, "
                                  "derives-the-mass, mass-from-ordering, "
                                  "ordering-predicts-mass, mass-fixes-ordering, "
                                  "more-complex/heavier coupling; bare "
                                  "'heavier' deliberately unpatterned)"},
    "PARTICLE_LADDER_RE": {"class": "control",
                           "note": "group-17 sweep pattern P3: ladder phrases "
                                   "('particle ladder', 'mass sequence', "
                                   "'particle hierarchy', 'complexity ladder')"},
    "PARTICLE_JUSTIFICATIONS": {"class": "control",
                                "note": "group-17 curated list (§12.2 "
                                        "firewall quoted list, §12.2 register "
                                        "table, Paper-16 bridge-scope "
                                        "deferrals, this description, "
                                        "changelog)"},
    "SCRIPT_PARTICLE_BAN": {"class": "control",
                            "note": "group-17 curated script exemptions: the "
                                    "F37 class-name phrases (ordering-key "
                                    "class names in mutant/diagnostic "
                                    "strings), with a phrase-wearing probe"},
    "BOUNDARY_BANNED_RE": {"class": "control",
                           "note": "group-6 sweep pattern: phantom list-verb and "
                                   "reified-boundary vocabulary"},
    "BOUNDARY_JUSTIFICATIONS": {"class": "control",
                                "note": "group-6 curated list (§4.3 non-substance rule, "
                                        "registry description, changelog)"},
    "REGISTER_BANNED_RE": {"class": "control",
                           "note": "group-7 sweep pattern: R register tokens "
                                   "(deprecated reconstruction-register alias)"},
    "REGISTER_JUSTIFICATIONS": {"class": "control",
                                "note": "group-7 curated list (§0.5.aa reconciliation "
                                        "note, R17 description, registry, changelog)"},
    "KINEMATICS_BANNED_RE": {"class": "control",
                             "note": "group-9 sweep pattern: differential-kinematics "
                                     "vocabulary"},
    "KINEMATICS_JUSTIFICATIONS": {"class": "control",
                                  "note": "group-9 curated list (§0.5.x terminology "
                                          "lock, registry description, changelog)"},
    "THERMO_BANNED_RE": {"class": "control",
                         "note": "group-10 sweep pattern: thermodynamic vocabulary"},
    "THERMO_JUSTIFICATIONS": {"class": "control",
                              "note": "group-10 curated list (§0.5.x terminology lock, "
                                      "Paper-12 firewall and deferral sections, "
                                      "registry description, changelog)"},
    "TELEO_BANNED_RE": {"class": "control",
                        "note": "group-11 sweep pattern: scalar, process, and "
                                "teleological readings of the ordering key "
                                "(v14(a) adds purpose-ascribing infinitival "
                                "shapes: designed/intended/in-order-to forms)"},
    "TELEO_JUSTIFICATIONS": {"class": "control",
                             "note": "group-11 curated list (§12 Canonical-Ordering "
                                     "Firewall, changelog)"},
    "ARITY_BANNED_RE": {"class": "control",
                        "note": "group-12 sweep pattern: the unqualified pairwise "
                                "junction formula and the restricted two-port phrase"},
    "ARITY_JUSTIFICATIONS": {"class": "control",
                             "note": "group-12 curated list (§4.3 pairwise corollary, "
                                     "registry descriptions, changelog)"},
    "BRIDGE_MAGNITUDE_RE": {"class": "control",
                            "note": "group-13 sweep pattern: the Stage P-reserved "
                                    "bridge word"},
    "BRIDGE_MAGNITUDE_JUSTIFICATIONS": {"class": "control",
                                        "note": "group-13 curated list (§8.5 "
                                                "bridge-reservation sentence, this "
                                                "description, changelog)"},
    "LABEL_BANNED_RE": {"class": "control",
                        "note": "group-14 sweep pattern: 'axiom' misapplied to "
                                "Paper-11 dependency labels, stale v2 role phrase"},
    "LABEL_JUSTIFICATIONS": {"class": "control",
                             "note": "group-14 curated list (changelog "
                                     "remediation-history entry)"},
    "MODAL_JUSTIFICATIONS": {"class": "control",
                             "note": "group-15 curated list (terminology lock, quoted "
                                     "defect patterns, changelog)"},
    "VOID_TOKEN_RE": {"class": "control",
                      "note": "void-token sweep pattern (the two banned tokens, "
                              "defined in the machinery block below)"},
    "VOID_TOKEN_JUSTIFICATIONS": {"class": "control",
                                  "note": "void-token sweep curated list (§0.5 design "
                                          "constraint, registry description, changelog)"},
    "FENCE": {"class": "control",
              "note": "fence token built dynamically so this file never contains a "
                      "raw triple-backtick (the paper embeds this listing in a fence)"},
    "HERE": {"class": "control",
             "note": "runtime path to this script's directory"},
    "PAPER": {"class": "control",
              "note": "runtime path to the paper file under test"},
    "_ROLE_WORD": {"class": "control",
                   "note": "group-15 pattern component: hyphen-guarded "
                           "active/passive word"},
    "_ROLE_NOUN": {"class": "control",
                   "note": "group-15 pattern component: extended-adjectival "
                           "noun list for the P3x pattern"},
    "_MODAL_ADVERB": {"class": "control",
                      "note": "group-15 pattern component: curated adverb "
                              "inventory for adverb-interrupted copulas "
                              "(P2); adverbs outside the list stay "
                              "human-audit territory"},
    "_MODAL_BEFORE": {"class": "control",
                      "note": "group-15 pattern component: modal capability forms "
                              "('can/could play')"},
    "_MODAL_INDEX": {"class": "control",
                     "note": "group-15 pattern component: encounter-index "
                             "tokens (the named 'encounter R' form; bare "
                             "'encounter' with no R is not a token)"},
    "_MODAL_NEG": {"class": "control",
                   "note": "group-15 pattern component: negation tokens"},
    "_MODAL_CLAUSE": {"class": "control",
                      "note": "group-15 pattern component: clause-boundary tokens"},
    "_MODAL_P1": {"class": "control",
                  "note": "group-15 pattern: play-verb pattern (plays/takes/"
                          "assumes, present and past)"},
    "_MODAL_P1B": {"class": "control",
                   "note": "group-15 pattern: gerund playing-the-role pattern"},
    "_MODAL_P1P": {"class": "control",
                   "note": "group-15 pattern: passive-voice play-verb pattern "
                           "('the X role is played by')"},
    "_MODAL_P1PART": {"class": "control",
                      "note": "group-15 pattern: participial play-verb pattern "
                              "('(having) played the X role')"},
    "_MODAL_P2": {"class": "control",
                  "note": "group-15 pattern: copula pattern (is/are/was/were, "
                          "comparative and curated-adverb interruptions)"},
    "_MODAL_P3ADJ": {"class": "control",
                     "note": "group-15 pattern: adjectival pattern"},
    "_MODAL_P3PAR": {"class": "control",
                     "note": "group-15 pattern: parenthetical pattern (plain "
                             "and participial forms)"},
    "_MODAL_P3X": {"class": "control",
                   "note": "group-15 pattern: extended-adjectival pattern"},
    "_MODAL_P4": {"class": "control",
                  "note": "group-15 pattern: copula-free verb pattern"},
    "_MODAL_P5": {"class": "control",
                  "note": "group-15 pattern: contrastive not-but pattern"},
    "_MODAL_PATTERNS": {"class": "control",
                        "note": "group-15 pattern inventory: all ten "
                                "pattern families swept"},
    "_INDEX_EXEMPT_PATTERNS": {"class": "control",
                               "note": "group-15: verb-sensitive index-exemption "
                                       "set (P4/P5 never index-exempt; the "
                                       "P1p/P1part forms index-exempt like "
                                       "P1/P1b)"},
    "SCALE_TOKENS": {"class": "control",
                     "note": "scale-claim tokens imported from the F38 registry "
                             "machinery (group-16 sweep input)"},
    "_MODAL_MACHINE_MSG": {"class": "control",
                           "note": "group-15 pattern component: machine assert-message "
                                   "exemption"},
    "_SEQATTR_CHAIN_NOUN": {"class": "control",
                           "note": "group-18 pattern component: chain-noun alternation "
                                   "for Q2 (rung/step/chain/sequence/order/ladder/series)"},
    "_SEQATTR_Q4_NOUN": {"class": "control",
                        "note": "group-18 pattern component: narrower chain-noun "
                                "alternation for Q4 (step/order excluded so the §8.6 "
                                "selection rule stays out of scope)"},
    "_SEQATTR_QUANT": {"class": "control",
                      "note": "group-18 pattern component: universal-quantifier "
                              "alternation for Q2 (all/every/each)"},
    "_SEQATTR_ATTRACT": {"class": "control",
                        "note": "group-18 pattern component: attraction-verb "
                                "alternation with the Q1-compound lookbehind, so the "
                                "all-attraction compound never fires as Q2/Q4"},
    "_SEQATTR_Q1": {"class": "control",
                   "note": "group-18 pattern: the explicit all-attraction compound "
                           "(also the spaced and -ing forms)"},
    "_SEQATTR_Q2": {"class": "control",
                   "note": "group-18 patterns: universal quantifier grammatically "
                           "joined to a chain-noun and the attraction verb, both "
                           "word orders, within a 60-character clause"},
    "_SEQATTR_Q3": {"class": "control",
                   "note": "group-18 patterns: sequential-narration shapes "
                           "(then-attracts, next-attraction, attractions-happen-in-"
                           "sequence, chain-attracts-at-every-step)"},
    "SEQATTR_JUSTIFICATIONS": {"class": "control",
                              "note": "group-18 curated prose pins: the §9.6 "
                                      "falsification statements, the Appendix H "
                                      "(H.4) claim-impact statement, the §9.3 "
                                      "sweep-result machinery, this description"},
    "SCRIPT_SEQATTR_ADMISSIONS": {"class": "control",
                                 "note": "group-18 script-side admissions: the F46 "
                                         "result-reporting phrases, each content-specific"},
    "EG_RELAY_RE": {"class": "control",
                    "note": "group-19 sweep pattern: the dropped 'relay position' "
                            "token and its hyphen/space variants"},
    "EG_RELAY_JUSTIFICATIONS": {"class": "control",
                                "note": "group-19 curated prose pins for the dropped "
                                        "token (empty: zero live prose occurrences; "
                                        "the changelog's historical record of the "
                                        "drop gets a content-specific pin when staged)"},
    "EG_PRESENTS_RE": {"class": "control",
                       "note": "group-19 sweep pattern: the scan-direction clause "
                               "shape 'P presents a port to S's scan'"},
    "EG_ORIENT_RE": {"class": "control",
                     "note": "group-19 sweep pattern: the X->Y orientation token"},
    "EG_TRIGGER_RE": {"class": "control",
                      "note": "group-19 sweep pattern: the 'encounter geometry' "
                              "term (spaced and hyphenated forms)"},
    "EG_IFF_D1_RE": {"class": "control",
                     "note": "group-19 sweep pattern: the blocked d=1 'iff' shape"},
    "EG_IS_D1_RE": {"class": "control",
                    "note": "group-19 sweep pattern: d=1-exclusive pinning shape"},
    "EG_PRIMITIVE_RES": {"class": "control",
                         "note": "group-19 sweep patterns: primitive-treatment "
                                 "shapes, with a negation guard"},
    "EG_CONSISTENCY_JUSTIFICATIONS": {"class": "control",
                                      "note": "group-19 curated prose pins: the §3.2 "
                                              "definition block, §§0.5.x/0.5.w entries, "
                                              "the §3.3 proof, the §§4.5/4.6 usage block, "
                                              "the §8.5 shell-profile line, the §11.2 "
                                              "environment line, the Appendix E rows, "
                                              "the Appendix H falsification statement, "
                                              "the Appendix J row, the changelog entries, "
                                              "this description"},
    "V13_ITEM_RE": {"class": "control",
                    "note": "group-20 sweep pattern: the six §12.1 enumerated "
                            "item heads (Photon / Open tilted states / Meson-like / "
                            "Baryon-like / Nuclei / Atoms)"},
    "V13_FLAG": {"class": "control",
                 "note": "group-20 sweep pattern: the '(reading aid; not "
                         "derived)' flag pinned on the six §12.1 items"},
    "V13_DEF_RE": {"class": "control",
                   "note": "group-20 sweep pattern: the §12.1 Definition "
                           "(Complexity Ordering) block locator"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "vocabulary firewall machinery; backs no Level-A claim.",
}
_ast.literal_eval(repr(INPUT_PROVENANCE))  # interface self-check: literal-evaluable

# v8: the continuum-vocabulary token. Case-insensitive.
GRADIENT_RE = re.compile(r"gradient", re.IGNORECASE)
# Every prose occurrence of the banned token must match one justification.
GRADIENT_JUSTIFICATIONS = [
    ("Terminology lock on \"gradient\"",
     "0.5.x lock: states the ban"),
    ("\"gradient-biased step selection\"",
     "0.5.x lock + changelog: names the excised token"),
    ("Continuous-gradient language",
     "0.5.x lock: confines continuum usage to Stage P/shadow"),
    ("continuous-gradient language",
     "changelog: v8 excision history"),
    ("banned token 'gradient'",
     "14.4 registry: F.42 description cites the sweep"),
    ("continuum-vocabulary leak excised",
     "changelog: v8 excision history"),
    ("phantom",
     "changelog: v8 excision history"),
]

# Built dynamically so this file never contains a raw triple-backtick:
# the paper embeds this script's source inside a fenced code block, and a
# literal fence inside the listing would corrupt naive fence parsing.
FENCE = "`" * 3

# Each entry: (content-specific substring, why that occurrence is legitimate).
# Every token-bearing prose line must contain at least one pattern; every
# pattern must match at least one line (no stale justifications).
JUSTIFICATIONS = [
    ("any term carrying physical dimension",
     "0.5.x firewall rule: names the banned tokens"),
    ("a physical step length is ℓ₀",
     "0.5.x register note: disambiguates the 'step' homonym"),
    ("no ℓ₀ enters",
     "0.5.x native distance: states the exclusion"),
    ("r = d·ℓ₀",
     "Level-B reconstruction formula (0.5.x native distance; v6 changelog)"),
    ("Every physical-scale token",
     "0.5.x occurrence principle: states the justification requirement"),
    ("— fundamental step length",
     "0.5.w reconstruction-calibration inventory (item 7, ℓ₀)"),
    ("— physical tick interval",
     "0.5.w reconstruction-calibration inventory (item 8, t₀)"),
    ("minimal mass quantum",
     "0.5.w reconstruction-calibration inventory (item 9, m₀)"),
    ("are imported at the reconstruction boundary",
     "0.5.w adoption counting: calibrations belong to Stage P"),
    ("measured physical interval per tick",
     "0.5.w tick-vs-t0 disambiguation"),
    ("Reconstruction Rule",
     "0.5.z Register B: Stage-P reconstruction definitions"),
    ("c_phys = ℓ₀/t₀",
     "0.5.z Register B: physical propagation speed definition"),
    ("C_exec and c_phys²",
     "0.5.z Register B: violation penalty"),
    ("No physical primitive scales",
     "0.5.v badge rule: states the Level-A ban"),
    ("a Level-A text containing ℓ₀",
     "14.4 registry: F.42 description cites its planted test case"),
    ("ℓ₀/ℓ0, t₀, m₀",
     "14.4 registry: R16 description names the banned tokens"),
    ("scale-token correction",
     "changelog: v6 history"),
    ("occurrence classified",
     "changelog: v6 history"),
    ("\"step length ℓ₀\"",
     "changelog: v6 history"),
    ("Two gaps the v6 firewall did not cover",
     "changelog: v7 history"),
    ("carrying ℓ₀",
     "changelog: v7 rectification history"),
    ("the m₀ sentence deleted",
     "changelog: v7 rectification history"),
    ("the §0.5 \"Tick vs t₀\" note",
     "§4.3 Port-Partition Exactness: cites the tick/t₀ disambiguation by name in the derivation scope note"),
    ("tick-vs-t₀",
     "changelog: V4 remediation history"),
]


def strip_code_fences(md):
    """Return lines with fenced code blocks replaced by None placeholders
    (line numbers preserved)."""
    out, incode = [], False
    for line in md.split("\n"):
        if line.strip().startswith(FENCE):
            incode = not incode
            out.append(None)
            continue
        out.append(None if incode else line)
    return out


def audit_prose_occurrences(md_text=None, justifications=None):
    """Extract every scale-token occurrence in prose (outside code fences)
    with its section context; check each against the justification list.

    Returns (violations, stale): violations lists unjustified occurrences,
    stale lists justifications matching nothing.
    """
    md = md_text if md_text is not None else PAPER.read_text(encoding="utf-8")
    justifications = (justifications if justifications is not None
                      else JUSTIFICATIONS)
    lines = strip_code_fences(md)
    cur = None
    occurrences = []
    for i, line in enumerate(lines, 1):
        if line is None:
            continue
        m = re.match(r"#{2,4}\s+(§[\d.]+)", line)
        if m:
            cur = m.group(1)
        if TOKEN_RE.search(line):
            occurrences.append((i, cur, line))
    violations = []
    for (i, sec, line) in occurrences:
        if not any(pat in line for pat, _ in justifications):
            violations.append(
                f"line {i} [{sec}]: unjustified scale token: "
                f"{line.strip()[:130]}")
    matched = {pat for pat, _ in justifications
               if any(pat in line for (_, _, line) in occurrences)}
    stale = [pat for pat, why in justifications if pat not in matched]
    return violations, stale


def check_vocab_list():
    md = PAPER.read_text(encoding="utf-8")
    start = md.index("POSITIVE DERIVATION")
    end = md.index("2. **COMPARISON", start)
    vocab = md[start:end]
    assert "relay-hop count d" in vocab, "native distance term missing"
    bad = [t for t in SCALE_TOKENS if t in vocab]
    assert not bad, f"scale tokens in native vocabulary list: {bad}"
    assert "step length" not in vocab.replace("step length is", ""), \
        "native 'step length' phrasing still present"
    return vocab


def check_scripts():
    import io
    violations = []
    for p in sorted(HERE.glob("F*.py")):
        src = p.read_text(encoding="utf-8")
        lines = src.splitlines()
        toks = list(tokenize.generate_tokens(io.StringIO(src).readline))

        def enclosing_func(lineno):
            for n in range(lineno, 0, -1):
                m = re.match(r"^(\s*)def\s+(\w+)", lines[n - 1])
                if m:
                    return m.group(2)
            return ""

        # Line ranges of the firewall-machinery statements that legitimately
        # name scale tokens: the SCALE_TOKENS import, the TOKEN_RE pattern,
        # and the curated JUSTIFICATIONS list.
        def stmt_range(name):
            for i, t in enumerate(toks):
                if (t.type == tokenize.NAME and t.string == name
                        and i + 1 < len(toks) and toks[i + 1].string == "="):
                    start = t.start[0]
                    depth = 0
                    for u in toks[i + 2:]:
                        if u.type in (tokenize.NEWLINE, tokenize.NL,
                                      tokenize.COMMENT, tokenize.INDENT,
                                      tokenize.DEDENT):
                            if depth == 0:
                                return (start, u.start[0])
                            continue
                        if u.string in "([{":
                            depth += 1
                        elif u.string in ")]}":
                            depth -= 1
                            if depth == 0:
                                return (start, u.end[0])
                    return (start, start)
            return None

        allowed_ranges = [r for r in
                          (stmt_range("SCALE_TOKENS"), stmt_range("TOKEN_RE"),
                           stmt_range("JUSTIFICATIONS")) if r]

        for t in toks:
            ln = t.start[0]
            if t.type == tokenize.NUMBER and ("." in t.string
                                             or re.search(r"[eE]", t.string)):
                if "print(" not in lines[ln - 1]:
                    violations.append(
                        f"{p.name}:{ln} float literal in code outside print()")
            if t.type == tokenize.NAME and t.string == "float":
                if "print(" not in lines[ln - 1]:
                    violations.append(
                        f"{p.name}:{ln} float() in code outside print()")
            if t.type in (tokenize.STRING, tokenize.COMMENT):
                hits = [tok for tok in SCALE_TOKENS if tok in t.string]
                if not hits:
                    continue
                in_machinery = any(a <= ln <= b for (a, b) in allowed_ranges)
                ok = (in_machinery
                      or FIREWALL_CONTEXT.search(lines[ln - 1])
                      or "planted" in enclosing_func(ln))
                if not ok:
                    violations.append(
                        f"{p.name}:{ln} scale token {hits} in derivation code")
    assert not violations, "script firewall violations:\n" + "\n".join(violations)


def check_registry_dependency_half():
    vs = f38.r16_violations(f38.REGISTRY)
    assert not vs, f"R16 violations in clean registry: {vs}"


def check_prose_occurrences():
    violations, stale = audit_prose_occurrences()
    assert not violations, \
        "unjustified scale-token occurrences in prose:\n" + "\n".join(violations)
    assert not stale, f"stale justifications (match nothing): {stale}"


def gradient_prose_violations(md_text):
    """All prose lines (outside code fences) containing the banned
    continuum token 'gradient' that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if GRADIENT_RE.search(line):
            if not any(pat in line for pat, _ in GRADIENT_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_gradient_sweep():
    """Continuum-vocabulary sweep: 'gradient' must not occur in native prose or in
    any script source except this script's own sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = gradient_prose_violations(md)
    assert not bad, "unjustified 'gradient' in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and GRADIENT_RE.search(l)]
    matched = {pat for pat, _ in GRADIENT_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in GRADIENT_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale gradient justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if not GRADIENT_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py":
                ok = bool(re.search(
                    r"GRADIENT|gradient sweep|v8|"
                    r"terminology lock|planted|firewall", sl, re.I))
            else:
                ok = False
            assert ok, f"{p.name}:{j} unjustified 'gradient' in script source"


# MACHINERY-START: continuum-adverb sweep. The banned tokens inside this
# block are the sweep's own patterns, never paper content.
CONTINUUM_RE = re.compile(r"continuo(us|usly)", re.IGNORECASE)
# Every prose occurrence of a continuum-vocabulary token must match one
# justification. Patterns are content-specific (v7/v8 convention): each of
# the paper's current occurrences was read with the paper open and filed
# under a legitimate category (terminology lock, firewall, register
# definition, comparison context, changelog) - no blanket justification.
CONTINUUM_JUSTIFICATIONS = [
    ("continuous metric theory",
     "comparison context: §0.5 note names standard-account vocabulary"),
    ("Continuous-gradient language belongs",
     "0.5.x terminology lock: confines continuum language to Stage P "
     "reconstruction or marked observational shadow"),
    ("continuous variables",
     "0.5.x Stage N register: forbidden-operations list states the ban"),
    ("continuous-limit extractions",
     "0.5.x Stage P register definition"),
    ("a continuous approximation",
     "hard firewall: breach condition names the forbidden operation"),
    ("artifact of continuous calculus",
     "comparison context (§0.5 dagger) and changelog: names continuous "
     "calculus as the standard-account artifact"),
    ("background continuous manifold",
     "manifold-ontology firewall: denial sentence"),
    ("continuous-form equation",
     "0.5.z register definition: the reconstruction line"),
    ("degraded continuous rendering",
     "downgrade clause: the reconstruction rendering"),
    ("no continuous limit",
     "§7.4 active-role definition: denial sentence"),
    ("continuous progress",
     "canonical-ordering firewall: banned justification phrase, plus "
     "changelog history"),
    ("continuous-gradient language is confined",
     "changelog: v8 lock history"),
    ("continuum-adverb sweep — admitted only in terminology locks",
     "this description — the §14.4 F.42 description's own continuum-adverb "
     "clause (names the swept tokens while stating the admission rule)"),
    ("Three prose \"continuously\" adverbs",
     "changelog — entry #95's remediation record (names the three excised "
     "native-prose occurrences and the sweep extension)"),
]
# Script sources are clean of continuum vocabulary except this script's own
# sweep machinery and the two curated docstring ban statements below. Each
# is an explicit restatement of a paper firewall; the exemption admits the
# ban statement, not the line - a defect wearing the ban phrase is still
# flagged (probed in check_planted).
SCRIPT_CONTINUUM_BAN = {
    "F37_complexity_ordering.py":
        ["continuous progress, no purpose, no degree of resolvedness"],
    "F48_consolidation_paths.py": ["No continuous calculus"],
}


def continuum_prose_violations(md_text):
    """All prose lines (outside code fences) containing a
    continuum-vocabulary token ('continuously'/'continuous') that match no
    curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if CONTINUUM_RE.search(line):
            if not any(pat in line for pat, _ in CONTINUUM_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def continuum_script_line_ok(pname, sl):
    """Script-source exemption predicate for continuum-vocabulary tokens."""
    if pname == "F42_stageN_firewall.py":
        return True  # this script's own sweep machinery
    pats = SCRIPT_CONTINUUM_BAN.get(pname)
    if not pats:
        return False
    return (any(pat in sl for pat in pats)
            and sum(1 for _ in CONTINUUM_RE.finditer(sl))
            == sum(1 for pat in pats for _ in CONTINUUM_RE.finditer(pat)))
# MACHINERY-END


def check_continuum_sweep():
    """Continuum-adverb sweep: 'continuously'/'continuous' must not occur in
    native prose or in any script source except the curated prose
    justifications and this sweep's own machinery plus the two docstring
    ban statements."""
    md = PAPER.read_text(encoding="utf-8")
    bad = continuum_prose_violations(md)
    assert not bad, \
        "unjustified continuum vocabulary in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and CONTINUUM_RE.search(l)]
    matched = {pat for pat, _ in CONTINUUM_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in CONTINUUM_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale continuum justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if not CONTINUUM_RE.search(sl):
                continue
            assert continuum_script_line_ok(p.name, sl), \
                f"{p.name}:{j} unjustified continuum vocabulary in script source"


# MACHINERY-START: particle-language sweep (group 17). The banned tokens
# inside this block are the sweep's own patterns and justification pins,
# never paper content.
# P1: bare meson/baryon forms. The negative lookahead excludes the "-like"
# hedge ("meson-like" is the paper's sanctioned structural descriptor).
# "meson_like" does not match: the underscore is a word character, so no
# boundary fires between the stem and the underscore. The hedge is the
# hyphenated "-like" form specifically: "baryonlike" (no hyphen) matches
# nothing - the "l" is a word character, so no boundary fires - and stays
# human-audit territory (orthographic-boundary staple).
PARTICLE_BARE_RE = re.compile(r"\b(mesons?|baryons?)(?!-like)\b", re.IGNORECASE)
# P2: mass-derivation shapes - concrete phrasings only. Bare "heavier" is
# deliberately NOT patterned: the §12.3 firewall witness ("a nucleus can be
# heavier than an atom with fewer nodes") must pass unpinned.
PARTICLE_MASS_RES = (
    re.compile(r"\bmass (hierarchy|sequence|spectrum|ladder)\b", re.IGNORECASE),
    re.compile(r"\bderives? .* masses?\b", re.IGNORECASE),
    re.compile(r"\bmasses? .* from the .* ordering\b", re.IGNORECASE),
    re.compile(r"\bordering .* (predicts?|fix(es)?|determines?) .* masses?\b",
               re.IGNORECASE),
    re.compile(r"\bmasses? .* (fix(es)?|determines?|predicts?) .* ordering\b",
               re.IGNORECASE),
    re.compile(r"\bmore complex\b.*\bheavier\b"
               r"|\bheavier\b.*\bmore complex\b", re.IGNORECASE),
)
# P3: ladder phrases. "particle hierarchy" is the §9 head fence's negated
# form (pin-admitted below); "complexity ladder" has zero live occurrences
# (future-proofing).
PARTICLE_LADDER_RE = re.compile(r"\bparticle ladder\b|\bmass sequence\b"
                                r"|\bparticle hierarchy\b|\bcomplexity ladder\b",
                                re.IGNORECASE)
# Every prose occurrence of a particle-language trigger must match one
# justification pin. Pins are span-scoped: a pin admits a trigger only if
# the pin's literal string covers the trigger's matched span - a pin never
# launders a defect in another clause of the same line. Each pin was read
# with the paper open and filed under its legitimate category (the §12.2
# firewall's quoted list, the §12.2 register table, the Paper-16
# bridge-scope deferrals, this description, the changelog); every pin is
# probed with a genuine defect wearing that pin in check_planted.
PARTICLE_JUSTIFICATIONS = [
    ("\"baryons\" in the standard account",
     "§12.2 firewall: the declared bridge sentence quotes the bare form "
     "to deny the standard-account reading"),
    ("(\"meson,\" \"baryon,\" \"nucleus,\" \"atom\")",
     "§12.2 firewall: the quoted convenient-labels list"),
    ("\"meson\"/\"mesons\"/\"baryon\"/\"baryons\"",
     "§12.2 register table: names the bare forms to mark them Register-2"),
    ("Bare 'meson'/'baryon' outside the §12.2 firewall",
     "§12.2 register table: the rule sentence stating the leakage boundary"),
    ("Paper 16 owns baryon/meson structural mapping",
     "bridge-scope deferral: the Abstract and §15 state Paper 16 owns "
     "the structural mapping"),
    ("Paper 16's baryon mapping",
     "bridge-scope deferral: the §1 exclusion box (does not pre-empt "
     "Paper 16)"),
    ("Paper 16's baryon/meson structural mapping",
     "bridge-scope deferral: the §14.1 deferred list"),
    ("Paper 16 owns the baryon mapping",
     "bridge-scope deferral: the changelog's neutron-identification "
     "removal entry"),
    ("bare 'meson'/'baryon' (outside the hyphenated '-like' hedge",
     "this description - the §14.4 F.42 description's own particle-language "
     "clause (names the swept tokens while stating the admission rule)"),
    ("\"mesons → baryons\" ordering repaired",
     "changelog - entry #101's remediation record (quotes the repaired "
     "abstract ordering)"),
    ("B=0/baryon-meson/B-bounds",
     "changelog - entry #123's deferred list (Paper-16 B=0 / baryon-meson "
     "scope note)"),
    ("not a particle hierarchy",
     "§9 head fence: the negated-thesis ladder fence denies the "
     "particle-hierarchy reading; the changelog quotes the fence"),
    ("'particle ladder', 'mass sequence', 'particle hierarchy', 'complexity ladder'",
     "this description - the §14.4 F.42 description's own particle-language "
     "clause (names the four P3 ladder phrases)"),
    ("\"particle hierarchy\" and \"complexity ladder\"",
     "changelog - entry #102's build record (names the two P3 additions)"),
]
# Script sources are clean of particle-language triggers except this
# script's own sweep machinery and the F37 class-name phrases below. Each
# phrase is the F.37 ordering-key class name as it appears in a mutant or
# diagnostic string; the exemption admits the phrase, not the line - a
# defect wearing the phrase is still flagged (probed in check_planted).
SCRIPT_PARTICLE_BAN = {
    "F37_complexity_ordering.py": [
        "M6 baryon res 1->0 (tie-break destroyed)",
        "M7 meson nodes 3->4 (reorders)",
        "D2 meson/baryon nodes 3->2 (order-preserving wrong input passes)",
        "meson/baryon step decided at resolution",
        "Tie-break robustness: meson/baryon decided at resolution for ANY shared tilt.",
        "DIAGNOSTIC PASS: meson/baryon tie-break at resolution",
    ],
}


def _particle_raw_triggers(line):
    """All (pattern-name, match) pairs firing on a physical line."""
    out = []
    for m in PARTICLE_BARE_RE.finditer(line):
        out.append(("P1", m))
    for k, rx in enumerate(PARTICLE_MASS_RES):
        for m in rx.finditer(line):
            out.append((f"P2.{k}", m))
    for m in PARTICLE_LADDER_RE.finditer(line):
        out.append(("P3", m))
    return out


def _particle_pin_admits(line, mstart, mend):
    """Span-scoped pin admission: a justification pin admits a trigger only
    if the pin's literal string covers the trigger's matched span. A pin
    never launders a defect sitting in another clause of the same line."""
    for jstr, _ in PARTICLE_JUSTIFICATIONS:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def particle_prose_violations(md_text):
    """All prose lines (outside code fences) with an unpinned
    particle-language trigger. One physical line is the unit; each trigger
    is admitted individually by a span-covering justification pin."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        for name, m in _particle_raw_triggers(line):
            if _particle_pin_admits(line, m.start(), m.end()):
                continue
            bad.append(f"line {i} [{name}]: {line.strip()[:120]}")
    return bad


def particle_script_line_ok(pname, sl):
    """Script-source exemption predicate for particle-language triggers."""
    if pname == "F42_stageN_firewall.py":
        return True  # this script's own sweep machinery (docstring item 17
        # and the INPUT_PROVENANCE notes name the tokens outside MACHINERY)
    pats = SCRIPT_PARTICLE_BAN.get(pname)
    if not pats:
        return False
    present = [pat for pat in pats if pat in sl]
    if not present:
        return False
    n_line = sum(1 for _ in _particle_raw_triggers(sl))
    n_pats = sum(1 for pat in present for _ in _particle_raw_triggers(pat))
    return n_line == n_pats
# MACHINERY-END


# MACHINERY-START: sequential-attraction sweep (group 18). The banned
# tokens inside this block are the sweep's own patterns and justification
# pins, never paper content.
# The sweep targets residual "the whole chain attracts" language: a
# universal sequential-attraction claim the paper's own §9.3 results
# falsify. Four pattern families:
# Q1: the explicit "all-attraction" compound (also "all attraction" and
# "all-attracting"). The lookbehind keeps the compound from double-firing
# in Q2/Q4.
# Q2: a universal quantifier ("all"/"every"/"each") grammatically joined
# to a chain-noun ("rung"/"step"/"chain"/"sequence"/"order"/"ladder"/
# "series") and the attraction verb, either word order, within a
# 60-character clause. The clause bound keeps distant cross-sentence joins
# out of scope: a bare "every incorporation order contains at least one
# forced decay" with attraction two sentences later does not fire.
# Q3: sequential-narration shapes - "then attracts", "next, attraction",
# "attractions happen in sequence", and the chain attracting "at every
# step".
# Q4: an incorporation arrow-chain (two arrows within 60 characters) on a
# line carrying a chain-noun, with an attraction word within 80 characters
# of the chain. The Q4 noun set is narrower than Q2's ("step"/"order" are
# out) so the §8.6 selection rule ("res(A, B) = 0 → attraction", whose
# line's nearest chain-noun is "step" in "incorporation step") stays out of
# scope; the Q1 lookbehind applies to Q4's attraction word so the compound
# never fires as Q4.
_SEQATTR_CHAIN_NOUN = r"(?:rungs?|steps?|chains?|sequences?|orders?|ladders?|series)"
_SEQATTR_Q4_NOUN = r"(?:chains?|ladders?|rungs?|sequences?|series)"
_SEQATTR_QUANT = r"(?:all|every|each)"
_SEQATTR_ATTRACT = r"(?<!all[\s-])attract(?:s|ed|ion|ions)?"
_SEQATTR_Q1 = re.compile(
    r"\ball[\s-]attract(?:ion|ing)?\b", re.IGNORECASE)
_SEQATTR_Q2 = (
    re.compile(r"\b" + _SEQATTR_QUANT + r"\b.{0,60}?\b" + _SEQATTR_CHAIN_NOUN
               + r"\b.{0,60}?\b" + _SEQATTR_ATTRACT + r"\b", re.IGNORECASE),
    re.compile(r"\b" + _SEQATTR_ATTRACT + r"\b.{0,60}?\b" + _SEQATTR_QUANT
               + r"\b.{0,60}?\b" + _SEQATTR_CHAIN_NOUN + r"\b", re.IGNORECASE),
)
_SEQATTR_Q3 = (
    re.compile(r"\bthen\b.{0,60}?\battract(?:s|ed|ion|ions)?\b", re.IGNORECASE),
    re.compile(r"\bnext[,:]?\s+attraction\b", re.IGNORECASE),
    re.compile(r"\battractions?\b.{0,40}?\bhappen(?:s|ed)?\b.{0,40}?\bin sequence\b",
               re.IGNORECASE),
    re.compile(r"\bchains?\b.{0,60}?\battract(?:s|ing|ion)?\b.{0,60}?\bat every "
               r"(?:steps?|rungs?)\b", re.IGNORECASE),
)
# Every prose occurrence of a sequential-attraction trigger must match one
# justification pin. Pins are span-scoped: a pin admits a trigger only if
# the pin's literal string covers the trigger's matched span - a pin never
# launders a defect in another clause of the same line. Each pin was read
# with the paper open and filed under its legitimate category (the §9.6
# falsification statements, the Appendix H (H.4) claim-impact statement,
# the §9.3 sweep-result machinery, the §4.6
# incorporation-mechanics sentence, this description, the changelog);
# every pin is probed with a genuine defect
# wearing that pin in check_planted.
SEQATTR_JUSTIFICATIONS = [
    ("the sequential all-attraction reading is falsified in §9.6",
     "§9.6 falsification: the Abstract, the §8.6 Disjunction paragraph, "
     "the §9.6 quarantine, the G.5 caption, the §13.2 export, and the "
     "changelog name the sequential all-attraction reading only to "
     "falsify it"),
    # v55 historical pin: the changelog is verbatim record and keeps the
    # pre-v55 address. This literal matches only the v43 changelog entry;
    # live prose uses §9.6 (pin above). Span-scoped: admits only the
    # trigger its literal covers. The uniqueness battery below enforces
    # that no live-prose occurrence can hide behind this pin.
    ("the sequential all-attraction reading is falsified in §9.5",
     "§9.5 falsification (historical address): changelog #104's verbatim "
     "v43 record keeps the pre-v55 section number"),
    ("the sequential all-attraction reading of the ladder is falsified in §9.6",
     "§9.6 falsification: the §1 introduction, the §1 exclusion box, and §17 "
     "name the sequential all-attraction reading of the ladder only to "
     "falsify it"),
    ("incorporate State 1, then State 2 against the enlarged aggregate, then "
     "State 3, and so on through State 9 — does every rung attract?",
     "§9.6 falsification: the §9.3 results pose the sequential question "
     "only to answer it in the negative"),
    ("The sequential all-attraction ladder is therefore **not** claimed.",
     "§9.6 falsification: the denial sentence states the sequential ladder "
     "is not claimed"),
    ("sequential all-attraction reading falsified",
     "registry impact: the Appendix H (H.4) claim-impact statement records "
     "the falsified reading"),
    ("Zero all-attraction orders: 0 of 362,880 per seed.",
     "§9.3 sweep machinery: the zero-result headline of the 9! order sweep"),
    ("Every incorporation order contains at least one forced decay. Because "
     "attraction is res = 0",
     "§9.3 sweep machinery: the zero-result's mechanism sentence"),
    ("the all-attraction partition (res = 0) does not move with TH",
     "§9.3 sweep machinery: the TH-independence limitation sentence"),
    ("zero all-attraction orders under every seed",
     "sweep results: the §9.3 accounting and the changelog both report the "
     "zero null"),
    ("Where incorporation then occurs — the §9.3 chain's attraction steps, "
     "each a junction completion",
     "§4.6 incorporation-mechanics sentence - the chain's "
     "\"attraction steps\" as junction completions (Alteration (i)), not a "
     "universal sequential-attraction claim"),
    ("Q1: the \"all-attraction\" compound (also \"all-attracting\"); Q2: a "
     "universal quantifier ('all'/'every'/'each') joined to a chain-noun "
     "('rung'/'step'/'chain'/'sequence'/'order'/'ladder'/'series') and the "
     "attraction verb, in either word order; Q3: sequential-narration shapes "
     "('then attracts', 'next, attraction', 'attractions happen in sequence', "
     "the chain attracting 'at every step'); Q4: an incorporation "
     "arrow-chain carrying a chain-noun and an attraction word",
     "this description - the §14.4 F.42 description's own sequential-"
     "attraction clause (the pattern glossary; proximity joins inside the "
     "glossary are the description naming the patterns, not paper claims)"),
]
# Script sources are clean of sequential-attraction triggers except this
# script's own sweep machinery and the F46 result-reporting phrases below.
# Each phrase is the F.46 ladder-sweep print text reporting the
# all-attraction null; the exemption admits the phrase, not the line - a
# defect wearing the phrase is still flagged (probed in check_planted).
SCRIPT_SEQATTR_ADMISSIONS = {
    "F46_caseA_ladder.py": [
        "INCLUDING all-attraction nulls",
        "all-attraction orders (TH-INDEPENDENT)",
        "total non-all-attraction",
        "every order all-attraction",
    ],
}


def _seqattr_raw_triggers(line):
    """All (pattern-name, match) pairs firing on a physical line."""
    out = []
    for m in _SEQATTR_Q1.finditer(line):
        out.append(("Q1", m))
    for k, rx in enumerate(_SEQATTR_Q2):
        for m in rx.finditer(line):
            out.append((f"Q2.{k}", m))
    for k, rx in enumerate(_SEQATTR_Q3):
        for m in rx.finditer(line):
            out.append((f"Q3.{k}", m))
    out.extend(_seqattr_q4_hits(line))
    return out


def _seqattr_q4_hits(line):
    """Q4: arrow-chain narration. A chain-noun line carrying an incorporation
    arrow-chain (two arrows within 60 characters) and an attraction word
    within 80 characters of the chain."""
    out = []
    arrows = [m.start() for m in re.finditer("→", line)]
    if not any(b - a <= 60 for a in arrows for b in arrows if b > a):
        return out
    if not re.search(r"\b" + _SEQATTR_Q4_NOUN + r"\b", line, re.IGNORECASE):
        return out
    for m in re.finditer(r"\b" + _SEQATTR_ATTRACT + r"\b", line, re.IGNORECASE):
        if any(abs(m.start() - a) <= 80 for a in arrows):
            out.append(("Q4", m))
    return out


def _seqattr_pin_admits(line, mstart, mend):
    """Span-scoped pin admission: a justification pin admits a trigger only
    if the pin's literal string covers the trigger's matched span. A pin
    never launders a defect sitting in another clause of the same line."""
    for jstr, _ in SEQATTR_JUSTIFICATIONS:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def seqattr_prose_violations(md_text):
    """All prose lines (outside code fences) with an unpinned
    sequential-attraction trigger. One physical line is the unit; each
    trigger is admitted individually by a span-covering justification pin."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        for name, m in _seqattr_raw_triggers(line):
            if _seqattr_pin_admits(line, m.start(), m.end()):
                continue
            bad.append(f"line {i} [{name}]: {line.strip()[:120]}")
    return bad


def seqattr_script_line_ok(pname, sl):
    """Script-source exemption predicate for sequential-attraction triggers."""
    if pname == "F42_stageN_firewall.py":
        return True  # this script's own sweep machinery (docstring item 18
        # names the swept tokens outside MACHINERY)
    pats = SCRIPT_SEQATTR_ADMISSIONS.get(pname)
    if not pats:
        return False
    present = [pat for pat in pats if pat in sl]
    if not present:
        return False
    n_line = sum(1 for _ in _seqattr_raw_triggers(sl))
    n_pats = sum(1 for pat in present for _ in _seqattr_raw_triggers(pat))
    return n_line == n_pats
# MACHINERY-END


def check_seqattr_sweep():
    """Sequential-attraction sweep: the covered universal-quantifier ladder
    patterns must not occur in native prose or in any script source except
    the curated prose justifications, this sweep's own machinery, and the
    F46 result-reporting phrases."""
    md = PAPER.read_text(encoding="utf-8")
    bad = seqattr_prose_violations(md)
    assert not bad, \
        "unjustified sequential-attraction language in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and _seqattr_raw_triggers(l)]
    matched = {pat for pat, _ in SEQATTR_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in SEQATTR_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale sequential-attraction justifications: {stale}"
    # Historical-pin uniqueness: the v55 pin admits the old "§9.5 falsified"
    # literal only for changelog #104's verbatim record. If a live-prose
    # occurrence ever appears, the count below exceeds 1 and the gate fails
    # (a new live-prose "falsified in §9.5" must cite §9.6, never the pin).
    # Counted on fence-stripped prose: the pin definition and this assertion
    # live inside F42's own embedded listing (code fence), not prose.
    hist_lit = "the sequential all-attraction reading is falsified in §9.5"
    prose_lines = [l for l in strip_code_fences(md) if l]
    prose_text = "\n".join(prose_lines)
    assert prose_text.count(hist_lit) == 1, \
        f"historical §9.5 literal must occur exactly once in prose (changelog #104); found {prose_text.count(hist_lit)}"
    # Location-aware: the single occurrence must be in the changelog/Appendix I
    # region (verbatim historical record), not live prose. A swap attack
    # (delete changelog occurrence, add identical literal in live prose) would
    # pass the count but fail here (red-team 2026-10-04).
    hit_idx = next(i for i, l in enumerate(prose_lines) if hist_lit in l)
    # Map back to the full document to check region: find Appendix I heading
    full_lines = md.split("\n")
    app_i = next(i for i, l in enumerate(full_lines) if l.startswith("## APPENDIX I"))
    # The prose_lines index doesn't map directly; instead check the hit is in
    # the changelog by verifying it appears after APPENDIX I in the full text.
    # Simpler: assert the literal occurs in the full text only at/after app_i.
    first_full_idx = next(i for i, l in enumerate(full_lines) if hist_lit in l and not l.strip().startswith("```"))
    # Skip fenced lines: find first non-fence occurrence
    in_fence = False
    first_prose_idx = None
    for i, l in enumerate(full_lines):
        if l.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence and hist_lit in l:
            first_prose_idx = i
            break
    assert first_prose_idx is not None and first_prose_idx > app_i, \
        "historical §9.5 literal must occur in the changelog (post-Appendix I), not live prose"
    for p in sorted(HERE.glob("F*.py")):
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if not _seqattr_raw_triggers(sl):
                continue
            assert seqattr_script_line_ok(p.name, sl), \
                f"{p.name}:{j} unjustified sequential-attraction language in script source"


def check_particle_sweep():
    """Particle-language sweep: bare 'meson'/'baryon', mass-derivation
    shapes, and ladder phrases must not occur in native prose or in any
    script source except the curated prose justifications, this sweep's own
    machinery, and the F37 class-name phrases."""
    md = PAPER.read_text(encoding="utf-8")
    bad = particle_prose_violations(md)
    assert not bad, \
        "unjustified particle language in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and _particle_raw_triggers(l)]
    matched = {pat for pat, _ in PARTICLE_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in PARTICLE_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale particle justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if not _particle_raw_triggers(sl):
                continue
            assert particle_script_line_ok(p.name, sl), \
                f"{p.name}:{j} unjustified particle language in script source"


# MACHINERY-START: encounter-geometry sweep (group 19; V5 remediation).
# New native Definition (Encounter Geometry) [L10-P11], section 3.2:
# three defect classes - the dropped token "relay position", the
# direction-flip sentence shape, and "encounter geometry" usage
# consistency - swept across the paper's prose (outside code fences) and
# all script sources. "direction" throughout means the section 8.6
# incoming-against-neighbor orientation, never directional step-choice
# (v8 terminology lock). This sweep's badge covers sweep consistency
# only: a well-worded but substantively wrong usage can pass the pins,
# so human review remains necessary (the same known limit as the R3
# topicality rule). See docstring item 19 for the full description.
EG_RELAY_RE = re.compile(r"relay[\s\-–—]?position", re.IGNORECASE)
# EG_RELAY_JUSTIFICATIONS: prose pin list for the dropped token. Empty
# on purpose: zero live prose occurrences exist, so there is no stale
# pin to carry. When the changelog records the drop, a content-specific
# pin (the changelog's own sentence about the drop) must be added here
# deliberately - the occurrence principle forbids adding it in advance.
# The changelog's historical record of the drop (item 114) is now the
# only admitted prose occurrence.
EG_RELAY_JUSTIFICATIONS = [
    ("the design term \"relay position\" is dropped from the live vocabulary",
     "changelog item 114 (V5): historical record of the dropped term"),
]
# The scan-direction clause shape: "P presents a port to S's scan".
# Captures (presenter P, scan owner S). Section 4.6's "A presents a
# non-O boundary port toward B" (the presented-port posture) never
# matches: "toward" has no "to <letter>'s scan" tail.
EG_PRESENTS_RE = re.compile(
    r"\b([A-Za-z])\s+presents?\s+a(?:n)?\s+(?:[\w\-–—]+\s+){0,3}ports?\s+to\s+"
    r"([A-Za-z])(?:'s|’s)\s+scan\b", re.IGNORECASE)
# The orientation token: a bare "X->Y" / "X→Y" letter pair (never a
# bare ">" - "E(A→B, τ)" marks the same orientation as "A->B").
EG_ORIENT_RE = re.compile(r"\b([A-Za-z])\s*(?:→|->)\s*([A-Za-z])\b")


def _eg_dirflip_hits(line):
    """Direction-flip hits on one line: a presents-clause whose presenter
    is the orientation's source and whose scan owner is the orientation's
    target ("X presents a port to Y's scan" under X->Y), with no
    orientation token on the line reading the clause as the defined
    direction. A presents-clause whose entities match no orientation
    token on its line is shape-consistent for its own orientation and
    stays human-audit territory."""
    out = []
    orients = [(m.group(1).upper(), m.group(2).upper())
               for m in EG_ORIENT_RE.finditer(line)]
    if not orients:
        return out
    for m in EG_PRESENTS_RE.finditer(line):
        p, s = m.group(1).upper(), m.group(2).upper()
        flip = any(p == o1 and s == o2 for (o1, o2) in orients)
        defined = any(p == o2 and s == o1 for (o1, o2) in orients)
        if flip and not defined:
            out.append(m)
    return out


def eg_dirflip_prose_violations(md_text):
    """All prose lines (outside code fences) carrying a direction-flip."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        for _ in _eg_dirflip_hits(line):
            bad.append(f"line {i} [direction-flip]: {line.strip()[:120]}")
            break
    return bad


def eg_relay_prose_violations(md_text):
    """All prose lines (outside code fences) containing the dropped
    token that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if EG_RELAY_RE.search(line):
            if not any(pat in line for pat, _ in EG_RELAY_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


# The "encounter geometry" term: spaced and hyphenated forms.
EG_TRIGGER_RE = re.compile(r"\bencounter[ -]geometry\b", re.IGNORECASE)
# The blocked d=1 "iff" shape: the term pinned to d = 1 exclusively via
# iff/if-and-only-if. The literal "=" keeps "d >= 1" (and "d≥1") from
# matching, and the definition's own "iff at least one of the following
# holds" has no "d = 1" after its iff, so it passes.
EG_IFF_D1_RE = re.compile(
    r"\bencounter[ -]geometry\b.{0,100}?\b(iff|if and only if)\b.{0,80}?\bd\s*=\s*1\b",
    re.IGNORECASE)
# The blocked d=1-exclusive shape without "iff": "encounter geometry is
# exactly d = 1". Tightened with is/means right after the term and a
# no-period window, so catalogue and machine-report rows never match.
EG_IS_D1_RE = re.compile(
    r"\bencounter[ -]geometry\b\s+(is|means)\b[^.\n]{0,50}?\bd\s*=\s*1\b",
    re.IGNORECASE)
# Primitive-treatment shapes: the defined term called a primitive or
# treated as one ("assumed"). A negation guard (not/no/never/n't/
# neither/nor) inside the matched span - or in the 40 characters before
# it, where a denial's negation typically sits - exempts the legitimate
# denials, e.g. the section 3.2 badge note "No new primitive is adopted".
EG_PRIMITIVE_RES = (
    re.compile(r"\bprimitive\b.{0,40}?\bencounter[ -]geometry\b", re.IGNORECASE),
    re.compile(r"\bencounter[ -]geometry\b.{0,40}?\bprimitive\b", re.IGNORECASE),
    re.compile(r"\bencounter[ -]geometry\b.{0,40}?\bis assumed\b", re.IGNORECASE),
    re.compile(r"\bassumed\b.{0,40}?\bencounter[ -]geometry\b", re.IGNORECASE),
)
EG_NEG_RE = re.compile(r"\b(not|no|never|n't|neither|nor)\b", re.IGNORECASE)


def _eg_banned_shapes(line):
    """Banned consistency shapes on one line: d=1-exclusive pinning and
    primitive treatment of the defined term. Returns hit descriptions."""
    hits = []
    if not EG_TRIGGER_RE.search(line):
        return hits
    if EG_IFF_D1_RE.search(line):
        hits.append("d=1-iff")
    if EG_IS_D1_RE.search(line):
        hits.append("d=1-exclusive")
    for rx in EG_PRIMITIVE_RES:
        m = rx.search(line)
        if m:
            window = line[max(0, m.start() - 40):m.end()]
            if not EG_NEG_RE.search(window):
                hits.append("primitive-treatment")
                break
    return hits


# EG_CONSISTENCY_JUSTIFICATIONS: prose pin list for the "encounter
# geometry" term. Every live prose occurrence is admitted
# content-specifically. Categories name the line's actual enclosing
# section (checked against the paper's headings, not the outline from
# memory). Each pin is a literal substring of its line; a stale pin
# (literal no longer present) fails the sweep by design.
EG_CONSISTENCY_JUSTIFICATIONS = [
    ("encounter geometry determines the outcome",
     "§0.5.x terminology firewall (the 'gradient' lock paragraph)"),
    ("encounter geometry (§3.2, L10-P11) plus a presented non-O boundary port",
     "§0.5.w Honest Primitive Inventory, item 13 (Engagement definition)"),
    ("**Definition (Encounter Geometry) [L10-P11].**",
     "§3.2: the definition heading itself"),
    ("*Undirected closure.* X and Y occupy encounter geometry",
     "§3.2: undirected closure of the definition"),
    ("*τ-abstraction note (reading gloss, Level B — not a third disjunct).*",
     "§3.2: τ-abstraction note heading inside the definition block"),
    ("the encounter-geometry conjunct of the §4.6 engagement definiens",
     "§3.2 badge note: hyphenated conjunct reference"),
    ("that side is fixed by the encounter geometry.",
     "§3.3 proof: encounter geometry as the disjunct-resolved side"),
    ("Given two configurations A and B in encounter geometry at tick t:",
     "§4.5 Role Assignment Protocol: encounter geometry as a precondition"),
    ("configurations A and B occupy encounter geometry, and A presents",
     "§4.6 Definition (Engagement): the term with the presents-clause"),
    ("The engagement definiens is relational: encounter geometry plus a presented non-O boundary port at a tick",
     "§4.6 proof: the definiens sentence"),
    ("the derived shell-profile value for the encounter geometry at hand",
     "§8.5: shell profile for the encounter geometry at hand"),
    ("presented by the surrounding medium in the encounter geometry",
     "§11.2 Definition (environment E): encounter geometry of the environment"),
    ("A and B in encounter geometry (§3.2, L10-P11) at tick τ",
     "Appendix E defined-token row: engagement"),
    ("| encounter geometry | X, Y occupy encounter geometry at tick τ (X→Y)",
     "Appendix E defined-token row: encounter geometry"),
    ("engagement (proximity encounter geometry at a tick) does not entail alteration (junction completion or occlusion)",
     "ENGAGEMENT_ALTERATION_SEPARATION claim-impact sentence: the Appendix E "
     "registry row, the Appendix H falsification statement, and the Appendix J "
     "theorem-map row"),
    ("42. **ENGAGEMENT_ALTERATION_SEPARATION** — engagement (proximity encounter geometry at a tick)",
     "Appendix H audit rules: ENGAGEMENT_ALTERATION_SEPARATION falsification statement"),
    ("encounter geometry selects attraction, repulsion, or forced decay by exact port-value complementarity",
     "changelog item 43 (Correction by excision)"),
    ("Engagement [L8-P11] is the tick-indexed predicate E(A→B, τ): encounter geometry plus a presented non-O boundary port",
     "changelog item 77 (v31)"),
    ("| ENCOUNTER_GEOMETRY_DEFINITION | A | definition |",
     "Appendix E.2 registry row: ENCOUNTER_GEOMETRY_DEFINITION"),
    ("52. **ENCOUNTER_GEOMETRY_DEFINITION** — encounter geometry is the disjunctive genus",
     "Appendix H claim-impact statement: ENCOUNTER_GEOMETRY_DEFINITION"),
    ("the encounter-geometry conjunct computed from the native Definition (Encounter Geometry) [L10-P11]",
     "§4.6 machine-check paragraph: the genus-based witness (F.47 description)"),
    ("and 'encounter geometry' usage consistency (every prose occurrence avoids d=1-exclusive pinning",
     "§14.x F.42 description: group-19 consistency sweep"),
    ("114. **V5 remediation — encounter-geometry definition",
     "changelog item 114 (V5): remediation record"),
    ("115. **V6 remediation — proof↔registry direction defects",
     "changelog item 115 (V6): remediation record"),
    ("the encounter geometry, which is re-evaluated every tick",
     "changelog item 123 (v56): quotes the retired §3.3 bridge sentence "
     "being repaired"),
    ("| ENCOUNTER_GEOMETRY_DEFINITION | A | §3.2 | §3.2 | prose (§3.2)",
     "Appendix J theorem-map row: ENCOUNTER_GEOMETRY_DEFINITION"),
]


def eg_consistency_prose_violations(md_text):
    """All prose lines (outside code fences) carrying the term that (a)
    match a blocked shape (d=1-exclusive pinning, primitive treatment),
    or (b) match no curated justification pin. Blocked shapes are
    checked first, so a pin never launders a defect in another clause."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if not EG_TRIGGER_RE.search(line):
            continue
        shapes = _eg_banned_shapes(line)
        if shapes:
            bad.append(f"line {i} [{','.join(shapes)}]: {line.strip()[:120]}")
            continue
        if not any(pat in line for pat, _ in EG_CONSISTENCY_JUSTIFICATIONS):
            bad.append(f"line {i} [unpinned]: {line.strip()[:120]}")
    return bad


def eg_script_violations():
    """Script-side encounter-geometry violations: the dropped token, the
    direction-flip shape, or a blocked consistency shape on a line
    carrying the term, in any F-script. This script (F42) is fully
    exempt: the particle/seqattr model - the docstring item 19, the
    INPUT_PROVENANCE notes, the MACHINERY block, and the planted
    mutants all name the swept tokens."""
    bad = []
    for p in sorted(HERE.glob("F*.py")):
        if p.name == "F42_stageN_firewall.py":
            continue
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            hits = []
            if EG_RELAY_RE.search(sl):
                hits.append("relay-position")
            if _eg_dirflip_hits(sl):
                hits.append("direction-flip")
            shapes = _eg_banned_shapes(sl)
            if shapes:
                hits.append("consistency:" + ",".join(shapes))
            if hits:
                bad.append(f"{p.name}:{j} [{';'.join(hits)}]: {sl.strip()[:100]}")
    return bad


def check_encounter_geometry_sweep():
    """Encounter-geometry sweep (group 19): the dropped "relay position"
    token occurs nowhere in prose; no direction-flip ("X presents a port
    to Y's scan" under X->Y) occurs in prose or script sources; every
    prose "encounter geometry" occurrence avoids the blocked shapes and
    matches a curated justification pin (no stale pins); script sources
    are clean except this script's own marked sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = eg_relay_prose_violations(md)
    assert not bad, "dropped 'relay position' token in prose:\n" + "\n".join(bad)
    bad = eg_dirflip_prose_violations(md)
    assert not bad, "direction-flip in prose:\n" + "\n".join(bad)
    bad = eg_consistency_prose_violations(md)
    assert not bad, "unjustified 'encounter geometry' in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md) if l and EG_TRIGGER_RE.search(l)]
    matched = {pat for pat, _ in EG_CONSISTENCY_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in EG_CONSISTENCY_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale encounter-geometry justifications: {stale}"
    sbad = eg_script_violations()
    assert not sbad, "encounter-geometry sweep trigger in script source:\n" + "\n".join(sbad)


# MACHINERY-END: encounter-geometry sweep (group 19).

# MACHINERY-START: boundary sweep (v9). The banned
# tokens inside this block are the sweep's own patterns, never paper content.
BOUNDARY_BANNED_RE = re.compile(
    r"boundary creation|membrane|container|cutoff surface|horizon|"
    r"edge of the medium|boundary is a positive|boundary as a positive|"
    r"boundary substance|boundary is an entity|positive boundary object|"
    r"the boundary acts|boundary exerts", re.IGNORECASE)
# Every prose occurrence of a boundary-as-object token must match one
# justification. Patterns are content-specific (v7/v8 convention).
BOUNDARY_JUSTIFICATIONS = [
    ("Boundary Non-Substance Rule",
     "4.3 rule: states the ban; names the excised v1 entry"),
    ("banned boundary-substance tokens",
     "14.4 registry: F.42 description cites the sweep"),
    ("\"boundary creation\"",
     "ban-statement sites: changelog + 4.3 rule + registry description"),
    ("phantom-verb",
     "changelog: v9 excision history"),
    ("No membrane/horizon/container/cutoff",
     "changelog: v9 excision history"),
    ("R19 phrase patterns",
     "14.4 registry: F.42 description cites the v14 phrase extension"),
    ("boundary-as-object example",
     "changelog: v14 R19 remediation history"),
]


def boundary_prose_violations(md_text):
    """All prose lines (outside code fences) containing a
    boundary-as-object token that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if BOUNDARY_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in BOUNDARY_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_boundary_sweep():
    """Boundary-object sweep: 'boundary creation' and boundary-substance tokens
    must not occur in native prose or in any script source except this
    script's own marked sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = boundary_prose_violations(md)
    assert not bad, \
        "unjustified boundary-as-object token in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and BOUNDARY_BANNED_RE.search(l)]
    matched = {pat for pat, _ in BOUNDARY_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in BOUNDARY_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale boundary justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not BOUNDARY_BANNED_RE.search(sl):
                continue
            # Marked sweep machinery is exempt in every script source, not
            # just this file's own: F.38's R19 phrase list and planted
            # test case live between MACHINERY markers (v14).
            if in_machinery:
                continue
            if p.name == "F42_stageN_firewall.py" and "MACHINERY-OK" in sl:
                continue
            assert False, \
                f"{p.name}:{j} unjustified boundary token in script source"
# MACHINERY-END


# MACHINERY-START: register-token sweep (paper v10). The banned
# tokens inside this block are the sweep's own patterns, never paper content.
REGISTER_BANNED_RE = re.compile(r"\bStage R\b|\bRegister R\b")
# Every prose occurrence of an R register token must match one justification.
REGISTER_JUSTIFICATIONS = [
    ("Stage Label Reconciliation Note",
     "0.5.aa note: declares the deprecated alias"),
    ("deprecated alias",
     "note + R17 + changelog: the R normalization statement"),
    ("Register-token integrity",
     "14.3 R17 + registry description: cites the sweep"),
    ("register-token reconciliation",
     "registry description + changelog: paper v10 history"),
    ("Paper 10 §0.5.aa",
     "note + changelog: the drift attribution"),
    ("canonical register labels",
     "changelog: paper v10 follow-through"),
]


def register_prose_violations(md_text):
    """All prose lines (outside code fences) containing an R register token
    that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if REGISTER_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in REGISTER_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_register_sweep():
    """Register-token sweep: R register tokens must not occur in native prose or
    in any script source except this script's own marked machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = register_prose_violations(md)
    assert not bad, \
        "unjustified R register token in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and REGISTER_BANNED_RE.search(l)]
    matched = {pat for pat, _ in REGISTER_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in REGISTER_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale register justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not REGISTER_BANNED_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    in_machinery or "MACHINERY-OK" in sl):
                continue
            assert False, \
                f"{p.name}:{j} unjustified R register token in script source"
# MACHINERY-END



# MACHINERY-START: void-token sweep. The banned
# tokens inside this block are the sweep's own patterns, never paper content.
VOID_TOKEN_RE = re.compile(r"isolat\w*|\bvicinity\b", re.IGNORECASE)
# Every prose occurrence of a void-token token must match one justification:
# the §0.5 design constraint (module self-containment), the registry
# description, the changelog.
VOID_TOKEN_JUSTIFICATIONS = [
    ("intentionally isolated",
     "0.5 design constraint: module self-containment"),
    ("admitted only in the §0.5 design constraint",
     "registry description: cites the sweep"),
    ("planted-sentence rejection",
     "changelog: sweep mention"),
]


def void_token_prose_violations(md_text):
    """All prose lines (outside code fences) containing a void-token token
    ('isolat*', 'vicinity') that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if VOID_TOKEN_RE.search(line):
            if not any(pat in line for pat, _ in VOID_TOKEN_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_void_token_sweep():
    """Void-token sweep: 'isolat*' and 'vicinity' must not occur in native
    prose or in any script source except this script's own marked machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = void_token_prose_violations(md)
    assert not bad, \
        "unjustified void-token token in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and VOID_TOKEN_RE.search(l)]
    matched = {pat for pat, _ in VOID_TOKEN_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in VOID_TOKEN_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale void-token justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not VOID_TOKEN_RE.search(sl):
                continue
            if in_machinery:
                continue
            if p.name == "F42_stageN_firewall.py" and "MACHINERY-OK" in sl:
                continue
            assert False, \
                f"{p.name}:{j} unjustified void-token token in script source"
# MACHINERY-END

# MACHINERY-START: kinematics sweep (v12). The banned
# tokens inside this block are the sweep's own patterns, never paper content.
KINEMATICS_BANNED_RE = re.compile(
    r"\bacceleration\b|\bvelocity\b|\bdeceleration\b", re.IGNORECASE)
# Every prose occurrence of a differential-kinematics token must match one
# justification: the §0.5.x lock, the registry description, the changelog.
KINEMATICS_JUSTIFICATIONS = [
    ("Terminology lock on differential kinematics",
     "0.5.x lock: states the ban"),
    ("kinematics terminology lock",
     "registry description + changelog: v12 history"),
    ("Differential-kinematics terminology lock",
     "changelog: v12 history"),
]


def kinematics_prose_violations(md_text):
    """All prose lines (outside code fences) containing a
    differential-kinematics token that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if KINEMATICS_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in KINEMATICS_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_kinematics_sweep():
    """Kinematics sweep: differential-kinematics tokens must not occur in
    native prose or in any script source except this script's own marked
    machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = kinematics_prose_violations(md)
    assert not bad, \
        "unjustified differential-kinematics token in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and KINEMATICS_BANNED_RE.search(l)]
    matched = {pat for pat, _ in KINEMATICS_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in KINEMATICS_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale kinematics justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not KINEMATICS_BANNED_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    in_machinery or "MACHINERY-OK" in sl):
                continue
            assert False, \
                f"{p.name}:{j} unjustified differential-kinematics token in script source"
# MACHINERY-END


# MACHINERY-START: thermo sweep (v13). The banned
# tokens inside this block are the sweep's own patterns, never paper content.
THERMO_BANNED_RE = re.compile(
    r"\btemperature\b|\bentrop(y|ies)\b|\bGibbs\b|\bBoltzmann\b|\bk_B\b|"
    r"\bensemble\b|\bmicrostates?\b|\bmacrostates?\b|\bthermal equilibrium\b|"
    r"\bprobability distribution\b", re.IGNORECASE)
# Every prose occurrence of a thermodynamic token must match one
# justification: the §0.5.x lock, the Paper-12 firewall/deferral sections,
# the registry description, the changelog.
THERMO_JUSTIFICATIONS = [
    ("Terminology lock on thermodynamic vocabulary",
     "0.5.x lock: states the ban"),
    ("Paper 12",
     "deferral + firewall: Paper-12 territory"),
    ("Design Constraint",
     "0.5 Design Constraint: module isolation"),
    ("No thermodynamic quantities",
     "14.2 firewall: Paper 11 introduces none"),
    ("thermo terminology lock",
     "registry description + changelog: v13 history"),
]


def thermo_prose_violations(md_text):
    """All prose lines (outside code fences) containing a thermodynamic
    token that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if THERMO_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in THERMO_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_thermo_sweep():
    """Thermo sweep: thermodynamic tokens must not occur in native
    prose or in any script source except this script's own marked
    machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = thermo_prose_violations(md)
    assert not bad, \
        "unjustified thermodynamic token in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and THERMO_BANNED_RE.search(l)]
    matched = {pat for pat, _ in THERMO_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in THERMO_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale thermo justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not THERMO_BANNED_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    in_machinery or "MACHINERY-OK" in sl):
                continue
            assert False, \
                f"{p.name}:{j} unjustified thermodynamic token in script source"
# MACHINERY-END

# MACHINERY-START: teleology sweep (v15). The banned
# phrases inside this block are the sweep's own patterns, never paper content.
# Red-team 2026-10-04: "serves to"/"exists to"/"in an effort to" excluded as
# too common in non-teleological prose (false positive in changelog #115).
TELEO_BANNED_RE = re.compile(
    r"\bmore work\b|\bamount of resolution\b|\bwork performed\b|"
    r"\bdegree of resolution\b|\bstrives\b|\btends toward\b|"
    r"\bdesigned to\b|\bintended to\b|\bin order to\b|"
    r"\bbuilt to\b|\bmade to\b|\bcrafted to\b|\bengineered to\b|"
    r"\bwith the purpose of\b|\bwith the goal of\b|"
    r"\baims to\b|\bseeks to\b",
    re.IGNORECASE)
# Every prose occurrence of a scalar/teleological phrase must match one
# justification: the §12 Canonical-Ordering Firewall, the changelog.
TELEO_JUSTIFICATIONS = [
    ("Canonical-Ordering Firewall",
     "§12 firewall: states the ban"),
]


def teleo_prose_violations(md_text):
    """All prose lines (outside code fences) containing a scalar or
    teleological phrase that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if TELEO_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in TELEO_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_teleo_sweep():
    """Teleology sweep: scalar/teleological phrases about the ordering key
    must not occur in native prose or in any script source except this
    script's own marked machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = teleo_prose_violations(md)
    assert not bad, \
        "unjustified teleological phrase in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and TELEO_BANNED_RE.search(l)]
    matched = {pat for pat, _ in TELEO_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in TELEO_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale teleo justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not TELEO_BANNED_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    in_machinery or "MACHINERY-OK" in sl):
                continue
            assert False, \
                f"{p.name}:{j} unjustified teleological phrase in script source"
# MACHINERY-END


# MACHINERY-START: arity sweep (v16). The banned
# patterns inside this block are the sweep's own machinery, never paper content.
ARITY_BANNED_RE = re.compile(r"6N\s*[−-]\s*2J|between two ports", re.IGNORECASE)
# Every prose occurrence of a binary-junction assumption must match one
# justification: the §4.3 pairwise corollary, the registry descriptions,
# the changelog (pre-v16 occurrences are dated historical records, not
# live claims).
ARITY_JUSTIFICATIONS = [
    ("pairwise corollary",
     "§4.3 corollary + §4.1 quantity list + registry descriptions + v16 changelog"),
    ("v1 proof of",
     "changelog: v1 §4.3 repair history"),
    ("§4.3 corollary",
     "changelog: v1 six-ports clarification"),
    ("exact allowed quantities",
     "changelog: v2 aggregate-definition tightening"),
    ("Defect located",
     "changelog: v9 boundary-creation defect"),
    ("Rejected alternatives",
     "changelog: v9 prescription review"),
    ("Boundary object-positing language",
     "changelog: v14 boundary-count history"),
    ("Junction arity corrected (v16)",
     "changelog: v16 junction-arity correction"),
]


def arity_prose_violations(md_text):
    """All prose lines (outside code fences) containing an unqualified
    binary-junction assumption that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if ARITY_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in ARITY_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_arity_sweep():
    """Arity sweep: the pairwise formula and 'between two ports'
    must not occur in native prose or in any script source except where
    justified (the §4.3 pairwise corollary, registry descriptions, the
    changelog) or inside this script's own marked sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = arity_prose_violations(md)
    assert not bad, \
        "unjustified binary-junction assumption in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and ARITY_BANNED_RE.search(l)]
    matched = {pat for pat, _ in ARITY_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in ARITY_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale arity justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not ARITY_BANNED_RE.search(sl):
                continue
            if in_machinery:
                continue
            # Descriptive mentions of the sweep itself are exempt in every
            # script source (cf. the gradient sweep's F.42 allowlist, here
            # extended: F.38's v14 changelog docstring is a dated record).
            if re.search(r"arity sweep|pairwise corollary|admitted only|"
                         r"planted|MACHINERY|changelog|firewall", sl, re.I):
                continue
            assert False, \
                f"{p.name}:{j} unjustified binary-junction assumption in script source"
# MACHINERY-END


# MACHINERY-START: magnitude bridge-word sweep. The banned
# phrase inside this block is the sweep's own pattern, never paper content.
#
# Script disclosure (verification-rigor staple: native domain, verified
# domain, map, what the map preserves, what stays outside the machine
# check):
#   Native domain: the paper's native Stage N prose claim that the phrase
#     "interaction magnitude" names no native quantity. The native quantity
#     is e.S(d) (exact rational), called the engagement-weighted scan
#     allocation; the phrase "interaction magnitude" is reserved for the
#     Stage P reconstruction layer, where the Reconstruction Rule would
#     convert the native allocation into a physical quantity - a
#     reconstruction this paper never performs.
#   Verified domain: (a) every occurrence of the phrase "interaction
#     magnitude" in the paper's prose outside fenced code blocks;
#     (b) every prose occurrence of the renamed term "engagement-weighted
#     scan allocation".
#   Map: token identity - each bridge-word occurrence is checked against
#     the curated justification list; each renamed-term occurrence is
#     checked against the paper's single definition line.
#   Preserved: that exactly one definition line binds the renamed term to
#     e.S(d) = e.s^2/(4d^2+2), and that no other binding of the term
#     exists anywhere in native prose.
#   Outside the machine check: semantic intent - the sweep proves token
#     discipline, not that a future reader will not re-bridge silently;
#     Paper 10's N(d) stays an inherited prose premise, not machine-derived;
#     the engagement-count profile (the old P2) is machine-derived by the
#     retargeted F.45 shell-profile check, not inherited. The Level A badge for this
#     sweep covers terminology consistency plus the F.45 scaling algebra
#     only - it does not certify the physics of any Stage P reconstruction.
BRIDGE_MAGNITUDE_RE = re.compile(r"interaction magnitude", re.IGNORECASE)
# Every prose occurrence of the bridge word must match one justification:
# the §8.5 bridge-reservation sentence, this sweep's description,
# the Appendix I changelog entry documenting the remediation.
BRIDGE_MAGNITUDE_JUSTIFICATIONS = [
    ("interaction magnitude' is reserved",
     "8.5 bridge-reservation sentence: declares the Stage P reservation"),
    ("magnitude bridge-word sweep",
     "F.42 description: cites the sweep"),
    ("interaction magnitude\" bridge-word remediation",
     "Appendix I entry 75: documents the bridge-word remediation in history"),
    ("swept only the single word \"interaction magnitude\"",
     "Appendix I entry 129: documents the V13 word-specific sweep gap in history"),
]

ESD_TERM = "engagement-weighted scan allocation"
ESD_DEFINITION_LINE = ("The engagement-weighted scan allocation is therefore "
                       "e·S(d) = e·s²/(4d² + 2).")


def bridge_magnitude_prose_violations(md_text):
    """All prose lines (outside code fences) containing the Stage P-reserved
    bridge word that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if BRIDGE_MAGNITUDE_RE.search(line):
            if not any(pat in line
                       for pat, _ in BRIDGE_MAGNITUDE_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_bridge_magnitude_sweep():
    """Magnitude bridge-word sweep: the Stage P-reserved bridge word must not
    occur in native prose outside the §8.5 bridge-reservation sentence,
    this sweep's description, and the changelog; script sources must be
    clean except this script's own marked sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = bridge_magnitude_prose_violations(md)
    assert not bad, \
        "unjustified bridge word in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and BRIDGE_MAGNITUDE_RE.search(l)]
    matched = {pat for pat, _ in BRIDGE_MAGNITUDE_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in BRIDGE_MAGNITUDE_JUSTIFICATIONS
             if pat not in matched]
    assert not stale, f"stale bridge-word justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not BRIDGE_MAGNITUDE_RE.search(sl):
                continue
            if in_machinery:
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    "MACHINERY-OK" in sl
                    or re.search(r"bridge-word|magnitude sweep|planted|firewall",
                                 sl, re.I)):
                continue
            assert False, \
                f"{p.name}:{j} unjustified bridge word in script source"


def check_esd_term_consistency():
    """Every native use of the renamed term resolves to e·S(d): exactly one
    definition line binds it in prose; every other occurrence either names
    e·S(d) on the same line or sits in §8.5, the section where the term is
    defined and used."""
    lines = strip_code_fences(PAPER.read_text(encoding="utf-8"))
    cur = None
    defn_idx = None
    uses = []
    for i, line in enumerate(lines, 1):
        if line is None:
            continue
        m = re.match(r"#{2,4}\s+(§[\d.]+)", line)
        if m:
            cur = m.group(1)
        if ESD_DEFINITION_LINE in line:
            assert defn_idx is None, \
                "duplicate definition lines for the renamed term"
            defn_idx = i
        elif ESD_TERM in line:
            uses.append((i, cur, line))
    assert defn_idx is not None, \
        "definition line for the renamed term missing from prose"
    for (i, sec, line) in uses:
        ok = ("e·S(d)" in line) or (sec == "§8.5")
        assert ok, (f"renamed-term use not resolving to e·S(d): "
                    f"line {i} [{sec}]: {line.strip()[:130]}")
# MACHINERY-END


# MACHINERY-START: label-terminology sweep. The banned
# phrases inside this block are the sweep's own patterns, never paper content.
#
# Script disclosure (verification-rigor staple: native domain, verified
# domain, map, what the map preserves, what stays outside the machine
# check):
#   Native domain: the paper's architectural claim that Paper 11 adopts no
#     new primitives and no new axioms - L5-P11 is a derived theorem
#     (section 3.1); L6-P11, L7-P11, L8-P11, L9-P11 are definitions; the
#     honest umbrella term is "Paper-11 dependency labels" (section
#     0.5.aa.1 dependency-label terminology lock).
#   Verified domain: (a) every prose occurrence (outside fenced code
#     blocks) of the mislabeling phrases "dependency axiom(s)" and the
#     stale v2 root "role primitive(s)"; (b) every occurrence of those
#     phrases in any F*.py script source.
#   Map: token identity - each occurrence is checked against the curated
#     justification list (prose) or the marked-machinery exemption
#     (script sources).
#   Preserved: that no live prose sentence and no script derivation calls
#     a Paper-11 label an axiom or invokes the stale root phrase outside
#     the documented remediation history.
#   Outside the machine check: semantic intent - the sweep proves token
#     discipline, not that a future reader grasps the taxonomy; the
#     theorem/definition classification itself stays a prose-plus-registry
#     premise (F.38/F.39), not something this sweep derives. The badge for
#     this sweep covers terminology consistency only.
LABEL_BANNED_RE = re.compile(r"dependency axiom|role primitive", re.IGNORECASE)
# Every prose occurrence of a label-terminology violation must match one
# justification: the changelog entry documenting the remediation history.
# (The section 0.5.aa.1 lock entry itself carries no banned token and needs
# no justification; the D.3 rewrite uses the honest taxonomy throughout.)
LABEL_JUSTIFICATIONS = [
    ("label-terminology pattern group",
     "changelog entry 87: documents the F.42 extension"),
    ("no-new-axiom architecture",
     "changelog entry 87: states the architecture the excised phrases contradicted"),
    ("label-terminology sweep",
     "F.42 script description: names the sweep and its admitted locations"),
]


def label_prose_violations(md_text):
    """All prose lines (outside code fences) containing a label-terminology
    violation - "dependency axiom(s)" applied to Paper-11 labels, or the
    stale v2 "role primitive(s)" root - that match no curated justification."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if LABEL_BANNED_RE.search(line):
            if not any(pat in line for pat, _ in LABEL_JUSTIFICATIONS):
                bad.append(f"line {i}: {line.strip()[:120]}")
    return bad


def check_label_sweep():
    """Label-terminology sweep: "dependency axiom(s)" and "role
    primitive(s)" must not occur in native prose or in any script source
    except where justified (the changelog remediation-history entry) or
    inside this script's own marked sweep machinery."""
    md = PAPER.read_text(encoding="utf-8")
    bad = label_prose_violations(md)
    assert not bad, \
        "unjustified label-terminology violation in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and LABEL_BANNED_RE.search(l)]
    matched = {pat for pat, _ in LABEL_JUSTIFICATIONS
               if any(pat in l for l in hit_lines)}
    stale = [pat for pat, _ in LABEL_JUSTIFICATIONS if pat not in matched]
    assert not stale, f"stale label justifications: {stale}"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not LABEL_BANNED_RE.search(sl):
                continue
            if in_machinery:
                continue
            if p.name == "F42_stageN_firewall.py" and "MACHINERY-OK" in sl:
                continue
            assert False, \
                f"{p.name}:{j} unjustified label-terminology token in script source"
# MACHINERY-END


# MACHINERY-START: modal-collapse sweep (group 15). Role-capability vs
# role-actuality: bare role-actuality assertions are swept across the
# paper's prose (outside code fences) and all script sources. The
# patterns, justification list, and fixtures below are the sweep's own
# machinery, never paper content.
#
# Patterns (unit: one physical line outside fenced code; X = hyphen-guarded
# active/passive; the hyphen guards keep "active-capable"/"passive-capable"
# from matching):
#   P1:  play-verb "plays/play|takes/took|assumes/assumed the X role".
#   P1b: gerund "playing the X role".
#   P1p: passive voice "the X role is (being) played".
#   P1part: participial "(having) played the X role".
#   P2:  copula "is/are/was/were [(more|less|most)] [adverb] (the) X" -
#        the adverb slot takes the curated _MODAL_ADVERB list only.
#   P3adj: "X interior|boundary|center|centre|aspect".
#   P3par: "(X at the center|centre|boundary|interior)", plain and
#        participial "(having been X at the ...)".
#   P3x: extended adjectival "X junction|node|port|configuration|state|
#        aggregate|selector(s)" - "role" itself is not in the noun list.
#   P4:  copula-free "stay(s)|remain(s)|become(s)|becoming (the) X".
#   P5:  contrastive "not (the) X (role)? ,? but (the) Y".
# Exemptions (applied in this order):
#   modal: "can/could" immediately before a P1/P1b match only - the paper's
#       sanctioned capability forms are "can/could play the * role";
#       "can stay active" is not sanctioned and stays flagged.
#   negation: a negation scoping the match within its clause - except P5,
#       whose "not" is part of the defect shape, never an exemption.
#   index: encounter-index tokens ("encounter R", "in R", R_1/R_2, R
#       followed by digits, subscript R forms) anywhere in the line - a
#       bare "encounter" with no R is NOT a token - but verb-sensitive:
#       the index exemption covers P1/P1b/P1p/P1part/P2/P3adj/P3par/P3x,
#       never P4 or P5 (stays/remains/becomes and contrastive not-but
#       forms are never sanctioned actuality verbs). Temporal clauses
#       ("when"), deictic tokens ("here"/"there"), and bare "at tick" are
#       NOT index tokens: a bare assertion under them is flagged.
#   pins: justification pins are span-scoped - a pin admits a trigger
#       only if the pin's literal string covers the trigger's matched
#       span, so a pin never launders a defect in another clause. Every
#       pin is probed with a genuine defect wearing that pin.
# Human-audit territory (stated honestly in the badge): indexed-but-
# modally-unearned sentences; adjectival nouns outside the covered lists;
# quoted counter-examples beyond the admitted list; cross-sentence
# anaphora (coreference is out of scope by design); adverbs outside the
# curated list; the modal guard's P1/P1b-only scope; index-token
# line-sharing (the tightened index token still exempts line-wide).
# The patterns are case-insensitive: a defect does not become legitimate
# by starting the sentence.
_ROLE_WORD = r"(?<!-)(active|passive)(?!-)"
_ROLE_NOUN = r"(junction|node|port|configuration|state|aggregate|selector)"
# Curated adverb inventory for adverb-interrupted copulas (P2): an adverb
# outside this list stays human-audit territory.
_MODAL_ADVERB = (r"(?:always|still|already|now|then|again|once|even|just|"
                 r"merely|simply|fully|intrinsically)")
_MODAL_P1 = re.compile(r"\b(plays?|takes?|took|assumes?|assumed)\s+the\s+"
                       + _ROLE_WORD + r"\s+role\b",
                       re.IGNORECASE)
_MODAL_P1B = re.compile(r"\bplaying\s+the\s+" + _ROLE_WORD + r"\s+role\b",
                        re.IGNORECASE)
_MODAL_P1P = re.compile(r"\bthe\s+" + _ROLE_WORD + r"\s+role\s+is\s+"
                        r"(being\s+)?played\b", re.IGNORECASE)
_MODAL_P1PART = re.compile(r"\b(having\s+)?played\s+the\s+"
                           + _ROLE_WORD + r"\s+role\b", re.IGNORECASE)
_MODAL_P2 = re.compile(r"\b(is|are|was|were)\s+((more|less|most)\s+)?"
                       r"(" + _MODAL_ADVERB + r"\s+)?(the\s+)?"
                       + _ROLE_WORD + r"\b",
                       re.IGNORECASE)
_MODAL_P3ADJ = re.compile(
    r"\b" + _ROLE_WORD + r"\s+(interior|boundary|center|centre|aspect)\b",
    re.IGNORECASE)
_MODAL_P3PAR = re.compile(
    r"\(\s*(having\s+been\s+)?" + _ROLE_WORD
    + r"\s+at\s+the\s+(center|centre|boundary|interior)\)",
    re.IGNORECASE)
_MODAL_P3X = re.compile(
    r"\b" + _ROLE_WORD + r"\s+" + _ROLE_NOUN + r"s?\b", re.IGNORECASE)
_MODAL_P4 = re.compile(
    r"\b(stays?|remains?|becomes?|becoming)\s+(the\s+)?"
    + _ROLE_WORD + r"\b", re.IGNORECASE)
_MODAL_P5 = re.compile(
    r"\bnot\s+(the\s+)?" + _ROLE_WORD + r"(\s+role)?\s*,?\s*but\s+(the\s+)?"
    + _ROLE_WORD + r"\b", re.IGNORECASE)
_MODAL_PATTERNS = (("P1", _MODAL_P1), ("P1b", _MODAL_P1B),
                   ("P1p", _MODAL_P1P), ("P1part", _MODAL_P1PART),
                   ("P2", _MODAL_P2),
                   ("P3adj", _MODAL_P3ADJ), ("P3par", _MODAL_P3PAR),
                   ("P3x", _MODAL_P3X), ("P4", _MODAL_P4),
                   ("P5", _MODAL_P5))
_MODAL_BEFORE = re.compile(r"\b(can|could)\s*$", re.IGNORECASE)
_MODAL_INDEX = re.compile(
    r"\bencounter\s+R\b|\bin\s+r\b|R_\d+|R[₁₂]|R\d+", re.IGNORECASE)
_MODAL_NEG = re.compile(r"\b(not|never|no|n't|neither|nor)\b", re.IGNORECASE)
_MODAL_CLAUSE = re.compile(r"[,;:—–()\-]")
# The encounter-index exemption covers the play/being/adjectival pattern
# families only - P4 (copula-free) and P5 (contrastive) are never
# sanctioned actuality verbs. The P1p/P1part passive and participial
# play-verb forms are index-exempt like P1/P1b: an encounter-indexed
# "played the active role in R" is indexed actuality either way.
_INDEX_EXEMPT_PATTERNS = frozenset(
    {"P1", "P1b", "P1p", "P1part", "P2", "P3adj", "P3par", "P3x"})

MODAL_JUSTIFICATIONS = [
    # (exact string, why it is legitimate)
    ("electrons are active, photons are passive",
     "§3.1 forbidden list: quoted entity-essentialist counter-examples, "
     "the exact defect pattern the theorem rejects"),
    ("aspect a plays the active role",
     "§4.2 Definition (Active Role): the operational definition stating "
     "the rule, encounter-indexed in the definiens"),
    ("The active role attaches to the aspect performing the mechanical "
     "shove toward alignment; the passive role attaches to the aspect "
     "serving as the alignment reference. Where both aspects are "
     "unresolved, both are active and the passive role is unoccupied",
     "§4.5 step 4: the protocol's actuality marker ('attaches to'); the "
     "'both are active' gloss is the protocol's both-unresolved case, "
     "warranted by the attaches-to sentence - the pin covers the gloss "
     "clause verbatim, never the line"),
    # Belt and suspenders: the two corollary sentences below are already
    # exempt (negation guard / index tokens); they are listed so the sweep
    # pins them verbatim against future rewording.
    ("Passive-capability is not the passive role.",
     "§3.1 corollary: negated thesis (already exempt via the negation guard)"),
    ("The separation holds in its strongest form: the same selector W that "
     "is passive in R₂ at τ₂ was active in R₁ at τ₁ — the F.39 relationality "
     "witness proves actual opposite roles in named encounters.",
     "§3.1 corollary: encounter-indexed actuality "
     "(already exempt via the index tokens)"),
    ("playing the passive role wholesale",
     "§4.3 B=0 edge case: the fully closed aggregate named as a "
     "counterfactual (dynamical realizability deferred to Paper 16) - the "
     "gerund describes the counterfactual's role pattern, not a live role "
     "assignment"),
    ("was active in one encounter",
     "§3.1: the relational theorem's own encounter-indexed actuality - "
     "'in one encounter' / 'in the next' index the roles to encounters; "
     "past-tense actuality, not an intrinsic assignment"),
    ("configurations of type T are always active/passive",
     "§3.1 forbidden list: quoted defect-pattern schema (the "
     "universal-quantifier form the theorem rejects)"),
    ("an aspect is active in an encounter iff it presents unmatched integers "
     "(u > 0), passive iff it serves as the resolved reference",
     "Abstract: the operational definition of the active/passive labels "
     "the sweep restates - definitional, not an actuality upgrade"),
    ("a test particle is passive by definition",
     "§3 'why not a tautology': reportage of standard physics' intrinsic "
     "assignment as the foil - the rival view stated, not the paper's "
     "assertion"),
]


def _modal_raw_triggers(line):
    """All (pattern-name, match) pairs firing on a physical line."""
    out = []
    for name, rx in _MODAL_PATTERNS:
        for m in rx.finditer(line):
            out.append((name, m))
    return out


def _modal_exempt_in(text, name, mstart):
    """Exemption for one trigger at mstart within text: modal, negation,
    or encounter-index. Returns the exemption kind or None."""
    before = text[:mstart]
    if name in ("P1", "P1b") and _MODAL_BEFORE.search(before):
        return "modal"
    if name != "P5":
        # P5's "not" is part of the defect shape, never an exemption.
        clause = _MODAL_CLAUSE.split(before)[-1]
        if _MODAL_NEG.search(clause):
            return "negation"
    if name in _INDEX_EXEMPT_PATTERNS and _MODAL_INDEX.search(text):
        return "index"
    return None


def _modal_pin_admits(line, mstart, mend):
    """Span-scoped pin admission: a justification pin admits a trigger only
    if the pin's literal string covers the trigger's matched span. A pin
    never launders a defect sitting in another clause of the same line."""
    for jstr, _ in MODAL_JUSTIFICATIONS:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def modal_collapse_prose_violations(md_text):
    """All prose lines (outside code fences) with an unexempt, unjustified
    modal-collapse trigger. One physical line is the unit; each trigger is
    admitted individually (modal / negation / index exemption, or a
    span-covering justification pin)."""
    bad = []
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        for name, m in _modal_raw_triggers(line):
            if _modal_exempt_in(line, name, m.start()):
                continue
            if _modal_pin_admits(line, m.start(), m.end()):
                continue
            bad.append(f"line {i} [{name}]: {line.strip()[:120]}")
    return bad


_MODAL_MACHINE_MSG = re.compile(
    r"assert|chk\s*\(|print\s*\(|raise\b|poisoned|must be|must play|"
    r"per section|surrogate|witness|PASS|FAIL|MACHINERY|\bR\d{2}\b|"
    r"collapse|detector", re.IGNORECASE)


def modal_collapse_script_violations():
    """Modal-collapse triggers in script sources. Exempt: this sweep's own
    marked machinery, F.42's MACHINERY-OK lines, and the machine-message
    class (assert/print/chk messages, planted-test invocations, and
    rule-description lines quoting defect patterns). Because registry
    claim texts can span source lines, the modal/negation/index
    exemptions are evaluated over the line plus its two predecessors."""
    bad = []
    for script in sorted(HERE.glob("F*.py")):
        lines = script.read_text(encoding="utf-8").splitlines()
        in_machinery = False
        for j, line in enumerate(lines, 1):
            if "MACHINERY-START" in line:
                in_machinery = True
                continue
            if "MACHINERY-END" in line:
                in_machinery = False
                continue
            if in_machinery:
                continue
            if script.name == "F42_stageN_firewall.py" and "MACHINERY-OK" in line:
                continue
            if not _modal_raw_triggers(line):
                continue
            start = max(0, j - 3)
            context = "\n".join(lines[start:j])
            offset = sum(len(l) + 1 for l in lines[start:j - 1])
            if _MODAL_MACHINE_MSG.search(context):
                continue
            for name, m in _modal_raw_triggers(line):
                if not _modal_exempt_in(context, name, offset + m.start()):
                    bad.append(f"{script.name}:{j} [{name}]: "
                               f"{line.strip()[:100]}")
                    break
    return bad


def check_modal_collapse_sweep():
    """Modal-collapse sweep: no unexempt, unjustified bare role-actuality
    assertion in the paper's prose or any script source; every
    justification entry is load-bearing (it occurs in a raw-triggered
    prose line)."""
    md = PAPER.read_text(encoding="utf-8")
    bad = modal_collapse_prose_violations(md)
    assert not bad, \
        "unjustified modal-collapse in prose:\n" + "\n".join(bad)
    hit_lines = [l for l in strip_code_fences(md)
                 if l and _modal_raw_triggers(l)]
    matched = {jstr for jstr, _ in MODAL_JUSTIFICATIONS
               if any(jstr in l for l in hit_lines)}
    stale = [jstr for jstr, _ in MODAL_JUSTIFICATIONS if jstr not in matched]
    assert not stale, f"stale modal justifications: {stale}"
    sbad = modal_collapse_script_violations()
    assert not sbad, \
        "modal-collapse trigger in script source:\n" + "\n".join(sbad)
# MACHINERY-END


# ---------------------------------------------------------------------------
# Canonical-enumeration sweep (#120). The V8 false pointer: the §7.5
# operator definition and the §11.2 consolidation-path definition cited
# §12.4 for the position-enumeration order, but §12.4 defines only the
# six-class ordering key. The order is now defined in §7.5 (Canonical
# Position Enumeration: index order, least index first); every prose use
# of the concept must be anchored there.
# ---------------------------------------------------------------------------
CANONENUM_RE = re.compile(
    r"canonically-first|canonical enumeration order|canonical positions?",
    re.IGNORECASE)
CANONENUM_DEF_RE = re.compile(
    r"Definition \(Canonical Position Enumeration\)")
# Pointer attribution is sentence-scoped: a section pointer is attributed
# to the concept only inside the sentence carrying the concept. (The
# stale §12.4 shape is rejected line-wide: it is never legitimate.)
_CANONENUM_SENT_SPLIT = re.compile(r"[.;!?]\s+")
_CANONENUM_STALE_RE = re.compile(r"\(§12\.4")
_CANONENUM_OK_RE = re.compile(r"\(§7\.5")
_CANONENUM_PTR_RE = re.compile(r"\(§([\d.]+)")


def _canonenum_prose_lines(md_text):
    """Yield (lineno, section, in_changelog, line) for prose lines."""
    cur, in_log = None, False
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if line.startswith("## "):
            in_log = "REVISION NOTES" in line
            m = re.match(r"#{2,4}\s+(§[\d.]+)", line)
            if m:
                cur = m.group(1)
            continue
        m = re.match(r"#{2,4}\s+(§[\d.]+)", line)
        if m:
            cur = m.group(1)
        yield i, cur, in_log, line


def canonenum_prose_violations(md_text):
    """Prose uses of the position-enumeration concept with a wrong or
    missing §7.5 anchor. Pointer attribution is sentence-scoped: the
    stale §12.4 shape is rejected line-wide; any other section pointer
    is attributed to the concept only inside the sentence carrying it.
    Admitted: the §7.x definition home (bare uses), sentences carrying
    an explicit §7.5 pointer, and the changelog record."""
    bad = []
    for i, sec, in_log, line in _canonenum_prose_lines(md_text):
        if not CANONENUM_RE.search(line):
            continue
        if in_log:
            continue
        if _CANONENUM_STALE_RE.search(line):
            bad.append(f"line {i} [{sec}]: stale §12.4 pointer on "
                       f"position-enumeration concept: {line.strip()[:120]}")
            continue
        verdict = None  # None = no pointer seen in any trigger sentence
        for sent in _CANONENUM_SENT_SPLIT.split(line):
            if not CANONENUM_RE.search(sent):
                continue
            if _CANONENUM_OK_RE.search(sent):
                verdict = "ok"
                break
            mptr = _CANONENUM_PTR_RE.search(sent)
            if mptr:
                verdict = (mptr.group(1), sent)
                break
        if verdict == "ok":
            continue
        if isinstance(verdict, tuple):
            num, sent = verdict
            bad.append(f"line {i} [{sec}]: wrong §{num} pointer "
                       f"on position-enumeration concept (want §7.5): "
                       f"{sent.strip()[:120]}")
            continue
        if sec is not None and sec.startswith("§7"):
            continue
        bad.append(f"line {i} [{sec}]: unanchored position-enumeration "
                   f"use (no §7.5 pointer): {line.strip()[:120]}")
    return bad


def check_canonenum_sweep():
    """Canonical-enumeration sweep: every prose use of the
    position-enumeration concept is anchored to its §7.5 definition; no
    script source carries the stale pointer shape on the concept."""
    md = PAPER.read_text(encoding="utf-8")
    bad = canonenum_prose_violations(md)
    assert not bad, \
        "canonical-enumeration pointer drift in prose:\n" + "\n".join(bad)
    # Anti-vacuity: the definition and its live anchor must exist, so the
    # sweep cannot pass by the defined term going missing.
    assert CANONENUM_DEF_RE.search(md), \
        "§7.5 Canonical Position Enumeration definition missing"
    assert "canonical enumeration order (§7.5)" in md, \
        "§11.2 canonical-enumeration (§7.5) anchor missing"
    for p in sorted(HERE.glob("F*.py")):
        in_machinery = False
        for j, sl in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "MACHINERY-START" in sl:
                in_machinery = True
                continue
            if "MACHINERY-END" in sl:
                in_machinery = False
                continue
            if not CANONENUM_RE.search(sl):
                continue
            if p.name == "F42_stageN_firewall.py" and (
                    in_machinery or "MACHINERY-OK" in sl):
                continue
            assert not _CANONENUM_STALE_RE.search(sl), \
                f"{p.name}:{j} stale §12.4 pointer on " \
                f"position-enumeration concept"



# MACHINERY-START: V13 reading-aid never-again gate (group 20). The
# placeholder-shaped strings inside this block are the sweep's own battery,
# never paper content.
# V13 defect class: a B-descriptor (boundary-port-count descriptor) inside
# the §12.1 Definition proper without the "(reading aid; not derived)" flag.
# The #122 remediation flagged all six §12.1 enumerated items; this gate pins
# the flags so a future edit cannot silently drop one. Scope is the §12.1
# Definition's six enumerated items (the V13 site); B-descriptor shapes in
# other Definitions stay human-audit territory, as disclosed in the §14.2
# F.42 description.
V13_ITEM_RE = re.compile(
    r"^(?:[1-6])\. (?:Photon|Open tilted states|Meson-like configurations|"
    r"Baryon-like configurations|Nuclei|Atoms) ", re.M)
V13_FLAG = "(reading aid; not derived)"
V13_DEF_RE = re.compile(
    r"\*\*Definition \(Complexity Ordering\)\.\*\*(.*?)(?=\n### |\Z)", re.S)


def v13_prose_violations(md_text):
    """Each of the six §12.1 enumerated items must carry the reading-aid
    flag. Returns a list of violation strings (empty when clean)."""
    body = "\n".join(l for l in strip_code_fences(md_text) if l is not None)
    m = V13_DEF_RE.search(body)
    if not m:
        return ["§12.1 Definition (Complexity Ordering) block not found"]
    block = m.group(1)
    bad = []
    items = V13_ITEM_RE.findall(block)
    if len(items) != 6:
        bad.append(
            "§12.1 Definition: want 6 enumerated items, found %d" % len(items))
    for line in block.splitlines():
        if V13_ITEM_RE.match(line) and V13_FLAG not in line:
            bad.append("§12.1 item missing %r: %s"
                       % (V13_FLAG, line.strip()[:110]))
    return bad


def check_v13_sweep():
    """V13 never-again gate (group 20): the six §12.1 B-descriptors keep
    their reading-aid flags; a dropped flag fails the build."""
    md = PAPER.read_text(encoding="utf-8")
    bad = v13_prose_violations(md)
    assert not bad, "V13 reading-aid flag missing:\n" + "\n".join(bad)
    # Anti-vacuity: the definition and the six flagged items must exist, so
    # the sweep cannot pass by the defined terms going missing.
    prose = "\n".join(l for l in strip_code_fences(md) if l is not None)
    assert V13_DEF_RE.search(prose), \
        "§12.1 Definition (Complexity Ordering) missing"
    assert md.count(V13_FLAG) >= 6, \
        "fewer than six reading-aid flags in the paper"
    # Planted battery: a dropped flag on one item is rejected; the intact
    # six-item block passes.
    block = V13_DEF_RE.search(prose).group(1)
    lines = block.splitlines()
    mutant = "\n".join(
        l.replace(V13_FLAG, "(reading aid)") if V13_ITEM_RE.match(l) and l.startswith("2.")
        else l for l in lines)
    assert v13_prose_violations("**Definition (Complexity Ordering).**" + mutant), \
        "planted dropped reading-aid flag NOT rejected"
    assert not v13_prose_violations(
        "**Definition (Complexity Ordering).**" + block), \
        "intact §12.1 items wrongly flagged: %s" % v13_prose_violations(
            "**Definition (Complexity Ordering).**" + block)
# MACHINERY-END: V13 reading-aid never-again gate (group 20).



# ---------------------------------------------------------------------------
# MACHINERY-START: triple-convergence scope gates (group 21). The
# placeholder-shaped strings inside this block are the sweep's own battery,
# never paper content.
# ChatGPT HIGH claim "binary transition operator vs non-binary junctions"
# (2026-10-04, staged): T is pairwise-scoped (the §7.5 Scope note -- k is
# the number of canonical positions of a pairwise junction, never a junction
# arity); the arity-3 dynamics are the inherited triple-convergence
# transformation (§7.6; Paper 2 §8.1; Paper 2 §11.1; Paper 3 §7; Paper 3
# §8.5). Three never-again gates over live prose (fenced listings and the
# Appendix-I changelog excluded -- the changelog is verbatim dated
# historical record):
# (i) unscoped completeness language -- "arbitrary finite k" / "complete
# (native) transition rule" must carry explicit pairwise scope in the same
# paragraph, or a span-scoped scope pin admits the trigger;
# (ii) triple-convergence citation -- every "triple-convergence" occurrence
# must name Paper 2 §8.1 (the sole native product source per the author's
# 2026-10-04 ruling, #126) or carry a §7.6 pointer in the same paragraph
# (the §7.6 heading itself carries its §7.6 pointer);
# (iii) σ two-tuple form -- σ is never generalized beyond (A, B); the
# sweep rejects σ=(A_1,A_2,A_3)-shaped definitions, plain-spelling
# three-component forms (σ = (A, B, C), T(A, B, C), unicode subscripts
# σ₁₂₃ / A₁), and three-tuple/n-tuple language attached to σ or T.
# Limitation-stating sentences (firewall, deferral, "the full mapping is
# deferred to a later paper") are the admitted class, never the violation
# class. A fourth sub-gate (2026-10-04 loop repair): case-insensitive
# /lab notes?/ in live prose is rejected except under four span-scoped
# pins -- the §1 "never citable authority" ban, the §1 quarantine of the
# complexity-difference selection rule, the §15 restatement of the ban,
# and the Appendix F F.3 banned-imports list.
# ---------------------------------------------------------------------------
G21_ARB_K_RE = re.compile(r"arbitrary finite k", re.IGNORECASE)
G21_COMPLETE_RULE_RE = re.compile(r"complete (native )?transition rule",
                                  re.IGNORECASE)
G21_PAIRWISE_RE = re.compile(
    r"pairwise|k_j\s*=\s*2|two-tuple|two tuples|scoped to pairwise",
    re.IGNORECASE)
G21_TC_RE = re.compile(r"triple-convergence", re.IGNORECASE)
# The citation anchor is Paper 2 §8.1 -- the author's 2026-10-04 ruling
# (#126) makes it the sole native reading of the triple-convergence
# products. A paragraph naming §8.1 (alone or with the other inherited
# sources) or pointing at §7.6 admits; a paragraph omitting §8.1 is
# rejected even when it cites Paper 2 §11.1, Paper 3 §7, or Paper 3 §8.5.
G21_TC_CITE_RE = re.compile(r"Paper 2 §8\.1(?![\d.])|§7\.6(?![\d.])")
G21_SIGMA3_RE = re.compile(r"σ\s*=\s*\(\s*A[_\s]*1")
# Plain-spelling coverage (2026-10-04 loop repair): comma-counting --
# two commas inside the parens is three components, so σ=(A, B) (one
# comma) and T(σ) (none) never match. Unicode subscripts: σ₁₂₃ and the
# A₁ form inside a σ=(...) definition.
G21_SIGMA_TRIPLE_RE = re.compile(r"σ\s*=\s*\([^()]*,[^()]*,[^()]*\)")
G21_T_TRIPLE_RE = re.compile(r"T\s*\([^()]*,[^()]*,[^()]*\)")
G21_SIGMA_SUB_RE = re.compile(r"σ[₁₂₃]|σ\s*=\s*\(\s*A?[₁₂₃]")
G21_TUPLE3_RE = re.compile(r"(three-tuple|3-tuple|n-tuple)", re.IGNORECASE)
# Plain-word "triple" near σ/T (2026-10-04 loop repair): the hyphenated-only
# TUPLE3 regex let "the σ triple" through. The (?!-convergence) guard keeps
# the sanctioned "triple-convergence" term out of the plain-word match; the
# σ/T proximity condition (applied at the use site, same as TUPLE3) keeps
# the badge narrow.
G21_TRIPLE_PLAIN_RE = re.compile(r"\btriple(?!-convergence)\b",
                                 re.IGNORECASE)
G21_T_NEAR_RE = re.compile(r"\bT\s*\(")
# Span-scoped scope pins: (literal, justification). A pin admits a gate-(i)
# trigger only when the pin literal covers the trigger's matched span --
# the trigger sentence itself is byte-identical and unsound-shaped, so the
# admission carries the pin's span in the violation-style record.
G21_SCOPE_PINS = [
    ("Machine-checked by F.43 in exact integer arithmetic at arbitrary "
     "finite k",
     "§7.5 Proof. -- inside §7.5, governed by its Scope note (k = the "
     "number of canonical positions of a pairwise junction)"),
]


def _g21_live_lines(md_text):
    """(lineno, line) for live prose: fenced code blocks removed, the
    Appendix-I changelog excluded (verbatim dated historical record)."""
    out = []
    in_log = False
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if line.startswith("## "):
            in_log = "REVISION NOTES" in line
            continue
        if in_log:
            continue
        out.append((i, line))
    return out


_G21_LIST_ITEM_RE = re.compile(r"^(- |[*] |\d+\.\s)")


def _g21_paragraphs(live_lines):
    """Group live lines into blank-line-separated paragraphs; markdown list
    items (-, *, N.) additionally start new paragraphs, since the §14.2
    script bullets and the Appendix-H numbered list run without blank lines
    between items and each item is its own semantic unit. Yields
    (start_lineno, [(lineno, line), ...])."""
    paras, cur, start = [], [], None

    def flush():
        nonlocal cur, start
        if cur:
            paras.append((start, cur))
            cur, start = [], None

    for i, line in live_lines:
        if line.strip() == "":
            flush()
            continue
        if start is None:
            start = i
        elif _G21_LIST_ITEM_RE.match(line):
            flush()
            start = i
        cur.append((i, line))
    flush()
    return paras


def _g21_pin_admits(line, mstart, mend, pins):
    for jstr, _ in pins:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def g21_prose_violations(md_text):
    """Group-21 gates over live prose. Returns violation strings (empty if
    clean). Gate (i) triggers are line-scoped with paragraph scope; gate
    (ii) is paragraph-scoped; gate (iii) is line-scoped."""
    bad = []
    live = _g21_live_lines(md_text)
    para_text_of = {}
    for _, plines in _g21_paragraphs(live):
        text = "\n".join(l for _, l in plines)
        for ln, _ in plines:
            para_text_of[ln] = text
    for ln, line in live:
        ptext = para_text_of.get(ln, line)
        # (i) unscoped completeness language
        for rx, name in ((G21_ARB_K_RE, "arbitrary-finite-k"),
                         (G21_COMPLETE_RULE_RE, "complete-rule")):
            for m in rx.finditer(line):
                if G21_PAIRWISE_RE.search(ptext):
                    continue
                if _g21_pin_admits(line, m.start(), m.end(),
                                  G21_SCOPE_PINS):
                    continue
                bad.append(f"line {ln} [g21-i/{name}]: unscoped completeness "
                           f"language (no pairwise scope in paragraph): "
                           f"{line.strip()[:120]}")
        # (ii) triple-convergence citation
        for _ in G21_TC_RE.finditer(line):
            if G21_TC_CITE_RE.search(ptext):
                continue
            bad.append(f"line {ln} [g21-ii]: triple-convergence occurrence "
                       f"without inherited citation or §7.6 pointer: "
                       f"{line.strip()[:120]}")
        # (iii) σ two-tuple form
        if (G21_SIGMA3_RE.search(line) or G21_SIGMA_SUB_RE.search(line)
                or G21_SIGMA_TRIPLE_RE.search(line)):
            bad.append(f"line {ln} [g21-iii]: σ generalized beyond (A, B): "
                       f"{line.strip()[:120]}")
        elif G21_T_TRIPLE_RE.search(line):
            bad.append(f"line {ln} [g21-iii]: T applied to three arguments: "
                       f"{line.strip()[:120]}")
        elif G21_TUPLE3_RE.search(line) and (
                "σ" in line or G21_T_NEAR_RE.search(line)):
            bad.append(f"line {ln} [g21-iii]: n-tuple language near σ/T: "
                       f"{line.strip()[:120]}")
        elif G21_TRIPLE_PLAIN_RE.search(line) and (
                "σ" in line or G21_T_NEAR_RE.search(line)):
            bad.append(f"line {ln} [g21-iii]: plain-word 'triple' near σ/T: "
                       f"{line.strip()[:120]}")
    return bad


# Group-21 lab-note sub-gate (2026-10-04 loop repair). The placeholder-
# shaped strings inside this block are the sweep's own battery, never paper
# content. Case-insensitive /lab[\s\-_]?notes?/ in live prose (fenced
# listings and the Appendix-I changelog excluded, same as the other
# group-21 gates) is REJECTED except under one of the seven span-scoped
# pins below. The pins follow the #102/#114/#115 pattern (literal,
# justification): a pin admits only the trigger span its literal covers.
# The two §14.2 F.38-bullet pins exist because the widened spelling class
# (2026-10-04 loop repair: hyphen/underscore forms join, matching F.38's
# R3 ban) newly covers that bullet's own ban description and planted-
# battery names -- gate vocabulary, never a lab-note authority claim.
G21_LABNOTE_RE = re.compile(r"lab[\s\-_]?notes?", re.IGNORECASE)
G21_LABNOTE_PINS = [
    ("The lab notes remain archaeology, never citable authority.",
     "§1 Introduction: the ban -- lab notes are never citable authority"),
    ("The complexity-difference gravity selection rule from the lab notes "
     "remains quarantined",
     "§1 Introduction: the complexity-difference selection rule stays "
     "quarantined"),
    ("Does not formalize the lab notes' complexity-difference gravity "
     "selection rule.",
     "§1 exclusion box: the complexity-difference selection rule stays "
     "quarantined"),
    ("The lab notes remain archaeology.",
     "§15 Limitations and Deferred Work: the ban restated"),
    ("the lab notes' complexity-difference gravity selection rule",
     "Appendix F F.3 Banned imports"),
    ("lab-note citations are banned by name",
     "§14.2 Script F.38 bullet: the ban described, not a citation"),
    ("the lab-note-smuggle, dropped-source, and text-field lab-note "
     "mutants",
     "§14.2 Script F.38 bullet: planted-battery names"),
]


def g21_labnote_prose_violations(md_text):
    """Group-21 lab-note sub-gate: every live-prose lab-note occurrence
    must be covered by a span-scoped pin; anything else is a violation."""
    bad = []
    for ln, line in _g21_live_lines(md_text):
        for m in G21_LABNOTE_RE.finditer(line):
            if _g21_pin_admits(line, m.start(), m.end(), G21_LABNOTE_PINS):
                continue
            bad.append(f"line {ln} [g21-labnote]: unpinned lab-note spelling "
                       f"in live prose: {line.strip()[:120]}")
    return bad


def check_g21_sweep():
    """Group-21 never-again gates: (i) unscoped completeness language,
    (ii) triple-convergence citation, (iii) σ two-tuple form, plus the
    lab-note prose sub-gate. Live prose must be clean; the planted battery
    must be rejected and the controls must pass."""
    md = PAPER.read_text(encoding="utf-8")
    bad = g21_prose_violations(md)
    assert not bad, \
        "group-21 scope-gate violations:\n" + "\n".join(bad)
    # Anti-vacuity: the scoped sites must exist, so the gates cannot pass
    # by the scoped language going missing.
    assert "**Scope.** T is scoped to pairwise junctions" in md, \
        "§7.5 Scope note missing"
    assert "### §7.6 Triple-Convergence Dynamics" in md, \
        "§7.6 heading missing"
    assert "the local state is σ = (A, B)" in md, \
        "§7.5 σ=(A, B) definition missing"
    # Planted battery: genuine spec violations; controls: admitted shapes.
    assert g21_prose_violations(
        "T is a complete native transition rule at arbitrary finite k."), \
        "planted unscoped completeness sentence NOT rejected"
    assert not g21_prose_violations(
        "T is a complete native pairwise transition rule at arbitrary "
        "finite k."), \
        "pairwise-scoped completeness control wrongly flagged"
    assert g21_prose_violations(
        "The triple-convergence dynamics resolve every junction natively."), \
        "planted uncited triple-convergence sentence NOT rejected"
    assert not g21_prose_violations(
        "The triple-convergence dynamics (§7.6) resolve the arity-3 "
        "junction."), \
        "§7.6-pointed triple-convergence control wrongly flagged"
    assert g21_prose_violations(
        "In the generalized reading σ=(A_1,A_2,A_3), T acts on three "
        "tuples."), \
        "planted three-component σ sentence NOT rejected"
    assert not g21_prose_violations(
        "The local state is σ = (A, B): the two sides' port-value tuples."), \
        "two-tuple σ control wrongly flagged"
    # Gate-(ii) §8.1 primacy (2026-10-04 author ruling, #126): Paper 2
    # §8.1 is the sole native reading of the triple-convergence products,
    # so the citation anchor is §8.1 -- a §8.1-naming paragraph admits
    # (alone or with the other inherited sources); a paragraph citing the
    # other sources while omitting §8.1 is rejected.
    assert not g21_prose_violations(
        "The triple-convergence dynamics (Paper 2 §8.1) resolve every "
        "junction natively."), \
        "§8.1-naming triple-convergence control wrongly flagged"
    assert g21_prose_violations(
        "The triple-convergence dynamics (Paper 2 §11.1; Paper 3 §7; "
        "Paper 3 §8.5) resolve every junction natively."), \
        "planted §8.1-omitting triple-convergence sentence NOT rejected"
    assert not g21_prose_violations(
        "The triple-convergence dynamics (Paper 2 §8.1; Paper 2 §11.1; "
        "Paper 3 §7; Paper 3 §8.5) resolve the arity-3 junction."), \
        "four-source triple-convergence control wrongly flagged"
    # Gate-(i) case-insensitivity (2026-10-04 loop repair): the capitalized
    # "Arbitrary finite k" evaded the old case-sensitive regex.
    assert g21_prose_violations(
        "Arbitrary finite k is the domain of the complete native "
        "transition rule."), \
        "planted capitalized completeness sentence NOT rejected"
    # Gate-(iii) plain-spelling coverage (2026-10-04 loop repair): comma-
    # counting and unicode subscripts. Controls: σ=(A, B) and T(σ) pass.
    assert g21_prose_violations(
        "Reading the local state as σ = (A, B, C) generalizes the "
        "junction."), \
        "planted plain-spelling three-component σ sentence NOT rejected"
    assert g21_prose_violations(
        "The transition T(A, B, C) resolves all three sides at once."), \
        "planted three-argument T sentence NOT rejected"
    assert g21_prose_violations(
        "With σ = (A₁, A₂, A₃) the local state carries three tuples."), \
        "planted unicode-subscript σ sentence NOT rejected"
    assert g21_prose_violations(
        "The σ₁₂₃ form generalizes the local state."), \
        "planted unicode-subscript σ_123 sentence NOT rejected"
    assert not g21_prose_violations(
        "The operator acts as T(σ) = σ where σ = (A, B)."), \
        "two-tuple σ / T(σ) control wrongly flagged"
    # Gate-(iii) plain-word "triple" (2026-10-04 loop repair): the
    # hyphenated-only TUPLE3 regex let "the σ triple" through. The
    # (?!-convergence) guard keeps the sanctioned "triple-convergence"
    # term out of the plain-word match; the σ/T proximity condition keeps
    # the badge narrow. (The "triple-convergence" control is asserted
    # against gate (iii) only -- gate (ii) still requires the inherited
    # citation or §7.6 pointer.)
    assert g21_prose_violations(
        "Reading the local state as the σ triple generalizes the junction."), \
        "planted plain-word 'σ triple' sentence NOT rejected"
    assert g21_prose_violations(
        "σ as a triple of port tuples resolves the junction at once."), \
        "planted plain-word 'triple of port tuples' sentence NOT rejected"
    assert not any("[g21-iii]" in v
                   for v in g21_prose_violations("triple-convergence")), \
        "sanctioned 'triple-convergence' wrongly flagged by gate (iii)"
    assert not any("[g21-iii]" in v for v in g21_prose_violations(
        "The local state is σ = (A, B).")), \
        "two-tuple σ control wrongly flagged by gate (iii)"
    # Group-21 lab-note sub-gate (2026-10-04 loop repair): unpinned
    # lab-note spellings in live prose are rejected; the seven pins admit
    # the §1 ban, the §1 quarantine, the §1 exclusion-box quarantine, the
    # §15 restatement, the F.3 banned-imports list, and the §14.2 F.38
    # bullet's ban description and planted-battery names. Admission is
    # span-scoped: a pin covers only the trigger span its literal covers,
    # so an extra mention appended outside a pin's span is rejected.
    bad = g21_labnote_prose_violations(md)
    assert not bad, \
        "group-21 lab-note violations:\n" + "\n".join(bad)
    assert g21_labnote_prose_violations(
        "Per the lab notes, the triple-convergence products are unpacked "
        "from inside."), \
        "planted lab-note sentence NOT rejected"
    # Orthographic variants (2026-10-04 loop repair): the hyphen and
    # underscore spellings join the banned class, matching F.38's R3 ban.
    assert g21_labnote_prose_violations(
        "Per the lab_note records, the products resolve this way."), \
        "planted lab_note-spelling sentence NOT rejected"
    assert g21_labnote_prose_violations(
        "Per the lab-note records, the products resolve this way."), \
        "planted lab-note-spelling sentence NOT rejected"
    # Span-scoped admission (2026-10-04 loop repair): an extra mention
    # appended to a pinned line OUTSIDE the pin's span is rejected.
    assert g21_labnote_prose_violations(
        "The lab notes remain archaeology, never citable authority. "
        "Per the lab_note records, the ban is total."), \
        "planted out-of-pin-span lab-note sentence NOT rejected"
    assert not g21_labnote_prose_violations(
        "The lab notes remain archaeology, never citable authority."), \
        "pinned lab-note ban control wrongly flagged"
# MACHINERY-OK
# MACHINERY-END: triple-convergence scope gates (group 21)




# ---------------------------------------------------------------------------
# MACHINERY-START: spatial-physical noun sweep (group 22). The
# placeholder-shaped strings inside this block are the sweep's own battery,
# never paper content.
# ChatGPT MEDIUM-HIGH claim "shove toward alignment" (2026-10-05, staged):
# §7.2's pre-repair prose characterized the shove with spatial-physical
# nouns ("concrete physical response", "pushed into geometric alignment")
# that no native definition anchored -- V13 (#75) swept only the single
# word "interaction magnitude", never this meaning class. The §7.2 repair
# rewords the Mechanical Shove definition operationally (the fabrication's
# scan resolving shear tension: at each tick, T zeroes the canonically-
# first complementary pair, strictly decreasing tau_J) plus one explicit
# bridge sentence reserving the spatial reading to Stage-P reconstruction;
# the §8.2 Mechanism sentence is reworded the same way. This gate is the
# never-again sweep over the meaning class (curated, not word-specific):
# every live-prose occurrence of the spatial-physical patterns below must
# carry (a) an explicit Stage-P / observational-shadow marking, or (b) a
# span-scoped justification pin. The native-definition-anchor class is
# vacuous on this tree by construction: the reworded §7.2 definition
# carries no trigger, so no live occurrence needs it (documented, not
# implemented as a third admission path).
# Fenced listings and the Appendix-I changelog are excluded (verbatim dated
# historical record), as is the §14.2 F.42 bullet's own description line
# ("this description" -- the established admission for a sweep's own
# pattern vocabulary).
# ---------------------------------------------------------------------------
G22_PATTERNS = [
    (re.compile(r"concrete physical", re.IGNORECASE), "concrete-physical"),
    (re.compile(r"physical response", re.IGNORECASE), "physical-response"),
    (re.compile(r"\bpushed\b", re.IGNORECASE), "pushed"),
    (re.compile(r"\bpushes\b", re.IGNORECASE), "pushes"),
    (re.compile(r"\bpushing\b", re.IGNORECASE), "pushing"),
    (re.compile(r"\bdisplacement\b", re.IGNORECASE), "displacement"),
    (re.compile(r"geometric alignment", re.IGNORECASE), "geometric-alignment"),
    (re.compile(r"moves through space", re.IGNORECASE), "moves-through-space"),
    (re.compile(r"\bmotion\b", re.IGNORECASE), "motion"),
]
# Explicit Stage-P / observational-shadow marking: a paragraph carrying one
# of these admits every trigger occurrence inside it (paragraph scope, the
# group-21 gate-(ii) pattern).
G22_MARK_RE = re.compile(r"Observational shadow|Stage-P reconstruction",
                         re.IGNORECASE)
# The sweep's own description line (§14.2 F.42 bullet) -- admitted as "this
# description", the established convention.
G22_SELF_DESC_RE = re.compile(
    r"^- \*\*Script F\.42 — Stage-N Vocabulary Firewall\.\*\*")
# Span-scoped justification pins: (literal, justification). A pin admits a
# trigger only when the pin literal covers the trigger's matched span.
G22_PINS = [
    ("**Bridge sentence (Stage-P reservation).** The spatial reading of "
     "the shove — the junction's two sides pushed toward each other "
     "through space — is not native: it belongs to Stage-P reconstruction "
     "(cf. §8.2, \"Observational shadow\"). Natively there is no background "
     "manifold and nothing is displaced.",
     "§7.2 bridge sentence: the spatial reading is explicitly reserved to "
     "Stage-P reconstruction (V13 option-(b) pattern)"),
    ("**Observational shadow.** The observed phenomenon of two massive "
     "configurations consolidating — falling toward each other — is the "
     "shadow of the fabrication pushing their boundaries into geometric "
     "alignment. The shadow's inverse-square form is the shadow of the "
     "shell-count scaling (Paper 10 §5.3.1).",
     "§8.2 Observational shadow paragraph: explicitly marked non-native "
     "block"),
    ("not a consequence of its being pushed by external sources",
     "§6.3 corollary: negation -- denies external pushing (anti-external-"
     "force control)"),
    ("at taxicab displacement (D, 0, 0) from A's reference at the origin",
     "§8.5 canonical encounter family: declared machine-check modeling "
     "context, not a native displacement claim"),
    ("Rest/motion/inertia as ledger states (Papers 6–7).",
     "§8.5 'From Papers 6–8' topic summary: inherited Papers 6–7 "
     "vocabulary, noun list -- not a native verb"),
    ("| SHOVE_DIRECTION | A | theorem | L1 | RESOLUTION_VERB | — | F.43 | "
     "shove pushes toward alignment |",
     "E.2 registry-text rendering of SHOVE_DIRECTION (registry text cell, "
     "not native prose)"),
    ("10. **SHOVE_DIRECTION** — the shove pushes toward alignment. If "
     "falsified, the resolution verb's direction fails.",
     "Appendix H claim-impact statement: registry-text impact statement, "
     "not native prose"),
    ("| SHOVE_DIRECTION | A | §7.2 | §7.2 | F.43 | shove pushes toward "
     "alignment |",
     "Appendix J theorem-map row: registry-text rendering of "
     "SHOVE_DIRECTION (generated from the registry by F.52; not native "
     "prose)"),
]


def _g22_live_lines(md_text):
    """(lineno, line) for group-22 live prose: fenced code blocks removed,
    the Appendix-I changelog excluded, and the §14.2 F.42 bullet's own
    description line excluded ('this description')."""
    out = []
    in_log = False
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if line.startswith("## "):
            in_log = "REVISION NOTES" in line
            continue
        if in_log:
            continue
        if G22_SELF_DESC_RE.match(line):
            continue
        out.append((i, line))
    return out


def _g22_pin_admits(line, mstart, mend, pins):
    for jstr, _ in pins:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def g22_prose_violations(md_text):
    """Group-22 sweep over live prose. Returns violation strings (empty if
    clean). A trigger occurrence is admitted iff its paragraph carries an
    explicit Stage-P / observational-shadow marking, or a span-scoped pin
    covers its matched span."""
    bad = []
    live = _g22_live_lines(md_text)
    para_text_of = {}
    for _, plines in _g21_paragraphs(live):
        text = "\n".join(l for _, l in plines)
        for ln, _ in plines:
            para_text_of[ln] = text
    for ln, line in live:
        ptext = para_text_of.get(ln, line)
        if G22_MARK_RE.search(ptext):
            continue
        for rx, name in G22_PATTERNS:
            for m in rx.finditer(line):
                if _g22_pin_admits(line, m.start(), m.end(), G22_PINS):
                    continue
                bad.append(f"line {ln} [g22/{name}]: spatial-physical noun "
                           f"in live prose without Stage-P/observational-"
                           f"shadow marking or justification pin: "
                           f"{line.strip()[:120]}")
    return bad


def check_g22_sweep():
    """Group-22 never-again gate: the spatial-physical noun meaning class
    from the §7.2 'shove toward alignment' remediation. Live prose must be
    clean; every pin must be load-bearing; the planted battery must be
    rejected and the controls must pass."""
    md = PAPER.read_text(encoding="utf-8")
    bad = g22_prose_violations(md)
    assert not bad, \
        "group-22 spatial-physical violations:\n" + "\n".join(bad)
    # Anti-vacuity: every pin literal must occur in the paper, so the pins
    # cannot pass by the pinned language going missing.
    for jstr, why in G22_PINS:
        assert jstr in md, "group-22 pin literal missing: %s" % why
    # Planted battery: genuine spec violations; controls: admitted shapes.
    assert g22_prose_violations(
        "The junction's two sides are pushed through space toward each "
        "other."), \
        "planted 'pushed through space' sentence NOT rejected"
    assert g22_prose_violations(
        "The shove is a concrete physical response to shear tension."), \
        "planted 'concrete physical response' sentence NOT rejected"
    assert g22_prose_violations(
        "Each tick, the boundary moves through space toward the other "
        "side."), \
        "planted 'moves through space' sentence NOT rejected"
    assert g22_prose_violations(
        "The junction settles into geometric alignment."), \
        "planted 'geometric alignment' sentence NOT rejected"
    assert g22_prose_violations(
        "The fabrication's scan pushing the boundary is a physical "
        "response to tension."), \
        "planted 'pushing'/'physical response' sentence NOT rejected"
    assert g22_prose_violations(
        "The native motion of the boundary closes the junction."), \
        "planted native-'motion' sentence NOT rejected"
    assert g22_prose_violations(
        "The taxicab displacement of the sides is a native quantity."), \
        "planted native-'displacement' sentence NOT rejected"
    # Controls: the admitted shapes pass.
    assert not g22_prose_violations(
        "**Bridge sentence (Stage-P reservation).** The spatial reading of "
        "the shove — the junction's two sides pushed toward each other "
        "through space — is not native: it belongs to Stage-P "
        "reconstruction (cf. §8.2, \"Observational shadow\"). Natively "
        "there is no background manifold and nothing is displaced."), \
        "§7.2 bridge-sentence control wrongly flagged"
    assert not g22_prose_violations(
        "**Observational shadow.** The observed phenomenon of two massive "
        "configurations consolidating — falling toward each other — is "
        "the shadow of the fabrication pushing their boundaries into "
        "geometric alignment."), \
        "§8.2 shadow control wrongly flagged"
    assert not g22_prose_violations(
        "The mechanical shove is the fabrication's scan resolving shear "
        "tension: at each tick, T zeroes the canonically-first "
        "complementary pair (§7.5), strictly decreasing τ_J."), \
        "§7.2 reworded-definition control wrongly flagged"
    assert not g22_prose_violations(
        "not a consequence of its being pushed by external sources"), \
        "§6.3 negation control wrongly flagged"
    assert not g22_prose_violations(
        "at taxicab displacement (D, 0, 0) from A's reference at the "
        "origin"), \
        "§8.5 taxicab-displacement control wrongly flagged"
    assert not g22_prose_violations(
        "Rest/motion/inertia as ledger states (Papers 6–7)."), \
        "Papers-6–8 topic-summary control wrongly flagged"
    assert not g22_prose_violations(
        "| SHOVE_DIRECTION | A | theorem | L1 | RESOLUTION_VERB | — | "
        "F.43 | shove pushes toward alignment |"), \
        "E.2 SHOVE_DIRECTION-row control wrongly flagged"
    assert not g22_prose_violations(
        "10. **SHOVE_DIRECTION** — the shove pushes toward alignment. If "
        "falsified, the resolution verb's direction fails."), \
        "H.4 SHOVE_DIRECTION-statement control wrongly flagged"
    # Pin-granularity probe (span-scoped admission): a trigger appended
    # OUTSIDE a pin's span is rejected even on a pinned line.
    assert g22_prose_violations(
        "not a consequence of its being pushed by external sources. "
        "The shove pushes harder each tick."), \
        "planted out-of-pin-span 'pushes' sentence NOT rejected"
# MACHINERY-OK
# MACHINERY-END: spatial-physical noun sweep (group 22)




# MACHINERY-START: universal-quantifier sweep (group 23). The
# placeholder-shaped strings inside this block are the sweep's own battery,
# never paper content.
# Scale-fidelity remediation (2026-10-05, staged #131): the old §0.5.v.3
# sentence ("Scale-up monotonically improves fidelity with no regime
# transition anywhere in the climb") carried an unbadged, unregistered
# universal quantifier -- "fidelity" was undefined and no machine check
# backed the monotonicity. The repaired sentence is badged [LEVEL A],
# registered as SCALE_FIDELITY, and machine-backed by F.56. This gate is
# the never-again sweep for that defect class: over the §0.5 front-matter
# (the prolegomenon through §0.5.v.3, fenced code removed), every
# universal-quantifier trigger below must be covered by a span-scoped
# justification pin naming its badge, its registry row, and its machine
# check -- or the sentence must be reworded. The gate fails closed: with
# zero pins on this tree, any future trigger in §0.5 fails the build.
# The "anywhere" pattern is noun-scoped to the scale/regime class
# (regime, scale, threshold, transition, law): vocabulary-scope sentences
# such as the v12 lock's "no object ... is defined anywhere in this paper"
# are outside the gate's semantic scope and stay human-audit territory.
# "No explicit regime switch" is a dedicated defect shape: clause-absence
# alone is never admittable and never pinnable -- the mere absence of a
# regime-switch clause proves nothing about regime absence. The shape is
# exempt only when the SAME line also names the honest proof: R15 (or its
# "exact-finite-sum" name) AND the conservation-forcing chain (§4.1, R15).
# A bare "no explicit regime switch, so regime absence is proved" sentence
# -- with no proof named -- is still rejected (context-blindness fix,
# changelog #131 fix pass).
# Orthographic scope, stated not widened: every pattern above is
# line- and sentence-boundary-limited -- the character classes exclude "."
# and newlines, so a trigger spanning a sentence boundary or a line break
# is not matched. That residue is human-audit territory; the patterns as
# written are the documented scope.
# ---------------------------------------------------------------------------
G23_PATTERNS = [
    (re.compile(r"\bmonotonic(ally|ity)?\b", re.IGNORECASE), "monotonic"),
    (re.compile(r"\bfor (all|every) N\b", re.IGNORECASE), "for-all-N"),
    (re.compile(r"\bno\b[^.\n]{0,60}\b(regime|scale|threshold|transition|law)\b"
                r"[^.\n]{0,40}\banywhere\b", re.IGNORECASE), "no-anywhere"),
    (re.compile(r"\bat any scale\b", re.IGNORECASE), "at-any-scale"),
    (re.compile(r"\bevery\b[^.\n]{0,60}\bat any\b", re.IGNORECASE),
     "every-at-any"),
]
# Dedicated defect shape: clause-absence offered as regime-absence proof.
G23_NEVER_RE = re.compile(r"\bno explicit regime switch\b", re.IGNORECASE)


def _g23_honest_chain(line):
    """RT-2 refinement (changelog #131 fix pass): a 'no explicit regime
    switch' occurrence on this line is exempt only when the SAME line also
    cites the honest proof -- R15 (or its "exact-finite-sum" name) AND the
    conservation-forcing chain. Line-scoped, matching the sweep's
    line-based orthographic scope."""
    low = line.lower()
    cites_r15 = ("r15" in low) or ("exact-finite-sum" in low)
    cites_chain = "conservation-forcing" in low
    return cites_r15 and cites_chain
# Span-scoped justification pins: (literal, justification). A pin admits a
# trigger only when the pin literal covers the trigger's matched span.
# Zero pins on this tree by design -- the §0.5.v.3 repair reworded the one
# historical trigger out, and no other §0.5 sentence carries a trigger.
# The anti-vacuity loop below is vacuous; the gate fails closed.
G23_PINS = []


def _g23_front_matter(md_text):
    """(lineno, line) for the §0.5 front-matter: from the PROLEGOMENON
    heading to the §1 heading, fenced code removed."""
    out = []
    in_scope = False
    for i, line in enumerate(strip_code_fences(md_text), 1):
        if line is None:
            continue
        if line.startswith("## §0.5 PROLEGOMENON"):
            in_scope = True
            continue
        if line.startswith("## §1 INTRODUCTION"):
            break
        if in_scope:
            out.append((i, line))
    return out


def _g23_pin_admits(line, mstart, mend, pins):
    for jstr, _ in pins:
        start = line.find(jstr)
        while start != -1:
            if start <= mstart and mend <= start + len(jstr):
                return True
            start = line.find(jstr, start + 1)
    return False


def g23_prose_violations(md_text):
    """Group-23 sweep over the §0.5 front-matter. Returns violation strings
    (empty if clean). A trigger occurrence is admitted iff a span-scoped
    pin covers its matched span; the 'no explicit regime switch' shape is
    admitted only when the same line also names the honest proof (R15 plus
    the conservation-forcing chain) -- bare clause-absence is rejected."""
    bad = []
    for ln, line in _g23_front_matter(md_text):
        if G23_NEVER_RE.search(line):
            if _g23_honest_chain(line):
                continue  # same-line honest proof: R15 + chain named
            bad.append(f"line {ln} [g23/no-explicit-regime-switch]: "
                       f"clause-absence offered as regime-absence proof -- "
                       f"the honest proof names R15 + the "
                       f"conservation-forcing chain: {line.strip()[:120]}")
            continue
        for rx, name in G23_PATTERNS:
            for m in rx.finditer(line):
                if _g23_pin_admits(line, m.start(), m.end(), G23_PINS):
                    continue
                bad.append(f"line {ln} [g23/{name}]: universal-quantifier "
                           f"trigger in §0.5 front-matter without a "
                           f"badge+registry+backing pin: "
                           f"{line.strip()[:120]}")
    return bad


def check_g23_sweep():
    """Group-23 never-again gate: the §0.5.v.3 scale-fidelity defect class.
    Live §0.5 front-matter must be clean; every pin must be load-bearing;
    the planted battery must be rejected and the controls must pass."""
    md = PAPER.read_text(encoding="utf-8")
    bad = g23_prose_violations(md)
    assert not bad, \
        "group-23 universal-quantifier violations:\n" + "\n".join(bad)
    # Anti-vacuity: every pin literal must occur in the paper, so the pins
    # cannot pass by the pinned language going missing.
    for jstr, why in G23_PINS:
        assert jstr in md, "group-23 pin literal missing: %s" % why
    # Planted battery: genuine spec violations; controls: admitted shapes.
    # The battery strings carry the §0.5 front-matter headings so the
    # scope function under test sees them in scope.
    scope = ("## §0.5 PROLEGOMENON\n%s\n## §1 INTRODUCTION\n")
    assert g23_prose_violations(scope % (
        "Scale-up monotonically improves resolution throughput with no "
        "regime transition anywhere in the climb.")), \
        "planted unbadged 'monotonically improves' sentence NOT rejected"
    assert g23_prose_violations(scope % (
        "There is no explicit regime switch in the axioms, so regime "
        "absence is proved.")), \
        "planted 'no explicit regime switch' sentence NOT rejected"
    assert not g23_prose_violations(scope % (
        "There is no explicit regime switch in the axioms, but regime "
        "absence is proved by R15's exact-finite-sum rule together with "
        "the conservation-forcing chain.")), \
        "honest-proof 'no explicit regime switch' sentence (R15 + " \
        "conservation-forcing chain on the same sentence) unexpectedly " \
        "flagged"
    assert not g23_prose_violations(scope % (
        "Scale-up improves fidelity: better means strictly more ledger "
        "entries executed exactly; never different means no regime "
        "transition.")), \
        "repaired Universality sentence unexpectedly flagged"
    assert not g23_prose_violations(scope % (
        "no object called \"native acceleration\" is defined anywhere in "
        "this paper.")), \
        "vocabulary-scope control unexpectedly flagged"
# MACHINERY-END: universal-quantifier sweep (group 23)




# MACHINERY-START: listing import self-containment (group 24). The
# placeholder-shaped strings inside this block are the sweep's own battery,
# never paper content.
# ChatGPT #8 remediation (2026-10-06, staged #134): the computational
# section heading claimed every embedded listing is "executable as printed",
# but F.46 hard-imports two draft-root modules (v14_blitz_f46_categorical,
# v14_f46_caseA_ladder) that are not embedded as listings -- an isolated copy
# of F.46's printed listing dies with ModuleNotFoundError. The dependency was
# disclosed in F.46's own runner note, so this was a heading overclaim, not a
# hidden dependency -- but the paper's integrity machinery (the 23/23
# embedded-listing byte-identity check) covers only embedded listings, leaving
# unembedded runtime files outside every machine gate. This group is the
# never-again gate for that defect class: for each of the 23 embedded listings
# (F.32-F.56 minus the staged-unlisted F.54/F.55), every ast-visible import in
# the listing text as embedded in the paper must resolve to (a) the standard
# library, (b) a fellow embedded F-module, or (c) a draft-root file that is
# BOTH declared in that listing's runner note (the module name appears in the
# listing text outside import statements, so an import cannot declare itself)
# AND hash-pinned in draft_root_dependency_manifest.txt with a sha256 matching
# the draft-root file. Anything else fails the build.
# Scope, stated not widened: only ast-visible `import` / `from ... import`
# statements are classified. Dynamic loads (F.38's and F.42's importlib loads
# of fellow embedded modules) are out of scope -- both targets are embedded
# listings, so "extract all listings and run" still holds; that residue is
# human-audit territory. The embedded set is derived from the paper's own
# listing headings and captions, never hardcoded: '### F<modname>' headings
# (F.32-F.45) and '**F.<NN> — ...**' captions (F.46-F.53, F.56), the caption
# numbers resolving to module names via the draft-root script glob (exactly
# one match required, asserted).
# ---------------------------------------------------------------------------
G24_MANIFEST_NAME = "draft_root_dependency_manifest.txt"


def _g24_embedded_listings(md_text):
    """(module_name, listing_text) for every embedded listing, in the paper's
    two listing formats. Derived from the paper's own headings and captions,
    never hardcoded."""
    out = []
    lines = md_text.split("\n")
    i, n = 0, len(lines)
    while i < n:
        name = None
        m = re.match(r"^### (F\w+)$", lines[i])
        if m:
            name = m.group(1)
        else:
            c = re.match(r"^\*\*F\.(\d+)\s*[—–-]", lines[i])
            if c:
                cands = sorted(HERE.glob("F%s_*.py" % c.group(1)))
                assert len(cands) == 1, \
                    "group-24: caption F.%s resolves to %d scripts, not one: %s" \
                    % (c.group(1), len(cands), cands)
                name = cands[0].stem
        if name:
            j = i + 1
            while j < n and lines[j].strip() == "":
                j += 1
            if j < n and lines[j].strip() == "```python":
                k = j + 1
                buf = []
                while k < n and lines[k].strip() != "```":
                    buf.append(lines[k])
                    k += 1
                out.append((name, "\n".join(buf)))
                i = k
        i += 1
    return out


def _g24_import_names(listing_text):
    """Top-level module names from ast-visible import statements."""
    tree = _ast.parse(listing_text)
    names = []
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Import):
            for a in node.names:
                names.append(a.name.split(".")[0])
        elif isinstance(node, _ast.ImportFrom):
            if node.module:
                names.append(node.module.split(".")[0])
    return names


def _g24_non_import_text(listing_text):
    """Listing text with import-statement lines removed, so the runner-note
    declaration check cannot be satisfied by the import itself."""
    tree = _ast.parse(listing_text)
    imp_lines = set()
    for node in _ast.walk(tree):
        if isinstance(node, (_ast.Import, _ast.ImportFrom)):
            for ln in range(node.lineno, (node.end_lineno or node.lineno) + 1):
                imp_lines.add(ln)
    return "\n".join(
        ln for i, ln in enumerate(listing_text.split("\n"), 1)
        if i not in imp_lines)


def _g24_read_manifest(draft_root):
    """{filename: sha256} from the sha256sum-format manifest ({} if the
    manifest file is absent -- the pinned-dependency assertion below then
    fails closed)."""
    entries = {}
    mp = draft_root / G24_MANIFEST_NAME
    if not mp.is_file():
        return entries
    for line in mp.read_text(encoding="utf-8").split("\n"):
        parts = line.split()
        if len(parts) >= 2:
            entries[parts[1]] = parts[0]
    return entries


def _g24_import_violations(mod_name, listing_text, embedded, manifest,
                           draft_root):
    """Violation strings for one embedded listing (empty if clean)."""
    try:
        imported = _g24_import_names(listing_text)
        prose = _g24_non_import_text(listing_text)
    except SyntaxError as e:
        return [f"[g24/{mod_name}]: listing does not parse ({e}) -- "
                f"not executable as printed"]
    bad = []
    for dep in dict.fromkeys(imported):
        if dep in sys.stdlib_module_names:
            continue
        if dep in embedded:
            continue
        declared = (dep in prose) or ((dep + ".py") in prose)
        fname = dep + ".py"
        hash_ok = False
        if fname in manifest:
            target = draft_root / fname
            if target.is_file():
                hash_ok = (hashlib.sha256(target.read_bytes()).hexdigest()
                           == manifest[fname])
        if declared and fname in manifest and hash_ok:
            continue
        reasons = []
        if not declared:
            reasons.append("not declared in the listing's runner note")
        if fname not in manifest:
            reasons.append("absent from " + G24_MANIFEST_NAME)
        elif not hash_ok:
            reasons.append("manifest hash does not match the draft-root file")
        bad.append(f"[g24/{mod_name}]: non-embedded import '{dep}' -- "
                   + "; ".join(reasons))
    return bad


def check_g24_sweep():
    """Group-24 never-again gate: listing import self-containment (ChatGPT
    #8). Live listings must be clean; the manifest must pin F.46's declared
    dependencies; the planted battery must be rejected and the controls
    must pass."""
    md = PAPER.read_text(encoding="utf-8")
    draft_root = HERE.parent
    listings = _g24_embedded_listings(md)
    embedded = {name for name, _ in listings}
    # Anti-vacuity: the embedded set must be the real 23 listings, so the
    # F.46 positive control below is not vacuous.
    assert len(listings) == 23, \
        f"group-24: expected 23 embedded listings, found {len(listings)}"
    assert "F46_caseA_ladder" in embedded, \
        "group-24: F.46 listing missing -- positive control vacuous"
    assert "F42_stageN_firewall" in embedded, \
        "group-24: F.42's own listing missing"
    manifest = _g24_read_manifest(draft_root)
    assert "v14_blitz_f46_categorical.py" in manifest \
        and "v14_f46_caseA_ladder.py" in manifest, \
        "group-24: F.46's declared dependencies missing from the manifest"
    bad = []
    for name, text in listings:
        bad.extend(_g24_import_violations(name, text, embedded, manifest,
                                          draft_root))
    assert not bad, \
        "group-24 listing import violations:\n" + "\n".join(bad)
    # Planted battery: genuine spec violations, each rejected with a printed
    # witness; the controls must pass.
    f46_text = dict(listings)["F46_caseA_ladder"]
    m1 = f46_text + "\nimport zz_sneaky_external_mod\n"
    w1 = _g24_import_violations("F46_caseA_ladder", m1, embedded, manifest,
                                draft_root)
    assert w1, "planted undeclared external import NOT rejected"
    print("group-24 witness M1 (undeclared external import): " + w1[0])
    tampered = dict(manifest)
    tampered["v14_blitz_f46_categorical.py"] = "0" * 64
    w2 = _g24_import_violations("F46_caseA_ladder", f46_text, embedded,
                                tampered, draft_root)
    assert w2, "planted manifest hash mismatch NOT rejected"
    print("group-24 witness M2 (manifest hash mismatch): " + w2[0])
    m3 = ("import zz_phantom_dep_mod\n"
          "# RUNNER NOTE: zz_phantom_dep_mod.py lives in the draft root.\n"
          "x = 1\n")
    w3 = _g24_import_violations("SYNTHETIC", m3, embedded, manifest,
                                draft_root)
    assert w3, "planted declared-but-unmanifested dependency NOT rejected"
    print("group-24 witness M3 (declared but unmanifested): " + w3[0])
    assert not _g24_import_violations("F46_caseA_ladder", f46_text, embedded,
                                      manifest, draft_root), \
        "F.46 positive control (declared + manifest + hashes match) " \
        "unexpectedly flagged"
    assert not _g24_import_violations("SYNTHETIC", "import os\nimport re\n",
                                      embedded, manifest, draft_root), \
        "stdlib-only control unexpectedly flagged"
    assert not _g24_import_violations("SYNTHETIC", "import F33_aggregate_a\n",
                                      embedded, manifest, draft_root), \
        "fellow-embedded-import control unexpectedly flagged"
# MACHINERY-END: listing import self-containment (group 24)




# MACHINERY-START: section-reference hygiene (v55). The placeholder-shaped
# strings inside this block are the sweep's own battery, never paper content.
# V10 never-again gate: the literal "9.x" placeholder heading survived into
# v54, and the drift-sweep boundary covered registry text but not section
# addresses. This check enforces, for the live paper body (before Appendix I,
# which with the revision notes is verbatim historical record): (a) no
# placeholder-shaped subsection headings; (b) every §N[.M...] cross-reference
# in prose resolves to a real heading; (c) the Contents' top-level entries
# agree with the ## headings.
SECTION_PLACEHOLDER_RE = re.compile(r"\b\d+\.[a-zA-Z]+\b")  # + for multi-letter (red-team 2026-10-04); Cyrillic lookalikes are a known limit
SECTION_TBD_RE = re.compile(r"\bTBD\b|\bXXX\b")
# §N, §N.M, §N.M.P..., with slash/dash compounds (§§4.3/4.4, §5.6–§5.7).
SECTION_REF_RE = re.compile(
    r"§([0-9]+(?:\.[0-9a-z]+)*)((?:[–—\-/]§?[0-9]+(?:\.[0-9a-z]+)*)*)")
# Cross-paper citations (Paper 2 §11.1, Paper 2.5 §13.5) are not Paper-11
# addresses; strip them (with any dash/slash compounds) before checking.
PAPER_PREFIX_RE = re.compile(
    r"Paper \d+(?:\.\d+)? §§?[0-9]+(?:\.[0-9a-z]+)*(?:[–—\-/]§?[0-9]+(?:\.[0-9a-z]+)*)*")
# The §0.5 family legitimately uses letter suffixes (§0.5.x, §0.5.w, ...);
# a letter suffix outside that family is a placeholder shape.
PLACEHOLDER_FAMILY_OK = "§0.5."
# "§7.x" is a deliberate family-generic (the §7 definition family), not an
# address; the actual address (§7.5) is given in the same sentence.
SECTION_FAMILY_OK = ["the §7.x definition home"]
# Known-open dangling refs: genuine instances of this defect class found by
# the v55 defect-class sweep, HELD for the author's direction (#122). Listed
# explicitly by address -- never by pattern -- so no new defect can hide
# behind them. Do not extend this list without a changelog entry.
# Known-open dangling §refs, held for the author. EMPTY as of #122: the two
# v55 calibration finds were fixed mechanically (§11.6 → "Paper 2 §11.6";
# §3.7 → "(Paper 10 §2.2)"). The liveness assertion in check_sectionref_sweep
# fires if an entry stops occurring as a bare §ref in live prose, so stale
# exemptions cannot silently persist and cover new defects (red-team 2026-10-04).
SECTION_KNOWN_OPEN = {}


def _sectionref_headings(md_text):
    return [l for l in md_text.split("\n") if re.match(r"^#{2,4}\s", l)]


def sectionref_prose_violations(md_text):
    """Placeholder headings, dangling §refs, and Contents mismatches in the
    live paper body. Returns a list of violation strings (empty if clean)."""
    bad = []
    lines = md_text.split("\n")
    try:
        app_i = next(i for i, l in enumerate(lines)
                     if l.startswith("## APPENDIX I"))
    except StopIteration:
        app_i = len(lines)
    headings = _sectionref_headings(md_text)
    head_text = "\n".join(headings)

    def exists(addr):
        pat = re.compile(r"^#{2,4}\s+§" + re.escape(addr)
                         + r"(?![0-9a-z.])", re.M)
        return bool(pat.search(head_text))

    # (a) placeholder-shaped subsection headings
    for h in headings:
        if PLACEHOLDER_FAMILY_OK in h:
            continue
        if SECTION_PLACEHOLDER_RE.search(h) or SECTION_TBD_RE.search(h):
            bad.append("placeholder heading: %s" % h.strip()[:100])

    # (b) every §ref in live prose resolves to a real heading
    incode = False
    for i, line in enumerate(lines[:app_i], 1):
        if line.strip().startswith(FENCE):
            incode = not incode
            continue
        if incode:
            continue
        tmp = PAPER_PREFIX_RE.sub("PAPERREF ", line)
        for fam in SECTION_FAMILY_OK:
            tmp = tmp.replace(fam, "FAMILYOK ")
        for m in SECTION_REF_RE.finditer(tmp):
            addrs = [m.group(1)]
            for p in re.split(r"[–—\-/]", m.group(2)):
                p = p.lstrip("§")
                if p:
                    addrs.append(p)
            for a in addrs:
                if a in SECTION_KNOWN_OPEN:
                    continue
                if not exists(a):
                    bad.append("line %d: dangling §%s" % (i, a))
    # (c) Contents top-level entries agree with ## headings
    # (the Contents lists no subsections, so only the section level is checked)
    m = re.search(r"^## CONTENTS\n(.*?)(?=\n## |\Z)", md_text, re.S | re.M)
    if m:
        for cl in m.group(1).split("\n"):
            cm = re.match(r"^(\d+)\.\s", cl)
            if cm and not exists(cm.group(1)):
                bad.append("Contents entry with no heading: %s"
                           % cl.strip()[:80])
    return bad
# MACHINERY-END


def check_sectionref_sweep():
    """Section-reference hygiene (V10 never-again gate): no placeholder
    headings, every §ref in live prose resolves to a real heading, Contents
    agrees with headings. Honest limits: existence, not correctness (a
    wrong-but-existing address passes); Appendix I and the revision notes
    are verbatim historical record and out of scope; cross-paper citations
    (Paper N §...) are out of scope; §refs inside fenced code blocks
    (script listings) are out of scope -- justification pins are covered by
    F.42's own group-18 pin check, provenance addresses by human audit."""
    md = PAPER.read_text(encoding="utf-8")
    bad = sectionref_prose_violations(md)
    assert not bad, \
        "section-reference hygiene violations:\n" + "\n".join(bad)
    # Liveness: every known-open address must still occur as a bare §ref in
    # live prose; a stale exemption would otherwise admit new defects silently.
    live_prose = "\n".join(l for l in strip_code_fences(md) if l)
    for addr in SECTION_KNOWN_OPEN:
        assert re.search(r"§" + re.escape(addr) + r"(?![0-9.])", live_prose), \
            f"stale SECTION_KNOWN_OPEN entry: §{addr} no longer occurs in live prose"
    # Planted battery: each mutant must be rejected with a witness.
    mut = md.replace("### §9.3 The ladder", "### 9.y The ladder", 1)
    assert any("placeholder heading" in v
               for v in sectionref_prose_violations(mut)), \
        "battery: placeholder '9.y' heading not rejected"
    mut2 = md.replace("falsified in §9.6 — what is claimed",
                      "falsified in §9.99 — what is claimed", 1)
    assert any("dangling §9.99" in v
               for v in sectionref_prose_violations(mut2)), \
        "battery: dangling §9.99 ref not rejected"
    mut3 = md.replace("9. Case Study A — The Nucleus→Atom Ladder",
                      "9. Case Study A — The Nucleus→Atom Ladder\n99. Nonexistent Section", 1)
    assert any("Contents entry" in v
               for v in sectionref_prose_violations(mut3)), \
        "battery: Contents/headings mismatch not rejected"
    print("F.42 PASS: section-reference hygiene clean - no placeholder "
          "headings; every §ref in live prose resolves to a real heading "
          "(Paper-N citations, the §7.x family-generic, Appendix I and the "
          "revision notes, and the two #122 known-open items exempt by "
          "explicit listing); Contents top-level entries agree with ## "
          "headings; planted placeholder-heading, dangling-ref, and "
          "Contents-mismatch mutants rejected.")


def check_planted():
    from copy import deepcopy    # (a) Level-A text carrying l0 -> rejected (token half).
    reg = deepcopy(f38.REGISTRY)
    tgt = next(r for r in reg if r["id"] == "RELATIONAL_ROLE_THEOREM")
    tgt["text"] += " with step length ℓ₀"
    vs = f38.r16_violations(reg)
    assert vs and any("R16" in s and "Level-A" in s for s in vs), \
        "planted Level-A scale token NOT rejected"
    # (b) Level-B scale-token claim with no Level-A ancestor -> rejected
    # (dependency half: Stage P must consume Stage N output).
    mini = [
        {"id": "NATIVE_A", "level": "A", "axioms": ["L1"], "deps": [],
         "deferred": [], "script": "F.32", "obs": False, "text": "native hop count"},
        {"id": "ORPHAN_P", "level": "B", "axioms": [], "deps": [],
         "deferred": [], "script": "F.99", "obs": False,
         "text": "reconstructed distance r = d · ℓ₀"},
    ]
    vs = f38.r16_violations(mini)
    assert vs and any("no Level-A ancestor" in s for s in vs), \
        "planted ancestor-less scale claim NOT rejected"
    # Control: the same claim WITH a native ancestor passes.
    mini[1]["deps"] = ["NATIVE_A"]
    assert not f38.r16_violations(mini), "well-formed scale claim wrongly rejected"
    # (c) Level-A theorem block carrying l0 -> occurrence audit flags it.
    synthetic = ("### §9.9 Fake Theorem [LEVEL A]\n\n"
                 "**Theorem (Fake).** Every configuration advances with "
                 "step length ℓ₀ per tick.\n\n*Proof.* Trivial. ■\n")
    vs, _ = audit_prose_occurrences(synthetic)
    assert vs and any("unjustified" in v for v in vs), \
        "planted Level-A theorem token NOT flagged"
    # (d) the v4 Section 5.1 pattern: Level-A prose sentence carrying m0.
    synthetic2 = ("### §5.1 Fake Section [LEVEL A]\n\n"
                  "Mass quantization fixes the mass of each state at N·m₀.\n")
    vs2, _ = audit_prose_occurrences(synthetic2)
    assert vs2 and any("unjustified" in v for v in vs2), \
        "planted Level-A prose m0 (v4 §5.1 pattern) NOT flagged"
    # Control: a justified occurrence passes the audit.
    synthetic3 = ("### §0.5.z Fake [LEVEL B]\n\n"
                  "where c_phys = ℓ₀/t₀ is defined.\n")
    vs3, _ = audit_prose_occurrences(synthetic3)
    assert not vs3, f"justified occurrence wrongly flagged: {vs3}"
    # (e) planted: a "gradient-biased" sentence smuggled into native prose
    # is flagged by the gradient sweep (v8).
    synthetic4 = ("### §7.9 Fake [LEVEL A]\n\nThe scan uses gradient-biased "
                  "step selection among ports.\n")
    assert gradient_prose_violations(synthetic4), \
        "planted 'gradient' in native prose NOT flagged"
    # Control: the terminology-lock sentence itself is justified.
    synthetic5 = ("### §0.5.x Fake\n\n**Terminology lock on \"gradient\" "
                  "(v8).** The word \"gradient\" does not occur in Stage N.\n")
    assert not gradient_prose_violations(synthetic5), \
        f"lock sentence wrongly flagged: {gradient_prose_violations(synthetic5)}"
    # planted: an "isolated configuration" sentence smuggled into native  # MACHINERY-OK
    # prose is flagged by the void-token sweep.  # MACHINERY-OK
    synthetic_vr = ("### §8.4 Fake [LEVEL A]\n\nForced decay occurs when an "  # MACHINERY-OK
                    "isolated configuration sheds its surplus.\n")  # MACHINERY-OK
    assert void_token_prose_violations(synthetic_vr), \
        "planted void-token sentence NOT flagged"  # MACHINERY-OK
    # Control: the changelog's sweep-mention sentence is justified.  # MACHINERY-OK
    synthetic_vr2 = ("New F.42 void-token sweep ('isolat*', 'vicinity') with "  # MACHINERY-OK
                     "planted-sentence rejection.\n")  # MACHINERY-OK
    assert not void_token_prose_violations(synthetic_vr2), \
        "sweep-mention sentence wrongly flagged"  # MACHINERY-OK
    # MACHINERY-START: planted boundary-as-object test case (v9).
    # The banned tokens below are the test's, not paper content.
    synthetic6 = ("### §7.9 Fake [LEVEL A]\n\nThe fabrication performs boundary "
                  "creation, raising a membrane around the aggregate.\n")
    assert boundary_prose_violations(synthetic6), \
        "planted boundary-as-object sentence in native prose NOT flagged"
    # Planted (v14): an object-positing phrase with no banned noun is still
    # flagged — the phrase-pattern extension of the boundary sweep (R19).
    synthetic6b = ("### §7.9 Fake [LEVEL A]\n\nThe boundary acts on the "
                   "medium, reshaping the scan.\n")
    assert boundary_prose_violations(synthetic6b), \
        "planted boundary phrase sentence in native prose NOT flagged"
    # MACHINERY-END
    # Control: the non-substance rule sentence itself is justified.
    # (Banned tokens below are the test's, not paper content.)
    synthetic7 = ("### §4.3 Fake\n\n**Boundary Non-Substance Rule (v9).** "
                  "Not a membrane, not a container.\n")  # MACHINERY-OK
    assert not boundary_prose_violations(synthetic7), \
        f"rule sentence wrongly flagged: {boundary_prose_violations(synthetic7)}"
    synthetic8 = ("### §9 Fake\n\nIn Stage R the native derivation proceeds, "  # MACHINERY-OK
                  "feeding Stage N directly.\n")  # MACHINERY-OK
    assert register_prose_violations(synthetic8), \
        "planted 'Stage R' sentence not flagged"  # MACHINERY-OK
    synthetic9 = ("**Stage Label Reconciliation Note.** \"Stage R\" is a "  # MACHINERY-OK
                  "deprecated alias for Stage P.\n")  # MACHINERY-OK
    assert not register_prose_violations(synthetic9), \
        f"alias-declaration sentence wrongly flagged: {register_prose_violations(synthetic9)}"
    # (h) planted: a differential-kinematics sentence smuggled into native
    # prose is flagged by the kinematics sweep (v12).
    # (Banned tokens below are the test's, not paper content.)
    synthetic10 = ("### §7.9 Fake [LEVEL A]\n\nThe scan's native acceleration "  # MACHINERY-OK
                   "peaks at the boundary.\n")  # MACHINERY-OK
    assert kinematics_prose_violations(synthetic10), \
        "planted differential-kinematics sentence NOT flagged"  # MACHINERY-OK
    # Control: the terminology-lock sentence itself is justified.
    synthetic11 = ("**Terminology lock on differential kinematics (v12).** "  # MACHINERY-OK
                   "The words \"acceleration\", \"velocity\", and "  # MACHINERY-OK
                   "\"deceleration\" do not occur in Stage N.\n")  # MACHINERY-OK
    assert not kinematics_prose_violations(synthetic11), \
        "lock sentence wrongly flagged"  # MACHINERY-OK
    # (i) planted: a thermodynamic sentence smuggled into native prose
    # is flagged by the thermo sweep (v13).
    # (Banned tokens below are the test's, not paper content.)
    synthetic12 = ("### §7.9 Fake [LEVEL A]\n\nThe boundary temperature drives "  # MACHINERY-OK
                   "the ensemble toward thermal equilibrium.\n")  # MACHINERY-OK
    assert thermo_prose_violations(synthetic12), \
        "planted thermodynamic sentence NOT flagged"  # MACHINERY-OK
    # Control: the terminology-lock sentence itself is justified.
    synthetic13 = ("**Terminology lock on thermodynamic vocabulary (v13).** "  # MACHINERY-OK
                   "The words \"temperature\" and \"entropy\" do not occur "  # MACHINERY-OK
                   "in Stage N.\n")  # MACHINERY-OK
    assert not thermo_prose_violations(synthetic13), \
        "lock sentence wrongly flagged"  # MACHINERY-OK
    # MACHINERY-START: planted teleological test case (v15).
    # The banned phrase below is the test's, not paper content.
    synthetic14 = ("### §12 Fake [LEVEL B]\n\nThe configuration strives "
                   "toward greater resolution.\n")
    assert teleo_prose_violations(synthetic14), \
        "planted teleological sentence NOT flagged"
    # Planted v14(a) purpose-ascribing shape: "designed to" must flag.
    synthetic_teleo_purpose = ("### §7.2 Fake [LEVEL B]\n\nThe scan is designed to "
                   "reduce tension.\n")
    assert teleo_prose_violations(synthetic_teleo_purpose), \
        "planted purpose-ascribing sentence NOT flagged"
    # Control: the firewall sentence itself is justified.
    synthetic15 = ("**Canonical-Ordering Firewall (v15).** The phrase "
                   "\"more work done\" never justifies the ordering.\n")
    assert not teleo_prose_violations(synthetic15), \
        "firewall sentence wrongly flagged"
    # MACHINERY-END
    # MACHINERY-START: planted particle-language test cases (group 17).
    # The defect sentences below are the test's, never paper content.
    # (p1) planted: bare names doing structural work are flagged (P1), and
    # the more-complex/heavier coupling fires P2.
    synthetic_p1 = ("### §12 Fake\n\nThe mesons are more complex than the "
                    "baryons because they are heavier.\n")
    w_p1 = particle_prose_violations(synthetic_p1)
    assert w_p1 and any("[P1]" in w for w in w_p1) \
        and any("[P2" in w for w in w_p1), \
        "planted bare-name/mass-coupling sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p1[0]}")
    # (p2) planted: a mass-hierarchy-from-ordering sentence is flagged (P2).
    synthetic_p2 = ("### §12 Fake\n\nThis mass hierarchy follows directly "
                    "from the complexity ordering.\n")
    w_p2 = particle_prose_violations(synthetic_p2)
    assert w_p2 and any("[P2" in w for w in w_p2), \
        "planted mass-hierarchy sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p2[0]}")
    # (p3) planted: a derives-the-mass sentence is flagged (P1+P2).
    synthetic_p3 = ("### §12 Fake\n\nThe ordering derives the meson masses.\n")
    w_p3 = particle_prose_violations(synthetic_p3)
    assert w_p3 and any("[P1]" in w for w in w_p3) \
        and any("[P2" in w for w in w_p3), \
        "planted derives-the-mass sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p3[0]}")
    # (p4) planted: a bare name at an ordering rung is flagged (P1).
    synthetic_p4 = ("### §12 Fake\n\nThe baryon sits at rung 4 of the "
                    "ordering.\n")
    w_p4 = particle_prose_violations(synthetic_p4)
    assert w_p4 and any("[P1]" in w for w in w_p4), \
        "planted bare-name rung sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p4[0]}")
    # (p5) planted: a ladder phrase is flagged (P3).
    synthetic_p5 = ("### §12 Fake\n\nThe particle ladder runs from photon "
                    "to atoms.\n")
    w_p5 = particle_prose_violations(synthetic_p5)
    assert w_p5 and any("[P3]" in w for w in w_p5), \
        "planted particle-ladder sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p5[0]}")
    # (p5b) planted: a "particle hierarchy" sentence is flagged (P3).
    synthetic_p5b = ("### §12 Fake\n\nThe particle hierarchy runs from photon "
                     "to atoms.\n")
    w_p5b = particle_prose_violations(synthetic_p5b)
    assert w_p5b and any("[P3]" in w for w in w_p5b), \
        "planted particle-hierarchy sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p5b[0]}")
    # (p6) planted: a pin-wearing defect - the firewall's quoted list
    # admits its own span but not a mass-derivation defect in the next
    # clause - is flagged.
    synthetic_p6 = ("### §12.2 Fake\n\nThe standard-account terms "
                    "(\"meson,\" \"baryon,\" \"nucleus,\" \"atom\") are used "
                    "as convenient labels. The meson mass fixes the ordering.\n")
    w_p6 = particle_prose_violations(synthetic_p6)
    assert w_p6 and any("[P1]" in w for w in w_p6), \
        "pin-wearing particle defect NOT flagged"
    print(f"F.42 planted-mutant witness: {w_p6[0]}")
    # (p7) pin-granularity probes: every justification pin probed with a
    # genuine defect wearing that pin in another clause - each probe must
    # flag, proving a pin launders only the span it covers.
    pin_probes = [
        ("pin-1",
         "### §12.2 Fake\n\nIt does not assert that the states are "
         "\"baryons\" in the standard account's sense. The baryon mass "
         "fixes the ordering.\n",
         "pin-1 granularity probe NOT flagged"),
        ("pin-2",
         "### §12.2 Fake\n\nThe standard-account terms (\"meson,\" "
         "\"baryon,\" \"nucleus,\" \"atom\") are convenient labels. "
         "The ordering derives the meson masses.\n",
         "pin-2 granularity probe NOT flagged"),
        ("pin-3",
         "### §12.2 Fake\n\nBare \"meson\"/\"mesons\"/\"baryon\"/\"baryons\" "
         "outside explicitly marked bridge contexts is Register-2. "
         "The baryons are heavier.\n",
         "pin-3 granularity probe NOT flagged"),
        ("pin-4",
         "### §12.2 Fake\n\nBare 'meson'/'baryon' outside the §12.2 "
         "firewall's quoted list is leakage. The meson sits at rung 3.\n",
         "pin-4 granularity probe NOT flagged"),
        ("pin-5",
         "### §14 Fake\n\nPaper 16 owns baryon/meson structural mapping. "
         "The ordering derives the meson masses.\n",
         "pin-5 granularity probe NOT flagged"),
        ("pin-6",
         "### §1 Fake\n\nDoes not pre-empt Paper 16's baryon mapping. "
         "This mass hierarchy follows from the complexity ordering.\n",
         "pin-6 granularity probe NOT flagged"),
        ("pin-7",
         "### §14 Fake\n\nPaper 16's baryon/meson structural mapping is "
         "deferred. The particle ladder runs from photon to atoms.\n",
         "pin-7 granularity probe NOT flagged"),
        ("pin-8",
         "### §15 Fake\n\nPaper 16 owns the baryon mapping. The mesons are "
         "more complex because they are heavier.\n",
         "pin-8 granularity probe NOT flagged"),
        ("pin-9",
         "### §14.4 Fake\n\nbare 'meson'/'baryon' (outside the hyphenated "
         "'-like' hedge) are swept. The baryon sits at rung 4.\n",
         "pin-9 granularity probe NOT flagged"),
        ("pin-10",
         "### §16 Fake\n\nthe \"mesons → baryons\" ordering repaired to "
         "\"-like\" forms. The ordering derives the meson masses.\n",
         "pin-10 granularity probe NOT flagged"),
        ("pin-11",
         "### §9 Fake\n\nThe ladder is an encounter sequence, not a particle "
         "hierarchy. The particle ladder runs from photon to atoms.\n",
         "pin-11 granularity probe NOT flagged"),
        ("pin-12",
         "### §14.4 Fake\n\nladder phrases ('particle ladder', 'mass sequence', "
         "'particle hierarchy', 'complexity ladder') are swept. The mass "
         "sequence runs from photon to atoms.\n",
         "pin-12 granularity probe NOT flagged"),
        ("pin-13",
         "### §16 Fake\n\nP3 now covers \"particle hierarchy\" and \"complexity "
         "ladder\". The ordering derives the meson masses.\n",
         "pin-13 granularity probe NOT flagged"),
    ]
    for _tag, _synth, _msg in pin_probes:
        _w = particle_prose_violations(_synth)
        assert _w, _msg
        print(f"F.42 planted-mutant witness ({_tag}): {_w[0]}")
    # Controls: the "-like" hedge, the pinned deferral, the firewall
    # witness, and the firewall sentence all pass.
    assert not particle_prose_violations(
        "### §12 Fake\n\nmeson-like configurations (three nodes, "
        "transient) precede baryon-like ones.\n"), \
        "'-like' control wrongly flagged"
    assert not particle_prose_violations(
        "### §14 Fake\n\nPaper 16 owns baryon/meson structural mapping.\n"), \
        "deferral control wrongly flagged"
    assert not particle_prose_violations(
        "### §12.3 Fake\n\na nucleus can be heavier than an atom with "
        "fewer nodes.\n"), \
        "firewall-witness control wrongly flagged"
    assert not particle_prose_violations(
        "### §12.2 Fake\n\nIt does not assert that the states in category 4 "
        "are \"baryons\" in the standard account's sense.\n"), \
        "firewall-sentence control wrongly flagged"
    # Script-side: the F37 class-name phrases pass the exemption; a defect
    # wearing a phrase is still flagged.
    assert particle_script_line_ok(
        "F37_complexity_ordering.py",
        "        (\"M6 baryon res 1->0 (tie-break destroyed)\","), \
        "F37 phrase line wrongly rejected"
    assert not particle_script_line_ok(
        "F37_complexity_ordering.py",
        "M6 baryon res 1->0 (tie-break destroyed); the meson mass fixes "
        "the ordering"), \
        "phrase-wearing defect NOT flagged"
    # MACHINERY-END
    # MACHINERY-START: planted sequential-attraction test cases (group 18).
    # The defect sentences below are the test's, never paper content.
    # (u1) planted: a residual bare-rung sequential-attraction sentence is
    # flagged (Q2).
    synthetic_u1 = ("### §9 Fake\n\nEach rung of the ladder attracts in turn.\n")
    w_u1 = seqattr_prose_violations(synthetic_u1)
    assert w_u1 and any("[Q2" in w for w in w_u1), \
        "planted bare-rung sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_u1[0]}")
    # (u1b) planted: the explicit all-attracting compound is flagged (Q1).
    synthetic_u1b = ("### §9 Fake\n\nThe all-attracting ladder incorporates "
                     "every state.\n")
    w_u1b = seqattr_prose_violations(synthetic_u1b)
    assert w_u1b and any("[Q1]" in w for w in w_u1b), \
        "planted all-attracting sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_u1b[0]}")
    # (u2) planted: a hostile-reader sequential-attraction sentence is
    # flagged (Q2).
    synthetic_u2 = ("### §9 Fake\n\nThe chain proceeds by attraction at every "
                    "step.\n")
    w_u2 = seqattr_prose_violations(synthetic_u2)
    assert w_u2 and any("[Q2" in w for w in w_u2), \
        "planted hostile-reader sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_u2[0]}")
    # (u3) planted: an arrow-caption asserting repeated attraction is
    # flagged (Q2+Q4).
    synthetic_u3 = ("### G.5 Fake\n\nFigure 5 — the ladder: nucleus → state → "
                    "aggregate, attraction at every rung.\n")
    w_u3 = seqattr_prose_violations(synthetic_u3)
    assert w_u3 and any("[Q4]" in w for w in w_u3), \
        "planted arrow-caption sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_u3[0]}")
    # (u3b)-(u3d) planted: the Q3 sequential-narration shapes are flagged.
    for _tag, _synth in [
        ("u3b",
         "### §9 Fake\n\nState 9 incorporates, then attracts the next state.\n"),
        ("u3c",
         "### §9 Fake\n\nNext, attraction: the enlarged aggregate takes "
         "State 2.\n"),
        ("u3d",
         "### §9 Fake\n\nAttractions happen in sequence along the ladder.\n"),
    ]:
        _w = seqattr_prose_violations(_synth)
        assert _w and any("[Q3" in w for w in _w), \
            f"planted Q3-shape sentence ({_tag}) NOT flagged"
        print(f"F.42 planted-mutant witness ({_tag}): {_w[0]}")
    # (u4) control: the falsification statement passes (pin-admitted).
    assert not seqattr_prose_violations(
        "### §9.5 Fake\n\nCase A: the sequential all-attraction reading is "
        "falsified in §9.5.\n"), \
        "falsification control wrongly flagged"
    # (u5) controls: first-encounter claims carry no covered trigger.
    assert not seqattr_prose_violations(
        "### §9.2 Fake\n\nAll 27 first encounters attract.\n"), \
        "first-encounter control wrongly flagged"
    assert not seqattr_prose_violations(
        "### §9.5 Fake\n\n27 of 27 attract against the pristine nucleus.\n"), \
        "first-encounter control (27 of 27) wrongly flagged"
    # (u6) planted: a pin-wearing defect - the denial pin admits its own
    # span but not a sequential-attraction defect in the next clause - is
    # flagged.
    synthetic_u6 = ("### §9.5 Fake\n\nThe sequential all-attraction ladder is "
                    "therefore **not** claimed. Each rung of the ladder "
                    "attracts in turn.\n")
    w_u6 = seqattr_prose_violations(synthetic_u6)
    assert w_u6 and any("[Q2" in w for w in w_u6), \
        "pin-wearing sequential-attraction defect NOT flagged"
    print(f"F.42 planted-mutant witness: {w_u6[0]}")
    # (u7) pin-granularity probes: every justification pin probed with a
    # genuine defect wearing that pin in another clause - each probe must
    # flag, proving a pin launders only the span it covers.
    seqattr_pin_probes = [
        ("pin-1",
         "### §9.5 Fake\n\nCase A: the sequential all-attraction reading is "
         "falsified in §9.5. Each rung of the ladder attracts in turn.\n",
         "pin-1 granularity probe NOT flagged"),
        ("pin-2",
         "### §1 Fake\n\nHere the sequential all-attraction reading of the "
         "ladder is falsified in §9.5, yet every step attracts.\n",
         "pin-2 granularity probe NOT flagged"),
        ("pin-3",
         "### §9 Fake\n\nThe reading asks: incorporate State 1, then State 2 "
         "against the enlarged aggregate, then State 3, and so on through "
         "State 9 — does every rung attract? The distinguished chain shows "
         "all rungs attract.\n",
         "pin-3 granularity probe NOT flagged"),
        ("pin-4",
         "### §9.5 Fake\n\nThe sequential all-attraction ladder is therefore "
         "**not** claimed. The chain attracts at every step.\n",
         "pin-4 granularity probe NOT flagged"),
        ("pin-5",
         "### §14 Fake\n\nThe registry notes the sequential all-attraction "
         "reading falsified; still, each rung attracts.\n",
         "pin-5 granularity probe NOT flagged"),
        ("pin-6",
         "### §9 Fake\n\nZero all-attraction orders: 0 of 362,880 per seed. "
         "Every rung attracts.\n",
         "pin-6 granularity probe NOT flagged"),
        ("pin-7",
         "### §9 Fake\n\nEvery incorporation order contains at least one "
         "forced decay. Because attraction is res = 0. The chain attracts "
         "at every step.\n",
         "pin-7 granularity probe NOT flagged"),
        ("pin-8",
         "### §9 Fake\n\nWhat is Level A is the TH-independence result: the "
         "all-attraction partition (res = 0) does not move with TH; each "
         "step attracts.\n",
         "pin-8 granularity probe NOT flagged"),
        ("pin-9",
         "### §16 Fake\n\nThe build records zero all-attraction orders under "
         "every seed. All rungs attract.\n",
         "pin-9 granularity probe NOT flagged"),
        ("pin-10",
         "### §9 Fake\n\nWhere incorporation then occurs — the §9.x chain's "
         "attraction steps, each a junction completion — it is Alteration "
         "(i). Each rung of the ladder attracts in turn.\n",
         "pin-10 granularity probe NOT flagged"),
        ("pin-11",
         "### §14.4 Fake\n\nThe sweep: Q1: the \"all-attraction\" compound "
         "(also \"all-attracting\"); Q2: a universal quantifier "
         "('all'/'every'/'each') joined to a chain-noun "
         "('rung'/'step'/'chain'/'sequence'/'order'/'ladder'/'series') and "
         "the attraction verb, in either word order; Q3: sequential-"
         "narration shapes ('then attracts', 'next, attraction', "
         "'attractions happen in sequence', the chain attracting 'at every "
         "step'); Q4: an incorporation arrow-chain carrying a chain-noun and "
         "an attraction word. Every rung attracts in turn.\n",
         "pin-11 granularity probe NOT flagged"),
    ]
    for (_tag, _synth, _msg), (_pstr, _why) in zip(seqattr_pin_probes,
                                                  SEQATTR_JUSTIFICATIONS):
        # the pin alone admits its own triggers (span-scoped self-admission)
        assert not seqattr_prose_violations(
            "### Fake\n\n" + _pstr + "\n"), \
            f"{_tag} pin does not admit its own span"
        _w = seqattr_prose_violations(_synth)
        assert _w, _msg
        print(f"F.42 planted-mutant witness ({_tag}): {_w[0]}")
    # Script-side: the F46 result-reporting phrases pass the exemption; a
    # defect wearing a phrase is still flagged.
    assert seqattr_script_line_ok(
        "F46_caseA_ladder.py",
        "    print(\"     per seed, INCLUDING all-attraction nulls. "
        "Distributions below.\")"), \
        "F46 phrase line wrongly rejected"
    assert not seqattr_script_line_ok(
        "F46_caseA_ladder.py",
        "    print(\"     per seed, INCLUDING all-attraction nulls. "
        "Each rung of the ladder attracts in turn.\")"), \
        "phrase-wearing defect NOT flagged"
    # MACHINERY-END
    # MACHINERY-START: planted encounter-geometry test cases (group 19).
    # The defect sentences below are the test's, never paper content.
    # (eg-r1)-(eg-r3) planted: the dropped "relay position" token and its
    # variants are flagged.
    synthetic_eg_r1 = ("### §8.5 Fake\n\nThe shell is the least relay position "
                       "at which Y presents a port.\n")
    w_eg_r1 = eg_relay_prose_violations(synthetic_eg_r1)
    assert w_eg_r1, "planted 'relay position' sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_r1[0]}")
    synthetic_eg_r2 = ("### §4.6 Fake\n\nThe relay-position metric orders the "
                       "shells.\n")
    w_eg_r2 = eg_relay_prose_violations(synthetic_eg_r2)
    assert w_eg_r2, "planted 'relay-position' sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_r2[0]}")
    synthetic_eg_r3 = ("### §8.5 Fake\n\nRelayposition data is not native.\n")
    w_eg_r3 = eg_relay_prose_violations(synthetic_eg_r3)
    assert w_eg_r3, "planted 'relayposition' sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_r3[0]}")
    # Control: the sanctioned "relay-hop" wording passes.
    assert not eg_relay_prose_violations(
        "### §8.5 Fake\n\nThe encounter distance is the least relay-hop "
        "shell.\n"), \
        "'relay-hop' control wrongly flagged"
    # (eg-d1)-(eg-d2) planted: direction-flip sentences - "X presents a
    # port to Y's scan" under an X->Y orientation token - are flagged.
    synthetic_eg_d1 = ("### §8.5 Fake\n\nIn the X→Y scan orientation, X presents "
                       "a port to Y's scan at τ.\n")
    w_eg_d1 = eg_dirflip_prose_violations(synthetic_eg_d1)
    assert w_eg_d1, "planted direction-flip sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_d1[0]}")
    synthetic_eg_d2 = ("### §8.5 Fake\n\nIn the A→B scan orientation, A presents "
                       "an open boundary port to B's scan at τ.\n")
    w_eg_d2 = eg_dirflip_prose_violations(synthetic_eg_d2)
    assert w_eg_d2, "planted direction-flip variant NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_d2[0]}")
    # Controls: the defined direction clause, the §4.6 posture clause,
    # and an orientation-free presents-clause all pass.
    assert not eg_dirflip_prose_violations(
        "### §8.5 Fake\n\nIn the X→Y scan orientation, Y presents a port to "
        "X's scan at τ.\n"), \
        "defined direction clause wrongly flagged"
    assert not eg_dirflip_prose_violations(
        "### §4.6 Fake\n\nA presents a non-O boundary port toward B.\n"), \
        "posture clause wrongly flagged"
    assert not eg_dirflip_prose_violations(
        "### §8.5 Fake\n\nB presents a port to A's scan at τ.\n"), \
        "orientation-free presents-clause wrongly flagged"
    # (eg-c1)-(eg-c3) planted: d=1-exclusive pinning and primitive
    # treatment of the defined term are flagged.
    synthetic_eg_c1 = ("### §3.2 Fake\n\nConfigurations occupy encounter "
                       "geometry iff d = 1.\n")
    w_eg_c1 = eg_consistency_prose_violations(synthetic_eg_c1)
    assert w_eg_c1 and any("d=1-iff" in w for w in w_eg_c1), \
        "planted d=1-iff sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_c1[0]}")
    synthetic_eg_c1b = ("### §3.2 Fake\n\nEncounter geometry is exactly d = 1 "
                        "for the pair.\n")
    w_eg_c1b = eg_consistency_prose_violations(synthetic_eg_c1b)
    assert w_eg_c1b and any("d=1-exclusive" in w for w in w_eg_c1b), \
        "planted d=1-exclusive sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_c1b[0]}")
    synthetic_eg_c2 = ("### §3.2 Fake\n\nThe primitive encounter geometry needs "
                       "no definition.\n")
    w_eg_c2 = eg_consistency_prose_violations(synthetic_eg_c2)
    assert w_eg_c2 and any("primitive-treatment" in w for w in w_eg_c2), \
        "planted primitive-treatment sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_c2[0]}")
    synthetic_eg_c3 = ("### §9 Fake\n\nEncounter geometry is assumed for the "
                       "chain.\n")
    w_eg_c3 = eg_consistency_prose_violations(synthetic_eg_c3)
    assert w_eg_c3 and any("primitive-treatment" in w for w in w_eg_c3), \
        "planted is-assumed sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_c3[0]}")
    # Pin-wearing probes: a banned shape wearing a legitimate pin in
    # another clause is still flagged - the pin admits the line's
    # legitimate span, never the defect.
    synthetic_eg_p1 = ("### §4.6 Fake\n\nconfigurations A and B occupy encounter "
                       "geometry, and A presents a port; the primitive encounter "
                       "geometry needs no definition.\n")
    w_eg_p1 = eg_consistency_prose_violations(synthetic_eg_p1)
    assert w_eg_p1 and any("primitive-treatment" in w for w in w_eg_p1), \
        "pin-wearing primitive defect NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_p1[0]}")
    synthetic_eg_p2 = ("### §8.5 Fake\n\nthe derived shell-profile value for the "
                       "encounter geometry at hand; still, encounter geometry "
                       "iff d = 1.\n")
    w_eg_p2 = eg_consistency_prose_violations(synthetic_eg_p2)
    assert w_eg_p2 and any("d=1-iff" in w for w in w_eg_p2), \
        "pin-wearing d=1-iff defect NOT flagged"
    print(f"F.42 planted-mutant witness: {w_eg_p2[0]}")
    # Controls: the definition's own "iff" carries no d = 1 pinning, a
    # legitimate denial of primitive status passes the negation guard,
    # and a pinned usage passes the full check.
    assert not _eg_banned_shapes(
        "Configurations X and Y occupy encounter geometry at tick τ (in the "
        "X→Y direction) iff at least one of the following holds."), \
        "definition-shaped 'iff' wrongly flagged"
    assert not _eg_banned_shapes(
        "No new primitive is adopted: encounter geometry is no primitive, "
        "every term resolves to registered labels."), \
        "negation-guard control wrongly flagged"
    assert not eg_consistency_prose_violations(
        "### §4.6 Fake\n\nAt tick τ, configurations A and B occupy encounter "
        "geometry, and A presents a port.\n"), \
        "pinned usage wrongly flagged"
    # MACHINERY-END

    # MACHINERY-START: planted arity test cases (v16).
    # The banned phrases below are the test's, not paper content.
    synthetic16 = ("### §4.1 Fake [LEVEL A]\n\nEach junction is completed "
                   "between two ports, consuming one port per node.\n")
    assert arity_prose_violations(synthetic16), \
        "planted 'between two ports' sentence NOT flagged"
    # Control: the repaired §4.1 sentence passes.
    synthetic17 = ("### §4.1 Fake\n\nEach junction is completed among two "
                   "or more ports.\n")
    assert not arity_prose_violations(synthetic17), \
        "repaired arity sentence wrongly flagged"
    # (l) planted: a universal pairwise-formula sentence in native prose
    # is flagged; the scoped pairwise-corollary sentence passes.
    synthetic18 = ("### §4.3 Fake [LEVEL A]\n\nThe boundary port count of "
                   "every aggregate is B = 6N − 2J.\n")
    assert arity_prose_violations(synthetic18), \
        "planted universal 6N-2J sentence NOT flagged"
    synthetic19 = ("### §4.3 Fake\n\npairwise corollary: for pairwise "
                   "junctions B = 6N − 2J.\n")
    assert not arity_prose_violations(synthetic19), \
        "pairwise-corollary sentence wrongly flagged"
    # MACHINERY-END
    # (m) planted: a bridge-word sentence smuggled into native prose is  # MACHINERY-OK
    # flagged by the magnitude bridge-word sweep, while the reservation  # MACHINERY-OK
    # sentence passes. (Banned phrase below is the test's, not paper  # MACHINERY-OK
    # content.)  # MACHINERY-OK
    synthetic_m = ("### §8.5 Fake [LEVEL A]\n\nThe interaction magnitude "  # MACHINERY-OK
                   "e·S(d) scales with proximity as 1/(4d^2+2).\n")  # MACHINERY-OK
    w_m = bridge_magnitude_prose_violations(synthetic_m)  # MACHINERY-OK
    assert w_m, "planted bridge-word sentence NOT flagged"  # MACHINERY-OK
    print(f"F.42 planted-mutant witness: {w_m[0]}")  # MACHINERY-OK
    synthetic_m2 = ("The term 'interaction magnitude' is reserved for the "  # MACHINERY-OK
                    "Stage P reconstruction layer.\n")  # MACHINERY-OK
    w_m2 = bridge_magnitude_prose_violations(synthetic_m2)  # MACHINERY-OK
    assert not w_m2, "reservation sentence wrongly flagged"  # MACHINERY-OK
    # MACHINERY-START: planted label-terminology test cases.
    # The banned phrases below are the test's, never paper content.
    # (n) planted: the exact excised D.3 sentence - Paper-11 labels called
    # "dependency axioms" - is flagged by the label-terminology sweep.
    synthetic_n = ("### D.3 Fake\n\nPaper 11 introduces three new dependency "
                   "axioms (L5-P11, L6-P11, L7-P11) for its role primitives.\n")
    w_n = label_prose_violations(synthetic_n)
    assert w_n, "planted label-misuse sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_n[0]}")
    # (o) planted: the exact excised section 0.5 sentence - the stale v2
    # "role primitives" root - is flagged.
    synthetic_n3 = ("### §0.5 Fake\n\nPaper 11's derivations establish the "
                    "role primitives required by downstream modules.\n")
    w_n3 = label_prose_violations(synthetic_n3)
    assert w_n3, "planted stale-root sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_n3[0]}")
    # (p) planted: a fresh synthetic "L5-P11 axiom" sentence - same defect
    # shape, new wording - is flagged.
    synthetic_np = ("### §3.1 Fake [LEVEL A]\n\nThe L5-P11 dependency axiom "
                    "grounds the relational role theorem.\n")
    w_np = label_prose_violations(synthetic_np)
    assert w_np, "planted fresh label-misuse sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_np[0]}")
    # Controls: the changelog remediation-history sentence (which quotes the
    # excised phrases as history) is justified; legitimate inherited-axiom
    # and honest-taxonomy sentences carry no banned token.
    synthetic_n2 = ("87. **Label-terminology remediation.** Appendix D.3 said "
                    "\"Paper 11 introduces three new dependency axioms\" - "
                    "directly inconsistent with the no-new-axiom architecture.\n")
    assert not label_prose_violations(synthetic_n2), \
        "remediation-history sentence wrongly flagged"
    synthetic_nc = ("### §0.5 Fake\n\nThe Hardware Topology Axiom is "
                    "inherited from Paper 10.\n")
    assert not label_prose_violations(synthetic_nc), \
        "inherited-axiom sentence wrongly flagged"
    synthetic_nd = ("### D.3 Fake\n\nPaper 11 introduces three new "
                    "dependency labels for its role machinery.\n")
    assert not label_prose_violations(synthetic_nd), \
        "honest-taxonomy sentence wrongly flagged"
    # MACHINERY-END
    # MACHINERY-START: planted modal-collapse test cases (group 15).
    # The defect sentences below are the test's, never paper content.
    # (q) planted: the exact old §4.2 unindexed sentences - the modal
    # collapses the remediation removed - are flagged.
    synthetic_q1 = ("### §4.2 Fake\n\nState 7 (X,O,O) is a simple state and "
                    "is unresolved (u > 0), so it plays the active role.\n")
    w_q1 = modal_collapse_prose_violations(synthetic_q1)
    assert w_q1, "planted old-L361 collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_q1[0]}")
    synthetic_q2 = ("### §4.2 Fake\n\nThe complex configuration's boundary "
                    "is active.\n")
    w_q2 = modal_collapse_prose_violations(synthetic_q2)
    assert w_q2, "planted old-L363 collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_q2[0]}")
    synthetic_q3 = ("### §4.2 Fake\n\nThe complex configuration's interior "
                    "is passive.\n")
    w_q3 = modal_collapse_prose_violations(synthetic_q3)
    assert w_q3, "planted old-L364 collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_q3[0]}")
    # (r) planted: an adjectival collapse - the same defect in attributive
    # form - is flagged.
    synthetic_r = ("### §4.2 Fake\n\nThe passive interior resolves first.\n")
    w_r = modal_collapse_prose_violations(synthetic_r)
    assert w_r, "planted adjectival collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_r[0]}")
    # (s) planted: temporal-clause and deictic tokens are no longer
    # accepted as encounter indexes - a bare assertion under "when",
    # "here", or "there" is flagged.
    synth_15s = ("### §9 Fake\n\nWhen the junction closes, the aspect is "
                 "passive.\n")
    w_15s = modal_collapse_prose_violations(synth_15s)
    assert w_15s, "planted temporal-clause collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15s[0]}")
    synth_15t = ("### §9 Fake\n\nHere the configuration is active. "
                 "There the node is passive.\n")
    w_15t = modal_collapse_prose_violations(synth_15t)
    assert len(w_15t) == 2, "planted deictic-clause collapses NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15t[0]}")
    # (u) planted: bare "at tick" without a named R is no longer an index
    # exemption.
    synth_15u = ("### §9 Fake\n\nAt tick 3 the boundary is passive.\n")
    w_15u = modal_collapse_prose_violations(synth_15u)
    assert w_15u, "planted bare-at-tick collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15u[0]}")
    # (v) planted: copula-free actuality verbs - the index exemption is
    # verb-sensitive, so "encounter" does not excuse "stays"/"remains"/
    # "becomes" forms.
    synth_15v = ("### §9 Fake\n\nThe aspect stays active through the "
                 "encounter.\n")
    w_15v = modal_collapse_prose_violations(synth_15v)
    assert w_15v, "planted copula-free (stays) collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15v[0]}")
    synth_15v2 = ("### §9 Fake\n\nThe configuration remains passive.\n")
    w_15v2 = modal_collapse_prose_violations(synth_15v2)
    assert w_15v2, "planted copula-free (remains) collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15v2[0]}")
    synth_15v3 = ("### §9 Fake\n\nThe aspect becomes active at the "
                  "boundary.\n")
    w_15v3 = modal_collapse_prose_violations(synth_15v3)
    assert w_15v3, "planted copula-free (becomes) collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15v3[0]}")
    # (w) planted: the gerund form - role actuality asserted with no
    # encounter index.
    synth_15w = ("### §9 Fake\n\nPlaying the passive role wholesale, the "
                 "aggregate presents no open boundary.\n")
    w_15w = modal_collapse_prose_violations(synth_15w)
    assert w_15w, "planted gerund collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15w[0]}")
    # (x) planted: extended adjectival forms - the collapse in attributive
    # form over the noun list.
    synth_15x = ("### §9 Fake\n\nThe passive junction completes first. "
                 "The active node presents its port.\n")
    w_15x = modal_collapse_prose_violations(synth_15x)
    assert len(w_15x) == 2, \
        "planted extended-adjectival collapses NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15x[0]}")
    # (y) planted: the contrastive not-but form - its "not" is part of the
    # defect shape, not a negation exemption.
    synth_15y = ("### §9 Fake\n\nIt is not the active role but the passive "
                 "role.\n")
    w_15y = modal_collapse_prose_violations(synth_15y)
    assert w_15y, "planted contrastive collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_15y[0]}")
    # Hardening battery: new defect shapes the extended patterns must flag.
    # Each is a genuine collapse; the sentences are the test's, never paper
    # content.
    # (hb1) P3par participial form: unindexed actuality in a participial
    # parenthetical.
    synth_hb1 = ("### §9 Fake\n\nThe aspect (having been active at the "
                 "boundary) resolves first.\n")
    w_hb1 = modal_collapse_prose_violations(synth_hb1)
    assert w_hb1, "planted participial-parenthetical collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_hb1[0]}")
    # (hb2) past-tense copula: was/were carries the same collapse as is/are.
    synth_hb2 = ("### §9 Fake\n\nThe configuration was passive.\n")
    w_hb2 = modal_collapse_prose_violations(synth_hb2)
    assert w_hb2, "planted past-tense copula collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_hb2[0]}")
    # (hb3) adverb-interrupted copula: the adverb does not excuse the
    # assertion.
    synth_hb3 = ("### §9 Fake\n\nThe boundary is always active.\n")
    w_hb3 = modal_collapse_prose_violations(synth_hb3)
    assert w_hb3, "planted adverb-interrupted copula collapse NOT flagged"
    print(f"F.42 planted-mutant witness: {w_hb3[0]}")
    # (hb4) the line-wide-scope killer: a bare assertion sharing its line
    # with a bare "encounter" elsewhere is flagged now that the index token
    # is the named "encounter R" form.
    synth_hb4 = ("### §9 Fake\n\nThe electron is active; the encounter "
                 "geometry is irrelevant.\n")
    w_hb4 = modal_collapse_prose_violations(synth_hb4)
    assert w_hb4, "planted line-wide-scope killer NOT flagged"
    print(f"F.42 planted-mutant witness: {w_hb4[0]}")
    # (hb5) pin-granularity probes: every justification pin probed with a
    # genuine defect wearing that pin in another clause - each probe must
    # flag, proving a pin launders only the span it covers.
    pin_probes = [
        ("pin-1",
         "### §9 Fake\n\n\"electrons are active, photons are passive.\" "
         "The node is passive.\n",
         "pin-1 granularity probe NOT flagged"),
        ("pin-2",
         "### §9 Fake\n\n\"aspect a plays the active role\" states the "
         "rule; the boundary is active.\n",
         "pin-2 granularity probe NOT flagged"),
        ("pin-3",
         "### §9 Fake\n\nThe active role attaches to the aspect performing "
         "the mechanical shove toward alignment; the passive role attaches "
         "to the aspect serving as the alignment reference. Where both "
         "aspects are unresolved, both are active and the passive role is "
         "unoccupied. The electron is active.\n",
         "pin-3 granularity probe NOT flagged"),
        ("pin-4",
         "### §9 Fake\n\nThe node is active; Passive-capability is not the "
         "passive role.\n",
         "pin-4 granularity probe NOT flagged"),
        ("pin-5",
         "### §9 Fake\n\nThe separation holds in its strongest form: the "
         "same selector W that is passive in R₂ at τ₂ was active in R₁ at "
         "τ₁ — the F.39 relationality witness proves actual opposite roles "
         "in named encounters.\nThe node is passive.\n",
         "pin-5 granularity probe NOT flagged"),
        ("pin-6",
         "### §9 Fake\n\nplaying the passive role wholesale, the aggregate "
         "is active.\n",
         "pin-6 granularity probe NOT flagged"),
        ("pin-7",
         "### §9 Fake\n\nA configuration that was active in one encounter "
         "may be passive in the next; the node is passive.\n",
         "pin-7 granularity probe NOT flagged"),
        ("pin-8",
         "### §9 Fake\n\nAny statement of the form \"configurations of type "
         "T are always active/passive.\" The node is passive.\n",
         "pin-8 granularity probe NOT flagged"),
        ("pin-9",
         "### §9 Fake\n\nNote that an aspect is active in an encounter iff "
         "it presents unmatched integers (u > 0), passive iff it serves as "
         "the resolved reference. The node is passive.\n",
         "pin-9 granularity probe NOT flagged"),
        ("pin-10",
         "### §9 Fake\n\nStandard physics also assigns intrinsic passivity: "
         "a test particle is passive by definition. The node is passive.\n",
         "pin-10 granularity probe NOT flagged"),
    ]
    for _tag, _synth, _msg in pin_probes:
        _w = modal_collapse_prose_violations(_synth)
        assert _w, _msg
        print(f"F.42 planted-mutant witness ({_tag}): {_w[0]}")
    # Controls: the modal capability form, the encounter-indexed form,
    # the hyphen-guarded *-capable form, the negated corollary, and the
    # indexed W witness all pass.
    assert not modal_collapse_prose_violations(
        "### §5.3 Fake\n\nA resolved simple state can play the passive role.\n"), \
        "modal capability control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §4.2 Fake\n\nIn an encounter R where it presents its open "
        "port, it plays the active role.\n"), \
        "encounter-indexed control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §8.6 Fake\n\nThe node is (passive-capable at the center).\n"), \
        "hyphen-guarded control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §3.1 Fake\n\nPassive-capability is not the passive role.\n"), \
        "negated corollary control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §3.1 Fake\n\nThe same selector W that is passive in R₂ at τ₂ "
        "was active in R₁ at τ₁.\n"), \
        "indexed W-witness control wrongly flagged"
    # (z) Controls: R3 (the broadened R-digit index) exempts a plays-the-role
    # assertion against the lock's own actuality form; the gerund form
    # passes when encounter-indexed; "can" + copula-free verb is NOT a
    # sanctioned capability form, so it must FLAG (documented diagnostic,
    # not a rejection).
    assert not modal_collapse_prose_violations(
        "### §4.2 Fake\n\nIt plays the active role in R3.\n"), \
        "R3-indexed control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §8.6 Fake\n\nnon-O seeking aspects playing the active role "
        "in R\n"), \
        "encounter-indexed gerund control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §4.2 Fake\n\nIn R, aspect b plays the passive role\n"), \
        "R-indexed control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §4.2 Fake\n\nIn R, the passive role is played by aspect b.\n"), \
        "R-indexed passive-voice control wrongly flagged"
    assert not modal_collapse_prose_violations(
        "### §4.2 Fake\n\nHaving played the active role in R, aspect a "
        "resolves.\n"), \
        "R-indexed participial control wrongly flagged"
    d_15 = modal_collapse_prose_violations(
        "### §9 Fake\n\nThe aspect can stay active.\n")
    assert d_15, "'can stay active' wrongly exempted by the modal guard"
    print(f"F.42 diagnostic (flags by design): {d_15[0]}")
    # MACHINERY-END
    # MACHINERY-START: planted canonical-enumeration test cases (#120).
    # The defect sentences below are the test's, never paper content.
    # (ce-1) planted: the V8 defect shape - "canonical enumeration order"
    # carrying the stale §12.4 pointer - is flagged.
    synthetic_ce1 = ("### §9.1 Fake [LEVEL A]\n\nEach junction completion "
                     "resolves pairs in canonical enumeration order "
                     "(§12.4).\n")
    w_ce1 = canonenum_prose_violations(synthetic_ce1)
    assert w_ce1, "planted stale-pointer enumeration sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_ce1[0]}")
    # (ce-2) planted: "canonically-first" carrying a wrong-section pointer
    # is flagged.
    synthetic_ce2 = ("### §8.2 Fake\n\nT zeroes out the canonically-first "
                     "admissible pair (§8.2).\n")
    w_ce2 = canonenum_prose_violations(synthetic_ce2)
    assert w_ce2, "planted wrong-pointer canonically-first NOT flagged"
    print(f"F.42 planted-mutant witness: {w_ce2[0]}")
    # (ce-3) planted: a bare unanchored "canonical enumeration order" use
    # outside the definition home is flagged.
    synthetic_ce3 = ("### §9.1 Fake\n\nResolution proceeds in canonical "
                     "enumeration order.\n")
    w_ce3 = canonenum_prose_violations(synthetic_ce3)
    assert w_ce3, "planted unanchored enumeration sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_ce3[0]}")
    # (ce-4) planted: a wrong-section pointer inside the §7.x definition
    # home is still flagged (the section exemption does not launder a
    # wrong pointer).
    synthetic_ce4 = ("### §7.3 Fake\n\nOne T-action resolves the "
                     "canonically-first admissible pair (§12.1).\n")
    w_ce4 = canonenum_prose_violations(synthetic_ce4)
    assert w_ce4, "planted wrong-pointer inside §7.x NOT flagged"
    print(f"F.42 planted-mutant witness: {w_ce4[0]}")
    # Controls: the §7.5 definition, the §11.2 anchored pointer, and the
    # §7.3 proof use all pass.
    assert not canonenum_prose_violations(
        "### §7.5 Fake\n\n**Definition (Canonical Position Enumeration).** "
        "Junction positions are indexed 1..k.\n"), \
        "enumeration definition wrongly flagged"
    assert not canonenum_prose_violations(
        "### §11.2 Fake\n\nEach step consumes one pair in canonical "
        "enumeration order (§7.5).\n"), \
        "anchored §11.2 pointer wrongly flagged"
    assert not canonenum_prose_violations(
        "### §7.3 Fake\n\nOne T-action resolves exactly one complementary "
        "pair at the canonically-first admissible position.\n"), \
        "§7.3 proof use wrongly flagged"
    # MACHINERY-END
    # MACHINERY-START: planted continuum-adverb test cases.
    # (s) planted: a "continuously" sentence smuggled into native prose is
    # flagged by the continuum-adverb sweep. (Defect sentences below are
    # the test's, never paper content.)
    synthetic_s = ("### §7.9 Fake [LEVEL A]\n\nThe scan runs continuously, "
                   "presenting unmatched integers.\n")
    w_s = continuum_prose_violations(synthetic_s)
    assert w_s, "planted 'continuously' sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_s[0]}")
    # (t) planted: a "continuous" sentence smuggled into native prose is
    # flagged by the continuum-adverb sweep.
    synthetic_t = ("### §7.9 Fake [LEVEL A]\n\nThe resolution completes "
                   "through a continuous shove.\n")
    w_t = continuum_prose_violations(synthetic_t)
    assert w_t, "planted 'continuous' sentence NOT flagged"
    print(f"F.42 planted-mutant witness: {w_t[0]}")
    # Controls: the Stage N forbidden-list sentence and the §7.4 denial
    # sentence pass; the two docstring ban statements pass the script-line
    # exemption; a defect wearing a ban phrase is still flagged.
    synthetic_s3 = ("### §0.5 Fake\n\n**Stage N — Native Exact Register.** "
                    "Forbidden operations: limits, continuous variables, "
                    "float arithmetic.\n")
    assert not continuum_prose_violations(synthetic_s3), \
        "forbidden-list sentence wrongly flagged"
    synthetic_s4 = ("### §7.4 Fake\n\nNo observer, no continuous limit, no "
                    "external context is required.\n")
    assert not continuum_prose_violations(synthetic_s4), \
        "denial sentence wrongly flagged"
    assert continuum_script_line_ok(
        "F37_complexity_ordering.py",
        "continuous progress, no purpose, no degree of resolvedness. "
        "Resolution"), \
        "F37 ban-statement line wrongly rejected"
    assert continuum_script_line_ok(
        "F48_consolidation_paths.py",
        "- Stage N throughout: finite, discrete, integer/rational, "
        "relational, deterministic. No continuous calculus, no new "
        "primitives."), \
        "F48 ban-statement line wrongly rejected"
    assert not continuum_script_line_ok(
        "F37_complexity_ordering.py",
        "no continuous progress, but the scan runs continuously"), \
        "ban-phrase exemption probe NOT flagged"
    # MACHINERY-END
    # MACHINERY-START: planted teleological test case (v15).
    # The banned phrase below is the test's, not paper content.
    synthetic14 = ("### §12 Fake [LEVEL B]\n\nThe configuration strives "
                   "toward greater resolution.\n")
    assert teleo_prose_violations(synthetic14), \
        "planted teleological sentence NOT flagged"
    # Planted v14(a) purpose-ascribing shape: "designed to" must flag.
    synthetic_teleo_purpose = ("### §7.2 Fake [LEVEL B]\n\nThe scan is designed to "
                   "reduce tension.\n")
    assert teleo_prose_violations(synthetic_teleo_purpose), \
        "planted purpose-ascribing sentence NOT flagged"
    # Control: the firewall sentence itself is justified.
    synthetic15 = ("**Canonical-Ordering Firewall (v15).** The phrase "
                   "\"more work done\" never justifies the ordering.\n")
    assert not teleo_prose_violations(synthetic15), \
        "firewall sentence wrongly flagged"
    # MACHINERY-END


check_vocab_list()
print("F.42 PASS: native vocabulary list contains zero physical-scale tokens.")
check_scripts()
n_script_sources = len(sorted(HERE.glob("F*.py")))
print(f"F.42 PASS: all {n_script_sources} script sources clean (count computed "
      "from the F*.py glob at run time) - scale tokens only in firewall "
      "machinery; no non-display float usage.")
check_registry_dependency_half()
print("F.42 PASS: R16 dependency half holds over the registry.")
check_prose_occurrences()
print("F.42 PASS: every physical-scale token in the paper's prose is "
      "individually justified (occurrence principle).")
check_gradient_sweep()
print("F.42 PASS: 'gradient' sweep clean - token occurs only in the "
      "terminology lock, the registry description, and the changelog; "
      "all script sources clean.")
check_continuum_sweep()
print("F.42 PASS: continuum-adverb sweep clean - 'continuously'/'continuous' "
      "occur only in the curated justifications (terminology locks, "
      "firewalls, register definitions, comparison contexts, this "
      "description, changelog); all script sources clean.")
check_boundary_sweep()
print("F.42 PASS: boundary-object sweep clean - phantom verb and substance "
      "tokens occur only where the ban is stated; all script sources clean.")
check_register_sweep()
print("F.42 PASS: register-token sweep clean - R tokens occur only in the "
      "reconciliation note, the registry description, and the changelog; "
      "all script sources clean.")
check_void_token_sweep()
print("F.42 PASS: void-token sweep clean - 'isolat*'/'vicinity' occur only in "  # MACHINERY-OK
      "the §0.5 design constraint, the registry description, and the "  # MACHINERY-OK
      "changelog; all script sources clean.")  # MACHINERY-OK
check_kinematics_sweep()
print("F.42 PASS: differential-kinematics sweep clean - the tokens occur only "
      "in the terminology lock, the registry description, and the changelog; "
      "all script sources clean.")
check_thermo_sweep()
print("F.42 PASS: thermo sweep clean - the tokens occur only in the "
      "terminology lock, the Paper-12 firewall and deferral sections, the "
      "registry description, and the changelog; all script sources clean.")
check_teleo_sweep()
print("F.42 PASS: teleology sweep clean - scalar/teleological phrases occur "
      "only in the Canonical-Ordering Firewall and the changelog; all "
      "script sources clean.")
check_arity_sweep()
print("F.42 PASS: arity sweep clean - the pairwise formula and 'between two "
      "ports' occur only in the §4.3 pairwise corollary, the registry "
      "descriptions, and the changelog; all script sources clean.")
check_bridge_magnitude_sweep()
print("F.42 PASS: magnitude bridge-word sweep clean - the bridge word occurs "
      "only in the §8.5 reservation sentence, this description, and the "
      "changelog; all script sources clean.")
check_esd_term_consistency()
print("F.42 PASS: every native use of 'engagement-weighted scan allocation' "
      "resolves to e·S(d) - exactly one definition line; all other uses "
      "in §8.5 or alongside e·S(d).")
check_label_sweep()
print("F.42 PASS: label-terminology sweep clean - 'axiom' misapplied to "
      "Paper-11 labels and the stale v2 root phrase occur only in the "
      "changelog remediation history; all script sources clean.")
check_modal_collapse_sweep()
print("F.42 PASS: modal-collapse sweep clean - none of the covered collapse "
      "patterns occurs in prose or script sources; every justification "
      "entry is load-bearing and span-scoped. Known limits (human-audit "
      "territory): indexed-but-modally-unearned sentences, adjectival nouns "
      "outside the covered lists, quoted counter-examples beyond the "
      "admitted list, cross-sentence anaphora, adverbs outside the curated "
      "list, and index-token line-sharing.")
check_particle_sweep()
print("F.42 PASS: particle-language sweep clean - bare 'meson'/'baryon', "
      "mass-derivation shapes, and ladder phrases occur only in the §12.2 "
      "firewall's quoted list, the §12.2 register table, the Paper-16 "
      "bridge-scope deferrals, this description, and the changelog; all "
      "script sources clean.")
check_seqattr_sweep()
print("F.42 PASS: sequential-attraction sweep clean - the covered "
      "universal-sequential-attraction patterns occur only in the §9.6 "
      "falsification statements, the §9.3 sweep-result machinery, the §4.6 "
      "incorporation-mechanics sentence, this description, the Appendix H "
      "(H.4) claim-impact statement, and the "
      "changelog; the F46 result-reporting phrases are "
      "admitted content-specifically.")
check_encounter_geometry_sweep()
print("F.42 PASS: encounter-geometry sweep clean - the dropped 'relay position' "
      "token occurs nowhere in prose or script sources; no direction-flip "
      "('X presents a port to Y's scan' under X->Y) occurs in prose or script "
      "sources; 'encounter geometry' occurrences avoid d=1-exclusive pinning "
      "and primitive treatment and each matches a curated justification pin "
      "(the §3.2 definition block, the §§0.5.x/0.5.w entries, the §3.3 proof, "
      "the §§4.5/4.6 usage block, the §8.5 shell-profile line, the §11.2 "
      "environment line, the Appendix E rows, the Appendix H falsification "
      "statement, the Appendix J row, the changelog entries, this description); "
      "the §4.6 posture clause is distinguished, not flagged.")
check_canonenum_sweep()
print("F.42 PASS: canonical-enumeration sweep clean - 'canonically-first' / "
      "'canonical enumeration order' / 'canonical positions' occur only in "
      "the §7.x definition home, in sentences carrying the §7.5 pointer, or "
      "in the changelog; no script source outside the sweep's own marked "
      "machinery carries the stale pointer.")
check_sectionref_sweep()
print("F.42 PASS: section-reference sweep clean - no placeholder headings; "
      "every §N.M cross-reference resolves to a real heading.")
check_v13_sweep()
print("F.42 PASS: V13 reading-aid sweep clean - the six §12.1 B-descriptors "
      "each carry '(reading aid; not derived)'; a planted dropped flag is "
      "rejected.")
check_g21_sweep()
print("F.42 PASS: group-21 scope gates clean - unscoped completeness "
      "language ('arbitrary finite k' / 'complete (native) transition "
      "rule', case-insensitive) occurs only with pairwise scope in the "
      "same paragraph or under a span-scoped scope pin (§7.5 Scope note, "
      "§7.5 Proof. pin); every 'triple-convergence' occurrence carries the "
      "a Paper-2-§8.1-naming citation or a §7.6 pointer (the §7.6 heading "
      "carries its own pointer; a paragraph omitting Paper 2 §8.1 is "
      "rejected); "
      "σ is never generalized beyond (A, B) -- subscript, plain-spelling, "
      "unicode-subscript, and plain-word three-component forms rejected; "
      "unpinned 'lab notes' in live prose rejected under the seven span-scoped pins; "
      "the changelog and fenced listings are excluded as dated record; "
      "planted unscoped-completeness, uncited-triple-convergence, "
      "three-component-σ, and unpinned-lab-note mutants are rejected and "
      "the controls pass.")
check_g22_sweep()
print("F.42 PASS: group-22 spatial-physical noun sweep clean - the curated "
      "spatial-physical patterns ('concrete physical', 'physical response', "
      "'pushed'/'pushes'/'pushing', 'displacement', 'geometric alignment', "
      "'moves through space', 'motion') occur in live prose only with an "
      "explicit Stage-P/observational-shadow marking or a span-scoped "
      "justification pin (the §7.2 bridge sentence's Stage-P reservation, "
      "the §8.2 'Observational shadow' paragraph, the §6.3 negation, the "
      "§8.5 canonical-family 'taxicab displacement' modeling context, the "
      "Papers-6–8 'Rest/motion/inertia' topic summary, the E.2 "
      "SHOVE_DIRECTION registry-text row, the H.4 SHOVE_DIRECTION impact "
      "statement, the Appendix-J SHOVE_DIRECTION theorem-map row); the "
      "changelog, fenced listings, and the §14.2 F.42 "
      "bullet's own description line are excluded; planted "
      "spatial-physical sentences are rejected (including an out-of-pin-"
      "span probe) and the pinned controls pass.")
check_g23_sweep()
print("F.42 PASS: group-23 universal-quantifier sweep clean - the §0.5 "
      "front-matter carries no unbadged universal-quantifier trigger "
      "('monotonically', 'for all N', noun-scoped 'no * anywhere', "
      "'at any scale', 'every * at any *'); bare 'no explicit regime "
      "switch' clause-absence is rejected (same-sentence R15 + "
      "conservation-forcing-chain proof exempt); planted unbadged-"
      "monotonicity and clause-absence mutants are rejected and the "
      "repaired-Universality, honest-proof, and vocabulary-scope controls "
      "pass.")
check_g24_sweep()
print("F.42 PASS: group-24 listing-import self-containment clean - every "
      "embedded listing's imports resolve to the standard library, a "
      "fellow embedded F-module, or a draft-root file declared in its "
      "runner note and hash-pinned in the manifest; planted undeclared-"
      "import, hash-mismatch, and declared-but-unmanifested mutants are "
      "rejected and the F.46, stdlib-only, and fellow-embedded controls "
      "pass.")

check_planted()
print("F.42 PASS: planted Level-A scale token rejected; planted ancestor-less "
      "scale claim rejected; planted Level-A theorem/prose tokens flagged; "
      "planted 'gradient' in native prose flagged; planted boundary-as-object "
      "sentence flagged; planted 'Stage R' sentence flagged and alias "  # MACHINERY-OK
      "declaration passes; planted differential-kinematics sentence flagged "
      "and lock sentence passes; planted thermodynamic sentence flagged "
      "and lock sentence passes; planted teleological and purpose-ascribing "
      "sentences flagged and firewall sentence passes; planted void-token sentence flagged; planted binary-junction sentences "
      "flagged and corollary sentence passes; planted bridge-word sentence flagged (witness printed above) "
      "and reservation sentence passes; planted label-misuse sentences flagged (witnesses printed above) "
      "and remediation-history sentence passes; planted modal-collapse sentences flagged (witnesses printed above) "
      "and modal/R3-indexed/gerund-indexed/R-indexed (plain, passive-voice, participial)/hyphen-guarded/negated/W-witness controls pass, "
      "hardening-battery mutants and pin-granularity probes flagged (witnesses printed above), "
      "and the 'can' + copula-free diagnostic flags by design; planted 'continuously'/'continuous' sentences flagged (witnesses printed above) "
      "and forbidden-list/denial sentences pass, docstring ban statements pass, ban-phrase probe flagged; planted particle-language mutants flagged (witnesses printed above), pin-wearing defect and pin-granularity probes flagged, '-like'/deferral/firewall-witness/firewall controls pass, F37 phrase lines pass and phrase-wearing defect flagged; well-formed reconstruction passes; planted sequential-attraction mutants flagged (witnesses printed above), pin-wearing defect and pin-granularity probes flagged, falsification/first-encounter controls pass, F46 phrase lines pass and phrase-wearing defect flagged; planted 'relay position'/'relay-position'/'relayposition' sentences flagged (witnesses printed above) and the 'relay-hop' control passes; planted direction-flip sentences flagged (witnesses printed above) and the defined direction clause, the §4.6 posture clause, and the orientation-free presents-clause pass; planted d=1-iff, d=1-exclusive, and primitive-treatment sentences flagged (witnesses printed above), pin-wearing probes flagged, the negation-guard control passes, and the definition-shaped 'iff' sentence plus a pinned usage pass; "
      "planted canonical-enumeration stale-pointer, wrong-pointer, and unanchored sentences flagged "
      "(witnesses printed above) and the §7.5 definition, §11.2 anchored-pointer, and §7.3 proof-use "
      "controls pass.")
