
# The saturated-center premise is INHERITED, not derived here (Paper 2
# §11.1, verified #109): a saturated center has no unresolved integer at
# the center, so a saturated simple state presents zero unmatched integers
# at the contact. Declared in INPUT_PROVENANCE as cited-paper.
_SATURATED_CENTER_SOURCE = "Paper 2 §11.1"

# The aggregate construction data (port sets, fixture rows) is imported
# from F.33-F.35 (their INPUT_PROVENANCE blocks declare it); it is not a
# module-level literal here, so it carries no entry in this block.
INPUT_PROVENANCE = {
    "A": {"class": "arbitrary-representative", "independence": "representative configuration A"},
    "B": {"class": "arbitrary-representative", "independence": "representative configuration B"},
    "TUPLES": {"class": "control", "note": "test tuple fixtures"},
    "n": {"class": "arbitrary-representative", "independence": "representative size"},
    "_SATURATED_CENTER_SOURCE": {"class": "cited-paper",
        "source": "Paper 2 §11.1 (saturated-center premise: no unresolved integer at the center)"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port'],
    "notes": "encounter enumeration over aspect-port states; the port kind only.",
}
#!/usr/bin/env python3
"""F.39 — Relational Role Theorem encounter enumeration (v19).

§4.2 defines the roles relationally over a resolution relationship
R = (a, p, b, q, tau): the aspect, the open port of a presented at tau,
the aspect serving as reference, its port q presented at p, the tick.

  active(a, R)  iff  u(a,tau) > 0  AND  a presents the open port p at tau
  passive(b, R) iff  b serves as the resolved reference in R.

The checkable structural core of "serves as the resolved reference" is:
u(b,tau) = 0 at the contact q, while a presents unmatched integers at p
(the encounter shape the section 7 shove operates on). The shove
dynamics themselves belong to section 7 / F.36 and are not modeled here.

An aspect is a PERSISTENT SELECTOR (C, s) (section 4.2). The selector
never changes; only its per-tick port values change. R is well-formed
iff p is a port of a, q a port of b, both evaluated at the same tick,
and p is open (values_a[p] != 0), per the section 3.2 definition;
malformed R is rejected, never assigned a role.

Regression guard: the u-only surrogate (role from u alone, R ignored)
is planted and shown to diverge from the section 4.2 predicates on a
well-formed encounter where the cited port is closed although u > 0.

v27 additions (append-only; pre-existing checks untouched):

(a) Role-cut 4-witness check (section 4.2): the four realizable
    simple/complex x active/passive combinations are each instantiated
    per the section 4.2 predicates and asserted realized.

(b) State-1 / State-9 passive-role witnesses (section 5.3): the
    whole-aspects of State 1 (inside X,X,X electron or Y,Y,Y positron)
    and State 9 (inside O,O,O) are instantiated per the section 4.2
    predicates, with u = 0 derived from the single native ground -- the
    inherited saturated-center premise, Paper 2 section 11.1 (verified
    #109: States 9 and 1 "have no unresolved integer at their centers
    to receive a docking partner; their geometric structure is
    settled") -- and asserted to play the passive role.

(c) Per-port u bookkeeping over the worked aggregates (a), (b), (c)
    (section 6.2): the PORT SETS -- which ports are boundary and which
    are junction-consumed -- are derived from the F.33-F.35 aggregate
    constructions themselves (imported, not hand-mirrored), and the u
    VALUES are read from those scripts' own fixture rows (non-O boundary
    port -> u = 1, seeking; O-valued boundary port -> u = 0, open but
    non-seeking per the repaired section 6.2; junction-consumed ports ->
    u = 0). The check verifies the bookkeeping partition: the port sets
    are disjoint and exhaustive, matching the Appendix B port counts;
    the fixture-read u pattern (seeking exactly on the non-O boundary
    ports) is asserted per port; a seeking boundary port-aspect is then
    shown to satisfy the section 4.2 active role predicate (section 6.2
    role claim -- definitional step, see the note below), while an
    O-valued boundary port-aspect cannot satisfy the active predicate's
    antecedent (its cited port presents no unmatched integer, so the
    encounter citing it as the presenting side is malformed per section
    3.2 and no role attaches).

Note on the "if seeking then active" step: it is the paper's section
4.2 definition APPLIED (active(a,R) iff u(a,tau) > 0 AND a presents
the open port p at tau), not a machine-derived result. The script
checks that a fixture-read seeking aspect meets the definition's
antecedents; the consequent then follows by definition. Seeking is
read from the fixtures, not constructed: only non-O boundary ports
count as seeking.
"""

A = ("C", "s")
B = ("C", "s2")

TUPLES = []
for n in (1, 2):
    def gen(prefix, n):
        if n == 0:
            TUPLES.append(tuple(prefix))
            return
        for v in (-1, 0, 1):
            gen(prefix + [v], n - 1)
    gen([], n)


def u(state):
    return sum(1 for v in state[1] if v != 0)


def ports_of(state):
    return range(len(state[1]))


def well_formed(R):
    """Section 3.2: p a port of a, q a port of b, same tick, p open."""
    a, p, b, q, tau = R
    return (p in ports_of(a) and q in ports_of(b)
            and a[2] == tau and b[2] == tau
            and a[1][p] != 0)


def active(R, side):
    """Section 4.2 active: u > 0 AND the cited port is presented open."""
    assert well_formed(R), "role predicate applied to malformed R"
    a, p, b, q, tau = R
    x, r = (a, p) if side == "a" else (b, q)
    return u(x) > 0 and x[1][r] != 0


def passive(R, side):
    """Section 4.2 passive (structural core): resolved at the cited
    contact while the partner presents unmatched integers at its
    contact -- the encounter shape in which this side serves as the
    resolved reference."""
    assert well_formed(R), "role predicate applied to malformed R"
    a, p, b, q, tau = R
    x, r = (a, p) if side == "a" else (b, q)
    y, s = (b, q) if side == "a" else (a, p)
    return x[1][r] == 0 and y[1][s] != 0


def role_of_surrogate(state, R):
    """Pre-v19 behavior: role from u alone, R ignored. Planted only to
    be caught diverging from the section 4.2 predicates."""
    return "active" if u(state) > 0 else "passive"


def states(selector):
    return [(selector, t, tau) for tau in (0, 1) for t in TUPLES]


def encounters():
    out = []
    for a in states(A):
        for b in states(B):
            for tau in (0, 1):
                if a[2] != tau or b[2] != tau:
                    continue
                for p in ports_of(a):
                    for q in ports_of(b):
                        R = (a, p, b, q, tau)
                        if well_formed(R):
                            out.append(R)
    return out


# ---------------------------------------------------------------------------
# v27 additions (append-only): role-cut witnesses (a), State-1/State-9
# passive-role witnesses (b), per-port u over aggregates (a)/(b)/(c) (c).
# ---------------------------------------------------------------------------


def check_role_cut_witnesses():
    """(a) Section 4.2 Role Cut Independence: all four simple/complex x
    active/passive combinations are realized, each instantiated per the
    section 4.2 role predicates. The four witnesses are the proof's own
    four items."""
    a_open = (("C_open", ("whole",)), (1, 0), 0)   # unresolved partner
    b_ref = (("C_ref", ("whole",)), (0,), 0)       # resolved reference

    # 1. simple + active: State 7 (X,O,O) -- simple state, unresolved.
    a7 = (("C7", ("whole",)), (1, 0, 0, 0, 0, 0), 0)
    R1 = (a7, 0, b_ref, 0, 0)
    assert well_formed(R1)
    assert active(R1, "a"), "simple+active: State-7 whole-aspect must be active"

    # 2. simple + passive: State 1 electron (X,X,X) -- simple, fully resolved.
    b1 = (("C1", ("whole",)), (0, 0, 0, 0, 0, 0), 0)
    assert u(b1) == 0, "State 1 must be fully resolved"
    R2 = (a_open, 0, b1, 0, 0)
    assert well_formed(R2)
    assert passive(R2, "b"), "simple+passive: State-1 whole-aspect must be passive"

    # 3. complex + active: bonded aggregate's boundary port-aspect (unresolved).
    a_port = (("Cagg", ("port", 0)), (1,), 0)
    R3 = (a_port, 0, b_ref, 0, 0)
    assert well_formed(R3)
    assert active(R3, "a"), "complex+active: boundary port-aspect must be active"

    # 4. complex + passive: bonded aggregate's interior junction-aspect,
    #    resolved by its bonding (section 4.1).
    b_junc = (("Cagg", ("junction", "j0")), (0, 0, 0), 0)
    assert u(b_junc) == 0, "interior junction must be resolved"
    R4 = (a_open, 0, b_junc, 0, 0)
    assert well_formed(R4)
    assert passive(R4, "b"), "complex+passive: interior junction-aspect must be passive"

    print("F.39 PASS: role-cut 4-witness -- simple+active, simple+passive, "
          "complex+active, complex+passive all realized per section 4.2.")


def whole_aspect_presented(triple, ground):
    """Derive a simple state's whole-aspect presented unmatched-integer
    tuple from its inside triple under the stated native ground.
    triple: the section 5.1 inside triple — ("X","X","X") or ("Y","Y","Y")
    for State 1 (electron / positron), ("O","O","O") for State 9.
    ground: "saturated_center" (States 1 and 9) — the inherited Paper 2
    section 11.1 premise (verified #109): no unresolved integer at the
    center to receive a docking partner; the geometric structure is
    settled. Declared, not derived here.
    A simple state is a single node: six ports (section 4.5 step 2), all
    boundary. The presented tuple is derived from the triple under the
    named ground (the triple gate below rejects unsaturated triples);
    u() computes the unmatched count from the derived tuple."""
    n_ports = 6
    if ground == "saturated_center":
        # INHERITED premise (_SATURATED_CENTER_SOURCE, Paper 2 section 11.1,
        # verified #109): no unresolved integer at the center, so zero
        # unmatched integers to present. Declared, not derived here.
        assert triple in (("X", "X", "X"), ("Y", "Y", "Y"), ("O", "O", "O")), \
            "saturated-center premise applies to saturated triples only"
        return (0,) * n_ports
    raise AssertionError("unknown native ground: %r" % (ground,))


def check_simple_reference_witnesses():
    """(b) Section 5.3 Simple State Reference Role: a simple state with a
    saturated center (States 1 and 9) can play the passive role as a
    reference for another configuration's resolution. State-1 inside triple
    is (X,X,X) electron or (Y,Y,Y) positron; State-9's inside triple is
    (O,O,O) (section 5.1 enumeration). Whole-aspects -- the
    inventory-sanctioned kind for simple states (section 4.2) -- are
    instantiated; u = 0 is derived for both from the inherited
    saturated-center premise (Paper 2 section 11.1, verified #109: no
    unresolved integer at the center to receive a docking partner; the
    geometric structure is settled); the passive role is asserted per the
    section 4.2 predicates."""
    a_open = (("C_open", ("whole",)), (1, 0), 0)   # unresolved partner
    for label, triple, ground in (("C1", ("X", "X", "X"), "saturated_center"),
                                  ("C1p", ("Y", "Y", "Y"), "saturated_center"),
                                  ("C9", ("O", "O", "O"), "saturated_center")):
        presented = whole_aspect_presented(triple, ground)
        whole = ((label, ("whole",)), presented, 0)
        assert u(whole) == 0, \
            f"{label} whole-aspect must present u = 0 at the contact"
        R = (a_open, 0, whole, 0, 0)
        assert well_formed(R)
        assert passive(R, "b"), \
            f"{label} (inside {','.join(triple)}) must play the passive role"
    print("F.39 PASS: State-1 (electron and positron) and State-9 "
          "whole-aspects (u=0 from the saturated-center premise) play the "
          "passive role per section 5.3.")


# Aggregate constructions, derived from the F.33-F.35 construction tables
# (Appendix B): nodes x 6 ports; junctions consume one port per
# participating node. The port SETS come from the scripts' own tables
# (imported -- no hand-mirrored transcription, so the sets cannot drift
# silently); the expected counts are the paper's documented Appendix B
# counts, kept as independent literals (the check). For (b) the branch-B
# (complementary-pair) construction is used: the paper's stated convention.
import F33_aggregate_a as _f33
import F34_aggregate_b as _f34
import F35_aggregate_c as _f35


def _aggregate_spec(label, triples, junctions, state_rows, expect):
    """Port inventory for one worked aggregate, derived from its script's
    own tables: node names -> indices; (node, port) -> "boundary" or
    ("junction", jid); per-port categorical values from the script's own
    fixture rows. A port booked by two junctions is rejected."""
    index = {name: i for i, name in enumerate(sorted(triples))}
    kinds = {}
    for i in range(len(index)):
        for p in range(6):
            kinds[(i, p)] = "boundary"
    for jid, d in junctions.items():
        for (v, p) in d["ports"]:
            assert kinds[(index[v], p)] == "boundary", "port double-booked"
            kinds[(index[v], p)] = ("junction", jid)
    values = {(index[v], p): state_rows[triples[v]][p]
              for v in triples for p in range(6)}
    return {"label": label, "kinds": kinds, "values": values,
            "expect": expect}


def _aggregate_specs():
    return {
        # (a): 3 nodes, 1 three-way center junction (F.33: arity 3).
        "a": _aggregate_spec("aggregate-(a)", _f33.AGG_A_TRIPLES,
                             _f33.AGG_A_JUNCTIONS, _f33.STATE_ROWS,
                             (15, 3, 4)),
        # (b): 2 nodes, 1 shared junction (F.34 branch B: 2 ports).
        "b": _aggregate_spec("aggregate-(b)/branch-B",
                             _f34.AGG_B_B_TRIPLES, _f34.AGG_B_B_JUNCTION,
                             _f34.STATE_ROWS, (10, 2, 3)),
        # (c): 3 nodes in a line, 2 shared junctions (F.35: 2x2 ports).
        "c": _aggregate_spec("aggregate-(c)", _f35.AGG_C_FIXTURE_TRIPLES,
                             _f35.AGG_C_JUNCTIONS, _f35.STATE_ROWS,
                             (14, 4, 5)),
    }


def check_aggregate_port_bookkeeping():
    """(c) Section 6.2 Complex Configuration Boundary is Seeking: for each
    worked aggregate (a), (b), (c) of Appendix B, the PORT SETS and the
    per-port u VALUES both come from the F.33-F.35 constructions
    (imported tables; u read from each script's own fixture rows --
    non-O boundary port: u = 1, seeking; O-valued boundary port: u = 0,
    open but non-seeking per the repaired section 6.2; junction-consumed
    ports: u = 0). Assert the partition is disjoint and exhaustive
    against the Appendix B counts; assert the fixture-read u pattern
    (seeking exactly on the non-O boundary ports); then the definitional
    step: a seeking boundary aspect presenting its port satisfies the
    section 4.2 active predicate, while an O-valued boundary aspect
    cannot satisfy the active predicate's antecedent -- "if seeking then
    active" applies the paper's definition, it is not a machine-derived
    result. An interior junction-aspect is shown to satisfy the passive
    predicate."""
    b_ref = (("C_ref", ("whole",)), (0,), 0)       # resolved reference
    a_open = (("C_open", ("whole",)), (1, 0), 0)   # unresolved partner
    parts = []
    for key, spec in _aggregate_specs().items():
        kinds = spec["kinds"]
        values = spec["values"]
        expect_boundary, expect_consumed, expect_interior = spec["expect"]
        all_ports = set(kinds)
        boundary = {k for k, v in kinds.items() if v == "boundary"}
        consumed = {k for k, v in kinds.items() if v != "boundary"}
        # Partition: disjoint and exhaustive; no double counting.
        assert boundary & consumed == set(), f"aggregate ({key}): overlap"
        assert boundary | consumed == all_ports, f"aggregate ({key}): gap"
        assert len(boundary) == expect_boundary, \
            f"aggregate ({key}) boundary count"
        assert len(consumed) == expect_consumed, \
            f"aggregate ({key}) consumed count"
        # Interior aspects = nodes + distinct shared junctions (F.33-F.35).
        jids = {v[1] for v in kinds.values() if v != "boundary"}
        n_nodes = len({n for (n, p) in kinds})
        assert n_nodes + len(jids) == expect_interior, \
            f"aggregate ({key}) interior count"
        # Per-port u, READ FROM the script fixtures (not constructed
        # uniformly): non-O boundary ports seeking (u = 1); O-valued
        # boundary ports open but non-seeking (u = 0); consumed ports
        # resolved (u = 0).
        seeking, non_seeking = set(), set()
        for port in boundary:
            if values[port] == "O":
                non_seeking.add(port)
                aspect = ((f"Cagg_{key}", ("port",) + port), (0,), 0)
                assert u(aspect) == 0, \
                    f"aggregate ({key}): O-valued boundary port {port} " \
                    "must be non-seeking"
            else:
                seeking.add(port)
                aspect = ((f"Cagg_{key}", ("port",) + port), (1,), 0)
                assert u(aspect) == 1, \
                    f"aggregate ({key}): non-O boundary port {port} " \
                    "must be seeking"
        assert seeking, f"aggregate ({key}): no seeking boundary port"
        assert non_seeking, \
            f"aggregate ({key}): no O-valued boundary port in fixtures"
        for jid in jids:
            jports = sorted(k for k, v in kinds.items()
                            if v == ("junction", jid))
            aspect = ((f"Cagg_{key}", ("junction", jid)), (0,) * len(jports), 0)
            assert u(aspect) == 0, f"aggregate ({key}): junction {jid} not resolved"
        # Section 6.2 role claim (DEFINITIONAL): a seeking boundary
        # aspect presenting its port satisfies the section 4.2 active
        # predicate -- "if seeking then active" is the paper's definition
        # applied, not a machine-derived result.
        bn, bp = sorted(seeking)[0]
        seek = ((f"Cagg_{key}", ("port", bn, bp)), (1,), 0)
        R1 = (seek, 0, b_ref, 0, 0)
        assert well_formed(R1)
        assert active(R1, "a"), f"aggregate ({key}): seeking boundary aspect must be active"
        # An O-valued boundary aspect cannot satisfy the active
        # predicate's antecedent: its cited port presents no unmatched
        # integer, so the encounter citing it as the presenting side is
        # malformed per section 3.2 (no role attaches).
        on, op = sorted(non_seeking)[0]
        o_aspect = ((f"Cagg_{key}", ("port", on, op)), (0,), 0)
        R_o = (o_aspect, 0, b_ref, 0, 0)
        assert not well_formed(R_o), \
            f"aggregate ({key}): O-valued boundary port {(on, op)} " \
            "must not present as the active side"
        # The resolved interior serves as the passive reference.
        jid0 = sorted(jids)[0]
        jports = sorted(k for k, v in kinds.items() if v == ("junction", jid0))
        interior = ((f"Cagg_{key}", ("junction", jid0)), (0,) * len(jports), 0)
        R2 = (a_open, 0, interior, 0, 0)
        assert well_formed(R2)
        assert passive(R2, "b"), f"aggregate ({key}): interior aspect must be passive"
        parts.append(f"({key}) {len(boundary)} boundary / {len(consumed)} "
                     f"consumed ({len(seeking)} seeking, "
                     f"{len(non_seeking)} non-seeking O-valued)")
    print("F.39 PASS: aggregates " + ", ".join(parts) +
          " -- port sets and u values from the F.33-F.35 constructions "
          "(fixture-read: non-O boundary u=1 seeking, O-valued boundary "
          "u=0 non-seeking); seeking aspects satisfy the active definition "
          "in encounters per section 6.2; O-valued boundary aspects cannot "
          "satisfy the active antecedent.")


def main():
    Rs = encounters()

    # 1. Totality (definitional): the section 4.2 predicates are
    #    complementary by construction (active needs u > 0 at a presented
    #    port; passive needs the cited contact at 0 while the partner
    #    presents unmatched integers), so every well-formed R assigns each
    #    side exactly one role. This runs the predicates over the full
    #    well-formed space but discriminates nothing beyond definitional
    #    complementarity -- checks 2-4 below are the discriminating ones.
    saw_active = saw_passive = False
    for R in Rs:
        for side in ("a", "b"):
            acts, passs = active(R, side), passive(R, side)
            assert acts != passs, f"indeterminate role in {R} side {side}"
            saw_active |= acts
            saw_passive |= passs
    assert saw_active and saw_passive, "a role was never realized"

    # 2. Relationality witness: ONE persistent selector, opposite roles
    #    across ticks, under the real section 4.2 predicates.
    W = ("C", "s")
    S1 = (W, (1, 0), 0)
    S2 = (W, (0, 0), 1)
    assert S1[0] == S2[0] == W, "selector must be literally identical"
    R1 = (S1, 0, (B, (0, 0), 0), 0, 0)
    R2 = ((B, (1, 0), 1), 0, S2, 0, 1)
    assert well_formed(R1) and well_formed(R2)
    assert active(R1, "a"), "W must be active in R1 per section 4.2"
    assert passive(R2, "b"), "W must be passive in R2 per section 4.2"

    # 3. Planted surrogate failure: u-only labeling diverges from the
    #    section 4.2 predicates on a well-formed encounter. Here b has
    #    u > 0, but the cited port q = 1 is closed, so per section 4.2
    #    b is passive -- while the surrogate says active.
    R_div = ((A, (1, 0), 0), 0, (B, (1, 0), 0), 1, 0)
    assert well_formed(R_div)
    assert role_of_surrogate(R_div[2], R_div) == "active"
    assert passive(R_div, "b") and not active(R_div, "b")
    # The surrogate's mislabeling is caught: it disagrees with section 4.2.

    # 4. No role caching across ticks (section 3.3 re-derivation check).
    cached = active(R1, "a")
    assert cached and not active(R2, "b"), "planted cache must mismatch"
    # A cache would replay "active" for W at tick 1; re-derivation says not.

    # v27 additions (append-only): all pre-existing checks above unchanged.
    check_role_cut_witnesses()
    check_simple_reference_witnesses()
    check_aggregate_port_bookkeeping()

    print(f"F.39 OK: {len(Rs)}-encounter totality run (definitional, not "
          f"discriminating); witness {W} active@tick0 passive@tick1; "
          f"surrogate divergence caught; cache rejected")


if __name__ == "__main__":
    main()