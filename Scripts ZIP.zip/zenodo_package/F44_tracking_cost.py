
INPUT_PROVENANCE = {
    "CU_BOUND": {"class": "control", "note": "sweep input: bound on free nonnegative shares (§7.3 states nonnegativity, no numeric bound; box verification plus linearity covers the cone)"},
    "KS": {"class": "control", "note": "sweep input: k values"},
    "VALS": {"class": "control", "note": "sweep input: share values"},
    "c": {"class": "arbitrary-representative", "independence": "representative cost value"},
    "checked": {"class": "control", "note": "check counter"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port'],
    "notes": "c(config_label, value) over port-value pairs; no aspect entity exists in this script's code.",
}
#!/usr/bin/env python3
"""Paper 11 - F.44: the port-level tracking-cost lemma and the relief
theorem's port-value composition (§7.3).

An s²-contribution assignment c(cfg, value) satisfies the Paper-8
mechanism constraints iff
    c(cfg, 0) = 0     (no tilt -> nothing to track -> cost exactly zero;
                       Paper 8 §2)
    c(cfg, v) >= 0    (tracking cost is a diverted circa share; v = ±1)
for every configuration label.  Total s² = sum of per-port contributions
(R15 exact-finite-sum rule, §4.1).

Proved domain (R23): port-value pairs (config_label, value) -- two labels,
three values. No aspect entity exists in this script's code: the lemma it
checks is the port-level tracking-cost lemma, not the aspect-level reading
(the aspect-level aggregation is asserted as Lemma 2 (Aspect Aggregation)
in §7.3 — author-authorized 2026-10-05, implemented and audited by
F.33–F.35, not machine-proved). The Paper-8 shape (c(cfg,0)=0,
c(cfg,±1)>=0) is the assumed input class (asserted of the constructed
assignments via p8_satisfying), not derived -- the v33 linearity sentence
covers the unbounded cone from the bounded box.

Direction 1: over every Paper-8-satisfying assignment on a bounded CU
range and over every acting local junction state (k = 1..4), one
T-action (§7.5) yields dS2 <= 0.  dTau < 0 per action is §7.5/F.43;
this script machine-checks the composition dTau < 0 => dS2 <= 0 at the
port-value grain.

Direction 2 (planted): two assignments violating the Paper-8
constraints must each be rejected with the expected violation, proving
the Paper-8 citation is load-bearing and not decorative:
  (a) the zero-tilt countermodel: c(0) = 5 > c(±1) = 0 -- violates
      "no tilt -> cost exactly zero" and exhibits dS2 > 0;
  (b) a negative-share assignment: c(+1) = -2 -- violates the
      diverted-share nonnegativity and exhibits dS2 > 0.
[LEVEL A] for the port-level lemma and the port-value relief composition.
"""
from itertools import product

VALS = (-1, 0, +1)
KS = (1, 2, 3, 4)
CU_BOUND = 3  # bounded range for the free nonnegative shares.
# CU_BOUND = 3 bounds a linear form in nonnegative shares, so box
# verification plus linearity covers the cone.


def T(state):
    (ca, A), (cb, B) = state
    A, B = list(A), list(B)
    for k in range(len(A)):
        if A[k] != 0 and A[k] == -B[k]:
            A[k] = 0
            B[k] = 0
            break
    return ((ca, tuple(A)), (cb, tuple(B)))


def acts(state):
    return T(state) != state


def total(state, c):
    (ca, A), (cb, B) = state
    return sum(c[(ca, x)] for x in A) + sum(c[(cb, x)] for x in B)


def p8_satisfying(c):
    """Paper-8 mechanism constraints on the assignment."""
    cfgs = {cfg for cfg, _ in c}
    return all(c[(cfg, 0)] == 0 for cfg in cfgs) and \
        all(c[(cfg, v)] >= 0 for cfg in cfgs for v in (+1, -1))


# ---- Direction 1: every Paper-8-satisfying assignment ----
states = [((('A', A), ('B', B)))
          for k in KS
          for A in product(VALS, repeat=k)
          for B in product(VALS, repeat=k)]
acting = [s for s in states if acts(s)]

checked = 0
for cp1, cm1, cp2, cm2 in product(range(CU_BOUND + 1), repeat=4):
    c = {('A', 0): 0, ('A', +1): cp1, ('A', -1): cm1,
         ('B', 0): 0, ('B', +1): cp2, ('B', -1): cm2}
    assert p8_satisfying(c)
    for s in acting:
        checked += 1
        d = total(T(s), c) - total(s, c)
        assert d <= 0, f"violation: {s} {c} dS2={d}"
print(f"F.44 PASS: direction 1 - dS2 <= 0 on {checked} "
      f"assignment x acting-state cases, 0 violations")


# ---- Direction 2: planted Paper-8 violations are rejected ----
def planted(name, c, expect_tag):
    assert not p8_satisfying(c), f"{name}: planted assignment unexpectedly satisfies P8"
    s = ((('A', (+1,)), ('B', (-1,))))  # one admissible pair
    d = total(T(s), c) - total(s, c)
    assert d > 0, f"{name}: planted assignment shows no dS2>0"
    print(f"F.44 PASS: direction 2 - planted '{name}' rejected "
          f"({expect_tag}); exhibits dS2={d}>0 under a T-action")


planted("zero-tilt countermodel",
        {('A', 0): 5, ('A', +1): 0, ('A', -1): 0,
         ('B', 0): 5, ('B', +1): 0, ('B', -1): 0},
        "c(0) > c(±1) contradicts 'no tilt -> cost exactly zero'")
planted("negative share",
        {('A', 0): 0, ('A', +1): -2, ('A', -1): 1,
         ('B', 0): 0, ('B', +1): 1, ('B', -1): 1},
        "negative diverted share contradicts budget-share nonnegativity")

print("F.44 PASS: port-level tracking-cost lemma and port-value relief "
      "composition machine-checked [LEVEL A]")