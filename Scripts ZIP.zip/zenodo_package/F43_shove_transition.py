
INPUT_PROVENANCE = {
    "CONF": {"class": "control", "note": "script-generated sweep population (2,850 random states, k=2..20) over the §5.1 state space"},
    "KS": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "OPERATOR_FNS": {"class": "paper-defined", "source": "§7.5 (resolution-transition operators; tension/admissibility per §7.1)"},
    "P": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "RAND520": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "STATES": {"class": "control", "note": "script-generated exhaustive enumeration (7,380 local junction states, k=1..4) over the §7.5 local-junction-state space"},
    "VALS": {"class": "control", "note": "module-level constant (sweep bound / test parameter)"},
    "_banned": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "_src": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "r1": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "rejected": {"class": "control", "note": "test fixture / rejection counter"},
    "seen": {"class": "arbitrary-representative", "independence": "representative value; outcome independent of specific choice"},
    "violations": {"class": "control", "note": "test fixture / rejection counter"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "transition operator over port-value tuples; backing claims quantify over no aspect kinds.",
}
#!/usr/bin/env python3
"""Paper 11 - F.43: the resolution transition operator (shove), §7.5.

Local state sigma = (A, B): the two sides' port-value tuples at one
established junction, values in {-1,0,+1} -- MACHINE LABELS for the
categorical port values (X-dominant -> +1, Y-dominant -> -1, O-neutral
-> 0). The labels carry no ordering, no signed arithmetic, and no net
sums. (The native claim "the shove conserves a signed ledger λ" is
withdrawn; see the machine-encoding note below.)

T(sigma): if any position j has A[j] == -B[j] != 0 (the two sides
present complementary categories AT that junction position, §7.1), zero
out the canonically-first such pair (§7.5: least index first); else sigma (stutter: the
seeking continues, §7.4).

MACHINE-ENCODING CONSISTENCY NOTE (per the verification-rigor staple):
  Native domain: the shove pairing complementary categorical port values
    at a junction (X-dominant with Y-dominant), resolving them.
  Verified domain: the {-1,0,+1} machine-label operator defined here.
  Map: X-dominant -> +1, Y-dominant -> -1, O-neutral -> 0.
  Index origin: the code uses 0-based indices; the paper (§7.5) numbers
    positions 1..k; least-first is preserved under j_paper = j_code + 1,
    so the implemented order and the defined order coincide.
  Preserved: totality, determinism, the exact -2 tension step per action,
    termination within tau/2 steps, confluence, and the vsum invariant
    (the machine-label sum is unchanged by the operator -- a consistency
    property OF THE ENCODING, not a native conservation law).
  Outside: any native "ledger conservation" claim. The vsum check below
    verifies that the machine encoding is self-consistent (the operator
    does not corrupt its own labels); it does not establish a native
    conserved quantity. The paper's Transition Properties theorem (§7.5)
    claims totality, determinism, tau-monotonicity, termination, and
    confluence -- not ledger conservation.

FINITE INSTANCE CHECK (k = 1..4, full enumeration, 7,380 states):
  Direction 1: the reference operator is total, deterministic,
  tau-monotone (tension drops by exactly 2 per action),
  machine-encoding-consistent (vsum invariant, see note above),
  terminating (fixed point in <= tau/2 steps), and confluent
  (fixed point = every positional complementary pair resolved).
  Direction 1b: the six planted ambiguous cases behave as specified.
  Direction 1c: the tension identity -- tau is identically the
  unmatched-integer count; tau > 0 is necessary but not sufficient for
  action (the stutter-with-tension class is enumerated exactly, in the
  three classes dangling / same-sign / cross-only).

PARAMETRIC K-INDEPENDENCE (the analytic bridge, inside the machine check):
  1. STEP CERTIFICATE (k-free). Every T tick has exactly one of two
     shapes, verifiable structurally with no mention of k: either the
     state stutters (output == input AND no complementary pair exists),
     or exactly one index j changes in both tuples, the pair there was
     complementary (a, -a with a != 0), both entries are zeroed, j is the
     first admissible index, and every other position is untouched.
     certify() checks this shape.
  2. LEMMAS DERIVED FROM THE CERTIFICATE. tau drops by exactly 2 because
     the certificate's action case zeroes a complementary label pair:
     delta_tau = -(a^2+b^2) = -2, derived from the certificate fields, not
     just measured. The vsum invariant holds because b = -a gives
     delta = -(a+b) = 0 -- a machine-encoding consistency property (see the
     note above), not a native conservation law. Termination in <= tau/2
     steps because each action removes exactly 2 of tau's integer budget
     (tau >= 0): 2*actions == tau_initial - tau_final is asserted on every
     chain. Confluence is order-independence: resolving position i never
     changes admissibility at any j != i (positions are independent), so the
     resolved set is exactly the initially-admissible set whatever the
     order -- checked by comparing first/last/random resolution orders
     and by the positional-independence identity on samples.
  3. CODE INTROSPECTION. The five operator functions are read back with
     inspect and asserted to contain no raise (no exception paths:
     totality is structural), no randomness (determinism is structural),
     and no reference to a global k bound (the k-free claim is in the
     code, not just the comments).
  4. FINITE INSTANCE CHECK RETAINED. The k = 1..4 full enumeration
     (7,380 states) is kept and must pass every lemma -- the old bound
     becomes the instance check, not the generality argument.
  5. RANDOMIZED CHECKS. Fixed-seed sampling at k = 5..20 exercises the
     lemmas beyond the old bound (including a planted variant that is
     clean at k <= 4 and corrupt above -- caught only because the checks
     reach k = 20).

PLANTED VARIANTS (each rejected with a printed witness):
  Direction 2 (finite check_operator machinery): six planted variants --
  encoding-consistency breach, tension increase, partiality, cross-positional matching,
  non-canonical tie-break, and position-0 skip.
  Parametric (check_T machinery at k = 5..20): planted variant 1
  (k-smuggling: clean at k <= 4, corrupt above), planted variant 2
  (partiality: raises where the shove cannot act -- stutter undefined),
  planted variant 3 (tau-violation: resolves, then re-opens a position
  so tension rises).

Scope limits (honest):
  - Finite k only. Native junction arity is finite (k_j >= 2, finite
    integer); infinite k is not native and is not covered. The analytic
    argument covers every finite k.
  - Binary local state. The operator is defined on sigma = (A, B) at one
    established junction (§7.5); n-ary junction composition beyond the
    binary local state is outside this script.
  - Canonical order. "Canonically-first admissible" is implemented as
    least-index selection (T_ref resolves ks[0]; certify enforces
    j == min over admissible indices), matching the §7.5 definition of
    the canonical enumeration order. The order is paper-defined; the
    script implements it, it does not re-prove it.
  - k = 1 is harmless over-coverage (native k_j >= 2); retained.
  - Model-to-physics mapping stays Level B per the paper's epistemic
    split; Level A here = the formal operator's properties.
"""
import inspect
import random
from itertools import product

VALS = (-1, 0, +1)
KS = (1, 2, 3, 4)

# --------------------------------------------------------------------------
# The operator (§7.5).
# --------------------------------------------------------------------------
def tension(sigma):
    A, B = sigma
    return sum(x * x for x in A) + sum(x * x for x in B)

def vsum(sigma):
    A, B = sigma
    return sum(A) + sum(B)

def admissible(sigma):
    A, B = sigma
    return [j for j in range(len(A)) if A[j] != 0 and A[j] == -B[j]]

def resolve(sigma, j):
    A, B = list(sigma[0]), list(sigma[1])
    A[j] = 0
    B[j] = 0
    return (tuple(A), tuple(B))

def T_ref(sigma):
    """The reference operator: canonically-first admissible pair, else
    stutter."""
    ks = admissible(sigma)
    return resolve(sigma, ks[0]) if ks else sigma

# --------------------------------------------------------------------------
# Step certificate (k-free structural certificate of one tick sigma -> t).
# --------------------------------------------------------------------------
class CertifyError(Exception):
    pass

def certify(sigma, t):
    """Returns ('stutter',) or ('action', j, a); raises CertifyError if the
    transition does not have the definitional shape."""
    A, B = sigma
    tA, tB = t
    if t == sigma:
        if admissible(sigma):
            raise CertifyError("stutter with an admissible pair available")
        return ("stutter",)
    diffs = [i for i in range(len(A)) if A[i] != tA[i] or B[i] != tB[i]]
    if len(diffs) != 1:
        raise CertifyError("transition touches %d positions" % len(diffs))
    j = diffs[0]
    a, b = A[j], B[j]
    if not (a != 0 and b == -a):
        raise CertifyError("resolved pair not complementary: (%r, %r)" % (a, b))
    if not (tA[j] == 0 and tB[j] == 0):
        raise CertifyError("resolved pair not zeroed")
    first = min(i for i in range(len(A)) if A[i] != 0 and A[i] == -B[i])
    if j != first:
        raise CertifyError("non-canonical position resolved")
    for i in range(len(A)):
        if i != j and (tA[i] != A[i] or tB[i] != B[i]):
            raise CertifyError("untouched position %d modified" % i)
    return ("action", j, a)

def valid_shape(t, sigma):
    A, _ = sigma
    return (isinstance(t, tuple) and len(t) == 2
            and len(t[0]) == len(A) and len(t[1]) == len(A)
            and all(x in VALS for x in t[0] + t[1]))

# --------------------------------------------------------------------------
# State spaces.
# --------------------------------------------------------------------------
def all_states():
    return [(k, (A, B))
            for k in KS
            for A in product(VALS, repeat=k)
            for B in product(VALS, repeat=k)]

ENUM14 = [s for _, s in all_states()]   # 7,380 states at k = 1..4

def rand_states(ks, n, seed):
    rng = random.Random(seed)
    out = []
    for k in ks:
        for _ in range(n):
            out.append((tuple(rng.choice(VALS) for _ in range(k)),
                        tuple(rng.choice(VALS) for _ in range(k))))
    return out

RAND520 = rand_states(range(5, 21), 300, 20260924)   # 4,800 states, k = 5..20
CONF = rand_states(range(2, 21), 150, 777)           # 2,850 states, k = 2..20

# --------------------------------------------------------------------------
# Lemma battery: every §7.5 property, checked per state (parametric).
# --------------------------------------------------------------------------
def check_T(T, states):
    """Return [(tag, witness_sigma), ...]; empty means T is clean."""
    viol = []
    for sigma in states:
        try:
            t = T(sigma)
        except Exception as e:
            viol.append(("total: raised on %r (%s)" % (sigma, e), sigma))
            continue
        if not valid_shape(t, sigma):
            viol.append(("total: bad shape on %r" % (sigma,), sigma))
            continue
        try:
            t2 = T(sigma)
        except Exception as e:
            viol.append(("total: raised on recompute (%s)" % e, sigma))
            continue
        if t2 != t:
            viol.append(("deterministic: same input, different output on %r"
                         % (sigma,), sigma))
        # Step certificate (structural, k-free).
        try:
            cert = certify(sigma, t)
        except CertifyError as e:
            viol.append(("certificate: %s on %r" % (e, sigma), sigma))
            cert = None
        # Numeric consequences, measured independently of the certificate.
        dt = tension(t) - tension(sigma)
        dl = vsum(t) - vsum(sigma)
        acted = (t != sigma)
        if acted:
            if dt != -2:
                viol.append(("tau: action changed tension by %d, not -2, on %r"
                             % (dt, sigma), sigma))
        else:
            if dt != 0:
                viol.append(("tau: stutter changed tension on %r" % (sigma,),
                             sigma))
        if dl != 0:
            viol.append(("encoding: vsum changed by %d on %r" % (dl, sigma),
                         sigma))
        if dt > 0:
            viol.append(("monotone: tension increased on %r" % (sigma,),
                         sigma))
        # Certificate-derived identities (the analytic step, mechanical).
        if cert is not None and cert[0] == "action":
            _, j, a = cert
            assert a * a == 1, "non-unit value in certificate"
            # delta_tau = -(a^2 + b^2) with b = -a  =>  exactly -2, by shape.
            assert -(a * a + a * a) == -2
            assert dt == -2, "certificate/numeric disagreement"
        # Termination chain with the tau/2 bound.
        s, actions = sigma, 0
        try:
            while True:
                s2 = T(s)
                if s2 == s:
                    break
                s, actions = s2, actions + 1
                if actions > 10000:
                    viol.append(("termination: no fixed point on %r"
                                 % (sigma,), sigma))
                    break
        except Exception as e:
            viol.append(("total: raised mid-chain (%s) on %r" % (e, sigma),
                         sigma))
        else:
            if 2 * actions != tension(sigma) - tension(s):
                viol.append(("termination: 2*actions != tension drop on %r"
                             % (sigma,), sigma))
            if actions > tension(sigma) // 2:
                viol.append(("termination: exceeded tau/2 on %r" % (sigma,),
                             sigma))
    return viol

def run_order(sigma, order, rng):
    s, steps = sigma, 0
    while True:
        ks = admissible(s)
        if not ks:
            return s, steps
        j = ks[0] if order == "first" else ks[-1] if order == "last" \
            else rng.choice(ks)
        s, steps = resolve(s, j), steps + 1
        assert steps < 10000, "non-termination"

def zero_initially_admissible(sigma):
    A, B = sigma
    tA = tuple(0 if (A[i] != 0 and A[i] == -B[i]) else A[i]
               for i in range(len(A)))
    tB = tuple(0 if (A[i] != 0 and A[i] == -B[i]) else B[i]
               for i in range(len(B)))
    return (tA, tB)

def run_to_fixpoint(T, s0):
    s, steps = s0, 0
    while True:
        s2 = T(s)
        if s2 == s:
            return s, steps
        s, steps = s2, steps + 1
        assert steps < 1000, "non-termination"

# --------------------------------------------------------------------------
# L0: code introspection -- the k-free claim is in the code.
# --------------------------------------------------------------------------
OPERATOR_FNS = {"tension": tension, "vsum": vsum, "admissible": admissible,
                "resolve": resolve, "T_ref": T_ref}
for _name, _fn in OPERATOR_FNS.items():
    _src = inspect.getsource(_fn)
    for _banned in ("raise", "random", "KS"):
        assert _banned not in _src, (_name, _banned)
print("F.43 PASS L0: code introspection -- no raise / randomness / k-bound "
      "reference in tension, vsum, admissible, resolve, T_ref.")

# --------------------------------------------------------------------------
# Direction 1: the finite instance check -- reference operator clean over
# the full k = 1..4 enumeration.
# --------------------------------------------------------------------------
def check_operator(T):
    """Return violation tags for operator T (empty = clean)."""
    v = []
    states = all_states()
    for k, s in states:
        try:
            s2 = T(s)
        except Exception:
            v.append("total: raised on %r" % (s,))
            continue
        if not (isinstance(s2, tuple) and len(s2) == 2
                and len(s2[0]) == k and len(s2[1]) == k
                and all(x in VALS for x in s2[0] + s2[1])):
            v.append("total: bad shape on %r" % (s,))
            continue
        try:
            again = T(s)
        except Exception:
            v.append("total: raised on recompute")
            continue
        if again != s2:
            v.append("deterministic: same input, different output")
        if tension(s2) > tension(s):
            v.append("monotone: tension increased on %r" % (s,))
        if s2 != s and tension(s) - tension(s2) != 2:
            v.append("monotone: action did not drop tension by exactly 2")
        if vsum(s2) != vsum(s):
            v.append("encoding: vsum changed on %r" % (s,))
        # termination with the tau/2 bound
        t, steps = s, 0
        while True:
            try:
                t2 = T(t)
            except Exception:
                v.append("total: raised mid-chain")
                break
            if t2 == t:
                break
            t, steps = t2, steps + 1
            if steps > 10 * k:
                v.append("termination: no fixed point")
                break
        if steps > tension(s) // 2:
            v.append("termination: exceeded tau/2 bound on %r" % (s,))
        # confluence: fixed point must be the all-pairs-resolved state
        ref_fp, _ = run_to_fixpoint(T_ref, s)
        if t != ref_fp:
            v.append("fixpoint: not the all-resolved state on %r" % (s,))
    # canonical: exact agreement with the reference on every state
    for k, s in states:
        try:
            if T(s) != T_ref(s):
                v.append("canonical: differs from reference operator")
                break
        except Exception:
            pass
    # §7.1-literalness: cross-only states must stutter
    for w in (((+1, -1), (+1, -1)), ((+1, 0), (0, -1))):
        try:
            if T(w) != w:
                v.append("positional: resolved a cross-only state")
        except Exception:
            v.append("total: raised on witness")
    return v

violations = check_operator(T_ref)
assert not violations, violations
print("F.43 PASS: direction 1 - reference operator clean "
      "(total, deterministic, tau-monotone, encoding-consistent, "
      "terminating, confluent) over the k = 1..4 finite instance check "
      "(%d states)." % len(ENUM14))

# --------------------------------------------------------------------------
# Direction 1b: the six planted ambiguous cases behave as specified.
# --------------------------------------------------------------------------
P = {
    # several admissible -> canonically-first resolves, full relief follows
    "P1": ((((+1, +1), (-1, -1))), ((0, +1), (0, -1)), ((0, 0), (0, 0)), 2),
    # none admissible (same sign) -> stutter, tension persists
    "P2": ((((+1,), (+1,))), ((+1,), (+1,)), ((+1,), (+1,)), 0),
    # cross-only complements -> stutter (§7.1 positional literalness)
    "P3": ((((+1, -1), (+1, -1))), (((+1, -1), (+1, -1))),
           (((+1, -1), (+1, -1))), 0),
    "P4": ((((+1, 0), (0, -1))), (((+1, 0), (0, -1))),
           (((+1, 0), (0, -1))), 0),
    # resolved -> stutter, tau 0
    "P5": ((((0, 0), (0, 0))), (((0, 0), (0, 0))), (((0, 0), (0, 0))), 0),
    # both sides unresolved -> symmetric resolution
    "P6": ((((+1, -1), (-1, +1))), ((0, -1), (0, +1)), ((0, 0), (0, 0)), 2),
}
for name, (s, want_step, want_fp, want_n) in P.items():
    got_step = T_ref(s)
    got_fp, got_n = run_to_fixpoint(T_ref, s)
    assert got_step == want_step, (name, got_step)
    assert got_fp == want_fp, (name, got_fp)
    assert got_n == want_n, (name, got_n)
    assert tension(got_fp) <= tension(s), name
    assert vsum(got_fp) == vsum(s), name
print("F.43 PASS: direction 1b - all six planted ambiguous cases behave "
      "as specified.")

# --------------------------------------------------------------------------
# Direction 1c: the tension identity (§7.1).
# --------------------------------------------------------------------------
STATES = all_states()
# (a) tau is identically the unmatched-integer count.
for k, s in STATES:
    A, B = s
    assert tension(s) == sum(1 for x in A + B if x != 0), \
        "tau != unmatched count"
# (b) tension is necessary but not sufficient for action.
actionable = [s for _, s in STATES if admissible(s)]
stutter_tension = [s for _, s in STATES
                   if tension(s) > 0 and not admissible(s)]
assert all(tension(s) > 0 for s in actionable), "action without tension"
assert stutter_tension, "no stutter-with-tension states"
for s in stutter_tension:
    assert T_ref(s) == s and tension(T_ref(s)) == tension(s), \
        "tension changed under stutter"
# zero tension means nothing to act on.
for _, s in STATES:
    if tension(s) == 0:
        assert T_ref(s) == s, "action at zero tension"

def stall_reasons(s):
    """Why each nonzero entry has no positional complement."""
    A, B = s
    reasons = set()
    for side, other in ((A, B), (B, A)):
        for i in range(len(side)):
            x, y = side[i], other[i]
            if x == 0:
                continue
            if y == x:
                reasons.add("same-sign")
            elif y == 0:
                if any(other[j] == -x for j in range(len(other)) if j != i):
                    reasons.add("cross-only")
                else:
                    reasons.add("dangling")
            # y == -x with x != 0 is admissible; unreachable here.
    return reasons

# (c) the stutter-with-tension class, enumerated exactly.
seen = set()
for s in stutter_tension:
    r = stall_reasons(s)
    assert r, "unclassified stutter-with-tension state"
    seen |= r
assert seen == {"dangling", "same-sign", "cross-only"}, seen
print("F.43 PASS: direction 1c - tension identity holds "
      f"({len(stutter_tension)} stutter-with-tension states in 3 classes; "
      "tension necessary but not sufficient for action).")

# --------------------------------------------------------------------------
# Direction 2: six planted variants must each be rejected, each with its
# expected violation tag (finite check_operator machinery).
# --------------------------------------------------------------------------
rejected = 0

def planted(T, expect):
    global rejected
    vs = check_operator(T)
    assert vs, "planted operator passed undetected"
    assert any(expect in x for x in vs), f"expected {expect}, got {vs}"
    rejected += 1

def T_nonconservative(sigma):
    # planted variant: resolves, then manufactures a fresh +1 (encoding-consistency breach).
    out = T_ref(sigma)
    if out != sigma:
        A, B = list(out[0]), list(out[1])
        if A[0] == 0:
            A[0] = 1
        return (tuple(A), tuple(B))
    return out

def T_tension_up(sigma):
    # planted variant: resolves, then re-opens a neighboring position.
    ks = admissible(sigma)
    if not ks:
        return sigma
    out = resolve(sigma, ks[0])
    A, B = list(out[0]), list(out[1])
    j = (ks[0] + 1) % len(A)
    if A[j] == 0 and B[j] == 0:
        A[j] = 1
        B[j] = -1
    return (tuple(A), tuple(B))

def T_partial(sigma):
    # planted variant: not total - raises where the shove cannot act.
    ks = admissible(sigma)
    if not ks:
        raise ValueError("no admissible pair")
    return resolve(sigma, ks[0])

def T_cross(sigma):
    # planted variant: cross-positional matching (rewires ports; not §7.1).
    A, B = sigma
    for i in range(len(A)):
        for j in range(len(B)):
            if A[i] != 0 and A[i] == -B[j]:
                A2, B2 = list(A), list(B)
                A2[i] = 0
                B2[j] = 0
                return (tuple(A2), tuple(B2))
    return sigma

def T_last(sigma):
    # planted variant: non-canonical tie-break (last admissible pair).
    ks = admissible(sigma)
    return resolve(sigma, ks[-1]) if ks else sigma

def T_skip0(sigma):
    # planted variant: never resolves position 0 (wrong fixed point).
    ks = [k for k in admissible(sigma) if k != 0]
    return resolve(sigma, ks[0]) if ks else sigma

planted(T_nonconservative, "encoding")
planted(T_tension_up, "monotone")
planted(T_partial, "total")
planted(T_cross, "positional")
planted(T_last, "canonical")
planted(T_skip0, "fixpoint")
assert rejected == 6, rejected
print("F.43 PASS: direction 2 - all 6 planted variants rejected.")

# --------------------------------------------------------------------------
# L1-L5: the parametric lemma battery on the reference operator.
# --------------------------------------------------------------------------
v = check_T(T_ref, ENUM14)
assert not v, v[:3]
print("F.43 PASS L1-L5: totality, determinism, exact -2 tension step, "
      "encoding consistency, tau/2 termination -- clean over the k = 1..4 "
      "finite instance check (%d states)." % len(ENUM14))

v = check_T(T_ref, RAND520)
assert not v, v[:3]
print("F.43 PASS L1-L5 (parametric): same five lemmas clean on %d "
      "fixed-seed random states at k = 5..20." % len(RAND520))

# --------------------------------------------------------------------------
# L6: confluence -- fixed point independent of resolution order.
# --------------------------------------------------------------------------
for s in CONF:
    r1 = random.Random(99)
    fp_first, _ = run_order(s, "first", r1)
    fp_last, _ = run_order(s, "last", r1)
    fp_rand, _ = run_order(s, "random", r1)
    assert fp_first == fp_last == fp_rand, ("order-dependence", s)
    # Analytic fixed-point characterization: exactly the initially
    # complementary positions get resolved, whatever the order.
    assert fp_first == zero_initially_admissible(s), ("fixed-point shape", s)
    # Positional independence: resolving i never changes admissibility at j.
    adm = set(admissible(s))
    for i in adm:
        assert set(admissible(resolve(s, i))) == adm - {i}, ("independence", s)
print("F.43 PASS L6: confluence -- first/last/random resolution orders reach "
      "the identical fixed point on %d states (k = 2..20); positional "
      "independence holds (resolving i leaves every j != i untouched)."
      % len(CONF))

# --------------------------------------------------------------------------
# The three parametric planted variants -- each must be rejected with a
# printed witness (check_T machinery at k = 5..20).
# --------------------------------------------------------------------------
def T_variant_k_smuggle(sigma):
    """Planted variant 1: k-smuggling -- clean at k <= 4, corrupt above."""
    A, B = sigma
    if len(A) <= 4:
        return T_ref(sigma)
    ks = admissible(sigma)
    if not ks:
        return sigma
    out = T_ref(sigma)
    oA, oB = list(out[0]), list(out[1])
    j2 = (ks[0] + 1) % len(oA)
    if oA[j2] == 0 and oB[j2] == 0:
        oA[j2] = 1
        oB[j2] = 1      # same-sign reopen: tension rises
    else:
        oA[j2] = 0      # asymmetric zeroing: tension drop != 2
    return (tuple(oA), tuple(oB))

def T_variant_partial(sigma):
    """Planted variant 2: partiality -- the stutter case is left undefined."""
    ks = admissible(sigma)
    if not ks:
        raise ValueError("no admissible pair")
    return resolve(sigma, ks[0])

def T_variant_tau_violation(sigma):
    """Planted variant 3: tau-violation -- resolves, then re-opens a position."""
    ks = admissible(sigma)
    if not ks:
        return sigma
    out = resolve(sigma, ks[0])
    A, B = list(out[0]), list(out[1])
    j2 = (ks[0] + 1) % len(A)
    A[j2] = 1
    B[j2] = 1
    return (tuple(A), tuple(B))

def expect_rejection(T, name, ok_substrings, states):
    viol = check_T(T, states)
    assert viol, "%s passed undetected" % name
    tags = [t for t, _ in viol]
    assert any(any(s in t for s in ok_substrings) for t in tags), \
        (name, tags[:5])
    wtag, wsig = viol[0]
    print("F.43 PASS %s REJECTED -- witness %r: %s" % (name, wsig, wtag))
    return len(viol)

# Planted variant 1 is invisible to the old bound: it passes k = 1..4 clean.
v14 = check_T(T_variant_k_smuggle, ENUM14)
assert not v14, v14[:3]
print("F.43 NOTE: planted variant 1 (k-smuggling) passes the k = 1..4 "
      "enumeration undetected -- the old bound is blind to it.")
n1 = expect_rejection(T_variant_k_smuggle, "planted variant 1 (k-smuggling)",
                      ("tau", "monotone", "certificate"), RAND520)
n2 = expect_rejection(T_variant_partial, "planted variant 2 (partiality)",
                      ("total",), RAND520)
n3 = expect_rejection(T_variant_tau_violation,
                      "planted variant 3 (tau-violation)",
                      ("tau", "monotone", "encoding"), RAND520)
print("F.43 PASS: all 3 parametric planted variants rejected "
      "(%d + %d + %d violating states found at k = 5..20)." % (n1, n2, n3))

print("=" * 70)
print("F.43 ALL PASS: the shove is a complete native transition rule, and the")
print("§7.5 transition lemmas hold for arbitrary finite k.")
print("  finite instance check : %d states at k = 1..4 (0 violations)"
      % len(ENUM14))
print("  parametric            : %d fixed-seed states at k = 5..20 (0 violations)"
      % len(RAND520))
print("  confluence            : %d states, 3 resolution orders agree" % len(CONF))
print("  planted variants      : 6 finite + 3 parametric -- all rejected with")
print("                          printed witnesses; variant 1 (k-smuggling)")
print("                          proven invisible to the k = 1..4 enumeration.")
print("=" * 70)