#!/usr/bin/env python3
"""Paper 11 -- F53_caseB_two_regime: machine audit of §10.3's two-regime
partition for Case B (collider outputs under forcing).

§10.3 (quoted verbatim as of the current text -- the sentences under audit):
  "Under forcing, collision events partition into two regimes:
   1. Clean resolution to simple states. The collision's incoming geometry
      and the target's geometry are complementary enough that the fabrication
      can resolve them into simple states. ...
   2. Trapped complex multi-junction overflow. The collision's incoming
      geometry and the target's geometry compound each other. The
      fabrication cannot resolve them into simple states within a single
      tick. The overflow accumulates at multiple junctions, producing a
      trapped complex configuration. Where the trapped residue exceeds the
      saturation threshold (res > TH), the configuration must decay through
      repeated forced-decay events; trapped residue at or below threshold
      (0 < res <= TH) selects repulsion under the §8.6 selection rule and
      is rejected, not decayed.
   The two regimes are distinguished by whether a single-tick resolution to
   simple states exists. If it does, the fabric reaches the simple-state
   configuration. If it does not, the fabric reaches the trapped
   configuration: saturated trapped residue (res > TH) remains unresolved
   until forced decay discharges the excess, while sub-threshold trapped
   residue (0 < res <= TH) selects repulsion and is rejected, not decayed."

WHAT THIS SCRIPT CHECKS (one reading, stated exactly): the per-tick
partition and its branch consequences under the paper's §8.6 selection
rule -- res = 0 -> attraction (clean); res > TH -> forced decay selected
(the per-tick mechanism of the "must decay" consequence, exactly on the
saturated band); 0 < res <= TH -> repulsion ("rejected, not decayed").
The multi-tick "repeated" fate ("must decay through REPEATED forced-decay
events"; "remains unresolved UNTIL forced decay discharges the excess")
is prose: §8.4 names ejection of the above-threshold residue but fixes no
per-event discharge quantum, so inter-tick residue evolution -- and hence
the repetition count -- is not natively determined (scope note S5; Paper 13
owns the time formalism). The script verifies everything about the
partition that the native content determines, and names what it does not.

HISTORICAL NOTE (changelog #111/#112): the v47 text applied "must decay
through repeated forced-decay events" to the whole trapped band (all
res > 0) with no saturation qualifier; that sentence was false on the
middle band under the paper's own §8.6 rule (0 < res <= TH selects
repulsion, "rejected, not decayed" -- on the per-tick reading and on any
multi-tick reading, a rejected junction does not decay). The saturation
qualifier ("Where the trapped residue exceeds the saturation threshold
(res > TH)") repaired it. This script audits the repaired text.

BRIDGE (one explicit sentence): "a single-tick resolution to simple states
exists" is rendered as tick-tau full complementary cover of the encounter's
presented geometry -- res(A,B) = 0 over the presented port tuples at the
encounter tick (the R-tuple's tau). The rendering's "complementary" half is
paper-owned (§8.6: "Full complementary cover ⟺ res(A, B) = 0"); the "into
simple states" product label and the "single" duration reading stay outside
the machine (scope notes S1, S2).

COVERAGE MAP (per the verification-rigor staple):
  Native domain: finite collision encounters -- an incoming configuration
    presenting a finite tuple of categorical port values against a target
    configuration presenting a finite tuple (the §8.6 directional encounter,
    read with A = incoming beam geometry, B = target geometry). In-domain:
    A presents at least one nonzero port (the taxonomy's domain guard).
  Verified domain: the {-1, 0, +1} machine-label model; exhaustive tuple-pair
    enumeration for side lengths 1..4, plus parametric witness families
    valid for symbolic k >= 2. The band partition itself is analytic over
    integer (res, TH) -- trichotomy over N0: {res = 0}, {0 < res <= TH},
    {res > TH} -- so exhaustiveness never depends on the enumeration bound.
  Map: F.36's M (X-dominant -> +1, Y-dominant -> -1, O-neutral -> 0;
    labels are categories, not quantities).
  What the map preserves:
    (1) res exactly -- a category-count function;
    (2) the clean/trapped partition -- a pure function of res;
    (3) branch verdicts -- taken from the F.36 oracle (the paper's §8.6 rule),
        never reimplemented here.
  What stays outside the machine check:
    S1. the "into simple states" product identification (rests on the §4.2
        27-inventory stipulation plus an interpretive step §10 never
        formalizes at port level);
    S2. the "single" duration reading of "single-tick" (same-tick caveat,
        §4.3: junction completions are never stated to be scan events; the
        rendering used here is resolvability AT the tick, not duration OF
        the resolution);
    S3. forced-vs-free attribution of presented geometry (§10.2 caveat --
        which presented tuples occur is the caveat's attribution question);
    S4. detector-data readings and ontology distinctions (§10.4, including
        the corollary, which holds by its own terms as a distinction of
        ontology, not of observable);
    S5. the multi-tick "repeated" fate. HONEST VERDICT (changelog #112):
        "fix the script so it actually does what it's supposed to do" was
        attempted: verifying the multi-tick fate ("must decay through
        REPEATED forced-decay events") would require a native rule for
        inter-tick residue evolution (res at tick tau+1 after a forced-decay
        event at tau). No such rule exists in native content: §8.4 names
        ejection of the above-threshold residue but fixes no per-event
        discharge quantum ("the junction array clears its load" states no
        quantum; "the resolution proceeds tick by tick, deterministically"
        states determinism, not the evolution rule); Paper 13 owns the time
        formalism and Paper 11 cites scan cadence only. The repetition count
        is therefore not natively determined -- the script cannot derive it,
        so it does not claim to. What the script DOES verify is everything
        the native content determines about the partition: the per-tick
        branch consequences on all three bands. The "repeated" fate remains
        prose at the claim's Level B, explicitly disclosed here, not smuggled
        as checked;
    S6. the Level-B premise that presented tuples faithfully model collider
        encounter geometry (the §8.6 epistemic split, as in F.36).

CHECKS:
  C1 res well-definedness: three independent implementations (count formula,
     per-port greedy pairing, maximum bipartite matching) agree on the whole
     collision domain; res is invariant under port permutation (zero-leak).
  C2 partition lemma: every in-domain collision geometry decides clean
     (res = 0) xor trapped (res > 0). (Exclusivity is excluded middle on the
     computed res; the substance is C3.)
  C3 HEADLINE -- trapped-band consequence audit: for every trapped geometry
     the branch is taken from the F.36 oracle (the paper's §8.6 rule):
     res > TH -> forced_decay; 0 < res <= TH -> repulsion. Verified:
       (a) the saturated sub-band (res > TH) selects forced decay -- §10.3's
           "selects forced decay" holds per-tick
           exactly here (the per-tick mechanism of the decay consequence;
           the multi-tick sequence is deferred to Paper 13 -- scope note S5);
       (b) the middle sub-band (0 < res <= TH) selects repulsion -- trapped
           overflow here is REJECTED, not decayed, exactly as the qualified
           §10.3 sentence states;
       (c) both sub-bands are non-empty for every viable TH (witnesses
           exhibited from the enumeration and the parametric families);
       (d) the clean band selects attraction TH-independently (res = 0).
     The script verifies the qualified §10.3 partition: the saturated band
     selects forced decay, the middle band selects repulsion, and the exact
     band boundary (res = TH) is reported. (Historical: the v47 unqualified
     text was false on the middle band under this same rule; repaired by the
     saturation qualifier, changelog #111/#112.)
  C4 TH-sensitivity (premise-perturbation): sweep TH over the viable band;
     the saturated/middle boundary tracks TH exactly; degenerate endpoints
     (TH = 0, TH = KMAX) reported as diagnostics.
  C5 domain-guard wiring: all-neutral incoming sides are refused, never
     scored -- the partition never sees out-of-domain geometries.
  V18 SELF-SWEEPS on this script:
     delete-the-assertion: the headline assert is deletable -- the band
       tabulation, witness exhibition, and mutant battery below still compute
       and print non-trivial results without it (compute-then-assert split).
     premise-perturbation: C4 moves the band boundary with TH exactly as the
       rule predicts; the mutant battery shows the wiring is rule-sensitive.

MUTANTS (genuine spec violations, each rejected with a printed witness):
  M1 reduction-sufficient mis-partition: labels a partially-paired res > 0
     geometry "clean" (partial cover is not cover -- cf. F.36 Theorem N).
  M2 fuseless: every trapped geometry -> forced_decay (drops the saturation
     fuse; collapses the middle band).
  M3 off-by-one fuse: res >= TH -> forced_decay (misplaces the fuse edge).
  M4 inverted fuse: res > TH -> repulsion (inverts the saturated branch).
  M5 topology-smuggling res: pairing constrained by port-index proximity
     (positional data steering res -- the map discards it per F.36).
  M6 guardless: scores an all-neutral incoming side (domain violation).

Native Stage N throughout: integer counts only; no continuum, no
capacity/absorption language. Exit 0 iff every check passes and every
mutant is rejected.
"""

INPUT_PROVENANCE = {
    # ---- declared-assumption: the live threshold input ----
    # The §8.6 model this audit is built on (residue definition, full-cover
    # iff, selection rule, domain guard, TH band) is F.36's checked domain;
    # F.53 imports F36 as the oracle and never reimplements the rule. The
    # §10.3 sentences under audit are quoted verbatim in the docstring above.
    "TH_LIVE": {"class": "declared-assumption",
                "prose": "§8.6; imported from F36.TH_LIVE (the §8.6 oracle's "
                         "live threshold); TH=1 is Paper 14's locked debt; "
                         "swept parametrically over the viable band plus "
                         "degenerate endpoints as diagnostics"},
    # ---- control: sweep bounds, seeds, counters, battery fixtures ----
    "VALUES": {"class": "control",
               "note": "machine labels {-1, 0, +1} for {X-dominant, Y-dominant, "
                       "O-neutral} (F.36's M; categories, not quantities)"},
    "KMAX": {"class": "control",
             "note": "enumeration bound: exhaustive tuple-pair sweep, side lengths "
                     "1..4 (stated explicitly; the band partition is analytic over "
                     "integer (res, TH), not bound-dependent)"},
    "SEED": {"class": "control", "note": "random seed for reproducibility"},
    "N_SHUFFLE": {"class": "control",
                  "note": "permutation-invariance probes per tuple pair"},
    "K_GRID": {"class": "control",
               "note": "k values at which the parametric witness families are "
                       "verified (families valid for symbolic k >= 2); the TH sweep "
                       "covers the viable band [1, k-1] plus the degenerate "
                       "endpoints 0 and k as diagnostics"},
    "n_pairs": {"class": "control", "note": "check counter / accumulator"},
    "n_clean": {"class": "control", "note": "check counter / accumulator"},
    "n_trapped": {"class": "control", "note": "check counter / accumulator"},
    "n_rejected": {"class": "control", "note": "mutant rejection counter"},
    "refused": {"class": "control", "note": "domain-guard refusal counter"},
    "failures": {"class": "control", "note": "mutant rejection accumulator"},
    "As": {"class": "control",
           "note": "permutation probe fixture: shuffled copy of the presented "
                   "tuple inside the C1 invariance check"},
    "degenerate_table": {"class": "control",
           "note": "degenerate-endpoint diagnostic: band table at TH=0"},
    "paper_regime": {"class": "control",
                     "note": "mutant-battery fixture: the paper's regime verdict "
                             "for the geometry under test"},
    "mutant_regime": {"class": "control",
                      "note": "mutant-battery fixture: the mutant's regime verdict "
                              "for the geometry under test"},
    "out6": {"class": "control",
             "note": "mutant-battery fixture: F36 oracle output for the guardless "
                     "(all-neutral incoming) mutant"},
    # ---- arbitrary-representative: exhibited witnesses ----
    "r2": {"class": "arbitrary-representative",
           "independence": "band membership is a pure function of (res, TH); the "
                           "finding is independent of which witness geometry "
                           "exhibits a band"},
    "r3": {"class": "arbitrary-representative",
           "independence": "band membership is a pure function of (res, TH); the "
                           "finding is independent of which witness geometry "
                           "exhibits a band"},
    "r4": {"class": "arbitrary-representative",
           "independence": "band membership is a pure function of (res, TH); the "
                           "finding is independent of which witness geometry "
                           "exhibits a band"},
    "true_r5": {"class": "arbitrary-representative",
                "independence": "band membership is a pure function of (res, TH); "
                                "the finding is independent of which witness "
                                "geometry exhibits a band"},
    "prox_r5": {"class": "arbitrary-representative",
                "independence": "band membership is a pure function of (res, TH); "
                                "the finding is independent of which witness "
                                "geometry exhibits a band"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "two-regime audit; backs a Level-B claim only (outside R23).",
}

import itertools
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import F36_interaction_taxonomy as F36  # the §8.6 oracle (dual-oracle cross-check)

VALUES = (-1, 0, 1)
KMAX = 4
SEED = 20261001
N_SHUFFLE = 3
TH_LIVE = F36.TH_LIVE  # 1; Paper 14's locked debt (declared assumption)

rng = random.Random(SEED)
failures = []


def check(name, cond, witness=""):
    print(("PASS " if cond else "FAIL ") + name + ("  " + str(witness) if witness and not cond else ""))
    if not cond:
        failures.append((name, witness))


# ---------------------------------------------------------------------------
# res, third independent implementation: maximum bipartite matching.
# A's nonzero ports matched against opposite-sign B ports; the matching is
# over port identities, the count is what matters. Independent of F.36's
# count formula (residue_vec) and its greedy pairing (residue_greedy).
# ---------------------------------------------------------------------------
def residue_matching(A_vals, B_vals):
    Anz = [a for a in A_vals if a != 0]
    Bnz = [(j, b) for j, b in enumerate(B_vals) if b != 0]
    match_b = {}

    def bpm(i, seen):
        a = Anz[i]
        for j, b in Bnz:
            if b == -a and j not in seen:
                seen.add(j)
                if j not in match_b or bpm(match_b[j], seen):
                    match_b[j] = i
                    return True
        return False

    matched = 0
    for i in range(len(Anz)):
        if bpm(i, set()):
            matched += 1
    return len(Anz) - matched


def res_all3(A, B):
    """res by all three implementations; returns the common value or raises."""
    g1 = F36.residue_vec(F36.counts_of(A), F36.counts_of(B))
    g2 = F36.residue_greedy(A, B)
    g3 = residue_matching(A, B)
    assert g1 == g2 == g3, ("res implementations diverge", A, B, g1, g2, g3)
    return g1


def regime_of(A, B):
    """The §10.3 partition predicate (bridge rendering disclosed above):
    clean iff tick-tau full complementary cover (res = 0), else trapped."""
    if not any(v != 0 for v in A):
        raise ValueError("incoming side presents no unmatched integers -- "
                         "outside the taxonomy's domain (refused, not scored)")
    return "clean" if res_all3(A, B) == 0 else "trapped"


def all_tuples(kmax):
    out = []
    for k in range(1, kmax + 1):
        out.extend(itertools.product(VALUES, repeat=k))
    return out


TUPLES = all_tuples(KMAX)
IN_DOMAIN = [(A, B) for A in TUPLES for B in TUPLES if any(v != 0 for v in A)]

# ---------------------------------------------------------------------------
# C1: res well-definedness -- three implementations agree; permutation invariance.
# ---------------------------------------------------------------------------
print("== C1: res well-definedness ==")
n_pairs = 0
for A, B in IN_DOMAIN:
    r = res_all3(A, B)  # raises on any divergence among the three
    n_pairs += 1
    for _ in range(N_SHUFFLE):
        As = list(A); Bs = list(B)
        rng.shuffle(As); rng.shuffle(Bs)
        if res_all3(As, Bs) != r:
            check("C1 permutation invariance", False, (A, B, As, Bs, r, res_all3(As, Bs)))
            break
print("  %d in-domain tuple pairs: count formula == greedy == max-matching;" % n_pairs)
print("  res invariant under %d port shuffles per pair (zero-leak)" % N_SHUFFLE)
check("C1 res well-defined and order-invariant", True)

# ---------------------------------------------------------------------------
# C2: partition lemma -- every in-domain geometry decides clean xor trapped.
# ---------------------------------------------------------------------------
print("== C2: partition lemma ==")
n_clean = n_trapped = 0
for A, B in IN_DOMAIN:
    if regime_of(A, B) == "clean":
        n_clean += 1
    else:
        n_trapped += 1
print("  in-domain pairs: %d clean, %d trapped, %d total" % (n_clean, n_trapped, n_pairs))
check("C2 partition total and exclusive", n_clean + n_trapped == n_pairs and n_clean > 0 and n_trapped > 0)

# ---------------------------------------------------------------------------
# C3 (headline): trapped-band consequence audit against the F.36 oracle.
# ---------------------------------------------------------------------------
print("== C3: trapped-band consequence audit ==")


def band_analysis(TH):
    """Compute-then-assert split (V18 delete-the-assertion): returns the full
    tabulation; the headline assert below is deletable without losing it."""
    tab = {"clean": [], "saturated": [], "middle": []}
    for A, B in IN_DOMAIN:
        r = res_all3(A, B)
        br = F36.branch(r, TH)  # the paper's §8.6 rule, via the oracle
        if r == 0:
            assert br == "attraction", (A, B, r, br)
            tab["clean"].append((A, B))
        elif r > TH:
            assert br == "forced_decay", (A, B, r, TH, br)
            tab["saturated"].append((A, B, r))
        else:
            assert br == "repulsion", (A, B, r, TH, br)
            tab["middle"].append((A, B, r))
    return tab


tab = band_analysis(TH_LIVE)
n_saturated = len(tab["saturated"])
n_middle = len(tab["middle"])
print("  at TH=%d: clean(attraction)=%d  trapped-saturated(forced_decay)=%d  trapped-middle(repulsion)=%d"
      % (TH_LIVE, len(tab["clean"]), n_saturated, n_middle))
w1 = tab["saturated"][0]; w2 = tab["middle"][0]
print("  saturated witness: A=%s B=%s res=%d -> %s" % (w1[0], w1[1], w1[2], F36.branch(w1[2], TH_LIVE)))
print("  middle witness:    A=%s B=%s res=%d -> %s" % (w2[0], w2[1], w2[2], F36.branch(w2[2], TH_LIVE)))
print("  §10.3's partition verified: 'selects forced decay'")
print("  holds per-tick exactly on the saturated band (res > TH);")
print("  the middle band (0 < res <= TH) is trapped (no single-tick cover) but selects")
print("  REPULSION -- rejected, not decayed, as the qualified sentence states.")
check("C3a saturated band selects forced decay", n_saturated > 0)
check("C3b middle band selects repulsion (not decay)", n_middle > 0)
check("C3c both trapped sub-bands realized", n_saturated > 0 and n_middle > 0)
# headline assert (deletable per the V18 self-sweep; the tabulation above stands alone)
assert n_middle > 0 and n_saturated > 0, "trapped band must split into both sub-bands"

# C3d: clean band selects attraction TH-independently (res = 0).
for TH in range(0, KMAX + 1):
    for A, B in tab["clean"][:200]:
        assert F36.branch(res_all3(A, B), TH) == "attraction", (A, B, TH)
check("C3d clean band = attraction, TH-independent", True)

# ---------------------------------------------------------------------------
# Parametric witness families (analytic, valid for symbolic k >= 2).
# Closed forms: (k,0)/(0,k) -> r=0; (k,0)/(0,k-1) -> r=1; (k,0)/(0,0) -> r=k.
# ---------------------------------------------------------------------------
print("== parametric families (symbolic k >= 2) ==")
K_GRID = [2, 3, 4, 5, 8, 13, 21]
for k in K_GRID:
    Ac = tuple([1] * k)
    r_clean = res_all3(Ac, tuple([-1] * k))
    r_mid = res_all3(Ac, tuple([-1] * (k - 1)))
    r_sat = res_all3(Ac, tuple([0] * k))
    assert (r_clean, r_mid, r_sat) == (0, 1, k), (k, r_clean, r_mid, r_sat)
    for TH in range(1, k):  # the viable band [1, k-1]
        assert F36.branch(r_clean, TH) == "attraction"
        assert F36.branch(r_mid, TH) == "repulsion"      # 0 < 1 <= TH
        assert F36.branch(r_sat, TH) == "forced_decay"   # k > TH
print("  families verified for k in %s: r in {0, 1, k} closed forms hold;" % K_GRID)
print("  for every k >= 2 and every viable TH in [1, k-1], all three bands realized")
check("parametric families: band trichotomy analytic over (res, TH)", True)

# ---------------------------------------------------------------------------
# C4: TH-sensitivity (premise-perturbation) -- the boundary tracks TH.
# ---------------------------------------------------------------------------
print("== C4: TH-sensitivity ==")
for TH in range(1, KMAX):
    t = band_analysis(TH)
    edge_ok = all(r > TH for _, _, r in t["saturated"]) and all(0 < r <= TH for _, _, r in t["middle"])
    both = len(t["saturated"]) > 0 and len(t["middle"]) > 0
    print("  TH=%d: saturated=%d middle=%d boundary-exact=%s" % (TH, len(t["saturated"]), len(t["middle"]), edge_ok))
    check("C4 boundary tracks TH=%d; middle band non-empty" % TH, edge_ok and both)
# degenerate endpoints: diagnostics, not rejections
degenerate_table = band_analysis(0)
tK = band_analysis(KMAX)
print("  DIAGNOSTIC TH=0: middle band empties (%d), all trapped -> forced_decay" % len(degenerate_table["middle"]))
print("  DIAGNOSTIC TH=KMAX=%d: saturated band empties (%d), all trapped -> repulsion" % (KMAX, len(tK["saturated"])))

# ---------------------------------------------------------------------------
# C5: domain-guard wiring -- all-neutral incoming refused, never scored.
# ---------------------------------------------------------------------------
print("== C5: domain guard ==")
refused = 0
for A0 in [t for t in TUPLES if not any(v != 0 for v in t)]:
    for B in TUPLES[:10]:
        try:
            regime_of(A0, B)
            check("C5 guard refuses all-neutral incoming", False, (A0, B))
        except ValueError:
            refused += 1
        try:
            F36.select_native([(i, v) for i, v in enumerate(A0)], [(i, v) for i, v in enumerate(B)])
            check("C5 oracle refuses all-neutral incoming", False, (A0, B))
        except ValueError:
            refused += 1
print("  %d all-neutral incoming presentations refused by script and oracle" % refused)
check("C5 domain guard wired (refuse, never score)", refused > 0)

# ---------------------------------------------------------------------------
# MUTANT BATTERY -- genuine spec violations, each rejected with a printed witness.
# ---------------------------------------------------------------------------
print("== mutant battery ==")
n_rejected = 0


def reject(name, witness, paper_out, mutant_out):
    global n_rejected
    bad = (mutant_out != paper_out)
    print(("REJECTED " if bad else "NOT-REJECTED ") + name)
    print("  witness=%s paper=%s mutant=%s" % (witness, paper_out, mutant_out))
    if bad:
        n_rejected += 1
    else:
        failures.append((name, witness))


def max_pairs(A, B):
    """Number of complementary pairs in a maximal pairing (for M1's premise)."""
    return sum(1 for v in A if v != 0) - res_all3(A, B)


# M1: reduction-sufficient mis-partition -- "clean" iff any complementary pair exists.
A1, B1 = (1, 1), (-1, 0)   # one pair exists, but res = 1 > 0
paper_regime = regime_of(A1, B1)
mutant_regime = "clean" if max_pairs(A1, B1) > 0 else "trapped"
reject("M1 reduction-sufficient mis-partition", (A1, B1, "res=1"), paper_regime, mutant_regime)

# M2: fuseless -- every trapped geometry -> forced_decay.
A2, B2 = (1, 1), (1, 1, 1)  # res = 2; at TH = 2 the paper says repulsion
r2 = res_all3(A2, B2)
paper_br = F36.branch(r2, 2)
reject("M2 fuseless (all trapped -> forced_decay)", (A2, B2, "res=%d TH=2" % r2), paper_br, "forced_decay")

# M3: off-by-one fuse -- res >= TH -> forced_decay.
A3, B3 = (1,), (1,)        # res = 1 = TH_LIVE
r3 = res_all3(A3, B3)
paper_br3 = F36.branch(r3, TH_LIVE)
reject("M3 off-by-one fuse (res >= TH -> decay)", (A3, B3, "res=%d TH=%d" % (r3, TH_LIVE)), paper_br3, "forced_decay")

# M4: inverted fuse -- res > TH -> repulsion.
A4, B4 = (1, 1), (0, 0)    # res = 2 > TH_LIVE
r4 = res_all3(A4, B4)
paper_br4 = F36.branch(r4, TH_LIVE)
reject("M4 inverted fuse (res > TH -> repulsion)", (A4, B4, "res=%d TH=%d" % (r4, TH_LIVE)), paper_br4, "repulsion")


# M5: topology-smuggling res -- pairing constrained by port-index proximity.
def residue_proximity(A_vals, B_vals, window=1):
    Anz = [(i, a) for i, a in enumerate(A_vals) if a != 0]
    Bfree = [(j, b) for j, b in enumerate(B_vals) if b != 0]
    used = set()
    unmatched = 0
    for i, a in Anz:
        for j, b in Bfree:
            if j not in used and b == -a and abs(i - j) <= window:
                used.add(j)
                break
        else:
            unmatched += 1
    return unmatched


A5, B5 = (1, 0, 0, 1), (-1, -1, 0, 0)  # true res = 0; proximity window strands a port
true_r5 = res_all3(A5, B5)
prox_r5 = residue_proximity(A5, B5)
reject("M5 topology-smuggling res (index-proximity pairing)", (A5, B5),
       "res=%d (order-free)" % true_r5, "res=%d (proximity-windowed)" % prox_r5)

# M6: guardless -- scores an all-neutral incoming side.
A6, B6 = (0, 0), (1,)
try:
    out6 = F36.select_native([(i, v) for i, v in enumerate(A6)], [(i, v) for i, v in enumerate(B6)])
    reject("M6 guardless (scores all-neutral incoming)", (A6, B6), "refused(ValueError)", out6)
except ValueError:
    print("REJECTED M6 guardless (scores all-neutral incoming)")
    print("  witness=%s paper=refused(ValueError) mutant=N/A (oracle refuses)" % ((A6, B6),))
    n_rejected += 1
# ...and the script's own partition must refuse it too
try:
    regime_of(A6, B6)
    reject("M6b script scores all-neutral incoming", (A6, B6), "refused(ValueError)", "scored")
except ValueError:
    print("REJECTED M6b script scores all-neutral incoming")
    print("  witness=%s paper=refused(ValueError)" % ((A6, B6),))
    n_rejected += 1

print("  mutants rejected: %d / 7" % n_rejected)
check("all mutants rejected with printed witnesses", n_rejected == 7 and not any(f[0].startswith("M") for f in failures))

# ---------------------------------------------------------------------------
print("======================================================================")
if failures:
    print("F53 RESULT: FAIL -- %d failing check(s)" % len(failures))
    for name, wit in failures:
        print("  - %s %s" % (name, wit))
    sys.exit(1)
print("F53 RESULT: PASS -- two-regime partition audited;")
print("  clean := tick-tau full complementary cover (res = 0) -> attraction;")
print("  trapped (res > 0) splits: res > TH -> forced_decay (saturated),")
print("  0 < res <= TH -> repulsion (middle: trapped but REJECTED, not decayed).")
print("  §10.3's qualified regime-2 consequence verified per-tick exactly on")
print("  the saturated band; the multi-tick 'repeated' fate is prose (S5).")
