#!/usr/bin/env python3
"""Paper 11 - F.45: proximity scaling (Section 8.5; registry claim PROXIMITY_SCALING).

Machine-checks the engagement-weighted scan-allocation scaling A(d) = e(d)*S(d)
with S(d) = s^2/(4d^2+2), in exact rational arithmetic (fractions.Fraction).

Epistemic boundary, stated explicitly:

  LEVEL A (machine-checked by this script):
    (i)   the scaling ALGEBRA: for fixed engagement count e and scan workload
          s^2, A(d1)/A(d2) = (4d2^2+2)/(4d1^2+2) exactly (check (c) -- the
          native-tier check: single port-pair encounters, e fixed per
          encounter by the §3.2 R-tuple definition);
    (ii)  the DERIVED shell profile (check (d)): the per-shell met-position
          counts e(D;d') computed from the paper's own aggregate fixtures
          (a), (b)-Branch-B, (c) -- imported from F.33/F.34/F.35, never
          hand-copied -- under the stated canonical embeddings. The machine
          derives: e_eng D-invariant on the canonical encounter family
          ((a)=3, (b)=1, (c)=1 as DERIVED values, asserted as a property not
          a literal); the engagement-shell relation (d*=D for (a)/(b),
          d*=D-1 for (c)); e(D;d') <= B(G) on every cell with B recomputed
          from the fixtures; the port-vs-position coincidence structure;
    (iii) the theorem-shape identity (check (e)): A(d1)/A(d2) =
          [e_eng(d1)/e_eng(d2)] * [N(d2)/N(d1)] verified against the DERIVED
          e_eng values -- this is what connects the derivation to e(d)*S(d);
    (iv)  the constructed taxicab-ball stress geometry (check (f)): a CONTROL
          geometry (not a paper-defined aggregate), machine-verified for
          junction arity, disjoint consumption, connectedness, and
          surface-openness, with its full e(D;d') table derived and its
          small-D irregularity recorded honestly with the domain boundary
          stated.
  INHERITED (not machine-derived here): Paper 10's N(d) = 4d^2+2 (check (a)
  verifies the formula against the independent table only); the Uniform Load
  Partition (equal per-position shares -- check (b) states the definition,
  no round-trip asserts); the §3.2 R-tuple definition fixing e per single
  port-pair encounter (native tier).
  NOT claimed: any physical magnitude for e or s^2; any d-dependence claim
  outside the canonical encounter family and the constructed ball. The old
  signature-inspection move is RETIRED as evidence for e-independence; it
  survives only as the labeled own-fact that B(G)'s construction takes no d.

  The old P2-confession ("NOT machine-derived by this script") is gone:
  e's profile is now machine-derived on the canonical family plus the
  constructed ball, with the domain boundary stated.

  No new primitives: integers, rationals (Fraction), the paper's own
  aggregate fixtures, integer taxicab D only.
"""
import os as _os
import sys as _sys
from fractions import Fraction

_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import F33_aggregate_a as F33
import F34_aggregate_b as F34
import F35_aggregate_c as F35

# The imported fixture modules as a module-level binding (paper-defined input;
# the junction data itself lives in F.33/F.34/F.35 and is never hand-copied).
FIXTURE_MODULES = {"a": F33, "b": F34, "c": F35}

INPUT_PROVENANCE = {
    # Paper-defined inputs (values from numbered paper sections / scripts).
    "SHELL_TABLE": {"class": "cited-paper",
                    "source": "Paper 10, §5.3.1 (N(d)=4d^2+2 oracle table)"},
    "FIXTURE_MODULES": {"class": "paper-defined",
                        "source": "§8.5 aggregates (a)/(b)/(c); junction data imported from "
                                  "F33_aggregate_a (AGG_A_JUNCTIONS), F34_aggregate_b "
                                  "(AGG_B_B_JUNCTION, Branch B per Dervis's decision), "
                                  "F35_aggregate_c (AGG_C_JUNCTIONS)"},
    # Declared assumptions (coordinate conventions, stated openly).
    "DIR_MAP": {"class": "declared-assumption",
                "prose": "§8.5 encounter geometry: port indices 0..5 mapped to the "
                         "lattice directions as a coordinate convention "
                         "(0:+x, 1:-x, 2:+y, 3:-y, 4:+z, 5:-z); the map is a "
                         "declared coordinate choice, not a paper sentence"},
    "EMBEDDINGS": {"class": "declared-assumption",
                   "prose": "§8.5 canonical encounter family: node embeddings stated openly "
                            "as the canonical coordinate choice -- (a) n0=(1,0,0), "
                            "n1=(0,1,0), n2=(0,0,1); (b) n0=(0,0,0), n1=(1,0,0); "
                            "(c) c0=(0,0,0), c1=(1,0,0), c2=(2,0,0)"},
    # Sweep controls, derived-result bindings, and check counters.
    "D_VALUES": {"class": "control", "note": "sweep input: integer taxicab D=1..20"},
    "BALL_RADII": {"class": "control", "note": "constructed-ball radii R=2,3 (control geometry)"},
    "_DELTA_TO_PORT": {"class": "control",
                       "note": "facing-port pairing for the constructed ball "
                               "(control geometry, not an input)"},
    "SHELL_PROFILES": {"class": "control",
                       "note": "derived shell-profile result per aggregate (not an input)"},
    "BALL_PROFILES": {"class": "control",
                      "note": "derived shell-profile result per ball radius (not an input)"},
    "EXPECTED_COINCIDENCE": {"class": "control",
                             "note": "pinned outcome record from the independent /tmp "
                                     "derivation: (ports, distinct positions) per aggregate "
                                     "(geometry outputs, not inputs)"},
    "BALL_EXPECTED_NJB": {"class": "control",
                         "note": "pinned outcome record from the independent /tmp "
                                 "derivation: (N, J, B) per ball radius"},
    "BALL_MAX_E": {"class": "control",
                   "note": "pinned outcome record from the independent /tmp "
                           "derivation: max e over all (D,d') cells per radius"},
    "BALL_MAX_OFFSET": {"class": "control",
                        "note": "pinned outcome record from the independent /tmp "
                                "derivation: argmax d' sits at fixed offset above D"},
    "BALL_SMALL_D": {"class": "control",
                     "note": "recorded derived data for the small-D irregular regime "
                             "(D < R+1); domain boundary stated, not a paper claim"},
    "checked_b": {"class": "control", "note": "check counter for (b)"},
    "checked_c": {"class": "control", "note": "check counter for (c)"},
    "checked_e": {"class": "control", "note": "check counter for (e)"},
    "w": {"class": "control", "note": "mutant-test witness holder"},
    "witness_pos": {"class": "control", "note": "mutant-test witness holder (nonuniform_share)"},
    # Arbitrary representatives (design §5.4: e and s2 are arbitrary
    # representatives; the ratio checks are independent of their values).
    "e": {"class": "arbitrary-representative", "independence": "(c) ratio A(d1)/A(d2) is independent of the specific e values"},
    "s2": {"class": "arbitrary-representative", "independence": "(b)/(c)/(e) checks are independent of the specific s2 values"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "scaling algebra; backing claims quantify over no aspect kinds.",
}

# Declared coordinate conventions (see INPUT_PROVENANCE; stated openly).
DIR_MAP = {0: (1, 0, 0), 1: (-1, 0, 0), 2: (0, 1, 0),
           3: (0, -1, 0), 4: (0, 0, 1), 5: (0, 0, -1)}
EMBEDDINGS = {
    "a": {"n0": (1, 0, 0), "n1": (0, 1, 0), "n2": (0, 0, 1)},
    "b": {"n0": (0, 0, 0), "n1": (1, 0, 0)},
    "c": {"c0": (0, 0, 0), "c1": (1, 0, 0), "c2": (2, 0, 0)},
}
D_VALUES = list(range(1, 21))  # integer taxicab D, 1..20
BALL_RADII = (2, 3)

# Pinned outcome records from the independent /tmp derivation run
# (derive_shell.py): geometry outputs used as oracles, not inputs.
EXPECTED_COINCIDENCE = {"a": (15, 12), "b": (10, 10), "c": (14, 14)}
BALL_EXPECTED_NJB = {2: (25, 36, 78), 3: (63, 114, 150)}
BALL_MAX_E = {2: 25, 3: 41}
BALL_MAX_OFFSET = {2: 3, 3: 4}
BALL_SMALL_D = {2: [(13, 2), (5, 1)], 3: [(25, 3), (13, 2), (5, 1)]}


# ---------------------------------------------------------------- (P1)
def N(d):
    """Shell count N(d) = 4d^2+2 (Paper 10, Section 5.3.1; inherited premise)."""
    return 4 * d * d + 2


# Independent hardcoded table (implementation check of the formula above).
SHELL_TABLE = {
    1: 6, 2: 18, 3: 38, 4: 66, 5: 102, 6: 146, 7: 198, 8: 258,
    9: 326, 10: 402, 11: 486, 12: 578, 13: 678, 14: 786, 15: 902,
    16: 1026, 17: 1158, 18: 1298, 19: 1446, 20: 1602,
}


def taxicab(p):
    return abs(p[0]) + abs(p[1]) + abs(p[2])


# ---- (a) shell counts for d = 1..20 ----
for d in D_VALUES:
    assert N(d) == SHELL_TABLE[d], f"N({d}) mismatch"
    assert N(d) > 0 and N(d) % 2 == 0  # positive, even
for d in D_VALUES[:-1]:
    assert N(d + 1) - N(d) == 8 * d + 4, "shell-difference structure"  # 4(2d+1)
assert all(N(d + 1) > N(d) for d in D_VALUES[:-1])  # strictly increasing
print("F.45 PASS: (a) N(d) = 4d^2+2 verified for d = 1..20 against the "
      "independent table (positive, even, strictly increasing, "
      "N(d+1)-N(d) = 8d+4).")


# ---- (b) per-position share S(d) = s^2/N(d), exact rationals ----
# NOTE (2026-09-25): the two divide-multiply round-trip asserts that lived
# here (S * N(d) == s2; uniform sum over N(d) positions == s2) have been
# deleted. They are the F.33-F.35 placeholder pattern: dividing a fiat
# total and multiplying back proves nothing about the world. What remains
# is the share definition, used by the ratio checks in (c) and (e).
def share(s2, d):
    return Fraction(s2, N(d))


checked_b = 0
for s2 in (1, 6, 12, 100):
    for d in D_VALUES:
        S = share(s2, d)
        # No round trip: S(d) is defined as s^2/N(d); asserting S*N(d)==s2
        # would only re-verify the definition.
        checked_b += 1
print(f"F.45 PASS: (b) per-position share S(d) = s^2/N(d) defined in exact "
      f"rational arithmetic ({checked_b} (s^2, d) cases; no round-trip "
      f"asserts -- see note above).")


# ---- (c) exact 1/(4d^2+2) d-dependence for FIXED e and s^2 ----
# Native-tier check: single port-pair encounters, e fixed per encounter by
# the §3.2 R-tuple definition (inherited premise, not derived here).
def engagement_weighted_scan_allocation(e, s2, d):
    """Engagement-weighted scan allocation A(d) = e*s^2/(4d^2+2), e fixed per encounter (§3.2)."""
    assert e >= 1 and s2 >= 1 and d >= 1
    return Fraction(e * s2, N(d))


checked_c = 0
for e in (1, 2, 5, 10):          # fixed engagement counts
    for s2 in (1, 12, 100):      # fixed scan workloads
        K = e * s2               # d-free part of the allocation
        # NOTE: the A(d)*N(d) == K round-trip assert that lived here has
        # been deleted (F.33-F.35 placeholder pattern). The ratio below
        # is the surviving check: it pins the d-dependence shape, not
        # the absolute scale (a constant-factor mutant passes the ratio).
        for d1 in D_VALUES:
            for d2 in D_VALUES:
                ratio = engagement_weighted_scan_allocation(e, s2, d1) / engagement_weighted_scan_allocation(e, s2, d2)
                expected = Fraction(N(d2), N(d1))  # = (4d2^2+2)/(4d1^2+2)
                assert ratio == expected, (e, s2, d1, d2)
                checked_c += 1
print(f"F.45 PASS: (c) for fixed e and s^2, A(d1)/A(d2) equals "
      f"(4d2^2+2)/(4d1^2+2) EXACTLY over {checked_c} (e, s^2, d1, d2) cases. "
      f"Scope: the ratio pins the 1/(4d^2+2) d-dependence shape only; no "
      f"absolute scale is pinned (a constant-factor mutant passes).")


# ---- (d) DERIVED shell profile: e(D;d') from the paper's own fixtures ----
# Junction structures are IMPORTED from F.33/F.34/F.35 (never hand-copied)
# and validated with each fixture's OWN input validation (pairwise-disjoint
# port consumption -- the fixtures' own check, not re-stipulated here).
# Source lines cited:
#   F33_aggregate_a: AGG_A_TRIPLES/AGG_A_JUNCTIONS lines 131-132,
#                    check2_input_validation line 232, Aggregate line 161;
#   F34_aggregate_b: AGG_B_B_TRIPLES line 173, AGG_B_B_JUNCTION lines 174-176
#                    (Branch B, complementary pair -- Dervis's decided
#                    convention), check2_input_validation line 266,
#                    Aggregate line 205;
#   F35_aggregate_c: AGG_C_JUNCTIONS lines 146-149, check2_input_validation
#                    line 250, Aggregate line 179.
def _fixture_aggregate(name):
    """Build the Aggregate from the fixture's own module data; validate with
    the fixture's own pairwise-disjointness check (raises on violation)."""
    mod = FIXTURE_MODULES[name]
    if name == "a":
        agg = mod.Aggregate("aggregate-(a)", mod.AGG_A_TRIPLES,
                            mod.AGG_A_JUNCTIONS)
    elif name == "b":
        agg = mod.Aggregate("aggregate-(b)/branch-B(complementary-pair)",
                            mod.AGG_B_B_TRIPLES, mod.AGG_B_B_JUNCTION)
    else:
        agg = mod.Aggregate("aggregate-(c)", mod.AGG_C_FIXTURE_TRIPLES,
                            mod.AGG_C_JUNCTIONS)
    mod.check2_input_validation(agg)
    return agg


def derive_shell_profile(name, emb_override=None):
    """e(D;d') for one aggregate on the canonical encounter family.

    A's reference at the array origin; B's local origin at (D,0,0), D=1..20.
    Presented port of B at local (node n, port p) sits at array position
    (D,0,0) + embed(n) + dir(p). e(D;d') = number of DISTINCT array positions
    with taxicab norm exactly d' coinciding with >=1 presented (open) port.
    Presented = open = not consumed by a completed junction (the fixture's
    own consumed set, validated pairwise-disjoint above).
    """
    agg = _fixture_aggregate(name)
    emb = dict(EMBEDDINGS[name])
    if emb_override:
        emb.update(emb_override)
    n_nodes = len(agg.nodes)
    k_sum = sum(d["arity"] for d in agg.junctions.values())
    consumed = agg.consumed()
    open_ports = agg.all_ports() - consumed
    # Dual B(G) computation: set-count vs 6N - sum(k_j).
    B_set = len(open_ports)
    B_formula = n_nodes * 6 - k_sum
    assert B_set == B_formula, (name, B_set, B_formula)
    table, e_eng, d_star, distinct_per_D = {}, [], [], []
    for D in D_VALUES:
        by_norm = {}
        for (n, p) in open_ports:
            ex, ey, ez = emb[n]
            dx, dy, dz = DIR_MAP[p]
            q = (D + ex + dx, ey + dy, ez + dz)
            by_norm.setdefault(taxicab(q), set()).add(q)
        e = {dd: len(s) for dd, s in by_norm.items()}
        ds = min(e)
        table[D] = e
        e_eng.append(e[ds])
        d_star.append(ds)
        distinct_per_D.append(len({q for s in by_norm.values() for q in s}))
    # The coincidence structure is D-independent (rigid x-shift preserves
    # it); assert as a property, then use the common value.
    assert len(set(distinct_per_D)) == 1, (name, distinct_per_D)
    return {"name": name, "N": n_nodes, "B": B_set,
            "n_ports": len(open_ports), "n_distinct": distinct_per_D[0],
            "table": table, "e_eng": e_eng, "d_star": d_star,
            "max_e": max(v for e in table.values() for v in e.values())}


SHELL_PROFILES = {name: derive_shell_profile(name) for name in ("a", "b", "c")}

# B(G) d-freeness as its OWN FACT: the boundary-count construction (6N -
# sum(k_j) over the fixture port sets) takes no distance parameter -- true
# and worth checking, but labeled explicitly: NOT evidence for
# e-independence. The e-profile is derived separately above.
for _aname in SHELL_PROFILES:
    _aprof = SHELL_PROFILES[_aname]
    assert _aprof["B"] == _aprof["N"] * 6 - sum(
        d["arity"] for d in _fixture_aggregate(_aname).junctions.values())
print("F.45 PASS: (d-own-fact) B(G) recomputed from the fixture port sets "
      "(dual: set-count = 6N - sum(k_j)): (a)=%d, (b)=%d, (c)=%d -- the "
      "construction takes no d, checked as its own fact; NOT evidence for "
      "e-independence."
      % (SHELL_PROFILES["a"]["B"], SHELL_PROFILES["b"]["B"],
         SHELL_PROFILES["c"]["B"]))

# The derived shell profile. D-invariance of e_eng is asserted as a PROPERTY
# (all 20 values equal -- no expected literal); the printed values are the
# derivation's output.
for _aname in SHELL_PROFILES:
    _aprof = SHELL_PROFILES[_aname]
    assert len(set(_aprof["e_eng"])) == 1, \
        "e_eng not D-invariant for aggregate (%s): %s" % (_aname, _aprof["e_eng"])
    # Engagement-shell relation, as computed: d*(D) = D for (a)/(b),
    # d*(D) = D-1 for (c).
    if _aname in ("a", "b"):
        assert _aprof["d_star"] == list(D_VALUES), \
            "shell relation broken for (%s)" % _aname
    else:
        assert _aprof["d_star"] == [d - 1 for d in D_VALUES], \
            "shell relation broken for (c)"
    # e(D;d') <= B(G) on every (D, d') cell, B recomputed from fixtures.
    for _D in D_VALUES:
        for _dd, _ee in _aprof["table"][_D].items():
            assert _ee <= _aprof["B"], (_aname, _D, _dd, _ee)
    # Port-vs-position coincidence structure, as computed (geometry outputs;
    # oracle values from the independent /tmp derivation run).
    assert (_aprof["n_ports"], _aprof["n_distinct"]) == \
        EXPECTED_COINCIDENCE[_aname], (_aname, _aprof["n_ports"],
                                       _aprof["n_distinct"])
    if _aprof["n_distinct"] < _aprof["n_ports"]:
        assert _aname == "a"  # coincidences occur only in (a)
    else:
        assert _aprof["n_distinct"] == _aprof["n_ports"]
    _maxcells = [(_D, _dd) for _D in D_VALUES
                 for _dd, _ee in _aprof["table"][_D].items()
                 if _ee == _aprof["max_e"]][0]
    print("F.45 PASS: (d) aggregate (%s): e_eng D-invariant over D=1..20 "
          "(derived values %s); d*(D)=%s; B=%d recomputed; e(D;d')<=B on all "
          "%d cells; ports vs distinct positions %d vs %d; max e=%d at "
          "(D,d')=%s."
          % (_aname, _aprof["e_eng"], "D" if _aname in ("a", "b") else "D-1",
             _aprof["B"],
             sum(len(t) for t in _aprof["table"].values()),
             _aprof["n_ports"], _aprof["n_distinct"],
             _aprof["max_e"], _maxcells))


# ---- (e) theorem-shape identity with DERIVED e ----
# A(d) := e_eng(d)*s^2/N(d) with the machine-derived e_eng values; verify
# A(d1)/A(d2) = [e_eng(d1)/e_eng(d2)] * [N(d2)/N(d1)] for all (d1, d2).
# With D-invariance this reduces to the (c) ratio -- the full identity is
# asserted, not the reduction.
checked_e = 0
for _aname in SHELL_PROFILES:
    _eeng = SHELL_PROFILES[_aname]["e_eng"]  # derived, length-20 list
    for s2 in (12, 100):
        for _d1 in D_VALUES:
            for _d2 in D_VALUES:
                _A1 = Fraction(_eeng[_d1 - 1] * s2, N(_d1))
                _A2 = Fraction(_eeng[_d2 - 1] * s2, N(_d2))
                _ratio = _A1 / _A2
                _expected = Fraction(_eeng[_d1 - 1], _eeng[_d2 - 1]) * \
                    Fraction(N(_d2), N(_d1))
                assert _ratio == _expected, (_aname, s2, _d1, _d2)
                checked_e += 1
print(f"F.45 PASS: (e) theorem-shape identity A(d1)/A(d2) = "
      f"[e_eng(d1)/e_eng(d2)]*[N(d2)/N(d1)] verified against the DERIVED "
      f"e_eng values over {checked_e} (aggregate, s^2, d1, d2) cases.")


# ---- (f) constructed taxicab-ball stress geometry (CONTROL) ----
# This ball is a CONSTRUCTED worst-case geometry -- provenance class
# control/declared-assumption -- not a paper-defined aggregate. Nodes at
# |v|_1 <= R for R=2,3; one 2-port junction per taxicab-adjacent node pair,
# consuming the facing ports (facing-port pairing from the direction map).
_DELTA_TO_PORT = {(1, 0, 0): 0, (-1, 0, 0): 1, (0, 1, 0): 2,
                  (0, -1, 0): 3, (0, 0, 1): 4, (0, 0, -1): 5}


def derive_ball_profile(R):
    """Build the taxicab ball, machine-verify its construction, and derive
    the full e(D;d') table for D=1..20."""
    nodes = [(x, y, z) for x in range(-R, R + 1)
             for y in range(-R, R + 1) for z in range(-R, R + 1)
             if abs(x) + abs(y) + abs(z) <= R]
    ids = {"v%d" % i: v for i, v in enumerate(sorted(nodes))}
    at = {v: k for k, v in ids.items()}
    junctions, seen_pairs, jn = {}, set(), 0
    for u in nodes:
        for dlt, p_u in _DELTA_TO_PORT.items():
            v = (u[0] + dlt[0], u[1] + dlt[1], u[2] + dlt[2])
            if v in at and (at[v], at[u]) not in seen_pairs:
                p_v = _DELTA_TO_PORT[(-dlt[0], -dlt[1], -dlt[2])]
                junctions["j%d" % jn] = {"ports": [(at[u], p_u), (at[v], p_v)],
                                        "arity": 2}
                seen_pairs.add((at[u], at[v]))
                jn += 1
    n_n, n_j = len(ids), len(junctions)
    consumed = {(v, p) for d in junctions.values() for (v, p) in d["ports"]}
    all_ports = {(v, p) for v in ids for p in range(6)}
    # Machine-verified construction (not stipulated):
    assert all(d["arity"] == 2 and len(d["ports"]) == 2
               for d in junctions.values()), "junction arity != 2"
    assert len(consumed) == 2 * n_j, "consumed sets not pairwise disjoint"
    adj = {v: set() for v in ids}
    for d in junctions.values():
        (a, _), (b, _) = d["ports"]
        adj[a].add(b)
        adj[b].add(a)
    reached = {next(iter(ids))}
    stack = list(reached)
    while stack:
        x = stack.pop()
        for y in adj[x]:
            if y not in reached:
                reached.add(y)
                stack.append(y)
    assert reached == set(ids), "junction graph not connected"
    open_ports = all_ports - consumed
    assert all(abs(ids[v][0]) + abs(ids[v][1]) + abs(ids[v][2]) == R
               for (v, p) in open_ports), "open port off the norm-R surface"
    B = len(open_ports)
    assert B == 6 * n_n - 2 * n_j, "B dual computation disagrees"
    table, e_eng, d_star, max_per_D = {}, [], [], []
    for D in D_VALUES:
        by_norm = {}
        for (v, p) in open_ports:
            ex, ey, ez = ids[v]
            dx, dy, dz = DIR_MAP[p]
            q = (D + ex + dx, ey + dy, ez + dz)
            by_norm.setdefault(taxicab(q), set()).add(q)
        e = {dd: len(s) for dd, s in by_norm.items()}
        ds = min(e)
        table[D] = e
        e_eng.append(e[ds])
        d_star.append(ds)
        max_per_D.append(max(e.values()))
    return {"R": R, "N": n_n, "J": n_j, "B": B, "table": table,
            "e_eng": e_eng, "d_star": d_star, "max_per_D": max_per_D,
            "max_e": max(max_per_D)}


BALL_PROFILES = {}
for _R in BALL_RADII:
    BALL_PROFILES[_R] = derive_ball_profile(_R)

for R in BALL_RADII:
    _bp = BALL_PROFILES[R]
    # N, J, B recomputed (oracle: independent /tmp derivation).
    assert (_bp["N"], _bp["J"], _bp["B"]) == BALL_EXPECTED_NJB[R], \
        (_bp["N"], _bp["J"], _bp["B"])
    # Max e is D-independent and sits at a FIXED offset above D (not growing
    # with D); the argmax offset is pinned as derived.
    assert all(_m == _bp["max_e"] for _m in _bp["max_per_D"]), \
        "max e varies with D"
    assert _bp["max_e"] == BALL_MAX_E[R], _bp["max_e"]
    for _D in D_VALUES:
        _offsets = sorted(_d - _D for _d, _e in _bp["table"][_D].items()
                          if _e == _bp["max_e"])
        assert _offsets == [BALL_MAX_OFFSET[R]], (_D, _offsets)
    # Large-D stabilized regime: e_eng=1, d*=D-R-1, and the offset-form
    # profile is D-independent -- for D >= R+1 (domain boundary stated).
    _ref = sorted((_d - 20, _e) for _d, _e in _bp["table"][20].items())
    for _D in D_VALUES:
        if _D >= R + 1:
            assert _bp["e_eng"][_D - 1] == 1, (_D, _bp["e_eng"][_D - 1])
            assert _bp["d_star"][_D - 1] == _D - R - 1, \
                (_D, _bp["d_star"][_D - 1])
            assert sorted((_d - _D, _e)
                          for _d, _e in _bp["table"][_D].items()) == _ref, \
                "offset profile not stabilized at D=%d" % _D
    # Small-D irregularity (D < R+1): recorded honestly as derived data with
    # the domain boundary stated -- not a paper claim.
    _small = [(_bp["e_eng"][d - 1], _bp["d_star"][d - 1])
              for d in range(1, R + 1)]
    assert _small == BALL_SMALL_D[R], _small
    print("F.45 PASS: (f) constructed ball R=%d: N=%d, J=%d, B=%d recomputed; "
          "max e=%d at fixed offset +%d above D for every D=1..20 (not "
          "growing with D); large-D stabilized regime D>=%d: e_eng=1, "
          "d*=D-%d, D-independent offset profile %s; small-D irregularity "
          "recorded (D,d*) pairs %s -- CONTROL geometry, not a paper claim."
          % (R, _bp["N"], _bp["J"], _bp["B"], _bp["max_e"],
             BALL_MAX_OFFSET[R], R + 1, R + 1, _ref, _small))


# ---- Planted mutants: each must be REJECTED with a printed witness ----
def find_ratio_witness(mag_fn, s2, e_fixed):
    """First (d1, d2) pair where mag_fn's ratio breaks the exact
    1/(4d^2+2) ratio against the true shell counts."""
    for d1 in D_VALUES:
        for d2 in D_VALUES:
            if d1 == d2:
                continue
            ratio = mag_fn(e_fixed, s2, d1) / mag_fn(e_fixed, s2, d2)
            expected = Fraction(N(d2), N(d1))
            if ratio != expected:
                return d1, d2, ratio, expected
    return None


# Variant 1: e_grows_with_d -- engagement grows with distance (violates the
# fixed-e native tier).
def allocation_e_grows(_e, s2, d):
    return Fraction(d * s2, N(d))  # planted: e = d


w = find_ratio_witness(allocation_e_grows, 12, None)
assert w is not None, "planted 'e_grows_with_d' was NOT rejected"
print(f"F.45 PASS: planted 'e_grows_with_d' rejected -- witness d1={w[0]}, "
      f"d2={w[1]}: ratio {w[2]} != expected {w[3]}.")


# Variant 2: wrong_denominator -- shell denominator 4d^2 instead of 4d^2+2.
def allocation_wrong_denom(e, s2, d):
    return Fraction(e * s2, 4 * d * d)  # planted: drops the +2


w = find_ratio_witness(allocation_wrong_denom, 12, 5)
assert w is not None, "planted 'wrong_denominator' was NOT rejected"
print(f"F.45 PASS: planted 'wrong_denominator' rejected -- witness d1={w[0]}, "
      f"d2={w[1]}: ratio {w[2]} != expected {w[3]}.")


# Variant 3: nonuniform_share -- position-weighted shares (breaks uniformity).
def nonuniform_shares(s2, d):
    """Planted: position 0 carries double weight."""
    n = N(d)
    total_w = n + 1  # (n-1)*1 + 2
    return [Fraction(2 * s2, total_w)] + [Fraction(s2, total_w)] * (n - 1)


witness_pos = None
for s2 in (12, 100):
    for d in D_VALUES:
        uniform = Fraction(s2, N(d))
        shares = nonuniform_shares(s2, d)
        assert sum(shares) == s2  # analytic: weight-sum identity, nonuniform_shares docstring
        for i, s in enumerate(shares):
            if s != uniform:
                witness_pos = (s2, d, i, s, uniform)
                break
        if witness_pos:
            break
    if witness_pos:
        break
assert witness_pos is not None, "planted 'nonuniform_share' was NOT rejected"
s2w, dw, iw, got, want = witness_pos
print(f"F.45 PASS: planted 'nonuniform_share' rejected -- witness s^2={s2w}, "
      f"d={dw}, position {iw}: share {got} != uniform {want}.")


# Variant 4 (m1): non-disjoint port consumption -- a junction table where two
# junctions share a port. The derivation pipeline validates consumption with
# the fixture's OWN pairwise-disjointness check before computing e; the
# check must fire loudly here.
def mutant_1_non_disjoint_consumption_rejected():
    bad_junctions = {
        "j0": {"ports": [("n0", 4), ("n1", 4), ("n2", 4)], "arity": 3},
        "j1": {"ports": [("n0", 4), ("n1", 0)], "arity": 2},  # ("n0",4) shared
    }
    bad = F33.Aggregate("aggregate-(a)/mutant_1", F33.AGG_A_TRIPLES,
                        bad_junctions)
    try:
        F33.check2_input_validation(bad)
    except F33.CheckRejected as ex:
        print("WITNESS mutant_1_non_disjoint_consumption: the fixture's own "
              "pairwise-disjointness check fired -- %s" % ex.witness)
        return True
    raise AssertionError("mutant_1 NOT rejected")


assert mutant_1_non_disjoint_consumption_rejected()


# Variant 5 (m2): perturbed embedding -- one node's embedding shifted +1 in x.
# Finding (machine, not stipulated): D-invariance of e_eng SURVIVES this
# perturbation (e_eng=3 for all D=1..20, d*=D unchanged) -- the shell profile
# is rigid under small rigid shifts. The perturbation IS caught, by the
# coincidence structure: 15 ports -> 14 distinct positions (was 12).
def mutant_2a_plus_one_shift_breaks_coincidence():
    prof = derive_shell_profile("a", emb_override={"n0": (2, 0, 0)})
    pair = (prof["n_ports"], prof["n_distinct"])
    if pair == EXPECTED_COINCIDENCE["a"]:
        raise AssertionError("mutant_2a NOT rejected")
    print("WITNESS mutant_2a_plus_one_shift: (a) n0 embedding +1 in x "
          "rejected by the coincidence structure -- ports vs distinct "
          "positions %s (expected %s); D-invariance of e_eng survived "
          "(e_eng=%s all D), so the shell profile's rigidity is genuine, "
          "not fragile" % (pair, EXPECTED_COINCIDENCE["a"], prof["e_eng"][0]))
    return True


assert mutant_2a_plus_one_shift_breaks_coincidence()


# Variant 5b (m2, large shift): a large embedding shift (-8 in x on (a)'s n2)
# moves a port inside the engagement shell for large D -- D-invariance of
# e_eng genuinely breaks, and the property assert fires.
def mutant_2b_large_shift_breaks_d_invariance():
    prof = derive_shell_profile("a", emb_override={"n2": (-8, 0, 1)})
    if len(set(prof["e_eng"])) == 1:
        raise AssertionError("mutant_2b NOT rejected")
    print("WITNESS mutant_2b_large_shift: (a) n2 embedding -8 in x rejected "
          "-- D-invariance of e_eng broken: e_eng=%s (D=1..20), d*=%s"
          % (prof["e_eng"], prof["d_star"]))
    return True


assert mutant_2b_large_shift_breaks_d_invariance()


# Variant 6 (m3): positions counted as ports -- count presenting PORTS (no
# dedup) at the engagement shell instead of distinct POSITIONS. For (a) the
# shell carries 5 presenting ports on 3 distinct positions; the coincidence
# equality (15 vs 12) must break.
def mutant_3_ports_instead_of_positions_rejected():
    agg = _fixture_aggregate("a")
    emb = EMBEDDINGS["a"]
    open_ports = agg.all_ports() - agg.consumed()
    for D in (1, 7, 20):
        by_norm_ports, by_norm_pos = {}, {}
        for (n, p) in open_ports:
            ex, ey, ez = emb[n]
            dx, dy, dz = DIR_MAP[p]
            q = (D + ex + dx, ey + dy, ez + dz)
            by_norm_ports.setdefault(taxicab(q), []).append((n, p))
            by_norm_pos.setdefault(taxicab(q), set()).add(q)
        ds = min(by_norm_pos)
        n_ports_shell = len(by_norm_ports[ds])
        n_pos_shell = len(by_norm_pos[ds])
        if n_ports_shell == n_pos_shell:
            raise AssertionError("mutant_3 NOT rejected at D=%d" % D)
        print("WITNESS mutant_3_ports_instead_of_positions: D=%d, shell "
              "d*=%d carries %d presenting PORTS on %d distinct POSITIONS "
              "-- counting ports instead of positions breaks the coincidence "
              "equality" % (D, ds, n_ports_shell, n_pos_shell))
    return True


assert mutant_3_ports_instead_of_positions_rejected()

print("F.45 PASS: 7/7 planted variants rejected with printed witnesses "
      "(e_grows_with_d, wrong_denominator, nonuniform_share, "
      "non-disjoint consumption, perturbed embedding +1x, perturbed "
      "embedding -8x, ports-instead-of-positions).")
print("F.45 DONE: proximity scaling machine-checked at LEVEL A -- scaling "
      "algebra + the DERIVED shell profile (canonical family + constructed "
      "ball); inherited: Paper 10's N(d), the Uniform Load Partition, the "
      "§3.2 R-tuple definition.")
