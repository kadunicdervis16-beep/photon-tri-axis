#!/usr/bin/env python3
"""Paper 11 - F.33: symbolic per-aspect s^2 decomposition of aggregate (a).

Aggregate (a): three State-4 nodes converging center-to-center (Appendix B.1).
One 3-way center junction J0 = {(n0,4),(n1,4),(n2,4)}, k = 3 (consume-O
convention; paper line 736: counts (6,6,3), B = 15).

What this script machine-checks (symbolic discipline): the coherence of the
per-aspect s^2 decomposition -- exact port partition, Tracking-Cost-consistent
contribution assignment, symbolic-sum identity via enumeration plus an
independent arithmetic audit, no double counting, no fiat magnitudes.
It verifies decomposition coherence, NOT physical magnitudes: no numeric
per-state s^2 exists anywhere in the framework (Paper 8 gives only the
floor-unit partial order 9 < {7,8} < 1; states 2-6 have no stated depth --
v14_A4, A4 correction, §5.1). s^2 stays symbolic throughout.

Coverage map (verification-rigor standard):
  (1) Native domain: Appendix B.1's per-aspect s^2 decomposition of aggregate
      (a) -- the native Stage-N claim that the three-node State-4 composite's
      s^2 workload decomposes exactly over its aspects.
  (2) Verified domain: the finite formal model -- the section-2 contribution
      assignment (resolved aspects -> integer 0; open tilt-presenting boundary
      ports -> positive formal symbols; O-valued ports and State-9 ports -> 0)
      applied to the paper-defined input (Table 5.1 triples; the Appendix B.1
      junction construction), checked by enumeration (Route 1) plus an
      independent arithmetic audit (count-vector shape prediction).
  (3) Map: native aspect (node / junction / boundary port of the worked
      aggregate) -> formal aspect in A(G); native "resolved" (§6.1; the
      Tracking-Cost Lemma §7.3 compels 0 at port grain only -- the
      aspect-level 0-attribution is the declared partition rule,
      consistent with (not compelled by) the lemma) -> contribution
      exactly 0; native "open port presenting unmatched tilt" ->
      positive formal symbol u_(v,p); S^2(G) :=
      sum_{a in A(G)} c(a) (R15 exact-finite-sum rule, §4.1).
  (4) Preserved: the exact port partition (B = 6N - sum(k_j), dual-computed),
      the zero/nonnegative contribution pattern, the symbolic-sum identity,
      symbol distinctness (no double counting), aspect coverage (every aspect
      exactly once).
  (5) Outside the machine check: physical s^2 magnitudes (Paper 8 cited, never
      reproduced); the premises themselves (Tracking-Cost Lemma, §6.1,
      Appendix B construction choices, the declared rule-(ii) choice); content
      input errors (triple misrecord with xy-invariance, wrong state
      assignment, shared c-rule error) -- including the sharp outcome-changing
      instance: a junction-table CONTENT swap that is structurally valid
      (pairwise-disjoint port lists, arity == port-list length, port indices
      in 0..5, node ids valid) but consumes the wrong ports (e.g. an
      X-valued port instead of the paper's O-valued one) moves the worked
      outcome while checks 1-7 all stay green -- demonstrated on the F.34
      branch-A input (symbols 8 -> 7, port-zeros 2 -> 3); the only machine
      backstop is the hardcoded per-input expectation literal in main; the
      hardcoded-script residual -- all caught only by code review (the
      independent re-read), never by the machine.

Badge:
"Level A conditional on the Tracking-Cost Lemma (port-level composition), §6.1, §5.1 Table 5.1 and its
boundary-tuple stipulation, the R15 sum rule and Port Count Invariance (§4.3),
the junction arity >= 2 rule, and the Appendix B / §9 / F.41 construction
premises; the machine checks the counting, not the premises."
The State-9 contribution rule (ii) is a declared Tracking-Cost-consistent
disambiguation, load-bearing for the §5 battery's State-9 substitutions.

Method notes (§4 of the build plan):
- Route 1 enumerates every aspect of A(G) explicitly -- N (node,v) and |E|
  (junction,j) zero terms included -- and ranges over boundary ports dG ONLY (the Route-1 boundary-only rule): consumed ports are not aspects of A(G); a consumed port reaching the
  emitter is a defensive hard error, never a zero term.
- The arithmetic audit predicts the term multiset's SHAPE by count-vector
  arithmetic without per-port term emission (the interior-zeros half is a
  self-consistency fixed point; the symbol-count and port-zero halves are
  the independent predictions). Both routes share the full input (triples +
  junction table + node set); the plan no longer pretends otherwise.
  Plan-faithfulness note: the plan's check-3 text ('exactly zeros_expected
  integer-0 terms' with zeros_expected = N+|E|) is unsatisfiable as written,
  because §2 also emits integer 0 for O-valued boundary ports. The audit
  therefore predicts port_zeros_expected by count vectors as well (documented
  in arithmetic_audit); check 3 asserts the full shape.
- The tautology guard (check 7) is necessary-but-insufficient: it rejects the
  fiat-total method (mutant_4) but passes the vacuity mutant (mutant_0) --
  check 5 (symbol hygiene) is the real backstop for vacuity.
"""

import ast as _ast
import sys
from collections import Counter
from fractions import Fraction
from itertools import product  # noqa: F401  (kept for interface parity across F.33-F.35)

# ---------------------------------------------------------------------------
# INPUT_PROVENANCE (P1/P2 interface): every module-level source name declared.
# Classes: paper-defined | cited-paper | declared-assumption | control |
#          arbitrary-representative. ast.literal_eval-able (self-checked below).
# NOTE: the Tracking-Cost Lemma (§7.3), Bonding-Reduces-Port-Openness (§6.1),
# the R15 exact-finite-sum rule (§4.1), and the State-9 rule-(ii)
# disambiguation are encoded in the contribution/summation logic below, not
# bound as module-level inputs; the Level-A conditionality on them is stated
# in the docstring's epistemic boundary, so they are not declared here.
# ---------------------------------------------------------------------------
INPUT_PROVENANCE = {
    "STATE_ROWS": {"class": "paper-defined",
                   "source": "§5.1 Table 5.1 (Outside Content boundary tuples)",
                   "anchor": "Outside Content"},
    "AGG_A_TRIPLES": {"class": "paper-defined",
                      "source": "Appendix B.1 aggregate (a) construction",
                      "anchor": "Three State-4 configurations"},
    "AGG_A_JUNCTIONS": {"class": "paper-defined",
                        "source": "Appendix B.1 (center junction consumes one "
                                  "port per node: idx 4, O-valued)",
                        "anchor": "consumes exactly one port per node"},
    "BATTERY_ROWS": {"class": "paper-defined",
                     "source": "§5.1 Table 5.1 (source rows 1-8)",
                     "anchor": "Outside Content"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port', 'junction', 'node'],
    "notes": "per-aspect decomposition: contributions emitted over node/junction/port aspects; the whole kind is not exercised.",
}
_ast.literal_eval(repr(INPUT_PROVENANCE))  # interface self-check: literal-evaluable


# ---------------------------------------------------------------------------
# State inventory: §5.1 Table 5.1 Outside Content tuples (the boundary tuple,
# by the §5.1 stipulation). Both s=1 rows listed.
# ---------------------------------------------------------------------------
STATE_ROWS = {
    "9":  ("X", "X", "X", "Y", "Y", "Y"),
    "1e": ("Y", "Y", "Y", "O", "O", "O"),   # Electron
    "1p": ("X", "X", "X", "O", "O", "O"),   # Positron
    "2":  ("X", "Y", "Y", "O", "O", "O"),
    "3":  ("X", "X", "Y", "O", "O", "O"),
    "4":  ("X", "X", "Y", "Y", "O", "O"),
    "5":  ("X", "Y", "Y", "Y", "O", "O"),
    "6":  ("X", "X", "X", "Y", "O", "O"),
    "7":  ("X", "X", "Y", "Y", "Y", "O"),
    "8":  ("X", "X", "X", "Y", "Y", "O"),
}
BATTERY_ROWS = ["1e", "1p", "2", "3", "4", "5", "6", "7", "8"]  # 9 source rows

# Aggregate (a) input data (paper-defined; see INPUT_PROVENANCE).
AGG_A_TRIPLES = {"n0": "4", "n1": "4", "n2": "4"}
AGG_A_JUNCTIONS = {"j0": {"ports": [("n0", 4), ("n1", 4), ("n2", 4)], "arity": 3}}


class CheckRejected(Exception):
    """A verification check rejected its input; carries the printed witness."""
    def __init__(self, witness):
        super().__init__(witness)
        self.witness = witness


class TermLedger(object):
    """An aspect-covering term multiset produced by a route's own per-aspect
    classification. The tautology guard (check 7) accepts ONLY TermLedgers: a
    fiat total (int/Fraction) has no per-aspect provenance and is rejected as
    a method, not as bad data."""
    def __init__(self, aspect_terms, source):
        aspects = [a for a, _ in aspect_terms]
        if len(set(aspects)) != len(aspects):
            dupes = sorted({a for a in aspects if aspects.count(a) > 1}, key=str)
            raise CheckRejected(
                "not aspect-covering: duplicate aspect emission %r" % (dupes,))
        self.aspect_terms = list(aspect_terms)
        self.aspects = frozenset(aspects)
        self.source = source

    def term_counter(self):
        return Counter(t for _, t in self.aspect_terms)


class Aggregate(object):
    """A bonded aggregate: node set V (node_id -> state-row key) + junction
    table E (junction_id -> {ports: [(node, idx)], arity: k})."""
    def __init__(self, name, triples, junctions):
        self.name = name
        self.triples = dict(triples)
        self.junctions = {j: {"ports": list(d["ports"]), "arity": d["arity"]}
                          for j, d in junctions.items()}
        self.nodes = sorted(self.triples)

    def all_ports(self):
        return {(v, p) for v in self.nodes for p in range(6)}

    def consumed(self):
        return {(v, p) for d in self.junctions.values() for (v, p) in d["ports"]}

    def boundary(self):
        return self.all_ports() - self.consumed()

    def aspect_set(self):
        A = {("node", v) for v in self.nodes}
        A |= {("junction", j) for j in self.junctions}
        A |= {("port", v, p) for (v, p) in self.boundary()}
        return A


# ---------------------------------------------------------------------------
# §2 per-aspect contribution c (symbolic).
# ---------------------------------------------------------------------------
def emit_contribution(agg, aspect, consumed):
    """c(a) for one aspect. consumed = the consumed-port set the route reads."""
    kind = aspect[0]
    if kind == "node":
        return 0  # interior resolved by participation in the completed junction
    if kind == "junction":
        return 0  # resolved by completion; NO junction s^2 is ever introduced
    _, v, p = aspect
    if (v, p) in consumed:
        # Route-1 boundary-only rule: consumed ports are not aspects of A(G) -- reaching the emitter is
        # a defensive hard error, never a zero term.
        raise CheckRejected(
            "consumed port (%r,%d) reached the Route-1 emitter "
            "(Route-1 boundary-only hard error: consumed ports are not aspects of A(G))" % (v, p))
    row = agg.triples[v]
    val = STATE_ROWS[row][p]
    if val == "O":
        return 0  # disjunct (i): O-valued (0-valued, categorical register) ->
                  # nothing to track -> cost exactly zero
    if row == "9":
        return 0  # disjunct (ii): declared Tracking-Cost-consistent choice
    return ("u", v, p)  # positive formal symbol, unique per port


def route1_enumerate(agg, consumed):
    """Route 1 (§4): enumerate every aspect of A(G) -- N (node,v) and |E|
    (junction,j) zero terms explicitly included; the port loop ranges over
    the boundary-port set ONLY. Returns an aspect-covering TermLedger."""
    terms = []
    for v in agg.nodes:
        terms.append((("node", v), emit_contribution(agg, ("node", v), consumed)))
    for j in sorted(agg.junctions):
        terms.append((("junction", j), emit_contribution(agg, ("junction", j), consumed)))
    for (v, p) in sorted(agg.all_ports() - consumed):
        a = ("port", v, p)
        terms.append((a, emit_contribution(agg, a, consumed)))
    return TermLedger(terms, source="route1")


# ---------------------------------------------------------------------------
# §4 checks.
# ---------------------------------------------------------------------------
def check2_input_validation(agg):
    """Input validation (these, not route agreement, constrain the input):
    junction port lists pairwise disjoint; arity declaration == port-list
    length; port index in 0..5; node id in V; consumed subset of all ports."""
    seen = {}
    for j in sorted(agg.junctions):
        d = agg.junctions[j]
        ports = d["ports"]
        if d["arity"] != len(ports):
            raise CheckRejected(
                "junction %r: arity declaration k=%d != port-list length %d"
                % (j, d["arity"], len(ports)))
        if d["arity"] < 2:
            raise CheckRejected("junction %r: arity %d < 2" % (j, d["arity"]))
        for (v, p) in ports:
            if v not in agg.triples:
                raise CheckRejected(
                    "junction %r names unknown node %r" % (j, v))
            if not (isinstance(p, int) and 0 <= p <= 5):
                raise CheckRejected(
                    "junction %r: port index %r outside 0..5" % (j, p))
            if (v, p) in seen:
                raise CheckRejected(
                    "port (%r,%d) listed in two junctions: %r and %r"
                    % (v, p, seen[(v, p)], j))
            seen[(v, p)] = j
    if not agg.consumed() <= agg.all_ports():
        raise CheckRejected("consumed port outside node port range")


def check6_port_invariants(agg):
    """Absolute port invariants: |dG| = 6N - sum(k_j) (dual computation);
    consumed u dG = all ports, disjoint; every port attributed exactly once."""
    N = len(agg.nodes)
    ksum = sum(d["arity"] for d in agg.junctions.values())
    B_set = len(agg.boundary())
    B_formula = N * 6 - ksum
    if B_set != B_formula:
        raise CheckRejected(
            "|dG|=%d != 6N-sum(k_j)=%d (dual computation disagrees)"
            % (B_set, B_formula))
    consumed, boundary, allp = agg.consumed(), agg.boundary(), agg.all_ports()
    if consumed & boundary:
        raise CheckRejected("consumed intersect dG nonempty: %r"
                            % sorted(consumed & boundary))
    if consumed | boundary != allp:
        raise CheckRejected("consumed union dG != all %d node ports" % len(allp))


def xy_count(row):
    return sum(1 for v in STATE_ROWS[row] if v in ("X", "Y"))


def o_count(row):
    return sum(1 for v in STATE_ROWS[row] if v == "O")


def arithmetic_audit(agg):
    """The arithmetic audit (§4): count-vector SHAPE prediction without
    per-port term emission. zeros_expected (interior) is a self-consistency
    fixed point; symbols_expected and port_zeros_expected are the
    independent count-vector predictions.

    Plan-faithfulness note: the plan's check-3 text ('exactly zeros_expected
    integer-0 terms' with zeros_expected = N+|E|) is unsatisfiable as written,
    because §2's contribution rule also emits integer 0 for O-valued boundary
    ports (and State-9 boundary ports under rule (ii)). The minimal honest
    repair keeps zeros_expected = N+|E| for the interior half and extends the
    count-vector prediction to the port-zero half (o(s) tallies minus consumed
    O ports, corrected for State-9 rows whose X/Y boundary ports emit 0 under
    rule (ii)). The audit thus predicts the FULL multiset shape."""
    N = len(agg.nodes)
    E = len(agg.junctions)
    zeros_expected = N + E
    n_s = Counter(agg.triples.values())
    total_xy = sum(n * xy_count(s) for s, n in n_s.items())
    total_o = sum(n * o_count(s) for s, n in n_s.items())
    consumed_xy = sum(1 for (v, p) in agg.consumed()
                      if STATE_ROWS[agg.triples[v]][p] in ("X", "Y"))
    consumed_o = sum(1 for (v, p) in agg.consumed()
                     if STATE_ROWS[agg.triples[v]][p] == "O")
    state9_xy_boundary = sum(
        1 for (v, p) in agg.boundary()
        if agg.triples[v] == "9" and STATE_ROWS["9"][p] in ("X", "Y"))
    state9_o_boundary = sum(
        1 for (v, p) in agg.boundary()
        if agg.triples[v] == "9" and STATE_ROWS["9"][p] == "O")
    symbols_expected = total_xy - consumed_xy - state9_xy_boundary
    port_zeros_expected = (total_o - consumed_o - state9_o_boundary
                           + state9_xy_boundary)
    return {"zeros_expected": zeros_expected,
            "port_zeros_expected": port_zeros_expected,
            "symbols_expected": symbols_expected, "N": N, "E": E}


def check1_aspect_covering(ledger, agg):
    """Route-1 enumeration covers every aspect of A(G) exactly once."""
    if ledger.aspects != agg.aspect_set():
        missing = sorted(agg.aspect_set() - ledger.aspects, key=str)
        extra = sorted(ledger.aspects - agg.aspect_set(), key=str)
        raise CheckRejected(
            "aspect coverage: missing=%r extra=%r" % (missing, extra))


def _is_int_zero(t):
    return type(t) is int and t == 0


def check3_audit_shape(ledger, audit, agg):
    """Arithmetic-audit shape agreement: exactly zeros_expected integer-0
    terms on interior aspects; exactly port_zeros_expected integer-0 terms on
    boundary ports; every other term a positive formal symbol (pairwise
    distinctness is enforced by check 5, which reads the raw term list -- a
    distinctness comparison over Counter keys here could never fire, and the
    old one was removed as dead code); symbol count equals the audit
    prediction."""
    interior_zeros = sum(1 for a, t in ledger.aspect_terms
                         if a[0] in ("node", "junction") and _is_int_zero(t))
    if interior_zeros != audit["zeros_expected"]:
        raise CheckRejected(
            "audit shape: %d integer-0 terms on interior aspects, audit "
            "expects %d (= N+|E|)" % (interior_zeros, audit["zeros_expected"]))
    port_zeros = sum(1 for a, t in ledger.aspect_terms
                     if a[0] == "port" and _is_int_zero(t))
    if port_zeros != audit["port_zeros_expected"]:
        raise CheckRejected(
            "audit shape: %d integer-0 terms on boundary ports, audit "
            "expects %d" % (port_zeros, audit["port_zeros_expected"]))
    tc = ledger.term_counter()
    symbols = [t for t in tc if t != 0]
    # No pairwise-distinctness assertion here: iterating a Counter yields
    # unique keys, so a distinctness comparison over `symbols` could never
    # fire (dead assertion removed; loop-back fix). Distinctness is enforced
    # solely by check5_symbol_hygiene, which iterates the raw term list.
    nsym = sum(tc[t] for t in symbols)
    if nsym != audit["symbols_expected"]:
        raise CheckRejected(
            "audit shape: %d positive-symbol occurrences, audit expects %d"
            % (nsym, audit["symbols_expected"]))


def check4_zero_audit(ledger, agg):
    """Zero audit: every interior aspect (node, junction) carries exactly the
    integer 0 (what 'no fiat junction s^2' means mechanically); every
    O-valued boundary port and every State-9 boundary port carries exactly 0."""
    for a, t in ledger.aspect_terms:
        kind = a[0]
        if kind in ("node", "junction"):
            if not _is_int_zero(t):
                raise CheckRejected(
                    "interior aspect %r carries non-zero term %r "
                    "(no fiat junction s^2)" % (a, t))
        else:
            _, v, p = a
            val = STATE_ROWS[agg.triples[v]][p]
            if (val == "O" or agg.triples[v] == "9") and not _is_int_zero(t):
                raise CheckRejected(
                    "port aspect %r (value %r, row %r) carries non-zero term %r"
                    % (a, val, agg.triples[v], t))


def check5_symbol_hygiene(ledger, agg):
    """Symbol hygiene: every nonzero term is a positive formal symbol --
    exactly the ("u", v, p) tuple the emitter produces (term-shape assertion:
    negative ints, positive ints, strings, or any other non-("u",...) term
    is a spec violation and is rejected here with a printed witness --
    loop-back fix); positive symbols pairwise distinct; their count equals
    the INDEPENDENTLY tallied open-X/Y-on-non-9 count (direct loop over dG,
    not the audit's count-vector path). THIS -- not the tautology guard --
    is what catches the vacuity mutant."""
    symbols = [t for _, t in ledger.aspect_terms if t != 0]
    # Term-shape assertion (loop-back fix for G1/G2): "positive formal
    # symbol" is a machine-checked shape, not prose. The emitter's
    # representation of an open tilt-presenting aspect is exactly the tuple
    # ("u", v, p). Distinct negative ints, distinct positive ints, and
    # distinct strings formerly passed checks 1,3,4,5,7 -- the machine only
    # checked "distinct nonzero terms" while the badge claimed "positive
    # formal symbols", and the prose S^2(G) >= S^2(G') corollary needs
    # nonnegativity.
    for t in symbols:
        if not (type(t) is tuple and len(t) == 3 and t[0] == "u"):
            raise CheckRejected(
                "symbol hygiene: nonzero term %r is not a positive formal "
                "symbol ('u', v, p) tuple" % (t,))
    if len(set(symbols)) != len(symbols):
        raise CheckRejected("symbol hygiene: positive symbols not pairwise distinct")
    tally = sum(1 for (v, p) in agg.boundary()
                if STATE_ROWS[agg.triples[v]][p] in ("X", "Y")
                and agg.triples[v] != "9")
    if len(symbols) != tally:
        raise CheckRejected(
            "symbol hygiene: %d positive symbols vs independently tallied %d "
            "open-X/Y-on-non-9 boundary ports" % (len(symbols), tally))


def check7_tautology_guard(ledger, agg, context=""):
    """Tautology guard (method rejection): the ledger predicate accepts ONLY
    aspect-covering term multisets produced by a route's own per-aspect
    classification. A fiat total plus round-trip division is rejected AS A
    METHOD. Documented as necessary-but-insufficient: the vacuity mutant IS
    aspect-covering and passes this guard (check 5 is its backstop)."""
    if not isinstance(ledger, TermLedger):
        witness = ("fiat total without per-aspect provenance -- round-trip "
                   "division is not a decomposition check")
        print("WITNESS check7/tautology-guard [%s]: %s" % (context, witness))
        raise CheckRejected(witness)
    check1_aspect_covering(ledger, agg)
    return True


def verify_decomposition(agg, label):
    """Honest pipeline: checks 1-7 over one aggregate. Returns (ledger, audit)."""
    check2_input_validation(agg)
    check6_port_invariants(agg)
    ledger = route1_enumerate(agg, agg.consumed())
    audit = arithmetic_audit(agg)
    check1_aspect_covering(ledger, agg)
    check3_audit_shape(ledger, audit, agg)
    check4_zero_audit(ledger, agg)
    check5_symbol_hygiene(ledger, agg)
    check7_tautology_guard(ledger, agg, label)
    return ledger, audit


# ---------------------------------------------------------------------------
# §5 counterfactual-robustness battery (this script's node subset).
# ---------------------------------------------------------------------------
def positive_symbol_aspects(agg, triples):
    """U(G): aspects with positive-symbol contributions under `triples`."""
    sub = Aggregate(agg.name, triples, agg.junctions)
    ledger = route1_enumerate(sub, sub.consumed())
    return {a for a, t in ledger.aspect_terms if t != 0}


def battery_tilt_removal(agg, pinned_nodes, f7_min):
    """§5 battery: for each pinned node v and each source row s (9 rows):
    substitute v := s (counterfactual term-rewriting on the formal expression,
    licensed by the categorical inventory -- not a dynamical claim), assert the
    substitution took effect (effectiveness), tie the emission to the audit's count-vector
    machinery, machine-check the precondition per (node, row) -- never
    assumed -- then check the strict count inequality |U(G')| < |U(G)| for
    v := State 9. The S^2(G) >= S^2(G') reading is a prose corollary only
    (Tracking-Cost nonnegativity + the machine-checked strict set inclusion);
    strict positivity of symbols is NOT assumed."""
    n = 0
    for v in pinned_nodes:
        for s in BATTERY_ROWS:
            G_s = dict(agg.triples)
            G_s[v] = s
            # Effectiveness assertions (close the no-op-substitution vacuity):
            assert STATE_ROWS[G_s[v]] == STATE_ROWS[s], \
                "substitution did not take effect at node %r" % v
            U = positive_symbol_aspects(agg, G_s)
            sub = Aggregate(agg.name, G_s, agg.junctions)
            assert len(U) == arithmetic_audit(sub)["symbols_expected"], \
                "battery emission disagrees with the audit count vector"
            # Precondition, machine-checked per (node, row): every node retains
            # an open tilt port; the analytic open-X/Y bound is the stronger check.
            for w in sub.nodes:
                open_xy = sum(1 for (vv, p) in sub.boundary() if vv == w
                              and STATE_ROWS[G_s[w]][p] in ("X", "Y"))
                assert open_xy >= f7_min[w], \
                    "analytic open-X/Y bound violated at (%r, %r): %d" % (w, s, open_xy)
                assert open_xy >= 1, "precondition violated at (%r, %r)" % (w, s)
            G_9 = dict(G_s)
            G_9[v] = "9"
            U9 = positive_symbol_aspects(agg, G_9)
            assert U9 < U, "§5 strictness failed at (%r, %r)" % (v, s)
            assert len(U9) < len(U)
            n += 1
    return n


# ---------------------------------------------------------------------------
# §8 planted-mutant battery. EVERY planted-variant function/builder/fixture
# carries planted/mutant/witness in its name (P1/P2 interface, F.49 RT_SCAN).
# ---------------------------------------------------------------------------
def mutant_0_all_zero_route(agg):
    """Vacuity mutant: emits integer 0 for every aspect, including open X/Y
    ports. Aspect-covering -- PASSES the tautology guard (documented as
    necessary-but-insufficient) and the zero audit vacuously; rejected by the
    symbol-hygiene / audit count check (checks 3+5)."""
    terms = [(a, 0) for a in sorted(agg.aspect_set(), key=str)]
    ledger = TermLedger(terms, source="mutant_0_all_zero_route")
    check7_tautology_guard(ledger, agg, "mutant_0")  # passes: shape, not content
    audit = arithmetic_audit(agg)
    try:
        check5_symbol_hygiene(ledger, agg)
    except CheckRejected:
        print("WITNESS mutant_0_all_zero_route: vacuous all-zero route rejected -- "
              "0 positive symbols vs independently tallied %d open-X/Y-on-non-9 "
              "(tautology guard passed: it checks shape, not content)"
              % audit["symbols_expected"])
        return True
    raise AssertionError("mutant_0 NOT rejected")


def mutant_1_invented_junction_s2(agg):
    """Variant route adds one fresh positive symbol per completed junction
    ('the junction's own s^2'). Rejected by the zero audit (check 4); the
    witness prints the junction id and the offending term."""
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        if a[0] == "junction":
            terms.append((a, ("u_junction_mutant_1", a[1])))
        else:
            terms.append((a, t))
    ledger = TermLedger(terms, source="mutant_1_invented_junction_s2")
    try:
        check4_zero_audit(ledger, agg)
    except CheckRejected as e:
        print("WITNESS mutant_1_invented_junction_s2: fiat junction s^2 "
              "rejected -- %s" % e.witness)
        return True
    raise AssertionError("mutant_1 NOT rejected")


def mutant_2_resolved_port_positive(agg, witness_port_mutant_2):
    """Variant route misreads the junction table: the witness consumed port is
    classified as open. Rejected by the audit-vs-enumeration shape mismatch
    (check 3) together with the consumed-port exclusion; the witness names the
    (node, port)."""
    assert witness_port_mutant_2 in agg.consumed()
    variant_consumed = agg.consumed() - {witness_port_mutant_2}
    ledger = route1_enumerate(agg, variant_consumed)
    audit = arithmetic_audit(agg)
    try:
        check3_audit_shape(ledger, audit, agg)
    except CheckRejected as e:
        print("WITNESS mutant_2_resolved_port_positive: consumed port %r "
              "misclassified as open -- %s"
              % (witness_port_mutant_2, e.witness))
        return True
    raise AssertionError("mutant_2 NOT rejected")


def mutant_3_table_double_count(agg, witness_fixture_mutant_3_table):
    """Variant JUNCTION TABLE lists one port in two junctions. Rejected by the
    pairwise-disjointness input-validation check (check 2); the witness names
    the port and both junctions. (Route agreement could never catch this --
    it is an input-level double count.)"""
    variant = Aggregate(agg.name + "/mutant_3", agg.triples,
                        witness_fixture_mutant_3_table)
    try:
        check2_input_validation(variant)
    except CheckRejected as e:
        print("WITNESS mutant_3_table_double_count: %s" % e.witness)
        return True
    raise AssertionError("mutant_3 NOT rejected")


def mutant_4_legacy_proof(agg):
    """The OLD method offered as a proof: a fiat total plus round-trip
    division. Rejected AS A METHOD by the tautology guard (check 7): the total
    has no per-aspect provenance. (Disclosure would not cure it -- even with
    the old docstring disclaimer attached, it is rejected.)"""
    s2_total = Fraction(50)  # the old fiat literal
    n = len(agg.nodes) + len(agg.junctions)
    try:
        check7_tautology_guard(s2_total / n * n, agg, "mutant_4_legacy_proof")
    except CheckRejected:
        return True  # witness printed by the guard
    raise AssertionError("mutant_4 NOT rejected")


def mutant_5_order_violation(agg, witness_node_mutant_5):
    """Variant claims a State-1 -> State-9 substitution does not strictly
    decrease the positive-symbol count. Rejected by the machine-checked §5
    inequality; the witness prints the aggregate, node, and both counts.
    CONDITIONAL on the declared State-9 rule (ii): without (ii) the inequality
    reverses and the variant's claim becomes true."""
    v = witness_node_mutant_5
    G_1 = dict(agg.triples); G_1[v] = "1e"
    G_9 = dict(G_1); G_9[v] = "9"
    U1 = positive_symbol_aspects(agg, G_1)
    U9 = positive_symbol_aspects(agg, G_9)
    assert len(U9) < len(U1), "§5 strictness premise failed"
    variant_claim_holds = len(U9) >= len(U1)
    if not variant_claim_holds:
        print("WITNESS mutant_5_order_violation: State-1->State-9 substitution on "
              "node %r of %r strictly decreases positive symbols: |U(G)|=%d -> "
              "|U(G')|=%d; the 'does not decrease' claim is rejected "
              "(conditional on the declared rule (ii))" % (v, agg.name, len(U1), len(U9)))
        return True
    raise AssertionError("mutant_5 NOT rejected")


def mutant_6_uniform_division(agg):
    """Defect-1 regression: variant computes per-aspect shares by division
    (the old total/interior_count, total/boundary pattern). Rejected: division
    assigns positive shares to resolved interior aspects, violating the
    exact-zero rule (check 4); the witness prints the interior aspect and its
    non-zero share. Documents why the old defect-1 code can never return."""
    audit = arithmetic_audit(agg)
    S = audit["symbols_expected"]            # fiat total (the defect: a count
                                             # used as a divisible total)
    n_interior = len(agg.nodes) + len(agg.junctions)
    share = Fraction(S, n_interior)           # the old total/interior pattern
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        terms.append((a, share) if a[0] in ("node", "junction") else (a, t))
    variant = TermLedger(terms, source="mutant_6_uniform_division")
    try:
        check4_zero_audit(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_6_uniform_division: uniform division rejected -- "
              "%s (divided share %s)" % (e.witness, share))
        return True
    raise AssertionError("mutant_6 NOT rejected")


def mutant_7_o_port_positive(agg, witness_port_mutant_7):
    """Variant assigns a positive symbol to an open O-valued boundary port.
    Rejected by the value-0 rule (disjunct (i); check 4); the witness names
    the port."""
    v, p = witness_port_mutant_7
    assert (v, p) in agg.boundary()
    assert STATE_ROWS[agg.triples[v]][p] == "O"
    terms = []
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        terms.append((a, ("u_mutant_7", v, p))
                     if a == ("port", v, p) else (a, t))
    variant = TermLedger(terms, source="mutant_7_o_port_positive")
    try:
        check4_zero_audit(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_7_o_port_positive: %s" % e.witness)
        return True
    raise AssertionError("mutant_7 NOT rejected")


def mutant_8_negative_terms(agg):
    """Positive-symbol SHAPE mutant (loop-back fix for G1/G2): emits DISTINCT
    NEGATIVE INTS on open X/Y ports in place of positive formal symbols.
    This variant passed checks 1, 3, 4, 5, and 7 on the old code -- the
    machine checked only 'distinct nonzero terms' while the badge claimed
    'positive formal symbols', and the prose S^2(G) >= S^2(G') corollary
    needs nonnegativity, so a negative-term variant passing silently is a
    genuine spec violation. Rejected by the check-5 term-shape assertion
    (every nonzero term must be a ('u', v, p) tuple); the witness prints the
    first offending term."""
    terms = []
    k = 0
    for a, t in route1_enumerate(agg, agg.consumed()).aspect_terms:
        if a[0] == "port" and t != 0:
            k += 1
            terms.append((a, -(1000 + k)))
        else:
            terms.append((a, t))
    variant = TermLedger(terms, source="mutant_8_negative_terms")
    try:
        check5_symbol_hygiene(variant, agg)
    except CheckRejected as e:
        print("WITNESS mutant_8_negative_terms: %s" % e.witness)
        return True
    raise AssertionError("mutant_8 NOT rejected")


def selftest_arity_crosscheck_rejects(agg):
    """check 2 cross-checks each arity declaration against its port-list
    length (catches a wrong arity -- the old bidirectional miscount class)."""
    bad = {j: {"ports": list(d["ports"]), "arity": d["arity"]}
           for j, d in agg.junctions.items()}
    j0 = sorted(bad)[0]
    bad[j0] = {"ports": bad[j0]["ports"][:-1], "arity": bad[j0]["arity"]}
    variant = Aggregate(agg.name + "/selftest", agg.triples, bad)
    try:
        check2_input_validation(variant)
    except CheckRejected as e:
        print("selftest: arity cross-check rejects the miscount -- %s" % e.witness)
        return True
    raise AssertionError("arity cross-check did not reject")


# ---------------------------------------------------------------------------
# Main: aggregate (a).
# ---------------------------------------------------------------------------
def main():
    agg = Aggregate("aggregate-(a)", AGG_A_TRIPLES, AGG_A_JUNCTIONS)

    ledger, audit = verify_decomposition(agg, "aggregate-(a)")
    assert audit["symbols_expected"] == 12, audit  # 15 boundary - 3 open O's
    assert audit["zeros_expected"] == 4, audit     # 3 nodes + 1 junction
    assert audit["port_zeros_expected"] == 3, audit  # 3 open O ports (idx 5)
    assert len(agg.boundary()) == 15
    print("F.33 PASS: aggregate (a) decomposition identity -- 4 interior aspects "
          "at exactly 0, 12 positive symbols; Route-1 enumeration and the "
          "arithmetic audit agree (checks 1-7 green).")

    n_battery = battery_tilt_removal(agg, ["n0", "n1", "n2"],
                                     {"n0": 3, "n1": 3, "n2": 3})
    assert n_battery == 27, n_battery
    print("F.33 PASS: §5 counterfactual battery -- 27/27 substitution "
          "inequalities strict (3 nodes x 9 source rows); substitution-"
          "effectiveness assertions and analytic open-X/Y bounds (>=3 per "
          "node-row) green.")

    assert mutant_0_all_zero_route(agg)
    assert mutant_1_invented_junction_s2(agg)
    assert mutant_2_resolved_port_positive(agg, ("n0", 4))
    witness_fixture_mutant_3_table = {
        "j0": {"ports": [("n0", 4), ("n1", 4), ("n2", 4)], "arity": 3},
        "j1": {"ports": [("n0", 4), ("n1", 0)], "arity": 2},  # (n0,4) twice
    }
    assert mutant_3_table_double_count(agg, witness_fixture_mutant_3_table)
    assert mutant_4_legacy_proof(agg)
    assert mutant_5_order_violation(agg, "n0")
    assert mutant_6_uniform_division(agg)
    assert mutant_7_o_port_positive(agg, ("n0", 5))
    assert mutant_8_negative_terms(agg)
    print("F.33 PASS: 9/9 planted mutants rejected with printed witnesses "
          "(mutant_0 vacuity via checks 3+5; mutant_4 legacy method via the "
          "tautology guard; mutant_8 negative-term shape via check 5).")

    assert selftest_arity_crosscheck_rejects(agg)
    print("F.33 PASS: input-validation arity cross-check rejects miscounts.")
    print("F.33 DONE: [LEVEL A] conditional on the Tracking-Cost Lemma (port-level composition), §6.1, "
          "§5.1 Table 5.1 and its boundary-tuple stipulation, the R15 sum "
          "rule and Port Count Invariance (§4.3), the junction arity >= 2 "
          "rule, and the Appendix B / §9 / F.41 construction premises; the "
          "machine checks the counting, not the premises. Rule (ii) is a "
          "declared Tracking-Cost-consistent disambiguation.")


if __name__ == "__main__":
    main()