INPUT_PROVENANCE = {
    "STATES": {"class": "control", "note": "sweep population: F.43's 7,380-state k=1..4 enumeration, imported never regenerated"},
    "RANDS": {"class": "control", "note": "script-generated fixed-seed sweep population (2,850 random states, k=2..20) over the §7.5 local-junction-state space"},
    "ALIGNED": {"class": "paper-defined", "source": "§7.2 Definition (Alignment) — asserted native definitional content, author-authorized (changelog #130); ALIGNED(sigma) := tau(sigma) == 0"},
    "TOWARD": {"class": "paper-defined", "source": "§7.2 Definition (Alignment) — asserted native definitional content, author-authorized (changelog #130); TOWARD(sigma) := tau(T(sigma)) < tau(sigma)"},
    "rejected": {"class": "control", "note": "test fixture / rejection counter"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "alignment correspondence over port-value tuples (the §7.5 local-junction-state space, via F.43's reference operator); backing claims quantify over no aspect kinds. Every 'alignment' claim below is conditional on the asserted §7.2 Definition (Alignment) (author-authorized, changelog #130).",
}
#!/usr/bin/env python3
"""Paper 11 - F.55: the alignment correspondence check (§7.2, asserted definition).

Implements the §7.2 asserted Definition (Alignment) and machine-checks
its correspondence with the §7.5 resolution transition:

  (i)   tau_J >= 0 always;
  (ii)  ALIGNED(sigma) := tau(sigma) == 0 is exactly the no-unmatched-integers
        state (every port value 0);
  (iii) every T-action strictly decreases tau_J (Delta = -2) -- i.e. moves
        toward alignment under the asserted definition (toward := strict
        per-tick tau decrease);
  (iv)  aligned states are fixed points (T(sigma) == sigma);
  (v)   the stutter-with-tension class is exactly the non-aligned fixed
        points (T(sigma) == sigma with tau_J > 0) -- direction is not
        arrival, machine-demonstrated on witnesses from all three
        stutter classes (dangling, same-sign, cross-only).

EPISTEMIC STANDING. This script checks the CORRESPONDENCE between the F.43
operator and the §7.2 asserted Definition (Alignment). The definition itself
is ASSERTED native definitional content (author-authorized, changelog #130)
-- asserted, not machine-proved. Every "alignment" claim printed here is
CONDITIONAL on that asserted definition. No registry claim is badged on this
script; the script stays staged-unlisted pending the author's ruling.

The reference operator is F.43's -- imported, never hand-copied, never
silently forked (the import executes F.43's own checks first, so this script
cannot run on a corrupt operator).
"""

import F43_shove_transition as _f43

tension = _f43.tension
T = _f43.T_ref
admissible = _f43.admissible

# The asserted definition (§7.2, changelog #130).
def ALIGNED(sigma):
    """A junction is aligned iff tau_J = 0 (all integers matched)."""
    return tension(sigma) == 0

def TOWARD(sigma):
    """A transition is toward alignment iff it strictly decreases tau_J."""
    return tension(T(sigma)) < tension(sigma)

STATES = _f43.ENUM14                      # 7,380 states, k = 1..4
RANDS = _f43.rand_states(range(2, 21), 150, 31337)  # 2,850 states, k = 2..20

def unmatched(sigma):
    A, B = sigma
    return [x for x in A + B if x != 0]

# --------------------------------------------------------------------------
# (i) tau_J >= 0 always.
# --------------------------------------------------------------------------
for s in STATES + RANDS:
    assert tension(s) >= 0, ("negative tension", s)
print("F.55 PASS (i): tau_J >= 0 on %d states (k = 1..4 enumeration + "
      "k = 2..20 random)." % (len(STATES) + len(RANDS)))

# --------------------------------------------------------------------------
# (ii) ALIGNED(sigma) is exactly the no-unmatched-integers state.
# --------------------------------------------------------------------------
for s in STATES + RANDS:
    assert ALIGNED(s) == (unmatched(s) == []), ("alignment mismatch", s)
print("F.55 PASS (ii): ALIGNED(sigma) == (tau == 0) == (no unmatched "
      "integers) on all %d states." % (len(STATES) + len(RANDS)))

# --------------------------------------------------------------------------
# (iii) every T-action strictly decreases tau_J -- moves toward alignment
# under the asserted definition (toward := strict per-tick decrease).
# --------------------------------------------------------------------------
n_acted = 0
for s in STATES + RANDS:
    t = T(s)
    if t != s:
        n_acted += 1
        dt = tension(t) - tension(s)
        assert dt == -2, ("action did not drop tau by 2", s, dt)
        assert TOWARD(s), ("action without toward-alignment", s)
    else:
        assert not TOWARD(s), ("toward-alignment on a stutter", s)
assert n_acted > 0, "no actions exercised"
print("F.55 PASS (iii): %d T-actions, every one strictly decreases tau_J "
      "(Delta = -2) -- toward alignment under the asserted definition; "
      "no stutter is toward alignment." % n_acted)

# --------------------------------------------------------------------------
# (iv) aligned states are fixed points.
# --------------------------------------------------------------------------
n_aligned = 0
for s in STATES + RANDS:
    if ALIGNED(s):
        n_aligned += 1
        assert T(s) == s, ("aligned state not a fixed point", s)
print("F.55 PASS (iv): all %d aligned states are fixed points "
      "(T(sigma) == sigma)." % n_aligned)

# --------------------------------------------------------------------------
# (v) the stutter-with-tension class is exactly the non-aligned fixed
# points -- direction is not arrival, machine-demonstrated.
# --------------------------------------------------------------------------
witnesses = {}
for s in STATES:
    fixed = (T(s) == s)
    tau = tension(s)
    if fixed and tau > 0:
        assert not admissible(s), ("acting state misclassified as stutter", s)
        for r in _f43.stall_reasons(s):
            witnesses.setdefault(r, s)
    elif fixed:
        assert tau == 0, ("zero-action non-aligned fixed point", s)
assert set(witnesses) == {"dangling", "same-sign", "cross-only"}, witnesses
print("F.55 PASS (v): non-aligned fixed points are exactly the "
      "stutter-with-tension class (all three classes witnessed):")
for r, w in sorted(witnesses.items()):
    print("    %-10s witness %r: tau = %d > 0, T(sigma) == sigma -- "
          "direction, not arrival." % (r, w, tension(w)))

# --------------------------------------------------------------------------
# Planted mutants: genuine spec violations, each rejected with a witness.
# --------------------------------------------------------------------------
rejected = 0

# M1: misdefined alignment admitting tau_J > 0 states (aligned := tau <= 2).
def aligned_loose(sigma):
    return tension(sigma) <= 2

bad = [s for s in STATES if aligned_loose(s) and unmatched(s) != []]
assert bad, "M1 passed undetected"
w = bad[0]
print("F.55 PASS M1 REJECTED -- misdefined alignment (tau <= 2) admits "
      "tau_J > 0 states: witness %r has tau = %d with unmatched integers "
      "present." % (w, tension(w)))
rejected += 1

# M2: a T-variant violating strict tau decrease (F.43's T_tension_up resolves,
# then re-opens a neighboring position: the action does not strictly decrease
# tau, so it breaks toward-alignment).
viol = [s for s in STATES
        if _f43.T_tension_up(s) != s
        and tension(_f43.T_tension_up(s)) >= tension(s)]
assert viol, "M2 passed undetected"
w = viol[0]
print("F.55 PASS M2 REJECTED -- tau-non-decreasing T-variant breaks "
      "toward-alignment: witness %r: tau %d -> %d (no strict decrease)."
      % (w, tension(w), tension(_f43.T_tension_up(w))))
rejected += 1

# M3: a claimed-arrival variant -- "every sigma reaches an aligned state" --
# refuted by a stutter witness (direction is not arrival).
def reaches_aligned(sigma, steps=10000):
    s = sigma
    for _ in range(steps):
        if ALIGNED(s):
            return True
        s2 = T(s)
        if s2 == s:
            return False
        s = s2
    return False

stuck = [s for s in STATES if tension(s) > 0 and T(s) == s]
assert stuck, "no stutter witnesses"
w = stuck[0]
assert not reaches_aligned(w), "M3 passed undetected"
print("F.55 PASS M3 REJECTED -- claimed arrival refuted by stutter witness "
      "%r: tau = %d > 0, T(sigma) == sigma, no aligned state ever reached."
      % (w, tension(w)))
rejected += 1

assert rejected == 3, rejected
print("=" * 70)
print("F.55 ALL PASS: the alignment correspondence holds -- CONDITIONAL on")
print("the asserted §7.2 Definition (Alignment) (author-authorized).")
print("  states checked : %d (k = 1..4) + %d (k = 2..20)" %
      (len(STATES), len(RANDS)))
print("  planted mutants: 3/3 rejected with printed witnesses")
print("=" * 70)
