#!/usr/bin/env python3
"""Paper 11 - F.54: proof<->registry cross-check.

The never-again guard for the registry-vs-proofs direction defect: F.38
checks the claim registry against itself (every claim's dependency and
axiom records are checked for internal consistency), but no check ever asks
whether the registry's dependency records agree with what the paper's own
proofs cite. A proof that cites a section whose claim the registry models
as depending on the citing claim is a direction inversion the registry's
self-check cannot see. This script closes that gap: it reads the paper's
proof blocks, header badges, and the E.3 derivation records, and checks
each against the registry's dependency topology.

Checks
------
3A. Proof-block citation check. Every ``*Proof.*`` block outside fenced code
    regions is attributed to the claim it proves (nearest preceding
    Theorem/Lemma/Definition header, resolved to a registry claim through
    the section map). Every Paper-11-local section citation inside the block
    is resolved to registry claims and derived labels through the section
    map — plus the cited section's header badge labels (V6: the finding-5
    class — a proof citing "the definition of open ports in §4.3" names the
    section's definitional content, which the header badge attributes to
    L6-P11; the map must see that label, not just the section's claims).
    The verdict, per (claim, cited section), is:
      - SATISFIED: a cited claim is reachable from the citing claim in the
        registry dependency graph, or a cited derived label is in the
        citing claim's axiom closure. Checked first, existentially: a
        section hosting several claims is satisfied if any of them is
        reachable. This charity is deliberate - the check is
        section-granular, and flagging a citation that also resolves
        upstream would manufacture false positives.
        V6 loop refinement (G3): when the claim-channel hit is an
        axiom-level (deps []) claim but a PRIMITIVE label also satisfies
        the citation, the verdict grounds on the primitive label, not the
        claim. Rationale: an axiom-level claim is definitional content;
        attributing a definitional citation to one specific definition
        risks the G3 misattribution (the §7.2 proof's "Shear tension is the
        unmatched-integer count τ_J (§7.1)" cites the Identity paragraph —
        TENSION_MEASURE_IDENTITY's registered content — not RESOLUTION_VERB,
        whose "unmatched integers produce shear tension" the Identity
        paragraph explicitly rejects). The primitive label is the honest
        level; which definition was cited stays human-audit territory
        (disclosed section-granularity limit).
      - DIRECTION_MISMATCH: no cited target is upstream of the citing
        claim, but a cited claim (or cited label) is modeled as depending
        on the citing claim. The registry edge points the wrong way
        relative to the proof.
      - UNMODELED_CITATION: the cited content is in neither the claim's
        dependency closure nor its axiom closure, and no reverse edge
        exists. The proof leans on content the registry does not model.
      - UNRESOLVED_SECTION: the cited section maps to no registry claim
        and no derived label. A census entry, never a violation.
      - REGISTRY_INCOMPLETENESS (V6 loop, B3): the cited section hosts a
        [LEVEL X] claim header that attributes to no registry claim. A
        violation kind, not census — but reported informationally, not
        failing: registering a new claim requires the author's word, so the
        guard surfaces the gap (with the paper-open adjudication) rather
        than blocking on it. Disclosed conditionals (V6 loop, B3:
        DISCLOSED_CONDITIONALS — unregistered [LEVEL A] material whose
        conditional status the paper discloses, e.g. the §6.1 bonding
        lemma per changelog #91) are informational, never violations.
    Cross-paper citations ("Paper N section") are excluded: they address
    another document, which this paper's registry cannot model.
3B. E.3 derivation-record direction check. Each E.3 row whose token
    resolves to a derived label is compared against that label's registry
    derivation record. A paper "Derived from" entry that the registry
    models as depending on the token's label is a direction inversion; a
    paper entry absent from the registry record without an inversion is
    reported as derivation drift.
4.  Header badge check. "depends ..." / "derivation record [...]" badges on
    claim headers are tokenized and compared exactly against the attributed
    claim's registry axiom set. V6 loop (B1): the bracket form
    "[Lx·Ly·…]" on "###" section headers and claim headers (the form of
    16/17 V6 fixes) is now parsed too. Claim-header bracket badges are
    compared exactly against the attributed claim's axioms. Section-header
    bracket badges are compared exactly against the section's single
    associated claim's axioms when the section header is that claim's sole
    machine-readable axiom list (exactly one associated claim and no
    claim-header bracket badge in the section); sections with claim-level
    badges, multiple associated claims, or no associated claims are not
    coverage-checked at the section level (disclosed boundary — the claim
    badge is the checked form where one exists). Tokens in PROSE_PRIMITIVE
    (V6: documented prose-level primitives — "tick", "a_k" — per the R18
    design decision, the §0.5.w tick lock (native tick is ordinal, not
    durational), and Paper 2 §1) are reported as PROSE_TOKEN
    (informational), never as violations. Dropped tokens (in the registry,
    absent from the badge) and extra tokens (in the badge, absent from the
    registry) are reported. (Full-layer [L1...] badges are a different,
    intentionally redundant convention and are outside this check.)
    Held findings (V6: HELD_FINDINGS — genuine findings parked pending the
    author's ruling, currently the E.3 engagement/L8-P11/L10-P11 direction
    question) print as HELD and do not fail the run; an entry that no
    longer matches the paper fails loudly. The held key includes the
    finding's direction content (V6 loop, A5/B2: the detail string), so a
    mutated parked finding fails loudly instead of matching a stale entry.
5.  Axioms↔proof-content check (V6 loop, B4/O1). Every derived (non-
    primitive) axiom label of a Level-A claim must be leaned on by at
    least one proof block attributed to that claim — "leaned on" means the
    proof cites a section whose label map carries the label, or the label
    is in a dependency's axiom closure. A label in the registry axioms
    (and the badge) that no proof block leans on is OVER_AXIOMATIZATION.
    Boundary disclosed honestly: the check is citation-granular, not
    semantic — a proof that uses a label's content without citing its
    section is a false positive by design, human-adjudicated.

Disclosures (the five required items)
-------------------------------------
(a) Native domain: the paper's sentences - proof blocks, header badges,
    and E.3 "Derived from" cells in paper_11.md.
(b) Verified domain: (1) the topology of proof-block section citations
    against the registry dependency graph (direction and presence only);
    (2) the token sets of header badges (depends-form and bracket-form)
    against registry axiom sets; (3) the label sets of E.3 derivation
    records against registry derivation records (direction only);
    (4) derived axiom labels against proof-block citation maps (presence
    of leaning only); (5) [LEVEL X] claim headers in cited sections
    against registry attribution (presence only). Nothing else.
(c) The map: section citations resolve through the section map (the
    RESOLUTIONS proved-sections inverted at runtime, plus derived-label
    sections from the registry); the dependency graph is the registry's
    own deps/axioms/derives_from edges with transitive closure computed at
    runtime by breadth-first search; header badges attribute to claims
    through the label named in the badge (or the enclosing claim header's
    label), resolved through the registry's label records.
(d) What the map preserves: exactness of the topology. Every finding names
    a real paper line and the real registry edges behind the verdict; the
    script invents no citations, no edges, and no claims. The section map
    and all closures are derived at runtime from the imported registry
    data - no result is hardcoded.
(e) What stays outside the machine check: the semantic content of a cited
    section (whether the cited section's content actually supports the
    proof step); prose citations outside proof blocks (except the E.3 and
    badge records, which are their own checks); cross-paper citations;
    sub-section (named) citation precision - the check is section-granular;
    whether a "forward reference" gloss discharges a direction debt (human
    ruling); which definition a definitional citation names (the guard
    grounds definitional citations at the primitive-label level; the
    Identity-paragraph vs verb distinction is human-audit territory);
    whether an axiom label's content is used without a citation (check 5
    is citation-granular by design); section-header badges where a
    claim-level badge exists, or with multiple/zero associated claims
    (human-audit territory); and the truth of the direction-mismatch
    findings themselves, which need a human ruling on whether the cited
    content is axiom-level for the citing claim.

Scope honesty
-------------
This is a topology checker, not a semantic prover. It cannot tell whether
a cited section's content actually establishes the proof step, only
whether the registry models the cited content as upstream of the citing
claim. An UNRESOLVED_SECTION is a census entry (the paper cites a section
that is neither a claim section nor a derived-label section), never a
violation. Sections hosting several claims are checked existentially, as
disclosed above: a citation that names no claim precisely enough to
disambiguate stays human-audit territory. If the registry data changes
shape incompatibly (a row without id/axioms/deps, a label without
derives_from/section/kind, a registry id absent from the section map, or
an empty parse where the paper must have content), the script fails loudly
instead of silently passing.

Sanitation
----------
No auditor grading language appears in this script's text. The defect
family is named only as "the registry-vs-proofs direction defect".

Import-cycle safety
-------------------
This module imports F.38 (REGISTRY, DERIVED, PRIMITIVE) and F.52
(RESOLUTIONS). Neither F.38 nor F.52 imports F.54, so there is no cycle.
The check functions take the registry data as parameters, so the
planted-mutant battery can run them against synthetic registries without
touching the live paper or the live registry.
"""

INPUT_PROVENANCE = {
    "HERE": {"class": "control",
             "note": "runtime path to this script's directory"},
    "PAPER_MD": {"class": "paper-defined",
                 "source": "paper_11.md (working source)",
                 "note": "paper text under test; proof blocks, header "
                         "badges, and the E.3 table are parsed from it"},
    "REGISTRY": {"class": "paper-defined",
                 "source": "F38_claim_registry.py REGISTRY",
                 "note": "claim dependency and axiom records under test"},
    "DERIVED": {"class": "paper-defined",
                "source": "F38_claim_registry.py DERIVED",
                "note": "derived-label derivation records under test"},
    "PRIMITIVE": {"class": "paper-defined",
                  "source": "F38_claim_registry.py PRIMITIVE",
                  "note": "primitive label set; closure bottom-out"},
    "RESOLUTIONS": {"class": "paper-defined",
                    "source": "F52_theorem_map.py RESOLUTIONS",
                    "note": "claim -> (stated section, proved section); "
                            "inverted at runtime into the section map"},
    "PATTERNS": {"class": "control",
                 "note": "the script's own section-citation, header, and "
                         "badge patterns"},
    "MUTANTS": {"class": "control",
                "note": "synthetic registries, proofs, and badges run "
                        "through the check functions; each must be "
                        "rejected with a printed witness"},
    "CONTROLS": {"class": "control",
                 "note": "synthetic passing cases; labeled diagnostic, "
                         "never counted among rejections"},
    "PROSE_PRIMITIVE": {"class": "control",
                        "note": "declared prose-level primitive token set "
                                "{tick, a_k}: anchored to the R18 design "
                                "decision (F.38 DERIVED comment), the "
                                "§0.5.w tick lock (native tick is ordinal, not durational), and Paper 2 §1; "
                                "reported as PROSE_TOKEN, never a violation"},
    "HELD_FINDINGS": {"class": "declared-assumption",
                      "note": "genuine findings parked pending the author's "
                              "ruling (currently the E.3 engagement / "
                              "L8-P11 / L10-P11 direction question, held "
                              "v50 Obj 1); each entry must match a live "
                              "finding on check, kind, token, label AND the "
                              "direction content (detail string), or the "
                              "script fails loudly"},
    "DISCLOSED_CONDITIONALS": {"class": "paper-defined",
                               "source": "paper_11.md changelog #91 and "
                                         "[LEVEL A] conditional-on prose",
                               "note": "unregistered [LEVEL A] material "
                                       "whose conditional status the paper "
                                       "discloses (currently the §6.1 "
                                       "bonding lemma); informational, never "
                                       "a violation"},
    "HEADER_LABELS": {"class": "paper-defined",
                     "source": "paper_11.md section header badges "
                               "(### §N ... [Lx-P11 ...])",
                     "note": "section header badge labels parsed from the "
                             "paper under test; merged into the section map "
                             "for the finding-5 citation class"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "proof<->registry cross-check machinery; backs no claim.",
}

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER_MD = (HERE.parent / "paper_11.md").read_text(encoding="utf-8")

import F38_claim_registry as f38
import F52_theorem_map as f52

REGISTRY = f38.REGISTRY
DERIVED = f38.DERIVED
PRIMITIVE = f38.PRIMITIVE
RESOLUTIONS = f52.RESOLUTIONS

# V6 (staged): prose-level primitives exempt from badge-token comparison.
# The §3.1 header badge's "tick" token is a documented prose-level primitive
# (R18 design decision — F.38's DERIVED comment: "tick is the Stage-N event
# serialization the proof runs over, not a premise label"; the §0.5.w
# tick lock (native tick is ordinal, not durational); Paper 2 §1 a_k), not a registry label. Extra badge tokens
# in this set are reported as PROSE_TOKEN (informational), never as
# violations — this preserves the guard's power over real label tokens.
PROSE_PRIMITIVE = {"tick", "a_k"}

# V6 loop (A2b/B1): label tokens recognized in header badges — derived
# Paper-11 labels (L\d+-P11), primitive labels (L1–L4 and the named
# primitives), and prose primitives (informational only, never labels).
BADGE_LABEL_RE = re.compile(r"\b(L\d+-P11|L\d+|BUDGET|PTR|DSC|S3|tick|a_k)\b")

# V6 (staged): held findings — genuine findings whose remediation is parked
# pending the author's ruling. A held finding prints as HELD (ruling pending)
# and does not fail the run. The list rejects unknown entries: every entry
# must match at least one live finding on check, kind, token, label AND the
# direction content (the detail string, V6 loop A5/B2), or the script fails
# loudly — a held finding that silently stops matching the paper, or a
# parked finding whose direction content mutates, is a defect.
HELD_FINDINGS = [
    {"check": "3B", "kind": "DIRECTION_MISMATCH",
     "token": "engagement", "label": "L8-P11",
     "detail": "E.3 models L8-P11 as deriving from L10-P11, but the "
               "registry models L10-P11 as deriving from L8-P11",
     "ruling": "held v50 finding Obj 1: the E.3 'engagement' row derives "
               "L8-P11 from L10-P11 while the registry models L10-P11 as "
               "deriving from L8-P11. Dervis has not ruled; DO NOT remediate "
               "(changelog #115's held-findings section, (d)(2))."},
]

# V6 loop (B3): disclosed conditionals — unregistered [LEVEL A] material
# whose conditional status the paper discloses. Informational, never a
# violation. Each entry cites the disclosure.
DISCLOSED_CONDITIONALS = [
    {"section": "§6.1",
     "header": "Lemma (Bonding Reduces Port Openness)",
     "disclosure": "changelog #91 ('Level A conditional on the §6.1 lemma'); "
                   "the [LEVEL A] conditional-on-§6.1 premises in the §4.3 "
                   "lemma statement, the §4.4/§6.2 machine-check paragraphs, "
                   "and the F.33–F.35 script descriptions",
     "rationale": "the lemma is a disclosed conditional premise (Paper 2 "
                  "§11.1 bonding-mode content rendered in port vocabulary), "
                  "not a hidden unregistered claim"},
]


def _fail(msg):
    """Loud failure: incompatible data shape, never a silent pass."""
    sys.stderr.write("F.54 SHAPE GUARD: %s\n" % msg)
    raise SystemExit(2)


def shape_guard():
    if not isinstance(REGISTRY, list) or not REGISTRY:
        _fail("REGISTRY is not a non-empty list")
    for row in REGISTRY:
        if (
            not isinstance(row, dict)
            or not isinstance(row.get("id"), str)
            or not isinstance(row.get("axioms"), list)
            or not isinstance(row.get("deps"), list)
        ):
            _fail("registry row lacks id/axioms/deps: %r" % (row,))
    if not isinstance(DERIVED, dict) or not DERIVED:
        _fail("DERIVED is not a non-empty dict")
    for lab, rec in DERIVED.items():
        if (
            not isinstance(rec, dict)
            or not isinstance(rec.get("derives_from"), list)
            or not isinstance(rec.get("section"), str)
            or not isinstance(rec.get("kind"), str)
            or not isinstance(rec.get("name"), str)
        ):
            _fail("DERIVED entry lacks derives_from/section/kind/name: %r" % (lab,))
    if not isinstance(RESOLUTIONS, dict) or not RESOLUTIONS:
        _fail("RESOLUTIONS is not a non-empty dict")
    for cid, val in RESOLUTIONS.items():
        if (
            not isinstance(val, (tuple, list))
            or len(val) != 2
            or not all(isinstance(s, str) for s in val)
        ):
            _fail("RESOLUTIONS value is not a (stated, proved) pair: %r" % (cid,))
    missing = [r["id"] for r in REGISTRY if r["id"] not in RESOLUTIONS]
    if missing:
        _fail("registry ids absent from the section map: %s" % missing)


# ---------------------------------------------------------------------------
# Runtime graph builders (no hardcoded results: every map and closure is
# derived here from the imported registry data).
# ---------------------------------------------------------------------------

def build_label_closure(derived):
    """label -> transitive derives_from closure (frozenset)."""
    closure = {}

    def close(lab, stack=()):
        if lab in closure:
            return closure[lab]
        if lab in stack:
            _fail("derives_from cycle involving %s" % lab)
        rec = derived.get(lab)
        if rec is None:
            return frozenset()
        out = set()
        for dep in rec["derives_from"]:
            out.add(dep)
            out |= close(dep, stack + (lab,))
        closure[lab] = frozenset(out)
        return closure[lab]

    for lab in derived:
        close(lab)
    return closure


def build_claim_dep_closure(by_id):
    """claim id -> transitive deps closure (frozenset)."""
    closure = {}

    def close(cid, stack=()):
        if cid in closure:
            return closure[cid]
        if cid in stack:
            _fail("dependency cycle involving %s" % cid)
        row = by_id.get(cid)
        if row is None:
            return frozenset()
        out = set()
        for dep in row["deps"]:
            out.add(dep)
            out |= close(dep, stack + (cid,))
        closure[cid] = frozenset(out)
        return closure[cid]

    for cid in by_id:
        close(cid)
    return closure


def build_claim_label_closure(registry, label_closure):
    """claim id -> labels in its axioms' transitive closure (frozenset)."""
    out = {}
    for row in registry:
        labs = set()
        for ax in row["axioms"]:
            labs.add(ax)
            labs |= set(label_closure.get(ax, ()))
        out[row["id"]] = frozenset(labs)
    return out


def build_section_map(resolutions, derived, header_labels=None):
    """section token -> {"claims": [...], "labels": [...]}.

    Claims enter through the RESOLUTIONS proved-sections (inverted);
    derived labels enter through their registry section records; section
    header badge labels (V6: the finding-5 class — a proof citing "the
    definition of open ports in §4.3" names the section's definitional
    content, which the header badge attributes to L6-P11) enter through
    header_labels.
    """
    sec = {}
    for cid, (_stated, proved) in resolutions.items():
        entry = sec.setdefault(proved, {"claims": [], "labels": []})
        if cid not in entry["claims"]:
            entry["claims"].append(cid)
    for lab, rec in derived.items():
        entry = sec.setdefault(rec["section"], {"claims": [], "labels": []})
        if lab not in entry["labels"]:
            entry["labels"].append(lab)
    for sec_key, labs in (header_labels or {}).items():
        entry = sec.setdefault(sec_key, {"claims": [], "labels": []})
        for lab in labs:
            if lab not in entry["labels"]:
                entry["labels"].append(lab)
    return sec


def build_home_labels(registry_ids, derived):
    """claim id -> the derived label whose record names exactly that claim.

    Only exact name normalizations count (e.g. the L5-P11 record names the
    relational-role theorem claim). Used for the label-level direction
    check: a cited label whose closure contains the citing claim's home
    label is modeled as depending on the citing claim.
    """
    home = {}
    for lab, rec in derived.items():
        norm = re.sub(r"[^A-Z0-9]+", "_", rec["name"].upper()).strip("_")
        if norm in registry_ids:
            home[norm] = lab
    return home


class Ctx:
    """All runtime structures the checks need, built from registry data."""

    def __init__(self, registry, derived, resolutions, header_labels=None):
        self.by_id = {r["id"]: r for r in registry}
        self.derived = derived
        self.label_closure = build_label_closure(derived)
        self.claim_dep_closure = build_claim_dep_closure(self.by_id)
        self.claim_label_closure = build_claim_label_closure(
            registry, self.label_closure
        )
        self.section_map = build_section_map(
            resolutions, derived, header_labels)
        self.home_label = build_home_labels(set(self.by_id), derived)
        self.stated_map = {}
        for cid, (_stated, _proved) in resolutions.items():
            self.stated_map.setdefault(_stated, []).append(cid)


# ---------------------------------------------------------------------------
# Paper parsers (fence-aware: embedded script listings are not paper prose).
# ---------------------------------------------------------------------------

def live_lines(text):
    """(line_no, text) pairs outside fenced code regions."""
    out, in_fence = [], False
    for i, ln in enumerate(text.splitlines(), start=1):
        if ln.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append((i, ln))
    return out


PROOF_START_RE = re.compile(r"^\*Proof\.\*")
# Hard structural boundaries: these never occur inside a proof block.
HARD_BOUNDARY_RE = re.compile(r"^(### |## |---|\*Proof\.\*)")


def _paragraphs(lines):
    """Group (line_no, text) pairs into paragraphs."""
    paras, cur, cur_no = [], [], None
    for no, ln in lines:
        if ln.strip() == "":
            if cur:
                paras.append((cur_no, cur))
                cur, cur_no = [], None
        else:
            if cur_no is None:
                cur_no = no
            cur.append(ln)
    if cur:
        paras.append((cur_no, cur))
    return paras


def parse_proof_blocks(lines):
    """Proof blocks: from a *Proof.* paragraph through the paragraph
    carrying the end marker. A proof whose opening paragraph lacks the
    marker is multi-paragraph: absorb following paragraphs until the
    marker or a hard structural boundary. If the boundary comes first,
    the proof is a markerless single paragraph."""
    paras = _paragraphs(lines)
    blocks = []
    i = 0
    while i < len(paras):
        no, plines = paras[i]
        if not PROOF_START_RE.match(plines[0]):
            i += 1
            continue
        body = list(plines)
        end_no = no + len(plines) - 1
        j = i + 1
        while not any("■" in l for l in body):
            if j >= len(paras):
                _fail("unterminated proof block at line %d" % no)
            nxt_no, nxt_lines = paras[j]
            if HARD_BOUNDARY_RE.match(nxt_lines[0]):
                break
            body.extend(nxt_lines)
            end_no = nxt_no + len(nxt_lines) - 1
            j += 1
        # If we stopped at a hard boundary without a marker, the proof is
        # just its opening paragraph.
        if not any("■" in l for l in body):
            body = plines
            end_no = no + len(plines) - 1
            j = i + 1
        blocks.append({"line": no, "end": end_no, "text": "\n".join(body)})
        i = j if j > i else i + 1
    return blocks


SECTION_RE = re.compile(r"^### §([\d.]+)")
BOLD_RE = re.compile(r"^\*\*(.+?)\*\*")
KIND_RE = re.compile(r"\b(Theorem|Lemma|Definition|Corollary)\b")
LEVEL_OR_LABEL_RE = re.compile(r"\[(LEVEL [ABC]|L\d+-P11)")


def parse_claim_headers(lines):
    """Claim headers: bold lines naming a Theorem/Lemma/Definition/
    Corollary, either in the **Name (Parenthetical)** form or the bare
    **Name Theorem [LEVEL A]** form."""
    headers = []
    cur_section = None
    for no, ln in lines:
        m = SECTION_RE.match(ln)
        if m:
            cur_section = m.group(1)
        bm = BOLD_RE.match(ln)
        if bm and KIND_RE.search(bm.group(1)):
            bold = bm.group(1)
            if not (
                LEVEL_OR_LABEL_RE.search(ln)
                or re.match(r"\*\*(Theorem|Lemma|Definition|Corollary) \(", ln)
            ):
                continue
            pm = re.search(r"\(([^)]*)\)", bold)
            if pm:
                name = pm.group(1)
            else:
                name = re.sub(r"\[[^\]]*\]", "", bold)
                name = KIND_RE.sub("", name).strip().rstrip(".").strip()
            headers.append(
                {
                    "line": no,
                    "section": cur_section,
                    "kind": KIND_RE.search(bold).group(1),
                    "name": name,
                    "raw": ln,
                }
            )
    return headers


def _tokens(s):
    return set(t for t in re.findall(r"[a-z0-9]+", s.lower()) if t)


def attribute_claim(header, ctx):
    """Resolve a claim header to a registry claim id: best token-overlap
    match among the claims proved in the header's section (unique, score
    >= 1); global fallback (unique, score >= 2) if the section hosts no
    claim. Returns None when unattributable."""
    name_toks = _tokens(header["name"])
    scoped = []
    if header["section"]:
        scoped = ctx.section_map.get("§" + header["section"], {}).get("claims", [])

    def score(cid):
        return len(name_toks & _tokens(cid))

    best, best_score, ties = None, 0, 0
    pool = scoped or list(ctx.by_id)
    for cid in pool:
        sc = score(cid)
        if sc > best_score:
            best, best_score, ties = cid, sc, 1
        elif sc == best_score and sc > 0:
            ties += 1
    min_score = 1 if scoped else 2
    if best is not None and best_score >= min_score and ties == 1:
        return best
    return None


EXTERNAL_CITE_RE = re.compile(r"Paper\s+\d+(?:\.\d+)?\s*,?\s*§\d+(?:\.\d+)*")
CITE_RE = re.compile(r"§\s*(\d+(?:\.\d+)*)")


def extract_citations(text):
    """Paper-11-local section citations, in order, deduplicated.
    Cross-paper citations ("Paper N §X") are stripped first: they address
    another document, which this registry cannot model."""
    clean = EXTERNAL_CITE_RE.sub("", text)
    seen, out = set(), []
    for m in CITE_RE.finditer(clean):
        if m.group(1) not in seen:
            seen.add(m.group(1))
            out.append(m.group(1))
    return out


def parse_e3_table(lines):
    """E.3 defined-token rows: token and "Derived from" cell."""
    rows = []
    in_table = False
    for no, ln in lines:
        if ln.startswith("**E.3 Defined Tokens"):
            in_table = True
            continue
        if in_table:
            if ln.startswith("|"):
                cells = [c.strip() for c in ln.strip().strip("|").split("|")]
                if (
                    len(cells) >= 5
                    and cells[0] not in ("Token", "---")
                    and not cells[0].startswith("---")
                ):
                    rows.append(
                        {"line": no, "token": cells[0], "derived_from": cells[4]}
                    )
            elif ln.strip() == "":
                continue
            else:
                break
    return rows


def parse_section_header_labels(lines):
    """Section header badge labels: "### §N ... [Lx-P11 ...]" -> {"§N": [...]}.

    V6 (staged): the finding-5 class. A proof citing "the definition of open
    ports in §4.3" names the section's definitional content, which the
    section header badge attributes to L6-P11; without the header labels the
    section map sees only the section's claims and misreads the citation as
    unmodeled. Fence-aware input (live_lines) like the other parsers.
    V6 loop (A2b): primitive labels (L1–L4, BUDGET, PTR, DSC, S3) are
    captured too — a proof citing a section for its definitional content
    (e.g. the §7.2 proof citing §7.5's operator definition) is satisfied
    via the shared primitive level. Prose primitives (tick, a_k) are NOT
    captured: they are not labels.
    """
    prim = set(f38.PRIMITIVE)
    out = {}
    for no, ln in lines:
        m = SECTION_RE.match(ln)
        if not m:
            continue
        labs = [t for t in BADGE_LABEL_RE.findall(ln)
                if t not in PROSE_PRIMITIVE]
        # Keep derived labels and primitives; drop anything else.
        labs = [t for t in labs
                if re.fullmatch(r"L\d+-P11", t) or t in prim]
        if labs:
            key = "§" + m.group(1)
            cur = out.setdefault(key, [])
            for lab in labs:
                if lab not in cur:
                    cur.append(lab)
    return out


def parse_badges(lines, ctx):
    """Header badges, attributed to registry claims.

    Three forms (V6 loop B1: the bracket form is new):
      - "depends ..." / "derivation record [...]" (kind "depends"): the
        original form. Only badge-shaped lines count (section headers,
        [LEVEL] headers, or explicit badge notes) - prose uses of "depends"
        are not badges.
      - bracket badges on claim headers, "[Lx·Ly·…]" (kind
        "bracket-claim"): attributed via the header's claim.
      - bracket badges on "###" section headers (kind "bracket-section"):
        attributed to the section's single associated claim (stated or
        proved) when there is exactly one; otherwise unattributed (census).
    """
    headers = parse_claim_headers(lines)
    header_by_line = {h["line"]: h for h in headers}
    badges = []
    for no, ln in lines:
        badge_text = None
        kind = "depends"
        # Red-team hardening (post-#116 loop): strip leading whitespace
        # before the shape checks — an indented badge-shaped line must not
        # be silently skipped — and apply the same header-shape gate to
        # the derivation-record branch (a prose line containing both
        # phrases was parsed as a badge).
        stripped = ln.lstrip()
        if "depends" in ln and (
            # Header-shaped lines only: a 35KB changelog line quoting a
            # badge string ("depends ..." + "[LEVEL" somewhere in the
            # prose) is not a badge. Section headers, [LEVEL] headers,
            # and explicit badge notes count; prose uses do not.
            stripped.startswith("###")
            or (stripped.startswith("**") and "[LEVEL" in ln)
            or stripped.startswith("*Badge note")
        ):
            m = re.search(r"depends\s+([^\]]+)", ln)
            if m:
                badge_text = m.group(1)
        elif ("derivation record" in ln and "Badge note" in ln
              and (stripped.startswith("###")
                   or stripped.startswith("**")
                   or stripped.startswith("*Badge note"))):
            m = re.search(r"derivation record\s*\[([^\]]+)\]", ln)
            if m:
                badge_text = m.group(1)
        if badge_text is not None:
            tokens = [t for t in re.split(r"[·,\s]+", badge_text.strip())
                      if t]
            claim_id = attribute_badge(no, ln, headers, ctx)
            badges.append(
                {"line": no, "kind": kind, "claim": claim_id,
                 "tokens": tokens, "raw": ln.strip()[:160]}
            )
            continue
        # Bracket form "[Lx·Ly·…]" (V6 loop B1).
        groups = re.findall(r"\[([^\]]+)\]", ln)
        label_groups = [g for g in groups if BADGE_LABEL_RE.search(g)]
        if not label_groups:
            continue
        # The label bracket is the last bracket carrying label tokens
        # ([LEVEL A] carries none).
        tokens = BADGE_LABEL_RE.findall(label_groups[-1])
        if not tokens:
            continue
        if no in header_by_line:
            h = header_by_line[no]
            claim_id = attribute_claim(h, ctx)
            # V6 loop (B1): a Definition header carrying a single derived
            # label bracket names the label being defined — e.g.
            # **Definition (Encounter Geometry) [L10-P11].** — not an axiom
            # list. It is not compared against claim axioms.
            if (h["kind"] == "Definition" and len(tokens) == 1
                    and tokens[0] in ctx.derived
                    and ctx.derived[tokens[0]].get("kind") == "definition"):
                badges.append(
                    {"line": no, "kind": "bracket-definition",
                     "claim": claim_id, "section": h["section"],
                     "tokens": tokens, "raw": ln.strip()[:160]}
                )
            else:
                badges.append(
                    {"line": no, "kind": "bracket-claim", "claim": claim_id,
                     "section": h["section"], "tokens": tokens,
                     "raw": ln.strip()[:160]}
                )
        else:
            m = SECTION_RE.match(ln)
            if not m:
                continue
            sec_key = "§" + m.group(1)
            assoc = sorted(set(ctx.stated_map.get(sec_key, [])
                               + ctx.section_map.get(
                                   sec_key, {}).get("claims", [])))
            claim_id = assoc[0] if len(assoc) == 1 else None
            badges.append(
                {"line": no, "kind": "bracket-section", "claim": claim_id,
                 "section": m.group(1), "tokens": tokens,
                 "raw": ln.strip()[:160]}
            )
    return badges


def label_to_claim(label, ctx):
    """Derived label -> registry claim id via the label record's name
    (exact normalization, then _DEFINITION/_THEOREM/_LEMMA suffix)."""
    rec = ctx.derived.get(label)
    if rec is None:
        return None
    norm = re.sub(r"[^A-Z0-9]+", "_", rec["name"].upper()).strip("_")
    ids = set(ctx.by_id)
    if norm in ids:
        return norm
    for suffix in ("_DEFINITION", "_THEOREM", "_LEMMA"):
        if norm + suffix in ids:
            return norm + suffix
    return None


def attribute_badge(no, ln, headers, ctx):
    """Badge -> claim: the label named in the badge line if any, else the
    nearest preceding claim header's label."""
    m = re.search(r"\[(L\d+-P11)\b", ln)
    label = m.group(1) if m else None
    if label is None:
        for h in reversed(headers):
            if h["line"] < no:
                hm = re.search(r"\[(L\d+-P11)\b", h["raw"])
                if hm:
                    label = hm.group(1)
                    break
    if label is None:
        return None
    return label_to_claim(label, ctx)


# ---------------------------------------------------------------------------
# Check 3A: proof-block citation check.
# ---------------------------------------------------------------------------

def check_citation(claim_id, section_token, ctx):
    """Verdict for one (claim, cited-section) pair.

    Order is load-bearing: SATISFIED is checked first, existentially, so a
    citation that also resolves upstream is not misread as an inversion.
    DIRECTION_MISMATCH fires only when no cited target is upstream of the
    citing claim but a cited target is modeled as depending on it.
    """
    sec_key = "§" + section_token
    entry = ctx.section_map.get(sec_key)
    if entry is None:
        return {
            "kind": "UNRESOLVED_SECTION",
            "claim": claim_id,
            "section": sec_key,
            "detail": "cited section maps to no registry claim and no "
                      "derived label (census entry)",
        }
    targets_claims = [c for c in entry["claims"] if c != claim_id]
    home = ctx.home_label.get(claim_id)
    targets_labels = [t for t in entry["labels"] if t != home]
    if not targets_claims and not targets_labels:
        return {
            "kind": "SATISFIED",
            "claim": claim_id,
            "section": sec_key,
            "detail": "self-section citation",
        }
    dep_closure = ctx.claim_dep_closure.get(claim_id, frozenset())
    lab_closure = ctx.claim_label_closure.get(claim_id, frozenset())
    claim_hit = next((tc for tc in targets_claims if tc in dep_closure),
                     None)
    label_hit = next((tl for tl in targets_labels if tl in lab_closure),
                     None)
    # V6 loop (A2b/G3): definitional-grounding precedence. If the only
    # claim-level satisfaction is via an axiom-level (deps []) claim but a
    # PRIMITIVE label also satisfies the citation, ground SATISFIED on the
    # primitive label, not the claim. An axiom-level claim is definitional
    # content; attributing a definitional citation to one specific
    # definition risks the G3 misattribution (the §7.2 proof's "Shear
    # tension is the unmatched-integer count τ_J (§7.1)" cites the Identity
    # paragraph — TENSION_MEASURE_IDENTITY's registered content — not
    # RESOLUTION_VERB, whose "produce" framing the Identity paragraph
    # rejects). The primitive label is the honest level; which definition
    # was cited stays human-audit territory.
    if (claim_hit is not None and label_hit is not None
            and not ctx.by_id[claim_hit]["deps"]
            and label_hit in f38.PRIMITIVE):
        return {
            "kind": "SATISFIED",
            "claim": claim_id,
            "section": sec_key,
            "detail": "cited primitive label %s is in %s's axiom closure "
                      "(definitional grounding; axiom-level claim %s not "
                      "attributed)" % (label_hit, claim_id, claim_hit),
        }
    if claim_hit is not None:
        return {
            "kind": "SATISFIED",
            "claim": claim_id,
            "section": sec_key,
            "detail": "cited claim %s is in %s's dependency closure"
                      % (claim_hit, claim_id),
        }
    if label_hit is not None:
        return {
            "kind": "SATISFIED",
            "claim": claim_id,
            "section": sec_key,
            "detail": "cited label %s is in %s's axiom closure"
                      % (label_hit, claim_id),
        }
    for tc in targets_claims:
        if claim_id in ctx.claim_dep_closure.get(tc, frozenset()):
            return {
                "kind": "DIRECTION_MISMATCH",
                "claim": claim_id,
                "section": sec_key,
                "detail": "registry models cited claim %s as depending on "
                          "citing claim %s" % (tc, claim_id),
            }
    if home:
        for tl in targets_labels:
            if home in ctx.label_closure.get(tl, frozenset()):
                return {
                    "kind": "DIRECTION_MISMATCH",
                    "claim": claim_id,
                    "section": sec_key,
                    "detail": "registry models cited label %s as depending "
                              "on %s (home label of %s)"
                              % (tl, home, claim_id),
                }
    return {
        "kind": "UNMODELED_CITATION",
        "claim": claim_id,
        "section": sec_key,
        "detail": "cited content is in neither %s's dependency closure nor "
                  "its axiom closure, and no reverse edge exists" % claim_id,
    }


# ---------------------------------------------------------------------------
# Check 3B: E.3 derivation-record direction check.
# ---------------------------------------------------------------------------

LABEL_TOKEN_RE = re.compile(r"\b(L\d+(?:-P11)?|PTR|BUDGET|DSC|S3)\b")


def token_to_derived_label(token, derived):
    """E.3 token -> derived label by name containment (either direction),
    unique best token-overlap wins; ties and non-matches return None."""
    tw = _tokens(token)
    best, best_score, ties = None, 0, 0
    for lab, rec in derived.items():
        nw = _tokens(rec["name"])
        if tw <= nw or nw <= tw:
            sc = len(tw & nw)
            if sc > best_score:
                best, best_score, ties = lab, sc, 1
            elif sc == best_score and sc > 0:
                ties += 1
    if best is not None and ties == 1 and best_score > 0:
        return best
    return None


def check_e3_row(token, derived_from_cell, ctx):
    """Compare one E.3 row's label set against the registry record.
    Returns a list of finding dicts (empty when the row matches)."""
    lab = token_to_derived_label(token, ctx.derived)
    if lab is None:
        return []
    paper_labels = LABEL_TOKEN_RE.findall(derived_from_cell)
    reg_set = set(ctx.derived[lab]["derives_from"])
    findings = []
    for m in paper_labels:
        if m in reg_set:
            continue
        if m in ctx.derived and lab in ctx.label_closure.get(m, frozenset()):
            findings.append(
                {
                    "kind": "DIRECTION_MISMATCH",
                    "label": lab,
                    "token": token,
                    "detail": "E.3 models %s as deriving from %s, but the "
                              "registry models %s as deriving from %s"
                              % (lab, m, m, lab),
                }
            )
        else:
            findings.append(
                {
                    "kind": "DERIVATION_DRIFT",
                    "label": lab,
                    "token": token,
                    "detail": "E.3 'Derived from' names %s, absent from the "
                              "registry derivation record of %s" % (m, lab),
                }
            )
    return findings


# ---------------------------------------------------------------------------
# Check 4: header badge check.
# ---------------------------------------------------------------------------

def check_badge(claim_id, badge_tokens, ctx):
    """Exact token-set comparison: badge tokens vs registry axiom set.

    Tokens in PROSE_PRIMITIVE are documented prose-level primitives, not
    registry labels: they are reported as PROSE_TOKEN (informational) and
    never counted as dropped/extra. The guard keeps its power over real
    label tokens.
    """
    axioms = set(ctx.by_id[claim_id]["axioms"])
    badge = set(badge_tokens)
    prose = sorted(badge & PROSE_PRIMITIVE)
    badge = badge - PROSE_PRIMITIVE
    dropped = sorted(axioms - badge)
    extra = sorted(badge - axioms)
    if not dropped and not extra:
        return {"kind": "MATCH", "claim": claim_id, "prose_tokens": prose}
    if dropped and extra:
        kind = "BADGE_DROPPED_AND_EXTRA"
    elif dropped:
        kind = "BADGE_DROPPED"
    else:
        kind = "BADGE_EXTRA"
    return {
        "kind": kind,
        "claim": claim_id,
        "prose_tokens": prose,
        "dropped": dropped,
        "extra": extra,
        "detail": "badge tokens %s vs registry axioms %s"
                  % (sorted(badge), sorted(axioms)),
    }


# ---------------------------------------------------------------------------
# Check 3A companion: REGISTRY_INCOMPLETENESS discriminator (V6 loop B3).
# ---------------------------------------------------------------------------

def check_section_completeness(sec_key, headers, ctx):
    """Every [LEVEL X] claim header hosted in a cited section must attribute
    to a registry claim.

    Returns (incomplete, disclosed): incomplete lists REGISTRY_INCOMPLETENESS
    findings for unattributed headers; disclosed lists DISCLOSED_CONDITIONAL
    informationals for headers whose unregistered status the paper
    discloses (DISCLOSED_CONDITIONALS).
    """
    incomplete, disclosed = [], []
    sec_num = sec_key.lstrip("§")
    for h in headers:
        if h["section"] != sec_num:
            continue
        if "[LEVEL" not in h["raw"]:
            continue
        if attribute_claim(h, ctx) is not None:
            continue
        disc = next((d for d in DISCLOSED_CONDITIONALS
                     if d["section"] == sec_key), None)
        entry = {
            "check": "3A",
            "section": sec_key,
            "line": h["line"],
            "header": h["raw"].strip()[:120],
        }
        if disc is not None:
            entry.update({
                "kind": "DISCLOSED_CONDITIONAL",
                "detail": "unregistered [LEVEL] header with disclosed "
                          "conditional status: %s" % disc["disclosure"],
            })
            disclosed.append(entry)
        else:
            entry.update({
                "kind": "REGISTRY_INCOMPLETENESS",
                "detail": "cited section hosts a [LEVEL] claim header "
                          "attributing to no registry claim",
            })
            incomplete.append(entry)
    return incomplete, disclosed


# ---------------------------------------------------------------------------
# Check 5: axioms<->proof-content (V6 loop B4/O1).
# ---------------------------------------------------------------------------

def check_over_axiomatization(claim_id, claim_proofs, ctx):
    """Every derived (non-primitive) axiom label of a Level-A claim must be
    leaned on by at least one proof block attributed to the claim.

    "Leaned on" (citation-granular, not semantic): the proof cites a section
    whose label map carries the label, or the label is in a dependency's
    axiom closure. A label in the registry axioms that no proof block leans
    on is OVER_AXIOMATIZATION — the O1 shape (spurious label in both axioms
    and badge). Boundary disclosed: a proof that uses a label's content
    without citing its section is a false positive by design.
    """
    row = ctx.by_id[claim_id]
    findings = []
    for ax in row["axioms"]:
        if ax in f38.PRIMITIVE or ax in PROSE_PRIMITIVE:
            continue
        if ax not in ctx.derived:
            continue
        leaned = False
        for _line, cited in claim_proofs:
            for sec in cited:
                entry = ctx.section_map.get("§" + sec)
                if entry and ax in entry["labels"]:
                    leaned = True
                    break
            if leaned:
                break
        if not leaned:
            for dep in row["deps"]:
                if ax in ctx.claim_label_closure.get(dep, frozenset()):
                    leaned = True
                    break
        if not leaned:
            findings.append({
                "kind": "OVER_AXIOMATIZATION",
                "claim": claim_id,
                "label": ax,
                "detail": "derived axiom label %s is in %s's registry "
                          "axioms but no attributed proof block cites a "
                          "section carrying it, and no dependency brings it"
                          % (ax, claim_id),
            })
    return findings


# ---------------------------------------------------------------------------
# Live run over the paper.
# ---------------------------------------------------------------------------

def _held_entry_for(finding):
    """Return the HELD_FINDINGS entry matching this finding, or None.

    V6 loop (A5/B2): the match key includes the finding's direction
    content (the detail string), not just check/kind/token/label — a
    mutated parked finding fails loudly instead of matching a stale entry.
    """
    for h in HELD_FINDINGS:
        keys = ("check", "kind", "token", "label", "detail")
        if all(finding.get(k) == v for k, v in h.items() if k in keys):
            return h
    return None


def run_live():
    lines = live_lines(PAPER_MD)
    header_labels = parse_section_header_labels(lines)
    ctx = Ctx(REGISTRY, DERIVED, RESOLUTIONS, header_labels)
    findings, census = [], []
    incompleteness, disclosed_conditionals = [], []

    # Check 3A: proof-block citations.
    headers = parse_claim_headers(lines)
    blocks = parse_proof_blocks(lines)
    if not blocks:
        _fail("no proof blocks parsed from the paper")
    cited_sections = set()
    claim_proofs = {}
    for b in blocks:
        prev = [h for h in headers if h["line"] < b["line"]]
        if not prev:
            census.append(
                {"check": "3A", "kind": "ORPHAN_PROOF", "line": b["line"],
                 "detail": "no preceding claim header"}
            )
            continue
        h = prev[-1]
        claim = attribute_claim(h, ctx)
        if claim is None:
            census.append(
                {"check": "3A", "kind": "UNATTRIBUTED_PROOF", "line": b["line"],
                 "header": h["name"], "section": "§" + (h["section"] or "?"),
                 "detail": "proof header resolves to no registry claim"}
            )
            continue
        secs = extract_citations(b["text"])
        claim_proofs.setdefault(claim, []).append((b["line"], secs))
        for sec in secs:
            cited_sections.add(sec)
            v = check_citation(claim, sec, ctx)
            v.update({"check": "3A", "line": b["line"],
                      "header": h["name"]})
            if v["kind"] in ("DIRECTION_MISMATCH", "UNMODELED_CITATION"):
                findings.append(v)
            elif v["kind"] == "UNRESOLVED_SECTION":
                census.append(v)

    # Check 3A companion (V6 loop B3): registry incompleteness discriminator.
    # Every [LEVEL X] claim header hosted in a cited section must attribute
    # to a registry claim.
    for sec in sorted(cited_sections):
        inc, disc = check_section_completeness("§" + sec, headers, ctx)
        incompleteness.extend(inc)
        disclosed_conditionals.extend(disc)

    # Check 3B: E.3 derivation records.
    rows = parse_e3_table(lines)
    if not rows:
        _fail("no E.3 rows parsed from the paper")
    e3_label_rows = 0
    for r in rows:
        if token_to_derived_label(r["token"], DERIVED) is not None:
            e3_label_rows += 1
        for v in check_e3_row(r["token"], r["derived_from"], ctx):
            v.update({"check": "3B", "line": r["line"]})
            findings.append(v)
    if e3_label_rows == 0:
        _fail("no E.3 row resolved to a derived label")

    # Check 4: header badges.
    badges = parse_badges(lines, ctx)
    if not badges:
        _fail("no header badges parsed from the paper")
    claim_badge_sections = {bd["section"] for bd in badges
                            if bd["kind"] == "bracket-claim"
                            and bd.get("section")}
    for bd in badges:
        if bd["claim"] is None:
            census.append(
                {"check": "4", "kind": "UNATTRIBUTED_BADGE", "line": bd["line"],
                 "detail": "badge attributes to no registry claim",
                 "raw": bd["raw"]}
            )
            continue
        if (bd["kind"] == "bracket-section"
                and bd.get("section") in claim_badge_sections):
            # V6 loop (B1): a section-header badge is not coverage-checked
            # when the section carries claim-level bracket badges — the
            # claim badge is the machine-checked axiom-list form; the
            # section header is a coarse summary (disclosed boundary).
            census.append(
                {"check": "4", "kind": "SUPERSEDED_SECTION_BADGE",
                 "line": bd["line"],
                 "detail": "section-header badge not coverage-checked: a "
                           "claim-level bracket badge in the same section is "
                           "the checked form",
                 "raw": bd["raw"]}
            )
            continue
        if bd["kind"] == "bracket-definition":
            # V6 loop (B1): a definition badge names the label being
            # defined, not an axiom list — informational, not checked.
            census.append(
                {"check": "4", "kind": "DEFINITION_BADGE",
                 "line": bd["line"],
                 "detail": "definition header names the defined label "
                           "(%s); not an axiom list"
                           % ", ".join(bd["tokens"]),
                 "raw": bd["raw"]}
            )
            continue
        v = check_badge(bd["claim"], bd["tokens"], ctx)
        if v["kind"] != "MATCH":
            v.update({"check": "4", "line": bd["line"]})
            findings.append(v)
        elif v.get("prose_tokens"):
            print("[check 4] PROSE_TOKEN (informational)  (paper line %s)"
                  % bd["line"])
            print("          prose-level primitive token(s), not registry "
                  "labels: %s" % v["prose_tokens"])

    # Check 5: axioms<->proof-content (V6 loop B4/O1). Live findings are
    # INFORMATIONAL, not violations: the paper's idiom leans on labels via
    # machine checks (scripts) as well as proof citations, so the
    # citation-granular check produces false positives by design. The O1
    # mechanism is proven by the synthetic mutant (which must be caught);
    # live output is human-adjudicated. Documented boundary, not hidden.
    check5_info = []
    for row in REGISTRY:
        if row.get("level") != "A":
            continue
        proofs = claim_proofs.get(row["id"], [])
        for v in check_over_axiomatization(row["id"], proofs, ctx):
            v.update({"check": "5"})
            check5_info.append(v)

    # Held findings: genuine findings parked pending the author's ruling.
    # They print as HELD and do not fail the run. Every HELD_FINDINGS entry
    # must match at least one live finding — fail loudly otherwise.
    held, live = [], []
    for f in findings:
        h = _held_entry_for(f)
        if h is not None:
            f = dict(f)
            f["held_ruling"] = h["ruling"]
            held.append(f)
        else:
            live.append(f)
    for h in HELD_FINDINGS:
        if not any(_held_entry_for(f) is h for f in findings):
            _fail("held finding no longer matches the paper: %r "
                  "(the paper changed under a parked ruling)" % (h,))
    findings = live

    return findings, census, held, incompleteness, disclosed_conditionals, \
        check5_info


# ---------------------------------------------------------------------------
# Planted-mutant battery + passing controls (synthetic registries; the live
# paper and live registry are untouched).
# ---------------------------------------------------------------------------

def _synth(registry, derived, resolutions, header_labels=None):
    return Ctx(registry, derived, resolutions, header_labels)


def _base_mutant_ctx(dep_flip=False):
    registry = [
        {"id": "M_CA", "axioms": ["M_LA"],
         "deps": ["M_CB"] if dep_flip else []},
        {"id": "M_CB", "axioms": ["M_LB"],
         "deps": [] if dep_flip else ["M_CA"]},
        {"id": "M_CC", "axioms": ["M_LA"], "deps": []},
    ]
    derived = {
        "M_LA": {"kind": "definition", "name": "m alpha",
                 "section": "§1", "derives_from": []},
        "M_LB": {"kind": "definition", "name": "m beta",
                 "section": "§2", "derives_from": []},
        "M_LC": {"kind": "definition", "name": "m zeta",
                 "section": "§3", "derives_from": []},
    }
    resolutions = {
        "M_CA": ("§1", "§1"),
        "M_CB": ("§2", "§2"),
        "M_CC": ("§3", "§3"),
    }
    return _synth(registry, derived, resolutions)


def mutant_direction_flipped_edge():
    """Registry edge flipped (M_CA wrongly modeled as depending on M_CB);
    M_CB's proof cites M_CA's section. Must be DIRECTION_MISMATCH."""
    ctx = _base_mutant_ctx(dep_flip=True)
    return check_citation("M_CB", "1", ctx)


def mutant_dropped_badge_token():
    """Badge omits a registry axiom. Must be BADGE_DROPPED."""
    registry = [{"id": "M_CA", "axioms": ["M_LA", "M_LC"], "deps": []}]
    derived = {
        "M_LA": {"kind": "definition", "name": "m alpha",
                 "section": "§1", "derives_from": []},
        "M_LC": {"kind": "definition", "name": "m zeta",
                 "section": "§3", "derives_from": []},
    }
    ctx = _synth(registry, derived, {"M_CA": ("§1", "§1")})
    return check_badge("M_CA", ["M_LA"], ctx)


def mutant_unmodeled_citation():
    """Proof cites a section whose content is in neither the claim's
    dependency closure nor its axiom closure. Must be UNMODELED_CITATION."""
    ctx = _base_mutant_ctx()
    return check_citation("M_CC", "2", ctx)


def mutant_downstream_citation():
    """Proof cites a section whose claim the registry models as depending
    on the citing claim. Must be DIRECTION_MISMATCH."""
    ctx = _base_mutant_ctx()
    return check_citation("M_CA", "2", ctx)


def mutant_badge_extra_token():
    """Badge carries a token the registry axioms lack.
    Must be BADGE_EXTRA."""
    ctx = _base_mutant_ctx()
    return check_badge("M_CA", ["M_LA", "M_LX"], ctx)


def mutant_e3_direction():
    """E.3-style record: paper says L90 derives from L91 while the
    registry models L91 as deriving from L90. Must be
    DIRECTION_MISMATCH."""
    registry = [{"id": "M_CD", "axioms": ["L90"], "deps": []}]
    derived = {
        "L90": {"kind": "definition", "name": "m delta",
                "section": "§4", "derives_from": []},
        "L91": {"kind": "definition", "name": "m epsilon",
                "section": "§5", "derives_from": ["L90"]},
    }
    ctx = _synth(registry, derived, {"M_CD": ("§4", "§4")})
    return check_e3_row("m delta", "L91", ctx)


def mutant_label_level_direction():
    """Label-level direction inversion (V6 loop B4): a cited derived label
    whose derives_from closure contains the citing claim's home label.
    Pins the home_label branch. Must be DIRECTION_MISMATCH."""
    registry = [{"id": "SYN_C", "axioms": ["SYN_LX"], "deps": []}]
    derived = {
        "SYN_LX": {"kind": "definition", "name": "syn ex",
                   "section": "§1", "derives_from": []},
        "SYN_LC": {"kind": "definition", "name": "syn c",
                   "section": "§1", "derives_from": []},
        "SYN_LD": {"kind": "definition", "name": "syn d",
                   "section": "§2", "derives_from": ["SYN_LC"]},
    }
    ctx = _synth(registry, derived, {"SYN_C": ("§1", "§1")})
    return check_citation("SYN_C", "2", ctx)


def mutant_over_axiomatization():
    """Over-axiomatization (V6 loop B4/O1): a derived label in the registry
    axioms (and the badge) that no proof block of the claim cites or leans
    on. Must be OVER_AXIOMATIZATION."""
    registry = [{"id": "SYN_O", "axioms": ["SYN_LA", "SYN_LX"], "deps": []}]
    derived = {
        "SYN_LA": {"kind": "definition", "name": "syn alpha",
                   "section": "§1", "derives_from": []},
        "SYN_LX": {"kind": "definition", "name": "syn ex",
                   "section": "§9", "derives_from": []},
    }
    resolutions = {"SYN_O": ("§1", "§1")}
    ctx = _synth(registry, derived, resolutions,
                 header_labels={"§1": ["SYN_LA"]})
    # The claim's proof cites §1 (carrying SYN_LA) but nothing carrying
    # SYN_LX; no dependency brings SYN_LX either.
    return check_over_axiomatization("SYN_O", [(10, ["1"])], ctx)


def mutant_bracket_badge_dropped():
    """Bracket badge dropping a registry axiom (V6 loop B1): the §8.1
    exploit shape — a section-header bracket badge missing a label the
    claim's axioms carry. Must be BADGE_DROPPED."""
    registry = [{"id": "SYN_B", "axioms": ["SYN_L6", "SYN_L10"], "deps": []}]
    derived = {
        "SYN_L6": {"kind": "definition", "name": "syn six",
                   "section": "§8", "derives_from": []},
        "SYN_L10": {"kind": "definition", "name": "syn ten",
                    "section": "§8", "derives_from": []},
    }
    ctx = _synth(registry, derived, {"SYN_B": ("§8", "§8")})
    return check_badge("SYN_B", ["SYN_L6"], ctx)


def control_definitional_grounds_on_primitive():
    """Definitional citation grounds on the primitive label (V6 loop A2b):
    the claim-channel hit is axiom-level (deps []) and a primitive label
    also satisfies — the verdict grounds on the primitive, not the claim.
    Passes by design (diagnostic)."""
    registry = [
        {"id": "SYN_D", "axioms": ["L1"], "deps": ["SYN_V"]},
        {"id": "SYN_V", "axioms": ["L1"], "deps": []},
    ]
    derived = {}
    resolutions = {"SYN_D": ("§7", "§7"), "SYN_V": ("§6", "§6")}
    ctx = _synth(registry, derived, resolutions,
                 header_labels={"§6": ["L1"]})
    return check_citation("SYN_D", "6", ctx)


def control_axiom_label_leaned_on():
    """A derived axiom label leaned on via a cited section's label map is
    not over-axiomatization. Passes by design (diagnostic)."""
    registry = [{"id": "SYN_O", "axioms": ["SYN_LA"], "deps": []}]
    derived = {
        "SYN_LA": {"kind": "definition", "name": "syn alpha",
                   "section": "§1", "derives_from": []},
    }
    ctx = _synth(registry, derived, {"SYN_O": ("§1", "§1")},
                 header_labels={"§1": ["SYN_LA"]})
    res = check_over_axiomatization("SYN_O", [(10, ["1"])], ctx)
    return {"kind": "CLEAN" if not res else "OVER_AXIOMATIZATION"}


def control_definition_citation_in_axioms():
    """Proof cites a definition section whose label is in the claim's
    axioms. Passes by design (diagnostic)."""
    ctx = _base_mutant_ctx()
    return check_citation("M_CA", "1", ctx)


def control_exact_badge():
    """Badge tokens exactly match the registry axioms. Passes by design
    (diagnostic)."""
    ctx = _base_mutant_ctx()
    return check_badge("M_CA", ["M_LA"], ctx)


def control_upstream_claim_citation():
    """Proof cites the section of a claim in its dependency closure.
    Passes by design (diagnostic)."""
    ctx = _base_mutant_ctx()
    return check_citation("M_CB", "1", ctx)


def control_prose_primitive_token():
    """Badge carries a documented prose-primitive token (tick) alongside the
    registry axioms. MATCH by design (diagnostic); the prose token is
    informational, never a violation."""
    ctx = _base_mutant_ctx()
    return check_badge("M_CA", ["M_LA", "tick"], ctx)


def control_section_header_label_in_axioms():
    """Proof cites a section whose header badge label is in the claim's
    axioms (the finding-5 class: definitional content attributed by the
    section header, not by a claim record). Passes by design (diagnostic)."""
    registry = [{"id": "M_CC", "axioms": ["M_LA"], "deps": []}]
    derived = {
        "M_LA": {"kind": "definition", "name": "m alpha",
                 "section": "§1", "derives_from": []},
        "M_LB": {"kind": "definition", "name": "m beta",
                 "section": "§2", "derives_from": []},
    }
    resolutions = {"M_CC": ("§3", "§3")}
    ctx = _synth(registry, derived, resolutions,
                 header_labels={"§2": ["M_LA"]})
    return check_citation("M_CC", "2", ctx)


MUTANTS = [
    ("direction-flipped edge", mutant_direction_flipped_edge,
     "DIRECTION_MISMATCH"),
    ("dropped badge token", mutant_dropped_badge_token, "BADGE_DROPPED"),
    ("proof citing an unmodeled section", mutant_unmodeled_citation,
     "UNMODELED_CITATION"),
    ("proof citing a downstream claim", mutant_downstream_citation,
     "DIRECTION_MISMATCH"),
    ("badge with an extra token the registry lacks",
     mutant_badge_extra_token, "BADGE_EXTRA"),
    ("E.3 derivation-record direction inversion", mutant_e3_direction,
     "DIRECTION_MISMATCH"),
    ("label-level direction inversion (home_label branch)",
     mutant_label_level_direction, "DIRECTION_MISMATCH"),
    ("over-axiomatization (spurious label in axioms and badge)",
     mutant_over_axiomatization, "OVER_AXIOMATIZATION"),
    ("bracket badge dropping a registry axiom (section-badge exploit)",
     mutant_bracket_badge_dropped, "BADGE_DROPPED"),
]

CONTROLS = [
    ("proof citing a definition section whose token is in the axioms",
     control_definition_citation_in_axioms, "SATISFIED"),
    ("badge exactly matching the registry axioms",
     control_exact_badge, "MATCH"),
    ("proof citing an upstream claim via the dependency closure",
     control_upstream_claim_citation, "SATISFIED"),
    ("badge with a prose-primitive token alongside the axioms",
     control_prose_primitive_token, "MATCH"),
    ("proof citing a section whose header badge label is in the axioms",
     control_section_header_label_in_axioms, "SATISFIED"),
    ("definitional citation grounding on the primitive label, not a "
     "coincidental axiom-level claim",
     control_definitional_grounds_on_primitive, "SATISFIED"),
    ("derived axiom label leaned on via a cited section's label map",
     control_axiom_label_leaned_on, "CLEAN"),
]


def regression_live_section_badge_drop():
    """Re-run the demonstrated B1 exploit on the live paper (in-memory):
    dropping L10-P11 from §8.1's section badge must FAIL the bracket-badge
    check. The paper file is untouched; only an in-memory copy is mutated.
    """
    target = "### §8.1 The Three Outcomes [LEVEL A] [L6-P11·L7-P11·L10-P11]"
    mutated = PAPER_MD.replace(
        target,
        "### §8.1 The Three Outcomes [LEVEL A] [L6-P11·L7-P11]",
        1)
    if mutated == PAPER_MD:
        _fail("regression target not found: §8.1 badge line")
    mlines = live_lines(mutated)
    mheader_labels = parse_section_header_labels(mlines)
    mctx = Ctx(REGISTRY, DERIVED, RESOLUTIONS, mheader_labels)
    badges = parse_badges(mlines, mctx)
    found = [bd for bd in badges
             if bd["kind"] == "bracket-section"
             and bd.get("section") == "8.1"]
    if not found:
        _fail("regression: mutated §8.1 badge not parsed")
    bd = found[0]
    if bd["claim"] is None:
        _fail("regression: mutated §8.1 badge unattributed")
    v = check_badge(bd["claim"], bd["tokens"], mctx)
    if v["kind"] not in ("BADGE_DROPPED", "BADGE_DROPPED_AND_EXTRA"):
        _fail("regression FAILED: dropping L10-P11 from §8.1's badge did "
              "not fail (got %s)" % v["kind"])
    print("REGRESSION  dropping L10-P11 from §8.1's badge -> %s (as designed)"
          % v["kind"])
    print("           witness: %s" % _witness(v))


def _witness(v):
    parts = []
    for key in ("claim", "header", "section", "token", "label", "line"):
        if key in v and v[key] is not None:
            parts.append("%s=%s" % (key, v[key]))
    if "dropped" in v:
        parts.append("dropped=%s" % v["dropped"])
    if "extra" in v:
        parts.append("extra=%s" % v["extra"])
    parts.append(v.get("detail", ""))
    return "; ".join(parts)


def run_mutants():
    print("--- planted-mutant battery ---")
    rejected = 0
    for name, thunk, expected in MUTANTS:
        res = thunk()
        kinds = [r["kind"] for r in res] if isinstance(res, list) else [res["kind"]]
        verdicts = res if isinstance(res, list) else [res]
        if expected not in kinds:
            _fail("mutant NOT rejected as designed: %s (got %s)" % (name, kinds))
        rejected += 1
        print("REJECTED  %-48s -> %s" % (name, expected))
        for v in verdicts:
            if v["kind"] == expected:
                print("           witness: %s" % _witness(v))
    print("--- controls (diagnostic: pass by design) ---")
    passed = 0
    for name, thunk, expected in CONTROLS:
        res = thunk()
        kind = res["kind"] if isinstance(res, dict) else None
        if kind != expected:
            _fail("control failed (script bug): %s (got %s)" % (name, kind))
        passed += 1
        print("PASS      %-48s -> %s" % (name, expected))
    print("mutants: %d/%d rejected as designed; controls: %d/%d pass"
          % (rejected, len(MUTANTS), passed, len(CONTROLS)))


def main():
    shape_guard()
    findings, census, held, incompleteness, disclosed, check5_info = \
        run_live()

    print("=" * 72)
    print("F.54 proof<->registry cross-check")
    print("=" * 72)

    if census:
        print("--- census (not violations) ---")
        for c in census:
            print("[%s] line %s: %s -- %s"
                  % (c["check"], c.get("line", "?"), c["kind"],
                     c.get("detail", "")))

    if disclosed:
        print("--- disclosed conditionals (informational; not violations) ---")
        for d in disclosed:
            print("[check %s] %s  (paper line %s)"
                  % (d["check"], d["kind"], d.get("line", "?")))
            print("          section %s: %s" % (d["section"], d["header"]))
            print("          %s" % d["detail"])

    if incompleteness:
        print("--- registry incompleteness (flagged; needs author's word) ---")
        for f in incompleteness:
            print("[check %s] %s  (paper line %s)"
                  % (f["check"], f["kind"], f.get("line", "?")))
            print("          section %s: %s" % (f["section"], f["header"]))
            print("          %s" % f["detail"])
        print("          disposition: no registry row is invented here — new "
              "registry content needs Dervis's word; the gap is surfaced, "
              "not blocked on.")

    if check5_info:
        print("--- check 5 informational (human-adjudicated; not violations) "
              "---")
        for f in check5_info:
            print("[check %s] %s" % (f["check"], f["kind"]))
            print("          witness: %s" % _witness(f))
        print("          boundary: citation-granular by design; labels leaned "
              "on via machine checks (not proof citations) are false "
              "positives here.")

    if held:
        print("--- held (ruling pending; not violations) ---")
        for f in held:
            print("[HELD check %s] %s  (paper line %s)"
                  % (f["check"], f["kind"], f.get("line", "?")))
            print("          witness: %s" % _witness(f))
            print("          ruling: %s" % f["held_ruling"])

    if findings:
        print("--- findings ---")
        for f in findings:
            print("[check %s] %s  (paper line %s)"
                  % (f["check"], f["kind"], f.get("line", "?")))
            print("          witness: %s" % _witness(f))
    else:
        print("no findings: every proof citation, badge, and E.3 record is "
              "consistent with the registry topology")

    print()
    run_mutants()
    print()
    print("--- live-paper regression (in-memory mutation; file untouched) ---")
    regression_live_section_badge_drop()
    print()

    if findings:
        print("F.54 RESULT: %d finding(s) - registry-vs-proofs mismatches "
              "present" % len(findings))
        raise SystemExit(1)
    if held:
        print("F.54 RESULT: clean modulo %d held finding(s) (ruling pending)"
              % len(held))
    else:
        print("F.54 RESULT: clean")


if __name__ == "__main__":
    main()
