
INPUT_PROVENANCE = {
    "E_YFREE": {"class": "paper-defined", "source": "§11.2 (Y-free environment)"},
    "E_YRICH": {"class": "paper-defined", "source": "§11.2 (Y-rich environment)"},
    "E_YRICH2": {"class": "paper-defined", "source": "§11.2 (Y-rich environment 2)"},
    "NCHECKS": {"class": "control", "note": "check counter"},
    "NREJECTED": {"class": "control", "note": "rejection counter"},
    "VALUES": {"class": "control", "note": "sweep input values"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "finite port-set combinatorics; backing claims quantify over no aspect kinds.",
}
#!/usr/bin/env python3
"""F.48: consolidation paths — upper bound, boundary-extension inclusion,
node-addition port formula, nodes-to-ports nonmonotonicity, and the
physical node-addition caveat (Paper 11, Section 11.2 structural claim).

Machine-checks, over a finite port-set model, the formalization of
consolidation paths: candidate contacts, the path set P(G;E), the
permutation upper bound, valued boundary-extension and its inclusion
consequence, the signed node-addition formula, the refutation of
unconditional nodes-to-ports and ports-to-paths monotonicity, and the
caveat that physical bonding need not yield boundary-extension. Twelve
planted mutants are rejected, each with a printed witness.

NATIVE DOMAIN
-------------
- Bonded aggregate (Paper 11 Section 4.1): nodes, junctions among two or
  more ports, each junction of arity k_j >= 2.
- Boundary-port set with B(G) = |dG| = 6N - sum_j k_j and Port Count
  Invariance (Section 4.3): six ports per node.
- Port closure on junction completion: "establishing a junction at a port
  renders that port closed" (Section 6.1); each port consumed by at most
  one completed junction.
- Junction completion as the structural alteration event (Section 4.6).
- Categorical complementarity: X<->Y pairing; O pairs with nothing
  (Section 8.6 taxonomy). Labels are categories only — never ordered,
  never summed, no signed arithmetic.
- Stage N throughout: finite, discrete, integer/rational, relational,
  deterministic. No continuous calculus, no new primitives.

VERIFIED DOMAIN
---------------
- A finite port-set model: aggregates of N <= 4 nodes with six valued
  ports each (values in {X, Y, O}, categorical); explicit junction lists
  with arity declarations (k_j >= 2), pairwise-disjoint port sets.
- Environments as finite multisets of partner ports with categorical
  values.
- Candidate contacts enumerated as (boundary port, partner port) pairs.
- Consolidation paths enumerated as finite non-empty sequences of
  candidate contacts with no port reuse, depth bounded by the boundary
  size; each event reduces the unmatched-integer count by exactly 2.

MAP (native -> verified)
------------------------
1. Native aggregate -> node/port/junction record: six ports per node,
   each junction a set of ports with declared arity.
2. Native valued boundary port -> (port, categorical label); the boundary
   is the set of ports consumed by no completed junction.
3. Native consolidation path -> finite event sequence over candidate
   contacts; each event closes its two ports (Section 6.1 made
   computational) and reduces the unmatched-integer count by 2.
4. Native environment -> fixed finite multiset of partner ports.
5. Native boundary-extension -> value-preserving injection between finite
   boundary sets, relative to a fixed environment.

PRESERVED BY THE MAP
--------------------
Port-set inclusion structure; complementarity as a function of the two
port values only; no-reuse of ports across events (closure lemma); the
per-event unmatched-integer reduction; the B = 6N - sum_j k_j ledger,
enforced by a dual oracle (|dG| cardinality vs. 6N - sum k_j must agree
on every construction).

OUTSIDE THE MACHINE CHECK
-------------------------
Whether real physical bonding events stand in boundary-extension
relations; whether the witness boundary tuples (all-O, all-X) are
realized by actual configurations; any chemical illustration mapping;
the quantitative "how many more paths" form (inclusion yields only <=);
Paper 2 Section 11.1's bonding modes themselves (cited, not re-derived).

LEVEL-A BADGE SCOPE (stated honestly)
-------------------------------------
The badge covers finite-domain combinatorics over the paper's
definitions: the bound, the inclusion, the formula, the refutations, and
the caveat, as checked by enumeration. It does NOT cover physical
readings: real bonding producing boundary-extensions, real environments
presenting partner-port multisets, and any observational correspondence
stay at Level B/C. The refutations license no positive replacement
monotone claim.

MODELING CHOICES (disclosed, not smuggled)
-----------------------------------------
(a) E is a fixed finite multiset of partner ports: path availability is
    environment-relative, not intrinsic to G.
(b) The empty sequence is not a path (k >= 1): resolving requires at
    least one resolution event; this is what keeps the |P| = 0 witnesses
    at zero.
(c) Each path step is one pairwise junction completion (one complementary
    pair); higher-arity completions are represented per constituent
    complementary pair.
(d) Port-consumption exclusivity: each port is consumed by at most one
    completed junction (forced by the dual B oracle).
(e) Path validity is per-sequence: no validity condition quantifies
    negatively over the whole boundary (load-bearing for inclusion).
(f) Partner-port identities in E are unique: qids are port identities,
    and the same partner port presented twice is malformed input —
    rejected at model-construction time with a clear message. This keeps
    the enumerated path list in agreement with the path set.

Sanitation: no grading language of any kind appears in this
file; no banned modeling tokens are used.
"""

import math
import random
import sys

X, Y, O = "X", "Y", "O"
VALUES = (X, Y, O)

NCHECKS = 0
NREJECTED = 0


def ok(cond, msg):
    """One machine check. Raises (nonzero exit) on failure."""
    global NCHECKS
    if not cond:
        raise AssertionError("CHECK FAILED: " + msg)
    NCHECKS += 1


def rejected(name, witness):
    """Record one planted-mutant rejection with its printed witness."""
    global NREJECTED
    NREJECTED += 1
    print("MUTANT %s REJECTED: %s" % (name, witness))


def complementary(a, b):
    """Categorical complementarity: X<->Y only; O pairs with nothing."""
    return {a, b} == {X, Y}


def make_aggregate(node_values, junctions):
    """Build an aggregate; assert the dual B oracle on every construction.

    node_values: {node: [6 categorical values]}.
    junctions: iterable of frozensets of (node, port-index), arity >= 2,
      pairwise disjoint (port-consumption exclusivity, modeling choice d).
    """
    nodes = {}
    for n, vals in node_values.items():
        assert len(vals) == 6 and all(v in VALUES for v in vals), \
            "six categorical port values per node"
        nodes[n] = list(vals)
    seen = set()
    clean = []
    total_k = 0
    for j in junctions:
        j = frozenset(j)
        assert len(j) >= 2, "junction arity k_j >= 2"
        assert not (seen & j), "port consumed by at most one junction"
        seen |= j
        total_k += len(j)
        clean.append(j)
    N = len(nodes)
    boundary = sorted((n, i) for n in nodes for i in range(6)
                      if (n, i) not in seen)
    b_card = len(boundary)
    b_ledger = 6 * N - total_k
    assert b_card == b_ledger, \
        "dual B oracle disagreement: |dG|=%d vs 6N-Sk=%d" % (b_card, b_ledger)
    return {"N": N, "nodes": nodes, "junctions": clean,
            "boundary": boundary, "bset": set(boundary), "B": b_card}


def port_value(G, p):
    n, i = p
    return G["nodes"][n][i]


def is_candidate_contact(G, eids, p, qid):
    if p not in G["bset"]:
        return False
    qv = eids.get(qid)
    if qv is None:
        return False
    return complementary(port_value(G, p), qv)


def check_environment(E):
    """Input validation: partner-port identities (qids) in E are unique.

    qids are port identities; the same partner port presented twice is
    malformed input. Fail fast with a clear message (modeling choice f).
    """
    qids = [qid for (qid, _) in E]
    assert len(set(qids)) == len(qids), \
        "malformed environment: duplicate partner-port identity in E"


def candidate_contacts(G, E):
    """C(G,E): all (p, q) with p in dG, q in E, complementary values."""
    check_environment(E)
    out = []
    for p in G["boundary"]:
        pv = port_value(G, p)
        for qid, qv in E:
            if complementary(pv, qv):
                out.append((p, qid))
    return out


def contact_counts(G, E):
    check_environment(E)
    xg = sum(1 for p in G["boundary"] if port_value(G, p) == X)
    yg = sum(1 for p in G["boundary"] if port_value(G, p) == Y)
    xe = sum(1 for _, v in E if v == X)
    ye = sum(1 for _, v in E if v == Y)
    return xg, yg, xe, ye


def valid_path(G, E, seq):
    """D3 validator: non-empty, complementary steps, no port reuse,
    unmatched-integer count strictly reduced by exactly 2 per step."""
    check_environment(E)
    eids = dict(E)
    if len(seq) == 0:
        return False  # modeling choice (b): the empty sequence is not a path
    used_p, used_q = set(), set()
    tau = 2 * len(seq)
    for (p, qid) in seq:
        if not is_candidate_contact(G, eids, p, qid):
            return False
        if p in used_p or qid in used_q:
            return False  # Section 6.1: a closed port cannot recur
        used_p.add(p)
        used_q.add(qid)
        tau -= 2
        if tau < 0:
            return False
    return tau == 0


def enumerate_paths(G, E):
    """All consolidation paths of G in E (bounded depth: no-reuse)."""
    contacts = candidate_contacts(G, E)
    paths = []

    def dfs(seq, used_p, used_q):
        for (p, qid) in contacts:
            if p in used_p or qid in used_q:
                continue
            s2 = seq + ((p, qid),)
            paths.append(s2)
            dfs(s2, used_p | {p}, used_q | {qid})

    dfs((), set(), set())
    return paths


def perm_bound(C):
    """Upper bound: sum_{k=1..C} C!/(C-k)! . C=0 gives 0 (no empty path)."""
    return sum(math.perm(C, k) for k in range(1, C + 1))


def extend_boundary(G1, extra_values, perm):
    """Build G2 boundary-extending G1: G1's ports renamed by perm (value
    preserving), plus one new node contributing six open ports with the
    given values. Returns (G2, iota) with iota a value-preserving
    injection dG1 -> dG2; asserts the extension conditions."""
    assert len(extra_values) == 6 and sorted(perm) == [0, 1, 2, 3, 4, 5]
    new_nodes = {}
    for n, vals in G1["nodes"].items():
        nv = [None] * 6
        for i, v in enumerate(vals):
            nv[perm[i]] = v
        new_nodes[n] = nv
    new_junctions = [frozenset((n, perm[i]) for (n, i) in j)
                     for j in G1["junctions"]]
    m = max(new_nodes) + 1
    new_nodes[m] = list(extra_values)
    G2 = make_aggregate(new_nodes, new_junctions)
    iota = {(n, i): (n, perm[i]) for (n, i) in G1["boundary"]}
    b2 = G2["bset"]
    ok(len(set(iota.values())) == len(iota), "extension injection injective")
    for p, ip in iota.items():
        ok(ip in b2, "extension injection lands in dG2")
        ok(port_value(G2, ip) == port_value(G1, p),
           "extension injection value-preserving")
    return G2, iota


def transport_path(seq, iota):
    return tuple((iota[p], qid) for (p, qid) in seq)


def check_inclusion(G1, G2, iota, E):
    """Assert transported P(G1;E) subset of P(G2;E) and |P1| <= |P2|."""
    P1 = enumerate_paths(G1, E)
    P2 = set(enumerate_paths(G2, E))
    for s in P1:
        t = transport_path(s, iota)
        ok(t in P2, "transported path %r not valid in G2" % (s,))
    n1, n2 = len(P1), len(P2)
    ok(n1 <= n2, "path-count inequality |P1| <= |P2|")
    return n1, n2

# ---------------------------------------------------------------------------
# Witness aggregates
# ---------------------------------------------------------------------------

def agg_allO_B10():
    """N=2, one pairwise junction, all-O boundary: B = 12-2 = 10."""
    return make_aggregate({0: [O] * 6, 1: [O] * 6}, [{(0, 0), (1, 0)}])


def agg_allX_B10():
    """N=2, one pairwise junction, all-X boundary: B = 10."""
    return make_aggregate({0: [X] * 6, 1: [X] * 6}, [{(0, 0), (1, 0)}])


def agg_allX_B6():
    """N=2, three pairwise junctions (same node pair), all-X boundary:
    B = 12-6 = 6. Six singleton candidate contacts against one Y partner."""
    return make_aggregate(
        {0: [X] * 6, 1: [X] * 6},
        [{(0, 0), (1, 0)}, {(0, 1), (1, 1)}, {(0, 2), (1, 2)}])


E_YRICH = [("q1", Y)]
E_YRICH2 = [("y1", Y), ("x1", X)]
E_YFREE = [("x1", X), ("x2", X), ("o1", O), ("o2", O)]


# ---------------------------------------------------------------------------
# T1: boundary-extension inclusion over an enumerated (G1, G2, E) sweep
# ---------------------------------------------------------------------------

def base_aggregates():
    gA = make_aggregate({0: [X, Y, O, X, Y, O]}, [])
    gB = make_aggregate({0: [X, Y, O, X, Y, O],
                         1: [X, Y, O, X, Y, O]}, [{(0, 0), (1, 0)}])
    gC = make_aggregate({0: [X, X, Y, Y, O, O],
                         1: [X, X, Y, Y, O, O]},
                        [{(0, 0), (1, 0)}, {(0, 1), (1, 1)},
                         {(0, 2), (1, 2)}])
    return [gA, gB, gC]


def t1_sweep():
    E_patterns = [
        [],
        [("e1", Y)],
        [("e1", X)],
        [("e1", Y), ("e2", Y)],
        [("e1", X), ("e2", Y)],
        [("e1", O)],
        [("e1", X), ("e2", O)],
    ]
    extras = {
        "allO": [O] * 6,
        "oneX": [X, O, O, O, O, O],
        "XY": [X, Y, O, O, O, O],
    }
    perms = {"id": [0, 1, 2, 3, 4, 5], "rev": [5, 4, 3, 2, 1, 0]}
    triples = 0
    skipped = 0
    for G1 in base_aggregates():
        for extra in extras.values():
            for perm in perms.values():
                for E in E_patterns:
                    G2, iota = extend_boundary(G1, extra, perm)
                    if len(candidate_contacts(G2, E)) > 7:
                        skipped += 1  # enumeration cap; bound still checked in T5
                        continue
                    check_inclusion(G1, G2, iota, E)
                    triples += 1
    print("T1 inclusion: %d (G1,G2,E) extension triples — transported "
          "P(G1;E) ⊆ P(G2;E) and |P1| <= |P2| in all "
          "(%d skipped, C>7 enumeration cap)" % (triples, skipped))


def t1_sharpness():
    # Non-strictness witness: one extra O-valued boundary port adds no
    # contacts (O pairs with nothing) -> equal path counts.
    G1 = make_aggregate({0: [X, O, O, O, O, O]}, [])
    G2o, io = extend_boundary(G1, [O] * 6, [0, 1, 2, 3, 4, 5])
    n1, n2 = check_inclusion(G1, G2o, io, [("q", Y)])
    ok(n1 == n2 == 1, "extra O port: |P| unchanged")
    # Strictness witness: one extra X-valued boundary port plus a further
    # Y partner adds candidate contacts -> strictly more paths.
    G2x, ix = extend_boundary(G1, [X, O, O, O, O, O], [0, 1, 2, 3, 4, 5])
    m1, m2 = check_inclusion(G1, G2x, ix, [("q1", Y), ("q2", Y)])
    ok(m2 > m1, "extra X port + Y partner: |P| strictly larger")
    print("T1 sharpness: extra-O port -> |P| equal (%d == %d); "
          "extra-X port + Y partner -> strict (%d < %d)"
          % (n1, n2, m1, m2))


# ---------------------------------------------------------------------------
# T2: node-addition formula — the three witnesses (+4 / -2 / 0)
# ---------------------------------------------------------------------------

def t2_witnesses():
    Gold = make_aggregate({0: [X, Y, O, X, Y, O]}, [])
    ok(Gold["B"] == 6, "Gold: single node, B=6")
    vals = {0: [X, Y, O, X, Y, O], 1: [X, Y, O, X, Y, O]}
    cases = [
        ("a", [{(0, 0), (1, 0)}], +4),                       # one pairwise
        ("b", [{(0, 0), (1, 0)}, {(0, 1), (1, 1)},            # 2+2+4 = 8
               {(0, 2), (0, 3), (1, 2), (1, 3)}], -2),
        ("c", [{(0, 0), (1, 0)}, {(0, 1), (1, 1)},            # 2+2+2 = 6
               {(0, 2), (1, 2)}], 0),
    ]
    dBs = {}
    for name, junc, expect in cases:
        Gnew = make_aggregate(vals, junc)
        knew = sum(len(j) for j in junc)  # ALL consumed ports, old + new
        dB = Gnew["B"] - Gold["B"]
        dBs[name] = dB
        ok(dB == expect, "witness %s: dB=%d" % (name, dB))
        ok(dB == 6 - knew,
           "node-addition formula dB = 6 - sum(k_new): %d = 6 - %d"
           % (dB, knew))
        ok(Gnew["B"] >= 1, "complex configuration carries open ports")
    print("T2 node-addition formula: dB = +4 / -2 / 0 on witnesses "
          "(a)/(b)/(c); dB = 6 - sum(k_new) in each; dual B oracle agrees "
          "on all six aggregates")
    return Gold, dBs


# ---------------------------------------------------------------------------
# T3: nodes -> ports nonmonotonicity
# ---------------------------------------------------------------------------

def t3_nonmonotonicity(Gold, Gbig):
    ok(Gold["N"] < Gbig["N"], "N: 1 < 2")
    ok(Gold["B"] > Gbig["B"], "B: 6 > 4")
    print("T3 nodes->ports nonmonotonicity: N 1 < 2 with B 6 > 4 "
          "(N=2 aggregate consumes 8 ports over 3 junctions)")


# ---------------------------------------------------------------------------
# T4: caveat — physical node-addition need not yield boundary-extension
# ---------------------------------------------------------------------------

def t4_caveat():
    G1 = make_aggregate({0: [X, Y, O, X, Y, O]}, [])
    E = [("q", Y)]
    S = (((0, 0), "q"),)
    ok(valid_path(G1, E, S), "S valid in G1")
    ok(S in set(enumerate_paths(G1, E)), "S in P(G1;E)")
    # Bond a new node AT p = (0,0): the junction closes that port.
    G2 = make_aggregate({0: [X, Y, O, X, Y, O],
                         1: [O, X, Y, O, X, Y]}, [{(0, 0), (1, 0)}])
    ok((0, 0) not in G2["bset"], "bonded port (0,0) closed in G2")
    ok(not valid_path(G2, E, S), "transported S invalid in G2")
    dB = G2["B"] - G1["B"]
    ok(dB == 4, "dB = +4 here")
    print("T4 caveat: path [((0,0):X, q:Y)] valid in G1; after bonding at "
          "(0,0) the port is closed, dG1 not subset of dG2, transported "
          "path invalid in G2 — dB=+4 yet boundary-extension failed")


# ---------------------------------------------------------------------------
# T5: upper bound over a sweep of small (G, E) instances
# ---------------------------------------------------------------------------

def t5_bound():
    rng = random.Random(20260925)
    E_patterns = [
        [],
        [("e1", Y)],
        [("e1", X)],
        [("e1", X), ("e2", Y)],
        [("e1", Y), ("e2", Y)],
        [("e1", O)],
        [("e1", X), ("e2", O), ("e3", Y)],
    ]
    vps = [[O] * 6, [X] * 6, [Y] * 6, [X, Y, O, X, Y, O], [X, X, Y, Y, O, O]]
    junc_by_N = {
        1: [[]],
        2: [[], [[(0, 0), (1, 0)]],
            [[(0, 0), (1, 0)], [(0, 1), (1, 1)]],
            [[(0, 0), (0, 1), (1, 0), (1, 1)]]],
        3: [[], [[(0, 0), (1, 0)]],
            [[(0, 0), (1, 0), (2, 0)]],
            [[(0, 0), (1, 0)], [(1, 1), (2, 1)]]],
    }
    n = 0
    skipped = 0
    for N, jps in sorted(junc_by_N.items()):
        for jp in jps:
            for vi in range(len(vps)):
                nodes = {m: vps[(vi + m) % len(vps)] for m in range(N)}
                G = make_aggregate(nodes, jp)  # dual B oracle asserted here
                for E in E_patterns:
                    xg, yg, xe, ye = contact_counts(G, E)
                    C = len(candidate_contacts(G, E))
                    ok(C == xg * ye + yg * xe,
                       "contact-count formula C = X_G*Y_E + Y_G*X_E")
                    if C > 7:
                        skipped += 1
                        continue
                    P = enumerate_paths(G, E)
                    for s in P:
                        ok(valid_path(G, E, s),
                           "every enumerated path satisfies D3")
                    ok(len(P) <= perm_bound(C),
                       "|P|=%d <= bound(%d)=%d" % (len(P), C, perm_bound(C)))
                    n += 1
    # one seeded-random value assignment for extra coverage
    nodes = {m: [rng.choice(VALUES) for _ in range(6)] for m in range(2)}
    G = make_aggregate(nodes, [[(0, 0), (1, 0)]])
    for E in E_patterns:
        C = len(candidate_contacts(G, E))
        if C > 7:
            skipped += 1
            continue
        P = enumerate_paths(G, E)
        ok(len(P) <= perm_bound(C), "random-value bound instance")
        n += 1
    print("T5 upper bound: %d small (G,E) instances — |P(G;E)| <= "
          "sum_{k=1..C} C!/(C-k)! in all; contact-count formula verified "
          "per instance (%d skipped, C>7 cap)" % (n, skipped))


# ---------------------------------------------------------------------------
# A-witnesses: the exact |P| values 0, 0, 6 and the shared-E inversion
# ---------------------------------------------------------------------------

def a_witnesses():
    Go = agg_allO_B10()
    Gx10 = agg_allX_B10()
    Gx6 = agg_allX_B6()
    ok(Go["B"] == 10 and Gx10["B"] == 10 and Gx6["B"] == 6, "witness B values")
    p_o1 = enumerate_paths(Go, E_YRICH)
    p_o2 = enumerate_paths(Go, E_YRICH2)
    ok(len(p_o1) == 0 and len(p_o2) == 0,
       "all-O B=10: |P|=0 in any environment (O pairs with nothing)")
    ok(len(enumerate_paths(Gx10, E_YFREE)) == 0,
       "all-X B=10 in Y-free E: |P|=0")
    p6 = enumerate_paths(Gx6, E_YRICH)
    ok(len(p6) == 6, "all-X B=6 in Y-rich E: |P|=6")
    ok(all(len(s) == 1 for s in p6), "the 6 paths are the 6 singletons")
    a, b = len(p_o1), len(p6)
    ok(a < b and Go["B"] > Gx6["B"], "shared-E inversion")
    print("A-witnesses: all-O B=10 -> |P|=0 in 2 environments; all-X B=10 "
          "in Y-free E -> 0; all-X B=6 in Y-rich E -> 6; shared-E "
          "inversion 0 < 6 with B 10 > 6")


# ---------------------------------------------------------------------------
# T6: environment input validation — duplicate partner-port identities
# ---------------------------------------------------------------------------

def t6_env_qid_validation():
    """A duplicate-qid E must fail fast at model-construction time with a
    clear message (modeling choice f)."""
    G = agg_allX_B6()
    fired = False
    try:
        candidate_contacts(G, [("q", Y), ("q", Y)])
    except AssertionError as exc:
        fired = "duplicate partner-port identity" in str(exc)
    ok(fired, "duplicate-qid E rejected at construction with a clear message")
    # a same-qid-different-value E is the same malformed shape
    fired2 = False
    try:
        valid_path(G, [("q", Y), ("q", X)], (((0, 3), "q"),))
    except AssertionError as exc:
        fired2 = "duplicate partner-port identity" in str(exc)
    ok(fired2, "duplicate qid with differing values also rejected")
    print("T6 environment validation: duplicate partner-port identity in E "
          "rejected at construction with a clear message")


# ---------------------------------------------------------------------------
# Planted mutants — each must be REJECTED with a printed witness.
# ---------------------------------------------------------------------------

def mutant_M1_mono():
    """MONO: unconditional 'B1 < B2 ==> |P1| < |P2|'."""
    Ga, Gb, E = agg_allX_B6(), agg_allO_B10(), E_YRICH
    pa = len(enumerate_paths(Ga, E))
    pb = len(enumerate_paths(Gb, E))
    implication = (not (Ga["B"] < Gb["B"])) or (pa < pb)
    ok(not implication, "M1 implication must fail on the inversion witness")
    rejected("M1 (MONO)",
             "B %d < %d holds but |P| %d < %d fails (%d vs %d, shared "
             "Y-rich E) — unconditional ports->paths monotonicity is false"
             % (Ga["B"], Gb["B"], pa, pb, pa, pb))


def mutant_M2_bound_viol():
    """BOUND-VIOL: enumerator dropping the no-reuse constraint
    (depth-bounded by C) overcounts past the bound."""
    G, E = agg_allX_B6(), E_YRICH
    contacts = candidate_contacts(G, E)
    C = len(contacts)
    out = []

    def dfs(seq):
        if len(seq) >= C:
            return
        for c in contacts:
            s2 = seq + (c,)
            out.append(s2)
            dfs(s2)

    dfs(())
    mcount, b = len(out), perm_bound(C)
    ok(mcount > b, "M2 mutant count must exceed the bound")
    rejected("M2 (BOUND-VIOL)",
             "C=%d: no-reuse-dropped count %d exceeds bound %d "
             "(honest |P|=%d)" % (C, mcount, b, len(enumerate_paths(G, E))))


def mutant_M3_incl_viol():
    """INCL-VIOL: transport dropping a transported event; inclusion
    claimed under boundary-extension anyway."""
    G1 = make_aggregate({0: [X, O, O, O, O, O]}, [])
    G2, iota = extend_boundary(G1, [O] * 6, [0, 1, 2, 3, 4, 5])
    E = [("q", Y)]
    S = (((0, 0), "q"),)
    ok(S in set(enumerate_paths(G1, E)), "singleton path in P(G1;E)")

    def mutant_transport(seq):
        return tuple((iota[p], qid) for (p, qid) in seq)[1:]

    t = mutant_transport(S)
    ok(t == (), "drop-transport of a singleton yields the empty sequence")
    ok(t not in set(enumerate_paths(G2, E)),
       "empty sequence is not a path in G2")
    rejected("M3 (INCL-VIOL)",
             "singleton path %r in G1 maps under drop-transport to () "
             "which is not in P(G2;E) — the broken transport proves no "
             "inclusion" % (S,))


def mutant_M4_o_pair():
    """O-PAIR: O-valued port accepted as complementary."""
    G, E = agg_allO_B10(), [("q", X)]

    def mutant_contacts():
        out = []
        for p in G["boundary"]:
            pv = port_value(G, p)
            for qid, qv in E:
                if complementary(pv, qv) or pv == O or qv == O:
                    out.append((p, qid))
        return out

    mc = mutant_contacts()
    honest = len(enumerate_paths(G, E))
    ok(len(mc) == 10 and honest == 0, "M4 setup: 10 mutant contacts, 0 honest")
    rejected("M4 (O-PAIR)",
             "mutant admits %d O-involving contacts on the all-O B=10 "
             "boundary; honest |P|=%d (O pairs with nothing)" % (len(mc), honest))


def mutant_M5_false_lemma(dBs):
    """FALSE-LEMMA: dB >= 0 asserted for all node-additions."""
    ok(not all(d >= 0 for d in dBs.values()),
       "M5: the nonnegativity claim must fail")
    rejected("M5 (FALSE-LEMMA)",
             "asserting dB >= 0 for all node-additions fails on witness "
             "(b): dB = %d = 6 - 8 (new junctions consumed 4 old-boundary "
             "ports)" % dBs["b"])


def mutant_M6_double_count():
    """DOUBLE-COUNT: a junction consumes an already-closed port and the
    ledger counts it again — killed by the |dG| oracle."""
    N = 2
    j1 = frozenset({(0, 0), (1, 0)})
    j2 = frozenset({(0, 0), (1, 1)})  # (0,0) consumed twice
    mutant_ledger = 6 * N - (len(j1) + len(j2))  # 8
    honest_boundary = [(n, i) for n in range(N) for i in range(6)
                       if (n, i) not in (j1 | j2)]
    ok(mutant_ledger != len(honest_boundary), "M6: oracle disagreement")
    rejected("M6 (DOUBLE-COUNT)",
             "mutant ledger 6N-Sk=%d vs |dG|=%d: port (0,0) consumed by two "
             "junctions and counted twice — the dual oracle catches the leak"
             % (mutant_ledger, len(honest_boundary)))


def mutant_M7_global_valid():
    """GLOBAL-VALID: validity requiring 'no other boundary port admits a
    contact' — breaks transport monotonicity (M3)."""
    def mutant_valid(G, E, seq):
        if not valid_path(G, E, seq):
            return False
        used_p = {p for (p, _) in seq}
        eids = dict(E)
        for p in G["boundary"]:
            if p in used_p:
                continue
            for qid, qv in E:
                if complementary(port_value(G, p), qv):
                    return False  # another port admits a contact
        return True

    G1 = make_aggregate({0: [X, O, O, O, O, O]}, [])
    G2, iota = extend_boundary(G1, [X, O, O, O, O, O], [0, 1, 2, 3, 4, 5])
    E = [("q", Y)]
    S = (((0, 0), "q"),)
    ok(mutant_valid(G1, E, S), "M7: S mutant-valid in G1")
    T = transport_path(S, iota)
    ok(not mutant_valid(G2, E, T), "M7: transported S mutant-invalid in G2")
    rejected("M7 (GLOBAL-VALID)",
             "path %r mutant-valid in G1 but its transport %r is "
             "mutant-invalid in G2 (extra X port (1,0) admits a contact) — "
             "the global quantifier breaks inclusion" % (S, T))


def mutant_M8_port_reuse():
    """PORT-REUSE: path reusing a port accepted as valid."""
    G = agg_allX_B6()
    E = [("q1", Y), ("q2", Y)]
    seq_q = (((0, 3), "q1"), ((0, 4), "q1"))  # partner port reused
    seq_p = (((0, 3), "q1"), ((0, 3), "q2"))  # boundary port reused

    def mutant_valid(G, E, seq):
        eids = dict(E)
        if not seq:
            return False
        return all(is_candidate_contact(G, eids, p, qid) for (p, qid) in seq)

    ok(mutant_valid(G, E, seq_q) and not valid_path(G, E, seq_q),
       "M8: q-reuse accepted by mutant, rejected honestly")
    ok(mutant_valid(G, E, seq_p) and not valid_path(G, E, seq_p),
       "M8: p-reuse accepted by mutant, rejected honestly")
    rejected("M8 (PORT-REUSE)",
             "mutant accepts q-reuse %r and p-reuse %r; honest validator "
             "rejects both (Section 6.1: a closed port cannot recur)"
             % (seq_q, seq_p))


def mutant_M9_empty_path():
    """EMPTY-PATH: the empty sequence counted as a path."""
    G, E = agg_allO_B10(), [("q", X)]
    honest = len(enumerate_paths(G, E))
    mutant_count = honest + 1  # mutant counts () as a path
    ok(honest == 0 and mutant_count > perm_bound(0),
       "M9: mutant overcount exceeds bound(0)=0")
    rejected("M9 (EMPTY-PATH)",
             "mutant counts () as a path: |P| %d -> %d, exceeding "
             "bound(C=0)=0; D3 requires k>=1" % (honest, mutant_count))


def mutant_M10_mono_bound():
    """MONO-BOUND: contact count (hence the bound) claimed monotone
    nondecreasing in B alone, for fixed E."""
    G1, G2, E = agg_allX_B6(), agg_allO_B10(), E_YRICH
    B1, B2 = G1["B"], G2["B"]
    C1 = len(candidate_contacts(G1, E))
    C2 = len(candidate_contacts(G2, E))
    ok(B1 <= B2 and not (C1 <= C2), "M10: monotonicity must fail")
    rejected("M10 (MONO-BOUND)",
             "B %d <= %d but C %d > %d (bounds %d vs %d): the contact "
             "count — and hence the bound — is not monotone in B alone"
             % (B1, B2, C1, C2, perm_bound(C1), perm_bound(C2)))


def mutant_M11_noncompl_completion():
    """NONCOMPL-COMPLETION: junction completion over a non-complementary
    (p, q) pair accepted as a path step."""
    G = make_aggregate({0: [X, O, O, O, O, O]}, [])
    E = [("qx", X)]
    seq = (((0, 0), "qx"),)

    def mutant_contacts():
        return [(p, qid) for p in G["boundary"] for (qid, _) in E]

    ok(seq[0] in mutant_contacts(), "M11: mutant admits the (X,X) pair")
    ok(not valid_path(G, E, seq), "M11: honest validator rejects it")
    rejected("M11 (NONCOMPL-COMPLETION)",
             "mutant completes non-complementary pair ((0,0):X, qx:X); "
             "honest validator rejects (X<->Y only)")


def mutant_M12_unvalued_inclusion():
    """UNVALUED-INCLUSION: boundary-extension admitted on unlabeled port
    sets (value-preservation dropped). Proves value-preservation is
    load-bearing, not decorative."""
    G1 = make_aggregate({0: [X, O, O, O, O, O]}, [])
    G2 = make_aggregate({0: [Y, O, O, O, O, O]}, [])
    E = [("q", Y)]
    S = (((0, 0), "q"),)
    ok(valid_path(G1, E, S), "M12: S valid in G1")
    # (a) the mutant admits the triple: as unlabeled sets the boundaries
    # coincide, so identity injection is the mutant's boundary-extension.
    ok(G1["bset"] == G2["bset"], "M12: unlabeled boundary sets coincide")
    iota = {p: p for p in G1["boundary"]}
    P1 = enumerate_paths(G1, E)
    P2 = set(enumerate_paths(G2, E))
    n1, n2 = len(P1), len(P2)
    ok(n1 == 1 and n2 == 0, "M12: |P(G1;E)|=1 > 0=|P(G2;E)|")
    T = transport_path(S, iota)
    ok(not valid_path(G2, E, T), "M12: transported path invalid in G2")
    inclusion_holds = all(transport_path(s, iota) in P2 for s in P1)
    ok(not inclusion_holds,
       "M12: inclusion fails under the mutant's admission")
    # (b) the genuine value-sensitive predicate does not admit it.
    flips = sorted(p for p in G1["boundary"]
                   if port_value(G2, iota[p]) != port_value(G1, p))
    ok(flips == [(0, 0)] and port_value(G1, (0, 0)) == X
       and port_value(G2, (0, 0)) == Y,
       "M12: exactly one value flip, at (0,0): X -> Y")
    rejected("M12 (UNVALUED-INCLUSION)",
             "mutant admits the (G1,G2,E) triple on unlabeled port sets, "
             "but the genuine value-sensitive predicate does not (value "
             "flip at (0,0): X -> Y); transported path ((0,0):X, q:Y) "
             "lands on ((0,0):Y, q:Y), a non-contact, so inclusion fails: "
             "|P(G1;E)|=%d > %d=|P(G2;E)|" % (n1, n2))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("F.48 consolidation-path checks — Paper 11, Section 11.2")
    t1_sweep()
    t1_sharpness()
    Gold, dBs = t2_witnesses()
    # T3 reuses the T2(b) construction: N=2, three junctions, B=4.
    Gbig = make_aggregate({0: [X, Y, O, X, Y, O],
                           1: [X, Y, O, X, Y, O]},
                          [{(0, 0), (1, 0)}, {(0, 1), (1, 1)},
                           {(0, 2), (0, 3), (1, 2), (1, 3)}])
    t3_nonmonotonicity(Gold, Gbig)
    t4_caveat()
    t5_bound()
    a_witnesses()
    t6_env_qid_validation()
    mutant_M1_mono()
    mutant_M2_bound_viol()
    mutant_M3_incl_viol()
    mutant_M4_o_pair()
    mutant_M5_false_lemma(dBs)
    mutant_M6_double_count()
    mutant_M7_global_valid()
    mutant_M8_port_reuse()
    mutant_M9_empty_path()
    mutant_M10_mono_bound()
    mutant_M11_noncompl_completion()
    mutant_M12_unvalued_inclusion()
    print("F.48 TOTAL: %d checks passed; %d/12 planted mutants rejected "
          "with printed witnesses." % (NCHECKS, NREJECTED))
    assert NREJECTED == 12, "all 12 mutants must be rejected"
    return 0


if __name__ == "__main__":
    sys.exit(main())