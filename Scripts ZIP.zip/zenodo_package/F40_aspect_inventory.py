INPUT_PROVENANCE = {
    "INVENTORY": {"class": "paper-defined", "source": "§4.2 (aspect inventory: port/junction/node/whole)"},
    "JUNCTIONS": {"class": "control", "note": "test junction fixtures"},
    "NODES": {"class": "control", "note": "test node fixtures"},
    "TICKS": {"class": "control", "note": "sweep input: tick values"},
    "VALUES": {"class": "control", "note": "sweep input: port values"},
    "CONFIG_ID": {"class": "control", "note": "model configuration identifier"},
    "junction": {"class": "arbitrary-representative", "independence": "representative resolved junction-aspect; outcome independent of specific choice"},
    "rejected": {"class": "control", "note": "planted-test rejection counter"},
    "seeking": {"class": "arbitrary-representative", "independence": "representative seeking port-aspect; outcome independent of specific choice"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port', 'junction', 'node', 'whole'],
    "notes": "inventory model exercises all four selector kinds.",
}
#!/usr/bin/env python3
"""Paper 11 - F.40: aspect inventory machine check (Section 4.2, rule R14).

Model:
- Configuration C: 2 nodes (n0, n1), 6 ports each (L2); one shared junction j0
  consuming n0.p0 and n1.p0 (Paper-2 bonding modes).
- Aspect = (config_id, kind, selector), kind in {port, junction, node, whole}.
- ports(a): the port set of the aspect, per selector kind (Section 4.2).
- u(a, tick): unmatched-integer count per selector kind over a port-value
  model {-1, 0, +1}; nonzero = unmatched (cf. F.36 / F.39). For a junction,
  PTR-closed is exactly the all-zero case, so u = 0 there too.
- R = (a, p, b, q, tick): well-formed iff p in ports(a) and q in ports(b)
  (Section 3.2 well-formedness constraint).

Verifies:
1. Inventory transcription + constructor-guard enforcement (R14).
   INVENTORY transcribes the paper's four-kind inventory (§4.2: "The four
   selector kinds cover every use of 'aspect' in this paper, and no other
   use is permitted"). The four kinds are a DEFINITIONAL STIPULATION of
   the paper, not a machine-derived result: no enumeration inside the
   script could prove a definition exhaustive. What the machine does check
   is (a) the transcription is the one the model enforces -- every aspect
   the model builds passes through make_aspect, which admits only
   (kind, selector) pairs with kind in the inventory and selector in the
   kind's selector domain S(C) = Ports(C) ∪ Junctions(C) ∪ Nodes(C) ∪ {C}
   (§4.2), rejecting anything else; and (b) planted non-inventory kinds
   and out-of-domain selectors are rejected with printed witnesses.
2. Per-kind semantic coherence over the FULL selector set: for every
   selector of every kind in the model (all 12 ports, the junction, both
   nodes, the whole -- 16 aspects), ports(a) is a non-empty subset of the
   configuration's ports and u(a, tick) is an exact integer >= 0 on every
   tick; the operational role definitions typecheck (a seeking
   port-aspect is active-capable in R; a resolved junction-aspect is
   passive-capable).
3. R-tuple well-formedness is enforced: a malformed R (a port no presented
   aspect owns) is rejected.
4. R14 planted rejections: a free-floating kind, a case-mismatched kind,
   and out-of-domain selectors are rejected with printed witnesses.
5. Prose use-coverage (new): every hyphenated X-aspect(s) token in the
   paper's prose (outside fenced code blocks) names an inventory kind
   (port/junction/node/whole) or a documented distributive quantifier
   (per-/all-aspect); a planted fifth-kind token is rejected with a
   printed witness. This closes the model/prose gap: no fifth aspect
   kind is USED anywhere in the paper, and no fifth kind is
   CONSTRUCTIBLE in the model.

Epistemic boundary, stated explicitly: the script does NOT machine-derive
the inventory's exhaustiveness. "Every aspect resolves to the four-kind
inventory" holds in the model by construction (the constructor guard),
which is the machine-checked enforcement of §4.2's definitional
stipulation -- the paper's Appendix I description already states this
honestly ("universality carried by the constructor guard"). The new
prose sweep proves no fifth kind is used; it does not prove no fifth
kind could be defined. Use-coverage is machine-exhaustive;
kind-exhaustiveness bottoms out in the definition -- the V18 verdict,
not a failure mode. Faithfulness of the transcription to §4.2 is
human-audit territory.
"""

INVENTORY = {"port", "junction", "node", "whole"}
VALUES = (-1, 0, +1)
TICKS = (0, 1)

CONFIG_ID = "C"
NODES = ("n0", "n1")
ALL_PORTS = {(n, i) for n in NODES for i in range(6)}
JUNCTIONS = {"j0": {("n0", 0), ("n1", 0)}}  # shared interior junction


def _selector_domain(kind):
    """The §4.2 selector domain S(C) per kind: Ports(C), Junctions(C),
    Nodes(C), {C}."""
    if kind == "port":
        return set(ALL_PORTS)
    if kind == "junction":
        return set(JUNCTIONS)
    if kind == "node":
        return set(NODES)
    if kind == "whole":
        return {CONFIG_ID}
    raise ValueError(f"R14: unknown aspect kind {kind!r}")


def make_aspect(kind, selector):
    """Constructor guard (R14): the ONLY way to build an aspect. Rejects a
    kind outside the four-kind inventory (a free-floating aspect) and a
    selector outside the kind's §4.2 selector domain. Exhaustiveness in the
    model is enforced here, by construction -- not proved by enumeration."""
    if kind not in INVENTORY:
        raise ValueError(f"R14: free-floating aspect kind {kind!r} "
                         "resolves to no selector in the inventory")
    if selector not in _selector_domain(kind):
        raise ValueError(f"R14: selector {selector!r} outside the {kind!r} "
                         "selector domain S(C)")
    return (CONFIG_ID, kind, selector)


def ports_of(aspect):
    _, kind, sel = aspect
    if kind == "port":
        return {sel}
    if kind == "junction":
        return set(JUNCTIONS[sel])
    if kind == "node":
        return {(sel, i) for i in range(6)}
    if kind == "whole":
        return set(ALL_PORTS)
    raise ValueError(f"R14: unknown aspect kind {kind!r}")


def u(aspect, tick_values):
    return sum(1 for p in ports_of(aspect) if tick_values[p] != 0)


def well_formed_R(a, p, b, q):
    return p in ports_of(a) and q in ports_of(b)


# ---- 1 + 2: guard enforcement and per-kind coherence over the FULL ----
# ---- selector set (every selector of every kind: 12 + 1 + 2 + 1 = 16) ----
aspects = (
    [make_aspect("port", (n, i)) for n in NODES for i in range(6)]
    + [make_aspect("junction", j) for j in JUNCTIONS]
    + [make_aspect("node", n) for n in NODES]
    + [make_aspect("whole", CONFIG_ID)]
)
assert len(aspects) == 16, "full selector set: 12 ports + 1 junction + 2 nodes + whole"
assert len({a[1] for a in aspects}) == 4, "all four kinds represented"

# Tick 0: boundary port n0.p1 presents an unmatched integer; junction resolved.
tick0 = {p: 0 for p in ALL_PORTS}
tick0[("n0", 1)] = 1
# Tick 1: everything resolved.
tick1 = {p: 0 for p in ALL_PORTS}

for a in aspects:
    ps = ports_of(a)
    assert ps and ps <= ALL_PORTS, ("ports(a) must be a non-empty port set", a)
    for tv in (tick0, tick1):
        n = u(a, tv)
        assert isinstance(n, int) and n >= 0, "u must be an exact integer >= 0"

# Spot semantics on the full set (not just representatives): the seeking
# boundary port counts its unmatched integer; the junction is resolved;
# node/whole aspects sum their ports.
seeking = make_aspect("port", ("n0", 1))
assert u(seeking, tick0) == 1, "port-aspect must count its unmatched integer"
junction = make_aspect("junction", "j0")
assert u(junction, tick0) == 0, "resolved junction-aspect must have u == 0"
for n in NODES:
    assert u(make_aspect("node", n), tick0) == sum(
        1 for i in range(6) if tick0[(n, i)] != 0), "node-aspect sums its six ports"
assert u(make_aspect("whole", CONFIG_ID), tick0) == 1, "whole-aspect sums the configuration"
assert u(make_aspect("whole", CONFIG_ID), tick1) == 0

# Role definitions typecheck against the kinds: active-capable vs passive-capable.
assert u(seeking, tick0) > 0      # active(a, R) admissible: u > 0, open port presented
assert u(junction, tick0) == 0    # passive(b, R) admissible: resolved reference

# ---- 3: R-tuple well-formedness ----
assert well_formed_R(seeking, ("n0", 1), junction, ("n0", 0)), "valid R"
assert not well_formed_R(seeking, ("n1", 5), junction, ("n0", 0)), \
    "malformed R (port owned by no presented aspect) must be rejected"
assert not well_formed_R(seeking, ("n0", 1), junction, ("n1", 5)), \
    "malformed R on the b side must be rejected"

# ---- 4: planted guard violations rejected (R14), each with a witness ----
rejected = []


def expect_reject(label, kind, selector):
    try:
        make_aspect(kind, selector)
    except ValueError as e:
        rejected.append(label)
        print(f"F.40 WITNESS: planted {label} rejected -- {e}")
        return
    raise SystemExit(f"F.40 planted {label} NOT rejected")


expect_reject("free-floating kind", "facet", "mystery")
expect_reject("case-mismatched kind", "PORT", ("n0", 1))
expect_reject("unknown-node selector", "port", ("n9", 0))
expect_reject("out-of-range port selector", "port", ("n0", 6))
expect_reject("unknown-junction selector", "junction", "j9")
assert rejected == ["free-floating kind", "case-mismatched kind",
                    "unknown-node selector", "out-of-range port selector",
                    "unknown-junction selector"], rejected

print("F.40 PASS: four-kind inventory transcribed from §4.2 (definitional "
      "stipulation, not machine-derived); the constructor guard admits "
      "only in-inventory kinds with in-domain selectors -- exhaustiveness "
      "in the model is enforced by construction.")
print("F.40 PASS: ports(a) and u(a,tick) well-defined over the full "
      "selector set (16 aspects: 12 ports + 1 junction + 2 nodes + whole); "
      "role definitions typecheck.")
print("F.40 PASS: R-tuple well-formedness enforced; malformed R rejected.")
print("F.40 PASS: 5/5 planted guard violations rejected (R14): "
      "free-floating kind, case-mismatched kind, unknown-node selector, "
      "out-of-range port selector, unknown-junction selector.")


def _prose_kind_token_sweep():
    """5. Prose use-coverage: every hyphenated X-aspect(s) token in the
    paper's prose names an inventory kind or a distributive quantifier.

    A hyphenated 'X-aspect' is a kind claim: it says the aspect is of kind
    X (the paper's own kind-naming convention, cf. the §4.2 definition
    bullets 'port-aspect:', 'junction-aspect:', ...). The machine therefore
    demands X in the four-kind inventory. The two distributive forms --
    'per-aspect' (for each aspect) and 'all-aspect(s)' (all aspects) --
    quantify over the inventory rather than naming a kind; they are
    documented here, not smuggled. Anything else (a planted
    'facet-aspect', 'loop-aspect', ...) is a fifth-kind smuggling attempt
    and fails loudly with a printed witness.

    Matching is case-insensitive and unicode dashes (U+2010-U+2015, U+2212)
    are normalized to the ASCII hyphen first: a fifth kind spelled
    'Facet-Aspect' or 'facet–aspect' must not evade the sweep.

    Boundary, stated: space-separated descriptive qualifiers ('interior
    aspects', 'seeking aspect', ...) are adjectives, not kind claims, and
    stay human-audit territory; the machine checks the hyphenated
    kind-claim convention, which is every kind-claim the paper makes.

    What this proves: no fifth aspect kind is USED anywhere in the paper's
    prose. What it does not prove: the inventory's conceptual
    exhaustiveness, which remains §4.2's definitional stipulation (see the
    docstring's epistemic boundary). Use-coverage is machine-exhaustive;
    kind-exhaustiveness bottoms out in the definition.
    """
    import re
    from pathlib import Path
    kinds = {"port", "junction", "node", "whole"}
    distributive = {"per", "all"}
    token_re = re.compile(r"\b([A-Za-z]+)-aspects?\b", flags=re.IGNORECASE)
    dash_re = re.compile("[\u2010-\u2015\u2212]")

    def _scan(lines):
        """Production scanning path: fence logic + regex + prefix check.
        Returns (n_tokens, bad) where bad is a list of
        (lineno, token, context) for rejected tokens."""
        in_fence = False
        bad = []
        n_tokens = 0
        for lineno, line in enumerate(lines, start=1):
            if line.startswith("```"):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            for m in token_re.finditer(line):
                n_tokens += 1
                prefix = m.group(1).lower()
                if prefix not in kinds and prefix not in distributive:
                    bad.append((lineno, m.group(0), line.strip()[:120]))
        return n_tokens, bad

    paper = Path(__file__).resolve().parent.parent / "paper_11.md"
    text = dash_re.sub("-", paper.read_text(encoding="utf-8"))
    lines = text.split("\n")
    n_tokens, bad = _scan(lines)
    if bad:
        for lineno, tok, ctx in bad:
            print(f"F.40 WITNESS: fifth-kind aspect token {tok!r} at prose "
                  f"line {lineno}: {ctx}")
        raise SystemExit(
            f"F.40 prose sweep REJECTED: {len(bad)} hyphenated aspect-kind "
            f"token(s) outside the four-kind inventory")
    # Planted fifth-kind smuggling attempts, run through the production
    # scanning path (regex + fence logic + prefix check) on synthetic
    # one-line papers -- not a parallel classifier.
    mutants = ["facet-aspect", "loop-aspect", "field-aspect",
               "phase-aspect", "stratum-aspect", "mode-aspect",
               "Facet-Aspect", "facet\u2013aspect"]
    for mu in mutants:
        probe = ["context before",
                 dash_re.sub("-", f"a planted {mu} token here"),
                 "context after"]
        _, mu_bad = _scan(probe)
        if not mu_bad:
            raise SystemExit(f"F.40 planted {mu!r} NOT rejected")
        print(f"F.40 WITNESS: planted {mu!r} rejected -- fifth-kind smuggling")
    # The four kind-definition bullets must exist (transcription anchor).
    for kind in ("port", "junction", "node", "whole"):
        if not re.search(r"^- \*\*" + kind + r"-aspect:\*\*", text, flags=re.M):
            raise SystemExit(f"F.40 transcription anchor missing: {kind}-aspect")
    print(f"F.40 PASS: prose use-coverage -- {n_tokens} hyphenated "
          f"aspect-kind tokens, every one names an inventory kind or a "
          f"distributive quantifier; 8/8 planted fifth-kind mutants rejected.")


_prose_kind_token_sweep()
