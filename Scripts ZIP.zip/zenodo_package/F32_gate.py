#!/usr/bin/env python3
"""Paper 11 - F.32 gate composition: the worked aggregates satisfy the
structural gate.

F.33-F.35's check-2 validates junction tables (pairwise-disjoint port
lists, arity cross-check, port-index and node-id bounds) but does not
enforce the §4.1 Bonded Aggregate definition's structural conditions:
at least two nodes, at least one junction, every junction spanning at
least two distinct nodes, and node-adjacency connectivity. F.32's
is_bonded_aggregate enforces exactly those conditions. This script
composes the two: it adapts the constructions verified by F.33-F.35 --
aggregate (a); aggregate (b) in both documented consumption conventions
(branch B is the paper's stated convention); aggregate (c) -- to F.32's
native ("aggregate", nodes, junctions) form and asserts the gate admits
each one, with printed witnesses.

Adaptation notes (all stated, none hidden): the junction port-index
structure is taken from each script's own construction table (the data
F.33-F.35 verify), with node names mapped to integer indices; node
identities are abstracted to F.32's own deterministic 27-state triples
(the gate checks bonding structure, not state content -- every node
must be a 27-state inventory member; which state is immaterial to the
gate). No construction data is hand-copied: the tables are imported.
"""

# No module-level self-contained bindings: the construction data is
# imported from the scripts that verify it (their INPUT_PROVENANCE
# blocks declare it), and node triples come from F.32's own generator.
INPUT_PROVENANCE = {}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "structural gate over aggregate constructions; not aspect-kind-quantified.",
}

import F32_simple_state as _f32
import F33_aggregate_a as _f33
import F34_aggregate_b as _f34
import F35_aggregate_c as _f35


def _to_native(triples, junctions):
    """Translate one aggregate construction to F.32's native form."""
    names = sorted(triples)
    index = {name: i for i, name in enumerate(names)}
    nodes = _f32._nodes(len(names))
    native_junctions = [
        [(index[v], p) for (v, p) in d["ports"]]
        for _, d in sorted(junctions.items())
    ]
    return ("aggregate", nodes, native_junctions)


def _constructions():
    return {
        "aggregate-(a)": _to_native(_f33.AGG_A_TRIPLES,
                                    _f33.AGG_A_JUNCTIONS),
        "aggregate-(b)/branch-A": _to_native(_f34.AGG_B_A_TRIPLES,
                                             _f34.AGG_B_A_JUNCTION),
        "aggregate-(b)/branch-B": _to_native(_f34.AGG_B_B_TRIPLES,
                                             _f34.AGG_B_B_JUNCTION),
        "aggregate-(c)": _to_native(_f35.AGG_C_FIXTURE_TRIPLES,
                                    _f35.AGG_C_JUNCTIONS),
    }


def main():
    cfgs = _constructions()
    for label, cfg in cfgs.items():
        _, nodes, junctions = cfg
        admitted = _f32.is_bonded_aggregate(cfg)
        print("WITNESS F.32-gate [%s]: nodes=%d junctions=%d arities=%s "
              "boundary=%d admitted=%s"
              % (label, len(nodes), len(junctions),
                 sorted(len(j) for j in junctions),
                 _f32.boundary_count(cfg), admitted))
        assert admitted, "F.32 gate rejected " + label
    print("F.32-gate PASS: all %d worked-aggregate constructions satisfy "
          "the §4.1 bonded-aggregate definition (>=2 nodes, >=1 junction, "
          "k_j >= 2, distinct nodes per junction, connected)."
          % len(cfgs))


if __name__ == "__main__":
    main()
