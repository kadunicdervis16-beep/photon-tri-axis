"""Paper 11 - F.32: structural-cut classification (simple vs complex).

Representations:
  ("single", triple)               an individual configuration from the 27
  ("aggregate", nodes, junctions)   a bonded multi-node structure: nodes is a
                                   list of 27-state triples, each junction is
                                   a list of (node, port) pairs consumed by it.

The structural cut (§4.1):
  simple  = not a complex atomic configuration, i.e. exactly the single-node
            case: a tilt triple from the 27-state inventory (L1).
  complex = a bonded aggregate of simple states carrying open ports, checked
            against the actual content of the §4.1 Bonded Aggregate definition
            (finite connected G = (V, E); V from the 27-state inventory;
            junctions completed among two or more ports with k_j >= 2) plus the
            Complex Configuration requirement of carrying open ports
            (B = 6N - sum_j k_j >= 1, §4.1/§4.3).

Both classifiers check structure, not bare tags.
"""

INPUT_PROVENANCE = {
    "PORTS_PER_NODE": {"class": "paper-defined", "source": "§4.3 Port Count Invariance (six ports per node)"},
    "SPANNING": {"class": "control", "note": "script-generated spanning family (F.32-built fixtures)"},
    "STATES": {"class": "paper-defined", "source": "§5.1 (27 simple states)"},
    "bad_arity1": {"class": "control", "note": "test fixture / rejection counter"},
    "bad_disconnected": {"class": "control", "note": "test fixture / rejection counter"},
    "bad_double_consumed": {"class": "control", "note": "test fixture / rejection counter"},
    "bad_node": {"class": "control", "note": "test fixture / rejection counter"},
    "bad_port": {"class": "control", "note": "test fixture / rejection counter"},
    "bad_self_junction": {"class": "control", "note": "test fixture / rejection counter"},
    "counts": {"class": "control", "note": "check counter / accumulator"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "structural-cut classification over configurations; not aspect-kind-quantified.",
}
from itertools import product

STATES = list(product("XYO", repeat=3))
assert len(STATES) == 27
PORTS_PER_NODE = 6


def _valid_node(triple):
    return triple in STATES


def is_bonded_aggregate(cfg):
    """Check the §4.1 Bonded Aggregate definition on cfg.

    Requires: finite G = (V, E) with at least two nodes and at least one
    junction (adjacency without a bonded junction does not constitute a
    bonded aggregate); every node a 27-state configuration (L1); every
    junction consuming k_j >= 2 ports (finite integer); bonding modes join
    configurations, so each junction spans at least two distinct nodes;
    the node adjacency graph is connected. Additionally enforced as input
    well-formedness (not a §4.1 definitional clause): each port consumed at
    most once, per the Port-Partition Exactness lemma (§4.3) — derived from
    the §6.1 bonding-mode premise and the Port Status binary.
    """
    if not (isinstance(cfg, tuple) and len(cfg) == 3 and cfg[0] == "aggregate"):
        return False
    _, nodes, junctions = cfg
    if not isinstance(nodes, list) or len(nodes) < 2:
        return False
    if any(not _valid_node(t) for t in nodes):
        return False
    if not isinstance(junctions, list) or len(junctions) < 1:
        return False
    n = len(nodes)
    consumed = set()
    adjacency = {i: set() for i in range(n)}
    for j in junctions:
        if not isinstance(j, list) or len(j) < 2:
            return False  # k_j >= 2, a finite integer
        members = set()
        for pair in j:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                return False
            i, p = pair
            if not (isinstance(i, int) and isinstance(p, int)):
                return False
            if not (0 <= i < n and 0 <= p < PORTS_PER_NODE):
                return False
            if (i, p) in consumed:
                return False  # each port consumed at most once
            consumed.add((i, p))
            members.add(i)
        if len(members) < 2:
            return False  # Paper 2 §11.1 bonding modes join configurations
        for a in members:
            adjacency[a] |= members - {a}
    seen, stack = {0}, [0]
    while stack:
        a = stack.pop()
        for b in adjacency[a]:
            if b not in seen:
                seen.add(b)
                stack.append(b)
    return len(seen) == n


def boundary_count(cfg):
    """B = 6N - sum_j k_j (§4.1 quantity; pairwise corollary B = 6N - 2J)."""
    _, nodes, junctions = cfg
    return PORTS_PER_NODE * len(nodes) - sum(len(j) for j in junctions)


def is_simple(cfg):
    """Structural predicate, not a bare tag check: exactly the single-node
    case holding a triple from the 27-state inventory. Everything else —
    unknown tags, malformed triples, aggregates — is not simple."""
    return (isinstance(cfg, tuple) and len(cfg) == 2 and cfg[0] == "single"
            and _valid_node(cfg[1]))


def is_complex(cfg):
    """A bonded aggregate per §4.1 carrying open ports."""
    return (isinstance(cfg, tuple) and cfg[0] == "aggregate"
            and is_bonded_aggregate(cfg) and boundary_count(cfg) >= 1)


# --- Spanning family, generated programmatically (not hardcoded instances) ---

def _nodes(n, step=7, start=3):
    """n distinct 27-state triples, deterministic cycle through the inventory."""
    return [STATES[(start + step * i) % 27] for i in range(n)]


def build_pairwise():
    """Two nodes, one pairwise junction (k_j = 2)."""
    return ("aggregate", _nodes(2), [[(0, 0), (1, 0)]])


def build_center3():
    """Three nodes sharing one center junction (k_j = 3), as in aggregate (a)."""
    return ("aggregate", _nodes(3), [[(0, 0), (1, 0), (2, 0)]])


def build_branched_chain():
    """Four nodes: a chain with a branch at node 1 (pairwise junctions)."""
    return ("aggregate", _nodes(4),
            [[(0, 0), (1, 0)], [(1, 1), (2, 0)], [(1, 2), (3, 0)]])


def build_star(n_leaves=4):
    """N >= 4 star: center node 0 bonded pairwise to each of n_leaves leaves."""
    return ("aggregate", _nodes(n_leaves + 1),
            [[(0, l), (k + 1, 0)] for k, l in enumerate(range(n_leaves))])


def build_chain_c():
    """Aggregate (c) per F.35's construction: linear chain of three nodes
    A-B-C with two shared pairwise junctions; the middle node B participates
    in both junctions (boundary count 14)."""
    return ("aggregate", _nodes(3), [[(0, 0), (1, 0)], [(1, 1), (2, 0)]])


SPANNING = {
    "pairwise": build_pairwise(),
    "k3-center": build_center3(),
    "branched-chain": build_branched_chain(),
    "star-5": build_star(4),
    "chain-c": build_chain_c(),
}

# Every spanning-family member satisfies the bonded-aggregate definition
# and classifies complex (not simple).
for name, cfg in SPANNING.items():
    assert is_bonded_aggregate(cfg), name
    assert is_complex(cfg), name
    assert not is_simple(cfg), name

# Every individual configuration from the 27 classifies simple.
assert all(is_simple(("single", s)) for s in STATES)

# The structural predicate admits no bare tags and no malformed structures.
assert not is_simple(("single", ("X", "Y", "Z")))   # symbol outside the inventory
assert not is_simple(("single", ("X", "Y")))        # not a tilt triple
assert not is_simple(("single",))                  # bare tag
assert not is_simple(("weird", ("X", "X", "X")))   # unknown tag
assert not is_simple(("aggregate", [("X", "X", "X")], []))  # < 2 nodes, no junction

bad_disconnected = ("aggregate", _nodes(3), [[(0, 0), (1, 0)]])
bad_arity1 = ("aggregate", _nodes(2), [[(0, 0)]])
bad_double_consumed = ("aggregate", _nodes(2), [[(0, 0), (1, 0)], [(0, 0), (1, 1)]])
bad_self_junction = ("aggregate", _nodes(2), [[(0, 0), (0, 1)]])
bad_node = ("aggregate", [("X", "X", "Z"), ("Y", "Y", "Y")], [[(0, 0), (1, 0)]])
bad_port = ("aggregate", _nodes(2), [[(0, 0), (1, 9)]])
for bad in (bad_disconnected, bad_arity1, bad_double_consumed,
            bad_self_junction, bad_node, bad_port):
    assert not is_bonded_aggregate(bad), bad
    assert not is_complex(bad), bad
    assert not is_simple(bad), bad

counts = {}
for s in STATES:
    n = non_o_count = sum(c != "O" for c in s)
    counts[n] = counts.get(n, 0) + 1
assert counts == {0: 1, 1: 6, 2: 12, 3: 8}, counts

saturated = [s for s in STATES if sum(c != "O" for c in s) == 3]
open_states = [s for s in STATES if 0 < sum(c != "O" for c in s) < 3]
photon = [s for s in STATES if sum(c != "O" for c in s) == 0]
assert len(saturated) == 8 and len(open_states) == 18 and len(photon) == 1


# --- Planted variant (controlled wrong implementation; not live code) ---
# A plausible-but-wrong shortcut: simple = complement of the
# bonded-aggregate check. It misclassifies every malformed aggregate in
# the rejection set as simple (disconnected, arity-1 junction, double
# port consumption, self-junction, non-inventory node, out-of-range
# port), because it never checks single-node structure directly.
def planted_is_simple(cfg):
    if isinstance(cfg, tuple) and cfg[0] == "aggregate":
        return not is_bonded_aggregate(cfg)
    return is_simple(cfg)


# The planted variant misclassifies the witness set as simple; the real
# structural predicate rejects every member of the same set.
WITNESS_SET = (bad_disconnected, bad_arity1, bad_double_consumed,
               bad_self_junction, bad_node, bad_port)
for bad in WITNESS_SET:
    assert planted_is_simple(bad), bad   # the variant gets it wrong
    assert not is_simple(bad), bad       # the real check rejects it


# Planted variant: a tag-only bonded predicate accepts a disconnected
# structure that the real definition rejects.
def planted_is_bonded(cfg):
    return isinstance(cfg, tuple) and cfg[0] == "aggregate"


assert planted_is_bonded(bad_disconnected)     # the variant accepts it
assert not is_bonded_aggregate(bad_disconnected)  # the real check rejects it

print("F.32 PASS: 27 singles classify simple; aggregates classify complex.")
print("F.32 PASS: spanning family (pairwise, k_j=3 center, branched chain, "
      "N=5 star, chain (c)) all satisfy the bonded-aggregate definition and "
      "classify complex.")
print("F.32 PASS: structural predicate rejects bare tags and malformed "
      "structures (arity, double consumption, self-junction, connectivity).")
print("F.32 PASS: planted complement-cut variant (simple = not bonded) "
      "misclassifies all 6 malformed-aggregate witnesses as simple; the "
      "structural predicate rejects all of them; the tag-only bonded "
      "predicate is rejected against the disconnected witness.")