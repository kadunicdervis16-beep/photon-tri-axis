#!/usr/bin/env python3
"""Paper 11 - F.52: theorem-map generator (Appendix J).

Reads the F.38 claim registry (REGISTRY, imported -- never hand-copied)
and emits Appendix J, the paper's theorem map: one row per registered
claim giving the registry ID, the badge level, where the claim is stated
in the paper, where it is proved, which script checks it, and the claim
text as registered. The map points at the paper's own sentences; it does
not rephrase them.

Statement/proof locations come from RESOLUTIONS, recorded from the
paper's own headings with the paper open. Every section token in
RESOLUTIONS is mechanically verified to exist as a paper heading
(the section-pointer check) -- the check is existence-only: whether the
claim is actually stated/proved at the recorded section is human-audit
territory, and a wrong-but-existing address passes by design, the
section-address analogue of R3's well-worded-but-wrong banner; a claim
whose location cannot be resolved is emitted as UNRESOLVED, never
guessed.

Run modes:
  python3 F52_theorem_map.py --emit   write appendix_j_theorem_map.md
                                      (sibling of the paper)
  python3 F52_theorem_map.py          verify the paper's embedded Appendix J
                                      is byte-identical to the generated text,
                                      check the map's per-claim attributions
                                      against the canonical E.2 table (ID,
                                      Level/Badge, Script/Checked-by
                                      agreement), run the section-pointer
                                      checks and the planted self-tests;
                                      exit 0 on PASS.

Table safety: claim texts are reproduced verbatim except that literal
"|" characters (absolute-value bars, e.g. |P(G;E)|) are backslash-escaped
so the markdown table keeps six columns. Nothing else is altered.

E.2<->J checker agreement (V9 remediation). E.2 is the paper's canonical
claim table; Appendix J is the generated map. Their shared attribution
columns -- ID, Level/Badge, Script/Checked-by -- must agree claim by
claim, or the check fails loudly with a witness naming the ID. Script
cells are compared as token sets with F.33-F.35-style range expansion,
so E.2's deliberate range notation and J's expanded rendering are the
same set, not drift; prose and inherited rows are compared as
prose/inherited (section-and-paper attribution tokens must match), never
as drift. This closes the drift class whose pre-#111 instance (E.2
"prose §11.3" against a stale "Checked by F.37") survived every gate
until #111(d)'s mechanical defect-class sweep caught it.

Disclosure. (1) Native domain: the paper's rendered E.2 canonical claim
table (Appendix E) and the embedded Appendix J theorem map, as they
appear in the paper text. (2) Verified domain: the parsed per-claim
(ID, Level/Badge, checker-cell) triples -- plain strings; the check
operates on the tables' renderings, never on the claims' content.
(3) Map: two header-located table parsers (maxsplit so the last column
keeps its pipes; wrong column counts and duplicate IDs rejected)
mapping rendered rows to ID->triple dicts, plus a cell classifier
mapping each checker cell to (kind, script-token set,
section/paper-attribution-token set): script ranges expanded across
every Unicode dash shape plus U+2212 (a re-typed dash cannot silently
change the token set) and the abbreviated "F.33–35" form; kind by
leading marker ("prose"/"inh."/"inherited") or script-token presence --
a cell with a prose/inherited marker word ANYWHERE that also carries
script tokens raises loudly instead of silently reclassifying (that
flip would mask exactly the kind-flip drift this gate exists to
catch); section/paper attribution tokens normalized across
§/section/sec./Paper spellings and compared in every kind, so a
prose-attribution difference inside a script cell is drift too. (4) What the map preserves: claim-ID identity, the
badge/level token, and the checker-attribution content -- which scripts
are named (as a set, order-free) and which section or inherited source
a prose/inherited row points at. (5) Outside the machine check: whether
a named script actually checks the claim (a script named in both tables
that checks nothing passes -- pointer topicality is F.38's R3,
existence-only, not this script); every other E.2 column (Kind, Axioms,
Deps, Deferred, Text -- Text is F.51's domain); J's Stated/Proved
addresses beyond heading existence; the claim texts; and agreement on a
wrong address -- if both tables named the same wrong-but-existing
section, this check passes by design (agreement, not correctness, is
what is gated here). Transitive, not direct: E.2's Script cells have no
direct gate against the registry's script pointers -- the path is
E.2<->J (this check) composed with J's byte-identity against the
registry-fed generator; the E.2<->registry script-pointer leg is
covered only through that composition.

No registry claim is badged on this machinery: it is process machinery
rendering the registry the paper already carries.
"""

INPUT_PROVENANCE = {
    "HERE": {"class": "control",
             "note": "runtime path to this script's directory"},
    "PAPER": {"class": "control",
              "note": "runtime path to the paper file under test"},
    "MAP_OUT": {"class": "control",
                "note": "emitted appendix filename (sibling of the paper)"},
    "GENERATED_DATE": {"class": "control",
                       "note": "date string stamped in the map header; "
                               "update on regeneration"},
    "EXPECTED_CLAIMS": {"class": "control",
                        "note": "registry claim count (57)"},
    "RESOLUTIONS": {"class": "paper-defined",
                    "note": "claim ID -> (stated section, proved section), "
                            "recorded from the paper's own headings with the "
                            "paper open; every section token is mechanically "
                            "verified against the paper's headings"},
    "E2_TABLE": {"class": "paper-defined",
                 "note": "the canonical E.2 claim table (Appendix E): "
                         "per-claim Level and Script cells, parsed from "
                         "the paper text"},
    "EMBEDDED_J": {"class": "paper-defined",
                   "note": "the embedded Appendix J theorem map: per-claim "
                           "Badge and Checked-by cells, parsed from the "
                           "paper text"},
    "RANGE_DASH": {"class": "control",
                   "note": "dash characters accepted in script ranges (en "
                           "dash as written in E.2, plus hyphen and em dash "
                           "so a re-typing of the dash cannot silently "
                           "change the token set)"},
    "NORMALIZATION_RULES": {"class": "control",
                            "note": "checker-cell classifier: F.XX token "
                                    "extraction with range expansion; "
                                    "prose/inherited rows compared as "
                                    "section+paper attribution token sets; "
                                    "established by inspection of the three "
                                    "range renderings, the prose rows, and "
                                    "the inherited rows"},
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "theorem-map generator machinery; backs no claim.",
}

import re
import sys
import unicodedata
from pathlib import Path

import F38_claim_registry as _f38

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "paper_11.md"
MAP_OUT = HERE.parent / "appendix_j_theorem_map.md"
GENERATED_DATE = "2026-10-05"
EXPECTED_CLAIMS = 57

# Dash characters accepted in script ranges ("F.33–F.35"). E.2 writes the
# range with an en dash (U+2013). The accepted class is every Unicode dash
# punctuation (category Pd: hyphen-minus, the U+2010–U+2015 dashes,
# U+FE58, U+FE63, U+FF0D, ...) plus U+2212 MINUS SIGN, which autocorrect
# and IMEs emit in place of a hyphen and which is visually identical to
# it in most fonts. Any of them delimits a range; a re-typing of the
# dash therefore cannot silently change the token set (loop H1,
# 2026-10-04: the old three-dash class dropped range interiors when an
# autocorrect dash was used, e.g. F.33−F.35 -> {F.33, F.35}).
def _range_dash_class():
    chars = [c for c in map(chr, range(0x20, 0x10000))
             if unicodedata.category(c) == "Pd"]
    chars.append("−")  # U+2212 MINUS SIGN (category Sm, not Pd)
    return "[" + "".join("\\" + c if c in "\\-[]^" else c
                         for c in chars) + "]"
RANGE_DASH = _range_dash_class()

# Claim ID -> (stated section, proved section), recorded with the paper open.
# "Proved" names the paper section carrying the proof; for inherited claims
# it names the cited source instead (no paper-section check applies there).
RESOLUTIONS = {
    "RELATIONAL_ROLE_THEOREM": ("§3.1", "§3.1"),
    "CAPABILITY_ACTUALITY_SEPARATION": ("§3.1", "§3.1"),
    "ROLE_CUT_INDEPENDENCE": ("§4.2", "§4.2"),
    "PORT_COUNT_INVARIANCE": ("§4.3", "§4.3"),
    "COMPLEX_BOUNDARY_ACTIVE": ("§6.2", "§6.2"),
    # Registration of the §4.1 Structural Insulation Theorem (authorized
    # 2026-10-01): stated and proved in §4.1.
    "STRUCTURAL_INSULATION_THEOREM": ("§4.1", "§4.1"),
    "COMPOUND_CLOSED_LOOP_COHERENCE": ("§4.4", "§4.4"),
    "SIMPLE_STATE_INSULATION": ("§5.2", "§5.2"),
    "SIMPLE_STATE_REFERENCE_ROLE": ("§5.3", "§5.3"),
    "DUAL_RESPONSE_MODES": ("§6.3", "§6.3"),
    "ENGAGEMENT_ALTERATION_SEPARATION": ("§4.6", "§4.6"),
    # v50: the new encounter-geometry definition claim (L10-P11), stated
    # and proved in §3.2 alongside the R-tuple definition.
    "ENCOUNTER_GEOMETRY_DEFINITION": ("§3.2", "§3.2"),
    "RESOLUTION_VERB": ("§7.1", "§7.1"),
    "ALIGNMENT_DEFINITION": ("§7.2", "§7.2"),
    "SHOVE_DIRECTION": ("§7.2", "§7.2"),
    "TRACKING_COST_LEMMA": ("§7.3", "§7.3"),
    # 2026-10-05 (#128): author-authorized definitional lemma, stated and
    # established in §7.3 (no script proves it; F.33–F.35 implement/audit it).
    "ASPECT_AGGREGATION": ("§7.3", "§7.3"),
    "TENSION_RELIEF": ("§7.3", "§7.3"),
    "SHOVE_TRANSITION_OPERATOR": ("§7.5", "§7.5"),
    "TENSION_MEASURE_IDENTITY": ("§7.1", "§7.1"),
    # ChatGPT HIGH claim remediation (2026-10-04, staged): the
    # triple-convergence event, inherited from the four cited passages
    # (the electron/positron-X-dominant/Y-dominant naming is Paper 11's
    # native State-1 tilt usage, confirmed by the author's binding
    # identification (2026-10-04), not carried by the passages); stated
    # at §7.6, proved in the four cited passages (the "(inherited)"
    # suffix is the J-table convention for inherited rows).
    "TRIPLE_CONVERGENCE_RESOLUTION":
        ("§7.6", "Paper 2 §8.1; Paper 2 §11.1; Paper 3 §7; Paper 3 §8.5 (inherited)"),
    "INTERACTION_TAXONOMY": ("§8.1", "§8.6"),
    "SATURATION_FUSE": ("§8.6", "§8.6"),
    "ENCOUNTER_TENSION_ANALYSIS": ("§8.6", "§8.6"),
    "PROXIMITY_SCALING": ("§8.5", "§8.5"),
    "PROXIMITY_SHELL_PROFILE": ("§8.5", "§8.5"),
    "CASE_A_LADDER": ("§9", "§9"),
    "CONSUMPTION_CONSTRUCTION_ROBUSTNESS": ("§9.4", "§9.4"),
    "TH_INDEPENDENCE": ("§8.6", "§8.6"),
    "DOMAIN_GUARD_DISJUNCTION": ("§8.6", "§8.6"),
    "CROSS_NUCLEUS_ROBUSTNESS": ("§9.5", "§9.5"),
    "CASE_B_COLLIDER": ("§10", "§10"),
    "CASE_C_STRUCTURAL": ("§11", "§11"),
    "COMPLEXITY_ORDERING": ("§12.1", "§12.1"),
    "LITHIUM_SODIUM_ILLUSTRATION": ("§11.3", "§11.3"),
    "AGGREGATE_A_DECOMPOSITION": ("Appendix B.1", "Appendix B.1"),
    "AGGREGATE_B_DECOMPOSITION": ("Appendix B.2", "Appendix B.2"),
    "AGGREGATE_C_DECOMPOSITION": ("Appendix B.3", "Appendix B.3"),
    "BRIDGE_LEDGER_P11": ("§13", "§13"),
    "FALSIFICATION_C19": ("§14.3", "§14.3"),
    "FALSIFICATION_C20": ("§14.3", "§14.3"),
    "FALSIFICATION_C21": ("§14.3", "§14.3"),
    "FALSIFICATION_C22": ("§14.3", "§14.3"),
    "PHOTON_BASELINE": ("§3.2", "Paper 2 §5; Paper 10 §2.1 (inherited)"),
    "ROLE_PERMANENCE_PROHIBITION": ("§3.3", "§3.3"),
    "BOUNDARY_PORT_CHARACTERIZATION": ("§4.3", "§4.3"),
    "SIMPLE_STATE_ENUMERATION": ("§5.1", "§5.1"),
    "ASPECT_INVENTORY": ("§4.2", "§4.2"),
    "SINGLE_REGIME": ("§0.5.ab", "Paper 10 (inherited)"),
    # 2026-10-05 (#131): scale-fidelity claim, stated and proved at §0.5.v.3
    # (machine halves by F.56; the fidelity identification author-authorized).
    "SCALE_FIDELITY": ("§0.5.v.3", "§0.5.v.3"),
    "PATH_UPPER_BOUND": ("§11.2", "§11.2"),
    "MONOTONICITY_REFUTATION": ("§11.2", "§11.2"),
    "BOUNDARY_EXTENSION_INCLUSION": ("§11.2", "§11.2"),
    "NODE_ADDITION_FORMULA": ("§11.2", "§11.2"),
    "NODES_PORTS_NONMONOTONICITY": ("§11.2", "§11.2"),
    "BOUNDARY_EXTENSION_CAVEAT": ("§11.2", "§11.2"),
    "PORT_PARTITION_EXACTNESS": ("§4.3", "§4.3"),
}


def script_label(script, lineage, inherited_from, section):
    """Render the registry's script pointer in the paper's F.XX convention."""
    if isinstance(script, list):
        parts = []
        for s in script:
            m = re.match(r"F(\d+)_", s)
            if not m:
                raise ValueError("unparseable script name: %r" % s)
            parts.append("F.%s" % m.group(1))
        return " + ".join(parts)
    if script:
        m = re.match(r"F(\d+)_", script)
        if not m:
            raise ValueError("unparseable script name: %r" % script)
        return "F.%s" % m.group(1)
    if lineage == "inherited":
        return "inherited (%s) — no Paper-11 script" % inherited_from
    return "prose (%s) — no machine check" % section


def section_exists(heading_lines, token):
    """True iff token names a real paper heading. None for non-paper
    tokens (inherited citations), which are not checked."""
    if token.startswith("§"):
        pat = re.compile(r"^#{2,4}\s+.*" + re.escape(token) + r"(?![\d.])")
    elif token.startswith("Appendix"):
        sub = token.split(" ", 1)[1]
        pat = re.compile(r"^#{2,4}\s+.*" + r"\b" + re.escape(sub) + r"\b")
    else:
        return None
    return any(pat.search(l) for l in heading_lines)


def table_text(text):
    """Verbatim claim text, table-safe: escape literal pipes."""
    if "\n" in text:
        raise ValueError("claim text contains a newline")
    return text.replace("|", "\\|")


def build_rows(registry, resolutions, heading_lines):
    rows = []
    for entry in registry:
        cid = entry["id"]
        res = resolutions.get(cid)
        if res is None:
            stated = proved = "UNRESOLVED"
        else:
            stated, proved = res
            for tok in (stated, proved):
                found = section_exists(heading_lines, tok)
                if found is False:
                    stated = proved = "UNRESOLVED"
                    break
        checked = script_label(entry.get("script"), entry.get("lineage"),
                               entry.get("inherited_from", "?"),
                               entry.get("section", "—"))
        rows.append((cid, entry["level"], stated, proved, checked,
                     table_text(entry["text"])))
    return rows


def generate():
    paper_lines = PAPER.read_text(encoding="utf-8").split("\n")
    heading_lines = [l for l in paper_lines if re.match(r"^#{2,4}\s", l)]
    registry = _f38.REGISTRY
    if len(registry) != EXPECTED_CLAIMS:
        raise ValueError("registry has %d claims, expected %d"
                         % (len(registry), EXPECTED_CLAIMS))
    rows = build_rows(registry, RESOLUTIONS, heading_lines)
    out = []
    out.append("## APPENDIX J — THEOREM MAP (GENERATED)")
    out.append("")
    out.append("**Honesty header.** This appendix is generated from the F.38 "
               "claim registry (57 claims) on %s by "
               "`scripts/F52_theorem_map.py`. It is a map, not a restatement: "
               "each row gives the registry ID, the badge level, where the "
               "claim is stated, where it is proved, and which script checks "
               "it, alongside the claim text as registered — the paper's own "
               "sentences, pointed at, never rephrased. The Stated/Proved "
               "addresses are recorded by hand with the paper open; the "
               "machine checks only that each address names a real paper "
               "heading, never that the claim is actually stated or proved "
               "there — a wrong-but-existing address passes every check by "
               "design. If this map and the paper disagree, the paper "
               "governs. Re-running the generator "
               "on the same inputs reproduces this text byte-for-byte "
               "(literal pipes in claim texts are escaped as `\\|` for table "
               "safety); running the generator without arguments verifies "
               "the reproduction against the embedded copy."
               % GENERATED_DATE)
    out.append("")
    out.append("| ID | Badge | Stated | Proved | Checked by | Claim (registry text) |")
    out.append("|---|---|---|---|---|---|")
    for (cid, level, stated, proved, checked, text) in rows:
        out.append("| %s | %s | %s | %s | %s | %s |"
                   % (cid, level, stated, proved, checked, text))
    return "\n".join(out)


def extract_embedded(paper_text):
    """Return the paper's embedded Appendix J block (without trailing blank)."""
    lines = paper_text.split("\n")
    try:
        start = next(i for i, l in enumerate(lines)
                     if l.startswith("## APPENDIX J"))
    except StopIteration:
        raise CheckerDriftRejected(
            "Appendix J heading not found in the paper")
    end = next((i for i in range(start + 1, len(lines))
                if re.match(r"^## ", lines[i])), len(lines))
    block = lines[start:end]
    while block and block[-1] == "":
        block.pop()
    return "\n".join(block)


class CheckerDriftRejected(Exception):
    """Raised when E.2<->Appendix-J checker-column drift is detected."""

    def __init__(self, witness):
        super().__init__(witness)
        self.witness = witness


def parse_e2_attributions(md_text):
    """Parse the E.2 claim table; return {id: (level, script_cell)}.

    Deliberately an independent parser from F.51's (independent gates):
    F.51's parser is text-oriented (ID -> Text cell); this one is
    attribution-oriented (ID -> (Level, Script)). Table-safety
    discipline: the table is located by its header row; each row is
    split with maxsplit=7 so the 8th (Text) column keeps its literal
    "|" characters (two live rows use them as math notation); rows with
    the wrong column count or duplicate IDs are rejected loudly.
    No pipe-guard on the early columns is attempted, and none is
    claimed: Text legitimately contains pipes, so no syntactic test on
    the parsed cells can distinguish an intruding pipe from a Text
    pipe. The safety is downstream instead: an asymmetric pipe
    corruption (one table only) fails loudly, because the truncated
    cell no longer agrees with the other table (battery-demonstrated).
    Only a byte-identical corruption of both tables would pass
    silently, and there is no realistic path to that — Appendix J is
    machine-generated from the registry, not hand-typed.
    """
    rows = {}
    in_table = False
    for lineno, line in enumerate(md_text.splitlines(), 1):
        if line.startswith("| ID | Level |"):
            in_table = True
            continue
        if not in_table:
            continue
        if line.startswith("|---"):
            continue
        if not line.startswith("|"):
            break
        body = line.strip()
        if not (body.startswith("|") and body.endswith("|")):
            raise CheckerDriftRejected(
                "E.2 line %d: not a well-formed table row" % lineno)
        cells = [c.strip() for c in body[1:-1].split("|", 7)]
        if len(cells) != 8:
            raise CheckerDriftRejected(
                "E.2 line %d: expected 8 columns, got %d"
                % (lineno, len(cells)))
        rid = cells[0]
        if rid in rows:
            raise CheckerDriftRejected("E.2 duplicate ID: %r" % rid)
        rows[rid] = (cells[1], cells[6])  # Level, Script
    if not rows:
        raise CheckerDriftRejected("E.2 table not found in the paper")
    return rows


def parse_j_attributions(paper_text):
    """Parse the embedded Appendix J; return {id: (badge, checked_by)}.

    Claim text is the last of 6 columns, so maxsplit=5 keeps it intact
    (literal pipes there are backslash-escaped by the generator); a row
    with the wrong column count or a repeated ID is rejected loudly.
    """
    block = extract_embedded(paper_text)
    rows = {}
    in_table = False
    for lineno, line in enumerate(block.split("\n"), 1):
        if line.startswith("| ID | Badge |"):
            in_table = True
            continue
        if not in_table:
            continue
        if line.startswith("|---"):
            continue
        if not line.startswith("|"):
            break
        cells = [c.strip() for c in line.strip()[1:-1].split("|", 5)]
        if len(cells) != 6:
            raise CheckerDriftRejected(
                "Appendix J line %d: expected 6 columns, got %d"
                % (lineno, len(cells)))
        rid = cells[0]
        if rid in rows:
            raise CheckerDriftRejected("Appendix J duplicate ID: %r" % rid)
        rows[rid] = (cells[1], cells[4])  # Badge, Checked by
    if not rows:
        raise CheckerDriftRejected("Appendix J table not found in the paper")
    return rows


def expand_script_tokens(cell):
    """Script-token set of a checker cell, with range expansion.

    "F.33–F.35 + F.39" -> {"F.33", "F.34", "F.35", "F.39"}: E.2's
    deliberate range notation and J's expanded rendering are the same
    set, not drift. The expansion is general -- it applies to any
    claim's cell, never to a named claim ID.
    """
    toks = set()
    # Full form "F.33–F.35" and abbreviated form "F.33–35" (loop H2):
    # in a checker cell the bare number can only continue the F. series,
    # so the abbreviated form is unambiguous. The old code expanded only
    # the full form and silently dropped the interior tokens of the
    # abbreviated one (F.33–35 -> {F.33}).
    for m in re.finditer(
            r"F\.(\d+)\s*" + RANGE_DASH + r"\s*(?:F\.(\d+)|(\d+))",
            cell):
        lo = int(m.group(1))
        hi = int(m.group(2) if m.group(2) is not None else m.group(3))
        if lo > hi:
            raise CheckerDriftRejected(
                "inverted script range in cell %r" % cell)
        toks.update("F.%d" % n for n in range(lo, hi + 1))
    rest = re.sub(
        r"F\.\d+\s*" + RANGE_DASH + r"\s*(?:F\.\d+|\d+)", " ", cell)
    toks.update("F." + n for n in re.findall(r"F\.(\d+)", rest))
    return toks


def attribution_tokens(cell):
    """Section/paper tokens of a checker cell, spelling-normalized.

    Recognized section spellings: §, "section(s)", "sec(s)." — all
    normalized to §N, so "prose §11.3" and "prose (see section 9.9)"
    tokenize the same attribution and a real attribution drift is caught
    (loop H4: the old tokenizer recognized only § and "Paper", so a
    smuggled "section 9.9" attribution was invisible). "Paper N" is
    case-insensitive and normalized to lowercase. Spellings outside this
    set remain invisible to the tokenizer — human-audit territory,
    disclosed, not claimed.
    """
    norm = re.sub(r"(?i)\bsections?\b\s*|\bsecs?\b\.?\s*", "§", cell)
    secs = set(re.findall(r"§\d+(?:\.\d+)*(?:\.[a-z]+)?", norm))
    papers = set("paper " + m.group(1)
                 for m in re.finditer(r"(?i)\bpaper\s+(\d+(?:\.\d+)?)",
                                      cell))
    return secs | papers


def classify_checker_cell(cell):
    """(kind, script_toks, attr_toks) for a checker cell.

    kind is "script" (F.XX tokens present, no leading prose/inherited
    marker), "prose" (leading "prose" marker), or "inherited"
    (leading "inh."/"inherited" marker). A cell with a leading
    prose/inherited marker that also carries script tokens raises
    loudly: silent reclassification would mask exactly the kind-flip
    drift class this gate exists to catch (a prose cell mentioning a
    script token must not flip to "script"). Section/paper
    attribution tokens are compared in every kind: a script cell
    whose embedded prose attribution drifts is drift too. Anything
    else raises: an unclassifiable checker cell is not agreement, it
    is a loud failure.
    """
    stripped = cell.strip()
    script_toks = expand_script_tokens(cell)
    lead_prose = re.match(r"prose\b", stripped, re.IGNORECASE) is not None
    lead_inh = re.match(r"(inh\.|inherited\b)", stripped,
                        re.IGNORECASE) is not None
    # Mixed-cell rule (loop H5): a prose/inherited marker word ANYWHERE
    # in the cell alongside script tokens raises loudly. The old
    # leading-only rule let a trailing marker slip through: "F.39 — prose"
    # classified as script {F.39} and agreed with a bare "F.39" silently.
    marker_anywhere = (
        re.search(r"(?i)\bprose\b", stripped) is not None
        or re.search(r"(?i)\binh\.|\binherited\b", stripped) is not None)
    if script_toks and marker_anywhere:
        raise CheckerDriftRejected(
            "mixed script+prose/inherited checker cell: %r" % cell)
    if lead_prose or lead_inh:
        kind = "prose" if lead_prose else "inherited"
    elif script_toks:
        kind = "script"
    else:
        raise CheckerDriftRejected(
            "unclassifiable checker cell: %r" % cell)
    return kind, script_toks, attribution_tokens(cell)


def checker_columns_agree(e2, jmap):
    """Compare E.2 {id: (level, script)} against J {id: (badge, checked)}.

    Returns a list of witness strings; empty means agreement. ID sets
    must match in both directions; per claim the Level/Badge tokens
    must be equal; the checker cells must classify to the same kind
    with equal token sets (script tokens after range expansion;
    prose/inherited section+paper attribution tokens).
    """
    failures = []
    for rid in e2:
        if rid not in jmap:
            failures.append(
                "checker drift: E.2 ID %r missing from Appendix J" % rid)
    for rid in jmap:
        if rid not in e2:
            failures.append(
                "checker drift: Appendix J ID %r missing from E.2" % rid)
    for rid in sorted(set(e2) & set(jmap)):
        level, script_cell = e2[rid]
        badge, checked_cell = jmap[rid]
        if level != badge:
            failures.append(
                "checker drift: Level/Badge mismatch on %r (E.2 %r vs "
                "J %r)" % (rid, level, badge))
        try:
            kind_e, ftoks_e, atoks_e = classify_checker_cell(script_cell)
            kind_j, ftoks_j, atoks_j = classify_checker_cell(checked_cell)
        except CheckerDriftRejected as exc:
            failures.append("checker drift: %s (on %r)" % (exc, rid))
            continue
        if kind_e != kind_j:
            failures.append(
                "checker drift: checker-kind mismatch on %r (E.2 %r vs "
                "J %r)" % (rid, kind_e, kind_j))
        elif ftoks_e != ftoks_j or atoks_e != atoks_j:
            failures.append(
                "checker drift: checker-token mismatch on %r (E.2 %s %s "
                "vs J %s %s)" % (rid, kind_e, sorted(ftoks_e | atoks_e),
                                 kind_j, sorted(ftoks_j | atoks_j)))
    return failures


def planted_checker_drift_battery(e2, jmap):
    """Prove the checker-column sweep can fail: eleven synthetic drifts,
    one per covered column/shape, each rejected with a witness naming
    the ID. Controls: the unmutated pair passes -- the three deliberate
    range renderings, every prose row, and both inherited rows agree.

    Returns the number of battery cases (so the PASS line cannot go
    stale when the battery grows).
    """
    clean = checker_columns_agree(e2, jmap)
    assert not clean, \
        "battery setup: live E.2<->J pair already drifts: %r" % (clean,)
    victim = "RELATIONAL_ROLE_THEOREM"
    rejected = []

    def expect_reject(mut_e2, mut_j, frag, mid):
        fails = checker_columns_agree(mut_e2, mut_j)
        assert any(frag in f and mid in f for f in fails), \
            "battery FAILED (%s): drift not rejected: %r" % (mid, fails)
        rejected.append(mid)

    # 1. ID missing from J.
    j1 = dict(jmap)
    del j1[victim]
    expect_reject(e2, j1, "missing from Appendix J", victim)
    # 2. Level/Badge mismatch.
    j2 = dict(jmap)
    _lv, ck = j2[victim]
    j2[victim] = ("B", ck)
    expect_reject(e2, j2, "Level/Badge mismatch", victim)
    # 3. Checker-kind flip: the stale pre-#111 shape -- "Checked by
    #    F.37" against E.2's "prose §11.3".
    j3 = dict(jmap)
    lv3, _ck3 = j3["LITHIUM_SODIUM_ILLUSTRATION"]
    j3["LITHIUM_SODIUM_ILLUSTRATION"] = (lv3, "Checked by F.37")
    expect_reject(e2, j3, "checker-kind mismatch",
                  "LITHIUM_SODIUM_ILLUSTRATION")
    # 4. Token drop inside an expanded list (E.2's range side intact).
    j4 = dict(jmap)
    lv4, _ck4 = j4["COMPLEX_BOUNDARY_ACTIVE"]
    j4["COMPLEX_BOUNDARY_ACTIVE"] = (lv4, "F.33 + F.35 + F.39")
    expect_reject(e2, j4, "checker-token mismatch",
                  "COMPLEX_BOUNDARY_ACTIVE")
    # 5. Prose section-attribution drift.
    j5 = dict(jmap)
    lv5, _ck5 = j5["LITHIUM_SODIUM_ILLUSTRATION"]
    j5["LITHIUM_SODIUM_ILLUSTRATION"] = (
        lv5, "prose (§9.8) — no machine check")
    expect_reject(e2, j5, "checker-token mismatch",
                  "LITHIUM_SODIUM_ILLUSTRATION")
    # 6. Script cell whose embedded prose attribution drifts: the
    #    mixed-cell rule now fires before any comparison (a prose
    #    marker anywhere in a script cell raises loudly), so this
    #    drift is rejected by the louder path.
    e6 = dict(e2)
    lv6, _ck6 = e6[victim]
    e6[victim] = (lv6, "F.39 + prose §3.1")
    j6 = dict(jmap)
    _lv6b, _ck6b = j6[victim]
    j6[victim] = (_lv6b, "F.39 + prose §9.8")
    expect_reject(e6, j6, "mixed script+prose", victim)
    # 7. Prose cell mentioning a script token: must raise loudly as a
    #    mixed cell, never silently flip to "script" (that flip would
    #    mask exactly the kind-flip drift this gate exists to catch).
    e7 = dict(e2)
    lv7, _ck7 = e7["LITHIUM_SODIUM_ILLUSTRATION"]
    e7["LITHIUM_SODIUM_ILLUSTRATION"] = (
        lv7, "prose §11.3 (cf. F.37)")
    expect_reject(e7, jmap, "mixed script+prose",
                  "LITHIUM_SODIUM_ILLUSTRATION")
    # 8. Dash-variant range drift (loop H1): E.2's range re-typed with
    #    U+2212 MINUS SIGN (what autocorrect emits) while J drops F.34.
    #    The widened dash class expands the range, so the dropped token
    #    is caught; the old three-dash class passed this silently.
    e8 = dict(e2)
    lv8, _ck8 = e8["COMPLEX_BOUNDARY_ACTIVE"]
    e8["COMPLEX_BOUNDARY_ACTIVE"] = (lv8, "F.33−F.35 + F.39")
    j8 = dict(jmap)
    lv8j, _ck8j = j8["COMPLEX_BOUNDARY_ACTIVE"]
    j8["COMPLEX_BOUNDARY_ACTIVE"] = (lv8j, "F.33 + F.35 + F.39")
    expect_reject(e8, j8, "checker-token mismatch",
                  "COMPLEX_BOUNDARY_ACTIVE")
    # 9. Abbreviated-range drift (loop H2): "F.33–35" expands to the
    #    full set, so J's dropped F.34 is caught; the old code read the
    #    abbreviated form as {F.33, F.35, F.39} and passed silently.
    e9 = dict(e2)
    lv9, _ck9 = e9["COMPLEX_BOUNDARY_ACTIVE"]
    e9["COMPLEX_BOUNDARY_ACTIVE"] = (lv9, "F.33–35 + F.39")
    j9 = dict(jmap)
    lv9j, _ck9j = j9["COMPLEX_BOUNDARY_ACTIVE"]
    j9["COMPLEX_BOUNDARY_ACTIVE"] = (lv9j, "F.33 + F.35 + F.39")
    expect_reject(e9, j9, "checker-token mismatch",
                  "COMPLEX_BOUNDARY_ACTIVE")
    # 10. Trailing prose marker (loop H5): "F.39 — prose" must raise as
    #     a mixed cell; the old leading-only rule classified it as
    #     script {F.39} and agreed with a bare "F.39" silently.
    e10 = dict(e2)
    lv10, _ck10 = e10[victim]
    e10[victim] = (lv10, "F.39 — prose")
    j10 = dict(jmap)
    lv10j, _ck10j = j10[victim]
    j10[victim] = (lv10j, "F.39")
    expect_reject(e10, j10, "mixed script+prose", victim)
    # 11. Section-spelling attribution drift (loop H4): a smuggled
    #     "section 9.9" is now tokenized, so the drift is caught; the
    #     old §-only tokenizer let it pass silently.
    j11 = dict(jmap)
    lv11, _ck11 = j11["LITHIUM_SODIUM_ILLUSTRATION"]
    j11["LITHIUM_SODIUM_ILLUSTRATION"] = (
        lv11, "prose §11.3 (see section 9.9) — no machine check")
    expect_reject(e2, j11, "checker-token mismatch",
                  "LITHIUM_SODIUM_ILLUSTRATION")

    print("WITNESS planted_checker_drift_battery: %d synthetic drifts "
          "(ID missing from J, Level/Badge mismatch, stale 'Checked by "
          "F.37' kind flip, dropped F.34 token, prose section-attribution "
          "drift, script-cell prose-attribution drift (mixed-cell path), "
          "leading mixed "
          "cell, U+2212 dash-variant range drift, abbreviated-range "
          "drift, trailing-marker mixed cell, section-spelling "
          "attribution drift); each rejected with a witness naming the "
          "ID. Controls: unmutated E.2<->J pair agrees -- the 3 "
          "deliberate range renderings, all prose rows, and both "
          "inherited rows pass." % len(rejected))
    return len(rejected)


def planted_self_test():
    """Prove the safety machinery can fail: a phantom section is not found,
    and a claim missing from RESOLUTIONS is emitted UNRESOLVED."""
    paper_lines = PAPER.read_text(encoding="utf-8").split("\n")
    heading_lines = [l for l in paper_lines if re.match(r"^#{2,4}\s", l)]
    if section_exists(heading_lines, "§99.9") is not False:
        raise AssertionError("section check failed to reject phantom §99.9")
    fake_res = {k: v for k, v in RESOLUTIONS.items()
                if k != "RELATIONAL_ROLE_THEOREM"}
    rows = build_rows(_f38.REGISTRY, fake_res, heading_lines)
    row = next(r for r in rows if r[0] == "RELATIONAL_ROLE_THEOREM")
    if row[2] != "UNRESOLVED" or row[3] != "UNRESOLVED":
        raise AssertionError("UNRESOLVED path did not fire")
    print("F.52 planted self-test PASS: phantom section rejected, "
          "missing resolution -> UNRESOLVED.")


def main():
    if "--emit" in sys.argv:
        MAP_OUT.write_text(generate() + "\n", encoding="utf-8")
        print("emitted %s" % MAP_OUT)
        return
    paper_text = PAPER.read_text(encoding="utf-8")
    generated = generate()
    embedded = extract_embedded(paper_text)
    if embedded != generated:
        for i, (a, b) in enumerate(zip(embedded.split("\n"),
                                       generated.split("\n"))):
            if a != b:
                raise SystemExit(
                    "F.52 FAIL: embedded Appendix J differs from generated "
                    "output at line %d:\n  embedded:  %r\n  generated: %r"
                    % (i + 1, a[:120], b[:120]))
        raise SystemExit(
            "F.52 FAIL: embedded Appendix J differs from generated output "
            "(length mismatch: %d vs %d lines)"
            % (len(embedded.split("\n")), len(generated.split("\n"))))
    # V9 remediation: the E.2<->J checker-column agreement gate. E.2 is
    # the canonical claim table; Appendix J is the generated map. Their
    # shared attribution columns (ID, Level/Badge, Script/Checked-by)
    # must agree on all 57 claims; any drift fails loudly with a
    # witness naming the ID.
    e2 = parse_e2_attributions(paper_text)
    jmap = parse_j_attributions(paper_text)
    if len(e2) != EXPECTED_CLAIMS:
        raise SystemExit(
            "F.52 FAIL: E.2 holds %d claims, expected %d"
            % (len(e2), EXPECTED_CLAIMS))
    if len(jmap) != EXPECTED_CLAIMS:
        raise SystemExit(
            "F.52 FAIL: Appendix J holds %d claims, expected %d"
            % (len(jmap), EXPECTED_CLAIMS))
    failures = checker_columns_agree(e2, jmap)
    if failures:
        raise SystemExit(
            "F.52 FAIL: E.2<->Appendix-J checker drift: %s"
            % ("; ".join(failures),))
    n_battery = planted_checker_drift_battery(e2, jmap)
    assert n_battery > 0
    planted_self_test()
    n_unresolved = sum(1 for l in generated.split("\n")
                       if "| UNRESOLVED |" in l)
    print("F.52 PASS: embedded Appendix J byte-identical to generated output; "
          "%d/%d claims resolved (%d UNRESOLVED); E.2<->J checker columns "
          "agree on %d/%d claims (ID, Level/Badge, Script/Checked-by); "
          "%d/%d planted checker drifts rejected."
          % (EXPECTED_CLAIMS, EXPECTED_CLAIMS, n_unresolved,
             EXPECTED_CLAIMS, EXPECTED_CLAIMS, n_battery, n_battery))


if __name__ == "__main__":
    main()
