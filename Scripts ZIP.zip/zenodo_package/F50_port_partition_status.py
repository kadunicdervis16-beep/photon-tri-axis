#!/usr/bin/env python3
"""Paper 11 - F.50: port-partition-half status gate (C22 combining check).

F.33-F.35 each machine-check the port-partition half of the
compound-closed-loop formalization over one worked aggregate: check-2
input validation (junction port lists pairwise disjoint, arity
cross-check, port-index and node-id bounds), check-6 port invariants
(|dG| = 6N - sum(k_j) dual-computed, consumed/boundary disjoint and
exhaustive), and the per-aspect decomposition identity (checks 1, 3, 4,
5, 7). The prose rule -- falsification condition C22 (§14.3 condition
22) -- states the consequence the three scripts never assert on their
own: if the decomposition verification of ANY ONE of the worked
aggregates fails, the port-partition half's Level-A badge support is
VOID.

This script machine-reports that rule: it runs each construction's own
verify_decomposition on that script's own fixtures (imported, never
hand-copied), reports per-aggregate PASS/FAIL, and computes
PORT_PARTITION_HALF_STATUS = SUPPORTED iff every construction passes,
else VOID. No downstream consumer acts on the verdict -- the script
reports it; wiring the registry build to fail on VOID is a design
change, not authorized. Both directions of the rule are asserted: the
clean run must yield SUPPORTED, and a planted mutant -- aggregate (c)'s
junction table perturbed so port (c1, 0) is listed in both junctions,
the C22 trigger condition of a double-counted port (the paper's own
designated stress case, cf. F.35's mutant_3 witness fixture) -- must
yield VOID with a printed witness citing FALSIFICATION_C22. The mutant
run keeps the other three constructions clean, proving the VOID follows
from the single (c) failure: the any-single-aggregate rule is
load-bearing, not a restatement of the inputs.

C22's second disjunct (the symbolic ledger identity broken) is
input-unreachable, and probe_ledger_identity_input_domain() says so
mechanically. The identity (enumeration vs arithmetic audit) is a
theorem over the check-2/check-6-passing input domain: F.35's sweep
proves it over all 10^3 state-row assignments, and checks 1/3/4/5/7 are
algebraic identities given the shared (triples, junctions) input (the
emitter and the audit read the same rows; the tally and the audit read
the same port lists). The probe confirms the contrapositive over a
structural perturbation battery of aggregate (c): every perturbed input
either passes verify_decomposition outright or fails at the
port-partition checks (check-2/check-6) -- never at a ledger-identity
check. The ledger half is therefore guarded at the ledger level, by
F.35's own 9-mutant battery (mutant_0/1/4/8 break the ledger
computation, not the input). The combining rule itself is
failure-mode-agnostic: any CheckRejected or AssertionError from any
check maps to FAIL and hence to VOID.

No registry claim is badged on this gate: it reports the badge-voiding
verdict of the existing Level-A claim FALSIFICATION_C22, whose script
pointer names this script alongside F.33-F.35.
"""

# Module-level bindings and their provenance classes. The construction
# tables are imported from the scripts that verify them (their
# INPUT_PROVENANCE blocks declare the fixtures); the planted-mutant
# junction table and the probe's perturbation tables are built inside
# functions, never at module level. The witness-classification tag
# tuples below are control bindings: they name F.35's own check-witness
# strings so the probe can classify failures by originating check.
INPUT_PROVENANCE = {
    "_PORT_PARTITION_TAGS": {
        "class": "control",
        "note": "witness-classification tags naming F.35 check-2/check-6 "
                "witness strings for the input-domain probe",
    },
    "_LEDGER_TAGS": {
        "class": "control",
        "note": "witness-classification tags naming F.35 checks 1/3/4/5/7 "
                "witness strings for the input-domain probe",
    },
}
# R23 domain declaration (2026-10-05): aspect kinds this script's
# checks exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": ['port', 'junction', 'node'],
    "notes": "runs the F.33-F.35 per-aspect decomposition checks via imported fixtures.",
}

import F33_aggregate_a as _f33
import F34_aggregate_b as _f34
import F35_aggregate_c as _f35


def _constructions():
    """(label, module, triples, junctions) for every worked construction."""
    return [
        ("aggregate-(a)", _f33, _f33.AGG_A_TRIPLES, _f33.AGG_A_JUNCTIONS),
        ("aggregate-(b)/branch-A", _f34, _f34.AGG_B_A_TRIPLES,
         _f34.AGG_B_A_JUNCTION),
        ("aggregate-(b)/branch-B", _f34, _f34.AGG_B_B_TRIPLES,
         _f34.AGG_B_B_JUNCTION),
        ("aggregate-(c)", _f35, _f35.AGG_C_FIXTURE_TRIPLES,
         _f35.AGG_C_JUNCTIONS),
    ]


def _run_one(label, mod, triples, junctions):
    """Run one construction's decomposition verification.

    Returns (verdict, witness): verdict is PASS when the script's own
    verify_decomposition returns cleanly, FAIL when it raises the
    script's CheckRejected (check-2/check-6) or an AssertionError
    (checks 1, 3, 4, 5, 7). The Aggregate constructor copies the
    junction tables, so module fixtures are never aliased.
    """
    agg = mod.Aggregate(label, triples, junctions)
    try:
        mod.verify_decomposition(agg, label)
    except (mod.CheckRejected, AssertionError) as e:
        witness = getattr(e, "witness", str(e))
        return ("FAIL", "%s: %s" % (type(e).__name__, witness))
    return ("PASS", None)


def port_partition_half_status(constructions):
    """Combine per-construction results into the C22 status.

    Runs every construction's decomposition verification and returns
    (status, results): status is SUPPORTED iff every construction
    passes, else VOID. The status is computed from the verification
    outcomes, never stipulated.
    """
    results = []
    for label, mod, triples, junctions in constructions:
        verdict, witness = _run_one(label, mod, triples, junctions)
        results.append((label, verdict, witness))
        if witness is not None:
            print("F.50 [%s]: FAIL -- %s" % (label, witness))
        else:
            print("F.50 [%s]: PASS" % label)
    failed = [label for label, verdict, _ in results if verdict == "FAIL"]
    status = "VOID" if failed else "SUPPORTED"
    return status, results


def mutant_double_count_c():
    """Planted mutant: the C22 trigger condition on aggregate (c).

    Perturbs (c)'s junction table so port (c1, 0) is listed in BOTH
    junctions -- a genuine double-counted port, the exact trigger
    condition falsification condition C22 names. The combining check
    must report VOID with a printed witness citing FALSIFICATION_C22,
    while the other three constructions still pass (the VOID follows
    from the single (c) failure alone).
    """
    perturbed_c = {
        "j0": {"ports": [("c0", 0), ("c1", 0)], "arity": 2},
        "j1": {"ports": [("c1", 0), ("c2", 0)], "arity": 2},
    }
    constructions = [
        (label, mod, triples,
         perturbed_c if label == "aggregate-(c)" else junctions)
        for label, mod, triples, junctions in _constructions()
    ]
    status, results = port_partition_half_status(constructions)
    by_label = {label: (verdict, witness)
                for label, verdict, witness in results}
    assert status == "VOID", \
        "mutant: expected VOID, got %s" % status
    assert by_label["aggregate-(c)"][0] == "FAIL", \
        "mutant: perturbed aggregate (c) must FAIL"
    assert all(by_label[l][0] == "PASS"
               for l in by_label if l != "aggregate-(c)"), \
        "mutant: the other constructions must still pass, else the VOID " \
        "is not attributable to the single (c) failure"
    print("WITNESS mutant_double_count_c: perturbed (c) junction table "
          "(port ('c1', 0) listed in j0 and j1) -> "
          "PORT_PARTITION_HALF_STATUS = VOID per FALSIFICATION_C22 "
          "(any single aggregate failure voids the port-partition half's "
          "Level-A badge support); check-2 witness: %s"
          % by_label["aggregate-(c)"][1])
    return True


# Witness-classification tags for the input-domain probe. Port-partition
# tags name check-2 (input validation) and check-6 (port invariants);
# ledger tags name checks 1/3/4/5/7 (the decomposition identity). The
# tags are F.35's own witness strings, matched case-insensitively.
_PORT_PARTITION_TAGS = (
    "arity declaration", "listed in two junctions", "unknown node",
    "outside 0..5", "outside node port range", "arity",
    "|dg|=", "consumed intersect", "consumed union", "dual computation",
)
_LEDGER_TAGS = (
    "aspect coverage", "audit shape", "carries non-zero", "symbol hygiene",
    "tautology", "fiat", "not aspect-covering", "duplicate aspect",
)


def _probe_perturbations():
    """(name, triples, junctions) battery for the input-domain probe.

    Row-value reassignments sample the dimension F.35's own sweep covers
    exhaustively (all 10^3 state-row assignments); the structural
    perturbations (node set, arity, port lists) cover the dimension the
    sweep fixes. All tables are built inside this function from F.35's
    imported fixture -- no hand-copied inputs.
    """
    base_t = dict(_f35.AGG_C_FIXTURE_TRIPLES)
    base_j = {j: {"ports": list(d["ports"]), "arity": d["arity"]}
              for j, d in _f35.AGG_C_JUNCTIONS.items()}
    out = []
    for node, row in [("c0", "9"), ("c1", "1e"), ("c2", "7")]:
        t = dict(base_t)
        t[node] = row
        out.append(("row-%s-%s" % (node, row), t, base_j))
    t = dict(base_t)
    del t["c2"]
    out.append(("drop-node-c2", t, base_j))
    t = dict(base_t)
    t["c3"] = "4"
    out.append(("add-node-c3", t, base_j))
    for jn, ar in [("j0", 1), ("j0", 3), ("j1", 1), ("j1", 3)]:
        jj = {j: {"ports": list(d["ports"]),
                  "arity": ar if j == jn else d["arity"]}
              for j, d in base_j.items()}
        out.append(("arity-%s-%d" % (jn, ar), dict(base_t), jj))
    jj = {"j0": {"ports": [("c0", 0), ("c1", 0)], "arity": 2},
          "j1": {"ports": [("c1", 0), ("c2", 0)], "arity": 2}}
    out.append(("double-count-(c1,0)", dict(base_t), jj))
    jj = {"j0": {"ports": [("c0", 0), ("c9", 0)], "arity": 2},
          "j1": {"ports": [("c1", 5), ("c2", 0)], "arity": 2}}
    out.append(("unknown-node-c9", dict(base_t), jj))
    jj = {"j0": {"ports": [("c0", 0), ("c1", 9)], "arity": 2},
          "j1": {"ports": [("c1", 5), ("c2", 0)], "arity": 2}}
    out.append(("port-index-9", dict(base_t), jj))
    out.append(("no-junctions", dict(base_t), {}))
    return out


def _classify_witness(witness):
    """Classify a check witness as a port-partition-check or a
    ledger-identity-check failure. Ledger tags are checked first so a
    witness naming both (should one ever exist) counts as ledger."""
    wl = witness.lower()
    if any(tag in wl for tag in _LEDGER_TAGS):
        return "ledger-identity"
    if any(tag in wl for tag in _PORT_PARTITION_TAGS):
        return "port-partition"
    return "unclassified"


def probe_ledger_identity_input_domain():
    """Mechanical confirmation: C22's ledger-identity disjunct is
    input-unreachable.

    Runs the structural perturbation battery of aggregate (c) through
    F.35's verify_decomposition and classifies every outcome: PASS, or a
    FAIL at a port-partition check (check-2/check-6). The probe asserts
    that NO perturbation fails at a ledger-identity check (1/3/4/5/7).
    Non-vacuity is asserted both ways: at least one perturbation passes
    (valid inputs exist) and at least one fails at a port-partition
    check (the battery can fail).

    This is the honest form of the requested "second-disjunct mutant": a
    mutant that breaks the symbolic ledger identity while passing
    check-2 cannot exist -- the identity is a theorem over the
    check-2/check-6-passing input domain (F.35's 10^3-assignment sweep
    plus the algebraic identity of the two audit routes over shared
    input). The ledger half is guarded at the ledger level by F.35's own
    9-mutant battery instead.
    """
    seen_pass = False
    seen_port_partition_fail = False
    n = 0
    for name, triples, junctions in _probe_perturbations():
        n += 1
        agg = _f35.Aggregate("aggregate-(c)/probe-" + name,
                             triples, junctions)
        try:
            _f35.verify_decomposition(agg, "probe-" + name)
            seen_pass = True
            print("F.50 probe [%s]: PASS (valid input)" % name)
        except (_f35.CheckRejected, AssertionError) as e:
            witness = getattr(e, "witness", str(e))
            cls = _classify_witness(witness)
            print("F.50 probe [%s]: FAIL@%s -- %s"
                  % (name, cls, witness[:110]))
            assert cls == "port-partition", \
                "probe: perturbation %r failed at a ledger-identity " \
                "check (witness: %s) -- the input-unreachability claim " \
                "is FALSE" % (name, witness)
            seen_port_partition_fail = True
    assert seen_pass, "probe battery vacuous: no perturbation passed"
    assert seen_port_partition_fail, \
        "probe battery vacuous: no perturbation failed at a " \
        "port-partition check"
    print("WITNESS probe_ledger_identity_input_domain: %d perturbations "
          "of aggregate (c); every outcome is PASS or a port-partition "
          "check (check-2/check-6) failure -- zero ledger-identity-check "
          "failures. C22's second disjunct is input-unreachable; the "
          "ledger half is guarded by F.35's own ledger-level mutant "
          "battery." % n)
    return True


def main():
    status, results = port_partition_half_status(_constructions())
    print("F.50 combining rule (FALSIFICATION_C22): "
          "PORT_PARTITION_HALF_STATUS = %s" % status)
    failed = [label for label, verdict, _ in results if verdict == "FAIL"]
    assert status == "SUPPORTED", \
        "F.50: clean fixtures yield VOID -- the port-partition half's " \
        "Level-A badge support is void; failing: %s" % failed
    assert mutant_double_count_c()
    assert probe_ledger_identity_input_domain()
    print("F.50 PASS: PORT_PARTITION_HALF_STATUS = SUPPORTED on the clean "
          "fixtures (4/4 constructions); the planted double-count mutant on "
          "aggregate (c) yields VOID with a printed witness; the "
          "ledger-identity input-domain probe confirms C22's second "
          "disjunct is input-unreachable (ledger half guarded by F.35's "
          "own battery) -- the any-single-aggregate-voids rule of "
          "FALSIFICATION_C22 is machine-reported.")


if __name__ == "__main__":
    main()
