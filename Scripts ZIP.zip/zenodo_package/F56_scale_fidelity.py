#!/usr/bin/env python3
"""Paper 11 - F.56: scale-fidelity audit for the section 0.5.v.3 Universality
claim (SCALE_FIDELITY).

Machine-checked halves of the SCALE_FIDELITY hybrid claim:
  (1) N-threshold sweep -- the native definition sources carry no
      N-case-split. Pattern-based sweep over the paper's live prose and the
      F*.py definition machinery, with the 8 Phase-1-adjudicated
      near-misses as a pinned allowlist (each entry names its paper section
      and states why it is not an N-case-split). A planted N-threshold
      mutant is rejected with a printed witness.
  (2) 6N strict monotonicity -- for all positive integers N1, N2 with
      N2 > N1: 6*N2 - 6*N1 = 6*(N2-N1) >= 6 > 0. Pure integer arithmetic.
      The analytic argument (totality over all positive integers, never a
      bounded enumeration) is this docstring; the sample below is a labeled
      demonstration instance, and each identity is computed two independent
      ways (distributed 6*n2-6*n1 versus factored 6*(n2-n1)).
  (3) Exactness composition -- DEMONSTRATION-grade (V18): a synthetic
      6N-entry Fraction workload sums exactly below. This shows the shape
      of the claim on a representative workload; it does not prove that
      the paper's native operations are exact. The machine weight for
      "native operations compose exactly" is F.42's section 0.5.v.1 float
      sweep (cited here, not re-implemented: this file itself is swept by
      it) plus R15's exact-finite-sum rule (section 4.1). Hence zero formal
      error at every finite N.

Epistemic standing: the fidelity identification (fidelity := extent times
exactness; extent = the 6N ledger entries, exactness = zero formal error)
is author-authorized native content (2026-10-05), asserted not
machine-proved. This script checks the three machine-provable halves above
and never the identification itself.

Planted-mutant battery (each rejected with a printed witness):
  M1  an N-case-split sentence ("For N > 10**6 the rule set switches to a
      bulk regime") -- caught by the defect patterns;
  M2  "B grows monotonically with N" -- rejected: B = 6N - sum(k_j) is a
      function of the junction structure as well as N, so it is not a
      pure-N function; the section 11.2 Nodes-to-ports nonmonotonicity
      theorem (N=1,B=6 against N=2,B=4) refutes the claim outright, and the
      battery computes that witness (B(1)=6 > B(2)=4) rather than citing it
      bare. Only pure-N functions survive a monotonicity claim;
  M3  "fidelity degrades with N" -- rejected: the exactness composition
      leaves no error source in the paper (F.42's §0.5.v.1 float sweep plus
      R15's exact-finite-sum rule, cited not re-implemented), so no
      positive error function can attach; the script's own 6N-entry trace
      is demonstration-grade (V18) and carries no part of the
      no-error-source claim;
  M4  an unbadged "monotonically improves X" sentence -- rejected by the
      battery's local badge oracle (the production gate is F.42 group 23;
      the oracle here demands [LEVEL A] plus a named F-check).
"""

import re
import ast as _ast
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "paper_11.md"

INPUT_PROVENANCE = {
    "HERE": {"class": "control",
             "note": "runtime path to this script's directory"},
    "PORTS_PER_NODE": {"class": "paper-defined",
                       "source": "§4.3 Port Count Invariance (six ports per node)"},
    "N_SAMPLE_BOUND": {"class": "control",
                       "note": "demonstration-enumeration bound; the analytic proof is unbounded over all positive integers"},
    "DEFECT_PATTERNS": {"class": "control",
                        "note": "genuine N-case-split shapes; any hit in the sweep domain fails the run"},
    "NEAR_MISS_PATTERNS": {"class": "control",
                           "note": "near-miss shapes; each is adjudicated against ALLOWLIST, never silently passed"},
    "ALLOWLIST": {"class": "control",
                  "note": "pinned allowlist: the 8 Phase-1-adjudicated near-misses (changelog #131); each entry names its paper section and why it is not an N-case-split"},
    "BATTERY": {"class": "control",
                "note": "planted-mutant battery inputs; each must be rejected, never admitted"},
}
_ast.literal_eval(repr(INPUT_PROVENANCE))  # interface self-check: literal-evaluable

# R23 domain declaration (2026-10-05): aspect kinds this script's checks
# exercise (see F.38 R23 / F.49 Check 5).
DOMAIN = {
    "proved": [],
    "notes": "scale-fidelity claim about N/scale, not aspect kinds: 6N strict "
             "monotonicity over positive integers, the N-threshold sweep over "
             "native definition sources, and the exactness composition. No "
             "aspect kind is exercised; the aspect-kind domain list is vacuous "
             "by design (R23 adjudication, changelog #131) -- not force-fit.",
}

PORTS_PER_NODE = 6
N_SAMPLE_BOUND = 10**6

# Genuine N-case-split shapes: a rule that changes with N. Any hit in the
# sweep domain fails the run -- there is no pin class for these.
DEFECT_PATTERNS = [
    (re.compile(r"\bfor N\s*(?:>=?|above\b|exceeds?\b)", re.IGNORECASE),
     "for-N-gt"),
    (re.compile(r"\bwhen N\s*(?:>=?|exceeds?\b)", re.IGNORECASE),
     "when-N-gt"),
    # The lookahead excludes the sweep's own name ("N-threshold sweep") and
    # its battery ("N-threshold mutant/mutants"): the pattern targets a
    # threshold posited as an object, never the machinery that hunts it.
    (re.compile(r"\bN[- ]threshold\b(?!\s+(sweep|mutants?))",
                re.IGNORECASE), "N-threshold"),
    (re.compile(r"\bthreshold\b[^\n.]{0,40}\bin N\b", re.IGNORECASE),
     "threshold-in-N"),
    (re.compile(r"\b(?:large|small)[- ]N\b", re.IGNORECASE), "large-small-N"),
    (re.compile(r"\bN[- ]regime\b", re.IGNORECASE), "N-regime"),
    (re.compile(r"\bat N\s*=\s*\d+[^\n.]{0,50}\b(?:change|switch|regime|different)\b",
                re.IGNORECASE), "at-N-change"),
]

# Near-miss shapes: threshold/bound language that is not an N-case-split.
# Each is pinned to its adjudication in ALLOWLIST; the anti-vacuity assert
# in check_sweep requires every entry to match at least one live hit.
NEAR_MISS_PATTERNS = [
    (re.compile(r"res\(A,?\s*B\)\s*>\s*TH\b"), "TH-fuse"),
    (re.compile(r"\btwo-regime\b"), "two-regime"),
    (re.compile(r"k_j\s*(?:\u2265|>=)\s*2\b"), "arity-floor"),
    (re.compile(r"\bsmall-D\b"), "small-D"),
    (re.compile(r"\bsaturation threshold", re.IGNORECASE),
     "saturation-threshold"),
    (re.compile(r"\b(?:emergence threshold|thermodynamic limit|transition "
                r"scale|renormalization flow)\b"), "ab-negations"),
    (re.compile(r"10\u2078\u2070|10\^80|10\*\*80"), "1e80"),
    (re.compile(r"\b(?:bounded enumeration|depth[- ]bounded|bounded test|"
                r"finite instance check)\b", re.IGNORECASE), "bounded-test"),
]

ALLOWLIST = {
    "TH-fuse": "TH is the Junction Saturation Threshold on the presented "
               "residue res(A,B) (§8.4/§8.6): a threshold on residue, not on N",
    "two-regime": "the two-regime partition is the §8.6 residue partition "
                  "(res=0 vs res>0) for Case B (§10.3/F.53): a partition on "
                  "residue, not on N",
    "arity-floor": "junction-arity definitional floor k_j ≥ 2 (§4.1): a "
                   "floor on arity, not on N",
    "small-D": "small-D regime is relay-distance irregularity (F.45, "
               "§8.5): d is not N",
    "saturation-threshold": "saturation thresholds: Paper 23's phase-locked "
                           "surface-state enumeration (outline, §0.5.x) and "
                           "the §8.6 saturation fuse (residue-gated); neither "
                           "is an N threshold",
    "ab-negations": "§0.5.ab Single-Regime Axiom negations (no transition "
                    "scale, no emergence threshold, ...): the denial of "
                    "thresholds, not a threshold",
    "1e80": "10⁸⁰ (§0.5.ab, §0.5.v.3): an inventory-count illustration of "
            "the single regime's scope, not a threshold",
    "bounded-test": "bounded test/instance domains in verification scripts "
                    "(k=1..4 enumeration, depth-bounded paths): finite test "
                    "fixtures, not native N-case-splits",
}

# Planted-mutant battery inputs. Each must be rejected by battery_check.
BATTERY = [
    {"id": "M1-n-threshold",
     "sentence": "For N > 10**6 the rule set switches to a bulk regime.",
     "kind": "defect-pattern"},
    {"id": "M2-B-monotone",
     "sentence": "B grows monotonically with N.",
     "kind": "pure-N"},
    {"id": "M3-fidelity-degrades",
     "sentence": "Fidelity degrades with N.",
     "kind": "error-source"},
    {"id": "M4-unbadged",
     "sentence": "Scale-up monotonically improves resolution throughput.",
     "kind": "badge"},
]


def live_lines():
    """(source_tag, lineno, line) over the paper's live prose (before
    Appendix I, fenced code removed) and the F*.py definition machinery.
    This file is excluded: its battery strings are exercised directly by
    battery_check, never via the file sweep."""
    out = []
    lines = PAPER.read_text(encoding="utf-8").splitlines()
    app_i = next(i for i, l in enumerate(lines)
                 if l.startswith("## APPENDIX I"))
    incode = False
    for i, l in enumerate(lines[:app_i]):
        if l.strip().startswith("```"):
            incode = not incode
            continue
        if incode:
            continue
        out.append(("paper", i + 1, l))
    for p in sorted(HERE.glob("F*.py")):
        if p.name == "F56_scale_fidelity.py":
            continue
        for j, l in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            out.append((p.name, j, l))
    return out


def sweep_n_threshold(lines):
    """Run the defect and near-miss patterns. Returns (defects, near_counts)."""
    defects = []
    near_counts = {name: 0 for _, name in NEAR_MISS_PATTERNS}
    for tag, ln, line in lines:
        for rx, name in DEFECT_PATTERNS:
            if rx.search(line):
                defects.append((tag, ln, name, line.strip()[:120]))
        for rx, name in NEAR_MISS_PATTERNS:
            if rx.search(line):
                near_counts[name] += 1
    return defects, near_counts


def check_sweep():
    """(1) N-threshold sweep: zero defect hits; every allowlist entry is
    load-bearing (matches at least one live hit). The anti-vacuity loop
    iterates the ALLOWLIST itself (probe-7 fix, changelog #131): removing
    an allowlist entry -- or a near-miss pattern -- breaks the key-set
    equality and fails the run; the printed count is computed from the
    actual allowlist, never hardcoded."""
    defects, near_counts = sweep_n_threshold(live_lines())
    assert defects == [], \
        "N-threshold defect hits:\n" + "\n".join(
            "%s:%d [%s] %s" % d for d in defects)
    assert set(ALLOWLIST) == set(near_counts), \
        "allowlist/near-miss-pattern key mismatch: %s vs %s" % (
            sorted(ALLOWLIST), sorted(near_counts))
    for name in ALLOWLIST:
        assert near_counts[name] >= 1, \
            "allowlist entry %r matches nothing (not load-bearing)" % name
    print("F.56 CHECK 1 PASS: N-threshold sweep clean -- 0 defect hits; "
          "%d/%d allowlist entries load-bearing."
          % (len(ALLOWLIST), len(ALLOWLIST)))


def ledger_entries(N):
    """The 6N ledger entries the same rule set executes at node count N."""
    return PORTS_PER_NODE * N


def boundary_count(N, junctions):
    """B = 6N - Σk_j: takes the junction structure as well as N."""
    return 6 * N - sum(junctions)


def admit_monotone_claim(func):
    """A monotone-in-N claim is admitted only for pure-N functions: the
    function must take exactly N (one parameter), and must strictly
    increase over the demonstration sample."""
    if func.__code__.co_argcount != 1:
        return False
    vals = [func(n) for n in (1, 2, 3, 10, 100, 1000)]
    return all(b > a for a, b in zip(vals, vals[1:]))


def check_monotonicity():
    """(2) 6N strict monotonicity. The proof is the analytic identity in
    the docstring (totality over all positive integers); below is the
    labeled demonstration instance, each identity computed two independent
    ways (distributed vs factored)."""
    pairs = []
    n = 1
    while n < N_SAMPLE_BOUND:
        pairs.append((n, n + 1))
        n *= 10
    pairs.append((1, N_SAMPLE_BOUND))
    for n1, n2 in pairs:
        assert 6*n2 - 6*n1 == 6*(n2-n1)  # analytic: distributivity over integers; totality in docstring
        assert 6*n2 - 6*n1 > 0
    assert admit_monotone_claim(ledger_entries)
    print("F.56 CHECK 2 PASS: 6N strictly increasing in N (analytic "
          "identity holds on %d sample pairs; pure-N control admitted)."
          % len(pairs))


def workload_trace(N):
    """One exact rational operation per ledger entry: 6N entries."""
    return [Fraction(i + 1, i + 2) for i in range(6 * N)]


def check_exactness():
    """(3) Exactness composition -- DEMONSTRATION-grade (V18): the modeled
    6N-entry synthetic workload sums exactly. This shows the claim's shape
    on a representative workload; the machine weight for the paper's
    no-error-source claim is F.42's float sweep + R15 (cited, not
    re-implemented)."""
    for N in (1, 2, 10, 1000):
        trace = workload_trace(N)
        assert all(type(x) is Fraction for x in trace)
        assert isinstance(sum(trace), Fraction)
    print("F.56 CHECK 3 PASS (DEMONSTRATION): synthetic 6N-entry workload "
          "sums exactly at N=1,2,10,1000; machine weight for the paper's "
          "no-error-source claim is F.42's §0.5.v.1 float sweep + R15.")


def battery_check(entry):
    """Returns (admitted, witness). Every battery entry must come back
    not-admitted."""
    s = entry["sentence"]
    kind = entry["kind"]
    if kind == "defect-pattern":
        hit = any(rx.search(s) for rx, _ in DEFECT_PATTERNS)
        return (not hit,
                "N-case-split shape detected" if hit else "no defect shape")
    if kind == "pure-N":
        # Computed witness (§11.2 L982): B(1) = 6 with no junctions,
        # B(2) = 4 with one arity-8 junction -- N rises while B falls, so
        # B is not monotone in N and a monotone-in-N claim over B is
        # inadmissible. This computes the cited nonmonotonicity rather
        # than resting the rejection on the arity check alone.
        assert boundary_count(1, []) == 6
        assert boundary_count(2, [8]) == 4
        assert boundary_count(2, [8]) < boundary_count(1, [])
        admitted = admit_monotone_claim(boundary_count)
        return (admitted,
                "§11.2 nonmonotonicity computed (B(1)=6 > B(2)=4): B is a "
                "function of the junction structure as well as N, not a "
                "pure-N function" if not admitted
                else "unexpectedly admitted")
    if kind == "error-source":
        # The mutant needs a positive error source to degrade fidelity.
        # The paper's no-error-source claim rests on F.42's §0.5.v.1 float
        # sweep plus R15's exact-finite-sum rule (cited, not
        # re-implemented). The synthetic 6N-entry trace exercised below is
        # DEMONSTRATION-grade (V18): it shows a representative workload
        # summing exactly -- it does not by itself establish "no error
        # source" in the paper.
        inexact = [x for x in workload_trace(1000)
                   if type(x) is not Fraction]
        admitted = len(inexact) > 0
        return (admitted,
                "no error source (F.42 §0.5.v.1 float sweep + R15 "
                "exact-finite-sum, cited; synthetic trace is "
                "demonstration-grade)" if not admitted
                else "unexpectedly admitted")
    if kind == "badge":
        # Local oracle for the group-23 requirement (badged + backed); the
        # production gate is F.42 group 23.
        ok = ("[LEVEL A]" in s) and bool(re.search(r"F\.\d+", s))
        return (ok, "unbadged monotonicity claim" if not ok else "badged")
    return (False, "unknown battery kind")


def check_battery():
    n_rejected = 0
    for entry in BATTERY:
        admitted, witness = battery_check(entry)
        assert not admitted, \
            "battery mutant %s unexpectedly admitted" % entry["id"]
        print("REJECTED %s (%s)" % (entry["id"], witness))
        n_rejected += 1
    # Controls: the honest shapes pass.
    assert admit_monotone_claim(ledger_entries)
    ok, _ = battery_check({"sentence": "Scale-up improves fidelity "
                                      "[LEVEL A] (F.56).",
                           "kind": "badge"})
    assert ok
    print("F.56 BATTERY PASS: 4/4 planted mutants rejected; pure-N and "
          "badged controls admitted.")


check_sweep()
check_monotonicity()
check_exactness()
check_battery()
print("F.56 DONE: scale-fidelity machine halves checked -- N-threshold "
      "sweep, 6N strict monotonicity, exactness composition; the fidelity "
      "identification remains author-authorized (asserted, not "
      "machine-proved).")
