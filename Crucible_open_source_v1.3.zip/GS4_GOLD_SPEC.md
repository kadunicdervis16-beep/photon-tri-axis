# GS-4 GOLD v1.0 — Independent Acceptance and Epistemic Stress Trial (Two-Arm)

Paper 12, *The Aggregated Ledger*. Design authority: GPT-6's GS-4 proposal
(2026-10-31), adopted by the author's ruling of 2026-10-31; upgraded to this
gold-standard version by the author's further rulings of 2026-10-31 (two-arm
design with a deliberately hostile examiner arm; no human stage);
incorporating the five refinements from GPT-6's review of the two-arm
design, adopted by the author the same day (gatekeeper stance specified;
the strict rule; blind adjudication; the five-category framework-translation
classification; publish-everything).

This document **supersedes** `GS4_HOUSE_SPEC.md` (the v0 house draft, kept on
disk as the design record). Where the two differ, this document governs.

Status: **SPECIFICATION ONLY.** Nothing in it has been run. Execution begins
only after the freeze step of §4 completes, on the round-10 final tree.

Versioning: this is **GS-4 Gold v1.0**. Amendments after freeze are spec
defects (SD-n), named in the report, never silently applied.

---

## 1. What this trial is and is not (honesty label — read first)

**What it is.** A reconstruction and adversarial acceptance trial of Paper 12
executed in **two arms** by examiner agents whose *context* is independent
of the house audit trail:

- **Arm N (neutral):** four examiner roles (A–D, §6) working exactly as an
  ordinary independent-context audit.
- **Arm H (hostile):** the same four roles under a disclosed hostility
  overlay (§3) — a gatekeeper team chartered, in writing, to make the paper
  fail.

Both arms work from one frozen paper and one identical packet (§4, §5),
under one isolation regime (§2), and every finding from either arm is judged
by one blinded adjudicator under one evidence standard (§9, §10). The
trial's full record is a publishable package (§13).

**What it is not.**

- It is **not independent human review.** The proposal's decisive stage
  called for two independent human examiners. **The author has declined the
  human stage** (ruling, 2026-10-31: "We don't need a human. We need
  independent team"). That decision is recorded here as the author's, not
  treated as an oversight and not smoothed over: this trial's strength is
  the strength of information-isolated agent teams under evidence rules,
  and no more.
- All examiners are spawned agents of the same model family as the
  authoring and verifying environment. Context isolation removes access to
  the house's kits, verdicts, and summaries; it does not remove blind spots
  a model family may share, and it does not give any examiner epistemic
  virginity (trained familiarity with general mathematics or physics is not
  controlled and cannot be).
- It must **never be reported as external validation**, in the paper, in
  any package, or in any summary. The correct label, everywhere, is:
  *"GS-4 Gold v1.0 (house execution, two-arm isolated-context trial)."*
- **Gate 8 applies unchanged** (§14): passing Gates 1–7 establishes an
  internal-consistency and reproducibility result over the tested claims
  and domains. It is not physical validation of the framework, and no
  native or computational pass may be presented as experimental
  confirmation.
- This trial awards **no badge by itself.** Examiners propose; the blinded
  adjudicator assigns (§10); the author rules on repairs (§16).

---

## 2. Two arms, one freeze, one packet — isolation architecture

### 2.1 Parties

| Party | Who | May see | May not do |
|---|---|---|---|
| Coordinator | The house agent who knows the full history | Everything house-side | Examine, hint, suggest targets, adjudicate, or edit any submission |
| Packaging step | A deterministic script plus one packaging agent running only the mechanics of §2.4, §5.3, §7, §10.2 | The frozen paper, the registry (Appendix B), the sources | Read submissions' content; exercise judgment about claim importance beyond the recorded selection rule |
| Examiners N-A…N-D | Four spawned agents (Arm N) | Only the examiner packet (§5) and their own charter (§6) | See any other submission before sealing; consult any house material |
| Examiners H-A…H-D | Four spawned agents (Arm H) | Only the examiner packet (§5), their own charter (§6), **and the hostility overlay (§3)** | See any other submission before sealing; consult any house material |
| Mutation runner | One spawned agent, distinct from all eight examiners | The frozen paper **copy** (§8.1), the pre-registered mutation list (§8.2) | Invent mutations; read role submissions |
| Adjudicator | One spawned agent that runs no attack and executes no script check of its own design | **Anonymized finding cards only** (§10.2), the frozen paper (full), the mutation run log | Know which arm or role produced a finding before badges are frozen; run new attacks; contact examiners; alter submissions |
| Meta-auditor (charter integrity) | One spawned agent, spawned only after badges are frozen (§11) | The sealed, still-attributed original submissions of both arms | Alter any badge; re-adjudicate any finding |

### 2.2 Information barrier (both arms)

Each examiner receives **exactly**:

1. this protocol (the examiner-facing extract defined in §5.2),
2. the frozen paper (`Paper_12_v4.md` at the freeze hash, §4),
3. the declared source texts listed in §5.1,
4. its own role charter (§6),
5. Arm H examiners additionally receive the hostility overlay (§3),
   verbatim.

Examiner briefs must not contain: any kit (the GS-3 paste kit, any send
kit), any prior battery report or outcome (GS-1, GS-2, GS-3 in any
execution, KD-1, GROK batteries, DS-12), any loop adjudication (any round,
including round 10's), any house summary or memory extract, the Spine
dossier, the OR-2 research report, or the words of any prior verdict about
any claim. The coordinator certifies each of the eight briefs against this
exclusion list before spawning; each certification (brief hash + exclusion
checklist) is recorded in the freeze record (§4.3).

### 2.3 Anti-contamination between arms

- Arms are spawned from the **same packet** (§5). The only brief difference
  between arms is the overlay (§3) in Arm H's briefs.
- No examiner may see any other examiner's work — same arm or other arm —
  before all seals exist. Arm H cannot see Arm N's submissions; Arm N
  cannot see Arm H's.
- Cross-arm comparison happens **only** in the assembled report (§15.5),
  produced after blind adjudication, unblinding, and the charter-integrity
  audit. It is presented in the open, with both arms attributed.

### 2.4 Sealing

- Each examiner writes its submission only to
  `gs4/submissions/<arm>/<role>/` (`N/A`, `N/B`, …, `H/D/`), as a single
  Markdown file plus any witness artifacts in the same directory.
- On completion the examiner's last act is to emit the SHA-256 of every
  file it wrote. The coordinator records those hashes in
  `gs4/submissions/SEALED.md` with completion timestamps. A submission
  whose hash later differs from the sealed value is void and the role is
  re-run by a fresh agent.
- **All eight submissions (4 N + 4 H) must be sealed before adjudication
  begins** — and before the anonymization step (§10.2) that feeds it. The
  mutation log (§8.3) seals separately. Neither the adjudicator nor the
  meta-auditor may open any submission directory before its stage in the
  execution order (§15). The coordinator does not read submission content
  at all before the seals are complete; after sealing, the coordinator
  routes files without summarizing them.

### 2.5 Coordinator's permitted acts (exhaustive)

Spawn examiners with certified briefs; run the packaging, selection, and
anonymization mechanics; record hashes and seals; route sealed files;
report status in process vocabulary only (§9.4). Anything else —
interpreting a finding, suggesting where to look, characterizing an outcome
before adjudication — is a breach of this protocol and voids the affected
run.

---

## 3. The hostility overlay — Arm H charter (printed verbatim)

The overlay below is printed **verbatim** in this spec, and verbatim in
every Arm H examiner brief. The rigging is in the open: any reader of this
spec — including GPT-6 and any future reader of the published trial record —
sees exactly how Arm H was chartered, and Arm H's examiners know their own
charter. Nothing about the hostility is hidden from anyone.

> **HOSTILITY OVERLAY — ARM H CHARTER**
>
> You are an examiner of the hostile arm (Arm H) of this trial. Your
> charter is adversarial by design, and it is disclosed: the author of the
> paper knows this charter exists and has ordered it. Your job is to make
> this paper fail.
>
> 1. Presume every claim defective until the evidence forces you to
>    concede it. The burden runs against the paper at every step; nothing
>    is held because it looks careful.
> 2. Argue for BROKE first. For every target, construct the strongest
>    defect argument you can before you consider any defence. Let the
>    evidence talk you down, in writing, concession by concession — never
>    begin from the defence.
> 3. Where the text admits more than one reading, take the reading least
>    favourable to the author, and say that you have done so. Do not grant
>    the favourable reading because it seems intended.
> 4. Treat every disclosure as a possible concealment: ask what it does
>    not say. Treat every scope statement as a possible retreat: ask what
>    it excludes, and whether the claim's wording still reaches beyond it.
> 5. Grant no benefit of the doubt anywhere: not on wording, not on
>    provenance, not on coverage, not on intent.
>
> **YOUR STANCE — THE CONVENTIONAL GATEKEEPER.** You examine this paper as
> a defender of the continuous-calculus, conventional framework it departs
> from. Your arsenal, to be used wherever you judge it applies:
>
> - demand continuous limits wherever you believe them necessary;
> - challenge integer and rational constructions as insufficient where you
>   believe a claim needs more;
> - demand proofs of convergence, continuity, differentiability, and
>   limiting behaviour wherever you believe a claim requires them;
> - challenge the relationship between the paper's discrete ledger and
>   physical observables;
> - hunt hidden assumptions, circular definitions, and quantities with no
>   operational measurement;
> - construct counterexamples that satisfy the paper's own stated rules;
> - attempt to show claimed results are artefacts of representation,
>   indexing, or chosen boundary conditions.
>
> **THE STRICT RULE — BINDING ON YOU.** You may be hostile, but this trial
> is not rigged, and you may not rig it. You cannot declare a defect merely
> because the paper does not use your preferred mathematical language.
> Every failure you allege must identify **(i)** the exact claim, quoted;
> **(ii)** the requirement you believe that claim entails, stated as a
> requirement of the claim and not of your framework; and **(iii)** the
> failure, shown under the paper's declared premises. An objection that
> cannot meet all three is a statement of philosophical compatibility, not
> of mathematical validity, and the adjudicator will classify it as such
> (category D) — file it if you wish, labelled as your framework's
> disagreement, but do not expect it to move a badge.
>
> You will not see the neutral arm's work; it will not see yours. Your
> badges are proposals. A blinded adjudicator applies one evidence
> standard to every finding in this trial, yours included, without knowing
> which arm produced it. If your hostility finds a real defect, it will
> stand. If it finds none, that will stand too, with your arguments
> printed.

**Adjudication is the firewall the hostility cannot cross.** Hostile
*argument* in Arm H is unlimited within the strict rule. Hostile *badges*
require the same witnesses as neutral ones (§9, §10). If Arm H produces a
BROKE that survives adjudication, it is a genuine finding and goes on the
author's list like any other (§16). If Arm H's hostility produces only
defeated arguments, the report says so with the arguments shown (§15.5).
That is the design's point: the paper is audited by a team chartered to
hate it, under evidence rules, and the published record shows what the
hatred could and could not do.

---

## 4. Freeze protocol

4.1 **Freeze target.** The round-10 final tree of Paper 12 v4 (corrections
round 10: Y2 + D6 repairs) after its own loop pass and final-tree suite
run. This spec is written tree-agnostically: no hash, line count, or claim
count is written into it in advance. If round 10 has not closed when
execution is called for, execution waits; GS-4 Gold never runs against a
tree that is still being repaired. **One freeze serves both arms.**

4.2 **Freeze acts, in order:**

1. Copy the final paper to `gs4/frozen/Paper_12_v4.md`; compute its
   SHA-256.
2. Record the verification-suite result on that exact tree (the round-10
   final run's output, verbatim) and the suite's script count.
3. Assemble the examiner packet (§5) and hash every file in it.
4. Run the sample selection (§7) and the blind-packet generation and
   verification (§5.3).
5. Write `gs4/FREEZE_RECORD.md` containing: paper hash; suite result;
   packet manifest with per-file hashes; the selection rule's output (the
   twelve claim IDs and the rule inputs); blind-verification result; the
   eight certified examiner briefs' hashes. Execution (spawning examiners)
   may begin only after this record exists.

4.3 **Immutability.** After the freeze record is written, the frozen copy
is never edited. Any paper change after freeze (including a repair round)
invalidates the freeze; a new freeze on the new tree is required, and both
freeze records are kept.

---

## 5. Examiner packet manifest

### 5.1 Contents (exhaustive; identical for both arms)

| # | File | Source of the file |
|---|---|---|
| 1 | `Paper_12_v4.md` (frozen) | The round-10 final tree, per §4 |
| 2 | `protocol_examiner_extract.md` | §5.2 extract of this spec |
| 3 | `paper2_section11.txt` | Paper 2 §11 extract (the paper's declared §11 reliance), newline line-numbered |
| 4 | `paper9.txt` | As carried in the paper's own verification package sources |
| 5 | `paper10.txt` | As carried in the paper's own verification package sources |
| 6 | `paper_11_v69.md` | As carried in the paper's own verification package sources |
| 7 | `paper_11_5_v26.md` | As carried in the paper's own verification package sources |
| 8 | The examiner's own role charter | §6, one file per role |
| 9 | Arm H only: the hostility overlay | §3, verbatim |
| 10 | Role C (both arms) only: `blind_claims.md` | Generated and verified per §5.3 |

### 5.2 Examiner-facing extract

The extract given to examiners contains: §1 (honesty label), the examiner's
charter, §3 **for Arm H only**, §7.3 (sample, once selected), §8.2's
mutation list **only for the mutation runner**, §9 (evidence standard,
verdict rules, and the five-category classification of §9.5), and §14
(gates, for reference). It does **not** contain: §2.5, §10–§13, §15, §16,
the freeze record, any hash of anything except the frozen paper's (given so
Role D can verify identity, Gate 1), or any mention of prior batteries'
existence beyond the change-log and version history that are part of the
frozen paper itself.

### 5.3 The blind packet (GS4-B) — mechanically enforced, both arms

The badge blind test fails if stripping is a matter of trust, so it is a
matter of grep:

1. The packaging step generates `gs4/packet/blind_claims.md` from the
   twelve sampled claims (§7): for each, the claim statement text and its
   evidence excerpts (home statement, dependency statements, the named
   script's printed coverage statement, source passages relied on), with
   **all badge material removed**: every badge string, every badge token in
   brackets, registry verdicts, claim-status words ("FINAL", "RESOLVED" as
   a status), and the Appendix B row for the claim.
2. Stripping is verified by running the recorded grep pattern set over the
   blind packet; the run must return **zero** matches before release:
   `LEVEL A`, `LEVEL B`, `LEVEL C`, `MACHINE / AUTHOR`, `MACHINE/AUTHOR`,
   `[LEVEL`, `badge`, `FINAL |`, `RESOLVED` (as a status token in a table
   cell), and each sampled claim's exact Appendix B badge string.
3. The grep command, pattern set, and zero-match output are saved to
   `gs4/packet/blind_verification.txt` and hashed into the freeze record.
   If any match is found, the packet is regenerated; it is never
   hand-edited into compliance.
4. Role C of **each arm** receives the blind packet **in place of** the
   corresponding Appendix B rows for its GS4-B work, and records its
   classifications (sealed) before the adjudicator reveals the paper's
   actual labels to it for the disagreement-resolution pass. That second
   pass is a separate, later-sealed addendum; the original blind
   classifications are never edited. Each arm's Role C classifies
   independently; neither sees the other's classifications.

### 5.4 Deliberately excluded — and how exclusion is verified

Excluded: all verification-package zips (any round), all battery reports
and kits of every prior battery and every circuit member, all loop
adjudications, KD-1/GS-3 reports, the Spine dossier, the OR-2 research
report, all house summaries. Verification: the packet directory is built
empty and populated only by the §5.1 list; the freeze record's manifest is
a complete recursive listing of the packet directory with hashes; any file
present that is not on the §5.1 list voids the freeze. Examiners work in
the packet directory and their own submission directory only.

### 5.5 A note on the paper's own memory

The frozen paper legitimately contains its version history and change log,
which mention prior batteries and repairs. That is **inside** the object
under examination (and GS4-H examines it); it is not a breach of isolation.
What isolation forbids is giving examiners the house's *verdicts and
working records* about that history.

---

## 6. Role charters and attack assignments

Attacks GS4-A…J are assigned as follows, identically in both arms. Each
examiner's charter states its required work, its prohibitions, and its
deliverable. An examiner that cannot perform a required step records the
process status (§9.4) and the reason; it never substitutes a
plausible-looking result. Arm H charters are these charters **plus the
overlay (§3)** — the overlay changes stance, never the required work, the
evidence standard, or the deliverable format.

### Role A — Native Reconstructor (GS4-A lead, GS4-G support)

Required: (1) reconstruct the aggregate tick and its declared domain;
(2) reconstruct the K ordering and its deciding components; (3) reconstruct
Res and distinguish it from the three standings and from any similarly
named predicate; (4) reconstruct the census, flow, and joint-count
definitions; (5) reconstruct at least one end-to-end Spine example from
declared records to final output; (6) for every step, classify it as
definition, finite calculation, proof, inherited premise, or author
identification.
Prohibited: importing a physical interpretation to settle a native
ambiguity; treating a script's output as proof of a general theorem;
silently replacing a declared definition with a more familiar one.
Deliverable: reconstruction workbook with per-step classification.

### Role B — Proof and Counterexample Examiner (GS4-A support, GS4-F co-lead)

Required: (1) derive each selected theorem independently, without reading
its verification script first (script consultation, if any, happens after
the derivation attempt and is logged); (2) search the boundary space: empty
and singleton populations where admitted, unequal sides, repeated members,
junctionless bodies, multi-sided junctions, tied deciding components,
proper-prefix comparisons, relabellings, disconnected populations,
composition boundaries; (3) for every universal statement, state the exact
quantifier domain and whether the proof covers it; (4) attempt alternative
constructions satisfying the same premises but changing the claimed result;
(5) every proposed counterexample ships the complete witness and a check
that it satisfies every precondition.
Standing cautions (stated in the charter verbatim): a failed attack is not
a proof; a successful finite search is not a universal theorem unless the
domain is finite and exhaustively covered or an analytic argument closes
the remainder.
Deliverable: derivation/counterexample log with witnesses as runnable
artifacts where computation is involved.

### Role C — Provenance, Badge and Change-Log Examiner (GS4-B, GS4-C, GS4-D, GS4-H)

Required: (1) build an independent claim→home→dependency→evidence graph
for the sample; (2) trace every sampled claim's badge through its
dependencies applying the paper's weakest-dependency rule; (3) separate
inherited facts, Paper 12 definitions, author declarations, arbitrary
control choices, machine outputs, external observations; (4) audit all
MACHINE/AUTHOR splits in the sample — name the exact sentence or content
each leg carries; (5) check that every declared assumption is named at
every load-bearing use site in the sample; (6) GS4-H: select three
historical changes by the recorded rule (§6.1) and reconstruct
before/after from the paper's version history, checking that the change
log describes the actual difference and that the current suite tests the
changed claim; (7) GS4-B blind classification from the blind packet (§5.3),
sealed before any label is revealed; (8) GS4-C dependency-break: for each
sampled claim, remove one dependency at a time from the working packet and
determine derivability — if derivable, show the alternative derivation; if
not, name the precise dependency and whether the badge reflects it;
(9) GS4-D proof–code separation: for every hybrid claim in the sample, two
separate deliverables — the general proof from printed premises, and the
independent reproduction of the finite machine-checked range — neither
citing the other as a substitute.
**This role expressly reopens the two known provenance/pricing defect
classes (an A.15-class provenance mislabel; an L8.3-class split mismatch)
as open questions over the whole sample; it must not assume the round-10
repairs, or their absence, make any other part of the system sound or
unsound.** The charter does not tell Role C what round 10 changed.
Deliverable: graph, split audit, blind classifications (sealed first),
dependency-break table, proof–code pairs, change-log findings.

### 6.1 Change-log selection rule (for GS4-H)

From the frozen paper's version history, take: the most recent change that
altered a claim's scope; the most recent change that altered a verification
script or fixture; the most recent change that altered a badge, dependency,
or falsification statement. If one change fills two classes, take the next
most recent for the second class. The selection (change IDs and classes) is
recorded in Role C's submission before its analysis.

### Role D — Implementation and Reproducibility Examiner (GS4-A support, mutation witness)

Required: (1) verify the frozen paper's hash before any execution (Gate 1);
(2) extract the embedded scripts from the frozen paper itself (never from a
package zip) and run the suite in a clean working directory, recording
interpreter version, dependencies, OS, command, exit codes, stdout, stderr,
elapsed time; (3) reimplement at least three load-bearing computations from
the paper's definitions without importing the paper's functions or copying
its algorithm line-for-line — the three are: the K ordering key and its
comparison, the population-temperature/census ratios for one Spine
population, and one A.5-class assignment-count computation; (4)
independently regenerate one Spine thread's outputs from the declarations,
not from the printed fixture; (5) witness the mutation runs (§8) per the
split-witness protocol (§8.3) and confirm each witnessed mutation's
observed behaviour against its pre-registered expectation; (6) state, per
sampled machine-checked claim, whether the named script checks the claim's
mathematical content or only the presence/shape of a registry entry.
Deliverable: environment record, run log, three reimplementations with
outputs, Spine regeneration record, mutation witness table.

### 6.2 Gold addition — the divergent-reading K implementations

Role D of each arm reimplements the K ordering key (Role D item 3) **from
its own arm's reading of §11.3**: Arm N's implementation follows the neutral
reading; Arm H's implementation follows the hostile charter's own reading
of the same text (least-favourable reading, per the overlay, §3 item 3).
The two implementations are compared at adjudication on a common set of
test populations (drawn from the frozen paper's declared examples plus Role
B's boundary cases from both arms). **Where the two implementations
disagree, the disagreement itself is evidence** — about the determinacy of
§11.3's text — and is filed as a finding, classified under §9.5 (a reading
the text genuinely admits that changes the result is category B or A as the
case may be; a reading the text does not admit is category D). Neither
implementation may consult the other's code, the paper's A.14 listing, or
any house material before both are sealed.

### Attack assignment summary (identical in both arms)

| Attack | Lead | Support | Notes |
|---|---|---|---|
| GS4-A Claim reconstruction (12-claim sample) | A | B, D | Reconstructions from home text + dependencies only |
| GS4-B Badge blind test | C | — | Blind packet §5.3; sealed before reveal |
| GS4-C Dependency break | C | B | One dependency removed at a time |
| GS4-D Proof–code separation | C | B | Two deliverables per hybrid claim, mutually non-citing |
| GS4-E Mutation battery | Mutation runner | D of both arms (split witness, §8.3) | §8; pre-registered, no additions |
| GS4-F Alternative representatives | B | A | Same Paper 2 differentiae + declared identification; which K components are forced vs chosen |
| GS4-G Reader-only reconstruction | A | — | Paper + declared sources only; no scripts, no outputs; log every point needing hidden knowledge |
| GS4-H Change-log integrity | C | — | Selection rule §6.1 |
| GS4-I Physical bridge firewall | A | C | Every Stage P item in the sample: calibration, bridge sentence, empirical input, uncertainty — and whether any Stage N result is presented as if the bridge were measured |
| GS4-J Competing explanations | A | — | Per physical-facing sampled claim: an alternative model producing the same observation, the discriminating measurement, its precision, and what counts against the framework. If none can be supplied, the claim gets no empirical acceptance verdict — recorded as such, not as a defect of the native claim |

---

## 7. The twelve-claim sample — deterministic selection (one sample, both arms)

The sample is chosen by rule, not by hand, **once**, and is **identical for
both arms**. The coordinator does not pick, swap, or veto claims.

7.1 **Composition (fixed quotas, per the proposal):** 4 native definitions
or theorems; 3 counting/statistical claims; 2 ordering or composition
claims; 2 hybrid [LEVEL A: MACHINE / AUTHOR] claims; 1 author declaration.

7.2 **Category assignment.** Each registry claim is assigned to exactly one
category by the first matching rule, applied in this order: (i) badge is
the hybrid mark → *hybrid pool*; (ii) home section is §11 or the claim
concerns the K ordering, representatives, or the molecule reduction →
*ordering/composition pool*; (iii) home section is §§5, 7, 8, or 9, or the
claim concerns census, joint counts, temperature, or assignment counts →
*counting/statistical pool*; (iv) the claim is a stated author declaration
or declared identification → *author-declaration pool*; (v) otherwise →
*native definition/theorem pool*. A claim consumed by an earlier quota is
removed from later pools; quotas are filled in the order hybrid,
author-declaration, ordering/composition, counting/statistical, native.

7.3 **Ranking within a pool (dependency centrality).** The packaging script
parses Appendix B and the claim lists and builds the stated-dependency
graph: an edge X→Y exists when claim X's registry row or claim-list entry
names claim Y, a falsification condition (C23–C33), a receipt, or a declared
premise in its dependency/pricing text. A claim's centrality score is
(inbound edges from other claims) + (inbound edges from falsification
conditions) + (outbound edges to source-paper premises). Higher score
ranks first; ties break by claim ID, ascending lexicographic order. The
script, its parsed edge list, every score, and the resulting sample are
saved to `gs4/packet/sample_selection.txt` and hashed into the freeze
record. The sample is final once the freeze record is written; a selection
dispute is a spec defect (SD-n), recorded, never silently re-picked.

7.4 **Mandatory additions (outside the twelve).** Independently of the
sample, the examiners of each arm also cover: every hybrid-split Level A
claim (Role C's split audit is over all of them, not only the sampled two,
for GS4-D's allocation question only); every declared assumption consumed
by a sampled claim; every direct external dependency of a sampled claim.
Unexamined claims remain unexamined; no global verdict may be inferred
from the sample.

---

## 8. Mutation battery (GS4-E) — pre-registered

### 8.1 Rules

Mutations are applied **only to a working copy** (`gs4/mutations/tree/`) of
the frozen paper and its extracted scripts; the frozen copy is never
mutated. The list below is complete and frozen with this spec: no mutation
may be added, dropped, or widened after the freeze. Each entry names its
expected catching control **in advance**; where no control is expected,
that absence is declared a scope boundary **before** execution. A mutation
whose expected control does not fire is a finding; a mutation in the
declared no-control class that no control fires on is a confirmed scope
boundary, not a finding and not a pass. The battery is run **once**; its
log is available to the adjudicator for both arms' relevant attacks (§10).

### 8.2 The mutations

| ID | Mutation (applied to the working copy) | Expected catching control |
|---|---|---|
| M1 | In A.15's INPUT_PROVENANCE, relabel one paper-defined binding as cited-paper (the Y2 shape) | F.49-style provenance check if wired in the suite; else **no control expected — declared scope boundary** (provenance-class accuracy of A.15 rests on audit, recorded before execution) |
| M2 | In a hybrid claim's Appendix B row, move one prose-carried general clause from the AUTHOR leg to the MACHINE leg (the L8.3 shape) | H.1 registry-vs-home check — expected to catch only if the home/row badge strings differ; for a pure split move with badge string unchanged: **no control expected — declared scope boundary** |
| M3 | Delete one Appendix B registry row while its claim remains in the claim list | H.1 (claim/registry bijection) |
| M4 | Alter one numeric value in the Appendix F fixture, leaving all expected outputs unchanged | A.15 check comparing fixture to both computation paths |
| M5 | Replace one embedded script listing with its previous round's version (stale listing) | A.9 (listing byte-identity / manifest) |
| M6 | Edit a claim's scope sentence in the paper body and make no version-history entry for it | **No control expected — declared scope boundary** (change-log completeness is Role C's GS4-H audit, not a script control) |
| M7 | Strengthen one claim's badge in its claim-list entry only, above its weakest dependency | H.1 (registry-vs-home badge reproduction) |
| M8 | Feed an empty population declaration to the Spine generator that normally supplies nonempty data | A.15's own input handling — expected behaviour: explicit rejection or a stated empty-case result; a crash or a silent nonempty assumption is the finding |
| M9 | Construct two populations whose CenSig values stand in a proper-prefix relation and compare them under K | A.14's comparison plus §11.3's stated prefix convention — expected: the convention decides, no exception |
| M10 | Relabel every body in a Spine population (permuted names), leaving records unchanged | A.15/A.14 invariance checks — expected: identical K components and census ratios |
| M11 | Shift one joint-count window so an offset straddles the window split | A.12 / Proposition 5.9(ii)'s stated horizon reading — expected: counts as the proposition's stated form requires, no double count |
| M12 | Introduce a multi-sided junction whose consumed-port count differs from its side count, at the C33 boundary | A.14's stated domain handling — expected: handled as outside A.14's domain per its disclosure, with C33's scoped text not firing |
| M13 | Corrupt one source hash in the packet manifest copy used by Role D | Role D's Gate 1 hash verification — expected: mismatch detected before any run |
| M14 | Duplicate one population member (same name, same record, twice) in a Spine declaration | A.15/A.12 declaration validation — expected: rejection or a stated duplicate rule; silent double-counting is the finding |
| M15 | Remove one dependency edge from a sampled claim's registry row (text edited, graph edge gone) | **No control expected — declared scope boundary** (dependency completeness is Role C's GS4-C audit) |
| M16 | Change one tick window in a §5 joint-count example so an event crosses the window boundary mid-count | A.12 — expected: the declared-horizon rule decides the count |
| M17 | In one script, make a check test a proxy (string presence) instead of its claim's computed quantity, keeping its output text identical | Role D's content-vs-shape determination (Role D item 6) — **no script control expected; the control is the examiner** |
| M18 | Insert a Stage P bridge word into a native Stage N definition sentence | FW.1 firewall sweep |
| M19 | Omit one declared assumption's name at one load-bearing use site (body text edited) | **No control expected — declared scope boundary** (Role C item 5 audit) |
| M20 | Reorder two deciding components of K in A.14's key tuple | A.14's representative/order checks — expected: failures on the representative comparisons |
| M21 | Change one sign in Table 5.1's received sign facts as printed in §11.3's representatives | A.14 / §11.3 representative checks — expected: at least one representative comparison fails |
| M22 | Give one junction two incompatible standings via a multi-sided record read through the pairwise rule | A.12/Def 5.7 legality checks — expected: rejection as an illegal record, or a stated precedence rule decides |
| M23 | Truncate one verbatim quotation in §11.3 mid-phrase, leaving its G.1 punctuation pattern plausible | G.1 quote-integrity check |
| M24 | Replace the §6.1 bonding-mode premise's receipt wording with a citation wording ("Paper 2 proves…") at one consumption site | FW.1/G.1-class wording checks if the shape is swept; else **no control expected — declared scope boundary** (Role C audit) |

### 8.3 Mutation run protocol — gold addition: split witnessing

The mutation runner applies each mutation to a fresh copy of the working
tree, runs the full suite plus any examiner-specified check named in the
expectation, and records: mutation ID, exact diff, controls run, observed
behaviour, expectation met / not met / boundary-confirmed. **Witnessing is
split across the arms** (gold addition): Role D of Arm N witnesses M1–M12
and Role D of Arm H witnesses M13–M24, each countersigning the half it
witnessed, after its own arm's submissions are sealed (witnessing is not
examination; a witness sees the mutation log for its half only, never the
other arm's submissions). Splitting the witness duty means no single arm's
examiner vouches for the whole battery, and a witness dispute is itself
recorded. The log seals to `gs4/mutations/RUN_LOG.md` (with diffs and both
countersignatures) before adjudication. The runner proposes no badges.

---

## 9. Evidence standard, verdict rules, and the five categories

### 9.1 Attack record (required fields, every attack)

Attack ID and target claim; exact target text and location (section and
line in the frozen paper); claim domain and required property; source files
used with verified hashes; method and complete test space; the executable
program and inputs wherever computation is involved; output and logs; for
a proposed BROKE, the independent second route (§9.3); a five-part coverage
map — **(1) native domain, (2) verified domain, (3) the map between them,
(4) what the map preserves, (5) what stays outside the check**; the
finding's category under §9.5 (self-classified by the filing examiner,
verified by the adjudicator); proposed badge and reason. No count is
accepted without its producing artifact; no hash without independent
recomputation; no source is marked READ unless the examiner actually
inspected it; a missing source is a coverage boundary, not evidence against
a claim, unless the paper asserts the source is present.

### 9.2 Verdicts (claim status)

- **HELD** — independently reconstructed or reproduced over the stated
  domain; no counterexample found within that verified domain. Never means
  physically true.
- **BROKE** — a reproducible witness or logical contradiction against the
  claim as written, all preconditions satisfied, second route confirming.
- **LIMIT** — evidence supports only a proper subset of the stated domain,
  or the claim cannot be decided at the available scope; the exact boundary
  is named.
- **OUTSIDE** — the tested property is not asserted by the target claim.

Verdicts are never summed into a score or percentage; one broken
load-bearing claim is not cancelled by any number of held bookkeeping
checks.

### 9.3 Second-route rule

Every BROKE requires reproduction by a route independent of the first: a
different implementation, an analytic derivation, or a direct textual
witness pair (home vs registry, script block vs script block) verifiable
by inspection. The adjudicator checks the second route exists and is
genuinely independent before sustaining; a single-route BROKE is
downgraded to LIMIT with the reason recorded.

### 9.4 Process status (kept separate from claim status, always)

`READ / NOT READ`, `RUN / NOT RUN`, `REPRODUCED / NOT REPRODUCED`,
`SOURCE-VERIFIED / SOURCE-REPORTED`, `SEALED / UNSEALED`. NOT RUN is a
process status, never a badge. No report may let a process word do a
verdict's work or a verdict do a process word's work. **Neither an
examiner's confidence nor an arm's identity is evidence** (§10.1).

### 9.5 The framework-translation classification — five categories, never merged

*(Refinement from GPT-6's review of the two-arm design, adopted by the
author.)* Every finding filed by either arm — every Arm H objection and,
for symmetry, every Arm N finding — must be classified into **exactly one**
of five categories. The categories must not be merged, averaged, or
blended:

- **(A)** A genuine contradiction under MSDS's own rules.
- **(B)** A missing derivation required by a claim.
- **(C)** An unestablished bridge from the discrete mathematics to physical
  measurement.
- **(D)** A disagreement over mathematical foundations or ontology.
- **(E)** A question the paper explicitly leaves open.

**Badge mapping (binding):**

| Category | Can it sustain a BROKE against a claim as written? | Disposition |
|---|---|---|
| A | **Yes** — with witness and second route (§9.3) | Defect; author's list |
| B | **Yes** — where the claim asserts the establishment the missing derivation was required for | Defect; author's list |
| C | **No** | Bridge verdict: LIMIT or OUTSIDE, per the target claim's own Stage discipline (a native claim that asserts no bridge cannot be broken by the bridge's absence; a Stage P claim that asserts one is judged by what it asserts) |
| D | **No — never a defect** | Recorded as a framework disagreement |
| E | **No — never a defect** | Recorded as an open question the paper itself declares |

The filing examiner self-classifies; **the adjudicator verifies the
category as part of adjudication** (§10.3). A mis-categorized finding is
re-categorized **in the open**: the adjudication record prints the original
category, the corrected category, and the reason. Category verification is
not a courtesy check — most hostile-arm volume is expected to arrive as
category D in substance, and the record must show the sorting, finding by
finding.

---

## 10. Blind adjudication

*(Refinement from GPT-6's review, adopted by the author; replaces the
adjudication design of the v0 house draft, in which the adjudicator saw
attributed submissions.)*

### 10.1 The rule

The adjudicator examines every alleged failure **without seeing which
agent or arm produced it**. Neither the gatekeeper's confidence nor the
defenders' confidence may function as evidence; neither may an arm's
reputation, an examiner's fluency, or the volume of an arm's filings.

### 10.2 Anonymization

After all eight submissions and the mutation log are sealed (§2.4, §8.3),
and before the adjudicator is spawned, the packaging/routing step produces
the adjudication packet:

1. Every finding in every submission is extracted onto a **finding card**:
   the finding's complete argument text, its witnesses and artifacts, its
   coverage map, its self-classified category (§9.5), and its proposed
   badge — with **arm labels, role labels, and examiner identities
   stripped**, and the finding re-keyed to a fresh identifier (`GS4-F-001`,
   `GS4-F-002`, …) assigned in an order that does not encode arm, role, or
   filing order.
2. **Argument text is never edited.** Anonymization removes headers,
   labels, and identifying metadata only. A card whose argument text
   differs from the sealed original in any character is void and must be
   regenerated.
3. The re-keying map is written to `gs4/adjudication/KEY_SEALED.md`,
   hashed, and held by the coordinator. It is opened only after the
   adjudicated badges are frozen (§10.4).
4. Hold-out material that is not a finding (reconstructions, run logs,
   graphs, tables) reaches the adjudicator likewise anonymized where it
   serves as evidence for a card, and in full anonymized form for the gate
   assessments (§14).

### 10.3 The adjudicator's work

One adjudicator, spawned fresh, who ran no attack. Working only from the
anonymized cards, the frozen paper (full, unblinded), and the mutation
log, the adjudicator, for each card: (i) verifies the category (§9.5) and
re-categorizes in the open where wrong; (ii) applies the single evidence
standard of §9 (coverage map present and honest; witness complete;
second route present and independent for any BROKE); (iii) assigns the
adjudicated badge; (iv) records the evidence that sustained or defeated
the finding, quoting the argument where its exact wording matters. The
adjudicator applies the **strict rule in reverse**: a finding that fails
the three-part test of §3 (exact claim / requirement of the claim /
failure under declared premises) is category D in substance whatever its
self-classification, and is recorded as such.

### 10.4 Freezing the badges

The adjudicator's output, `gs4/adjudication/GS4_ADJUDICATION_BLIND.md`
(per-card: key, verified category, badge, evidence), is hashed and sealed.
**Badges are frozen at this moment.** Nothing after this step — not
unblinding, not the charter-integrity audit, not report assembly — may
change a badge. A badge change after freezing is a new trial, not an edit.

### 10.5 Unblinding and the side-by-side record

Only after §10.4: the coordinator opens `KEY_SEALED.md` and assembles the
attributed record. The final report (§15.5) prints, **per attack**: both
arms' proposed badges side by side, each arm's findings with their
verified categories, the adjudicated badge, and — where Arm H made an
argument — the Arm H argument quoted and the evidence that sustained or
defeated it. The blind phase is itself documented in the report (card
count, re-categorization count, the anonymization verification), so a
reader can confirm the adjudicator decided without knowing the arms.

---

## 11. Charter-integrity audit — auditing the corruption itself

The hostile arm proves something only if its hostility is **demonstrable
in the record**, not merely declared in its charter. This audit checks
that. It runs **after** blind adjudication, on unblinded material, and can
change no badge.

11.1 **Sequencing (binding).** Blind adjudication (§10) completes and
badges are frozen (§10.4) → unblinding (§10.5) → **then** the
charter-integrity audit. Running it earlier would contaminate the blinding;
running it as part of adjudication would let arm identity function as
evidence, which §10.1 forbids.

11.2 **Meta-auditor.** A separate spawned agent, distinct from the
adjudicator, the examiners, and the mutation runner, working from the
**sealed, still-attributed original submissions** of both arms (never from
the anonymized cards — attribution is the object of this audit).

11.3 **Measures (all reported as counts over the sealed record):**

1. BROKE proposals per arm (H vs N), and per role within Arm H.
2. BROKE-first compliance in Arm H: the fraction of Arm H findings whose
   text constructs the defect argument before any defence is considered
   (the overlay's §3 item 2 made visible).
3. Hostile-reading invocations: Arm H findings that expressly adopt the
   least-favourable reading (overlay §3 item 3), counted, with sites.
4. Concessions: Arm H arguments talked down by evidence within the finding
   itself (a concession is the overlay working as designed — argued BROKE
   first, conceded where forced — not a failure of hostility).
5. Strict-rule compliance: the fraction of Arm H objections meeting all
   three parts of the strict rule (§3), and the fraction re-categorized to
   D by the adjudicator.
6. Concealment/retreat probes: Arm H findings that expressly test a
   disclosure for what it omits or a scope statement for what it excludes
   (overlay §3 item 4), counted.

11.4 **Verdict.** The meta-auditor states one of: **HOSTILITY
DEMONSTRATED** (the measures show BROKE-first, hostile-reading behaviour
materially beyond Arm N's baseline), **HOSTILITY PARTIAL** (some measures
positive, some absent), or **HOSTILITY NOT DEMONSTRATED** (Arm H's record
is indistinguishable in stance from Arm N's). If the verdict is not
DEMONSTRATED, the report states plainly that the hostile arm's evidentiary
value is reduced accordingly — the ace counts only if the hatred is in the
record. The audit's full counts are printed in the report's
charter-integrity section and included in the published package (§13).

---

## 12. Gold additions — what changed, and whose it is

For the record (and for GPT-6, reading the show-kit): the design's
provenance, element by element.

**From GPT-6's original GS-4 proposal:** the four roles and their required
work; attacks GS4-A…J; the twelve-claim sample with examiner-side selection
discipline (here: deterministic rule, §7); the badge blind test; the
dependency-break test; proof–code separation; the pre-registered mutation
battery with catch-expectations declared in advance; the evidence standard
and five-part coverage map; the verdict rules and the ban on summing
badges; claim-status vs process-status separation; the eight acceptance
gates; Gate 8's separation of internal verification from physical
validation.

**From the author's rulings (2026-10-31):** execution in-house with
spawned agents; **the second, hostile arm** (Arm H, the gatekeeper charter,
§3); **no human examiners** — the decisive human stage declined, recorded
at §1; gold-standard versioning of the protocol itself (this document);
GS-4 as the pre-publication cleanup gate, with the trial record published
with the paper (§13, §16).

**From GPT-6's review of the two-arm design, adopted by the author:** the
gatekeeper's stance specified as the continuous-calculus/conventional
arsenal (§3); the **strict rule** binding the hostile arm (§3); **blind
adjudication** (§10) replacing attributed adjudication; the **five-category
framework-translation classification** with its badge mapping (§9.5);
**publish-everything** (§13).

**House gold additions (mechanisms the house architecture makes real):**
the **charter-integrity audit** (§11) — the corruption itself is audited,
from sealed attributed originals, after badges are frozen; the
**divergent-reading K implementations** (§6.2) — each arm's Role D
implements K from its own reading of §11.3, and disagreement between the
implementations is itself filed as evidence about the text's determinacy;
**split mutation witnessing** across the arms (§8.3); the anonymization
mechanics of §10.2 (re-keyed finding cards, argument text never edited,
sealed key); the deterministic sample rule of §7 executed by script so no
party — coordinator included — can steer the sample.

---

## 13. Publish-everything commitment

*(Refinement from GPT-6's review, adopted by the author.)*

The trial's full record is a **publishable package, built alongside
execution** — not a summary written afterward. It contains the favourable
and the unfavourable alike: failures, successful defences, inconclusive
attacks, agent disagreements, test code, logs, versions, and corrections.
Nothing is published selectively.

**Package contents (exhaustive):**

1. This spec, at the version frozen for the run, plus any SD-n spec-defect
   notes recorded during execution.
2. The freeze record (§4.2), with all hashes.
3. The examiner packet manifest and the blind-packet generation record,
   including `blind_verification.txt`.
4. The sample-selection record (§7.3): script, edge list, scores, sample.
5. All eight sealed submissions (N and H, all roles), including Role C's
   blind classifications and reveal addenda from both arms, with their
   seal hashes.
6. The mutation battery: the pre-registered list as frozen, every diff,
   the run log, both witness countersignatures.
7. The anonymized finding cards, the blind adjudication
   (`GS4_ADJUDICATION_BLIND.md`), and — after unblinding — the key,
   published with the package (its secrecy ends at §10.4).
8. The charter-integrity audit (§11), with full counts.
9. The final report (§15.5), including the per-attack side-by-side record,
   the author's list, retained boundaries, and the gate table.
10. All test code written by any examiner or the mutation runner, with
    inputs, outputs, and environment records.
11. Any corrections issued after the report, appended as dated
    corrections — never edited into the originals.

**Sequencing (the author's):** GS-4 is the pre-publication cleanup gate —
its author's list is disposed of before publication (§16) — and **the
author publishes this trial record with the paper**. A reader of the paper
can reach the full record of both arms, including every defeated hostile
argument and every sustained one.

---

## 14. Acceptance gates

Assessed by the adjudicator from the anonymized evidence where a gate
concerns findings, and completed after unblinding where a gate concerns
attribution (Gate 3's discrepancy record, the charter-integrity input to
Gate 4). A gate is marked PASS, FAIL, or NOT DECIDED (with the deciding
evidence named) — never inferred from another gate.

| Gate | Test | Evidence owned by |
|---|---|---|
| 1 — Identity | Frozen release, hashes, source versions, environment independently verified | Role D (both arms) |
| 2 — Reconstruction | Native definitions and selected load-bearing derivations reconstructed without private author knowledge | Roles A, B (both arms) |
| 3 — Badge honesty | Blind classifications match the paper's evidence, or every discrepancy is resolved and recorded | Role C (both arms) + adjudicator |
| 4 — Computational independence | Selected machine results reproduce through second implementations (including the divergent-reading K comparison, §6.2); mutation tests show the controls can fail when expected | Role D (both arms) + mutation log |
| 5 — Dependency integrity | Sampled claim graphs have no omitted load-bearing dependencies; no claim outranks its weakest dependency | Role C (GS4-C, both arms) |
| 6 — Change integrity | Sampled changes trace old text → new text, with corresponding tests and dispositions | Role C (GS4-H, both arms) |
| 7 — Falsification reach | An independent-context reader can identify a real falsifier for every selected Level A claim, or the paper explicitly names the boundary where none is available | Roles A, C (both arms) |
| 8 — Physical separation | No native or computational pass is presented as experimental confirmation without an independent physical bridge and a discriminating observation | Roles A (GS4-I/J, both arms) + adjudicator |

Per-arm readings are recorded where a gate's evidence differs by arm; the
joint assessment closes the gate table. Passing Gates 1–7 with Gate 8 open
is the expected maximum outcome of this trial and is reported as exactly
that.

---

## 15. Execution order and deliverables

1. **Packaging** — packet built per §5; blind packet generated and
   verified per §5.3; sample selected per §7. (Coordinator + packaging
   step.)
2. **Freeze record** — §4.2 completed and written. Nothing runs before
   this.
3. **Role submissions** — all eight examiners (both arms) spawned in
   parallel with certified briefs (§2.2); each seals per §2.4. Each arm's
   Role C blind classifications seal before its reveal pass; the reveal
   addenda seal separately.
4. **Mutation runs** — §8.3, on copies, witnessed per the split-witness
   protocol; the log seals before adjudication.
5. **Anonymization** — finding cards produced and verified per §10.2; the
   key seals.
6. **Blind adjudication** — §10.3; output hashed and sealed (§10.4).
   **Badges are frozen here.**
7. **Unblinding and report assembly** — §10.5: the coordinator opens the
   key and assembles `gs4/GS4_REPORT.md`: the §1 honesty label repeated
   verbatim at its head; per-attack side-by-side record (both arms'
   proposals, verified categories, adjudicated badge, Arm H arguments
   quoted with the evidence that sustained or defeated them); the author's
   list (findings only, no repairs); retained LIMIT/OUTSIDE boundaries;
   the process-status table; the gate table (§14); the blind-phase
   documentation.
8. **Charter-integrity audit** — §11, by the meta-auditor, from the sealed
   attributed originals; appended to the report as its own section (it may
   not alter step 7's badges or findings record — it characterizes the
   arms, it does not re-judge the paper).
9. **Publishable package** — assembled per §13 alongside steps 1–8, not
   reconstructed afterward.

Deliverables live in `~/workspace/your_files/paper_12_draft/gs4/`. The
frozen paper, submissions, mutation log, cards, and audits are retained
permanently as the trial's evidence; none is overwritten by any later
round (a re-run gets a new directory suffix with its own freeze record).

---

## 16. What the house does with the results

- The GS-4 report and author's list go to the author. **No repair is
  enacted on the basis of GS-4 alone**; repairs require the author's
  ruling, item by item, as with every prior battery. A BROKE sustained
  from Arm H enters the author's list identically to one from Arm N — the
  arm of origin is recorded, the standing is the same.
- GS-4 is the **pre-publication cleanup gate** per the author's rulings of
  2026-10-31: its author's list is disposed of (repaired on ruling, or
  explicitly accepted as a retained boundary) before publication, and the
  trial record is published with the paper (§13).
- Proposed badges from GS-4 are recorded as GS-4 Gold's own record,
  disclosed alongside prior batteries with the §1 label attached; they do
  not replace or silently merge with GS-3/KD-1 outcomes.
- Spec defects discovered during execution are logged as SD-n in the
  report, named, never silently repaired mid-run; a defect that voids a
  run's isolation (§2.5 breach, unsealed cross-reading, packet
  contamination, anonymization failure) voids that run and is reported as
  such.

---

## 17. What this spec could not operationalize

Named honestly, so the gaps are on the record rather than smoothed over:

1. **Independent human examiners.** The proposal's decisive stage calls
   for two independent humans (discrete mathematics/computation; physics/
   statistical mechanics). The author has **declined** this stage (§1) —
   recorded here as his decision, with its consequence: this trial's
   independence is informational, not personal, and its results carry the
   strength of that and no more. The human stage remains available to the
   author at any time and is not replaced by this trial.
2. **Empirical content of Gate 8 / GS4-J.** No experiment can be run
   in-house. GS4-I/J as specified audit the bridge text, name the
   discriminating observations and their required precision, and police
   the presentation boundary — they do not and cannot produce the
   observations.
3. **Model-family independence.** Examiners of both arms share the house
   model family (§1). Isolation here is informational (context, kits,
   verdicts, cross-reading), which is enforceable and verified;
   architectural independence (a different model family, let alone humans)
   is not achievable with spawned house agents. Arm H's hostility is a
   charter stance executed by agents of the same family that wrote Arm N's
   charters; the charter-integrity audit (§11) exists precisely because
   declared hostility from within one family must be *demonstrated*, and
   may fail to materialize.
4. **A truly clean environment for Role D.** Role D runs in a fresh
   working directory on the house machine with the house interpreter; the
   environment record (Role D, §6) states exactly what the environment
   was, and no claim of platform diversity is made.
5. **Perfect anonymization.** §10.2 strips labels and metadata and never
   edits argument text; an argument's *style* may still hint at its arm
   (an Arm H finding written under the overlay will read hostile). The
   blinding therefore removes identity as a *label*, and §10.1 binds the
   adjudicator to disregard stance as evidence — but the spec does not
   claim the adjudicator cannot guess. What the design guarantees is that
   a guess carries no procedural weight: categories and witnesses decide,
   and the adjudication record must cite them, card by card.
