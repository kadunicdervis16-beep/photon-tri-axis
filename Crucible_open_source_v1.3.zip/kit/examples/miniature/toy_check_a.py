#!/usr/bin/env python3
"""Toy checker A -- counts, moves, conservation, diagonals.

Checks (toy_v2.md): T1.1-T1.3, T2.1-T2.2 (v2 scope: moves and adjacent
swaps), T3.1-T3.5. Stdlib only.

INPUT_PROVENANCE
  positions : paper-defined (P0 is DECLARED RECEIPT R1, toy_v2 section 6;
              the other positions are declared test fixtures below)
  rules     : paper-defined (toy_v2 sections 1-3)
  mutants   : control (planted spec violations, see below)

Planted mutants (genuine spec violations, must be REJECTED with witness):
  MUTANT-A1  a "move" that copies a pebble instead of relocating it --
             violates T1.3 (one pebble per cell is kept, but the source
             cell stays occupied) and T2.2 (total count grows by 1).
  MUTANT-A2  a diagonal count that counts the centre cell TWICE in the
             distinct-diagonal-cells total -- violates T3.5's identity.
"""
import sys

CELLS = [(r, c) for r in range(3) for c in range(3)]
COLOURS = {"red", "blue"}

# P0: DECLARED RECEIPT R1 (carried by declaration, not derived).
P0 = {(0, 0): "red", (0, 1): "blue", (1, 1): "red"}
FIXTURES = [
    P0,
    {(2, 2): "blue"},
    {(0, 0): "red", (0, 2): "blue", (1, 1): "blue",
     (2, 0): "red", (2, 2): "red"},
    {},
]


def counts(pos):
    total = len(pos)
    red = sum(1 for v in pos.values() if v == "red")
    blue = sum(1 for v in pos.values() if v == "blue")
    return total, red, blue


def check_position(pos):
    assert all(cell in CELLS for cell in pos), f"off-board cell in {pos}"
    assert all(v in COLOURS for v in pos.values()), f"bad colour in {pos}"
    total, red, blue = counts(pos)
    assert red + blue == total
    rows = [sum(1 for (r, _), v in pos.items() if r == i) for i in range(3)]
    cols = [sum(1 for (_, c), v in pos.items() if c == i) for i in range(3)]
    assert sum(rows) == total, f"T3.1 row sum {rows} != total {total}"
    assert sum(cols) == total, f"T3.2 col sum {cols} != total {total}"
    for colour in COLOURS:
        cr = [sum(1 for (r, _), v in pos.items() if r == i and v == colour)
              for i in range(3)]
        assert sum(cr) == counts(pos)[1 if colour == "red" else 2], "T3.3"
    main = [(i, i) for i in range(3)]
    anti = [(i, 2 - i) for i in range(3)]
    dm = sum(1 for cell in main if cell in pos)
    da = sum(1 for cell in anti if cell in pos)
    distinct = len({*main, *anti} & set(pos))
    centre = 1 if (1, 1) in pos else 0
    assert dm + da <= total + centre, "T3.4"
    assert dm + da == distinct + centre, (
        f"T3.5 diagonal identity fails: {dm}+{da} != {distinct}+{centre}")
    return total, red, blue


def do_move(pos, src, dst):
    assert src in pos and dst not in pos
    assert abs(src[0] - dst[0]) + abs(src[1] - dst[1]) == 1, "T2.1 adjacency"
    new = dict(pos); new[dst] = new.pop(src); return new


def do_swap(pos, a, b):
    assert a in pos and b in pos
    assert abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1
    new = dict(pos); new[a], new[b] = new[b], new[a]; return new


def main():
    for pos in FIXTURES:
        check_position(pos)
    # T2.2 (v2 scope): a move and an adjacent swap each preserve counts.
    after_move = do_move(P0, (0, 0), (1, 0))
    assert counts(after_move) == counts(P0), "T2.2 move conservation"
    pos2 = {(0, 0): "red", (0, 1): "blue"}
    assert counts(do_swap(pos2, (0, 0), (0, 1))) == counts(pos2), "T2.2 swap"
    print("toy_check_a: T1.1-T3.5 PASS on "
          f"{len(FIXTURES)} positions (incl. receipt P0)")

    # MUTANT-A1: copy instead of move -> total grows 3 -> 4.
    mutant = dict(P0); mutant[(1, 0)] = mutant[(0, 0)]  # source kept
    try:
        assert counts(mutant) == counts(P0), (
            f"conservation violated: before={counts(P0)} after={counts(mutant)} "
            f"witness cell (0,0) still occupied and (1,0) newly occupied")
        print("MUTANT-A1: NOT REJECTED (FAIL)")
        return 1
    except AssertionError as e:
        print(f"MUTANT-A1: REJECTED -- {e}")

    # MUTANT-A2: centre double-counted in distinct-diagonal total.
    pos = FIXTURES[2]
    dm = sum(1 for i in range(3) if (i, i) in pos)
    da = sum(1 for i in range(3) if (i, 2 - i) in pos)
    centre = 1 if (1, 1) in pos else 0
    distinct_true = len(({(i, i) for i in range(3)} |
                         {(i, 2 - i) for i in range(3)}) & set(pos))
    distinct_bad = distinct_true + centre  # mutant: centre counted again
    if dm + da == distinct_bad + centre:
        print("MUTANT-A2: NOT REJECTED (FAIL)")
        return 1
    print(f"MUTANT-A2: REJECTED -- T3.5 witness: {dm}+{da} != "
          f"{distinct_bad}+{centre} (mutant distinct={distinct_bad} vs "
          f"true distinct={distinct_true}; centre (1,1) double-counted)")
    print("toy_check_a: ALL PASS, mutants rejected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
