clean placeholder
