# MINIATURE RUN LOG — every run, command and actual output

Workstream 8, 2026-10-31. Working directory for all toy runs:
`~/workspace/your_files/paper_12_draft/glm_additions/miniature/`
Outputs below are verbatim (long outputs trimmed only where marked
`[…]`; verdict lines are never trimmed).

Toy inventory: toy_v1.md = 15 claims; toy_v2.md = 16 claims;
changes v1→v2 = 4 (badge TR-001, hybrid split TR-002, scope TR-003,
new claim TR-004); declared receipt R1 (claim T6.1's premise);
open debt D1 (reversibility, discharge condition in toy §6, unmet).

---

## 1. Toy verification scripts (own checks + planted mutants)

### 1a. `python3 toy_check_a.py` — exit 0
```
toy_check_a: T1.1-T3.5 PASS on 4 positions (incl. receipt P0)
MUTANT-A1: REJECTED -- conservation violated: before=(3, 2, 1) after=(4, 3, 1) witness cell (0,0) still occupied and (1,0) newly occupied
MUTANT-A2: REJECTED -- T3.5 witness: 3+3 != 6+1 (mutant distinct=6 vs true distinct=5; centre (1,1) double-counted)
toy_check_a: ALL PASS, mutants rejected
```

### 1b. `python3 toy_check_b.py` — exit 0
```
toy_check_b: T4.1, T4.2, T5.1, T5.2 PASS (50 shuffled orderings; P0 score = 5)
MUTANT-B1: REJECTED -- T4.1 witness at index 1: column-major gives (1, 0), canonical gives (0, 1)
MUTANT-B2: REJECTED -- T5.1 witness: weights (1,1) give score(P0)=3, spec weights (2,1) give 5
toy_check_b: ALL PASS, mutants rejected
```

---

## 2. Sample selection (Crucible kit tool — landed before this run)

Command:
```
python3 ~/workspace/your_files/paper_12_draft/gs4/open_source/kit/tools/sample_selection.py \
    --registry registry_v2.tsv --out sample_selection_out.txt
```
Adaptation required: **only its documented input adaptation** — the toy
registry was transcribed into the tool's TSV shape
(`templates/REGISTRY_INPUT.tsv`: claim_id / category / badge /
home_section / dependencies / named_by_conditions). No toy content was
changed to fit the tool; categories were pre-filled from the toy's own
section structure, which the template explicitly permits.
Result — exit 0 (full record in `sample_selection_out.txt`):
```
CRUCIBLE -- SAMPLE SELECTION RECORD (deterministic; spec section 7)
Registry claims parsed: 16; edges: 19.
Quotas: {'hybrid': 2, 'declaration': 1, 'ordering': 2, 'counting': 3, 'native': 4}; fill order: hybrid, declaration, ordering, counting, native.
[…]
SCORES (claim: inbound_claims + inbound_conditions + outbound_src = centrality):
  T1.3: 6 + 0 + 0 = 6  [pool: native via registry]
  T1.2: 3 + 0 + 0 = 3  [pool: native via registry]
  T1.1: 2 + 0 + 0 = 2  [pool: native via registry]
  T3.3: 2 + 0 + 0 = 2  [pool: counting via registry]
[…]
THE SAMPLE (12 claims, fill order hybrid, declaration, ordering, counting, native):
  T5.1  [pool: hybrid; score: 0]
  T5.2  [pool: hybrid; score: 0]
  T6.1  [pool: declaration; score: 0]
  T4.1  [pool: ordering; score: 1]
  T4.2  [pool: ordering; score: 0]
  T3.3  [pool: counting; score: 2]
  T3.1  [pool: counting; score: 1]
  T3.4  [pool: counting; score: 1]
  T1.3  [pool: native; score: 6]
  T1.2  [pool: native; score: 3]
  T1.1  [pool: native; score: 2]
  T2.1  [pool: native; score: 1]
Sample JSON: ["T5.1", "T5.2", "T6.1", "T4.1", "T4.2", "T3.3", "T3.1", "T3.4", "T1.3", "T1.2", "T1.1", "T2.1"]
```
**Verdict: PASS, paper-agnostic as documented.** The receipt dependency
was honestly recorded as `T6.1 -> receipt:R1 [receipt-unexpanded]`
(no indirections file was supplied, and the tool said so in its own
edge list rather than dropping it).

---

## 3. Reverse-dependency oracle (`../oracle/reverse_deps.py`) — FINDING

The tool landed during this workstream. Its docstring states it is the
oracle "for Paper 12 (round-11 tree)" and locates its paper via three
hardcoded candidate paths or the `PAPER12_PATH` environment variable.
That env override is the only input convention by which it can be
pointed at another paper, so it was used for every toy run below.

### 3a. Control — the tool works on its home paper (no-arg, default)
```
$ python3 ../oracle/reverse_deps.py
Top load-bearing nodes (by transitive dependent claims; then all transitive dependents, then direct dependents)
node                                                       type       depClaims depAll direct  badge/desc
A.2                                                        script            14     14      7  parallel-T well-definedness
Paper 2 §8.1                                               premise           11     13      1
G.1                                                        script            11     12      4  quote integrity
[…]
```
Also: `python3 ../oracle/reverse_deps.py --help` does not print help;
it treats `--help` as a node name: `unknown node: --help` followed by
the Paper 12 script list (`known scripts: A.1, …, Paper 11 script F.37`).

### 3b. Script→dependents query against the toy — FAILS (crash)
```
$ PAPER12_PATH=$PWD/toy_v2.md python3 ../oracle/reverse_deps.py toy_check_b
Traceback (most recent call last):
  […]
  File "../oracle/reverse_deps.py", line 298, in build_graph
    appb = next(i for i, l in enumerate(lines)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
StopIteration
```
Real exit code (measured without a pipe): **1**.

### 3c. Claim query and no-arg load-bearing listing against the toy — same crash
`PAPER12_PATH=$PWD/toy_v2.md python3 ../oracle/reverse_deps.py T3.3`
and the same command with **no argument**, and with `--stats`, each
produce the identical `StopIteration` traceback at line 298.

### 3d. Diagnostic probe (throwaway copy in /tmp, toy itself NOT changed)
The probe copy renamed the toy's registry heading to `## Appendix B. …`
and appended a `## Appendix C.` heading — the two headings line 298 /
the next `next(...)` require. Result:
```
$ PAPER12_PATH=/tmp/toy_probe.md python3 ../oracle/reverse_deps.py --stats
nodes: 7  {'premise': 7}
edges (depends-on, deduplicated): 6
  parser-derived edges: 0
  receipt-encoded edges (incl. parser+receipt): 6
[…]
registry rows parsed: 0; home claim entries parsed: 0
```
and its no-arg listing ranks only the tool's seven hardcoded
Paper 11 / Paper 2 premise nodes (Paper 2 §1, Paper 2 §11.1, Paper 2
§8.1, Paper 11 §6.1 bonding-mode premise, Paper 11 §7.6, Paper 2 §4.1
a_k definition, Paper 11 §4.3), each with 0 dependent claims.

**FINDING (oracle generality):** the crash is only the first layer.
`build_graph` requires headings literally starting `## Appendix B.` and
`## Appendix C.`; registry rows are only counted if they contain
`-P12` and the claim ID matches
`L\d+\.\d+-P12 | LD\.\d+-P12 | LC\.\d+-P12 | LE\.\d+-P12 | OR-\d+`;
script nodes are only `A.1–A.15, FW.1, G.1, H.1, H.2` and Paper 11's
F.33/F.37; and 6 of its edges plus 7 premise nodes are constants in the
source (`RECEIPT_EDGES`) naming Paper 11/2 sections by line number.
A paper that does not share Paper 12's ID grammar, appendix layout,
and script names cannot be queried at all — the requested
script→dependents query and load-bearing listing are **not runnable
against the toy**, and no toy-side adaptation short of renaming the
toy's claims to `*-P12` IDs and rebuilding its appendices in Paper
12's shape would change that. That adaptation was **not** performed;
it would have made the toy Paper-12-shaped, defeating the test.

---

## 4. Change-graph checker (`../change_graph/check_change_graph.py`)

The tool landed during this workstream. It takes `--r10 / --r11 /
--graph` path overrides, so pointing it at the toy trees needed no
adaptation. Its extraction and authority layers, however, are
Paper-12-shaped (see 4a).

### 4a. FAITHFUL graph (`CHANGE_GRAPH.json`) — FAIL, and the failure is the instrument's
The faithful graph records all 4 changes in their natural kinds
(badge-change T3.2, split-change T5.1, scope-change T2.2, new-claim
T3.5) with the toy's own authorities TR-001…TR-004.
```
$ python3 ../change_graph/check_change_graph.py --r10 toy_v1.md --r11 toy_v2.md --graph CHANGE_GRAPH.json
graph entries: 4
--- change-graph check (REAL INPUTS) ---
claims extracted: round-10 0, round-11 0
differing badge/split aspect pairs: 0
text-change coverage: 0 text-change entries vs 0 claims whose home text differs []
  FAIL(b): entry 0: badge-change for unknown claim 'T3.2'
  FAIL(b): entry 1: split-change for unknown claim 'T5.1'
  FAIL(c): entry 0 ('T3.2' 'badge-change'): authority 'TR-001' lacks a recognizable reference (Ruling N / F-NNN / DA-.. / EA-.. / RT-..)
  FAIL(c): entry 1 ('T5.1' 'split-change'): authority 'TR-002' lacks a recognizable reference (Ruling N / F-NNN / DA-.. / EA-.. / RT-..)
  FAIL(c): entry 2 ('T2.2' 'scope-change'): authority 'TR-003' lacks a recognizable reference (Ruling N / F-NNN / DA-.. / EA-.. / RT-..)
  FAIL(c): entry 3 ('T3.5' 'new-claim'): authority 'TR-004' lacks a recognizable reference (Ruling N / F-NNN / DA-.. / EA-.. / RT-..)
VERDICT: FAIL — 6 problem(s)     (exit 1)
```
Why: the extractor's claim-ID pattern is
`L\d+\.\d+-P12 | LD… | LC… | LE… | OR-\d+` (copied from Paper 12's
H.1/H.2), so it extracts **0 claims from either toy tree** and every
toy badge/split entry becomes an "unknown claim"; and its
`AUTHORITY_RE` accepts only `Ruling <n>`, `F-<3 digits>`, or a
`DA- / EA- / RT-` prefix, so the toy's `TR-00N` ruling IDs are
unrecognisable. Its split extraction additionally requires the literal
mark `Component split —`, which the toy does not use (the toy writes
"MACHINE component:" / "AUTHOR component:").

### 4b. Checker-shaped graph (`CHANGE_GRAPH_passform.json`) — PASS, VACUOUS (disclosed adaptation)
Adaptations, both disclosed in that file's own description field:
(1) authorities spelled `Ruling N (TR-00N)` to satisfy AUTHORITY_RE;
(2) the badge and split changes recorded as `text-change` entries
(the only faithful-ish kind the checker does not reject for a T-ID).
```
$ python3 ../change_graph/check_change_graph.py --r10 toy_v1.md --r11 toy_v2.md --graph CHANGE_GRAPH_passform.json
graph entries: 4
claims extracted: round-10 0, round-11 0
differing badge/split aspect pairs: 0
text-change coverage: 2 text-change entries vs 0 claims whose home text differs []
VERDICT: PASS — every differing badge/split aspect has a faithful patch entry; every entry carries an authority reference.     (exit 0)
```
**This PASS is vacuous and is recorded as such:** with 0 claims
extracted and 0 differing aspect pairs, there is nothing for coverage
check (a) to cover. It demonstrates the checker's entry/authority
plumbing runs on foreign files; it does **not** verify the toy patch.

### 4c. Doctored graph — FAIL, as required
`CHANGE_GRAPH_doctored.json` = passform with entry 0's authority
stripped (manual doctoring, per the task's alternative to --selftest):
```
$ python3 ../change_graph/check_change_graph.py --r10 toy_v1.md --r11 toy_v2.md --graph CHANGE_GRAPH_doctored.json
  FAIL(c): entry 0 ('T3.2' 'text-change'): authority '' lacks a recognizable reference (Ruling N / F-NNN / DA-.. / EA-.. / RT-..)
VERDICT: FAIL — 1 problem(s)     (exit 1)
```

### 4d. `--selftest` on the passform — cannot set up (consequence of 4a)
```
$ python3 ../change_graph/check_change_graph.py --r10 toy_v1.md --r11 toy_v2.md --graph CHANGE_GRAPH_passform.json --selftest
  [PASS] intact graph passes (0 problem(s))
  [FAIL] selftest setup: no badge/split entry to remove     (exit 1)
```
The selftest's first plant needs a badge/split entry to remove; the
only graph form the checker accepts for the toy has none, because
badge/split entries for toy claims are exactly what check (b) rejects.

**FINDING (change-graph generality):** path inputs are general, the
graph JSON schema and typed kind set are general, and checks (a)–(c)
are general *logic* — but the extraction layer (claim-ID grammar,
Appendix B/C span, `Component split —` mark, H.1 home-entry shapes)
and the authority grammar are Paper 12's. On a foreign paper the
checker either FAILs a true patch (faithful form) or PASSes it
vacuously (adapted form); neither run verifies the toy's badge/split
diff, which was recomputed by hand for this log instead (v1 vs v2:
T3.2 badge, T5.1 split — exactly the two aspects, matching the graph).

---

## 5. Red-team harness (`../crucible_v12/release/kit/tools/red_team.py`) — PASS

Case: `red_team_case/` (in this folder). `expected.json` names
`toy_check_b.py` with witness `T5.1 score of P0`; `clean/` holds a
placeholder file (the script's data is embedded, so the clean tree is
the script as staged); `mutant/miniature/toy_check_b.py` is the script
with the T5.1 weights changed (2,1) → (1,1) — an external mutant copy,
not one of the script's internal mutants. The overlay path
`miniature/toy_check_b.py` follows the harness's documented staging
rule (script staged under its parent directory's name); that is the
harness's own convention for embedded-data scripts, not a toy change.
```
$ python3 ~/workspace/your_files/paper_12_draft/glm_additions/crucible_v12/release/kit/tools/red_team.py red_team_case --scripts . --verbose
case red_team_case
  script: toy_check_b.py
  witness: 'T5.1 score of P0'
  --- clean run output ---
  | toy_check_b: T4.1, T4.2, T5.1, T5.2 PASS (50 shuffled orderings; P0 score = 5)
  | […]
  --- end clean output (exit 0) ---
  --- mutant run output ---
  | […]
  | AssertionError: T5.1 score of P0
  --- end mutant output (exit 1) ---
  clean run: exit 0 -- OK (the unmutated input passes, as it must)
  mutant run: rejected (exit 1) -- OK
  witness: present in the mutant run's output -- OK
  CASE VERDICT: PASS
SUMMARY: 1/1 cases behaved as expected
RED_TEAM VERDICT: PASS     (exit 0)
```
**Verdict: PASS, paper-agnostic.** No toy content was adapted; only the
case directory was authored to the harness's documented case format.

---

## 6. Summary of instrument verdicts on the miniature

| Instrument | Result | Adaptation needed |
|---|---|---|
| sample_selection.py (Crucible kit) | PASS — 12-claim sample from 16 | Documented TSV transcription only |
| oracle/reverse_deps.py | **FINDING** — crashes (StopIteration, exit 1) on the toy; probe shows 0 toy claims parseable, graph = hardcoded Paper 11/2 premises | None possible short of renaming toy claims to `*-P12` + Paper 12 appendix layout (not done) |
| change_graph/check_change_graph.py | Faithful graph: FAIL (b)×2 + (c)×4 with 0 claims extracted. Adapted graph: PASS but vacuous; doctored: FAIL (c); --selftest cannot set up | Authorities respelled + badge/split demoted to text-change (disclosed, in-file) |
| crucible_v12 red_team.py | PASS — 1/1 cases, witness present | Case authored to documented format only |

Pending runs: **none.** All four instruments had landed by the time of
the runs above (oracle and change-graph landed mid-workstream and were
run the same session; the red-team harness was found in
`../crucible_v12/release/kit/tools/red_team.py`).

---

## Post-repair addendum

This addendum was appended after the log above was written. It does
not alter the log's existing text.

After the log was written, two repairs changed the behaviours
§§3–4 recorded:

- **R1 (oracle):** `oracle/reverse_deps.py` no longer crashes on an
  out-of-grammar paper. It refuses cleanly, exit 2. Verified refusal
  line (stderr, on the toy):

  ```
  REFUSED: no '## Appendix B.' heading found — the input does not carry the registry grammar this tool reads (Appendix B claim rows between '## Appendix B.' and '## Appendix C.' headings; see INPUT GRAMMAR in the module docstring).
  ```

  (exit 2)

- **R2 (checker):** `change_graph/check_change_graph.py` no longer
  FAILs a faithful foreign patch, or PASSes an adapted one
  vacuously, on 0 extraction. It refuses, exit 1. Verified refusal
  line (on the toy trees):

  ```
  REFUSAL: 0 claims extracted — at least one input is outside the declared grammar; no verification performed
  ```

  (exit 1)

§§3–4 stand as the as-run record of the pre-repair tools: the
`StopIteration` crash (exit 1) in §3 and the FAIL / vacuous-PASS
runs in §4 are what those tools did at the time, and they are not
rewritten here. §6's summary table is superseded for those two
rows by this addendum: the oracle row now reads as a clean
REFUSED (exit 2) on out-of-grammar papers, and the change-graph
checker row now reads as a REFUSAL on 0 extraction (exit 1).
`ARCHITECTURE.md` Layer 7 was conformed to match.
