#!/usr/bin/env python3
"""Toy checker B -- canonical ordering, scoring, balance.

Checks (toy_v2.md): T4.1, T4.2, T5.1 (v2 split [TR-002]: MACHINE =
arithmetic given weights 2,1; AUTHOR = choice of weights), T5.2.
Stdlib only.

INPUT_PROVENANCE
  records/positions : declared test fixtures below
  weights (2, 1)    : declared-assumption (AUTHOR component of T5.1)
  ordering rule     : paper-defined (toy_v2 section 4)

Planted mutants (genuine spec violations, must be REJECTED with witness):
  MUTANT-B1  column-major order presented as canonical -- violates T4.1
             (row-major): cell (1,0) must precede (0,1) in column-major
             but follow it in row-major; the orders differ at index 1.
  MUTANT-B2  score computed with weights (1,1) instead of (2,1) --
             violates T5.1: P0 scores 5 under (2,1), 3 under (1,1).
"""
import random
import sys

P0 = {(0, 0): "red", (0, 1): "blue", (1, 1): "red"}  # receipt R1 position
WEIGHTS = {"red": 2, "blue": 1}  # AUTHOR component of T5.1


def canonical(cells):
    return sorted(cells)  # (row, col) tuples sort row-major: T4.1


def score(pos, weights=WEIGHTS):
    return sum(weights[v] for v in pos.values())


def balanced(pos):
    vals = list(pos.values())
    return vals.count("red") == vals.count("blue")


def main():
    cells = [(r, c) for r in range(3) for c in range(3)]
    assert canonical(cells) == cells, "T4.1 row-major order"
    # T4.2: any input permutation sorts to canonical.
    rng = random.Random(12)
    for _ in range(50):
        shuffled = cells[:]; rng.shuffle(shuffled)
        assert canonical(shuffled) == cells, "T4.2 sorting"
    # T5.1 MACHINE component: arithmetic given the weights.
    assert score(P0) == 2 * 2 + 1 * 1 == 5, "T5.1 score of P0"
    assert score({}) == 0
    assert score({(2, 2): "blue", (0, 0): "blue"}) == 2
    # T5.2
    assert balanced({(0, 0): "red", (0, 1): "blue"}) is True
    assert balanced(P0) is False  # 2 red, 1 blue
    print("toy_check_b: T4.1, T4.2, T5.1, T5.2 PASS "
          "(50 shuffled orderings; P0 score = 5)")

    # MUTANT-B1: column-major claimed as canonical.
    col_major = sorted(cells, key=lambda rc: (rc[1], rc[0]))
    if col_major == canonical(cells):
        print("MUTANT-B1: NOT REJECTED (FAIL)"); return 1
    idx = next(i for i, (a, b) in enumerate(zip(col_major, cells)) if a != b)
    print(f"MUTANT-B1: REJECTED -- T4.1 witness at index {idx}: "
          f"column-major gives {col_major[idx]}, canonical gives {cells[idx]}")

    # MUTANT-B2: wrong weights (1,1).
    bad = score(P0, {"red": 1, "blue": 1})
    if bad == score(P0):
        print("MUTANT-B2: NOT REJECTED (FAIL)"); return 1
    print(f"MUTANT-B2: REJECTED -- T5.1 witness: weights (1,1) give "
          f"score(P0)={bad}, spec weights (2,1) give {score(P0)}")
    print("toy_check_b: ALL PASS, mutants rejected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
