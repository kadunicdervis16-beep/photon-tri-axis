# Toy Adjudication Note — authorities for v1 → v2

Every v1→v2 change cites exactly one authority below. No other v1→v2
differences are authorised.

- **TR-001 (toy ruling, badge change)** — Finding TF-001: `toy_check_a.py`
  as delivered in v1 already checks column-counts (T3.2) on every test
  position, so T3.2's `[LEVEL B]` understates its checking.
  **Ruling:** T3.2 badge `[LEVEL B]` → `[LEVEL A]` in v2.
- **TR-002 (toy ruling, hybrid-split change)** — Finding TF-002: v1's
  T5.1 split put the weights (2, 1) wholly in the AUTHOR component, but
  the *arithmetic* `2·red + 1·blue` given the weights is machine work.
  **Ruling:** in v2, T5.1's MACHINE component covers the arithmetic
  given the weights; the AUTHOR component covers only the *choice* of
  weights 2 and 1. The claim's total content is unchanged.
- **TR-003 (toy ruling, scope change)** — Finding TF-003: a swap of two
  adjacent pebbles (T2.3) also preserves red/blue/total counts, by the
  same counting argument as moves.
  **Ruling:** T2.2 scope widens from “moves only” to “moves and adjacent
  swaps” in v2; T2.2 gains dependency T2.3.
- **TR-004 (toy ruling, new claim)** — Finding TF-004: v1 states the
  centre-on-both-diagonals fact inside T3.4 but never claims the exact
  diagonal identity.
  **Ruling:** add new claim **T3.5** in v2: “diag_main + diag_anti =
  total_on_diagonals + centre_count, where total_on_diagonals counts
  distinct diagonal cells” — badged `[LEVEL A]`, checked by
  `toy_check_a.py`, dependencies T1.3, T3.4.

Status of R1 / D1 in v2: R1 remains a declared receipt (unchanged).
D1 remains open — its discharge condition is not met by any v2 change.
