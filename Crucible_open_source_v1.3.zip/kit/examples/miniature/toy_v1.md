# The Pebble Ledger — A Toy Paper (v1)

*A miniature, paper-agnostic worked example. Domain: coloured pebbles on a
rectangular board. No physics, no Paper 12 content.*

## 0. Conventions

- Claim IDs: `T<section>.<n>`.
- Badges: `[LEVEL A]` = machine-checked in this toy; `[LEVEL B]` = stated,
  not yet machine-checked; `[LEVEL A: MACHINE / AUTHOR]` = hybrid (see §5);
  `[DECLARED RECEIPT]` = carried by declaration (see §6).
- Registry: Appendix B (§B) is the authoritative claim list. A claim's
  registry row gives ID, badge, home section, dependencies, and scope.

## 1. Board and tokens

- **T1.1** [LEVEL A] The board is a 3×3 grid of 9 distinct cells, addressed
  `(row, col)` with row, col ∈ {0,1,2}. Scope: this 3×3 board only.
- **T1.2** [LEVEL A] Every pebble is exactly one of {red, blue}. No third
  colour exists in the toy.
- **T1.3** [LEVEL A] A position is a function from cells to
  {empty, red, blue}; at most one pebble occupies a cell.

## 2. Moves and conservation

- **T2.1** [LEVEL A] A move relocates one pebble to an adjacent empty cell
  (Manhattan distance 1). Dependencies: T1.1, T1.3.
- **T2.2** [LEVEL A] Conservation: any sequence of moves preserves the total
  pebble count and the red count and the blue count separately.
  Scope: **moves only** (not swaps). Dependencies: T2.1, T1.2.
- **T2.3** [LEVEL B] A swap exchanges two adjacent pebbles in one step.
  Scope: adjacent pairs only. Dependencies: T1.3.

## 3. Counting

- **T3.1** [LEVEL A] For any position, the three row-counts sum to the
  total pebble count. Dependencies: T1.3.
- **T3.2** [LEVEL B] For any position, the three column-counts sum to the
  total pebble count. Dependencies: T1.3.
- **T3.3** [LEVEL A] The red row-counts sum to the red total, and likewise
  for blue. Dependencies: T3.1, T1.2.
- **T3.4** [LEVEL B] The two diagonal counts sum to at most the total plus
  the centre count (the centre lies on both diagonals). Dependencies: T1.3.

## 4. Ordering

- **T4.1** [LEVEL A] Canonical order: positions are listed row-major
  (row 0 left-to-right, then row 1, then row 2); this order is total and
  transitive over the 9 cells. Dependencies: T1.1.
- **T4.2** [LEVEL A] Sorting pebble records by (row, col) yields the
  canonical order of T4.1, regardless of input order. Dependencies: T4.1.

## 5. Scoring — hybrid claims

- **T5.1** [LEVEL A: MACHINE / AUTHOR] Score S = 2·(red count) + 1·(blue
  count).
  - *MACHINE component:* S is computed exactly from a position by
    `toy_check_b.py`.
  - *AUTHOR component:* the weights 2 and 1 are the author's stipulated
    values for this game; they are not derived from §§1–4.
  Dependencies: T3.3.
- **T5.2** [LEVEL A: MACHINE / AUTHOR] A position is “balanced” iff
  red count = blue count.
  - *MACHINE component:* equality of the two counts is checked by
    `toy_check_b.py`.
  - *AUTHOR component:* the word “balanced” for equal counts is the
    author's naming choice.
  Dependencies: T1.2, T3.3.

## 6. Declared receipt and open debt

- **DECLARED RECEIPT R1** [DECLARED RECEIPT] — **T6.1** [DECLARED RECEIPT]
  The starting position P0 (red at (0,0), blue at (0,1), red at (1,1)) is
  taken from the external Referee List, entry 7. This toy does **not**
  derive P0; it carries P0 by declaration, flagged as such, and every
  claim depending on P0 inherits this flag. Dependencies: receipt:R1.
- **OPEN DEBT D1** — No claim in v1 proves that every position reachable
  by moves from P0 can return to P0 (reversibility). **Discharge
  condition for D1:** add a checker that enumerates the reachable set
  from P0 on the 3×3 board and exhibits a return move sequence for each
  member, and register that checker as T2.2's or a new claim's script;
  until then D1 stays open and no reversibility claim is badged.

## B. Appendix B — Registry (v1)

| claim_id | badge | home_section | dependencies | scope |
|---|---|---|---|---|
| T1.1 | [LEVEL A] | 1 |  | 3x3 board only |
| T1.2 | [LEVEL A] | 1 |  | all pebbles |
| T1.3 | [LEVEL A] | 1 |  | all positions |
| T2.1 | [LEVEL A] | 2 | T1.1; T1.3 | adjacent moves |
| T2.2 | [LEVEL A] | 2 | T2.1; T1.2 | moves only |
| T2.3 | [LEVEL B] | 2 | T1.3 | adjacent pairs |
| T3.1 | [LEVEL A] | 3 | T1.3 | all positions |
| T3.2 | [LEVEL B] | 3 | T1.3 | all positions |
| T3.3 | [LEVEL A] | 3 | T3.1; T1.2 | all positions |
| T3.4 | [LEVEL B] | 3 | T1.3 | all positions |
| T4.1 | [LEVEL A] | 4 | T1.1 | 9 cells |
| T4.2 | [LEVEL A] | 4 | T4.1 | all records |
| T5.1 | [LEVEL A: MACHINE / AUTHOR] | 5 | T3.3 | all positions |
| T5.2 | [LEVEL A: MACHINE / AUTHOR] | 5 | T1.2; T3.3 | all positions |
| T6.1 | [DECLARED RECEIPT] | 6 | receipt:R1 | starting position P0 |

Claim count (v1): **15 claims** (T1.1–T6.1 as tabled) + 1 declared receipt
(R1, which is T6.1's premise) + 1 open debt (D1).
Verification scripts: `toy_check_a.py` (T1.x–T3.x), `toy_check_b.py`
(T4.x–T5.x).
