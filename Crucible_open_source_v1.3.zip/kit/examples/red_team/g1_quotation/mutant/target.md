# Red-team example target (clean)

Paper 9 §4 gives its temperature definition as follows [CITED — L2-P12]:

> Temperature is the localized density and frequency of chaotic creation-geometry rewrite events per second.
