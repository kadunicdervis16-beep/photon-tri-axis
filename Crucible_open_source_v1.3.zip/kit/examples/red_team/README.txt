RED_TEAM EXAMPLES -- three worked mutant cases (Crucible v1.2)
================================================================

These cases exercise kit/tools/red_team.py against three scripts of
the Paper 12 round-11 verification suite. Each case is a directory
with an expected.json, a clean/ input tree and a mutant/ input tree.
The three cases were chosen because the three scripts receive their
input by three DIFFERENT mechanisms -- together they demonstrate the
harness's staging convention (below) covering all of them.

RUNNING THEM
  From the release root:

    python3 kit/tools/red_team.py kit/examples/red_team \
        --scripts <SUITE_SCRIPTS_DIR>

  where <SUITE_SCRIPTS_DIR> is the directory holding the round-11
  suite scripts (staging_v18/scripts in the Paper 12 workspace:
  A14_ordering_key.py, A15_spine.py, G1_quotes.py and their siblings).
  The recorded run of exactly this command is in RUN_LOG.txt beside
  this file: 3/3 cases behaved as expected.

THE INPUT CONVENTION (why the trees look the way they do)
red_team.py stages each run in a fresh sandbox: it copies the script's
whole directory into the sandbox under its real name (so sibling
imports and __file__-relative lookups keep working), then overlays
the case's input tree onto the sandbox root, preserving relative
paths, and runs the staged script with cwd = the sandbox root. The
examples' overlay paths therefore start with "scripts/" because the
suite directory is named "scripts". Per script:

  a14_ordering_key/ -- A.14 reads NO input file: the populations, the
    ordering key and its checks are all embedded in the script. The
    only way to feed it a mutant input is to replace the staged
    script itself, so clean/ and mutant/ each carry
    scripts/A14_ordering_key.py -- byte-identical to the suite's in
    clean/, and in mutant/ carrying one changed line: Ss moved ahead
    of Res in key_KB, the workload-first key (the paper's own mutant
    M1, promoted to the main key). Diff the two trees to see it.
  a15_spine_declaration/ -- A.15 also embeds its input (the Appendix
    F populations' declarations and the printed fixture), and imports
    A.12/A.4/A.5 from its own directory; the harness stages those
    siblings from the suite, unmutated. clean/ and mutant/ each carry
    scripts/A15_spine.py; the mutant flips one declared local state
    (E-SMALL body S3, junction J3: sigma ((-1, 0), (1, 0)) becomes
    ((1, 0), (-1, 0))). One flipped declaration, 23 fixture fields
    disagree -- check (2) is the witness.
  g1_quotation/ -- G.1 is the argv case: it checks a quotation target
    named on its command line, so expected.json declares
    "input": "target.md" and "argv": ["{input}"], and the trees carry
    just target.md. The clean target quotes Paper 9's temperature
    definition verbatim; the mutant changes "per tick" to
    "per second" -- one word, and the quotation must come back
    NOT FOUND in its attributed source.

ONE HONEST LIMIT, NAMED
G.1 resolves its cited source texts (Papers 9/10/11/11.5) by its own
resolution chain: a sources/ directory beside the staging root, then
beside the staging tree, then the original Paper 12 workspace paths.
The staged sandbox has no sources/ of its own, so in the recorded run
the sources were read through that chain from the Paper 12 workspace
on disk. The case therefore ships only the file G.1 takes as its
declared input (the target) and relies on the script's own source
resolution for the cited papers -- if you move these cases to a
machine without those sources, stage them by adding a sources/ tree
(paper9.txt, paper10.txt, paper_11_v69.md, paper_11_5_v26.md) to both
input trees; the harness overlay will place it where G.1 looks first.
A.14 and A.15 have no such dependence: they are self-contained apart
from A.15's sibling imports, which the staging convention supplies.

WHAT EACH WITNESS IS
The witness in each expected.json is a substring printed ONLY by the
rejection path being exercised (a named [FAIL] check line for A.14
and A.15; the [NOT FOUND] full-report line for G.1) -- never a phrase
the script prints on a passing run. A mutant run that exits nonzero
without its witness would still be a harness FAILURE for the case:
failing is not enough; the script must fail for the stated reason.
