#!/usr/bin/env python3
"""A.14 — Population ordering key (Paper 12 §11.3, claim L11.4-P12).

Machine companion to §11.3's population ordering key, enacted on the
author's ruling of 2026-10-28 (OPEN RULING OR-2, resolved): for a
finite declared population P at a declared tick,

    K(P) = ( Ntot, Res, Tau0, Ss, Su, -Btot, CenSig )

read lexicographically, where Ntot, Ss, Su, Btot are the population
sums of the §3 record components, Tau0 is the aggregate tension
tau_agg of §4, Res = 1 if no junction of P presents an admissible
index and 0 otherwise (a junction of more than two sides, carried
through the tick unchanged under Definition 4.1, presents no
admissible index for the tick — the reading is within
Definition 4.1's scope), and CenSig is the census signature:
the multiset of the bodies' count vectors (§3.2), sorted descending.
This script computes the key from declared populations and checks
the machine content of L11.4-P12: the key's behaviour on the
constructed exemplar representatives and on the enumerated families
below, the stability invariants, and the re-verification of the two
printed witnesses (W1, W4). It is the suite's fourteenth script in
run order. The key's DEFINITION and the representative construction
are the AUTHOR components of L11.4-P12; this script checks behaviour
of the definition as stated, and its coverage map below says
exactly how far that behaviour is enumerated.

COVERAGE MAP (the house discipline: the badge never outruns the
verified domain).
  NATIVE DOMAIN: all finite declared populations (bodies' §3
    records plus the local states of their established junctions),
    ordered by K as §11.3 defines it; the overlap with Paper 11
    §12.1's six exemplar classes, read as one-member populations.
  VERIFIED DOMAIN: (i) the six constructed representatives of
    §11.3 and their homogeneous families {G x n}, n = 1..4,
    and the nuclei/atoms step parametrically at the shared M
    (u = 0..4, S = 1..4, other components held equal);
    (ii) the sigma family F1: every multiset of size 1..2 drawn
    from all 81 length-2 local states, one junction per body, body
    data (N = 1, Ss = 0, Su = 0) held fixed as a declared control
    isolating sigma behaviour — 3,402 populations; (iii) the
    body-data exhibits of check (6); (iv) the multi-port family
    of check (8): declared bodies identical except in their
    junctions' declared consumed-port counts k_j, over
    (k_1, k_2) in {2, 3, 4}^2, on which the key's separation is
    read at the components §11.3 names. On the representatives the
    full induced order and each step's deciding component are
    computed. On F1: name invariance is checked for every
    population (seeded shuffles of body order); transitivity is
    checked exhaustively over all triples of the 81 one-junction
    populations and over a fixed-seed sample of triples from the
    full family; the stability invariants (declaration vs rest)
    are checked on every population.
  THE MAP: a population is declared exactly as §3.1/§4 declare it
    — bodies with (N, Ss, Su) record components and their
    junctions' local states sigma = (A, B); the key is computed
    from that declaration by the definitions above. Each junction's
    declaration also carries its consumed-port count k_j as record
    data, read exactly as §11.3's definition reads it (Paper 11
    §4.1's port count, received at §3.1): the key's k_j multiset
    comes from that data alone, never from the presented state.
    Every population constructed before round 11 declared one
    consumed port per presented side; the multi-port family of
    check (8) declares k_j = 3 and 4 at two-sided junctions. The
    map preserves exactly the key's value and the components it
    is read from.
  WHAT CARRIES THE GENERAL CLAIMS: the order properties in
    general (total preorder, name invariance) are finite
    arithmetic on the definition — a lexicographic tuple of
    totally ordered components, with sums and a sorted multiset
    as its entries — stated in §11.3's prose; the enumeration
    here is corroboration and counterexample search over the
    stated domains, and it found none. The Monte Carlo search of
    the OR-2 research programme (seed 20261028; 2,000,000 pairs,
    1,500,000 triples over a 6,000-population pool, zero
    transitivity violations) is reported in the research record
    as a measurement of its disclosed generator; it is not
    re-run here and no claim in the paper rests on it.
  OUTSIDE THE CHECK, stated plainly: the key's definition itself
    (the author's ruling, L11.4-P12's AUTHOR component); the
    representative construction's fidelity to Paper 2's classes
    beyond the differentiae the construction states (Paper 2
    §§11.4-11.5 state the differentiae in Paper 2's vocabulary;
    the rendering as presented junction data is §11.3's
    construction, not a citation); body-record tick-dynamics,
    which §4 does not state — the stability check holds body
    components (N, Ss, Su) fixed across the tick exactly as §4's
    stated dynamics do; populations beyond the enumerated
    families, covered by the prose argument, not by enumeration;
    junction declarations beyond the enumerated k_j values and
    shapes of checks (1)-(8) — the definition's reading of k_j
    is general, and §11.3's prose carries it there; the
    enumeration covers the declared families named in the
    VERIFIED DOMAIN.

WITNESSES (rebuilt and re-verified here, as printed in §11.3's
research record): W1, the stability theorem's sharpness — two
one-junction populations whose K order reverses between the
declaration tick and rest, proving the boundary of the stability
statement is real (a positive exhibit of a stated bound, not a
rejection). W4, the silent-slot flip — declared representatives of
the meson-like / baryon-like pair with the paper-silent workload
slot assigned adversarially (Ss 9 against 4): workload-first keys
order the pair against §12.1; K is unmoved, because no component
before Res consults the slot at that step.

MUTANTS (genuine violations of §11.3's stated properties, each
REJECTED with a printed witness): M1, the workload-first key K-A
(Ntot, Ss, Res, Su, -Btot, CenSig) — rejected by W4: it consults
a paper-silent slot to decide a pair §12.1 decides by a stated
component. M2, the census-only key (CenSig alone) — rejected on
the constructed representatives: the meson-like and baryon-like
representatives carry IDENTICAL count vectors, so the census-only
key ties a pair the ordering separates; the census confers no
rank (L11.3-P12). M3, a name-dependent key (K with the sorted
census signature replaced by the bodies' junction states in
listed order) — rejected on the named-pair exhibit: two
declarations differing only in which named body carries which
sigma, with identical censuses at every tick, receive different
M3 keys; K ties them, as name invariance requires.

INPUT_PROVENANCE:
  - T, tau, admissibility (A[k] = -B[k] != 0, canonical-first):
    class=cited-paper (Paper 11 §7.5, as restated in Paper 12
    §4; the same conventions as scripts A.2/A.10/A.12).
  - The boundary formula B = 6N - sum_j k_j and the count vector:
    class=cited-paper (Paper 11 §4.1 via Paper 12 §§3.1-3.2).
  - Each junction's declared consumed-port count k_j, carried in
    the declaration as record data and read exactly as §11.3's
    definition reads it: the declaration form is
    class=paper-defined (Paper 12 §§3.1, 11.3); the declared
    values inside the representatives are part of their
    construction (class as there); the multi-port family's
    k_j values 3 and 4 are class=control (declared values
    isolating the k_j reading).
  - Standings (Definition 5.7) where the named-pair exhibit uses
    them: class=paper-defined (Paper 12 §5).
  - The key's component order and the Res reading:
    class=paper-defined (Paper 12 §11.3, on the author's ruling
    of 2026-10-28).
  - The six constructed representatives: the construction
    class=paper-defined (Paper 12 §11.3, on the author's
    ruling), over differentiae class=cited-paper (the texts
    state: node counts and Paper 2 §§11.4-11.5's surplus
    differentia — one integer unresolved at the junction
    against all surplus resolved; workload positivity for the
    tilted class is a stated sign fact, Paper 11 Table 5.1);
    the nuclei/atoms representatives take M = 4 + u at u = 0
    and S = 2 under F.37's declared assumptions M > 3, S >= 1,
    class=declared-assumption, inherited from Paper 11's F.37.
  - The F1 family's fixed body data (N = 1, Ss = 0, Su = 0) and
    the sample seeds: class=control (declared controls isolating
    sigma behaviour; seeds fixed and printed at run time).
"""
import itertools
import random
import sys
from fractions import Fraction

FAILURES = []


def report(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(name)
    return ok


# ---------------------------------------------------------------- model
def admissible_indices(sigma):
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def tau(sigma):
    return sum(x * x for side in sigma for x in side)


def T(sigma):
    A, B = sigma
    adm = admissible_indices(sigma)
    if not adm:
        return sigma
    k = adm[0]
    A2, B2 = list(A), list(B)
    A2[k] = 0
    B2[k] = 0
    return (tuple(A2), tuple(B2))


# Round 11: the k_j multiset is DECLARATION data. Earlier versions
# of this script read k_j from the presented state's side count
# (len(sigma)) because its declarations carried no port-consumption
# data; that reading separated from §11.3's definition wherever a
# junction consumed more than one port at a side (the round-7
# disclosure at C33). Declarations now carry each junction's
# consumed-port count k_j alongside its local state, and Body
# reads the multiset from that data alone.


def standing(sigma):
    """Definition 5.7 standing of a two-sided junction."""
    A, B = sigma[0], sigma[1]
    n = min(len(A), len(B))
    if any(A[k] == 1 and B[k] == -1 for k in range(n)):
        return '+'
    if any(A[k] == -1 and B[k] == 1 for k in range(n)):
        return '-'
    return '0'


class Body:
    __slots__ = ('N', 'Ss2', 'Su', 'sigmas', 'kjs')

    def __init__(self, N, Ss2, Su, sigmas, kjs):
        sigmas = tuple(sigmas)
        kjs = tuple(kjs)
        if len(kjs) != len(sigmas):
            raise ValueError(
                "declaration refused: k_j data must accompany every "
                "junction — one declared consumed-port count per "
                "junction (§11.3 reads k_j from the record)")
        if type(N) is not int or N < 1:
            raise ValueError(
                "declaration refused: a body record has integer "
                "N >= 1 (§3.1's record domain)")
        if type(Ss2) is not int or type(Su) is not int \
                or Ss2 < 0 or Su < 0:
            raise ValueError(
                "declaration refused: record components Ss, Su "
                "are integers >= 0 (§3.1's record domain)")
        for s, kj in zip(sigmas, kjs):
            if not isinstance(s, (tuple, list)) or len(s) < 2:
                raise ValueError(
                    "declaration refused: a junction presents at "
                    "least two sides (§4's scope rule); a "
                    "zero- or one-sided entry is not a junction")
            side_lens = set()
            for side in s:
                if not isinstance(side, (tuple, list)) \
                        or len(side) < 1:
                    raise ValueError(
                        "declaration refused: each presented side "
                        "presents at least one port (§0.4(b)'s "
                        "premise)")
                side_lens.add(len(side))
                if any(type(v) is not int or v not in (-1, 0, 1)
                       for v in side):
                    raise ValueError(
                        "declaration refused: a local state's "
                        "entries are in {-1, 0, +1} (§4's "
                        "local-state form)")
            if len(side_lens) != 1:
                raise ValueError(
                    "declaration refused: a local state's sides "
                    "are equal-length port vectors (§4's "
                    "local-state form)")
            if type(kj) is not int or kj < len(s):
                raise ValueError(
                    "declaration refused: a junction's declared k_j "
                    "is at least one consumed port per presented "
                    f"side (§0.4(b)'s premise); got k_j = {kj} for "
                    f"a {len(s)}-sided junction")
        if sum(kjs) > 6 * N:
            raise ValueError(
                "declaration refused: sum_j k_j > 6N would make "
                "B < 0 (§3.1's record domain)")
        self.N = N
        self.Ss2 = Ss2
        self.Su = Su
        self.sigmas = sigmas
        self.kjs = kjs

    def k_multiset(self):
        return tuple(sorted(self.kjs))

    def B(self):
        return 6 * self.N - sum(self.k_multiset())

    def vector(self):
        return (self.N, self.k_multiset(), self.B(), self.Ss2, self.Su)

    def standing(self):
        sts = [standing(s) for s in self.sigmas if len(s) == 2]
        if '+' in sts:
            return '+'
        if '-' in sts:
            return '-'
        return '0'


class Population:
    __slots__ = ('bodies',)

    def __init__(self, bodies):
        self.bodies = tuple(bodies)

    def junctions(self):
        return [s for b in self.bodies for s in b.sigmas]

    def N_tot(self):
        return sum(b.N for b in self.bodies)

    def Ss_tot(self):
        return sum(b.Ss2 for b in self.bodies)

    def Su_tot(self):
        return sum(b.Su for b in self.bodies)

    def B_tot(self):
        return sum(b.B() for b in self.bodies)

    def tau_agg(self):
        return sum(tau(s) for s in self.junctions())

    def acting(self):
        return sum(1 for s in self.junctions()
                   if len(s) == 2 and admissible_indices(s))

    def resolved(self):
        """Res: 1 iff no junction presents an admissible index."""
        return 1 if self.acting() == 0 else 0

    def census_sig(self):
        return tuple(sorted((b.vector() for b in self.bodies),
                            reverse=True))

    def census(self):
        from collections import Counter
        return Counter(b.vector() for b in self.bodies)

    def tick(self):
        return Population([
            Body(b.N, b.Ss2, b.Su,
                 [T(s) if len(s) == 2 else s for s in b.sigmas],
                 b.kjs)
            for b in self.bodies])

    def rest(self):
        P = self
        while P.acting() > 0:
            P = P.tick()
        return P


# ---------------------------------------------------------------- keys
def key_KB(P):
    """The §11.3 key."""
    return (P.N_tot(), P.Ss_tot(), P.tau_agg(), P.resolved(),
            P.Su_tot(), -P.B_tot(), P.census_sig())


def key_KA(P):
    """MUTANT M1: workload consulted before Res."""
    return (P.N_tot(), P.Ss_tot(), P.resolved(), P.Su_tot(),
            -P.B_tot(), P.census_sig())


def key_KH(P):
    """The mean-form workload-first variant of the W4 exhibit."""
    n = len(P.bodies)
    if n == 0:
        raise ValueError(
            "the mean-form variant is undefined on the empty "
            "population: a mean over no bodies is not formed "
            "(the §11.3 key itself is sum-form, and total there)")
    return (Fraction(P.N_tot(), n), Fraction(P.Ss_tot(), n),
            P.resolved(), Fraction(P.Su_tot(), n))


def key_census_only(P):
    """MUTANT M2: the census signature alone."""
    return P.census_sig()


def key_name_dependent(P):
    """MUTANT M3: the bodies' junction states in listed order in
    place of the sorted census signature — the key reads the
    declaration's listing, not the population."""
    return (P.N_tot(), P.resolved(), P.tau_agg(), P.Ss_tot(),
            P.Su_tot(), -P.B_tot(),
            tuple(b.sigmas for b in P.bodies))


COMPONENTS = ["Ntot", "Res", "Tau0", "Ss", "Su", "-Btot", "CenSig"]


def deciding_component(ka, kb):
    for i, (x, y) in enumerate(zip(ka, kb)):
        if x != y:
            return COMPONENTS[i]
    return "(tie)"


# ------------------------------------------------------- representatives
def representatives():
    """The six representatives constructed at §11.3, verbatim."""
    photon = Population([Body(1, 0, 0, [], ())])
    tilted = Population([Body(1, 1, 1, [], ())])
    # meson-like: presented data stands with opposed pairs at its
    # junctions — the surplus of Paper 2 §11.4 standing unresolved.
    meson = Population([Body(3, 9, 3, [((1,), (-1,)), ((1,), (-1,))], (2, 2))])
    # baryon-like: junctions present matching same-sign pairs; no
    # opposed pair stands — Paper 2 §11.5's resolved structure,
    # under §11.3's declared identification.
    baryon = Population([Body(3, 9, 3, [((1,), (1,)), ((-1,), (-1,))], (2, 2))])
    # nuclei: M = 4 (u = 0 under the declared assumption M = 4 + u).
    nuclei = Population([Body(4, 8, 2, [((1, 1), (1, 1)), ((1,), (1,))], (2, 2))])
    # atoms: nuclei plus incorporated simple states, S = 2 >= 1.
    atoms = Population([Body(6, 10, 3, [((1, 1), (1, 1)), ((1,), (1,))], (2, 2))])
    return {'photon': photon, 'tilted': tilted, 'meson': meson,
            'baryon': baryon, 'nuclei': nuclei, 'atoms': atoms}


ORDER = ['photon', 'tilted', 'meson', 'baryon', 'nuclei', 'atoms']
EXPECTED_DECIDER = {('photon', 'tilted'): 'Ss',
                    ('tilted', 'meson'): 'Ntot',
                    ('meson', 'baryon'): 'Res',
                    ('baryon', 'nuclei'): 'Ntot',
                    ('nuclei', 'atoms'): 'Ntot'}


def all_sigmas():
    return [((e[0], e[1]), (e[2], e[3]))
            for e in itertools.product((-1, 0, 1), repeat=4)]


def f1_family():
    sigmas = all_sigmas()
    pops = [Population([Body(1, 0, 0, [s], (2,))]) for s in sigmas]
    for s1, s2 in itertools.combinations_with_replacement(sigmas, 2):
        pops.append(Population([Body(1, 0, 0, [s1], (2,)),
                                Body(1, 0, 0, [s2], (2,))]))
    return pops


SEED = 20261028


def main():
    print("=" * 70)
    print("A.14 — POPULATION ORDERING KEY (§11.3): the §11.3 key over")
    print("the constructed representatives and the enumerated families")
    print("=" * 70)

    reps = representatives()
    keys = {c: key_KB(reps[c]) for c in ORDER}

    # (1) the overlap on the constructed representatives
    steps_ok = True
    deciders = []
    for a, b in zip(ORDER, ORDER[1:]):
        if not keys[a] < keys[b]:
            steps_ok = False
        deciders.append(f"{a}<{b} at "
                        f"{deciding_component(keys[a], keys[b])}")
    report("(1a) representatives: K induces §12.1's order, strictly, "
           "at every adjacent step", steps_ok, "; ".join(deciders))
    dec_ok = all(deciding_component(keys[a], keys[b]) == EXPECTED_DECIDER[(a, b)]
                 for a, b in zip(ORDER, ORDER[1:]))
    report("(1b) each step decides at the component §11.3 names "
           "(photon/tilted at Ss, the 3-node step at Res, the rest "
           "at Ntot)", dec_ok)
    report("(1c) the meson-like and baryon-like representatives "
           "carry identical count vectors — the census ties them; "
           "only the junction data separates them",
           reps['meson'].bodies[0].vector()
           == reps['baryon'].bodies[0].vector()
           and keys['meson'] != keys['baryon'],
           f"shared vector {reps['meson'].bodies[0].vector()}")

    # (2) homogeneous families
    hom_ok = True
    for n in (2, 3, 4):
        hk = {c: key_KB(Population([reps[c].bodies[0]] * n))
              for c in ORDER}
        hom_ok = hom_ok and all(hk[a] < hk[b]
                                for a, b in zip(ORDER, ORDER[1:]))
    report("(2) homogeneous families {G x n}, n = 1..4: the class "
           "order is preserved at every multiplicity", hom_ok)

    # (2b) the nuclei/atoms step, parametrically at the shared M:
    # the atoms representative is the nuclei representative's M with
    # S incorporated states added, so the step must hold for every
    # u >= 0 and S >= 1, decided at Ntot.
    Jsig = reps['nuclei'].bodies[0].sigmas
    Jkj = reps['nuclei'].bodies[0].kjs
    par_ok = True
    for u in range(5):
        for S in range(1, 5):
            nk = key_KB(Population([Body(4 + u, 8, 2, Jsig, Jkj)]))
            at = key_KB(Population([Body(4 + u + S, 8, 2, Jsig, Jkj)]))
            par_ok = par_ok and nk < at and \
                deciding_component(nk, at) == "Ntot"
    report("(2b) the nuclei/atoms step is parametric: at the shared "
           "M, for u = 0..4 and S = 1..4 with all other components "
           "held equal, K(nuclei) < K(atoms), decided at Ntot", par_ok)

    # (3) the F1 family: name invariance over every population
    pops = f1_family()
    rng = random.Random(SEED)
    inv_fail = 0
    for P in pops:
        bodies = list(P.bodies)
        rng.shuffle(bodies)
        if key_KB(Population(bodies)) != key_KB(P):
            inv_fail += 1
    report(f"(3) F1 family ({len(pops)} populations): name "
           "invariance under seeded shuffles of body order",
           inv_fail == 0 and len(pops) == 3402,
           f"failures: {inv_fail} (seed {SEED})")

    # (4) transitivity: exhaustive over the 81 singles' triples;
    # fixed-seed sample over the full family (corroboration — the
    # general claim is the prose argument of §11.3)
    singles = pops[:81]
    skeys = [key_KB(P) for P in singles]
    viol = 0
    for i in range(81):
        for j in range(81):
            if skeys[i] <= skeys[j]:
                for k in range(81):
                    if skeys[j] <= skeys[k] and not skeys[i] <= skeys[k]:
                        viol += 1
    report("(4a) transitivity, exhaustive over all triples of the "
           "81 one-junction populations", viol == 0,
           f"{81 ** 3} triples, violations: {viol}")
    fkeys = [key_KB(P) for P in pops]
    rng = random.Random(SEED)
    viol = 0
    trials = 300000
    for _ in range(trials):
        i, j, k = (rng.randrange(len(pops)) for _ in range(3))
        if fkeys[i] <= fkeys[j] <= fkeys[k] and not fkeys[i] <= fkeys[k]:
            viol += 1
    report("(4b) transitivity, fixed-seed sample of triples over "
           "the full F1 family (corroboration, not the proof)",
           viol == 0, f"{trials} triples (seed {SEED}), "
           f"violations: {viol}")

    # (5) stability invariants on every F1 population: the
    # components §11.3's theorem names as tick-invariant agree
    # between declaration and rest; body components are held fixed
    # across the tick exactly as §4's stated dynamics hold them.
    bad = 0
    for P, k0 in zip(pops, fkeys):
        kR = key_KB(P.rest())
        if (k0[0], k0[3], k0[4], k0[5], k0[6]) != \
                (kR[0], kR[3], kR[4], kR[5], kR[6]):
            bad += 1
    report("(5) stability invariants: Ntot, Ss, Su, -Btot, CenSig "
           "agree between declaration and rest on every F1 "
           "population (Res and Tau0 are the components that may "
           "move)", bad == 0, f"violations: {bad}")

    # (6) witnesses, rebuilt and re-verified
    P1 = Population([Body(1, 0, 0, [((1, 1, 1), (-1, 1, 1))], (2,))])
    Q1 = Population([Body(1, 0, 0, [((1,), (1,))], (2,))])
    w1 = key_KB(P1) < key_KB(Q1) and key_KB(P1.rest()) > key_KB(Q1.rest())
    report("(6a) WITNESS W1 (stability sharpness): two one-junction "
           "populations whose K order reverses between declaration "
           "and rest — P at declaration < Q (Res decides), at rest "
           "P > Q (Tau0 decides)", w1,
           "P tau 6 -> rest 4 (Res 0 -> 1); Q tau 2, at rest "
           "throughout")
    meson_w = Population([Body(3, 9, 3, [((1,), (-1,)), ((1,), (-1,))], (2, 2))])
    baryon_w = Population([Body(3, 4, 3, [((1,), (1,)), ((-1,), (-1,))], (2, 2))])
    w4 = (key_KA(meson_w) > key_KA(baryon_w)
          and key_KH(meson_w) > key_KH(baryon_w)
          and key_KB(meson_w) < key_KB(baryon_w))
    report("(6b) WITNESS W4 (silent-slot flip): with the paper-"
           "silent workload slot assigned adversarially (meson "
           "Ss = 9, baryon Ss = 4), the workload-first keys order "
           "the pair against §12.1 and K keeps §12.1's order", w4)

    # (7) mutants, rejected with printed witnesses
    report("(7a) MUTANT M1 (workload-first key K-A) REJECTED: on "
           "the W4 assignment it orders meson-like after "
           "baryon-like, against §12.1 — it consults a paper-"
           "silent slot at a step §12.1 decides by a stated "
           "component",
           key_KA(meson_w) > key_KA(baryon_w),
           "witness: the W4 pair of check (6b)")
    report("(7b) MUTANT M2 (census-only key) REJECTED: it ties "
           "the meson-like and baryon-like representatives, whose "
           "count vectors are identical — a census-only key is "
           "not total on the overlap",
           key_census_only(reps['meson'])
           == key_census_only(reps['baryon'])
           and keys['meson'] < keys['baryon'],
           f"witness: shared CenSig {key_census_only(reps['meson'])}")
    ja = ((1, 1), (-1, -1))
    jb = ((-1, 0), (1, 0))
    Pn = Population([Body(1, 0, 0, [ja], (2,)), Body(1, 0, 0, [jb], (2,))])
    Qn = Population([Body(1, 0, 0, [jb], (2,)), Body(1, 0, 0, [ja], (2,))])
    same_census = all(Pn_t.census() == Qn_t.census()
                      for Pn_t, Qn_t in
                      zip([Pn, Pn.tick(), Pn.tick().tick()],
                          [Qn, Qn.tick(), Qn.tick().tick()]))
    report("(7c) MUTANT M3 (name-dependent key) REJECTED: two "
           "declarations differing only in which named body "
           "carries which sigma — censuses identical at every "
           "tick — receive different M3 keys, while K ties them "
           "as name invariance requires",
           same_census and key_name_dependent(Pn) != key_name_dependent(Qn)
           and key_KB(Pn) == key_KB(Qn),
           "witness: the named-pair exhibit")

    # (8) the declared-k_j reading (round 11): identical presented
    # states with different DECLARED consumed-port counts separate
    # exactly where §11.3's definition puts the difference — first
    # at -Btot, the component C33's scope note names.
    sig = ((1,), (-1,))
    bx = Body(3, 9, 3, [sig, sig], (2, 2))
    by = Body(3, 9, 3, [sig, sig], (3, 2))
    bz = Body(3, 9, 3, [sig, sig], (4, 4))
    kx, ky, kz = (key_KB(Population([b])) for b in (bx, by, bz))
    report("(8a) declared k_j is read as record data: identical "
           "presented states with declared k_j (2, 2), (3, 2), "
           "(4, 4) key strictly in that order, each step deciding "
           "at -Btot",
           kx < ky < kz
           and deciding_component(kx, ky) == "-Btot"
           and deciding_component(ky, kz) == "-Btot",
           f"K(2,2) = {kx[:6]}, K(3,2) = {ky[:6]}, "
           f"K(4,4) = {kz[:6]}")
    fam_ok = True
    for k1 in (2, 3, 4):
        for k2 in (2, 3, 4):
            B = 18 - (k1 + k2)
            vec = (3, tuple(sorted((k1, k2))), B, 9, 3)
            expected = (3, 0, 4, 9, 3, -B, (vec,))
            got = key_KB(Population(
                [Body(3, 9, 3, [sig, sig], (k1, k2))]))
            fam_ok = fam_ok and got == expected
    report("(8b) the multi-port family: all nine declared "
           "(k_1, k_2) in {2, 3, 4}^2 return the key computed by "
           "hand from the definition (B = 18 - (k_1 + k_2); Tau0 = 4; "
           "Res = 0)", fam_ok)
    report("(8c) the representatives' count vectors are the ones "
           "§11.3's printed table carries",
           reps['photon'].bodies[0].vector() == (1, (), 6, 0, 0)
           and reps['tilted'].bodies[0].vector() == (1, (), 6, 1, 1)
           and reps['meson'].bodies[0].vector()
               == (3, (2, 2), 14, 9, 3)
           and reps['baryon'].bodies[0].vector()
               == (3, (2, 2), 14, 9, 3)
           and reps['nuclei'].bodies[0].vector()
               == (4, (2, 2), 20, 8, 2)
           and reps['atoms'].bodies[0].vector()
               == (6, (2, 2), 32, 10, 3),
           "photon (1, (), 6, 0, 0); tilted (1, (), 6, 1, 1); "
           "meson/baryon (3, (2, 2), 14, 9, 3); nuclei "
           "(4, (2, 2), 20, 8, 2); atoms (6, (2, 2), 32, 10, 3)")

    def _refused(fn):
        try:
            fn()
        except ValueError:
            return True
        return False

    report("(8d) inadmissible declarations are REFUSED with stated "
           "verdicts, never computed: k_j data missing for a "
           "junction; k_j below one consumed port per presented "
           "side; sum_j k_j > 6N; N = 0; the mean-form variant on "
           "the empty population",
           _refused(lambda: Body(3, 9, 3, [sig], ()))
           and _refused(lambda: Body(3, 9, 3, [sig], (1,)))
           and _refused(lambda: Body(1, 0, 0, [sig], (7,)))
           and _refused(lambda: Body(0, 0, 0, [], ()))
           and _refused(lambda: key_KH(Population([]))),
           "each refusal is a ValueError naming the domain rule")
    report("(8e) malformed local states and components are REFUSED "
           "at the gate (repair batch 2): a zero-sided junction "
           "(whose key would otherwise equal a genuine junction's); "
           "a one-sided entry; sides of mismatched length; a side "
           "presenting no port; entries outside {-1, 0, +1}; "
           "non-integer record components (NaN, float, bool)",
           _refused(lambda: Body(1, 0, 0, [()], [2]))
           and _refused(lambda: Body(1, 0, 0, [((1, 0),)], [1]))
           and _refused(lambda: Body(2, 0, 0, [((1, 1), (-1,))],
                                     [2]))
           and _refused(lambda: Body(1, 0, 0, [((), (1, 0))],
                                     [2]))
           and _refused(lambda: Body(1, 0, 0, [((2,), (-2,))],
                                     [2]))
           and _refused(lambda: Body(1, float("nan"), 0, [], ()))
           and _refused(lambda: Body(1, 1.5, 0, [], ()))
           and _refused(lambda: Body(True, 0, 0, [], ())),
           "each refusal is a ValueError naming §4's form or "
           "§3.1's integer domain")
    report("(8f) the empty population's key is the value §11.3 "
           "prints, positively computed",
           key_KB(Population([])) == (0, 1, 0, 0, 0, 0, ()),
           f"K(empty) = {key_KB(Population([]))}")

    # diagnostics (labelled, not claims)
    s1 = ((1, 0), (-1, 0))
    s2 = ((1, 1), (-1, -1))
    pop87 = Population([Body(1, 0, 0, [s1], (2,))] * 6
                       + [Body(1, 0, 0, [s2], (2,))] * 6)
    print(f"  [DIAGNOSTIC] the §8.7 population's key under declared "
          f"control records (N = 1, Ss = 0, Su = 0 per body): "
          f"K = {key_KB(pop87)[:6]} + CenSig of 12 bodies")

    print("=" * 70)
    if FAILURES:
        print(f"A.14 VERDICT: FAIL — {len(FAILURES)} check(s) failed: "
              f"{FAILURES}")
        return 1
    print("A.14 VERDICT: PASS — the §11.3 key computes as defined; "
          "the overlap holds on the constructed representatives; "
          "name invariance, transitivity and the stability "
          "invariants hold on the enumerated domains; W1 and W4 "
          "re-verified; M1/M2/M3 rejected with witnesses.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
