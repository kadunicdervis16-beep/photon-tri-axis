# BLIND ADJUDICATION (Crucible -- spec sections 9, 10)

**Trial:** <trial label> -- <paper title>, frozen tree.
**Adjudicator:** blinded adjudicator, spawned fresh; ran no attack and
executed no examiner work.
**Protocol:** spec sections 9, 10.1, 10.3, 10.4, <gate section>, followed
exactly.
**Frozen paper:** `<file>`, SHA-256 `<hash>` -- recomputed by this
adjudicator and matching the freeze value; <line count> lines.
**Materials used (only these):** the <n> anonymized finding cards
<first key>...<last key>; the anonymized evidence documents; the witness
artifacts under neutral names; the frozen paper and the packet sources
beside it; the sealed mutation log (<n> pre-registered mutations:
<x> expectation met, <y> boundary-confirmed, <z> not met; witness
countersignatures <status>). Nothing under the submissions tree, the
briefs, or the sealed key was opened. No attempt was made to learn
which examiner or arm produced any card; stance, fluency, and filing
volume were not treated as evidence.

## Method, applied per card

(i) The category (A-E) is verified against the frozen text; where
wrong, the card is re-categorized IN THE OPEN (original category,
corrected category, reason, in the card's record). The strict rule is
applied in reverse: a finding that cannot name the exact claim, a
requirement of that claim, and a failure under the paper's declared
premises is category D in substance whatever it calls itself.
(ii) The evidence standard is applied: five-part coverage map present
and honest; witness complete; for any proposed BROKE, a genuinely
independent second route -- failing which the badge is downgraded to
LIMIT with the reason recorded. Category C/D/E findings can never
sustain a BROKE.
(iii) The adjudicated badge is assigned.
(iv) The evidence that sustained or defeated the finding is recorded,
quoting the argument where its exact wording matters.
Duplicate charges across cards are adjudicated card by card on each
card's own evidence, with convergence noted.

**Process status (kept separate from claim status):** READ: <...> /
NOT RUN: <...> / REPRODUCED or NOT REPRODUCED: <...> /
SOURCE-VERIFIED: <...>

---

## Per-card records (<n>)

### <CARD KEY>
- **Target claim:** <ID> (<section>, lines)
- **Self-classified category:** <A-E>
- **Verified category:** <A-E> <(re-categorized from <x> -- see evidence summary)>
- **Proposed badge:** <HELD | BROKE | LIMIT | OUTSIDE>
- **Adjudicated badge:** <HELD | BROKE | LIMIT | OUTSIDE>
- **Evidence summary:** <what was verified, where, and what decided it;
  for a downgrade, the failed requirement and the boundary that makes
  the residue LIMIT; for a sustained BROKE, both routes>

<repeat per card>

---

## Arithmetic (frozen at sealing of this file)

| | HELD | LIMIT | OUTSIDE | BROKE | cards |
|---|---|---|---|---|---|
| Adjudicated (all cards) | <n> | <n> | <n> | <n> | <n> |

By verified category: A <n> / B <n> / C <n> / D <n> / E <n>.
Re-categorizations in the open: <n> (<list>).
BROKE proposals: <n> filed -> <n> sustained, <n> downgraded (<keys>).
Single-route downgrades: <n> (<keys>).

BADGES ARE FROZEN when this file is hashed and sealed. Nothing after
this step -- not unblinding, not the charter-integrity audit, not
report assembly -- may change a badge. A badge change after freezing
is a new trial, not an edit.
