# CHARTER-INTEGRITY AUDIT (Crucible -- spec section 11)

**Trial:** <trial label> -- <paper title>, frozen tree.
**Meta-auditor:** separate agent, distinct from the adjudicator, the
examiners, and the mutation runner.
**Sequencing:** this audit was run AFTER blind adjudication completed
and badges were frozen, and after unblinding. **No badge has been
changed and no finding has been re-adjudicated.** This report
characterizes the arms only.
**Materials:** the sealed, still-attributed original submissions of
both arms; the blind adjudication; the opened key (used only to
attribute cards in measures that need it).

## Seal verification (sample)

Hashes recomputed and compared against the seal record for <n> files
-- <which: all submissions, reveal addenda, witness files, the
adjudication file, the key file against its recorded pre-opening hash,
a sample of artifacts>. **Result: <all matched / discrepancies listed>.**
The record audited below is the sealed record.

## Denominators

- Arm H findings: <n> (<per role>), in 1:1 correspondence with the
  <n> Arm H cards in the key.
- Arm N findings: <n> (<per role>), in 1:1 correspondence with the
  <n> Arm N cards.
- <Material that enters no denominator (reveal addenda, witness files)
  and why.>

---

## Measure 1 -- BROKE proposals per arm, and per role within Arm H

| Arm | BROKE proposals | Findings | Rate |
|---|---|---|---|
| H | <n> | <n> | <%> |
| N | <n> | <n> | <%> |

Per role within Arm H: <table with card keys via the key>
Context from the frozen adjudication (recorded, not altered): <of Arm
H's proposals, how many sustained / downgraded, with keys>

## Measure 2 -- BROKE-first compliance in Arm H

<The fraction of Arm H findings whose text constructs the defect
argument before any defence is considered: clear cases <n>/<total>;
with visible defect-first behaviour <n>/<total>. Arm N comparison:
<n>. Method stated.>

## Measure 3 -- Hostile-reading invocations

<Arm H findings that expressly adopt the least-favourable reading:
count, with card keys. Arm N: count.>

## Measure 4 -- Concessions

<Arm H arguments talked down by evidence within the finding itself:
count. A concession is the overlay working as designed -- argued BROKE
first, conceded where forced -- not a failure of hostility.>

## Measure 5 -- Strict-rule compliance

<Of Arm H's defect-proposing objections: how many meet all three parts
of the strict rule (exact claim / requirement of the claim / failure
under declared premises); how many the adjudicator re-categorized to
D. Arm N comparison where meaningful.>

## Measure 6 -- Concealment / retreat probes

<Arm H findings that expressly test a disclosure for concealment or a
scope statement for retreat: count, with keys, and their adjudicated
fates.>

## Verdict

**HOSTILITY <DEMONSTRATED | PARTIAL | NOT DEMONSTRATED>**

<The counts that decide it, stated plainly. If any measure is absent
or could not be computed, say so here -- a measure that does not exist
weakens the arm's evidentiary value and is recorded, not smoothed
over.>
