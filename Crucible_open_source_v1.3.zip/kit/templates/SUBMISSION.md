# SUBMISSION -- <trial label>
## Arm <N | H>, Role <A | B | C | D> -- <role name> (<attacks led / supported>)

Frozen paper: `<file>`, <line count> lines. SHA-256 recomputed by this
examiner: `<hash>` -- <matches / does not match> the brief's freeze
value. <If it does not match: stop, record, and file nothing further.>

Packet sources and recomputed SHA-256 (every hash independently
recomputed; no source is marked READ unless actually inspected):

| file | SHA-256 | READ? |
|---|---|---|
| <...> | <...> | <READ / NOT READ> |

Artifacts in this directory: <every code file, output log, and data
file, each with a one-line description. No count is claimed anywhere in
this submission without its producing artifact in this list.>

The sample (from the packet's selection record): <claim IDs>

---

## <Attack ID> -- <attack name>

### Reconstruction / derivation / audit record
<The role's required work for this attack, in full. Reconstructions
carry the per-step classification (definition / finite calculation /
proof / inherited premise / author identification). Derivations are
stepwise maps naming every premise used.>

### Findings

#### Finding <n> -- <one-line statement of the alleged defect or result>
- Target claim: <ID> (<section>, <line in the frozen paper>)
- Exact target text: "<quoted verbatim>"
- Domain and required property: <...>
- Sources used: <files + hashes + line ranges actually inspected>
- Method and complete test space: <...>
- Witness / artifacts: <the witness; for a proposed BROKE, the
  independent second route and why it is independent>
- Coverage map:
  (1) native domain: <...>
  (2) verified domain: <...>
  (3) map between them: <...>
  (4) what the map preserves: <...>
  (5) what stays outside the check: <...>
- Category (self-classified; exactly one of A-E, never merged):
  <A genuine contradiction under the paper's own rules |
   B missing derivation required by a claim |
   C unestablished bridge to physical measurement |
   D disagreement over foundations or ontology |
   E question the paper explicitly leaves open>
- Proposed badge: <HELD | BROKE | LIMIT | OUTSIDE>
- Reason: <the argument. Arm H: construct the defect argument first,
  then concessions one by one, in writing.>
- Process status for this finding: <READ/NOT READ; RUN/NOT RUN;
  REPRODUCED/NOT REPRODUCED; SOURCE-VERIFIED/SOURCE-REPORTED>

<repeat per finding; a finding is the unit that becomes a finding card
at anonymization, so keep each finding self-contained>

---

## Process status (whole submission; kept separate from claim status)

READ: <...> / NOT READ: <...>
RUN: <...> / NOT RUN: <...> (with reasons)
REPRODUCED: <...> / NOT REPRODUCED: <...>
SOURCE-VERIFIED: <...> / SOURCE-REPORTED: <...>

## What this role did not examine

<Unsampled claims remain unexamined; name every required step not
performed and why. No global verdict is inferred from this submission.>
