<!-- FINDING CARD -- produced at anonymization (spec section 10.2).
     The finding's argument text is copied CHARACTER-IDENTICALLY from the
     sealed submission; only headers, labels, and identifying metadata
     are removed. A card whose argument text differs from the sealed
     original in any character is void and must be regenerated.
     The re-keying map (card key -> arm/role/examiner) is sealed
     separately and opened only after badges are frozen. -->

### CARD <FRESH-KEY -- e.g. TRIAL-F-001; the key order must not encode
arm, role, or filing order>

- Target claim: <ID> (<section>, <line in the frozen paper>)
- Exact target text: "<quoted verbatim>"
- Domain and required property: <copied verbatim from the finding>
- Sources used: <copied verbatim>
- Method and complete test space: <copied verbatim>
- Witness / artifacts: <copied verbatim; artifacts referenced under
  neutral names>
- Coverage map: <copied verbatim -- (1) native domain, (2) verified
  domain, (3) map between them, (4) what the map preserves, (5) what
  stays outside the check>
- Category (self-classified, spec section 9.5): <A | B | C | D | E>
- Proposed badge: <HELD | BROKE | LIMIT | OUTSIDE>
- Reason: <copied verbatim>

<!-- Anonymization checklist for the packaging step (delete before use
     is NOT permitted -- fill it in):
     [ ] arm label removed   [ ] role label removed
     [ ] examiner identity removed   [ ] self-references to the arm
         removed from headers/metadata only (argument text untouched)
     [ ] argument text diffed against the sealed original: identical
-->
