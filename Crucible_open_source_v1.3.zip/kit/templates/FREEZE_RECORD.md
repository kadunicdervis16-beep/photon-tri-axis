# FREEZE RECORD (Crucible -- spec section 4.2)

Trial label (use it everywhere): <trial label -- e.g. "Crucible v1.1
(two-arm isolated-context trial) on <paper title>">

Freeze date: <YYYY-MM-DD>. One freeze serves both arms. After this
record is written, the frozen copy is never edited; any paper change
invalidates this freeze, and a new freeze record is written (both are
kept).

## 1. Frozen paper

- File: <path to the frozen copy>
- SHA-256: <hash>
- Lines: <count and the counting convention used>
- Suite result on this exact tree (verbatim, section 2 below)

## 2. Verification-suite result on this exact tree (verbatim)

<Paste the suite's own closing output verbatim -- never a paraphrase.
Record: the command run, the tree it ran on, the script count, and the
full output's own location + SHA-256.>

```
<verbatim closing lines>
```

## 3. Environment freeze (kit v1.1)

| Item | Value |
|---|---|
| Coordinator / packaging host OS | <...> |
| Interpreter for packaging scripts | <name + version> |
| Examiner environment(s) | <one row per distinct environment actually used> |
| Adjudicator environment | <...> |
| Platform-diversity claim | <state exactly what diversity exists; if all roles ran on one host/interpreter, say so -- claim no more than was used> |

## 4. Packet manifest (complete recursive listing with hashes)

| File | SHA-256 |
|---|---|
| <frozen paper, as it appears in the packet> | <...> |
| <protocol / spec extract given to examiners> | <...> |
| <each declared source file> | <...> |
| <sample selection record (tools/sample_selection.py output)> | <...> |
| <blind verification record (tools/blind_packet.py log)> | <...> |
| <blind packet (Role C only, if issued separately)> | <...> |

Source notes: <where each source file came from, with its own hash at
its origin if it is an extract>.

Packaging scripts used, with hashes: <sampler / blind-packet builder /
card maker / brief builder -- name + SHA-256 each>.

## 5. Sample selection -- rule output

- Rule: tools/sample_selection.py <exact command line>
- Registry input: <path + SHA-256>
- Indirections input (if any): <path + SHA-256>
- The sample: <claim IDs, in fill order>
- Full record: <path + SHA-256>

## 6. Blind-packet verification

- Result: <ZERO MATCHES -- packet released / FAIL (trial does not start)>
- Record: <path + SHA-256>

## 7. Certified examiner briefs

| Brief (arm/role) | SHA-256 |
|---|---|
| <N/A> | <...> |
| <N/B> | <...> |
| <N/C> | <...> |
| <N/D> | <...> |
| <H/A> | <...> |
| <H/B> | <...> |
| <H/C> | <...> |
| <H/D> | <...> |

Brief certification: each brief was checked against the exclusion list
(no kits, no prior battery reports or verdicts, no prior adjudications,
no house summaries, no examiner work products from earlier trials).
<Name who certified, and how.>

## 8. Pre-freeze process events

<Anything that happened during packaging before the freeze -- misparses,
regenerations, corrections -- recorded here in the open. "None" is a
valid entry; an empty section is not.>

EXECUTION MAY BEGIN ONLY AFTER THIS RECORD EXISTS.
