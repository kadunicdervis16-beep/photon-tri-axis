#!/usr/bin/env python3
"""Crucible v1.1 -- blind-packet generation and verification.

Builds the packet for the badge blind test (GS-4 Gold spec section 5.3):
claim statements and evidence with ALL badge/status material removed, so a
classifier must assign epistemic status from content alone. Generalized
from the first run's packaging step; nothing paper-specific is baked in --
the stripping rules and the verification pattern set are inputs.

STRIPPING (applied to each input file, in order):
  1. Bracketed spans matching --bracket-regex (default r"\\[[^\\]]*\\]",
     where badge strings conventionally live) are removed and counted.
  2. Sentences matching any regex in --drop-patterns FILE (one regex per
     line, '#' comments allowed) are dropped and counted. The defaults
     reproduce the first run's vocabulary: sentences mentioning 'badge',
     'resolved', 'final', a 'level a/b/c' grade, or a hybrid split marker.

VERIFICATION (the release gate): after stripping, the assembled packet is
scanned for every literal pattern in the verification set -- the defaults
below, plus --verify-patterns FILE (one literal string per line), plus
every exact string in --badges FILE (one per line; typically the sampled
claims' registry badge strings). If ANY pattern occurs even once, the
script writes the log, prints the failures, and exits nonzero WITHOUT
writing the packet (it assembles to a temporary file and renames only on
a clean scan). A packet that exists was verified clean against the
recorded pattern set.

EXAMPLE
  python3 blind_packet.py claims.md evidence.md --out blind_packet.md \\
      --log blind_verification.txt --badges sampled_badges.txt

SELF-TEST
  python3 blind_packet.py --selftest
"""
import argparse
import re
import sys
import tempfile
from pathlib import Path

DEFAULT_VERIFY_PATTERNS = [
    "LEVEL A", "LEVEL B", "LEVEL C",
    "MACHINE / AUTHOR", "MACHINE/AUTHOR",
    "[LEVEL", "badge", "RESOLVED",
]
DEFAULT_DROP_REGEXES = [
    r"badge",
    r"resolved",
    r"\bfinal\b",
    r"level [abc]\b",
    r"machine / author",
    r"machine/author",
]


def read_lines_file(path):
    if not path:
        return []
    out = []
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if line and not line.startswith("#"):
            out.append(line)
    return out


def strip_text(text, bracket_re, drop_res):
    n_brackets = len(bracket_re.findall(text))
    text = bracket_re.sub("", text)
    sents = re.split(r"(?<=[.!?])\s+", text.replace("\n", " "))
    kept, dropped = [], 0
    for s in sents:
        if any(r.search(s) for r in drop_res):
            dropped += 1
        else:
            kept.append(s)
    return " ".join(kept).strip(), n_brackets, dropped


def build_packet(inputs, bracket_re, drop_res):
    parts = [
        "BLIND CLASSIFICATION PACKET (Crucible -- classification blind test)",
        "The claims below are reproduced with their statements, dependency",
        "statements, and any named coverage statements, with all status",
        "material removed. Classify each claim under the paper's own",
        "epistemic-status definitions, using only what is printed here.",
        "",
    ]
    stats = {}
    for path in inputs:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        stripped, nb, nd = strip_text(text, bracket_re, drop_res)
        stats[str(path)] = (nb, nd)
        parts.append("=" * 70)
        parts.append(f"SOURCE: {path}")
        parts.append("")
        parts.append(stripped)
        parts.append("")
    return "\n".join(parts) + "\n", stats


def count_literal(haystack, needle):
    if not needle:
        return 0
    return haystack.count(needle)


def run(inputs, out_path, log_path, verify_patterns, badges, bracket_re, drop_res):
    packet, stats = build_packet(inputs, bracket_re, drop_res)
    patterns = list(verify_patterns) + list(badges)
    counts = {p: count_literal(packet, p) for p in patterns}
    failures = [(p, c) for p, c in counts.items() if c > 0]
    log = ["CRUCIBLE -- BLIND PACKET GENERATION AND VERIFICATION RECORD",
           f"Inputs: {[str(i) for i in inputs]}",
           "Stripping counts per input (bracket spans removed / sentences dropped):"]
    for k, (nb, nd) in stats.items():
        log.append(f"  {k}: {nb} / {nd}")
    log.append("Verification pattern set (literal strings), required result ZERO:")
    for p in patterns:
        log.append(f"  pattern {p!r}: {counts[p]} matches")
    if failures:
        log.append(f"RESULT: FAIL -- {failures}; packet NOT written")
        if log_path:
            Path(log_path).write_text("\n".join(log) + "\n")
        print("BLIND PACKET NON-COMPLIANT:", failures)
        return 1
    log.append("RESULT: ZERO MATCHES -- packet released")
    if log_path:
        Path(log_path).write_text("\n".join(log) + "\n")
    if out_path:
        tmp = Path(str(out_path) + ".tmp")
        tmp.write_text(packet)
        tmp.rename(out_path)
        print(f"blind packet written: {out_path} ({len(packet)} bytes); zero matches confirmed")
    return 0


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Build and verify a Crucible blind packet (spec section 5.3). "
                    "Refuses to write the packet unless the verification scan is clean.")
    p.add_argument("inputs", nargs="*", help="claim/evidence text files to strip and assemble")
    p.add_argument("--out", help="packet output path")
    p.add_argument("--log", help="verification record path")
    p.add_argument("--verify-patterns",
                   help="file of extra literal patterns that must not occur (one per line)")
    p.add_argument("--badges",
                   help="file of exact badge strings that must not occur (one per line)")
    p.add_argument("--drop-patterns",
                   help="file of regexes; a sentence matching any is dropped "
                        "(default: the built-in status-vocabulary set)")
    p.add_argument("--bracket-regex", default=r"\[[^\]]*\]",
                   help="regex for bracketed spans to remove (default: r'\\[[^\\]]*\\]')")
    p.add_argument("--selftest", action="store_true",
                   help="run the built-in self-test and exit")
    return p.parse_args(argv)


def selftest():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        good = td / "claims.md"
        good.write_text(
            "CLAIM X1\n"
            "The count is exactly 2^(1-n) for all n >= 1 [LEVEL A: MACHINE / AUTHOR]. "
            "This badge sentence must vanish entirely. "
            "The finite cases n = 1..6 are enumerated by the checker.\n")
        badges = td / "badges.txt"
        badges.write_text("[LEVEL A: MACHINE / AUTHOR]\n")
        out, log = td / "packet.md", td / "log.txt"
        bracket_re = re.compile(r"\[[^\]]*\]")
        drop_res = [re.compile(rx, re.I) for rx in DEFAULT_DROP_REGEXES]
        rc = run([good], out, log, DEFAULT_VERIFY_PATTERNS,
                 ["[LEVEL A: MACHINE / AUTHOR]"], bracket_re, drop_res)
        assert rc == 0 and out.exists(), "clean packet was refused"
        body = out.read_text()
        assert "2^(1-n)" in body and "LEVEL" not in body, "stripping wrong"
        print("SELFTEST blind_packet: badge-bearing input stripped, packet released, "
              "verification zero")

        bad = td / "bad.md"
        bad.write_text("CLAIM X2\nThis claim carries the GOLD STAR mark in plain "
                       "prose, outside any bracket and outside the drop set.\n")
        out2 = td / "packet2.md"
        rc = run([bad], out2, td / "log2.txt", DEFAULT_VERIFY_PATTERNS,
                 ["GOLD STAR"], bracket_re, drop_res)
        assert rc == 1 and not out2.exists(), "non-compliant packet was written"
        print("SELFTEST blind_packet: surviving exact badge string caught by the "
              "verification scan, packet refused (nonzero exit, nothing written)")
        print("SELFTEST blind_packet: PASS")


def main(argv=None):
    args = parse_args(argv)
    if args.selftest:
        selftest()
        return 0
    if not args.inputs or not args.out:
        print("error: INPUT files and --out are required (or use --selftest)",
              file=sys.stderr)
        return 2
    verify = list(DEFAULT_VERIFY_PATTERNS) + read_lines_file(args.verify_patterns)
    badges = read_lines_file(args.badges)
    drop_src = read_lines_file(args.drop_patterns) or DEFAULT_DROP_REGEXES
    drop_res = [re.compile(rx, re.I) for rx in drop_src]
    bracket_re = re.compile(args.bracket_regex)
    return run(args.inputs, args.out, args.log, verify, badges, bracket_re, drop_res)


if __name__ == "__main__":
    sys.exit(main())
