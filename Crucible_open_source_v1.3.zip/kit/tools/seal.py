#!/usr/bin/env python3
"""Crucible v1.1 -- write-once sealing of a submissions tree.

The Crucible's evidence discipline depends on records that cannot be
quietly edited after the fact (GS-4 Gold spec section 2.4). This tool
seals a directory tree: it walks the tree, computes the SHA-256 of every
file, and writes a SEALED.md record at the tree root. Sealing is
WRITE-ONCE: if any SEALED.md already exists anywhere in the tree, the
seal is refused -- a sealed tree is never re-sealed, only verified.
Verification recomputes every hash and reports each file that is missing,
changed, or added since sealing; the exit code is nonzero on any
discrepancy.

Typical use, per submission directory (one seal per examiner submission,
exactly as the first run's submissions/SEALED.md was assembled section by
section -- or seal each role directory separately, your choice, but say
which in your freeze record):

  python3 seal.py seal submissions/N/A
  python3 seal.py verify submissions/N/A

SELF-TEST
  python3 seal.py --selftest
"""
import argparse
import hashlib
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

RECORD_NAME = "SEALED.md"


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def tree_files(root):
    return sorted(p for p in Path(root).rglob("*") if p.is_file())


def find_records(root):
    return [p for p in tree_files(root) if p.name == RECORD_NAME]


def do_seal(root):
    root = Path(root)
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2
    existing = find_records(root)
    if existing:
        print("REFUSED: tree already contains seal record(s): "
              + ", ".join(str(p) for p in existing)
              + " -- sealing is write-once; verify instead.", file=sys.stderr)
        return 1
    files = tree_files(root)
    lines = [
        "# SEAL RECORD (Crucible -- write-once; spec section 2.4)",
        "",
        f"Tree root: {root}",
        f"Sealed at (UTC): {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}",
        f"Files sealed: {len(files)}",
        "",
        "## Files (path -- sha256)",
    ]
    for p in files:
        lines.append(f"- {p.relative_to(root).as_posix()} -- {sha256_of(p)}")
    record = root / RECORD_NAME
    record.write_text("\n".join(lines) + "\n")
    print(f"sealed {len(files)} file(s) under {root} -> {record}")
    return 0


def parse_record(path):
    entries = {}
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        if raw.startswith("- ") and " -- " in raw:
            rel, digest = raw[2:].rsplit(" -- ", 1)
            entries[rel.strip()] = digest.strip()
    return entries


def do_verify(root):
    root = Path(root)
    records = find_records(root)
    if not records:
        print(f"error: no {RECORD_NAME} found under {root}", file=sys.stderr)
        return 2
    problems = []
    checked = 0
    for record in records:
        base = record.parent
        entries = parse_record(record)
        on_disk = {p.relative_to(base).as_posix() for p in tree_files(base)
                   if p.name != RECORD_NAME}
        for rel, digest in sorted(entries.items()):
            checked += 1
            p = base / rel
            if not p.exists():
                problems.append(f"MISSING: {rel} (recorded in {record})")
            elif sha256_of(p) != digest:
                problems.append(f"CHANGED: {rel} (recorded in {record})")
        for rel in sorted(on_disk - set(entries)):
            problems.append(f"ADDED since sealing: {rel} (under {base})")
    if problems:
        for prob in problems:
            print(prob)
        print(f"VERIFY: FAIL -- {len(problems)} discrepancy(ies), {checked} file(s) checked")
        return 1
    print(f"VERIFY: OK -- {checked} file(s) match their seal record(s)")
    return 0


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Write-once sealing and verification of a Crucible "
                    "submissions tree (spec section 2.4).")
    p.add_argument("command", nargs="?", choices=["seal", "verify"],
                   help="'seal' writes SEALED.md (refused if one exists); "
                        "'verify' recomputes and compares")
    p.add_argument("directory", nargs="?", help="tree root")
    p.add_argument("--selftest", action="store_true",
                   help="run the built-in self-test and exit")
    return p.parse_args(argv)


def selftest():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "sub"
        (root / "inner").mkdir(parents=True)
        (root / "SUBMISSION.md").write_text("findings\n")
        (root / "inner" / "run.py").write_text("print('x')\n")
        assert do_seal(root) == 0
        assert do_verify(root) == 0
        print("SELFTEST seal: tree sealed and verified clean")
        assert do_seal(root) == 1, "re-seal of a sealed tree was not refused"
        print("SELFTEST seal: re-seal refused (write-once)")
        (root / "SUBMISSION.md").write_text("findings -- edited after sealing\n")
        assert do_verify(root) == 1, "tampered file was not detected"
        print("SELFTEST seal: post-seal edit detected by verify (CHANGED)")
        print("SELFTEST seal: PASS")


def main(argv=None):
    args = parse_args(argv)
    if args.selftest:
        selftest()
        return 0
    if not args.command or not args.directory:
        print("error: COMMAND and DIRECTORY are required (or use --selftest)",
              file=sys.stderr)
        return 2
    return do_seal(args.directory) if args.command == "seal" else do_verify(args.directory)


if __name__ == "__main__":
    sys.exit(main())
