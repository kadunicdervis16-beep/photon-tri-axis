#!/usr/bin/env python3
"""Crucible v1.2 -- red-team harness: run a suite script against clean
and mutated inputs and require that the mutation is REJECTED, with a
witness.

A verification script that has never been seen to fail proves little:
the input-equals-output failure mode (a check that passes because its
input was built to pass) is only excluded by feeding the script a
genuine violation and watching it reject that violation, for the
stated reason. This harness mechanizes exactly that discipline for an
arbitrary suite script. It is the external, reusable form of the
mutant batteries the Paper 12 suite scripts carry internally (A.14's
M1/M2/M3, G.1's mutant battery, A.15's edge battery): those batteries
live inside one paper's scripts; this tool runs the same shape of
test from OUTSIDE any script, against any script, from declared
case files.

CASE FORMAT
A mutant case is a directory:

    case_dir/
      expected.json     {"script": ..., "witness": ..., "description": ...}
      clean/            the unmutated input tree (see TREES below)
      mutant/           the mutated input tree

  expected.json fields:
    script      (required) path or file name of the suite script under
                test. Resolution order: as given (absolute, or relative
                to the current directory); relative to the case
                directory; relative to --scripts DIR.
    witness     (required) a substring the MUTANT run's combined output
                (stdout + stderr) must contain. Pick a substring that
                only the rejection produces -- a verdict line or a
                named failure line -- not a phrase the script prints
                either way. This author duty is now a machine check,
                not just advice: the witness must also be ABSENT from
                the CLEAN run's output, and a witness present there
                fails the case (it does not discriminate). A mutant
                run that rejects without the witness is a harness
                FAILURE: the script failed, but not demonstrably for
                the stated reason.
    description (required) what the mutation is and which stated
                property it violates.
    argv        (optional) argument list for the script, after the
                script path. Placeholders: {input} = the staged
                absolute path of the file named by "input";
                {sandbox} = the sandbox root; {script} = the staged
                script path. Default: no arguments.
    input       (optional) name (relative path inside the trees) of
                the case's primary input file, for {input} and for
                the RED_TEAM_INPUT environment variable.
    fail_marker (optional) extra substring that counts as a printed
                failure verdict for a run that exits 0. The
                built-in printed-verdict markers are lines matching
                "VERDICT: FAIL". A run counts as REJECTED when
                it exits nonzero OR prints a failure verdict. The
                rejection definition is applied SYMMETRICALLY: to
                the mutant run (which must be rejected) and to the
                clean run (which must NOT be).
    timeout     (optional) per-run timeout in seconds (overrides
                --timeout for this case).

  The clean input tree may instead be supplied for several cases at
  once with --clean DIR, used by any case that has no clean/ of its
  own. The mutant tree may also be given as loose files in the case
  directory itself (everything except expected.json, clean/, mutant/
  and README* files); the mutant/ subdirectory form is preferred
  because it keeps the two trees symmetric and unambiguous.

INPUT CONVENTION -- HOW A SCRIPT RECEIVES ITS INPUT
Suite scripts locate their inputs in incompatible ways (all three
occur in the Paper 12 round-11 suite alone): some read a file named
on argv (G.1's quotation target); some read paths resolved from
their own location -- sibling imports, a paper file beside the
scripts folder, sources/ directories relative to the staging root
(A.15, G.1's cited sources); some read no file at all because their
input data is embedded in the script itself (A.14, A.15's
declarations and fixture). No single argv convention covers all
three, so this harness uses a STAGING convention instead:

  1. A fresh sandbox directory is created per run (clean and mutant
     runs get separate sandboxes).
  2. The script's whole directory is copied into the sandbox under
     its real name, so sibling imports and __file__-relative lookups
     keep working exactly as in the suite layout. (Exception: if the
     script sits in the case directory itself, only the script file
     is staged, under scripts/.)
  3. The case's input tree (clean/ or mutant/) is overlaid onto the
     sandbox ROOT, preserving relative paths. A tree entry such as
     "scripts/A14_ordering_key.py" therefore REPLACES the staged
     copy of that script -- which is how embedded-data scripts are
     mutated -- while "Paper_12_v4.md" lands beside scripts/ where
     a parent-relative lookup expects it, and a plain "target.md"
     lands at the root, to be passed with argv ["{input}"].
  4. The script runs as:  python3 <staged script> <argv...>
     with cwd = the sandbox root and environment additions
     RED_TEAM_SANDBOX, RED_TEAM_CASE, and RED_TEAM_INPUT when
     "input" is declared. There is NO phase variable: the harness
     must not tell the script which run it is in. (An earlier
     version passed RED_TEAM_PHASE ("clean" | "mutant"); that
     channel is removed, and any inherited RED_TEAM_PHASE is
     stripped from the environment the script receives. The other
     variables were audited: RED_TEAM_CASE is the same in both
     runs, and RED_TEAM_SANDBOX / RED_TEAM_INPUT carry the sandbox
     path, so the staging paths themselves are phase-neutral --
     temporary sandboxes get random names, and sandboxes kept with
     --keep are staged as run_a (clean) / run_b (mutant), a mapping
     known only to the harness. A script that distinguishes the
     runs by input CONTENT is inherent and fine; the harness must
     not hand it the answer.)

VERDICTS
Per case the harness checks, in order:
  null mutant  the effective clean and mutant input trees are NOT
               byte-identical (file sets and per-file bytes are
               compared). Identical trees mean no mutation was
               actually delivered, and the case fails.
  clean run    is NOT itself rejected under the case's own
               rejection definition (nonzero exit, a printed
               failure verdict, or the case's fail_marker), and
               exits 0. (If it is rejected, the case proves
               nothing: the script was already failing before any
               mutation.)
  mutant run   is rejected (nonzero exit or a printed failure
               verdict), AND its output contains the witness.
  witness      the witness is ABSENT from the clean run's output.
  discrimination  (A witness the clean run also prints does not
               discriminate the rejection from a pass.)
Every check that fails is a harness FAILURE for that case, printed
with its reason. The harness prints per-case verdicts and a summary
and exits nonzero if any case misbehaves. Nothing is repaired,
retried, or re-graded: a failing case is a finding about the script
(or about the case), reported as-is.

EXAMPLE
  python3 red_team.py kit/examples/red_team --scripts /path/to/suite/scripts
  python3 red_team.py path/to/one_case --clean path/to/shared_clean_tree

SELF-TEST
  python3 red_team.py --selftest
  Builds toy scripts and four toy cases in a temporary directory --
  one well-formed case (must PASS), one whose mutant is not actually
  rejected (the harness must FAIL it), one whose mutant rejects
  without the declared witness (the harness must FAIL it), and one
  input-ignoring script that always prints "VERDICT: FAIL" plus the
  witness and exits 0, on byte-identical clean/mutant trees (the
  harness must FAIL it: its clean run is itself rejected, its
  witness does not discriminate, and its mutant tree is no
  mutation) -- and checks the harness returns exactly those
  verdicts.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FAIL_VERDICT_RE = re.compile(r"VERDICT:\s*FAIL")
IGNORE_NAMES = {"__pycache__"}


def _ignore(_dir, names):
    return [n for n in names if n in IGNORE_NAMES or n.endswith(".pyc")]


def resolve_script(spec, case_dir, scripts_dir):
    """Resolve expected.json's "script" to an existing file, or None."""
    p = Path(spec)
    candidates = []
    if p.is_absolute():
        candidates.append(p)
    else:
        candidates.append(Path.cwd() / p)
        candidates.append(Path(case_dir) / p)
        if scripts_dir:
            candidates.append(Path(scripts_dir) / p)
    for c in candidates:
        if c.is_file():
            return c.resolve()
    return None


def tree_files(tree_root):
    """All files under a tree root, as (relative path, absolute path)."""
    tree_root = Path(tree_root)
    out = []
    for p in sorted(tree_root.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            out.append((p.relative_to(tree_root), p))
    return out


def trees_identical(files_a, files_b):
    """True iff two effective input trees are byte-identical: the
    same set of relative paths, with equal bytes per file. Used for
    the null-mutant check -- a "mutant" tree identical to the clean
    tree delivers no mutation at all."""
    a = {str(rel): p for rel, p in files_a}
    b = {str(rel): p for rel, p in files_b}
    if set(a) != set(b):
        return False
    return all(a[rel].read_bytes() == b[rel].read_bytes() for rel in a)


def mutant_tree_root(case_dir):
    """The mutant input tree: mutant/ if present, else loose case files."""
    case_dir = Path(case_dir)
    if (case_dir / "mutant").is_dir():
        return case_dir / "mutant"
    return case_dir  # loose-file form; tree_files filtered by caller rules


def loose_mutant_files(case_dir):
    case_dir = Path(case_dir)
    out = []
    for p in sorted(case_dir.iterdir()):
        if p.is_dir() or p.name == "expected.json":
            continue
        if p.name.startswith("README"):
            continue
        out.append((Path(p.name), p))
    return out


def stage_sandbox(script_path, case_dir, overlay_files, keep_root=None):
    """Create a sandbox: staged script directory + overlaid input tree.

    Returns the sandbox Path. The staged script lives at
    sandbox/<script dir name>/<script name>, except when the script
    sits in the case directory itself (then sandbox/scripts/<name>).
    """
    if keep_root:
        sandbox = Path(keep_root)
        sandbox.mkdir(parents=True, exist_ok=True)
    else:
        sandbox = Path(tempfile.mkdtemp(prefix="red_team_"))
    script_dir = script_path.parent
    if script_dir.resolve() == Path(case_dir).resolve() or \
            Path(case_dir).resolve() in script_dir.parents:
        stage_dir = sandbox / "scripts"
        stage_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(script_path, stage_dir / script_path.name)
    else:
        stage_dir = sandbox / script_dir.name
        shutil.copytree(script_dir, stage_dir, ignore=_ignore)
    for rel, src in overlay_files:
        dst = sandbox / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    return sandbox


def run_script(staged_script, argv_template, sandbox, case_name,
               primary_input_rel, timeout):
    argv = []
    for item in argv_template:
        item = item.replace("{sandbox}", str(sandbox))
        item = item.replace("{script}", str(staged_script))
        if "{input}" in item:
            if primary_input_rel is None:
                raise ValueError("{input} used in argv but expected.json "
                                 "declares no \"input\" file")
            item = item.replace("{input}", str(sandbox / primary_input_rel))
        argv.append(item)
    env = dict(os.environ)
    # Phase channel removed: the harness never tells the script
    # whether this is the clean or the mutant run, and an inherited
    # RED_TEAM_PHASE (e.g. exported by a caller's shell) is stripped
    # so it cannot leak the phase either.
    env.pop("RED_TEAM_PHASE", None)
    env["RED_TEAM_SANDBOX"] = str(sandbox)
    env["RED_TEAM_CASE"] = case_name
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if primary_input_rel is not None:
        env["RED_TEAM_INPUT"] = str(sandbox / primary_input_rel)
    try:
        proc = subprocess.run(
            [sys.executable, str(staged_script), *argv],
            cwd=str(sandbox), env=env, capture_output=True, text=True,
            timeout=timeout)
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except subprocess.TimeoutExpired as exc:
        out = ""
        if exc.stdout:
            out += exc.stdout.decode("utf-8", "replace") \
                if isinstance(exc.stdout, bytes) else exc.stdout
        if exc.stderr:
            out += exc.stderr.decode("utf-8", "replace") \
                if isinstance(exc.stderr, bytes) else exc.stderr
        return None, out + f"\n[harness: run timed out after {timeout}s]"


def is_rejection(exit_code, output, fail_marker):
    if exit_code is None:      # timed out: not a rejection, a failure
        return False
    if exit_code != 0:
        return True
    if FAIL_VERDICT_RE.search(output):
        return True
    if fail_marker and fail_marker in output:
        return True
    return False


def run_case(case_dir, scripts_dir=None, clean_fallback=None,
             default_timeout=600, keep_root=None, verbose=False):
    """Run one case. Returns (ok: bool, lines: list of report lines)."""
    case_dir = Path(case_dir)
    name = case_dir.name
    lines = [f"case {name}"]
    problems = []

    exp_file = case_dir / "expected.json"
    if not exp_file.is_file():
        return False, lines + [f"  FAIL: no expected.json in {case_dir}"]
    try:
        exp = json.loads(exp_file.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, lines + [f"  FAIL: expected.json unreadable: {exc}"]
    for field in ("script", "witness", "description"):
        if not exp.get(field):
            problems.append(f"expected.json lacks a non-empty {field!r}")
    if problems:
        return False, lines + [f"  FAIL: {p}" for p in problems]

    lines.append(f"  script: {exp['script']}")
    lines.append(f"  description: {exp['description']}")
    lines.append(f"  witness: {exp['witness']!r}")

    script_path = resolve_script(exp["script"], case_dir, scripts_dir)
    if script_path is None:
        return False, lines + [
            f"  FAIL: script {exp['script']!r} not found (tried as given, "
            f"relative to the case directory, and under --scripts)"]

    clean_root = case_dir / "clean"
    if clean_root.is_dir():
        clean_files = tree_files(clean_root)
    elif clean_fallback:
        clean_files = tree_files(clean_fallback)
    else:
        return False, lines + [
            "  FAIL: no clean input tree (no clean/ in the case and no "
            "--clean reference given); a mutant without its clean "
            "counterpart proves nothing"]
    if (case_dir / "mutant").is_dir():
        mutant_files = tree_files(case_dir / "mutant")
    else:
        mutant_files = loose_mutant_files(case_dir)
    if not mutant_files:
        return False, lines + ["  FAIL: the mutant input tree is empty"]

    # Null-mutant check: the effective clean and mutant trees (the
    # case's clean/ or the --clean shared tree, vs mutant/ or the
    # loose-file mutant form) must not be byte-identical.
    null_mutant = trees_identical(clean_files, mutant_files)

    timeout = int(exp.get("timeout", default_timeout))
    argv_template = exp.get("argv", [])
    primary = exp.get("input")
    results = {}
    # Kept sandboxes are staged under phase-neutral names; the
    # clean -> run_a / mutant -> run_b mapping is known only to the
    # harness, and no staged path or environment value may encode
    # the phase (see the module docstring's input convention).
    stage_names = {"clean": "run_a", "mutant": "run_b"}
    for phase, files in (("clean", clean_files), ("mutant", mutant_files)):
        keep = None
        if keep_root:
            keep = Path(keep_root) / name / stage_names[phase]
        sandbox = stage_sandbox(script_path, case_dir, files,
                                keep_root=keep)
        staged = sandbox / script_path.parent.name / script_path.name
        if not staged.is_file():   # case-dir staging exception
            staged = sandbox / "scripts" / script_path.name
        try:
            code, output = run_script(staged, argv_template, sandbox,
                                      name, primary, timeout)
        except ValueError as exc:
            return False, lines + [f"  FAIL: {exc}"]
        results[phase] = (code, output)
        if verbose:
            lines.append(f"  --- {phase} run output ---")
            lines += ["  | " + ln for ln in output.splitlines()]
            lines.append(f"  --- end {phase} output (exit {code}) ---")
        if not keep_root:
            shutil.rmtree(sandbox, ignore_errors=True)

    clean_code, clean_out = results["clean"]
    mut_code, mut_out = results["mutant"]

    if null_mutant:
        problems.append(
            "mutant tree is identical to the clean tree — no mutation")
        lines.append("  tree comparison: mutant tree identical to "
                     "the clean tree -- FAIL")
    else:
        lines.append("  tree comparison: clean and mutant trees "
                     "differ -- OK")

    # Symmetric rejection: the case's rejection definition is applied
    # to the clean run too. A clean run that counts as rejected (by
    # exit code, a printed failure verdict, or the fail_marker) means
    # the script was already failing before any mutation.
    clean_rejected = is_rejection(clean_code, clean_out,
                                  exp.get("fail_marker"))
    if clean_rejected:
        problems.append(
            "clean run is itself rejected under the case's rejection "
            "definition — the case proves nothing "
            f"(clean run exit {clean_code})")
        lines.append(f"  clean run: exit {clean_code}, itself "
                     f"rejected under the case's rejection "
                     f"definition -- FAIL")
    elif clean_code == 0:
        lines.append("  clean run: exit 0 -- OK (the unmutated input "
                     "passes, as it must)")
    else:
        problems.append(
            f"clean run exited {clean_code}, expected 0 -- the script "
            f"already fails on the unmutated input, so this case "
            f"proves nothing")
        lines.append(f"  clean run: exit {clean_code} -- FAIL")

    rejected = is_rejection(mut_code, mut_out, exp.get("fail_marker"))
    if rejected:
        lines.append(f"  mutant run: rejected (exit {mut_code}) -- OK")
    else:
        problems.append(
            f"mutant run was NOT rejected (exit {mut_code} and no "
            f"printed failure verdict) -- the script accepted the "
            f"mutated input")
        lines.append(f"  mutant run: exit {mut_code}, no rejection -- FAIL")

    if exp["witness"] in mut_out:
        lines.append("  witness: present in the mutant run's output -- OK")
    else:
        problems.append(
            f"witness {exp['witness']!r} NOT found in the mutant run's "
            f"output -- the rejection, if any, is not demonstrably for "
            f"the stated reason")
        lines.append("  witness: ABSENT from the mutant run's output "
                     "-- FAIL")

    # Witness discrimination: the witness must be a rejection-only
    # string, so it must be absent from the clean run's output.
    if exp["witness"] in clean_out:
        problems.append(
            "witness does not discriminate: present in the clean "
            "run's output")
        lines.append("  witness discrimination: witness PRESENT in "
                     "the clean run's output -- FAIL")
    else:
        lines.append("  witness discrimination: witness absent from "
                     "the clean run's output -- OK")

    ok = not problems
    lines.append(f"  CASE VERDICT: {'PASS' if ok else 'FAIL'}"
                 + ("" if ok else " -- " + "; ".join(problems)))
    return ok, lines


def find_cases(paths):
    """Each path is a case directory, or a container of case directories."""
    cases = []
    for raw in paths:
        p = Path(raw)
        if (p / "expected.json").is_file():
            cases.append(p)
        elif p.is_dir():
            subs = [d for d in sorted(p.iterdir())
                    if d.is_dir() and (d / "expected.json").is_file()]
            cases.extend(subs)
    return cases


def build_parser():
    p = argparse.ArgumentParser(
        prog="red_team.py",
        description="Red-team harness: run a suite script against clean "
                    "and mutated inputs; require the mutant to be "
                    "rejected, with a witness. The clean run must NOT "
                    "itself be rejected under the same definition, the "
                    "witness must be absent from the clean run's "
                    "output, and the mutant tree must differ from the "
                    "clean tree. See the module docstring for the case "
                    "format and the staging input convention.",
        epilog="example: python3 red_team.py kit/examples/red_team "
               "--scripts /path/to/suite/scripts")
    p.add_argument("cases", nargs="*",
                   help="case directories, or directories containing "
                        "case directories")
    p.add_argument("--scripts",
                   help="directory holding the suite scripts, used to "
                        "resolve a bare script name in expected.json")
    p.add_argument("--clean",
                   help="shared clean input tree for cases that have "
                        "no clean/ of their own")
    p.add_argument("--timeout", type=int, default=600,
                   help="per-run timeout in seconds (default 600; a "
                        "case's expected.json may override it)")
    p.add_argument("--keep",
                   help="keep the sandboxes under this directory "
                        "(<dir>/<case>/run_a and run_b -- phase-neutral "
                        "names; the mapping is the harness's alone) for "
                        "inspection; default: sandboxes are temporary "
                        "and removed")
    p.add_argument("--verbose", action="store_true",
                   help="print each run's full output, indented")
    p.add_argument("--selftest", action="store_true",
                   help="run the built-in self-test on toy inputs and exit")
    return p


TOY_SCRIPT = '''\
import sys
text = open(sys.argv[1], encoding="utf-8").read()
if "BADTOKEN" in text:
    print("toy rejection: BADTOKEN present in input")
    sys.exit(3)
print("TOY VERDICT: PASS")
'''

LIAR_SCRIPT = '''\
# Input-ignoring fixture (the red-team loop's shape): never reads its
# input, always prints a failure verdict plus the case's witness, and
# exits 0. On byte-identical clean/mutant trees such a case must FAIL.
print("VERDICT: FAIL")
print("liar witness: always printed")
'''


def selftest():
    problems = []
    with tempfile.TemporaryDirectory(prefix="red_team_selftest_") as td:
        td = Path(td)
        scripts = td / "scripts"
        scripts.mkdir()
        (scripts / "toy_check.py").write_text(TOY_SCRIPT, encoding="utf-8")
        (scripts / "liar_check.py").write_text(LIAR_SCRIPT,
                                               encoding="utf-8")

        def make_case(name, clean_text, mutant_text, witness,
                      script="toy_check.py"):
            case = td / name
            (case / "clean").mkdir(parents=True)
            (case / "mutant").mkdir(parents=True)
            (case / "clean" / "input.txt").write_text(clean_text,
                                                      encoding="utf-8")
            (case / "mutant" / "input.txt").write_text(mutant_text,
                                                       encoding="utf-8")
            (case / "expected.json").write_text(json.dumps({
                "script": script,
                "witness": witness,
                "description": f"self-test case {name}",
                "argv": ["{input}"],
                "input": "input.txt",
            }), encoding="utf-8")
            return case

        good = make_case("good_case", "all fine\n", "has BADTOKEN\n",
                         "toy rejection: BADTOKEN present")
        sneaky = make_case("sneaky_case", "all fine\n", "still fine\n",
                           "toy rejection: BADTOKEN present")
        mute = make_case("mute_case", "all fine\n", "has BADTOKEN\n",
                         "a witness that never appears")
        liar = make_case("liar_case", "same input\n", "same input\n",
                         "liar witness: always printed",
                         script="liar_check.py")
        expectations = [(good, True), (sneaky, False), (mute, False),
                        (liar, False)]
        for case, want in expectations:
            ok, lines = run_case(case, scripts_dir=scripts)
            for ln in lines:
                print("  " + ln)
            status = "ok" if ok == want else "SELFTEST FAILURE"
            print(f"  selftest: {case.name}: harness verdict "
                  f"{'PASS' if ok else 'FAIL'}, expected "
                  f"{'PASS' if want else 'FAIL'} -- {status}")
            if ok != want:
                problems.append(case.name)
    if problems:
        print(f"SELFTEST: FAIL -- wrong verdict for: {problems}")
        return 1
    print("SELFTEST: PASS -- the well-formed case passes; the "
          "unrejected mutant, the witness-less rejection, and the "
          "input-ignoring always-fail script on identical trees are "
          "all failed by the harness, as required")
    return 0


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.selftest:
        return selftest()
    if not args.cases:
        print("error: at least one CASE path is required "
              "(or use --selftest)", file=sys.stderr)
        return 2
    cases = find_cases(args.cases)
    if not cases:
        print("error: no case directories found (a case directory "
              "contains expected.json)", file=sys.stderr)
        return 2
    print("RED_TEAM -- mutant-case harness (Crucible v1.2)")
    print(f"cases: {len(cases)}")
    results = []
    for case in cases:
        ok, lines = run_case(case, scripts_dir=args.scripts,
                             clean_fallback=args.clean,
                             default_timeout=args.timeout,
                             keep_root=args.keep, verbose=args.verbose)
        print()
        for ln in lines:
            print(ln)
        results.append((case.name, ok))
    n_ok = sum(1 for _, ok in results if ok)
    print()
    print(f"SUMMARY: {n_ok}/{len(results)} cases behaved as expected")
    for name, ok in results:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
    print(f"RED_TEAM VERDICT: {'PASS' if n_ok == len(results) else 'FAIL'}")
    return 0 if n_ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
