#!/usr/bin/env python3
"""Crucible v1.1 -- mutation-battery pre-registration and run log.

The mutation battery (GS-4 Gold spec section 8) is evidence only because
its expectations are fixed BEFORE any mutation is run: a mutation whose
expected control does not fire is a finding, and that sentence means
nothing if the expectation was written after seeing the result. This
scaffold enforces the order mechanically:

  1. expect    -- register a mutation: id, target, and EITHER the expected
                  catching control OR an explicit declared scope boundary
                  ("no control expected"). Refused if an observation for
                  that id already exists anywhere in the log directory.
  2. seal-expectations
               -- freeze the expectations file: writes expectations.seal
                  holding its SHA-256 and the sealing time. After this,
                  `expect` refuses all further registrations.
  3. observe   -- record what a mutation run did: observed behaviour,
                  verdict (met | not-met | boundary-confirmed), witness.
                  Refused unless the expectation exists AND the
                  expectations are sealed AND the seal still verifies
                  against the current expectations file. One observation
                  per (id, half); duplicates are refused.
  4. status    -- print the full table and the enforcement state.

PER-HALF WITNESS FILES (v1.1 refinement): with --half N or --half H,
observations go to witness_N.md / witness_H.md instead of RUN_LOG.md, so
each half's witness physically holds only its own half of the log -- the
first run relied on attestation for this separation; the kit makes it
structural. `status` reads all three files.

A mutation's expectation entry and observation entries are single lines
in a documented pipe-separated format inside Markdown files, so the log
stays human-readable and diff-able:

  expectation:  | id | target | expected-control-or-boundary | registered-at |
  observation:  | id | verdict | observed behaviour | witness | observed-at |

EXAMPLE
  python3 mutation_log.py --log mut/ expect --id M1 \\
      --target "provenance relabel in script X" \\
      --expected-control "no control expected -- declared scope boundary"
  python3 mutation_log.py --log mut/ seal-expectations
  python3 mutation_log.py --log mut/ observe --id M1 --half N \\
      --verdict boundary-confirmed --witness "Role D (Arm N)" \\
      --observed "suite green; no check fires on the relabel"

SELF-TEST
  python3 mutation_log.py --selftest
"""
import argparse
import hashlib
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

VERDICTS = ("met", "not-met", "boundary-confirmed")


def now_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_of(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exp_path(log):
    return Path(log) / "expectations.md"


def sealfile_path(log):
    return Path(log) / "expectations.seal"


def obs_files(log):
    log = Path(log)
    return [log / "RUN_LOG.md", log / "witness_N.md", log / "witness_H.md"]


def obs_path_for(log, half):
    if half:
        return Path(log) / f"witness_{half}.md"
    return Path(log) / "RUN_LOG.md"


def read_expectations(log):
    p = exp_path(log)
    entries = {}
    if not p.exists():
        return entries
    for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
        if raw.startswith("| M"):
            cells = [c.strip() for c in raw.strip().strip("|").split("|")]
            if len(cells) >= 4:
                entries[cells[0]] = {"target": cells[1], "expected": cells[2],
                                     "registered_at": cells[3]}
    return entries


def read_observations(log):
    obs = {}
    for p in obs_files(log):
        if not p.exists():
            continue
        for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if raw.startswith("| M"):
                cells = [c.strip() for c in raw.strip().strip("|").split("|")]
                if len(cells) >= 5:
                    obs.setdefault(cells[0], []).append(
                        {"verdict": cells[1], "observed": cells[2],
                         "witness": cells[3], "observed_at": cells[4],
                         "file": p.name})
    return obs


def expectations_sealed_ok(log):
    """Return (sealed?, detail). Sealed means the seal file exists and its
    hash matches the current expectations file."""
    sf = sealfile_path(log)
    if not sf.exists():
        return False, "expectations not sealed"
    recorded = None
    for raw in sf.read_text(encoding="utf-8", errors="replace").splitlines():
        if raw.startswith("sha256:"):
            recorded = raw.split(":", 1)[1].strip()
    if recorded is None:
        return False, "seal file malformed (no sha256 line)"
    if not exp_path(log).exists():
        return False, "expectations file missing"
    if sha256_of(exp_path(log)) != recorded:
        return False, "expectations file differs from its seal (edited after sealing)"
    return True, "sealed and verified"


def clean(text):
    return text.replace("|", "/").replace("\n", " ").strip()


def cmd_expect(args):
    log = Path(args.log)
    log.mkdir(parents=True, exist_ok=True)
    if sealfile_path(log).exists():
        print("REFUSED: expectations are already sealed; the battery is frozen. "
              "New mutations require a new log directory (a new battery).",
              file=sys.stderr)
        return 1
    if args.id in read_observations(log):
        print(f"REFUSED: an observation for {args.id} already exists; an "
              "expectation cannot be registered after its result is known.",
              file=sys.stderr)
        return 1
    exps = read_expectations(log)
    if args.id in exps:
        print(f"REFUSED: expectation for {args.id} is already registered.",
              file=sys.stderr)
        return 1
    expected = args.expected_control or (
        "no control expected -- declared scope boundary: " + (args.scope_boundary or ""))
    if not args.expected_control and not args.scope_boundary:
        print("error: give --expected-control or --scope-boundary", file=sys.stderr)
        return 2
    p = exp_path(log)
    if not p.exists():
        p.write_text("# MUTATION BATTERY -- PRE-REGISTERED EXPECTATIONS "
                     "(Crucible, spec section 8)\n\n"
                     "| id | target | expected control / declared boundary | registered at (UTC) |\n"
                     "|---|---|---|---|\n")
    with p.open("a") as f:
        f.write(f"| {args.id} | {clean(args.target)} | {clean(expected)} | {now_utc()} |\n")
    print(f"expectation registered: {args.id}")
    return 0


def cmd_seal(args):
    log = Path(args.log)
    if not exp_path(log).exists() or not read_expectations(log):
        print("REFUSED: no expectations registered yet.", file=sys.stderr)
        return 1
    if sealfile_path(log).exists():
        print("REFUSED: expectations already sealed.", file=sys.stderr)
        return 1
    sealfile_path(log).write_text(
        "# EXPECTATIONS SEAL (Crucible mutation battery)\n"
        f"sha256: {sha256_of(exp_path(log))}\n"
        f"sealed_at_utc: {now_utc()}\n"
        f"expectations: {len(read_expectations(log))}\n")
    print(f"expectations sealed: {len(read_expectations(log))} mutation(s), "
          f"sha256 {sha256_of(exp_path(log))[:16]}...")
    return 0


def cmd_observe(args):
    log = Path(args.log)
    sealed, detail = expectations_sealed_ok(log)
    if not sealed:
        print(f"REFUSED: cannot record an observation -- {detail}. "
              "Pre-registration must be complete and sealed first.",
              file=sys.stderr)
        return 1
    exps = read_expectations(log)
    if args.id not in exps:
        print(f"REFUSED: no pre-registered expectation for {args.id}.",
              file=sys.stderr)
        return 1
    target_file = obs_path_for(log, args.half)
    existing = read_observations(log).get(args.id, [])
    if any(o["file"] == target_file.name for o in existing):
        print(f"REFUSED: an observation for {args.id} already exists in "
              f"{target_file.name}; observations are write-once per half.",
              file=sys.stderr)
        return 1
    if not target_file.exists():
        target_file.write_text(
            f"# MUTATION RUN LOG{' -- WITNESS HALF ' + args.half if args.half else ''} "
            "(Crucible, spec section 8)\n\n"
            "| id | verdict | observed behaviour | witness | observed at (UTC) |\n"
            "|---|---|---|---|---|\n")
    with target_file.open("a") as f:
        f.write(f"| {args.id} | {args.verdict} | {clean(args.observed)} | "
                f"{clean(args.witness)} | {now_utc()} |\n")
    print(f"observation recorded: {args.id} -> {args.verdict} ({target_file.name})")
    return 0


def cmd_status(args):
    log = Path(args.log)
    sealed, detail = expectations_sealed_ok(log)
    exps = read_expectations(log)
    obs = read_observations(log)
    print(f"Mutation log: {log}")
    print(f"Expectations: {len(exps)} registered; state: {detail}")
    print(f"{'id':<6} {'verdict':<19} expected control / boundary")
    for mid in sorted(exps):
        got = obs.get(mid, [])
        verdict = ", ".join(o["verdict"] for o in got) if got else "(not run)"
        print(f"{mid:<6} {verdict:<19} {exps[mid]['expected']}")
    extra = sorted(set(obs) - set(exps))
    if extra:
        print("WARNING: observations with no expectation:", ", ".join(extra))
    return 0


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Crucible mutation-battery pre-registration and run log "
                    "(spec section 8). Expectations seal before observations exist.")
    p.add_argument("--log", default="mutations_log",
                   help="log directory (default: mutations_log)")
    p.add_argument("--selftest", action="store_true",
                   help="run the built-in self-test and exit")
    sub = p.add_subparsers(dest="command")
    e = sub.add_parser("expect", help="pre-register a mutation's expectation")
    e.add_argument("--id", required=True)
    e.add_argument("--target", required=True)
    e.add_argument("--expected-control",
                   help="the control expected to catch this mutation")
    e.add_argument("--scope-boundary",
                   help="why no control is expected (declared scope boundary)")
    sub.add_parser("seal-expectations", help="freeze the expectations file")
    o = sub.add_parser("observe", help="record a run observation (requires sealed expectations)")
    o.add_argument("--id", required=True)
    o.add_argument("--verdict", required=True, choices=VERDICTS)
    o.add_argument("--observed", required=True)
    o.add_argument("--witness", required=True)
    o.add_argument("--half", choices=["N", "H"],
                   help="write to this half's witness file instead of RUN_LOG.md")
    sub.add_parser("status", help="print the battery table")
    return p.parse_args(argv)


def selftest():
    import contextlib, io
    with tempfile.TemporaryDirectory() as td:
        log = str(Path(td) / "mut")
        def run(argv):
            with contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(io.StringIO()):
                return main(argv)
        assert run(["--log", log, "observe", "--id", "M1", "--verdict", "met",
                    "--observed", "x", "--witness", "w"]) == 1
        print("SELFTEST mutation_log: observation before pre-registration refused")
        assert run(["--log", log, "expect", "--id", "M1", "--target", "t",
                    "--expected-control", "checker H"]) == 0
        assert run(["--log", log, "observe", "--id", "M1", "--verdict", "met",
                    "--observed", "x", "--witness", "w"]) == 1
        print("SELFTEST mutation_log: observation before expectations sealed refused")
        assert run(["--log", log, "seal-expectations"]) == 0
        assert run(["--log", log, "expect", "--id", "M2", "--target", "t",
                    "--expected-control", "c"]) == 1
        print("SELFTEST mutation_log: registration after sealing refused")
        assert run(["--log", log, "observe", "--id", "M9", "--verdict", "met",
                    "--observed", "x", "--witness", "w"]) == 1
        print("SELFTEST mutation_log: observation for unregistered id refused")
        assert run(["--log", log, "observe", "--id", "M1", "--verdict", "met",
                    "--observed", "checker fired", "--witness", "Role D (Arm N)",
                    "--half", "N"]) == 0
        assert (Path(log) / "witness_N.md").exists()
        assert run(["--log", log, "observe", "--id", "M1", "--verdict", "met",
                    "--observed", "dup", "--witness", "w", "--half", "N"]) == 1
        print("SELFTEST mutation_log: per-half witness file written; duplicate refused")
        (Path(log) / "expectations.md").write_text(
            Path(log, "expectations.md").read_text() + "| M7 | late | edit | now |\n")
        assert run(["--log", log, "observe", "--id", "M1", "--verdict", "met",
                    "--observed", "x", "--witness", "w", "--half", "H"]) == 1
        print("SELFTEST mutation_log: post-seal expectations edit detected; "
              "further observations refused")
        print("SELFTEST mutation_log: PASS")


def main(argv=None):
    args = parse_args(argv)
    if args.selftest:
        selftest()
        return 0
    if args.command == "expect":
        return cmd_expect(args)
    if args.command == "seal-expectations":
        return cmd_seal(args)
    if args.command == "observe":
        return cmd_observe(args)
    if args.command == "status":
        return cmd_status(args)
    print("error: a subcommand is required (expect | seal-expectations | "
          "observe | status), or use --selftest", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
