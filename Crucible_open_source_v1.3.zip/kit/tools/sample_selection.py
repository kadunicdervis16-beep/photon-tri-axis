#!/usr/bin/env python3
"""Crucible v1.1 -- deterministic claim-sample selection.

Implements the Crucible's sample rule (GS-4 Gold spec section 7) over a
plain TSV claim registry, so any paper's claims can be sampled by rule
rather than by hand. Paper-agnostic: no claim IDs, section numbers, or
badge strings from any particular paper appear below; every paper-specific
choice is an input (the registry) or an option (markers, section lists,
quotas).

INPUT -- the registry TSV (see templates/REGISTRY_INPUT.tsv). Columns:
  claim_id          unique claim identifier (any string without tabs)
  category          native | counting | ordering | hybrid | declaration
                    (may be left blank; see assignment rules below)
  badge             the claim's badge string, verbatim ("" if none)
  home_section      the claim's home section number in the paper ("" ok)
  dependencies      semicolon-separated dependency tokens (may be empty):
                      <claim_id>     an edge to another claim in the TSV
                      cond:<name>    a falsification condition
                      src:<name>     a source-paper / external premise
                      label:<name>   an indirection label (see below)
                      receipt:<name> an indirection receipt (see below)
  named_by_conditions  semicolon-separated condition names whose text
                    names this claim (the inbound-condition component)

INDIRECTION: labels and receipts often stand for a set of claims. Pass
--indirections FILE with lines of the form
    label:<name> = claimA, claimB, ...
    receipt:<name> = claimC, ...
and each indirection token in a dependencies cell expands to edges to
every listed claim. Unexpanded tokens are still recorded in the audit
trail as edges to the token itself (kind label/receipt).

CATEGORY ASSIGNMENT (only for rows whose category cell is blank; first
match wins, mirroring spec 7.2):
  (i)   badge contains the hybrid marker (default "MACHINE / AUTHOR",
        override with --hybrid-marker)                    -> hybrid
  (ii)  home_section is in --ordering-sections            -> ordering
  (iii) home_section is in --counting-sections            -> counting
  (iv)  badge equals --declaration-badge (if given)       -> declaration
  (v)   otherwise                                         -> native

CENTRALITY (spec 7.3): score = (inbound edges from other claims, after
indirection expansion) + (inbound edges from falsification conditions,
from named_by_conditions) + (outbound edges to src: premises, distinct
targets). Ranking inside a pool: score descending, ties by claim_id
ascending (lexicographic). Quotas are filled in the order hybrid,
declaration, ordering, counting, native; defaults --quotas
hybrid=2, declaration=1, ordering=2, counting=3, native=4 (the twelve of
the first run). The full audit trail -- edge list, per-claim score
components, ranked pools, the sample -- is printed and, with --out,
written to a record file.

EXAMPLE
  python3 sample_selection.py --registry registry.tsv \\
      --indirections indirections.txt --out sample_selection.txt

SELF-TEST
  python3 sample_selection.py --selftest
"""
import argparse
import sys
import tempfile
from pathlib import Path

CATEGORIES = ("native", "counting", "ordering", "hybrid", "declaration")
FILL_ORDER = ("hybrid", "declaration", "ordering", "counting", "native")
DEFAULT_QUOTAS = {"hybrid": 2, "declaration": 1, "ordering": 2,
                  "counting": 3, "native": 4}


def split_cell(cell):
    return [t.strip() for t in (cell or "").split(";") if t.strip()]


def load_registry(path):
    rows = {}
    order = []
    header = None
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        cells = raw.split("\t")
        if header is None:
            header = [c.strip() for c in cells]
            continue
        rec = {}
        for i, name in enumerate(header):
            rec[name] = cells[i].strip() if i < len(cells) else ""
        cid = rec.get("claim_id", "")
        if not cid:
            continue
        rows[cid] = rec
        order.append(cid)
    if header is None:
        raise SystemExit("registry has no header row")
    for col in ("claim_id", "category", "badge", "dependencies"):
        if col not in header:
            raise SystemExit(f"registry is missing required column: {col}")
    return rows, order


def load_indirections(path):
    table = {}
    if not path:
        return table
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, members = line.split("=", 1)
        table[key.strip()] = [m.strip() for m in members.split(",") if m.strip()]
    return table


def assign_category(rec, args, sections_ordering, sections_counting):
    cat = rec.get("category", "").strip().lower()
    if cat:
        if cat not in CATEGORIES:
            raise SystemExit(f"unknown category {cat!r} for claim {rec['claim_id']}")
        return cat, "registry"
    badge = rec.get("badge", "")
    hs = rec.get("home_section", "").strip()
    if args.hybrid_marker and args.hybrid_marker in badge:
        return "hybrid", "rule(i) hybrid marker"
    if hs and hs in sections_ordering:
        return "ordering", "rule(ii) ordering section"
    if hs and hs in sections_counting:
        return "counting", "rule(iii) counting section"
    if args.declaration_badge and badge.strip() == args.declaration_badge:
        return "declaration", "rule(iv) declaration badge"
    return "native", "rule(v) default"


def select(rows, order, indirections, args):
    sec_o = set(split_cell(args.ordering_sections.replace(",", ";")))
    sec_c = set(split_cell(args.counting_sections.replace(",", ";")))
    quotas = dict(DEFAULT_QUOTAS)
    if args.quotas:
        for kv in args.quotas.split(","):
            k, v = kv.split("=")
            if k.strip() not in CATEGORIES:
                raise SystemExit(f"unknown quota category: {k}")
            quotas[k.strip()] = int(v)

    category = {}
    cat_how = {}
    for cid in order:
        category[cid], cat_how[cid] = assign_category(rows[cid], args, sec_o, sec_c)

    edges = []            # (src, dst, kind)
    inbound_claims = {c: 0 for c in order}
    inbound_conds = {c: 0 for c in order}
    outbound_src = {c: 0 for c in order}
    for cid in order:
        conds = split_cell(rows[cid].get("named_by_conditions", ""))
        inbound_conds[cid] = len(set(conds))
        for cond in sorted(set(conds)):
            edges.append((f"cond:{cond}", cid, "condition-names-claim"))
        src_seen = set()
        for tok in split_cell(rows[cid].get("dependencies", "")):
            if tok.startswith("cond:"):
                edges.append((cid, tok, "condition"))
            elif tok.startswith("src:"):
                edges.append((cid, tok, "premise"))
                if tok not in src_seen:
                    src_seen.add(tok)
                    outbound_src[cid] += 1
            elif tok.startswith("label:") or tok.startswith("receipt:"):
                kind = tok.split(":", 1)[0]
                members = indirections.get(tok)
                if members:
                    for m in members:
                        if m in rows and m != cid:
                            edges.append((cid, m, f"{kind}-expanded"))
                            inbound_claims[m] += 1
                        else:
                            edges.append((cid, m, f"{kind}-expanded-external"))
                else:
                    edges.append((cid, tok, kind + "-unexpanded"))
            elif tok in rows:
                if tok != cid:
                    edges.append((cid, tok, "claim"))
                    inbound_claims[tok] += 1
            else:
                edges.append((cid, tok, "external"))
    score = {c: inbound_claims[c] + inbound_conds[c] + outbound_src[c] for c in order}

    pools = {}
    for cid in order:
        pools.setdefault(category[cid], []).append(cid)
    for k in pools:
        pools[k].sort(key=lambda c: (-score[c], c))

    sample, used = [], set()
    for k in FILL_ORDER:
        for cid in pools.get(k, []):
            if len([s for s in sample if category[s] == k]) >= quotas[k]:
                break
            if cid not in used:
                sample.append(cid)
                used.add(cid)

    out = []
    out.append("CRUCIBLE -- SAMPLE SELECTION RECORD (deterministic; spec section 7)")
    out.append(f"Registry claims parsed: {len(order)}; edges: {len(edges)}.")
    out.append(f"Quotas: {quotas}; fill order: {', '.join(FILL_ORDER)}.")
    out.append(f"Hybrid marker: {args.hybrid_marker!r}; ordering sections: "
               f"{sorted(sec_o)}; counting sections: {sorted(sec_c)}; "
               f"declaration badge: {args.declaration_badge!r}.")
    out.append("")
    out.append("EDGE LIST (src -> dst [kind]):")
    for s, d, k in sorted(edges):
        out.append(f"  {s} -> {d} [{k}]")
    out.append("")
    out.append("SCORES (claim: inbound_claims + inbound_conditions + outbound_src = centrality):")
    for c in sorted(order, key=lambda c: (-score[c], c)):
        out.append(f"  {c}: {inbound_claims[c]} + {inbound_conds[c]} + "
                   f"{outbound_src[c]} = {score[c]}  [pool: {category[c]} via {cat_how[c]}]")
    out.append("")
    out.append("POOLS (ranked):")
    for k in FILL_ORDER:
        out.append(f"  {k}: {pools.get(k, [])}")
    out.append("")
    out.append(f"THE SAMPLE ({len(sample)} claims, fill order "
               f"{', '.join(FILL_ORDER)}):")
    for c in sample:
        out.append(f"  {c}  [pool: {category[c]}; score: {score[c]}]")
    import json
    out.append("")
    out.append("Sample JSON: " + json.dumps(sample))
    return "\n".join(out) + "\n", sample


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Deterministic Crucible claim-sample selection (spec section 7).")
    p.add_argument("--registry", help="registry TSV (see templates/REGISTRY_INPUT.tsv)")
    p.add_argument("--indirections", help="optional indirection file: "
                                            "'label:<name> = id1, id2, ...' per line")
    p.add_argument("--out", help="write the selection record to this file "
                                 "(default: stdout only)")
    p.add_argument("--hybrid-marker", default="MACHINE / AUTHOR",
                   help="badge substring marking the hybrid pool "
                        "(default: 'MACHINE / AUTHOR')")
    p.add_argument("--ordering-sections", default="",
                   help="comma-separated home_section values for the ordering pool")
    p.add_argument("--counting-sections", default="",
                   help="comma-separated home_section values for the counting pool")
    p.add_argument("--declaration-badge", default="",
                   help="exact badge string marking the declaration pool")
    p.add_argument("--quotas", default="",
                   help="comma-separated category=n overrides "
                        "(default hybrid=2,declaration=1,ordering=2,counting=3,native=4)")
    p.add_argument("--selftest", action="store_true",
                   help="run the built-in toy-registry self-test and exit")
    return p.parse_args(argv)


TOY_TSV = (
    "claim_id\tcategory\tbadge\thome_section\tdependencies\tnamed_by_conditions\n"
    "N1\tnative\t[LEVEL A]\t1\tN2\t\n"
    "N2\tnative\t[LEVEL A]\t2\t\thard\n"
    "N3\tnative\t[LEVEL A]\t2\tsrc:PriorPaper\t\n"
    "N4\tnative\t[LEVEL A]\t3\t\t\n"
    "C1\tcounting\t[LEVEL A]\t5\tN1; src:PriorPaper\thard\n"
    "C2\tcounting\t[LEVEL A]\t8\tlabel:core\t\n"
    "C3\tcounting\t[LEVEL A]\t8\t\t\n"
    "C4\tcounting\t[LEVEL A]\t9\tC1\t\n"
    "O1\tordering\t[LEVEL A]\t11\tC1\t\n"
    "O2\tordering\t[LEVEL A]\t11\t\t\n"
    "H1\thybrid\t[LEVEL A: MACHINE / AUTHOR]\t6\tC1; O1\t\n"
    "H2\thybrid\t[LEVEL A: MACHINE / AUTHOR]\t6\t\t\n"
    "D1\tdeclaration\t[LEVEL A: AUTHOR]\t0\t\t\n"
)
TOY_IND = "label:core = N1, C1\n"
# Hand-computed: inbound_claims: N1 gets C1 + label-expansion from C2 = 2;
# N2 gets N1 = 1; C1 gets C4, O1, H1, label-expansion from C2 = 4.
# inbound_conds: N2 = 1 (hard), C1 = 1 (hard).
# outbound_src: N3 = 1, C1 = 1.
# scores: C1=4+1+1=6, N1=2, N2=1+1=2, N3=1, H1=0, O1=0, others 0.
# Pools ranked: hybrid [H1,H2] (tie 0 -> lexicographic), declaration [D1],
# ordering [O1,O2], counting [C1(6), C2(0), C3(0), C4(0)] -> C2,C3,C4 lex,
# native [N1(2), N2(2), N3(1), N4(0)] -> N1 before N2 on tie.
EXPECTED = ["H1", "H2", "D1", "O1", "O2", "C1", "C2", "C3",
            "N1", "N2", "N3", "N4"]


def selftest():
    with tempfile.TemporaryDirectory() as td:
        reg = Path(td) / "registry.tsv"
        ind = Path(td) / "indirections.txt"
        reg.write_text(TOY_TSV)
        ind.write_text(TOY_IND)
        rows, order = load_registry(reg)
        indt = load_indirections(ind)
        args = parse_args(["--registry", str(reg)])
        record, sample = select(rows, order, indt, args)
        assert sample == EXPECTED, f"sample mismatch:\n got {sample}\nwant {EXPECTED}"
        # determinism: a second run must produce byte-identical record
        record2, _ = select(rows, order, indt, args)
        assert record == record2, "selection is not deterministic"
        print("SELFTEST sample_selection: toy registry (13 claims) parsed")
        print("SELFTEST sample_selection: hand-computed sample reproduced: "
              + ", ".join(sample))
        print("SELFTEST sample_selection: repeat run byte-identical (deterministic)")
        print("SELFTEST sample_selection: PASS")


def main(argv=None):
    args = parse_args(argv)
    if args.selftest:
        selftest()
        return 0
    if not args.registry:
        print("error: --registry is required (or use --selftest)", file=sys.stderr)
        return 2
    rows, order = load_registry(args.registry)
    indirections = load_indirections(args.indirections)
    record, sample = select(rows, order, indirections, args)
    sys.stdout.write(record)
    if args.out:
        Path(args.out).write_text(record)
    return 0


if __name__ == "__main__":
    sys.exit(main())
