THE CRUCIBLE -- INSTRUMENT KIT
Version: Crucible v1.1 (kit accompanying the GS-4 Gold v1.0 design)
Release: open, by its author, for anyone's use (see README.txt and
CREDITS.txt in the release root).

WHAT THIS KIT IS
The v1.0 release published the Crucible's design (GS4_GOLD_SPEC.md), a
plain-language README, the first run's full trial report as a worked
example, and its credits. That is a description plus an example. This
kit is the addition GPT-6's closing advice called for -- the part that
makes the Crucible a reusable verification INSTRUMENT: everything a
researcher who has never seen the originating work needs to take the
specification, run the benches on their own paper, inspect the
evidence, and reproduce the adjudication. (The principle is quoted in
full in REPRODUCIBILITY.txt.)

CONTENTS
  QUICKSTART.txt        the stranger's path, step by step, in order:
                        prepare, freeze, sample, blind packet, briefs,
                        examine, seal, mutate, adjudicate blind,
                        unblind and report, publish everything.
  REPRODUCIBILITY.txt   how the first run's adjudication reproduces
                        from its published record (artifact -> step ->
                        what to check), the reproduction procedure, and
                        the record layout a new run must keep.
  templates/            blank artifacts generalized from the first run:
                        the four role charters, the hostile overlay,
                        the freeze record (with the v1.1 environment
                        block), the submission, the finding card, the
                        adjudication, the charter-integrity audit, the
                        registry input shape, and the protocol notes.
  tools/                four working scripts, python3 standard library
                        only, every path an argument, no constants from
                        any paper:
                        - sample_selection.py: the deterministic
                          claim sample (quotas, centrality, audit
                          trail) over a TSV registry.
                        - blind_packet.py: strips status material and
                          refuses to release a packet whose
                          verification scan is not zero.
                        - seal.py: write-once sealing and verification
                          of a submissions tree.
                        - mutation_log.py: mutation pre-registration
                          with mechanically enforced ordering
                          (expectations seal before observations
                          exist) and per-half witness files.
                        Each tool has --help and a --selftest that runs
                        clean on toy inputs.

v1.1 REFINEMENTS FOLDED IN (over the first run's practice)
- Per-half mutation witness FILES (structural separation, not
  attestation) -- templates/PROTOCOL_NOTES.txt note 2, mutation_log.py
  --half.
- The continuation-agent rule, formalized -- PROTOCOL_NOTES note 1.
- The environment freeze in the freeze record -- templates/
  FREEZE_RECORD.md section 3, and Role D's environment record.
- The anonymization style caveat stated where adjudicators will see
  it -- PROTOCOL_NOTES note 4.

WHAT DID NOT GENERALIZE (named, per the release's own discipline)
- The first run's packaging scripts that parse a specific paper's
  internals (its registry tables, its script manifest, its listing
  format -- select_sample.py / make_blind.py / make_cards.py /
  build_briefs.py / assemble_data.py in the trial record) are
  paper-shaped by nature. The kit generalizes their FUNCTIONS
  (sampling over a declared TSV; stripping + zero-scan; card format as
  a template) but a new user must still connect the sampler to their
  own registry -- that connection is the TSV, and filling it honestly
  is the user's work, not a script's.
- Card extraction and report assembly remain coordinator work guided
  by templates; no tool in this kit pretends to anonymize prose
  automatically, because argument-text fidelity is checked by diffing,
  and the diff needs a human (or agent) who answers for it.

HONESTY LABELS (unchanged from v1.0)
An independent-context trial, not independent human review unless the
examiners are. It awards no badge by itself and validates no physics.
Publish everything: failures, defences, inconclusive attacks,
disagreements, code, logs, versions, corrections.

================================================================
v1.2 NOTE (added in the v1.2 release; everything above is v1.1,
unchanged)
================================================================
v1.2 adds ONE tool and one worked-examples directory; nothing above
changes, and no v1.1 file is modified by this addition except this
readme's note itself.

  tools/red_team.py     the red-team harness (external form):
                        runs a suite script against a clean input
                        tree and a mutated input tree and requires
                        the mutant to be REJECTED -- nonzero exit or
                        a printed failure verdict -- AND to carry a
                        declared witness substring in its output, so
                        the script must fail for the stated reason,
                        not merely fail. This is the reusable,
                        outside-the-script form of the mutant
                        batteries the originating suite's scripts
                        carry internally. A case is a directory:
                        expected.json (script, witness, description)
                        plus clean/ and mutant/ input trees. Because
                        suite scripts locate their inputs in
                        incompatible ways (an argv path; paths
                        resolved from the script's own location;
                        data embedded in the script itself), the
                        harness uses a staging convention -- the
                        script's directory is copied into a fresh
                        sandbox and the input tree is overlaid onto
                        the sandbox root -- specified in full in the
                        tool's docstring and --help. Standard library
                        only; --selftest included, like the other
                        tools.

  examples/red_team/    three worked cases against the originating
                        paper's round-11 suite scripts (an ordering-
                        key mutant, a spine-declaration mutant, a
                        quotation mutant -- one per input mechanism),
                        with a README stating the convention and the
                        one named limit (the quotation case relies on
                        its script's own source-resolution chain),
                        and RUN_LOG.txt recording the harness run:
                        3/3 cases behaved as expected.

  Harness hardening (added to this v1.2 note; the tool's docstring
  is the full specification): the rejection definition is now
  applied SYMMETRICALLY -- a clean run that itself counts as
  rejected (nonzero exit, a printed failure verdict, or the case's
  fail_marker) fails the case, since it proves nothing; the
  declared witness must be ABSENT from the clean run's output, not
  merely present in the mutant run's (a witness that does not
  discriminate fails the case); the effective clean and mutant
  input trees are compared file-by-file and byte-by-byte, and
  identical trees fail the case as a null mutant; and the harness
  no longer tells the script which run it is in -- the
  RED_TEAM_PHASE environment variable is removed (and stripped if
  inherited), and sandboxes kept with --keep are staged under the
  phase-neutral names run_a / run_b. The --selftest gains a fourth
  toy case in exactly the shape these checks close (an
  input-ignoring script that always prints a failure verdict plus
  the witness and exits 0, on identical trees), which the harness
  must fail. The three worked examples above still pass 3/3 under
  the hardened harness, and RUN_LOG.txt has been regenerated from
  that hardened run.

  The kit now also ships kit/examples/miniature/ -- 'The Pebble
  Ledger', a paper-agnostic miniature on which the sample-selection
  rule and red-team harness passed and the Paper-12-shaped
  instruments' limits were found and recorded (see
  MINIATURE_RUN_LOG.md therein).

================================================================
v1.3 NOTE (added in the v1.3 release; everything above is
unchanged)
================================================================
v1.3 names the two editions of the Crucible:

  FRONTIER (Tier Z/F, v1.2 mechanics) -- the edition above: the
                        zip (Tier Z) and its members sent as
                        individual files (Tier F), under the v1.2
                        mechanics.

  STANDARD (Tier T)     -- the Standard Edition: the same trial
                        carried by text-only mechanics.

Same trial, two mechanics, chosen by the agent's interface, never
by the paper's convenience.

The STANDARD edition's governing document is
standard/PROTOCOL_T.md.
