================================================================================
CRUCIBLE TEXT EDITION — PART 2 OF 8 — README
Source: README.txt — sha256 599d5ba83711bbd97ef5760f704e551472d6c363e2b494a922bba587edf4325c — 11489 bytes
Each body below is byte-identical to its source in Crucible_open_source_v1.2.zip.
================================================================================
THE CRUCIBLE
A two-arm independent-context acceptance trial for research papers
Design: GS-4 Gold v1.0
First run: Paper 12, "The Aggregated Ledger," 31 October 2026


WHAT IT IS
----------

The Crucible is a pre-publication acceptance trial. Before a paper is
published, it is frozen -- one exact file, hashed, unchangeable for the
duration of the trial -- and examined by two teams of examiners who did
not write it, did not build its verification apparatus, and are not
given the author's audit trail.

There are two arms, working in complete isolation from each other:

  * Arm N, the neutral arm: examiners who reconstruct, test, and audit
    the paper exactly as an ordinary independent audit would.

  * Arm H, the hostile arm -- the gatekeeper: the same examiner roles
    working under a disclosed hostility charter. The gatekeeper is
    chartered, in writing, to make the paper fail. It argues from the
    incumbent framework the paper departs from (in the first run,
    continuous calculus and the conventional formalism): it presumes
    every claim defective, takes the reading least favourable to the
    author wherever the text admits more than one, treats every
    disclosure as a possible concealment and every scope statement as
    a possible retreat, and argues for the harshest verdict first,
    letting the evidence talk it down.

Both arms receive exactly the same packet: the frozen paper, the
protocol, and only the source texts the paper itself declares. No
prior audit reports, no earlier verdicts, no author explanations, no
private fixtures.

Every finding from either arm is then stripped of its author's
identity -- the findings are anonymized onto re-keyed cards -- and a
single adjudicator who ran nothing judges all of them under one
evidence standard, without knowing which arm, or which examiner,
produced any of them. Neither the gatekeeper's confidence nor the
defenders' confidence counts as evidence. Only witnesses count.

Every objection, from either arm, must be classified into exactly one
of five categories, which may never be merged:

  (A) a genuine contradiction under the paper's own framework's rules;
  (B) a missing derivation that a claim requires;
  (C) an unestablished bridge from the discrete mathematics to
      physical measurement;
  (D) a disagreement over mathematical foundations or ontology;
  (E) a question the paper explicitly leaves open.

Only categories (A) and (B) can break a claim. Category (C) is a
bridge verdict, judged by what the claim itself asserts. Categories
(D) and (E) are never defects at all -- and under this classification
they cannot be dressed up as defects, which is precisely the fraud a
hostile audit would otherwise be able to commit.

One strict rule binds the gatekeeper: hostility is permitted, rigging
is not. It may not declare a defect merely because the paper does not
use its preferred mathematical language. Every alleged failure must
name the exact claim, the requirement that claim entails, and the
failure under the paper's declared premises. An objection that cannot
do all three is a statement of philosophical compatibility, not of
mathematical validity, and the adjudicator files it as such.

Finally, the whole record is published with the paper: the failures,
the successful defences, the inconclusive attacks, the disagreements
between examiners, the test code, the logs, the versions, and the
corrections. Not only the favourable results.


THE PROBLEM IT ANSWERS
----------------------

Self-certification. A research programme can be rigorously
self-checked and still be grading its own work: the same environment
defines a claim, chooses its representation, implements its checker,
classifies the result, and audits the relationship between those
steps. Honest work can share one blind spot across all five steps, and
no amount of additional checking inside the same environment removes
it. The evidence that changes confidence is different in kind: can
someone who did not build the paper -- or someone chartered to want
it dead -- reconstruct its results from its declared sources, name
everything it assumes, and fail to break it under rules that give the
attack every fair chance?

The Crucible is built to produce exactly that evidence, and to make
the attack's failure -- or success -- a matter of public record
rather than of anyone's assurance.


HOW TO RUN IT
-------------

The full protocol is GS4_GOLD_SPEC.md in this package. In outline:

  1. FREEZE. Fix the exact paper under trial. Record its hash, its
     line count, and the result of its own verification suite run on
     that exact tree. Any change after the freeze invalidates the
     trial.

  2. PACKET. Assemble the examiner packet: the frozen paper, the
     protocol extract, and the paper's declared source texts. Nothing
     else. Verify the exclusions. One part of the packet -- the badge
     blind test -- is generated by a packaging step that strips every
     badge label and registry verdict from the sampled claim
     statements, and the stripping is verified mechanically (a search
     for badge tokens must return zero) before the packet is released.

  3. SAMPLE. Twelve claims are selected by a deterministic, recorded
     rule over the paper's claim registry (fixed category quotas;
     ranking by dependency centrality), executed by the packaging
     step. Nobody -- not the coordinator, not the examiners -- picks
     the claims by hand.

  4. EXAMINE, IN ISOLATION. Each arm fields four roles: a native
     reconstructor, a proof-and-counterexample examiner, a provenance
     and badge examiner, and an implementation and reproducibility
     examiner. Arm H's roles work under the additional hostility
     charter, printed verbatim in the specification. Examiners do not
     see each other's work, do not see the other arm's work, and do
     not see any prior audit material. Each role's submission is
     sealed -- written once, hashed -- before any cross-reading is
     possible. A pre-registered battery of deliberate corruptions
     (mutations: wrong provenance classifications, split badge
     allocations, deleted registry rows, altered fixtures, truncated
     quotations, and more) is run on copies of the paper's apparatus,
     each with its expected catching control named in advance, so a
     miss cannot be redefined as out of scope afterwards.

  5. ADJUDICATE, BLIND. All findings are extracted onto anonymized,
     re-keyed cards; the key is sealed. A non-running adjudicator
     applies the one evidence standard: verdicts of HELD, LIMIT,
     OUTSIDE, or BROKE; a BROKE requires a reproducible witness and an
     independent second route, or it is downgraded. The adjudicator
     also verifies every finding's five-category classification and
     re-categorizes in the open where a filing is wrong. Badges are
     frozen before anyone is unblinded.

  6. AUDIT THE HOSTILITY. After unblinding, a separate auditor scores
     the hostile arm's sealed record: did it actually behave
     hostilely -- arguing for the harshest verdict first, taking
     unfavourable readings, conceding only where the evidence forced
     it? The verdict (in the first run: HOSTILITY DEMONSTRATED) is
     part of the published record. A hostile arm that pulled its
     punches would prove nothing, and the record would say so.

  7. PUBLISH EVERYTHING. The trial report and its complete evidence
     package are published alongside the paper. Findings are not
     repaired by the trial; they go to the author as a list, and the
     author rules on each repair in the open.


WHAT IT IS NOT
--------------

  * It is not independent human review. In the first run, both arms
    were teams of AI agents, information-isolated from the authoring
    environment but of the same model family. The isolation is real --
    of information and context -- and it is not the same species as
    independent human examiners. The method does not claim otherwise,
    and its results must never be reported as external validation.

  * It is not physical validation. Passing the trial establishes an
    internal-consistency and reproducibility result over the tested
    claims and domains. Whether a framework's native results describe
    nature is a separate, empirical question, answered by bridges to
    measurement and discriminating observations, not by any audit.

  * It awards no badge by itself. Examiners propose; the blinded
    adjudicator assigns; the author rules on repairs.


THE FIRST RUN
-------------

The Crucible's first full run was executed on 31 October 2026 against
Paper 12, "The Aggregated Ledger" (Dervis Kadunic), part of the
"Departure From the Photon Baseline" series. The frozen paper was the
round-10 corrected tree (SHA-256 fc0499af...), its own suite green
18/18 on that exact tree. The complete trial report is included in
this package as TRIAL_REPORT_first_run.md.

The headline result, stated plainly:

  * 87 findings were adjudicated: 38 HELD, 31 LIMIT, 15 OUTSIDE,
    3 BROKE.
  * All three sustained BROKE verdicts were filed by the hostile arm.
    (It proposed four; one was downgraded under the evidence
    standard. The neutral arm proposed none.) The three sustained
    verdicts cover two underlying defects: a bridge-term exclusivity
    claim breached by the paper's own appendix, and a badge
    definition in tension with the paper's pricing practice -- the
    second of these independently matching an item the author's own
    internal audit had already parked for his ruling.
  * The mutation battery ran 24 pre-registered corruptions: 14 were
    caught as expected, 7 confirmed a stated boundary, and 3 escaped
    their controls -- each escape itself recorded as a finding.
  * The charter-integrity audit returned HOSTILITY DEMONSTRATED: the
    gatekeeper's hostility is a matter of sealed record, not of
    anyone's description.
  * Of the method's eight acceptance gates, six passed, one failed
    (on a single limb: changes made by correction rounds that no
    automated check tests), and one was left undecided pending an
    author's ruling the trial does not make for him.

Nothing in the trial edited the paper. Every defect it sustained
went to the author as a list, for his rulings, in the open.


CREDITS AND RELEASE
-------------------

The Crucible exists because GPT-6 (ChatGPT), asked what would change
his confidence in this research programme, proposed the independent
acceptance trial that became GS-4 -- and then, reviewing the two-arm
design, made it harder to cheat. The hostile gatekeeper arm, the
gold-standard engineering of the protocol, and the execution are
Dervis Kadunic's and his house team's. See CREDITS.txt for the full
account; credit where due is part of the method.

The method is released openly by its author, Dervis Kadunic, for
anyone's use. Take it, run it on your own work, improve it. If it
breaks your paper before your critics can, it has done its job.


FILES IN THIS PACKAGE
---------------------

  README.txt                -- this file.
  GS4_GOLD_SPEC.md          -- the complete protocol, GS-4 Gold v1.0,
                               as executed in the first run (including
                               the hostility charter, printed verbatim).
  TRIAL_REPORT_first_run.md -- the first run's full trial report,
                               included as the worked example.
  CREDITS.txt               -- who contributed what.
