#!/usr/bin/env python3
"""build_index.py -- R3 addressing index for a markdown paper (Crucible
Standard Edition, Tier T, v1.3).

WHAT THIS IS
------------
A text-tier agent addresses material in a long paper in this order of
preference:

    unique anchor strings  >  section headings  >  line numbers

This tool builds the index that makes the first of those possible.  It
scans a paper for its section headings and, for every heading, selects
an *anchor string*: a 40-80 character string taken from the section's
own text that occurs EXACTLY ONCE in the whole paper.  A text-tier
agent can then find the section by searching for the anchor string,
without trusting anyone's line numbers.

The output is a TSV with columns:

    section_id | start_line | end_line | anchor_string |
    anchor_occurrence_count

An entry whose anchor_occurrence_count is not 1 is INVALID.  Invalid
entries are never silently passed: the tool writes the literal string
DEFECT in the count column, leaves the anchor empty, and lists the
section, with its reason, in the defects report.

LINE CONVENTION (critical)
--------------------------
The paper is read as UTF-8 text with newline translation disabled and
split on '\\n' ONLY -- never str.splitlines(), which also splits on
\\f, \\v, \\x85 and other boundaries and would silently shift every
address after such a character.  Line numbers are 1-based and agree
with `grep -n`.  If the text ends with '\\n', the empty element after
that final newline is not a line and is dropped, so the line count
agrees with `wc -l`.

HEADING DETECTION (critical)
----------------------------
The paper embeds verification scripts as fenced listings full of
'#'-comment lines (in Paper 12 v4, 2,148 lines start with '# '), so a
naive grep for '#' lines is useless.  Headings are lines starting with
'## ' (level 2, sections) or '### ' (level 3, subsections) that lie
OUTSIDE fenced code blocks.  Fence state is tracked while scanning: a
fence is a run of >= 3 backticks or >= 3 tildes; it opens a block and a
later fence of the same character, at least as long as the opening run
and carrying no info string, closes it (so a plain ``` fence toggles,
exactly as expected, and a ```` fence that embeds whole markdown
sources containing their own ``` fences stays open across them).  The
scan counts and reports how many heading-like lines ('## ' / '### ')
were skipped inside fences.

SECTION_ID RULE
---------------
Strip the leading hashes and whitespace from the heading; replace
'&nbsp;' with a space; collapse runs of whitespace to single spaces.
Then:

  1. If the cleaned heading begins with a section-number token --
     digits with optional dot-separated parts ('0', '0.1', '12.3'),
     optionally prefixed with '§' and optionally followed by a full
     stop ('§4.', '7.'), or an appendix-style letter token ('C.1') --
     the section_id is '§' + that token (e.g. '§0.1', '§4', '§C.1').
  2. Else if the cleaned heading contains 'Appendix X' (X a capital
     letter), the section_id is that text (e.g. 'Appendix F').
  3. Else the section_id is the cleaned heading text itself,
     truncated to 60 characters.

Section_ids are addresses, not keys: two headings may legitimately
share one (e.g. a section '§7' and its later '§7 claims' subsection
both map to '§7'); rows are distinguished by start_line.

START / END LINES
-----------------
start_line is the heading's own line number.  end_line is the line
before the next heading of level <= this heading's level, or the
paper's last line, whichever comes first.  (A level-2 section ends
where the next level-2 heading begins; a level-3 subsection ends where
the next level-3 or level-2 heading begins.)

ANCHOR SELECTION
----------------
For each section, its own lines are considered in order -- the heading
line first, then body lines up to end_line -- skipping empty lines,
skipping lines inside fences, and skipping lines containing a tab.
At most the first 40 such eligible lines are searched.  From each
eligible line (stripped of surrounding whitespace):

  * if 40 <= len(line) <= 80: the whole stripped line is a candidate;
  * if len(line) > 80: windows of length 80, 72, 64, 56, 48, 40, in
    that order, each starting at a word boundary (position 0, or a
    position immediately after a space) in ascending order;
  * if len(line) < 40: the line yields no candidate.

For each candidate, in generation order, its occurrence count in the
ENTIRE paper text is computed with an OVERLAPPING-aware count (a
find-loop stepping by 1, so 'aa' occurs 3 times in 'aaaa'; str.count's
non-overlapping count would say 2 and could crown an anchor that a
receiver's overlapping search finds more than once).  The first
candidate whose overlapping count is exactly 1 is the section's
anchor and is recorded with count 1.  If no candidate in the first 40
eligible lines qualifies, the anchor is empty, the count is the
literal DEFECT, and the section is listed in the defects report with
its reason: 'no eligible line' (no line survived the skip rules) or
'no unique candidate'.

Candidate lines are additionally skipped when they contain any of
'\\f', '\\v', '\\x85', '\\u2028' or '\\u2029': those characters are
line boundaries to str.splitlines() and to some receivers' tooling,
so an anchor spanning one could be found at a different address --
or not at all -- by a receiver that splits differently.

FENCE STATE AT EOF
------------------
The scan reports the fence state at end of file.  If a fence is still
open at EOF, the index header and the defects report declare it:
the defects report names the line where the unclosed fence opened
as a DECLARED DEFECT (headings after that line may have been missed,
because the scanner believed it was inside a listing).

TSV FORMAT
----------
Leading comment lines beginning with '#' state the escapes rule, the
line convention, the count semantics and the validity rule.  Then a
header row with the five column names, then one tab-separated row per
heading in document order.  Cells never contain raw tabs or newlines
by construction (candidate lines containing a tab are skipped, and a
candidate is always a slice of a single line); backslashes are literal
characters -- no escaping is applied anywhere.

USAGE
-----
    build_index.py PAPER.md [-o INDEX.tsv] [--defects DEFECTS.md]
    build_index.py --verify PAPER.md INDEX.tsv
    build_index.py --selftest

--verify re-reads the paper and the index, recomputes every
non-DEFECT row's anchor occurrence count from the paper (overlapping
count), and checks every row against a fresh heading scan: the
header-declared paper sha256 and line count must match the paper
argument; the multiset of row start_lines must equal the fresh
scan's heading start_lines exactly; the rows must be in document
order; and each row's section_id, end_line and anchor must equal
the fresh scan's values for that section (anchor choice is
deterministic, so a swapped or substituted anchor is a mismatch
even when the substituted string is itself unique).  It prints
every mismatch and exits 0 iff all rows check out, so a doctored
index is caught mechanically.

--selftest builds a synthetic mini-paper in a temporary directory
(a fake heading inside a fence, two sections sharing an identical
prose line, and one section with no unique anchor) and checks the
tool's behaviour against it assertion by assertion.

Python 3, standard library only.
"""

import argparse
import hashlib
import re
import sys
import tempfile
from pathlib import Path

COLUMNS = ["section_id", "start_line", "end_line", "anchor_string",
           "anchor_occurrence_count"]
MIN_ANCHOR = 40
MAX_ANCHOR = 80
WINDOW_LENGTHS = (80, 72, 64, 56, 48, 40)
MAX_ELIGIBLE_LINES = 40

SECTION_TOKEN_RE = re.compile(
    r"^§?\s*(\d+(?:\.\d+)*|[A-Z](?:\.\d+)+)\.?(?=\s|$)")
APPENDIX_RE = re.compile(r"Appendix\s+([A-Z])\b")
FENCE_RE = re.compile(r"^(`{3,}|~{3,})(.*)$")
# Characters that are line boundaries to str.splitlines() and to some
# receivers' tooling.  A candidate anchor line containing any of them
# is excluded (see the module docstring).
FORBIDDEN_LINE_CHARS = "\f\v\x85\u2028\u2029"
HEADER_IDENTITY_RE = re.compile(
    r"^# Source paper: .* -- sha256 ([0-9a-fA-F]+) -- (\d+) lines\.$")


def count_overlapping(text, needle):
    """Overlapping occurrence count of `needle` in `text`.

    A find-loop stepping by 1: count_overlapping('aaaa', 'aa') == 3,
    where str.count (non-overlapping) would return 2.  Anchor
    acceptance uses this count in generation AND in --verify.
    """
    if not needle:
        return 0
    count = 0
    start = 0
    while True:
        idx = text.find(needle, start)
        if idx < 0:
            return count
        count += 1
        start = idx + 1


# --------------------------------------------------------------------------
# Reading and scanning
# --------------------------------------------------------------------------

def read_paper(path):
    """Read a paper as UTF-8 text, split on '\\n' only.

    Returns (text, lines).  `text` is the file's full text, untranslated;
    `lines[i]` is line i+1.  The empty element after a trailing '\\n' is
    dropped: it is not a line.
    """
    with open(path, "r", encoding="utf-8", newline="") as fh:
        text = fh.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return text, lines


def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def scan_lines(lines):
    """One pass over `lines`: fence state, headings, skipped-line counts.

    Returns a dict with:
      headings: list of (level, line_no, raw_line) outside fences,
      in_fence: list of bool, one per line (True for lines inside a
                fenced block and for the fence delimiter lines
                themselves),
      skipped_heading_like: count of '## '/'### ' lines inside fences,
      hash_comment_inside: count of '# ' lines inside fences (reported
                for transparency; these are mostly script comments),
      fence_at_eof: None if every fence is closed by EOF, else a dict
                {char, length, open_line} describing the fence still
                open at EOF and the 1-based line where it opened.
    """
    headings = []
    in_fence = [False] * len(lines)
    skipped_heading_like = 0
    hash_comment_inside = 0
    fence_char = None
    fence_len = 0
    fence_open_line = None

    for idx, line in enumerate(lines):
        stripped = line.lstrip()
        match = FENCE_RE.match(stripped)
        if fence_char is None:
            if match:
                fence_char = match.group(1)[0]
                fence_len = len(match.group(1))
                fence_open_line = idx + 1
                in_fence[idx] = True
                continue
        else:
            in_fence[idx] = True
            if (match and match.group(1)[0] == fence_char
                    and len(match.group(1)) >= fence_len
                    and match.group(2).strip() == ""):
                fence_char = None
                fence_len = 0
                fence_open_line = None
            elif line.startswith("## ") or line.startswith("### "):
                skipped_heading_like += 1
            elif line.startswith("# "):
                hash_comment_inside += 1
            continue
        if line.startswith("### "):
            headings.append((3, idx + 1, line))
        elif line.startswith("## "):
            headings.append((2, idx + 1, line))

    fence_at_eof = None
    if fence_char is not None:
        fence_at_eof = {"char": fence_char, "length": fence_len,
                        "open_line": fence_open_line}
    return {
        "headings": headings,
        "in_fence": in_fence,
        "skipped_heading_like": skipped_heading_like,
        "hash_comment_inside": hash_comment_inside,
        "fence_at_eof": fence_at_eof,
    }


def fence_state_line(scan):
    """One-line declaration of the fence state at EOF (TSV header /
    defects report wording, shared by both)."""
    fence = scan.get("fence_at_eof") if scan else None
    if fence is None:
        return "closed"
    return (f"open -- unclosed fence opened at line "
            f"{fence['open_line']}")


def section_id_of(raw_heading_line):
    """Derive a section_id from a heading line (rule in the docstring)."""
    text = re.sub(r"^#{2,3}\s+", "", raw_heading_line)
    text = text.replace("&nbsp;", " ")
    text = " ".join(text.split())
    token = SECTION_TOKEN_RE.match(text)
    if token:
        return "§" + token.group(1)
    appendix = APPENDIX_RE.search(text)
    if appendix:
        return "Appendix " + appendix.group(1)
    return text[:60]


def build_sections(lines, scan):
    """Turn a scan into section records with start/end lines."""
    raw = scan["headings"]
    last_line = len(lines)
    sections = []
    for pos, (level, line_no, raw_line) in enumerate(raw):
        end_line = last_line
        for next_level, next_line, _ in raw[pos + 1:]:
            if next_level <= level:
                end_line = next_line - 1
                break
        sections.append({
            "level": level,
            "start_line": line_no,
            "end_line": end_line,
            "raw_heading": raw_line,
            "section_id": section_id_of(raw_line),
        })
    return sections


# --------------------------------------------------------------------------
# Anchor selection
# --------------------------------------------------------------------------

def candidates_for_line(stripped):
    """Yield candidate anchor strings from one stripped line, in order."""
    length = len(stripped)
    if length < MIN_ANCHOR:
        return
    if length <= MAX_ANCHOR:
        yield stripped
        return
    starts = [i for i in range(length)
              if stripped[i] != " "
              and (i == 0 or stripped[i - 1] == " ")]
    for window in WINDOW_LENGTHS:
        for start in starts:
            if start + window <= length:
                yield stripped[start:start + window]


def find_anchor(text, lines, in_fence, section, count_cache):
    """Find a section's anchor.  Returns a row dict (see build_index)."""
    eligible = 0
    tried = 0
    anchor = ""
    count_field = "DEFECT"
    for line_no in range(section["start_line"], section["end_line"] + 1):
        if eligible >= MAX_ELIGIBLE_LINES:
            break
        line = lines[line_no - 1]
        if in_fence[line_no - 1]:
            continue
        if line.strip() == "":
            continue
        if "\t" in line:
            continue
        if any(ch in line for ch in FORBIDDEN_LINE_CHARS):
            continue
        eligible += 1
        for candidate in candidates_for_line(line.strip()):
            tried += 1
            count = count_cache.get(candidate)
            if count is None:
                count = count_overlapping(text, candidate)
                count_cache[candidate] = count
            if count == 1:
                anchor = candidate
                count_field = "1"
                break
        if count_field == "1":
            break
    if count_field == "DEFECT":
        reason = ("no eligible line" if eligible == 0
                  else "no unique candidate")
    else:
        reason = ""
    return {
        "section_id": section["section_id"],
        "level": section["level"],
        "start_line": section["start_line"],
        "end_line": section["end_line"],
        "anchor_string": anchor,
        "anchor_occurrence_count": count_field,
        "defect_reason": reason,
        "eligible_lines": eligible,
        "candidates_tried": tried,
    }


def build_index(text, lines):
    """Scan a paper (text + lines) and build all index rows.

    Returns (rows, scan, sections).
    """
    scan = scan_lines(lines)
    sections = build_sections(lines, scan)
    count_cache = {}
    rows = [find_anchor(text, lines, scan["in_fence"], section, count_cache)
            for section in sections]
    return rows, scan, sections


# --------------------------------------------------------------------------
# Output: TSV and defects report
# --------------------------------------------------------------------------

def tsv_text(rows, paper_name, paper_sha256, line_count, scan=None):
    out = [
        "# R3 addressing index -- built by build_index.py "
        "(Crucible Standard Edition, Tier T, v1.3).",
        f"# Source paper: {paper_name} -- sha256 {paper_sha256} -- "
        f"{line_count} lines.",
        "# Escapes rule: cells never contain raw tabs or newlines by "
        "construction; backslashes are literal characters, no escaping "
        "is applied.",
        "# Line convention: the paper was read as UTF-8 text and split "
        "on '\\n' only (never str.splitlines()); line numbers are "
        "1-based and agree with grep -n.",
        "# Count semantics: anchor_occurrence_count is an "
        "OVERLAPPING-aware count (find-loop stepping by 1) of the "
        "anchor string in the entire paper text.",
        "# Validity rule: anchor_occurrence_count must be 1. A row "
        "whose count field is the literal DEFECT is an invalid entry, "
        "declared as an index defect in the defects report.",
        f"# Fence state at EOF: {fence_state_line(scan)}",
        "\t".join(COLUMNS),
    ]
    for row in rows:
        out.append("\t".join([
            row["section_id"],
            str(row["start_line"]),
            str(row["end_line"]),
            row["anchor_string"],
            row["anchor_occurrence_count"],
        ]))
    return "\n".join(out) + "\n"


def defects_text(rows, scan, paper_name, paper_sha256, line_count):
    by_level = {2: 0, 3: 0}
    for row in rows:
        by_level[row["level"]] = by_level.get(row["level"], 0) + 1
    defects = [row for row in rows
               if row["anchor_occurrence_count"] == "DEFECT"]
    verified = len(rows) - len(defects)
    out = [
        f"# Index Defects Report -- {paper_name}",
        "",
        "## Paper identity",
        "",
        f"- File name: {paper_name}",
        f"- sha256: {paper_sha256}",
        f"- Line count (\\n convention, 1-based, agrees with grep -n): "
        f"{line_count}",
        "",
        "## Scan",
        "",
        f"- Headings found outside fences: {len(rows)} "
        f"(level 2 ('## '): {by_level.get(2, 0)}; "
        f"level 3 ('### '): {by_level.get(3, 0)})",
        f"- Heading-like lines skipped inside fences "
        f"('## ' / '### ' lines): {scan['skipped_heading_like']}",
        f"- Supplementary: '# ' lines inside fences (script comments "
        f"and embedded-source lines, not headings): "
        f"{scan['hash_comment_inside']}",
        f"- Rows emitted: {len(rows)}",
        f"- Anchors verified unique (occurrence count exactly 1): "
        f"{verified}",
        f"- Defect rows: {len(defects)}",
        f"- Fence state at EOF: {fence_state_line(scan)}",
        "",
        "## Defect sections",
        "",
    ]
    if not rows:
        out.append("no sections found -- the scan found no level-2 or "
                   "level-3 headings outside fences in this paper; "
                   "the index is header-only and must not be relied "
                   "on as an addressing index.")
        out.append("")
    fence = scan.get("fence_at_eof")
    if fence is not None:
        out.append(f"DECLARED DEFECT: unclosed fence at EOF -- the "
                   f"fence opened at line {fence['open_line']} "
                   f"({fence['char'] * fence['length']}) was never "
                   f"closed; headings after that line may have been "
                   f"missed by the scan.")
        out.append("")
    if defects:
        out.append("| section_id | start_line | reason | detail |")
        out.append("|---|---|---|---|")
        for row in defects:
            detail = (f"{row['eligible_lines']} eligible line(s) "
                      f"examined, {row['candidates_tried']} candidate(s) "
                      f"tried, none occurring exactly once")
            if row["defect_reason"] == "no eligible line":
                detail = "no line survived the skip rules"
            out.append(f"| {row['section_id']} | {row['start_line']} | "
                       f"{row['defect_reason']} | {detail} |")
    else:
        out.append("None. Every section's anchor occurs exactly once "
                   "in the paper.")
    out += [
        "",
        "## Honesty note",
        "",
        "An index with defects is still shippable if the defects are "
        "declared, as they are here. An index with UNDECLARED defects "
        "is not.",
        "",
    ]
    return "\n".join(out)


def write_text(path, content):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(content)


# --------------------------------------------------------------------------
# --verify
# --------------------------------------------------------------------------

def verify_index(paper_path, index_path):
    """Re-check an index against its paper.  Returns a list of mismatches."""
    text, lines = read_paper(paper_path)
    fresh_rows, _scan, _sections = build_index(text, lines)
    fresh_by_start = {row["start_line"]: row for row in fresh_rows}
    fresh_starts = [row["start_line"] for row in fresh_rows]

    with open(index_path, "r", encoding="utf-8", newline="") as fh:
        index_text = fh.read()
    mismatches = []

    # (d) Header identity: the header-declared paper sha256 and line
    # count must match the paper argument.
    identity = None
    for ln in index_text.split("\n"):
        match = HEADER_IDENTITY_RE.match(ln)
        if match:
            identity = match
            break
    if identity is None:
        mismatches.append(
            "header identity missing: no '# Source paper: ... -- "
            "sha256 ... -- N lines.' line to validate against the paper")
    else:
        declared_sha = identity.group(1).lower()
        declared_lines = int(identity.group(2))
        actual_sha = sha256_of(paper_path)
        if declared_sha != actual_sha:
            mismatches.append(
                f"header identity mismatch: index declares paper "
                f"sha256 {declared_sha}, the paper argument hashes to "
                f"{actual_sha}")
        if declared_lines != len(lines):
            mismatches.append(
                f"header identity mismatch: index declares "
                f"{declared_lines} paper lines, the paper argument has "
                f"{len(lines)} lines")

    index_lines = [ln for ln in index_text.split("\n")
                   if ln != "" and not ln.startswith("#")]
    if not index_lines:
        mismatches.append("index contains no header row and no data rows")
        return mismatches
    header = index_lines[0].split("\t")
    if header != COLUMNS:
        mismatches.append(
            f"header row mismatch: expected {COLUMNS!r}, found {header!r}")
    data_lines = index_lines[1:]

    if len(data_lines) != len(fresh_rows):
        mismatches.append(
            f"row count mismatch: index has {len(data_lines)} data rows, "
            f"a fresh heading scan finds {len(fresh_rows)} headings")

    # Parse every row's start_line once, for the coverage/order checks.
    parsed_starts = []
    for line in data_lines:
        cells = line.split("\t")
        try:
            parsed_starts.append(int(cells[1]))
        except (ValueError, IndexError):
            parsed_starts.append(None)

    # (b) Coverage: the multiset of index start_lines must equal the
    # fresh scan's heading start_lines exactly (a row replaced by a
    # duplicate of another row keeps the row count but breaks this).
    from collections import Counter
    index_counter = Counter(s for s in parsed_starts if s is not None)
    fresh_counter = Counter(fresh_starts)
    if index_counter != fresh_counter:
        missing = sorted((fresh_counter - index_counter).elements())
        extra = sorted((index_counter - fresh_counter).elements())
        mismatches.append(
            f"coverage mismatch: index start_lines do not match the "
            f"fresh scan's heading start_lines as a multiset "
            f"(missing: {missing}; duplicated/extra: {extra})")

    # (c) Order: rows must be in document order (two complete rows
    # exchanged keep coverage but break this).
    if parsed_starts != fresh_starts:
        mismatches.append(
            f"row order mismatch: index rows are not in document "
            f"order / do not match the fresh scan's heading order "
            f"(index start_lines: {parsed_starts}; fresh scan: "
            f"{fresh_starts})")

    for pos, line in enumerate(data_lines, start=1):
        cells = line.split("\t")
        if len(cells) != len(COLUMNS):
            mismatches.append(
                f"row {pos}: expected {len(COLUMNS)} tab-separated "
                f"cells, found {len(cells)}: {line!r}")
            continue
        section_id, start_s, end_s, anchor, count_s = cells
        try:
            start_line = int(start_s)
            end_line = int(end_s)
        except ValueError:
            mismatches.append(
                f"row {pos} ({section_id}): non-integer start/end line: "
                f"{start_s!r}/{end_s!r}")
            continue
        fresh = fresh_by_start.get(start_line)
        if fresh is None:
            mismatches.append(
                f"row {pos} ({section_id}): start_line {start_line} is "
                f"not a heading line in a fresh scan of the paper")
            continue
        if section_id != fresh["section_id"]:
            mismatches.append(
                f"row {pos}: section_id {section_id!r} at start_line "
                f"{start_line} does not match fresh scan "
                f"{fresh['section_id']!r}")
        if end_line != fresh["end_line"]:
            mismatches.append(
                f"row {pos} ({section_id}, line {start_line}): end_line "
                f"{end_line} does not match fresh scan {fresh['end_line']}")
        fresh_is_defect = fresh["anchor_occurrence_count"] == "DEFECT"
        if count_s == "DEFECT":
            if anchor != "":
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"DEFECT row carries a non-empty anchor_string")
            if not fresh_is_defect:
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"index declares DEFECT but a fresh scan finds a "
                    f"unique anchor for this section")
        else:
            if fresh_is_defect:
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"index claims a valid anchor but a fresh scan "
                    f"finds none (fresh result: DEFECT)")
            # (a) The anchor must be the fresh scan's anchor for THIS
            # section (anchor choice is deterministic and identical
            # to generation), so anchors swapped between sections --
            # or any substituted anchor -- are caught even when the
            # substituted string is itself unique in the paper.
            elif anchor != fresh["anchor_string"]:
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"anchor does not match the fresh scan's anchor "
                    f"for this section: index has {anchor!r}, fresh "
                    f"scan selects {fresh['anchor_string']!r}")
            if count_s != "1":
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"anchor_occurrence_count is {count_s!r}, expected '1'")
            actual = count_overlapping(text, anchor) if anchor else 0
            if actual != 1:
                mismatches.append(
                    f"row {pos} ({section_id}, line {start_line}): "
                    f"anchor occurs {actual} time(s) in the paper "
                    f"(overlapping count), expected exactly 1: "
                    f"{anchor!r}")
    return mismatches


# --------------------------------------------------------------------------
# --selftest
# --------------------------------------------------------------------------

def run_selftest():
    results = []

    def check(label, condition):
        results.append((label, bool(condition)))
        print(f"{'PASS' if condition else 'FAIL'}: {label}")

    shared = ("Shared prose line that appears in two different "
              "sections here.")
    alpha_unique = ("Alpha keeps a singular sentence that no other "
                    "section repeats.")
    beta_unique = ("Beta answers with its own unrepeated sentence "
                   "for the index.")
    shared_two = ("Second shared line that Gamma repeats from the "
                  "Beta section.")
    check("fixture lines are 40-80 characters",
          all(MIN_ANCHOR <= len(s) <= MAX_ANCHOR
              for s in (shared, alpha_unique, beta_unique, shared_two)))

    mini_lines = [
        "# Mini Paper",                       # 1
        "",                                   # 2
        "## 1 Alpha",                         # 3
        "",                                   # 4
        shared,                               # 5
        "",                                   # 6
        alpha_unique,                         # 7
        "",                                   # 8
        "```",                                # 9
        "## 99 Fake heading inside a fence",  # 10
        "# a script comment, not a heading",  # 11
        "```",                                # 12
        "",                                   # 13
        "## 2 Beta",                          # 14
        "",                                   # 15
        shared,                               # 16
        "",                                   # 17
        shared_two,                           # 18
        "",                                   # 19
        beta_unique,                          # 20
        "",                                   # 21
        "## 3 Gamma",                         # 22
        "",                                   # 23
        shared,                               # 24
        "",                                   # 25
        shared_two,                           # 26
    ]
    with tempfile.TemporaryDirectory() as tmp:
        paper = Path(tmp) / "mini.md"
        write_text(paper, "\n".join(mini_lines) + "\n")
        text, lines = read_paper(paper)
        check("line convention: mini-paper has 26 lines by '\\n' split",
              len(lines) == 26)
        rows, scan, _sections = build_index(text, lines)
        by_id = {row["section_id"]: row for row in rows}

        check("fenced fake heading is skipped (3 headings found, "
              "ids §1/§2/§3)",
              [row["section_id"] for row in rows] == ["§1", "§2", "§3"])
        check("heading-like lines skipped inside fences == 1",
              scan["skipped_heading_like"] == 1)
        check("shared line occurs more than once in the paper",
              text.count(shared) >= 2)
        check("Alpha's anchor is its unique line, not the shared line",
              by_id["§1"]["anchor_string"] == alpha_unique)
        check("Beta's anchor is its unique line, not the shared line",
              by_id["§2"]["anchor_string"] == beta_unique)
        check("Alpha end_line is the line before Beta's heading (13)",
              by_id["§1"]["end_line"] == 13)
        check("Gamma (every line duplicated) is reported DEFECT",
              by_id["§3"]["anchor_occurrence_count"] == "DEFECT"
              and by_id["§3"]["anchor_string"] == "")
        check("Gamma's defect reason is 'no unique candidate'",
              by_id["§3"]["defect_reason"] == "no unique candidate")
        check("Gamma end_line is the paper's last line (26)",
              by_id["§3"]["end_line"] == 26)

        index_path = Path(tmp) / "mini_INDEX.tsv"
        defects_path = Path(tmp) / "mini_DEFECTS.md"
        digest = sha256_of(paper)
        clean_tsv = tsv_text(rows, paper.name, digest, len(lines), scan)
        write_text(index_path, clean_tsv)
        write_text(defects_path,
                   defects_text(rows, scan, paper.name, digest, len(lines)))
        mismatches = verify_index(paper, index_path)
        check("--verify accepts the selftest index (no mismatches)",
              mismatches == [])
        defects_md = defects_path.read_text(encoding="utf-8")
        check("defects report names the DEFECT section (§3)",
              "§3" in defects_md and "no unique candidate" in defects_md)

        # A doctored index must be caught: move Alpha's end_line by one.
        doctored = clean_tsv.replace("§1\t3\t13\t", "§1\t3\t14\t")
        write_text(index_path, doctored)
        mismatches = verify_index(paper, index_path)
        check("--verify catches a doctored end_line", len(mismatches) >= 1)

        # --- T1: overlapping-aware counting ---------------------------
        check("overlapping count: 'aa' in 'aaaa' is 3 (str.count "
              "would say 2)",
              count_overlapping("aaaa", "aa") == 3
              and "aaaa".count("aa") == 2)
        check("TSV header declares the fence state at EOF (closed)",
              "# Fence state at EOF: closed" in clean_tsv
              and "Fence state at EOF: closed" in defects_md)

        def verify_text(tsv):
            write_text(index_path, tsv)
            return verify_index(paper, index_path)

        tsv_lines = clean_tsv.split("\n")
        header_idx = next(i for i, ln in enumerate(tsv_lines)
                          if ln.startswith("section_id\t"))
        data = tsv_lines[header_idx + 1:header_idx + 4]
        row_a, row_b, row_c = (ln.split("\t") for ln in data)

        # --- Probe (a): anchor replaced by a thrice-occurring string
        # labelled count 1 must be caught.  `shared` occurs exactly 3
        # times in the mini-paper.
        check("probe fixture: shared line occurs exactly 3 times "
              "(overlapping count)", count_overlapping(text, shared) == 3)
        probe = list(row_a)
        probe[3] = shared
        probe[4] = "1"
        probe_tsv = "\n".join(tsv_lines[:header_idx + 1]
                              + ["\t".join(probe), data[1], data[2]]) + "\n"
        check("--verify catches probe (a): thrice-occurring anchor "
              "labelled count 1", len(verify_text(probe_tsv)) >= 1)

        # --- T3(a): anchors swapped between two sections --------------
        swap_a, swap_b = list(row_a), list(row_b)
        swap_a[3], swap_b[3] = row_b[3], row_a[3]
        swap_tsv = "\n".join(tsv_lines[:header_idx + 1]
                             + ["\t".join(swap_a), "\t".join(swap_b),
                                data[2]]) + "\n"
        check("--verify catches T3(a): anchors swapped between two "
              "sections", len(verify_text(swap_tsv)) >= 1)

        # --- T3(b): a row replaced by a duplicate of another row ------
        dup_tsv = "\n".join(tsv_lines[:header_idx + 1]
                            + [data[0], data[0], data[2]]) + "\n"
        check("--verify catches T3(b): row replaced by a duplicate "
              "of another row", len(verify_text(dup_tsv)) >= 1)

        # --- T3(c): two complete rows exchanged -----------------------
        exch_tsv = "\n".join(tsv_lines[:header_idx + 1]
                             + [data[1], data[0], data[2]]) + "\n"
        check("--verify catches T3(c): two complete rows exchanged",
              len(verify_text(exch_tsv)) >= 1)

        # --- T3(d): header-declared paper sha256 zeroed ---------------
        zeroed = clean_tsv.replace(digest, "0" * 64)
        check("--verify catches T3(d): header sha256 zeroed",
              len(verify_text(zeroed)) >= 1)
        write_text(index_path, clean_tsv)

        # --- T2: unclosed fence at EOF is a declared defect -----------
        broken_lines = ["# Broken", "", "## 1 Only", "",
                        "A unique sentence for the only section here.",
                        "```", "code that never closes the fence"]
        broken = Path(tmp) / "broken.md"
        write_text(broken, "\n".join(broken_lines) + "\n")
        b_text, b_lines = read_paper(broken)
        b_rows, b_scan, _s = build_index(b_text, b_lines)
        check("unclosed fence at EOF is recorded by the scan "
              "(opening line named)",
              b_scan["fence_at_eof"] is not None
              and b_scan["fence_at_eof"]["open_line"] == 6)
        b_defects = defects_text(b_rows, b_scan, broken.name,
                                 sha256_of(broken), len(b_lines))
        check("defects report declares the unclosed fence, naming "
              "its opening line",
              "DECLARED DEFECT: unclosed fence at EOF" in b_defects
              and "line 6" in b_defects
              and "Fence state at EOF: open" in b_defects)
        b_tsv = tsv_text(b_rows, broken.name, sha256_of(broken),
                         len(b_lines), b_scan)
        check("TSV header declares 'Fence state at EOF: open'",
              "# Fence state at EOF: open" in b_tsv)

        # --- T4: forbidden-character lines are not anchor candidates --
        ls_line = ("A long unique sentence with a line separator "
                   "inside" + chr(0x2028) + "it for the test here.")
        t4_lines = ["# T4", "", "## 1 Sep", "", ls_line]
        t4_paper = Path(tmp) / "t4.md"
        write_text(t4_paper, "\n".join(t4_lines) + "\n")
        t4_text, t4_ls = read_paper(t4_paper)
        t4_rows, _ts, _s2 = build_index(t4_text, t4_ls)
        check("line containing U+2028 is excluded from anchor "
              "candidates (section is DEFECT with no anchor)",
              len(t4_rows) == 1
              and t4_rows[0]["anchor_occurrence_count"] == "DEFECT"
              and t4_rows[0]["anchor_string"] == ""
              and 40 <= len(ls_line) <= 80)

        # --- T4: zero-heading paper declares 'no sections found' ------
        nh = Path(tmp) / "nohead.md"
        write_text(nh, "# Just a title\n\nNo headings here at all.\n")
        nh_text, nh_lines = read_paper(nh)
        nh_rows, nh_scan, _s4 = build_index(nh_text, nh_lines)
        nh_defects = defects_text(nh_rows, nh_scan, nh.name,
                                  sha256_of(nh), len(nh_lines))
        check("zero-heading paper: scan finds no sections and the "
              "defects report declares 'no sections found'",
              nh_rows == [] and "no sections found" in nh_defects)

    failed = [label for label, ok in results if not ok]
    print(f"SELFTEST: {len(results) - len(failed)}/{len(results)} "
          f"assertions passed")
    return 1 if failed else 0


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="build_index.py",
        description="Build the R3 addressing index (unique anchor "
                    "strings per section) for a markdown paper, verify "
                    "an existing index against its paper, or run the "
                    "built-in selftest. See the module docstring for "
                    "the line convention, heading and section_id rules, "
                    "and anchor semantics.",
        epilog="examples:\n"
               "  build_index.py PAPER.md -o INDEX.tsv "
               "--defects DEFECTS.md\n"
               "  build_index.py --verify PAPER.md INDEX.tsv\n"
               "  build_index.py --selftest\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("paper", nargs="?",
                        help="the paper (markdown) to index")
    parser.add_argument("index", nargs="?",
                        help="the index TSV (only with --verify)")
    parser.add_argument("-o", "--output", metavar="INDEX.tsv",
                        help="where to write the index TSV "
                             "(default: <paper stem>_INDEX.tsv in the "
                             "current directory)")
    parser.add_argument("--defects", metavar="DEFECTS.md",
                        help="where to write the defects report "
                             "(default: no report file; defects are "
                             "still counted and named in the summary)")
    parser.add_argument("--verify", action="store_true",
                        help="verify mode: check INDEX.tsv against "
                             "PAPER.md and exit 0 iff every row "
                             "checks out")
    parser.add_argument("--selftest", action="store_true",
                        help="run the built-in selftest on a synthetic "
                             "mini-paper and exit")
    args = parser.parse_args(argv)

    if args.selftest:
        if args.paper or args.index or args.verify:
            parser.error("--selftest takes no paper/index arguments")
        return run_selftest()

    if not args.paper:
        parser.error("a paper path is required (or use --selftest)")
    paper_path = Path(args.paper)
    if not paper_path.is_file():
        print(f"error: paper not found: {paper_path}", file=sys.stderr)
        return 2

    if args.verify:
        if not args.index:
            parser.error("--verify requires both PAPER.md and INDEX.tsv")
        index_path = Path(args.index)
        if not index_path.is_file():
            print(f"error: index not found: {index_path}",
                  file=sys.stderr)
            return 2
        mismatches = verify_index(paper_path, index_path)
        for mismatch in mismatches:
            print(f"MISMATCH: {mismatch}")
        if mismatches:
            print(f"VERIFY FAILED: {len(mismatches)} mismatch(es)")
            return 1
        _text, lines = read_paper(paper_path)
        with open(index_path, "r", encoding="utf-8", newline="") as fh:
            row_count = sum(1 for ln in fh.read().split("\n")
                            if ln and not ln.startswith("#")) - 1
        print(f"VERIFY OK: {row_count} rows checked against "
              f"{paper_path.name} ({len(lines)} lines); every "
              f"non-DEFECT anchor occurs exactly once and every "
              f"start/end line matches a fresh heading scan.")
        return 0

    if args.index:
        parser.error("an index path is only meaningful with --verify")

    text, lines = read_paper(paper_path)
    rows, scan, _sections = build_index(text, lines)
    digest = sha256_of(paper_path)
    output_path = (Path(args.output) if args.output
                   else Path(paper_path.stem + "_INDEX.tsv"))
    write_text(output_path,
               tsv_text(rows, paper_path.name, digest, len(lines), scan))
    if args.defects:
        write_text(Path(args.defects),
                   defects_text(rows, scan, paper_path.name, digest,
                                len(lines)))
    if not rows:
        print("WARNING: no sections found -- the scan found no "
              "level-2 or level-3 headings outside fences in "
              f"{paper_path.name}; the index at {output_path} is "
              "header-only and must not be relied on as an "
              "addressing index (declared in the defects report).",
              file=sys.stderr)
    if scan.get("fence_at_eof") is not None:
        print(f"WARNING: unclosed fence at EOF -- the fence opened "
              f"at line {scan['fence_at_eof']['open_line']} was "
              f"never closed (declared in the defects report).",
              file=sys.stderr)
    defects = [row for row in rows
               if row["anchor_occurrence_count"] == "DEFECT"]
    by_level = {2: 0, 3: 0}
    for row in rows:
        by_level[row["level"]] = by_level.get(row["level"], 0) + 1
    print(f"Paper: {paper_path.name} -- sha256 {digest} -- "
          f"{len(lines)} lines")
    print(f"Headings outside fences: {len(rows)} "
          f"(level 2: {by_level.get(2, 0)}, level 3: "
          f"{by_level.get(3, 0)}); heading-like lines skipped inside "
          f"fences: {scan['skipped_heading_like']}")
    print(f"Rows written to {output_path}: {len(rows)}; anchors "
          f"verified unique: {len(rows) - len(defects)}; "
          f"DEFECT rows: {len(defects)}")
    for row in defects:
        print(f"DEFECT: {row['section_id']} at line "
              f"{row['start_line']} -- {row['defect_reason']}")
    if args.defects:
        print(f"Defects report written to {args.defects}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
