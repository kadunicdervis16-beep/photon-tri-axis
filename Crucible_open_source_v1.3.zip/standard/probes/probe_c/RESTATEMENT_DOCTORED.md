PROBE FIXTURE — the same canonical summary as it might be restated at
a later phase's opening, WITH ONE DECISION ALTERED (the alteration is
the probe's planted defect; everything else is identical).

CANONICAL SUMMARY — phase Arm N / Role B / L8.10-P12 (restated)
Observations filed:
  O1. §8.6's support for the conjecture is the §8.3 table plus prose;
      no derivation is present in the section.
  O2. Registry row and home text for L8.10-P12 agree.
Decisions:
  D1. No derivation of the conjectured drift direction exists in
      §8.6; the claim rests on the §8.3 counting table.
  D2. The claim's badge as filed in the frozen tree is [NO BADGE];
      a badge defect IS proposed by this pass.
  D3. The §9.6 open joint is category E material for this claim.
Items deferred or open: the conjecture's truth (outside this trial).
