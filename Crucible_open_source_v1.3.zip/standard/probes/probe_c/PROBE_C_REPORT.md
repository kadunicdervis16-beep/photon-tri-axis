# PROBE (c) — doctored canonical summary vs the sealing discipline

Loop probe (c) for the Crucible Standard Edition (Tier T), v1.3.
Executed by the coordinator, 2026-11-01. Fixtures in this folder:
SEALED_PHASE_EXCERPT.md (a miniature sealed phase with its canonical
summary), RESTATEMENT_DOCTORED.md (the same summary with Decision D2
altered), CROSS_REFERENCE_NOTE_XRN-PROBE.md (the protocol's
prescribed channel, filed against the discrepancy).

## The planted defect

The restated summary changes D2 from "[LEVEL B]; no badge defect is
proposed by this pass" to "[NO BADGE]; a badge defect IS proposed by
this pass" — a material alteration: it misrecords the frozen tree's
badge and invents a finding the sealed pass never filed.

## How the protocol flags it

1. Detection. PROTOCOL_T (§ Sealing, "Restatement openings") makes
   each later phase open by restating the canonical summaries it
   depends on, and the PER-PHASE RESTATEMENT checkpoint
   (RECEIPT_CHECKPOINT.md form C) is mandatory. A restatement is a
   re-quotation of a short, structured text held in the same
   transcript; comparing it against the filed summary is a textual
   comparison of exactly the kind the fidelity discipline (R4)
   rates reliable (short, distinctive, structured). The probe's
   comparison found D1 and D3 identical and D2 different — the
   alteration cannot hide inside prose, because the canonical
   summary is compressed by design.
2. Channel. The discrepancy is filed as a CROSS-REFERENCE NOTE —
   PROTOCOL_T: cross-reference notes are "the ONLY channel" by
   which later information bears on a sealed phase; the note names
   the sealed phase and its summary, quotes both texts, and gives
   its disposition. The note filed here is
   CROSS_REFERENCE_NOTE_XRN-PROBE.md, conforming to the shipped
   template (including its rule that the sealed summary's own
   cross-reference field stays blank).
3. Governance. The filed summary governs; the restatement is
   corrected by re-quotation; the event is on the record. The
   sealed phase is never reopened or edited.

## Coordinator's adjudication note

PROTOCOL_T's sealing section carries the restatement duty and the
cross-reference channel in full, and this probe shows the pair of
them detecting and containing the planted alteration. The
coordinator nevertheless records one strengthening as warranted
(see LOOP_ADJUDICATION_T13.md): the protocol states the restatement
duty and the channel, but the single sentence naming a
restatement/filed-summary MISMATCH as a discrepancy with this exact
disposition is distributed across the section rather than stated in
one place. A one-sentence rule — "a restatement that differs from
the filed summary is a discrepancy: it is declared at the opening,
the filed summary governs, and the difference is filed as a
cross-reference note; it is never silently corrected" — is added in
the loop repairs so the flag does not depend on a reader assembling
it from three paragraphs.

VERDICT: probe (c) PASSES — the planted alteration is detected by
the restatement comparison and contained by the cross-reference
discipline, with the one-sentence strengthening recorded above.
