# CROSS-REFERENCE NOTE -- XRN-PROBE-01

- Note ID: XRN-PROBE-01
- Trial: Crucible Standard Edition (Tier T) v1.3 — loop probe (c)
  (fixture; not a real trial)
- Filed in: coordinator's probe, at the restatement opening of the
  phase following the sealed fixture phase
- Date / session: 2026-11-01; probe session

## Target sealed phase

- Sealed phase: PROBE FIXTURE — Arm N, Role B, target L8.10-P12
  (SEALED_PHASE_EXCERPT.md)
- Its canonical summary ID: the CANONICAL SUMMARY filed inside
  SEALED_PHASE_EXCERPT.md ("phase Arm N / Role B / L8.10-P12")
- Item(s) in that phase this note bears on: Decision D2

## The new information

At the next phase's restatement opening, the restated canonical
summary (RESTATEMENT_DOCTORED.md) was compared against the filed
canonical summary, decision by decision. Decisions D1 and D3 match
the filed text. Decision D2 does NOT match:

  FILED:    "D2. The claim's badge as filed in the frozen tree is
             [LEVEL B]; no badge defect is proposed by this pass."
  RESTATED: "D2. The claim's badge as filed in the frozen tree is
             [NO BADGE]; a badge defect IS proposed by this pass."

The restatement alters the recorded badge and invents a defect
proposal the sealed phase never made. The discrepancy is detectable
by direct comparison of two short structured texts — the comparison
the Standard Edition's fidelity discipline (R4) rates reliable —
with no hash, count, or computation of any kind.

Material citation(s): the two fixture filings named above, compared
in full in this note; no paper passage is relied on.

Source status of the new information: observed in this session, at
the restatement checkpoint (RECEIPT_CHECKPOINT form C).

## Why it bears on the sealed phase

It contradicts the sealed phase's Decision D2 as restated. Left
standing, every later phase would work from a decision the sealed
phase never took — the precise contamination R6's file-then-freeze
discipline exists to prevent.

## Disposition

The FILED canonical summary governs. The restatement is corrected
by re-quotation of the filed summary; the discrepancy is recorded
here as a process event. The sealed phase is NOT reopened, NOT
modified, and its canonical summary is NOT edited to point back at
this note (its cross-reference field stays blank, by rule). Had the
altered decision carried a badge consequence, the matter would
belong to adjudication (badges not yet frozen) or to the Author's
List (after freezing) — never to a quiet edit of the restatement.
