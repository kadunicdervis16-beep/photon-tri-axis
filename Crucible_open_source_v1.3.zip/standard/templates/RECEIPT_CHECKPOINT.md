# RECEIPT CHECKPOINTS -- THE THREE MANDATORY FORMS
<!-- Crucible Standard Edition (Tier T), Protocol T v1.3, checkpoints
     (R8). Three checkpoints are mandatory: (A) receipt, (B) per-attack
     precondition, (C) per-phase restatement. Each is filed in this
     canonical form, using ONLY the R1 checks (echo of first/last
     lines; anchor presence with occurrence counts; heading lists in
     declared order; range contiguity; truncation at visible
     boundaries). No form in this file asks for, or may contain, a
     figure presented as computed or verified by the agent: sender-side
     figures are recorded as the sender's, labelled as such, or not
     recorded here at all.
     A FAILED checkpoint stops the affected work and is reported,
     never silently absorbed: the failure, the affected material, and
     the resolution (re-send / re-paste / declared gap) are carried in
     the run's process-events record and in the report.
     FORM A PRESUPPOSES the chunk manifest's per-chunk fields: the
     shipped CHUNK_MANIFEST.txt (paper12_chunks/CHUNK_MANIFEST.txt)
     now carries, per chunk, TOKEN, SCAN RESULT, REGENERATIONS,
     HEADINGS IN ORDER, and ANCHORS, under its filled "HOW TO READ
     THIS TRANSMISSION" head and its AGENT-SIDE CHECKS section. A
     manifest without those fields does not support a form A filing.
     Checkpoint budget (Protocol T, checkpoints): ONE form A per
     transmission batch (re-paste batches included); form B
     consolidated per role pass; form C per phase opening.
     Addressing throughout: the full address of a passage is the pair
     (section_id, start_line) plus its anchor; section_id alone only
     where the index shows it unique; a DEFECT row is addressed by
     heading + start_line only and has no anchor. -->

Trial: <trial label -- e.g. "Crucible Standard Edition (Tier T)
v1.3 on <paper title>">
Checkpoint filed by: <agent / session, as filed in the transcript>
Date / session: <date; session identifier if the run spans sessions>

======================================================================
FORM A -- RECEIPT CHECKPOINT
Filed at receipt of the packet, and again at receipt of each later
transmission (charters, blind packet, listings, re-pastes, handoff
kit). ONE form A per transmission batch, with one block per part /
chunk in the batch, in transmission order. Registration is
incremental: filed form A receipts stand across sessions, and a
registration index reply references them by checkpoint ID
(Protocol T, checkpoints -- including the partial-registration
rule: a receiving session files its OWN form A for parts it
re-receives; it never completes a predecessor's half-filed form A).
======================================================================

Checkpoint ID: <e.g. RCPT-01; later receipts RCPT-02, ...>
Transmission covered: <what arrived -- parts / chunks, by their
heads, in order>

### Per part / chunk

<!-- Repeat this block for every part and every chunk. -->

- Part / chunk: <part n of N; chunk n of N where chunked>
- Title echoed: "<the part / chunk's title, echoed as received>"
- First line echoed: "<first line, verbatim as received>"
- Last line echoed: "<last line, verbatim as received>"
- First content line echoed: "<first NON-BLANK body line, verbatim
  as received> (line <NNNN, as declared in the chunk head>)"
- Last content line echoed: "<last NON-BLANK body line, verbatim
  as received> (line <NNNN, as declared in the chunk head>)"
  <!-- R1 check 1 as strengthened: blank first/last lines are
       degenerate evidence -- 110 of Paper 12's 111 chunks end on a
       blank line and chunk 66 begins on one -- so the content-line
       echoes are mandatory, not optional. -->
- Delimiters: <open line present with its token / close line present
  with the SAME token / defect observed: <state it>>
- Heading list confirmed in order: <YES -- the headings found, in
  the order found, restated here: <list> / NO -- declared list:
  <...>; found list: <...>; the difference: <...>>
- Anchors declared for this part: <each anchor restated, with the
  count found in the material as held and the count declared:
  <anchor> -- found <n>, declared <n>, at declared position
  <head / middle / tail> / anchor ABSENT / count DIFFERS: <as found>>
- Declared range: <start_line-end_line, as declared in the chunk
  head -- the sender's figures, recorded as the sender's>
- Contiguity with previous chunk: <YES -- this chunk's declared
  range follows the previous chunk's with no gap and no range
  overlap / NO -- the gap or overlap, stated / NOT APPLICABLE --
  first chunk of its document>
- Overlap match: <YES -- the 3 lines repeated at this chunk's head
  under "OVERLAP FROM PREVIOUS CHUNK" match the last 3 lines of
  the previous chunk as held / NO -- the difference, stated /
  NOT APPLICABLE -- first chunk of its document>
- Truncation at a visible boundary: <NONE OBSERVED / OBSERVED --
  the observation: <ends mid-line / declared last line is not the
  line present / delimiter unclosed / promised sections not
  reached / declared range longer than the material present>>
- Verdict for this item: **HELD / NOT HELD**
  <If NOT HELD: what is missing or wrong, and what re-send is
  requested. Work depending on a NOT HELD item does not proceed.>

### Receipt summary

- Items HELD: <n of m, listed by part / chunk>
- Items NOT HELD: <listed, with the re-send requested for each --
  or "none">
- Index rows registered in this receipt (where the transmission
  carried the index or paper chunks): <rows confirmed, by
  (section_id, start_line); duplicate section_id values noted;
  DEFECT rows registered as DEFECT, by heading + start_line --
  or "not applicable to this transmission">
- Discrepancies with sender-side figures: <any difference between
  the sender's declared figures (manifest / part heads) and what
  the R1 checks found, stated as a difference between the sender's
  record and the material as held -- never resolved by adopting a
  sender figure as the agent's own>

Receipt verdict: **COMPLETE / INCOMPLETE** <INCOMPLETE stops the
dependent work until the re-send's receipt checkpoint is filed>

======================================================================
FORM B -- PER-ATTACK PRECONDITION CHECKPOINT
Filed before an attack's work begins, CONSOLIDATED PER ROLE PASS
for the attacks actually run in that pass (one filing per role
pass, a section per attack), and repeated where an attack resumes
after a handoff or a long context gap.
======================================================================

Checkpoint ID: <e.g. PRE-GS4-A-N-01 (attack, arm, order)>
Attack: <attack ID and name -- e.g. GS4-C Dependency break>
Arm / role performing it: <Arm N | Arm H; Role <A | B | C | D>>

### Materials this attack depends on

<!-- Every passage, listing, packet, or record the attack's method
     needs, cited by full address. Each is restated present HERE,
     at this checkpoint -- located in the material as held, not
     recalled from an earlier phase. -->

| material | full address (section_id, start_line) + anchor -- or heading + start_line for a DEFECT row | present as held? | first line echoed | last line echoed |
|---|---|---|---|---|
| <...> | <...> | <YES / NO> | "<...>" | "<...>" |
| <...> | <...> | <YES / NO> | "<...>" | "<...>" |

For each material: the agent confirms PRESENCE of its anchor at
the located passage in the material as held. The anchor's global
occurrence count is the sender's declared figure (the index's
anchor_occurrence_count, computed sender-side over the whole
frozen paper), restated here AS THE SENDER'S FIGURE: <anchor --
present at the located passage, YES / NO; sender's declared
global count: <n, as declared in the index>; DEFECT rows:
"DEFECT -- no anchor; located by heading". No whole-corpus count
is demanded of, or filed by, the agent.>

Load-bearing quotations this attack will use that require fresh
re-paste at this phase (fidelity budget, R4 -- including EVERY
load-bearing quotation from a DEFECT section, at any context
size): <each listed, with its re-paste status: RE-PASTED at this
checkpoint / AWAITING RE-PASTE -- the attack is NOT READY until it
arrives>

Other preconditions: <blind packet sealed-status for GS4-B / sealed
classifications for a reveal pass / mutation log status for a
witness duty -- the preconditions the spec sets for this attack,
each stated MET / NOT MET>

Verdict: **READY / NOT READY**
<If NOT READY: the missing or unmet items, listed; the attack does
not begin on substitute material. The gap is declared here and
carried as a coverage boundary in the attack's filing, or the
material is re-pasted and this checkpoint is re-filed.>

======================================================================
FORM C -- PER-PHASE RESTATEMENT CHECKPOINT
Filed at every phase opening, before the phase's work begins. This
is the sealing discipline's opening act (Protocol T, R6): no
restatement, no phase.
======================================================================

Checkpoint ID: <e.g. RST-PHASE2-H-C (phase, arm, role)>
Phase opening: <phase number and name; arm / role where applicable>

### Canonical summaries restated

<!-- The prior canonical summaries this phase depends on, restated
     BY ID and in substance: the decisions and observations this
     phase will rely on, compressed as the summaries themselves
     state them. Restating a summary is not re-reading its sealed
     prose; reliance runs on the summary. Where this phase needs
     the sealed prose itself (a quotation, a witness), that need
     is a re-paste item, listed below -- not a quiet re-reading
     presented as reliance on the summary. -->

| canonical summary ID | phase / arm / role it sealed | what this phase relies on from it |
|---|---|---|
| <...> | <...> | <observations / decisions, by their numbers in that summary> |
| <...> | <...> | <...> |

Summaries this phase does NOT depend on: <listed by ID, or "none --
all prior summaries are relied on as tabled above">

### Completeness of materials

- Materials this phase depends on: <each, by full address --
  (section_id, start_line) + anchor, or heading + start_line for a
  DEFECT row -- with its standing as held: HELD at <receipt
  checkpoint ID> / RE-PASTED at this opening / NOT HELD>
- Re-pastes performed at this opening: <passages re-pasted, located
  by anchor (or by heading, for a DEFECT section), first and last
  lines echoed in this filing -- the list, or "none required and
  none performed", with the context-size ground for that judgement
  stated (active material estimate vs the R4 range)>

### Gaps declared

<Every gap this phase opens with: material NOT HELD, summaries
unavailable, quotations awaiting re-paste, attacks NOT READY
carried over, open items inherited from a handoff. Each gap states
its effect on this phase's work (proceeds without it as a declared
coverage boundary / the affected attack or step does not proceed).
"None" is a valid entry; an empty section is not.>

Phase opening verdict: **OPEN / NOT OPEN**
<NOT OPEN only where a gap stops the phase itself, not merely an
attack within it; the stopping gap is named.>
