# CHARTER-INTEGRITY AUDIT -- Tier T form (Crucible Standard Edition,
Protocol T v1.3), adapted from the kit's CHARTER_INTEGRITY.md
(spec section 11)

**Trial:** <trial label -- e.g. "GS-4 Gold v1.0, Standard Edition
(Tier T) -- single-agent sequential sealed passes,
independent-context trial"> -- <paper title>, frozen tree.
**Meta-auditor:** at Tier T, a later sealed pass by the examining
agent, disclosed as such -- or a separate agent/session receiving
the transcript. (The kit form's "separate agent, distinct from the
adjudicator, the examiners, and the mutation runner" is the file
tier's form; at Tier T the auditor is whoever Protocol T's
charter-integrity section names, and the reduced strength is
stated, not smoothed over.)
**Sequencing:** this audit was run AFTER anonymized-card
adjudication completed and badges were frozen, and after
unblinding. **No badge has been changed and no finding has been
re-adjudicated.** This report characterizes the arms only.
**Materials:** the sealed, still-attributed original filings of
both arms; the adjudication filing; the opened key (used only to
attribute cards in measures that need it).

## Seal verification (Tier T form)

At Tier T there is no hash recomputation by the agent (R1). The
record audited is the record AS FILED: each filing relied on below
is cited by its position in the transcript and its canonical
summary ID, and its receipt/sealing status is restated from the
run's checkpoint filings. **Result: <the filings cited are the
filed filings, per the record / discrepancies listed -- a
discrepancy between sealed prose and its canonical summary,
discovered here or later, is a cross-reference-note matter
(Protocol T, Limits 12), never a quiet edit>.**

## Denominators

- Arm H findings: <n> (<per role>), in 1:1 correspondence with the
  <n> Arm H cards in the key.
- Arm N findings: <n> (<per role>), in 1:1 correspondence with the
  <n> Arm N cards in the key.
- <Material that enters no denominator (reveal addenda, witness
  files) and why.>

All counts below are HAND COUNTS over the filed transcript,
labelled as hand counts, with counted sites cited by filing and
finding number so a reader can recount (Protocol T,
charter-integrity audit).

---

## Measure 1 -- BROKE proposals per arm, and per role within Arm H

| Arm | BROKE proposals | Findings | Rate |
|---|---|---|---|
| H | <n> | <n> | <%> |
| N | <n> | <n> | <%> |

Per role within Arm H: <table with card keys via the key>
Context from the frozen adjudication (recorded, not altered): <of
Arm H's proposals, how many sustained / downgraded, with keys>

## Measure 2 -- BROKE-first compliance in Arm H

<The fraction of Arm H findings whose text constructs the defect
argument before any defence is considered: clear cases <n>/<total>;
with visible defect-first behaviour <n>/<total>. Arm N comparison:
<n>. Method stated.>

## Measure 3 -- Hostile-reading invocations

<Arm H findings that expressly adopt the least-favourable reading:
count, with card keys. Arm N: count.>

## Measure 4 -- Concessions

<Arm H arguments talked down by evidence within the finding itself:
count. A concession is the overlay working as designed -- argued
BROKE first, conceded where forced -- not a failure of hostility.>

## Measure 5 -- Strict-rule compliance

<Of Arm H's defect-proposing objections: how many meet all three
parts of the strict rule (exact claim / requirement of the claim /
failure under declared premises); how many the adjudicator
re-categorized to D. Arm N comparison where meaningful.>

## Measure 6 -- Concealment / retreat probes

<Arm H findings that expressly test a disclosure for concealment or
a scope statement for retreat: count, with keys, and their
adjudicated fates.>

## Verdict

**HOSTILITY DEMONSTRATED** / **HOSTILITY PARTIAL** /
**HOSTILITY NOT DEMONSTRATED** -- mark exactly one, in its full
form. (The verdict labels at Tier T are the full HOSTILITY-prefixed
forms; the bare words DEMONSTRATED / PARTIAL / NOT DEMONSTRATED are
not verdicts.)

<The counts that decide it, stated plainly. If any measure is
absent or could not be computed, say so here -- a measure that does
not exist weakens the arm's evidentiary value and is recorded, not
smoothed over. If the verdict is not HOSTILITY DEMONSTRATED, state
plainly that the hostile arm's evidentiary value is reduced
accordingly.>
