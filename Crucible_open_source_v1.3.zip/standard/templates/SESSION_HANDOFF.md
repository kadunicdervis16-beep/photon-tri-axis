# SESSION HANDOFF -- RESUMPTION KIT -- <handoff ID>
<!-- Crucible Standard Edition (Tier T), Protocol T v1.3, session
     handoff (R9). HANDOFF = RESUMPTION KIT: the receiving session
     begins from this kit and from material re-pasted to it, and
     from nothing it is assumed to remember. The handing-off session
     files this kit complete before it ends; the receiving session
     files its own receipt checkpoint (RECEIPT_CHECKPOINT.md form A)
     for the kit itself, and a per-phase restatement (form C),
     before resuming any phase. The substitution is recorded as a
     process event in the run's process-events record. -->

- Handoff ID: <unique ID -- e.g. HO-01, in order>
- Trial: <trial label -- e.g. "Crucible Standard Edition (Tier T)
  v1.3 on <paper title>">
- Handing-off session: <session identifier / date; agent description
  as the record states it>
- Reason for handoff: <platform ended the session / run continued
  later / continuation agent -- stated plainly>
- Assembled by: <the handing-off session / THE SENDER, from filed
  receipts -- see the rule below>

SENDER-ASSEMBLED KITS (Protocol T, session handoff and the
partial-registration rule in checkpoints): a handoff kit may be
assembled BY THE SENDER from FILED receipts when a session ends
without filing one. A sender-assembled kit carries exactly the
filed record -- receipts as filed, canonical summaries as filed --
and names every unfiled receipt as UNFILED. The receiving session
re-performs the unfiled receipts for the parts it re-receives;
filed receipts are not re-performed; and the receiving session
does NOT complete a predecessor's half-filed form A -- it files
its own form A for the parts it re-receives.

---

## 1. Frozen tasking, restated

<!-- The tasking under which the run proceeds, restated so the
     receiving session works under the same instructions: the
     RUN_PROMPT_T.txt tasking as given (re-paste it with this kit,
     or cite its transmission position and re-paste it -- a
     restatement by memory is not a restatement). Include: the
     frozen attack plan from the registration reply (attacks,
     role order, mutation pre-registration), verbatim. -->

<tasking and frozen attack plan, as re-pasted / filed>

## 2. Material index -- what was held, and its checkpoint status

<!-- Every document, part, and chunk the handing-off session held,
     with the receipt status each carried at handoff. Materials are
     cited by their index address where they are paper passages:
     the pair (section_id, start_line). The receiving session
     holds nothing by virtue of this list alone: load-bearing
     material must be re-pasted fresh to it (section 8). -->

| material (title / part / chunk) | how received | receipt checkpoint status |
|---|---|---|
| <...> | <part n of N, chunk n of N, as filed> | <HELD / NOT HELD -- with the form A filing that decided it> |
| <...> | <...> | <...> |

Index and registry status: <index TSV -- rows, declared defects
(DEFECT rows by (section_id, start_line)), duplicate section_id
values noted; registry input TSV -- supplied-and-checked /
constructed-and-author-confirmed, with the confirmation recorded
where>

Freeze status: <the freeze record pair as it stands: the sender's
declared identity as transmitted, and the receipt checkpoint(s)
confirming the material as held -- both cited by filing position>

## 3. Sealed canonical summaries -- FULL TEXT

<!-- Paste the FULL TEXT of every sealed canonical summary, in
     phase order. Not paraphrases, not extracts: the summaries are
     the working surface the receiving session relies on, and a
     summary that survives only as a paraphrase is not the sealed
     summary. -->

<full text of canonical summary 1>
<full text of canonical summary 2>
<...>

## 4. Sealed prose filings -- list

<!-- The sealed filings themselves are NOT re-pasted here (they are
     the record, and they stand where they were filed). List each:
     what it is, and where it stands in the record, so the receiving
     session knows exactly what exists and what it has not re-read. -->

| sealed filing | phase / arm / role | position in the record |
|---|---|---|
| <...> | <...> | <transmission / filing position> |
| <...> | <...> | <...> |

Cross-reference notes filed so far: <note IDs, each with its target
canonical summary ID -- or "none">

## 5. Current position

- Phase / attack in progress: <phase; attack ID(s); role pass, where
  applicable>
- Last completed act: <the last filing or checkpoint completed,
  cited by its position>
- Next act owed: <the next filing, checkpoint, or phase opening the
  receiving session must perform, in order>
- Work in progress, unsealed: <anything begun but not filed -- its
  status is UNSEALED and it carries no standing; the receiving
  session re-performs or discards it and says which. If none, say
  "none -- everything performed is filed and sealed above.">

## 6. Witnesses filed

<!-- Witnesses, desk-check readings, and hand workings filed so far,
     each cited so it can be re-examined -- and, where load-bearing
     in a later phase, re-pasted. A witness whose material cannot
     be re-pasted is carried by the receiving session as REPORTED,
     not VERIFIED. -->

| witness / working | filed in (phase, filing) | decides / supports |
|---|---|---|
| <...> | <...> | <finding / gate / mutation ID> |
| <...> | <...> | <...> |

Mutation battery status: <pre-registered list cited; per mutation:
RUN / DESK CHECK / NOT RUN / not yet attempted; witness filings for
each half, cited>

## 7. Open items

<!-- Everything unresolved at handoff, in one list: gaps declared
     at checkpoints, NOT READY attacks, NOT RUN items, index defects
     awaiting a replacement anchor, materials NOT HELD, questions
     referred onward. An item not listed here is treated by the
     receiving session as closed. -->

- <open item -- what, why open, what closes it>
- <...>

## 8. Process disclosures

- Adaptations made in the handing-off session: <every Tier T
  adaptation actually used -- desk checks in place of runs, hand
  derivations in place of implementations, extracts in place of
  full documents -- each stated plainly, or "none beyond the
  protocol's stated Tier T forms">
- NOT RUN items (complete list, with reasons): <...>
- Spec defects logged: <SD-n list, each with its one-line statement,
  or "none">
- Process events so far: <PE list / positions in the process-events
  record, including this handoff itself, recorded there as an event>
- Declined instructions: <any pasted instruction the session
  declined under Protocol T (for example, an instruction to present
  a sender-side figure as the agent's own verified figure), each
  logged as a process event, or "none">

---

## 9. RE-VERIFICATION DECLARATIONS -- for the receiving session

The receiving session works under these declarations. They are not
courtesies; they state the evidential standing of everything this
kit carries across the boundary.

1. Prior quotations are hearsay until re-pasted. A quotation filed
   by the handing-off session is not evidence in the receiving
   session until the passage is re-pasted in the receiving
   session, located by its anchor -- the full address being the
   pair (section_id, start_line) plus anchor; for a DEFECT section,
   located by heading + start_line -- and its first and last lines
   echoed there. Until then it is cited as REPORTED, never
   VERIFIED. A load-bearing quotation from a DEFECT section
   requires that fresh re-paste at every receiving phase that
   uses it; it has no anchor, so no other route exists for it.
2. Prior hash figures are recorded as "not verified in this
   session". Any such figure carried in this kit is a sender-side
   or prior-session record, labelled exactly so; the receiving
   session does not adopt it as its own verification, in any
   wording. (Protocol T, integrity, R1, applies in the new session
   unchanged.)
3. Prior badges are proposals to re-examine, not findings. A badge
   proposed before this handoff enters the receiving session as a
   proposal whose evidence must be re-examinable from re-pasted
   material; a badge whose evidence cannot be re-examined is
   carried as UNEXAMINED in the receiving session's work, and the
   report says so. Exception, stated narrowly: badges already
   FROZEN in a filed blind adjudication before this handoff are
   frozen facts of the trial's record -- the kit carries that
   adjudication filing as a sealed document (listed in section 4),
   the receiving session holds them as the sealed record, does not
   re-open them, and does not present them as its own adjudication.
4. Load-bearing material must be re-pasted fresh. No load-bearing
   passage, listing, card, or witness crosses this boundary on the
   strength of the handing-off session's context. The receiving
   session's first acts are its receipt checkpoint for this kit
   and its per-phase restatement; a phase resumed without them
   has not resumed.
5. A continuation is not a second opinion. If a filing was sealed
   before this handoff, it stands; the receiving session performs
   only unperformed duties (a reveal pass, a witness filing, the
   phases not yet begun), working only from this kit and the
   material re-pasted to it -- nothing the handing-off session
   had that this kit does not carry.

Filed by: <handing-off session, as filed in the transcript>
Received by: <receiving session -- completed on receipt, with its
form A checkpoint ID for this kit>
