<!-- FINDING CARD -- Tier T form (Crucible Standard Edition, Protocol T
     v1.3), adapted from the kit's FINDING_CARD.md (spec section 10.2).
     Produced at anonymization, which at Tier T is a SENDER act: the
     sender builds, strips, and verifies the adjudication packet; the
     agent's inspection at receipt is a receipt check only.
     FIDELITY RULE AT TIER T -- SUBSTANTIVE IDENTITY, not character
     identity: the finding's argument text is carried from the sealed
     submission with the same decisions, the same numbers, the same
     badges, and the same negations. A card whose argument differs
     from the sealed original IN SUBSTANCE -- in any decision, number,
     badge, or negation, or in the wording of a deciding sentence --
     is void and must be regenerated. A difference in none of those is
     within the declared tolerance and is noted on the card, not
     voided. (This replaces the kit form's character-identity rule,
     which a text-tier transmission cannot honestly certify.)
     The re-keying map (card key -> arm/role/examiner) is sealed
     separately by the sender and opened only after badges freeze.
     QUOTING UNIT (Protocol T, fidelity budget): the "Exact target
     text" below is the claim's deciding sentence(s), at most about
     50 tokens, quoted exactly; the full claim is incorporated by its
     address -- the pair (section_id, start_line) plus anchor. -->

### CARD <FRESH-KEY -- TRIAL-F-001, TRIAL-F-002, ... at Tier T (a
disclosed deviation from spec section 10.2's GS4-F-001... prefix;
the TRIAL-F- prefix is kept and the deviation is disclosed in
Protocol T's "What differs" table); the key order must not encode
arm, role, or filing order>

- Target claim: <ID> -- full address: (section_id: <...>,
  start_line: <...>) plus anchor: "<anchor string>" (section_id
  alone only where the index shows it unique; for a DEFECT row:
  heading + start_line, no anchor)
- Exact target text: "<the claim's deciding sentence(s), quoted
  verbatim -- the quoting unit, <= about 50 tokens>"
- Domain and required property: <copied from the finding>
- Sources used: <copied from the finding>
- Method and complete test space: <copied from the finding>
- Witness / artifacts: <copied from the finding; artifacts referenced
  under neutral names>
- Coverage map: <copied from the finding -- (1) native domain,
  (2) verified domain, (3) map between them, (4) what the map
  preserves, (5) what stays outside the check>
- Category (self-classified, spec section 9.5): <A | B | C | D | E>
- Proposed badge: <HELD | BROKE | LIMIT | OUTSIDE>
- Reason: <copied from the finding>
- Tolerance note: <"carried under substantive identity; no
  substantive difference from the sealed original" -- or the
  non-substantive differences noted, one by one>

<!-- Anonymization checklist for the SENDER's packaging step (delete
     before use is NOT permitted -- fill it in):
     [ ] arm label removed   [ ] role label removed
     [ ] examiner identity removed   [ ] self-references to the arm
         removed from headers/metadata only (argument text untouched)
     [ ] argument text compared against the sealed original under
         the SUBSTANTIVE-IDENTITY rule: same decisions, numbers,
         badges, negations; deciding sentences unaltered
-->
