# CANONICAL SUMMARY -- <summary ID>
<!-- Crucible Standard Edition (Tier T), Protocol T v1.3, sealing (R6).
     Filed at the close of a phase, as the phase's last act. The
     canonical summary is the working surface for all later phases:
     later phases restate, cite, and rely on the summaries, not on
     the sealed prose. The sealed prose filing is never edited after
     this summary is filed. Cross-reference notes filed later against
     this phase are separate filings that NAME this summary; they do
     not modify it. Leave the cross-reference field blank at filing,
     exactly as instructed in that field. -->

- Trial: <trial label -- e.g. "Crucible Standard Edition (Tier T)
  v1.3 on <paper title>">
- Summary ID: <unique ID for this summary -- e.g. CS-N-A-01; used by
  restatement checkpoints, cross-reference notes, and handoffs>
- Phase: <phase number and name -- e.g. Phase 2, examination / Phase 3,
  mutation battery / Phase 4, blind adjudication>
- Arm / role: <Arm N | Arm H | no arm (mutation battery, adjudication,
  charter-integrity, report) -- and, where a role applies, Role
  <A | B | C | D> and its name>
- Attacks covered in this phase: <attack IDs -- GS4-A .. GS4-J, or
  "none (battery / adjudication / administrative phase)">
- Filing this summary closes: <the sealed prose filing -- its title
  in the transcript, and its position (transmission / filing number)>
- Date / session: <date; session identifier if the run spans sessions>

---

## Observations filed

<!-- Numbered. One observation per numbered item, in filing order.
     An observation is what this phase filed as its record: a
     reconstruction step, a derivation result, a finding (with its
     ID), a count with its producing working, a desk-check result, a
     process status. Keep each item compressed but complete enough
     that a later phase can rely on THIS item without re-reading the
     sealed prose. Where an item is a finding, carry: finding ID,
     target claim, category (A-E), proposed badge. -->

1. <observation -- compressed statement, with finding ID / claim /
   category / proposed badge where the item is a finding>
2. <observation>
3. <...>

Count: <n observations in the sealed filing; this list must account
for all of them -- if an observation is omitted from this summary
as not load-bearing, say so here and name it>

## Decisions, with compressed reasons

<!-- Every decision this phase made that a later phase will rely
     on: a reading adopted, a domain boundary fixed, a category
     assigned, a badge proposed or (in adjudication) assigned, a
     control judged to have fired or missed, a gate limb assessed.
     One line per decision: the decision, then the compressed
     reason -- the deciding evidence in a phrase, not the full
     argument (the argument lives in the sealed filing). -->

- <decision> -- <compressed reason: the evidence that decided it>
- <decision> -- <compressed reason>
- <...>

## Items deferred or open

<!-- Everything this phase did not close: attacks or steps marked
     NOT READY / NOT RUN (with the reason), gaps declared at this
     phase's checkpoints, questions referred onward, matters whose
     material was NOT HELD. An item not listed here is treated by
     later phases as closed by this phase. "None" is a valid entry;
     an empty section is not. -->

- <open item -- what it is, why it is open, and where it goes next
  (named later phase / Author's List / process-events record)>
- <...>

## Materials relied on

<!-- Every passage this phase relied on as load-bearing, cited for
     re-location and re-paste (R3, R4): the full address -- the
     pair (section_id, start_line) -- plus the anchor string.
     section_id alone suffices only where the index shows it
     unique. For a DEFECT row (no anchor exists), cite heading +
     start_line, leave the anchor cell as "DEFECT -- no anchor",
     and note that the passage was re-pasted fresh at this phase
     (a load-bearing quotation from a DEFECT section always
     requires fresh re-paste). Line numbers beyond start_line
     only where the paste rendered them. A passage not listed
     here was not load-bearing for this phase. -->

| section_id | start_line | anchor_string (verbatim, 40-80 chars) | relied on for |
|---|---|---|---|
| <...> | <...> | <...> | <observation / decision number> |
| <...> | <...> | <...> | <...> |

Other material read in this phase (not load-bearing): <section_ids /
documents, with READ status in this session>

Process status for this phase (kept separate from claim status):
READ: <...> / NOT READ: <...>
RUN: <...> / NOT RUN: <...> (with reasons)
DESK CHECK: <...> (labelled as desk checks, never as runs)
REPRODUCED: <...> / NOT REPRODUCED: <...>
SOURCE-VERIFIED (by R1 receipt checks only): <...> /
SOURCE-REPORTED: <...>

## Cross-reference notes filed against this phase

<!-- LEAVE BLANK AT FILING. Do not write in this field, ever.
     Cross-reference notes are separate files (form:
     CROSS_REFERENCE_NOTE.md) that NAME this summary by its ID
     above. A later reader assembles the list of notes against
     this phase from the notes themselves and from the
     process-events / notes index of the run -- never from an
     edit to this summary. -->

(Blank at filing, by rule.)

---

## Closing declaration -- SEALED

This phase is sealed. The prose filing named above and this summary
were filed completely before any later phase began, and neither
will be edited, re-filed, or silently supplemented. Later phases
work from this summary, restated at their openings. Later
information bearing on this phase will be filed as a
cross-reference note naming this summary's ID; no such note reopens
or modifies this phase.

Sealed by: <examining agent / phase, as filed in the transcript>
