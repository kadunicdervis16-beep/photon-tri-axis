# CROSS-REFERENCE NOTE -- <note ID>
<!-- Crucible Standard Edition (Tier T), Protocol T v1.3, sealing (R6).
     A cross-reference note is the ONLY channel by which later
     information may bear on a sealed phase. It is a separate filing.
     It names the sealed phase and its canonical summary; it never
     edits, re-files, or supplements the sealed filing, and the
     sealed phase's canonical summary is never edited to point back
     at it (its cross-reference field stays blank, by rule). If this
     note's information would change a badge: before badges freeze it
     belongs to adjudication; after they freeze it belongs to the
     Author's List and a future trial. It never belongs to a quiet
     edit. -->

- Note ID: <unique ID -- e.g. XRN-01, in filing order>
- Trial: <trial label -- e.g. "Crucible Standard Edition (Tier T)
  v1.3 on <paper title>">
- Filed in: <phase / arm / role filing this note, and its position
  in the transcript>
- Date / session: <date; session identifier if the run spans
  sessions>

## Target sealed phase

- Sealed phase: <phase number and name; arm / role where applicable>
- Its canonical summary ID: <the ID on the target's
  CANONICAL_SUMMARY.md -- cite it exactly>
- Item(s) in that phase this note bears on: <observation / decision /
  finding numbers in the target's canonical summary; finding IDs
  where the item is a finding>

## The new information

<!-- State the information itself, completely enough to be judged
     without re-reading anything else, WITH ITS OWN material
     citation: the full address of every passage relied on -- the
     pair (section_id, start_line) plus anchor string (section_id
     alone only where the index shows it unique); for a DEFECT
     section, heading + start_line and a note that the passage was
     re-pasted fresh for this note. A load-bearing quotation here
     obeys the fidelity budget (Protocol T, R4): fresh at this
     filing, short and distinctive, second-routed where it can be. -->

<the new information, stated in full>

Material citation(s):

| section_id | start_line | anchor_string (or "DEFECT -- no anchor") | what it supports in this note |
|---|---|---|---|
| <...> | <...> | <...> | <...> |

Source status of the new information: <read / derived / observed in
this session -- with the filing, pass, or checkpoint it comes from;
if it comes from a later session than the target phase, say so>

## Why it bears on the sealed phase

<the connection, stated plainly: which observation, decision, or
finding of the sealed phase this information touches, and how --
confirms / complicates / contradicts / extends -- with the reason
a reader can check from the two filings alone>

## Disposition

<!-- Exactly one. Mark it. -->

- [ ] Sealed phase stands -- the note is recorded; nothing in the
      sealed phase's standing changes, for this reason: <reason>
- [ ] Matter referred to the Author's List -- the note's substance
      is carried to the report's Author's List as: <the list item,
      in findings language, no repair proposed>
- [ ] Spec defect -- the note exposes a defect in the tasking, the
      protocol, or the specification, logged as: <SD-n> (never
      converted into a paper finding)
- [ ] Referred to adjudication (only where badges are not yet
      frozen) -- as material for card(s): <card key(s), or "new card
      to be extracted at adjudication from this note">

## Non-reopening statement

The sealed phase named above is NOT reopened or modified by this
note. Its prose filing and its canonical summary stand exactly as
filed. This note is a separate filing in the record, published with
the record, and any consequence it has flows only through the
disposition marked above.

Filed by: <phase / arm / role, as filed in the transcript>
