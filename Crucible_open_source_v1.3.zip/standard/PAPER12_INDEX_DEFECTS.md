# Index Defects Report -- Paper_12_v4.md

## Paper identity

- File name: Paper_12_v4.md
- sha256: db5b40047656f583990228779aff7206c7a3cc42065f540412691aa05d99c793
- Line count (\n convention, 1-based, agrees with grep -n): 71720

## Scan

- Headings found outside fences: 145 (level 2 ('## '): 25; level 3 ('### '): 120)
- Heading-like lines skipped inside fences ('## ' / '### ' lines): 362
- Supplementary: '# ' lines inside fences (script comments and embedded-source lines, not headings): 2147
- Rows emitted: 145
- Anchors verified unique (occurrence count exactly 1): 144
- Defect rows: 1
- Fence state at EOF: closed

## Defect sections

| section_id | start_line | reason | detail |
|---|---|---|---|
| The exhibits | 63906 | no unique candidate | 1 eligible line(s) examined, 0 candidate(s) tried, none occurring exactly once |

## Honesty note

An index with defects is still shippable if the defects are declared, as they are here. An index with UNDECLARED defects is not.
