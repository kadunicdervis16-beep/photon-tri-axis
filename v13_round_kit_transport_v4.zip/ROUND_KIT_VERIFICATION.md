# ROUND KIT VERIFICATION — Paper 12.5 v13 external round, transport v4 (build verification record, 2026-11-21)

Role of this file: it is the transport's own build verification record, shipped at the transport root (`ROUND_KIT_VERIFICATION.md`). It carries the full check-by-check table for transport v4. Its own inventory row (in `ROUND_KIT_README.md` and in the table below) is hashless: this file is anchored by the transport SHA-256 stated by the author with the delivery and reported in the round's envelope (a file cannot hash the archive that contains it).
README SHA-256: `8c33bb30f74137a0e752878013ead030fc10397e2911b571a270d29ec6ac01c2`.
Instruction SHA-256: `95bb596dc5257105ac87980245c0fc64a78cab794476feb3d511b8712be877be` (`EXTERNAL_ROUND_INSTRUCTION_v4.md`, as amended v4.1 to ride inside this transport).
Transport member count: 4.

| Check | Expected | Actual | Result |
|---|---|---|---|
| nested package sha256 == 3f8350e1… | `3f8350e1ca1cd9474129d3d4a2965493cc7f70b6a4d5f59805c3cfaaa3fb2605` | `3f8350e1ca1cd9474129d3d4a2965493cc7f70b6a4d5f59805c3cfaaa3fb2605` | PASS |
| nested package member count == 1147 | `1147` | `1147` | PASS |
| nested package cache members == 0 | `0` | `0` | PASS |
| nested package unsafe members == 0 | `0` | `0` | PASS |
| sha256 of nested MANIFEST.sha256 == printed M (§8.24) | `e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd` | `e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd` | PASS |
| MANIFEST.sha256 entries | `1146` | `1146` | PASS |
| manifest plain verify (sha256sum -c): OK count | `1143` | `1143` | PASS |
| manifest slot-normalized entries verify under the §8.24 constructions (paper / txt / aavep manifest) | `a1f5d695… / e6f85dda… / cc11b22e…` | `a1f5d69587a9080335aefe09b2fa91e6e7768f5f46aa95dc60df7ba49ef7373c / e6f85ddabd465ab6ee4211d250d9b404e258d4788f1331d4bebd9821c94c1458 / cc11b22ecc71746699be747510e43aa06588a464f5cc40feeba5d9b9881882e7` | PASS |
| CONFIG_FREEZE recompute over the in-package crucible/ tree (44 files excl. freeze pair) == printed F (§8.24) | `e1db0ae1c7b545cdae7282329741bd80cc43a3d3fb7059c1552e5a1f9375cb6e` | `e1db0ae1c7b545cdae7282329741bd80cc43a3d3fb7059c1552e5a1f9375cb6e` | PASS |
| store pins match (5 sources in sources_store/) | `5/5` | `5/5` (db5b4004… / 9225cd8d… / 6c107177… / c73a4840… / 5e99256b…) | PASS |
| README in zip == staging README bytes | `8c33bb30f74137a0e752878013ead030fc10397e2911b571a270d29ec6ac01c2` | `8c33bb30f74137a0e752878013ead030fc10397e2911b571a270d29ec6ac01c2` | PASS |
| instruction in zip == delivery instruction bytes (v4.1) | `95bb596dc5257105ac87980245c0fc64a78cab794476feb3d511b8712be877be` | `95bb596dc5257105ac87980245c0fc64a78cab794476feb3d511b8712be877be` | PASS |
| member count == 4 | `4` | `4` | PASS |
| no __pycache__/.pyc members in transport | `0` | `0` | PASS |
| package-swap probe: transport copy with nested package replaced by the v12 package (db52b881…) — the printed-hash checks must catch it | `CAUGHT` | `CAUGHT` (probe nested package hashes to db52b881…, ≠ printed 3f8350e1…; probe package's MANIFEST.sha256 hashes to 263ce5db…, ≠ printed M e83da14f…) | PASS |
| ROUND_KIT_VERIFICATION.md present at transport root | `PRESENT` | `PRESENT` | PASS |
| ROUND_KIT_VERIFICATION.md (this file) | — (hashless; anchored by the transport hash stated by the author at delivery) | — | RECORD |
| README sha256 printed in this file == extracted README sha256 (self-consistency; verified at build, staging record) | `8c33bb30f74137a0e752878013ead030fc10397e2911b571a270d29ec6ac01c2` | `8c33bb30f74137a0e752878013ead030fc10397e2911b571a270d29ec6ac01c2` | PASS |

Overall: **ALL PASS**
