# EXTERNAL ROUND INSTRUCTION v4 — Paper 12.5 v13

**Amendment v4.1 (2026-11-21, packaging only).** This
instruction now ships **inside** the transport archive (the
author's upload channel takes two files: the manuscript and
the transport). No step, expectation, needle, or rule
changes. Two consequences, both handled below: the
transport's own SHA-256 cannot be printed inside a member of
the transport, so it is stated by the author with the
delivery and your envelope reports the value you compute —
the author verifies it on receipt; and the member hashes for
this instruction and the transport's README are carried in
`ROUND_KIT_VERIFICATION.md` inside the transport (Step 1.1
checks them).

**Supersession.** This instruction (v4, 2026-11-21) supersedes
`EXTERNAL_ROUND_INSTRUCTION_v3.md` in full. Do not run v3
against this kit: v3 was written against Paper 12.5 **v12** —
its files table, its 27-instrument suite, its 32-instrument
target manifest, and its Crucible instance #3 describe a target
that no longer exists. What worked in v3 — the step order, the
verbatim-reporting discipline, and the ESP form — is carried
over deliberately, extended by two steps new in v13 (the
`verify.py` front door, Step 3; the claim spot-check and
exhibits, Step 8).

**What this round is.** An independent execution audit of
Paper 12.5 v13, *The Ensemble Illusion*, and its supplied
verification package: you run the paper's own instruments, the
AAVEP procedure, and the Crucible adapter state check, and you
return **one** ESP v2.4 envelope containing the encoded report
(§9). This is a META_AUDIT of execution only. It makes no
native physics claim, and no step in it asks you to adjudicate
the paper's substantive claims by hand.

**Governing versions.** ESP 2.4 · AAVEP 1.1 · AAVEP-CAL v2 ·
Crucible GS-4 Gold (configuration instance #4, for this paper,
shipped inside the package — see Step 7).

**AAVEP standing — PROMOTED (2026-11-13).** AAVEP stands
PROMOTED out of DEMONSTRATION by the author's ruling of
2026-11-13, on GPT-6's executed external round against v11 of
that day. v13 prints the promotion in its own text (§8.24
states the record; §0.5.1 item-6 likewise). The vendored kits
(v1.0/v1.1) still print DEMONSTRATION in their frozen texts;
that printed standing is historical. The full record is in the
transport's `ROUND_KIT_README.md`.

**What is new in v13 — one paragraph you need.** v13 is the
"A-list" build (2026-11-13/14): §3.5 states and proves the
finite exchangeability theorem (claim L3.4.4; instrument E.7,
§8.25), falsifier C53 is registered (the falsification surface
runs **C34–C53**), the package gains a one-command
verification front door (`verify.py` + `VERIFY.md`), a claim
spot-check index with `check_claim.py` (machine-checked by the
new instrument H.13, §8.26), three self-contained exhibits,
and a Crucible configuration regenerated over the v13 tree
(instance #4). The suite is now **29 instruments**; the AAVEP
target manifest is regenerated for v13 (**34 instruments, 33
claims**) and ships in-package. v13 was delivered **once** —
there is no repair twin. The v12 paper
(`e073c9fc3bee62610bf86a1d695eb6eeb533d9532845994af1bceb8fc8d344f2`)
and the v12 package
(`db52b88171697bdfcbd9056aca28d1757b99bb4ca96961316a26cd450257ec66`)
are different files and are **not** this round's target; Step
1's printed-hash checks exist to catch exactly that
substitution.

## Files you receive

| Slot | File | SHA-256 | Notes |
|---|---|---|---|
| 1 | `Paper_12_5_v13.md` | `7096e38fe99691e80378ac694f716279a7d4890ade030eae80a5fe4de4edad38` | The manuscript. Separate upload; unchanged; 2,619,887 bytes; 45,172 lines. |
| 2 | `v13_round_kit_transport_v4.zip` | stated by the author with the delivery (see Amendment v4.1) | The transport. 4 members: `ROUND_KIT_README.md`, `ROUND_KIT_VERIFICATION.md`, this instruction, and the nested package. Contents inventoried in its root `ROUND_KIT_README.md`; build verification record (with the README and instruction member hashes) in its root `ROUND_KIT_VERIFICATION.md`. Report the transport hash you compute in the envelope's integrity section. |

Inside the transport: the README pair, this instruction, and the nested package.
**The package is the ingestion** — everything the round needs
ships inside it:

| Path (in the extracted package, root `paper_12_5_verification/`) | SHA-256 | Role |
|---|---|---|
| `Paper_12_5_v13_verification_package.zip` (the nested package itself) | `3f8350e1ca1cd9474129d3d4a2965493cc7f70b6a4d5f59805c3cfaaa3fb2605` | The verification package, nested byte-untouched (1,147 members; no caches; no unsafe members). |
| `MANIFEST.sha256` (inside the package) | file hashes to `e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd` | The package inventory: 1,146 entries. Its hash is the value the paper prints at §8.24 (`package-manifest-sha256`). |
| `crucible/` (inside the package) | freeze `e1db0ae1c7b545cdae7282329741bd80cc43a3d3fb7059c1552e5a1f9375cb6e` | Frozen GS-4 configuration instance #4 **for this paper** (46 members; recursive manifest over the 44 files excluding the freeze pair). The freeze value is the paper's printed `crucible-freeze-sha256` at §8.24. |
| `aavep_manifest/aavep_target_manifest_v13.json` (inside the package) | plain `cc0e70daa7d376ee0cd34cce6f956beeb73642cdf82237b4d3eb97c42732dde4` | AAVEP v1.1 target manifest for v13 (manifest_id `aavep-target-paper-12.5-v13`; 34 instruments, 33 claims). |
| `sources_store/` (inside the package) | five pins below | The five H.6 sources, shipped in-package; the walker consumes the store only. |

The five store pins (== the pins in H.6's header):
`Paper_12_v4.md` `db5b40047656f583990228779aff7206c7a3cc42065f540412691aa05d99c793` ·
`paper_11_5_v26.md` `9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60` ·
`paper_11_v69_PDF_1_47yt.pdf` `6c1071777deacf3bdb43d165040487844f30189bc642666c886a793ae2f99974` ·
`paper1_extracted.txt` `c73a4840ef18f1e0a17cd0fac333a83ed7d9206424c30e1b9939969b4d358643` ·
`Paper_9_5_The_Borrowed_Thermometer_Paper9_Style_FINAL_2_c4ck.pdf` `5e99256b66a9e58b6cf75a4274eaa70de089b150df3dd864ac264d71ebe20b03`.

## SETUP

1. Verify the Slot 1 file against the hash above, and the
   transport by its members per Step 1, before running
   anything. A mismatch stops the round: report it in the
   envelope's integrity section; do not proceed on a
   mismatched target.
2. Extract the transport anywhere. Extract the nested package
   to a **working copy** directory of your choosing. All
   execution happens on copies. Never edit the supplied
   manuscript, the supplied package bytes, the transport
   members, or any frozen kit. (The extracted package root is
   `paper_12_5_verification/`; below, `<PKG>` means that
   directory in your working copy, and `<KIT>` means
   `<PKG>/aavep_v11`, the frozen AAVEP v1.1 kit shipped inside
   the package. The package also ships the frozen v1.0 kit at
   `<PKG>/aavep/`; the v1.1 kit governs this round.) Step 3
   (`verify.py`) runs on its **own second pristine extraction**
   of the nested package — keep the two trees distinct and say
   which tree each later step ran on.
3. **Nothing else is placed, copied, or installed.** There are
   no home-directory placements (the suite has no home
   dependence — it passes entire with HOME pointed at an empty
   directory), no substrate copy (the `cards_self` substrate
   ships inside `<PKG>/cards_self/` itself), and no external
   files of any kind. If your environment seems to require
   one, that is a finding about the package, not a setup step:
   report it.
4. Make sure `pdftotext` is available if you can (H.6's two PDF
   extraction legs use it on the stored PDFs) and note its
   availability in the report either way. If it is unavailable,
   those two legs degrade to the printed UNCHECKABLE form —
   declared behaviour, not a missing file.
5. Remove any `__pycache__` directories your own Python imports
   create inside a working copy before that copy's final suite
   run — H.12 counts shipped caches, and caches you generated
   are yours, not the package's (an earlier round hit exactly
   this; the clean re-run is the result of record).

## SELF-ADMINISTRATION authorization

You are authorized to **self-administer** AAVEP-CAL v2 (Step
2): you act as both administrator and subject, in separate
trees, following the kit's CAL spec v2. Your receipt will
grade **SELF-ADMINISTERED**. Print that grade everywhere the
receipt is used, exactly as graded. A self-administered PASS
certifies that the six-trap procedure was followed in this
session; it certifies no independence and no general auditor
competence, and your report must say so in those terms. Do not
upgrade, shorten, or omit the grade anywhere.

## STEP 1 — INTEGRITY

1. Recompute and report: the Slot 1 manuscript hash; the
   transport hash (no printed expectation inside the kit —
   the author verifies your reported value against the
   delivery record on receipt); the nested package hash
   (recomputed from the extracted transport member, not from
   a re-download); the manuscript copy inside the package
   (must equal the Slot 1 hash); and the two remaining
   transport members — `ROUND_KIT_README.md` and this
   instruction — against the member hashes printed in
   `ROUND_KIT_VERIFICATION.md`.
2. Verify the package manifest — the printed M/F verification:
   - `sha256sum <PKG>/MANIFEST.sha256` must equal
     `e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd`,
     the value the paper prints at §8.24 as
     `package-manifest-sha256`.
   - `sha256sum -c MANIFEST.sha256` inside `<PKG>` must verify
     **1,143 of 1,146 entries plainly**. Exactly three entries
     are slot-normalized: the manifest lists those three files
     at the SHA-256 of their slot-normalized form, so the plain
     check fails on them by construction. Verify each under
     the construction §8.24 states, and report the computed
     values:
     - `Paper_12_5_v13.md` — SHA-256 of the file with both
       printed slot values (the `package-manifest-sha256` and
       `crucible-freeze-sha256` values) replaced by sixty-four
       zeros. Expected computed value: `a1f5d69587a9080335aefe09b2fa91e6e7768f5f46aa95dc60df7ba49ef7373c`.
     - `Paper_12_5_v13.txt` — the same replacement (the
       rendering carries the values without backticks).
       Expected: `e6f85ddabd465ab6ee4211d250d9b404e258d4788f1331d4bebd9821c94c1458`.
     - `aavep_manifest/aavep_target_manifest_v13.json` —
       SHA-256 of its form with its two target-hash field
       values (the manuscript's plain SHA-256; the
       package-manifest SHA-256) replaced by sixty-four
       zeros. Expected:
       `cc11b22ecc71746699be747510e43aa06588a464f5cc40feeba5d9b9881882e7`.
     Report entries, plain-verified count, slot-normalized
     verified count, missing, and mismatches as counted — the
     counts above are the expectation, not a substitute for
     your count. Any further plain-check failure is a mismatch:
     report it as such.
3. Verify the Crucible freeze from bytes: recompute the
   CONFIG_FREEZE recursive hash over `<PKG>/crucible/` —
   SHA-256 over the canonical `{relpath: file sha256}` map of
   the 44 files excluding `CONFIG_FREEZE.json`/`CONFIG_FREEZE.md`
   (canonical form is `json.dumps(map, sort_keys=True,
   separators=(",", ":"))`, relpaths relative to `crucible/`,
   each file's hash computed from its extracted bytes) — and
   compare against `e1db0ae1…` in full in your working notes;
   report MATCH/MISMATCH. Also confirm the per-file map agrees
   with `CONFIG_FREEZE.json`'s declared map. **Freeze-check
   discipline:** (a) the recomputation must run FROM THE
   EXTRACTED FILES' BYTES — hashing the map declared inside
   `CONFIG_FREEZE.json` proves nothing; (b) the adapter's
   state line (Step 7) is not a freeze verification: a
   freeze-record self-hash failure appears only as an adapter
   note (state and exit code unchanged), and the adapter does
   not cross-check the freeze record's target hashes against
   tree bytes — always pair the adapter state with this byte
   recomputation.
4. Verify the five store sources in `<PKG>/sources_store/`
   against the pins in the files table.
5. Report any unsafe archive members (absolute paths, `..`
   traversals, escaping symlinks) as counted in both archives.

## STEP 2 — GATE 0 (AAVEP-CAL v2) + kit self-test

1. Verify the kit before use:
   `python3 <KIT>/tools/aavep_selftest.py` — expected
   `SELFTEST: 66/66 checks passed`, exit 0. Report verbatim.
2. Run AAVEP-CAL v2 under the SELF-ADMINISTRATION authorization
   above, using `<KIT>/tools/aavep_cal.py` and the governing
   spec `<KIT>/cal/AAVEP_CAL_SPEC_v2.md`, with administrator
   and subject trees disjoint. Choose and record your
   operator/administrator identifiers. Derive subject responses
   from the subject fixtures only.
3. Report: tier and score (expected form: PASS, 6/6), the
   administration grade as graded (SELF-ADMINISTERED), session
   id, session commitment, transcript hash, per-trap outcomes,
   and the receipt-verification result (the runner in Step 5
   re-scores the receipt from administrator custody; report
   that line too when you have it). **No later step's findings
   are receivable without a same-session PASS receipt.** If
   Gate 0 does not pass, stop: return the envelope with Gate 0
   reported and every later step marked NOT RUN with that
   reason.

## STEP 3 — verify.py (the package front door; NEW in v13)

The package ships a one-command verification wrapper at its
root (`<PKG2>/verify.py`, contract in `<PKG2>/VERIFY.md`),
where `<PKG2>` is your **second, pristine extraction** of the
nested package, kept distinct from the Step 4–8 working copy.

1. On the pristine extraction, before any other tool runs
   inside that tree (the wrapper's integrity stage contracts
   for a pristine tree; sequencing is part of the exercise),
   run:

   ```
   python3 verify.py \
     --admin-dir <your Step 2 CAL administrator tree> \
     --subject-dir <your Step 2 CAL subject tree> \
     --keys <your published CAL keys> \
     --responses <your Step 2 subject responses>
   ```

   supplying **your own** Step 2 administration's custody
   material, in the form `VERIFY.md` and `verify.py --help`
   declare. (The kit self-test is invoked by the wrapper from
   the kit directory; that is the wrapper's declared handling
   of the frozen kit, not an edit to it.)
2. Report the verdict line verbatim and **all seven stage
   lines verbatim** — `integrity`, `gate0`, `kit-selftest`,
   `suite`, `aavep-runner`, `plugin`, `crucible-state`, each
   as `STAGE <name>: PASS` / `FAIL` / `NOT RUN` with its
   reason where printed. **Expected: `VERIFY: COMPLETE`** —
   every stage PASS. A stage that cannot run on your custody
   reports NOT RUN and the verdict degrades to
   `VERIFY: COMPLETE-DEGRADED`: report it as derived, with the
   stage and the reason. NOT RUN never upgrades, here or
   anywhere in this round.
3. The wrapper's stages re-derive results Steps 4–7 derive
   directly. That duplication is deliberate: report both. A
   disagreement between the wrapper's stage and your direct
   run of the same bench is a finding with two witnesses —
   report it, do not reconcile it by preference.

## STEP 4 — SUITE (direct RB1)

1. From `<PKG>` (your first working copy), with your own
   `__pycache__` removed:

   ```
   python3 scripts/RB1_run_all.py Paper_12_5_v13.md
   ```

   The suite runs from the package root under any HOME (an
   empty HOME included — no placements exist to make).
2. Report the aggregate verdict line and exit code verbatim,
   the elapsed time, and **all 29 per-instrument verdicts
   verbatim** (E1–E7, M1, M2, G1, G2, G3, G4, G4X, FW1,
   H1–H13, IDX1). Expected aggregate: `RB1 PASS: 29/29 scripts
   exit 0 on the final tree`.
3. **H.6 is expected plain PASS here**, consuming the shipped
   store, with the verdict line in the shipped record's form:
   `H6 RESULT: PASS (zero MISMATCH; battery caught both
   mutants; UNCHECKABLE items, if any, are printed above and
   named in disclosure (5))`. If `pdftotext` was unavailable
   in your environment, the two PDF extraction legs degrade
   to UNCHECKABLE and the verdict line changes accordingly —
   that is declared behaviour; report the availability and
   the derived line as derived. Any other deviation: report
   what the run derives, with the failing source, its
   locator, and the pin against the observed hash.
4. A first attempt made before cache cleanup is setup history:
   note it under observations (as earlier rounds did) and let
   the clean final run be the result of record. Do not
   silently discard attempts.

## STEP 5 — AAVEP RUNNER (manifest shipped in-package)

The runner's target manifest ships **inside the package**
(`<PKG>/aavep_manifest/aavep_target_manifest_v13.json`; 34
instruments, 33 claims), and H.6 consumes the in-package
store. Run the runner now.

1. Run preflight first and read its lock table in full
   (`<KIT>/tools/aavep_preflight.py` per its `--help`, against
   the in-package manifest, your working-copy package, the
   nested package zip, and the house root the manifest's
   locators declare). Report its summary line verbatim (target
   MATCH/MISMATCH; instrument count — 34; BLOCKED list;
   problems; valid), every BLOCKED instrument by id, and every
   printed notice. Report the preflight BLOCKED list verbatim.
   Note: `problems: 0` and `valid: True` do NOT clear a
   BLOCKED instrument — the runner refuses BLOCKED instruments;
   a non-empty BLOCKED list is a finding. H.6's five sources
   must lock from the in-package store locators the manifest
   declares (`paper_12_5_verification/sources_store/…`).
2. Then run the runner (paths adjusted to your layout; the
   kit's `--help` and `<KIT>/AGENT_INSTRUCTIONS.md` govern any
   flag not shown). Layout requirement, from the house run of
   record: **present the package inside the run workspace as
   the manifest's `workspace_file` locators declare**, and
   present your administrator tree, subject directory,
   published keys, and opening record, so the receipt
   re-scores from administrator custody (RESCORED) rather than
   grading commitment-only:

   ```
   python3 <KIT>/tools/aavep_run.py \
     --manifest <PKG>/aavep_manifest/aavep_target_manifest_v13.json \
     --package <your extracted package copy> \
     --package-zip <the extracted transport's nested package zip> \
     --workspace <a fresh runner workspace> \
     --house-root <the root presenting the package at the manifest's locators> \
     --receipt <your Gate 0 published receipt> \
     --cal-admin-dir <your CAL administrator tree> \
     --cal-keys <your published CAL keys> \
     --ledger <a fresh run ledger path>
   ```

   (`--package` is the directory that CONTAINS the extracted
   `paper_12_5_verification/` directory (its parent directory)
   — the layout the house run used.)
3. **Report the runner's derived overall and every
   per-instrument status verbatim** — all 34 instruments
   (E1–E7, M1, M2, G1, G2, G3, G4, G4X, FW1, H1–H13, IDX1,
   RB1, plugin-provenance, plugin-cards, esp-conformance,
   crucible-adapter), plus the confinement line and the
   event-log head, exactly as derived. Never shorten a
   degraded status (PASSED-DEGRADED, COMPLETE-DEGRADED) in
   anything you write.

   **PRE-REGISTERED EXPECTATION — the needle; a prediction,
   not an instruction to reach it.** The house run under this
   manifest derived: **31 PASSED, 3 PASSED-DEGRADED, 0 FAILED,
   0 BLOCKED**; overall **COMPLETE-DEGRADED · 0 FAILED**. All
   three degraded grades are the **B-32 PARTIAL-MARKER
   class** — the protocol-default marker word UNCHECKABLE
   occurring in honest output prose — not substantive
   qualifications:
   - **H.6: PASSED-DEGRADED (PARTIAL-MARKER)** — exit 0; the
     marker is the word UNCHECKABLE in its own verdict prose
     (Step 4.3 quotes the line: the marker occurs at a
     MISMATCH count of zero). Quote H.6's runner stdout
     verbatim in your report, so the mechanism is visible in
     your run, not just asserted. Grade it as the named B-32
     vocabulary behaviour of the frozen v1.1 runner (recorded
     in AAVEP v1.1's design record as a v1.2 tension), **not
     as a defect** — and not as a plain PASS either: print the
     degraded status whole.
   - **RB1: PASSED-DEGRADED (PARTIAL-MARKER)** — the same
     class propagated from H.6's output; its inner run
     derives `RB1 PASS: 29/29`.
   - **crucible-adapter: PASSED-DEGRADED (PARTIAL-MARKER)** —
     the runner-internal adapter runs against the shipped
     in-package configuration and derives the PARTIAL state;
     Step 7 derives the same configuration's state line
     directly. Report both as derived; they are two
     presentations of one configuration, not a discrepancy to
     reconcile.
   **If your run derives otherwise, report what it derives.**
   The expectation is held only if the STATUSES match AND
   H.6's stdout, quoted verbatim, shows the PARTIAL-MARKER
   mechanism — an H.6 FAILED, a BLOCKED instrument, or a
   degraded grade with any other spill is a different result:
   report it as such, with the spill head quoted.
4. Do not edit the manifest, the lock table, statuses, spill,
   or the ledger to change a derivation. Corrections are new
   runs, reported as such.

## STEP 6 — PLUGIN (honesty plugin, all card sets)

1. Using the plugin shipped in the package (the kit's plugin:
   `PYTHONPATH=<KIT>/plugin/src`; the manifest's
   `plugin-cards` command form: `python3 -m honesty_plugin
   cards <set>/canonical_cards.json --sources <set
   directory>`; the same plugin source ships at
   `<PKG>/apparatus/plugin_src`), run card validation over
   **every** canonical card set in the package, from the
   package alone: `cards` (39 expected), `cards_lattice`
   (43), `cards_literature` (143), `cards_self` (318),
   `cards_additions` (three files: 58, 62, 24),
   `cards_self_supplement` (202),
   `cards_self_supplement_v7` (288),
   `cards_self_supplement_v8` (118),
   `cards_self_supplement_v9` (237),
   `cards_self_supplement_v10` (188),
   `cards_self_supplement_v11` (255),
   `cards_self_supplement_v12` (187),
   `cards_self_supplement_v13` (369). For `cards_literature`,
   whose canonical file is a bare list with no sources map
   (its sources resolve by the documented
   `{source_id}_excerpts.txt` convention, which the generic
   route does not implement): an explicit temporary sources
   map to the documented filenames is the documented route
   (earlier rounds used it and then verified
   `cards_literature/SOURCES.sha256`); the alternative honest
   report is the set as suite-validated via H.3 in your Step
   4 run. Say which route each set used — never pass a set in
   silence.
2. Report per set: the verdict line verbatim
   (accepted/rejected counts), the exit code, and whether the
   sources manifest verified. Also run the plugin's
   provenance check over `<PKG>/scripts` (the manifest's
   `plugin-provenance` command) and report it as derived.
3. **`cards_self` under BOTH routes — required.** (i) The
   generic plugin route: the set's substrate,
   `Paper_12_5_v5.md`, ships inside `<PKG>/cards_self/`
   itself, so the source resolves in place — no copy step
   exists in this round; report the verdict exactly as
   derived. (ii) The suite route: H4's verdict for the same
   set from your Step 4 run. Report both, labelled by route.
   A disagreement between routes is reported, not resolved by
   preference.
4. State the plugin's declared limits in your not-checked
   list (semantic support, premise truth, layer correctness
   beyond taxonomy membership, location correctness beyond
   source-file membership, set completeness — validate_cards
   establishes none of these).

## STEP 7 — CRUCIBLE (configuration shipped in-package)

The configuration ships **inside the package** at
`<PKG>/crucible/` (instance #4, frozen over the v13 tree; its
freeze verified byte-by-byte in Step 1.3). This step is a
state derivation and a freeze verification — **not a trial**.
Convening the trial is a house act; no bench in this round is
asked to convene it, spawn examiner benches, or manufacture
trial artifacts.

1. **Adapter state (required).** Run the vendored adapter
   state against the shipped configuration's freeze record and
   frozen tree:

   ```
   python3 <KIT>/tools/crucible_adapter.py state \
     --freeze-record <PKG>/crucible/freeze/trial_freeze_record.json \
     --tree <PKG>/crucible/freeze/frozen_tree \
     --out <adapter_state.json>
   ```

   Report the **state line verbatim**. **Expected:
   `PARTIAL · anchor UNANCHORED`** — the frozen-ready state:
   the freeze is UNANCHORED (external anchoring is the
   author's act), and no trial artifacts exist, so PARTIAL is
   the ceiling for the configuration as supplied. Frozen-ready
   means: the configuration is frozen, its freeze recomputes
   from file bytes (Step 1.3), and the adapter loads it — no
   trial execution has occurred. Report the adapter's full
   notes list, not just the state line. `NOT RUN` here would
   mean the configuration failed to load — report it as such,
   with the adapter's notes.
2. **Freeze verification (required).** Your Step 1.3
   recomputation is this configuration's freeze verification;
   report its result alongside the state line, and also
   report the state the configuration itself shipped
   (`<PKG>/crucible/adapter_state_initial.json`) for
   comparison. **Never mark the trial itself RUN** — not on
   the basis of the configuration's existence, its shipped
   state artifacts, or this step. A configuration is
   readiness, not execution.

## STEP 8 — SPOT-CHECK + EXHIBITS (holder's tools; NEW in v13)

The acceptance history of this package is that exercising the
holder's tools caught defects the benches' table-and-path
checks could not reach. This step exercises them directly.

1. **Claim spot-check.** From `<PKG>/spotcheck/`, run
   `check_claim.py` (its `--help` governs the invocation form)
   for each of: **L3.4.4**, **C53**, **C52**, **L8.13-P12.5**.
   Expected: `SPOTCHECK PASS` for each, against the shipped
   (index, run record) pair. Report each verdict line
   verbatim.
2. **Negative control (required).** Run the same tool for an
   identifier that is not in the index (for example
   `L9.9.9`). Expected: a not-in-index report, **not** a PASS
   and not a crash-free silence. Report the output verbatim.
   A tool that passes everything passes nothing.
3. **Exhibits.** Run each of the three exhibits in
   `<PKG>/exhibits/` (`exhibit_tombstone.py`,
   `exhibit_gibbs.py`, `exhibit_negtemp.py`). Each is
   self-contained, prints its provenance (including its own
   hash — compare against the manifest entries:
   `ca6f8853c368680c092d5b9913bdeb80836cde44f0fcd96cf64cfab33b6ef9cd`,
   `928d4ec4c430d00a983a16732a65807e1fc8d822ee40944516895da566044d51`,
   `0b957d2f0348ee0ac8a01f160d467ea570fa0134ddf008f06beebde98382b6d1`),
   and executes to its own PASS line. Report the three
   verdict lines verbatim.

## RULES (all steps)

- **Verbatim derivations.** Every status, verdict, state line,
  and count in your report is copied from the tool output that
  derived it. Posture — hostile, neutral, appreciative — never
  changes what counts as evidence.
- **Expectations are predictions.** Where this instruction
  pre-registers an expectation (Steps 1, 3, 4, 5, 6, 7, 8), it
  is there to be tested. Deriving otherwise and reporting it
  plainly is a successful round; adjusting anything to reach
  an expectation is fabrication and voids the round.
- **Printed expectations need witnesses.** A report that
  matches an expectation without carrying the run's own
  witnesses (session ids, event-log heads, counts you
  computed, spill lines) is not evidence.
- **Work on copies; edit nothing supplied.** The manuscript,
  the package bytes, the transport members, the frozen kits,
  the configuration tree, and the manifest are read-only
  inputs. The only writes this instruction directs are: your
  working-copy extractions, runner / CAL workspaces and
  ledgers you create, and your report.
- **BLOCKED and NOT RUN are results.** Name the instrument,
  the reason, and the governing source for each. Never let an
  unexecuted check pass silently, and never convert an absence
  into a pass.
- **Findings need witnesses.** A finding is filed only with
  its governing source, that source's hash, the verbatim quote
  at its line, and the enclosing heading. A FAIL you cannot
  witness is reported as an observation, not a finding.
  Second-agent reproduction governs adjudication where the
  AAVEP procedure requires it; your own confidence is not a
  lifecycle state.
- **Print degraded whole.** PASSED-DEGRADED and
  COMPLETE-DEGRADED are statuses, not embarrassments. Never
  shorten them — and never inflate them either: a
  PASSED-DEGRADED whose mechanism is the pre-registered B-32
  marker class is graded as that named behaviour, not upgraded
  to a defect and not smoothed into a PASS.
- **No coverage inflation.** State what you did not check
  (§9, `not_checked`). An execution audit is not a
  line-by-line semantic adjudication, and saying so is part
  of the result.

## STEP 9 — ESP FORM

Carried over from v1/v2/v3 — it worked, three times. Return
exactly one ESP v2.4 envelope, built as follows:

- Envelope tier: `archival`. Header: `message_type: "CLAIM"`,
  `protocol_version: "2.4"`, `min_protocol_version: "2.4"`,
  your `sender_agent`, target `Paper_12_5_v13 author / audit
  recipient`, an ISO-8601 `timestamp`, and a fresh
  `message_id`.
- Epistemic context: `register: "META_AUDIT"`, `badge:
  "META"`, `registry_version: 0`, empty `active_axioms`,
  `axiom_set_hash` = sixty-four zeros, and `scope_notes`
  stating this is an execution audit of Paper_12_5_v13 and
  its supplied verification package, META_AUDIT only, no
  native physics claim. `session_id`: your report id.
- Payload: `claim_class: "COMPUTATIONAL"`, `format:
  "AUDIT_REPORT"`, `determinism: {"mode": "DETERMINISTIC"}`,
  `protocol: {"name": "ESP", "version": "2.4"}`, and
  `provenance`: `bundle_manifest_hash` =
  `e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd`
  (the package manifest hash), `depends_on` naming the two
  received files, `lineage: "bundle"`.
- **`payload.content` is ONE STRING**: the entire audit
  report (§9 OUTPUT) as a single JSON document, stringified
  into that one string field. Not an object, not split across
  fields, not attached elsewhere. (Every earlier validated
  envelope carried the report exactly this way; the one
  envelope that nested an object was rejected by the engine.
  Keep the string form.)
- **Integrity hashes blank**: `integrity.content_hash: ""`,
  `integrity.envelope_hash: ""`, `integrity.axiom_set_hash` =
  sixty-four zeros, `integrity.status: "PENDING"`,
  `integrity.tier: "chat"`. The chat tier computes hashes
  locally at validation; pre-filled hashes of your own
  manufacture are a defect, not diligence.
- **Validate before sending**: run the shipped validator over
  the exact envelope you will send —
  `python3 <PKG>/aavep_v11/esp/esp_cli.py validate <envelope
  file>` (it reads stdin if given no file) — and send only an
  envelope whose verdict is VALIDATED. Report that verdict
  line in the report itself
  (`esp_engine_validation_verdict`). The validator is a
  presenter, never a fixer: if it rejects, fix the envelope
  you authored, never the tool, and never ask the tool to
  repair hashes for you.

## OUTPUT — the one envelope's report must contain

The stringified report inside `payload.content` is one JSON
document with, at minimum:

- `report_id`, `governing_versions` (ESP 2.4, AAVEP 1.1,
  AAVEP_CAL 2, Crucible GS-4 Gold configuration instance #4),
  and `target` (manuscript name, hash, bytes, lines; package
  name).
- `integrity`: every Step 1 result — uploaded manuscript,
  transport, nested package (hash, members, unsafe members),
  package-copy manuscript hash, package manifest (hash,
  printed §8.24 M, match, entries, plain/slot-normalized
  verified counts, missing, mismatches), slot normalization
  detail (the three entries with your computed normalized
  hashes), the CONFIG_FREEZE recompute result (computed hash,
  printed F, match, file count), the five store sources with
  hashes and the pin result, `pdftotext` availability.
- `aavep_cal_v2`: Step 2 in full — status, tier, score,
  administration grade as graded, receipt fields, receipt
  verification, and the scope-limit sentence for
  self-administration.
- `aavep_v1_1_kit_selftest`: status, checks (66/66 expected
  form), exit code, evidence.
- `verify_py`: Step 3 — the verdict line verbatim, all seven
  stage lines verbatim, the custody material supplied (form
  only, not contents), and which pristine extraction it ran
  on.
- `suite`: Step 4 — runner, command, status, exit code,
  instrument count (29), elapsed seconds, aggregate verdict
  verbatim, all per-instrument verdicts, and the H6 detail
  (verdict, source status, summary line), with `pdftotext`
  availability stated here as well.
- `aavep_runner` (required): the Step 5 preflight summary
  verbatim; **the runner's derived overall verbatim**; and
  **every per-instrument status** (all 34) as derived,
  including H6, RB1, plugin-provenance, plugin-cards,
  esp-conformance, and crucible-adapter; confinement line;
  event-log head; H.6's stdout needle lines quoted verbatim;
  and an explicit note of whether the pre-registered needle
  held in your run — held only if the STATUSES match AND
  H.6's stdout carries the PARTIAL-MARKER mechanism visibly;
  any other derivation is a different result and is reported
  as such.
- `honesty_plugin`: Step 6 — per-set verdicts with exit codes
  and sources-manifest results for all sets (including the
  three `cards_additions` files and
  `cards_self_supplement_v13`), the provenance result, a
  summary count, and **`cards_self` reported under BOTH
  routes**, labelled: (generic plugin, substrate in place)
  and (H4 via the suite), each with its own verdict. State
  which route `cards_literature` used.
- `crucible_gs4` (required): the shipped configuration
  identified (in-package path, freeze hash); **the adapter
  state line, verbatim**; the adapter's notes; your
  freeze-verification result (Step 1.3 recomputation); the
  configuration's own shipped state artifact for comparison;
  and an explicit statement that the trial was **not**
  convened in this round (convening is a house act) — never a
  RUN claim from the configuration alone.
- `spotcheck`: Step 8 — the four claim checks with their
  verdict lines verbatim, the negative control's output
  verbatim, and the three exhibits with their verdict lines
  verbatim and their recomputed hashes.
- `esp_engine_validation_verdict`: the Step 9 validator's
  verdict line for the envelope carrying this report.
- `findings` (witnessed, per RULES — empty list if none),
  `observations`, `not_run` (each with its reason), and
  `not_checked`.
- `overall_status`: one line that prints every bench's
  outcome at its exact size — integrity, Gate 0 with its
  grade, kit self-test, verify.py verdict, direct RB1 as
  derived, AAVEP runner overall as derived, plugin summary
  with the cards_self two-route result, spot-check summary,
  and the Crucible adapter state — with degraded statuses
  printed whole and no bench's outcome borrowed to cover
  another's.

Return the one validated envelope. Nothing else is the
deliverable: no separate prose summary substitutes for it, and
no result outside it is of record.

— End of instruction v4 —
