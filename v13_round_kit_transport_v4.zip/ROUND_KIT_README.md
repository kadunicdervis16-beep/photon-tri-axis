# ROUND KIT README — Paper 12.5 v13 external round, transport v4

Date: 2026-11-21. Target: Paper 12.5 — *The Ensemble Illusion*,
**v13** (delivered 2026-11-14).

This file is the README at the root of
`v13_round_kit_transport_v4.zip` (the ingestion transport, v4).
It inventories every member of that archive, states what the
round needs and where it lives, records what v13 is, states the
standing facts a runner needs, and states the known residues
plainly. Read it before extracting anything.

## Slots — what you receive, and what this archive is

- **Slot 1 (separate upload, NOT in this archive, unchanged):**
  `Paper_12_5_v13.md` — the manuscript itself.
  SHA-256 `7096e38fe99691e80378ac694f716279a7d4890ade030eae80a5fe4de4edad38`;
  2,619,887 bytes; 45,172 lines. Verify your Slot 1 copy against
  this hash before anything else.
- **This archive (Slot 2):** `v13_round_kit_transport_v4.zip` —
  the v13 verification package (nested, byte-untouched), this
  README, the build verification record, and the instruction
  (next bullet). That is all: **the package is the ingestion**
  (next section).
- **Instruction (inside this archive):**
  `EXTERNAL_ROUND_INSTRUCTION_v4.md` — the external-round
  instruction this kit serves (v4.1: it rides inside the
  transport because the author's upload channel takes two
  files). It supersedes
  `EXTERNAL_ROUND_INSTRUCTION_v3.md` in full; v3 was written
  against v12 — its files table, its 27-instrument suite, its
  32-instrument target manifest, and its Crucible instance #3
  describe a target that no longer exists. Do not run v3
  against this kit.

The house run records are **not** shipped in this archive. They
are house ingestion provenance, not ingestion content: you run
fresh, and house verdicts must not anchor your run. The
standing facts below quote the house derivations because the
instruction pre-registers them as predictions — the records
themselves stay with the house.

## Contents — every member of this archive

Archive member count is recorded in
`ROUND_KIT_VERIFICATION.md`, shipped inside this transport at
its root. The transport's own SHA-256 cannot be printed
inside it (a file cannot hash the archive that contains it);
it is stated by the author with the delivery, and the round's
envelope reports the value the runner computes — the author
verifies it on receipt. The verification file's own row is
hashless and is anchored the same way. Every other member is
listed here. Hashes are SHA-256 over the member's bytes
exactly as shipped.

| # | Path in archive | Bytes | SHA-256 |
|---|---|---|---|
| 1 | `ROUND_KIT_README.md` | (this file) | — (this file; recompute with `sha256sum ROUND_KIT_README.md` after extraction and compare against `ROUND_KIT_VERIFICATION.md` in this transport) |
| 2 | `ROUND_KIT_VERIFICATION.md` | (this transport's verification record) | — (hashless here and in its own table — it carries the README's and the instruction's SHA-256 values) |
| 3 | `Paper_12_5_v13_verification_package.zip` | 18884115 | `3f8350e1ca1cd9474129d3d4a2965493cc7f70b6a4d5f59805c3cfaaa3fb2605` |
| 4 | `EXTERNAL_ROUND_INSTRUCTION_v4.md` | 35956 | `95bb596dc5257105ac87980245c0fc64a78cab794476feb3d511b8712be877be` |

The nested package is **byte-untouched**: it is the delivered
`Paper_12_5_v13_verification_package.zip`, SHA-256
`3f8350e1ca1cd9474129d3d4a2965493cc7f70b6a4d5f59805c3cfaaa3fb2605`,
copied without recompression of its contents, re-zipping, or
any edit. It has 1,147 members, no interpreter caches, and no
unsafe members. Its `MANIFEST.sha256` (1,146 entries) hashes to
`e83da14f9bb18912e979841945b68b40d03f15bbf3ce57316e5f7bed1aebcdfd`
— the value the paper prints at §8.24 as
`package-manifest-sha256`.

## The package is the ingestion — what the round needs, inside it

Everything an external round needs ships **inside the nested
package** (root `paper_12_5_verification/` after extraction;
`<PKG>` below). Nothing outside it is required.

**The one-command front door — `verify.py` + `VERIFY.md`.**
New in v13 (item A7 of the build): the package root carries a
single verification wrapper that runs seven stages in declared
order (integrity, gate0, kit-selftest, suite, aavep-runner,
plugin, crucible-state) and prints one verdict
(`VERIFY: COMPLETE` when every stage ran and passed; a NOT RUN
stage never upgrades the verdict). `VERIFY.md` is its contract.
The instruction runs it as its own step, on its own pristine
extraction, with your Gate 0 custody supplied — and then runs
the direct benches anyway: the wrapper is a convenience, not a
substitute for your own derivations.

**The claim spot-check index — `spotcheck/`.** Also new (A8):
`claim_index.json` (33 claims; 20 conditions, C34–C53; 18
instrument entries with stored verdict lines),
`check_claim.py`, `build_claim_index.py`, and the shipped
`suite_run_record.txt` the index was built from. The pair's
consistency is machine-checked inside the suite by H.13
(§8.26). The instruction exercises `check_claim.py` directly,
including a negative control.

**The exhibits — `exhibits/`.** Three self-contained runnable
exhibits (A9), each printing its provenance and executing to
its own PASS line, each pinned by H.13:
`exhibit_tombstone.py`
(`ca6f8853c368680c092d5b9913bdeb80836cde44f0fcd96cf64cfab33b6ef9cd`;
S = k log W as bookkeeping provenance), `exhibit_gibbs.py`
(`928d4ec4c430d00a983a16732a65807e1fc8d822ee40944516895da566044d51`;
the C(2N,N) factor as a counting rule), `exhibit_negtemp.py`
(`0b957d2f0348ee0ac8a01f160d467ea570fa0134ddf008f06beebde98382b6d1`;
the negative-temperature census).

**The H.6 sources store — `sources_store/`.** The five series
sources H.6's registry walker consumes, each under the
byte-hash pin printed in H.6's header, shipped inside the
package:

| Path (under `<PKG>/sources_store/`) | Bytes | SHA-256 (== H.6 pin) |
|---|---|---|
| `Paper_12_v4.md` | 4458947 | `db5b40047656f583990228779aff7206c7a3cc42065f540412691aa05d99c793` |
| `paper_11_5_v26.md` | 642312 | `9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60` |
| `paper_11_v69_PDF_1_47yt.pdf` | 1786596 | `6c1071777deacf3bdb43d165040487844f30189bc642666c886a793ae2f99974` |
| `paper1_extracted.txt` | 42227 | `c73a4840ef18f1e0a17cd0fac333a83ed7d9206424c30e1b9939969b4d358643` |
| `Paper_9_5_The_Borrowed_Thermometer_Paper9_Style_FINAL_2_c4ck.pdf` | 218077 | `5e99256b66a9e58b6cf75a4274eaa70de089b150df3dd864ac264d71ebe20b03` |

**The Crucible configuration — `crucible/`.** A complete GS-4
trial configuration **for this paper**, generated over the v13
final tree and frozen at the v13 build: instance #4 of the
configuration mechanism (Paper 12's is #1, v11's #2, v12's #3 —
all frozen history, untouched). 46 members: the CONFIG_FREEZE
pair plus the 44 frozen files they inventory (freeze record
and frozen tree under `crucible/freeze/`, examiner packet
under `crucible/packet/`, 25 registered mutations, role
charters, blind adjudication protocol). Its freeze identity —
the CONFIG_FREEZE recursive hash, SHA-256 over the canonical
`{relpath: file sha256}` map of the 44 files, the freeze pair
excluded — is
`e1db0ae1c7b545cdae7282329741bd80cc43a3d3fb7059c1552e5a1f9375cb6e`,
the value the paper prints at §8.24 as
`crucible-freeze-sha256`. (`crucible/CONFIG_FREEZE.json`
itself: 4,894 bytes, SHA-256
`3a7b82cd56e2ae7cb47f33601b6d925e0d5083bcb0d8cffefc3c967c96ddff03`;
`crucible/CONFIG_FREEZE.md`: 1,572 bytes, SHA-256
`fe381b368201ce1dc789472f101052b9a3713b806b0fa207d49a9c069b02a709`.)

**The AAVEP target manifest — `aavep_manifest/`.**
`aavep_target_manifest_v13.json` (30,885 bytes; plain SHA-256
`cc0e70daa7d376ee0cd34cce6f956beeb73642cdf82237b4d3eb97c42732dde4`;
manifest_id `aavep-target-paper-12.5-v13`; 34 instruments, 33
claims), generated against this version's hashes and
instrument table, so the protocol's general runner has a
current target in the package itself. Its package-manifest
entry is slot-normalized (the §8.24 construction: its two
target-hash field values — the manuscript's plain SHA-256 and
the package-manifest SHA-256 — replaced by sixty-four zeros
before hashing), giving
`cc11b22ecc71746699be747510e43aa06588a464f5cc40feeba5d9b9881882e7`.

**The kits and instruments.** The frozen AAVEP v1.1 kit ships
entire at `<PKG>/aavep_v11/` (tools, CAL v2, ESP engine,
honesty plugin under `plugin/`); the frozen v1.0 kit at
`<PKG>/aavep/`; the plugin source also at
`<PKG>/apparatus/plugin_src`. The suite is `<PKG>/scripts/`
(RB1 runner plus the 29 instruments: E1–E7, M1, M2, G1–G4,
G4X, FW1, H1–H13, IDX1). The card sets ship in place —
`cards`, `cards_lattice`, `cards_literature`, `cards_self`,
`cards_additions`, and the self-card supplements
`cards_self_supplement` (v6) through
`cards_self_supplement_v13` — **including the historical
`cards_self` substrate**: `Paper_12_5_v5.md` ships inside
`cards_self/` itself, so the generic plugin resolves that set
in place, with no copy step and no external file.

## Decision — no H.6 home copies in this transport

Transport v2 carried the five H.6 sources a second time, at
canonical `workspace/…` paths, because v11's walker resolved
its sources through the holder's home directory. **Transports
v3 and v4 carry no home copies, deliberately.** The walker
consumes the shipped store only; the suite passes entire with
HOME pointed at an empty directory (an acceptance run, on the
record), so no component of the round resolves data outside
the package. Shipping home copies again would create a second,
divergent source of truth for bytes the package already pins —
the exact ambiguity the store cure exists to remove. The one
outside-package input the round still has is a *tool*, not
data: `pdftotext`, which H.6's two PDF extraction legs use on
the stored PDFs. If it is unavailable in your environment,
those two legs degrade to the printed UNCHECKABLE form —
declared behaviour, stated in the paper; report its
availability either way.

## What v13 is — the build record in brief

v13 was built 2026-11-13/14 under the author's commission (the
"A-list": ten items adopted from an external review round on
v12, rebuilt for an agent audience). Headline items: **A1** —
§3.5 states and proves the finite exchangeability theorem in
native voice (claim L3.4.4, split badge MACHINE grid / AUTHOR
totality), instrument **E.7** (§8.25: 829 sequences over 15
cells; 88,213 (sequence, permutation) pairs; 9,681 ordered
equal-count pairs with the permutation constructed and checked
pair by pair; four planted mutants rejected on printed
witnesses), falsifier **C53** registered — the falsification
surface now runs **C34–C53**, carried by the layered statement
L11.4 (L11.1–L11.3 stand unrewritten). **A7/A8/A9** — the
`verify.py` front door, the spot-check index, and the three
exhibits above. **A10** — the §0.5.7 orientation block (the
predicted-and-incurred failures exhibit and the mirror table).
All new prose was dual-carded: the v13 supplement validates
**369/369** under the plugin (bridges 186 — 68 declared / 118
undeclared, disclosed at Appendix F.5; falsifiers stated on
369/369). The build's loop pass (devil's advocate 12 charges /
9 sustained; evil auditor 2 defects; red team 3 critical + 7
further holes) was repaired before assembly; the full record
is `BUILD_RECORD_v13.md`, kept with the house's delivery
files. v13 was delivered **once** — there is no repair twin.

The delivered tree's acceptance, on that record: **RB1 PASS
29/29** on the package tree, again from a fresh extraction of
the delivered zip, and again with HOME at an empty directory;
**VERIFY: COMPLETE** from a pristine extraction with the house
CAL v2 administration supplied (all seven stages PASS); the
AAVEP runner's derivation quoted in the standing facts below;
every shipped card set validating under the plugin from the
package alone; the adapter state PARTIAL · anchor UNANCHORED.

**Other versions are different files, and are not this
round's target.** The v12 paper is
`e073c9fc3bee62610bf86a1d695eb6eeb533d9532845994af1bceb8fc8d344f2`
and the v12 package is
`db52b88171697bdfcbd9056aca28d1757b99bb4ca96961316a26cd450257ec66`.
If the package in front of you hashes to the v12 value, you
are holding the previous version — the instruction's
printed-hash checks exist to catch exactly that substitution,
at the slot, at the nested package, and at the §8.24 manifest
interlock.

## AAVEP PROMOTION record

By the author's ruling of 2026-11-13, GPT-6's executed
external round of that day against v11 (AAVEP-CAL v2 PASS 6/6
under the SELF-ADMINISTERED grade; kit self-test 66/66; RB1
27/27; envelope ESP-VALIDATED · chat tier — the ESP engine's
verdict on the envelope's form, not an AAVEP run stamp)
PROMOTED AAVEP out of DEMONSTRATION standing. v12 and v13 both
print the promotion in their own text (§8.24, on the record
quoted there; §0.5.1 item-6 likewise). The frozen AAVEP kits
(v1.0/v1.1) still print DEMONSTRATION in their frozen texts,
and earlier papers' embedded appendices print the standing of
their versions — that printed standing is historical, the kits
and prior versions are not edited, and this record plus §8.24
state the standing as it now is.

## Standing facts a runner needs

- **AAVEP: PROMOTED** (author's ruling, 2026-11-13; above).
- **Crucible: configured for this paper, trial not convened.**
  The configuration shipped in the package (instance #4) is
  frozen; the adapter derives **PARTIAL · anchor UNANCHORED**
  from its artifacts — the frozen-ready state, and the ceiling
  until trial artifacts exist. The freeze is UNANCHORED:
  external anchoring is the author's act and has not been
  done. Convening the trial is likewise a house act; the
  configuration's existence never by itself makes the trial
  RUN.
- **The runner needle — pre-registered.** Under the AAVEP
  runner with the shipped v13 manifest, the house run derived:
  **31 PASSED, 3 PASSED-DEGRADED, 0 FAILED, 0 BLOCKED**;
  overall **COMPLETE-DEGRADED · 0 FAILED**. All three degraded
  grades are the **B-32 PARTIAL-MARKER class** — the
  protocol-default marker word UNCHECKABLE occurring in honest
  output prose — not substantive qualifications:
  - **H.6: PASSED-DEGRADED (PARTIAL-MARKER)** — exit 0. The
    mechanism is visible in its own verdict prose, which
    carries the marker word at a mismatch count of zero
    (directly, in the suite, H.6 derives plain PASS with the
    verdict line: `H6 RESULT: PASS (zero MISMATCH; battery
    caught both mutants; UNCHECKABLE items, if any, are
    printed above and named in disclosure (5))`).
  - **RB1: PASSED-DEGRADED (PARTIAL-MARKER)** — the same class
    propagated from H.6's output; its inner run derives
    `RB1 PASS: 29/29`.
  - **crucible-adapter: PASSED-DEGRADED (PARTIAL-MARKER)** —
    the runner-internal adapter derives the PARTIAL state
    from the shipped in-package configuration; the
    instruction's Crucible step derives the same
    configuration's state line directly. Two presentations of
    one configuration, not a discrepancy.
  Grade the class as the named B-32 vocabulary behaviour of
  the frozen v1.1 runner (recorded in AAVEP v1.1's design
  record as a v1.2 tension), **not as a defect** — and not as
  a plain PASS either: print the degraded status whole. **If
  your run derives otherwise, report what it derives.**
- **House Gate 0 grade — disclosed.** The house acceptance
  above ran under a house-administered CAL v2 administration
  (one agent holding both principals in sequential phases),
  graded **ADMINISTERED**, PASS 6/6. Your round
  self-administers and grades **SELF-ADMINISTERED**. The
  grades are different words for different custody; neither
  upgrades the other.

## Known residues — stated plainly

**(a) The B-32 marker class.** Three of the runner's grades
are PASSED-DEGRADED for the vocabulary reason above. Nothing
in this kit touches the frozen runner; the class is named
here and in the instruction so it is graded as what it is.

**(b) The vendored adapter's blind spot.** A tamper of the
Crucible configuration that also recomputes the
configuration's self-hash passes the adapter alone. The
defence is the kit-level byte-recompute: H.12's legs inside
the suite, and the instruction's Step 1 CONFIG_FREEZE
recomputation from file bytes, which the adapter state must
always be paired with. The frozen kits were not touched.

**(c) The freeze is UNANCHORED** — see the standing facts.
The adapter's PARTIAL is the honest ceiling for the
configuration as supplied, not a shortfall to explain away.

**(d) Clause (a) stands UNRESOLVED, 8/8** — in the paper, not
in this round's scope: Chandler Ch. 3 (pp. 54–72) remains
unheld by the house, and §2.8's narrowed claim is printed
with that status. No step in this round tests it, and no
result in this round changes it.

**(e) H.13's authenticity limit** (red-team RT-5, disclosed
in the instrument's own text): the spot-check index's
authority is anchored by the package manifest interlock and
the paper's printed hashes, not by H.13 itself.

## Verification

Before building this archive, every input was recomputed
against its pin on the house machine (manuscript, nested
package, manifest closure in both directions — 1,143 entries
plain-verified and the three slot-normalized entries verified
under the §8.24 constructions — freeze recomputation from the
declared map, store pins — all matched). After building, the
archive was test-extracted to scratch and re-verified,
including a package-swap probe: a copy of this transport with
the nested package replaced by the v12 package is caught by
the kit's printed-hash checks (recorded in the verification
file). The full check-by-check table is in
`ROUND_KIT_VERIFICATION.md`, shipped inside this transport at
its root; any check that had failed would have stopped
delivery, not been narrated around.

## Frozen history — what this kit does not do

- It does not edit the manuscript, the verification package,
  the AAVEP kits (v1.0/v1.1), the Crucible configuration, or
  the AAVEP manifest. Everything here is a byte copy at a
  declared path.
- It does not anchor the Crucible freeze, convene the Crucible
  trial, or certify anything. It supplies ingestion so an
  external runner can execute the round the instruction
  defines.
