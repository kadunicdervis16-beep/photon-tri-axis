#!/usr/bin/env python3
"""P.8 — Mass has no unique "intrinsic" value: pole vs MS-bar vs scale.

INPUT_PROVENANCE (per Paper 11 V17/P2 staple):
  - Pole-MSbar relation coefficients: class=cited-paper
    (c1 = 4/3 one-loop; c2 = 13.4434 - 1.0414*n_l two-loop, Gray et al. /
    Chetyrkin-Steinhauser; n_l = 5 light flavors for the top).
  - alpha_s(M_Z) = 0.1180: class=cited-paper (PDG world average, representative).
  - One-loop mass anomalous dimension running: class=paper-defined
    (standard RG form m(mu)=m(mu0)[a(mu)/a(mu0)]^{gamma0/2beta0};
    declared assumption: one-loop truncation, n_f fixed — the mu-DEPENDENCE
    is the claim, not the exact trajectory).
  - gamma0 = 8 (quark mass anomalous dimension, one-loop), beta0 = 11-2n_f/3.

CONTINUUM_USE (v24 FORTRESS — explicit disclosure, Dervis's "disclose why"):
  - WHAT: the pole<->MS-bar series m_pole = m_MS [1 + c1 (a_s/pi) +
    c2 (a_s/pi)^2] with cited-paper real coefficients; one-loop RG running
    with math.log (scale dependence) and real exponents.
  - WHY NEEDED: the exhibit IS the SM's own scheme/scale machinery — the
    paper's claim is "no unique encounter-free mass exists across definitions
    or scales", and the definitions (pole vs MS-bar) and the scale-dependence
    are the SM's real-analytic relations. The continuum is not scaffolding
    around the exhibit; it is the exhibit.
  - WHAT WOULD BE LOST INTEGER-NATIVE: the exhibited relations themselves.
    The definitional spread (~9 GeV vs 0.3 GeV precision) and the mu-dependence
    are statements about the SM's series and RG equations; an integer-native
    toy would exhibit *a* scheme-dependence, not the SM's. The renormalon
    ambiguity (disclosed, not computed) is likewise intrinsically about the
    series' large-order behavior in the continuum.

What the script checks (native domain: perturbative quark-mass definitions;
verified domain: the scheme/scale arithmetic):
  1. m_pole - m_MSbar for the top at one and two loops: the DEFINITIONAL spread
     across "the mass" exceeds experimental precision by an order of magnitude.
  2. m_MSbar(mu) evaluated at mu = m_b vs mu = M_Z: the number moves with the
     scale — the scale index is constitutive, not parametric.
  3. Planted mutant M1: assert the pole number IS "the intrinsic mass" and the
     MS-bar number is "a correction" — REJECTED: both are equally valid
     definitions, and the "correction" framing is scheme-conventional.

Map preserves: the size ordering (definitional spread >> exp. precision);
the sign and monotonicity of mu-dependence.
Outside the check: renormalon ambiguity of the pole mass (would strengthen the
point; disclosed, not computed); electroweak effects; full 4-loop running.
"""
import math

# ---- provenance: cited-paper inputs ----
ALPHA_S_MZ = 0.1180
C1 = 4.0 / 3.0
N_L = 5
C2 = 13.4434 - 1.0414 * N_L
GAMMA0 = 8.0

def beta0(nf):
    return 11.0 - 2.0 * nf / 3.0

def pole_from_msbar(m_ms, a_s, loops=2):
    """m_pole = m_MSbar * [1 + c1*(a/pi) + c2*(a/pi)^2 + ...]."""
    x = a_s / math.pi
    k = 1.0 + C1 * x
    if loops >= 2:
        k += C2 * x * x
    return m_ms * k

def run_alphas(mu, mu0=91.1876, a0=ALPHA_S_MZ, nf=5):
    """One-loop alpha_s running (declared approximation)."""
    b0 = beta0(nf)
    return a0 / (1.0 + b0 * a0 / (2.0 * math.pi) * math.log(mu / mu0))

def run_mmsbar(mu, mu0, m0, nf=5):
    """One-loop MS-bar mass running (declared approximation)."""
    a_mu = run_alphas(mu, nf=nf)
    a_0 = run_alphas(mu0, nf=nf)
    return m0 * (a_mu / a_0) ** (GAMMA0 / (2.0 * beta0(nf)))

def main():
    print("P.8 — mass scheme/scale exhibit")
    # Representative MS-bar top mass (scale of order m_t); alpha_s run to ~m_t.
    m_ms_mt = 163.0  # GeV, representative MS-bar mass
    a_mt = run_alphas(163.0)
    m_pole_1 = pole_from_msbar(m_ms_mt, a_mt, loops=1)
    m_pole_2 = pole_from_msbar(m_ms_mt, a_mt, loops=2)
    spread_1 = m_pole_1 - m_ms_mt
    spread_2 = m_pole_2 - m_ms_mt
    print(f"  m_MSbar(m_t) = {m_ms_mt:.2f} GeV")
    print(f"  m_pole (1-loop) = {m_pole_1:.2f} GeV  (spread {spread_1:+.2f})")
    print(f"  m_pole (2-loop) = {m_pole_2:.2f} GeV  (spread {spread_2:+.2f})")
    exp_prec = 0.3  # GeV, representative experimental precision on m_t
    assert spread_1 > 10 * exp_prec, "definitional spread unexpectedly small"
    print(f"  Definitional spread ({spread_1:.1f} GeV) >> experimental precision "
          f"({exp_prec} GeV): 'the' mass is definition-dependent.")

    # Scale dependence of the MS-bar mass itself (bottom quark illustration).
    m_b_mb = 4.18
    m_b_mz = run_mmsbar(91.1876, 4.18, m_b_mb, nf=5)
    print(f"  m_b(m_b) = {m_b_mb:.3f} GeV; m_b(M_Z) = {m_b_mz:.3f} GeV")
    assert m_b_mz < m_b_mb, "mass should decrease with scale (QCD)"
    assert abs(m_b_mb - m_b_mz) > 1.0, "scale shift unexpectedly small"
    print("  The MS-bar 'mass' moves with mu: the scale index is constitutive.")

    # Mutant M1: the pole number is THE intrinsic mass; MS-bar is "a correction".
    # Witness: the framing is reversible with equal validity — call MS-bar
    # "the" mass and the pole shift becomes "the correction". Neither choice is
    # licensed by the formalism; the formalism supplies a relation, not a ranking.
    rel = (m_pole_2 - m_ms_mt) / m_ms_mt
    print(f"  MUTANT M1 ('intrinsic' = pole): relative 'correction' = {rel:.3f}")
    assert rel > 0.03, "mutant unexpectedly close"
    print("  M1 REJECTED: witness = the pole<->MSbar relation is symmetric; "
          "'correction' is a scheme-conventional label, not a physical ranking. "
          "The renormalon ambiguity (disclosed, not computed) makes the pole "
          "mass itself definition-limited at O(Lambda_QCD).")

    print("P.8 GREEN: mass is the hardest case and it still fails — no unique "
          "encounter-free number exists across definitions or scales.")

if __name__ == "__main__":
    main()
