#!/usr/bin/env python3
"""G.2 — Contrast table completeness verifier for Paper 11.5.

Checks: every Standard Model intrinsic-property claim in the §4 contrast table
is mapped to exactly one Paper 11 result and carries exactly one verdict.
No orphan claims, no orphan results, no missing verdicts.
A count assertion (v24) requires that the loose row pattern (any "| N |" row)
and the strict 7-cell row regex find the same number of rows — the checks
below run over the strict set, and a shape drift between the two would
silently truncate the checked set, so a mismatch fails the run.
Draft resolution (v19 fallback chain): argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft file is printed on every run.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


# Portable draft resolution (v14 hardening; v19 fallback chain):
# argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
# newest paper_11_5_v<N>.md. $PAPER_MD at a nonexistent file falls through;
# argv[1] is honored verbatim (unchanged pre-v19 behavior, including
# fail-on-nonexistent input). The helper is inlined: scripts stay
# standalone, no shared imports.
DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()

# Extract the §4 contrast table rows
table_start = text.find("## 4 &nbsp; SHARP CONTRAST")
table_end = text.find("## 5 &nbsp;", table_start)
section = text[table_start:table_end]

rows = re.findall(r"^\| (\d+) \|", section, re.M)
strict_rows = re.findall(
    r"^\| (\d+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|",
    section, re.M)
print(f"Draft: {DRAFT}")
print(f"Contrast table rows: {len(rows)} (loose pattern)")
print(f"Strict 7-cell rows parsed: {len(strict_rows)}")
# v24 (F-29): a row counted by the loose pattern must parse under the strict
# pattern — otherwise the completeness claims below would be made over a
# silently truncated row set.
if len(strict_rows) != len(rows):
    print(f"G.2 FAIL: {len(rows)} rows found by loose pattern but only "
          f"{len(strict_rows)} parsed by the strict 7-cell regex — "
          "row-shape drift; completeness checks not run.")
    sys.exit(1)

# Each row must have 5 cells: #, Phenomenon, Standard derived, Standard inferred, P11 derived, Verdict
# (v2 table has 6 columns)
issues = []
for num, phenom, std_der, std_inf, p11, verdict in strict_rows:
    if not phenom.strip():
        issues.append(f"Row {num}: empty phenomenon")
    if not std_der.strip():
        issues.append(f"Row {num}: empty standard-derived")
    if not std_inf.strip():
        issues.append(f"Row {num}: empty standard-inferred")
    if not p11.strip():
        issues.append(f"Row {num}: empty P11 result")
    # Verdict must start with a bold controlled term
    vm = re.search(r"\*\*(.+?)\.\*\*", verdict)
    if not vm:
        issues.append(f"Row {num}: verdict lacks bold term: {verdict[:60]}...")
    else:
        term = vm.group(1).strip()
        allowed = ["Category mistake", "Intrinsic only in prose", "Reified bookkeeping",
                   "Reified arithmetic", "Self-refuting", "Untestable assertion",
                   "Precision misattributed", "Scale amnesia", "Gloss falsified"]
        if term not in allowed:
            issues.append(f"Row {num}: verdict term '{term}' not in controlled vocabulary")

# Check: every property in §3 audit appears in §4
audit_props = ["charge", "spin", "mass", "color", "flavor", "magnetic moment"]
section_lower = section.lower()
for prop in audit_props:
    if prop not in section_lower:
        issues.append(f"§3 property '{prop}' missing from §4 contrast table")

if issues:
    print("ISSUES:")
    for i in issues:
        print(f"  - {i}")
    sys.exit(1)
print("G.2 PASS: contrast table complete, all verdicts controlled, all §3 properties mapped.")
