#!/usr/bin/env python3
"""P.5 — CKM basis rotation executable for Paper 11.5.

Constructs the CKM matrix from PDG values and demonstrates that "flavor"
depends on the interaction basis. A "down quark" in the weak basis is a
superposition of mass eigenstates — the "flavor" is encounter-indexed
by which interaction is asking.

Uses PDG 2024 values: s12=0.225, s23=0.041, s13=0.0037, delta=1.14 rad.

INPUT_PROVENANCE:
  - s12, s23, s13, delta: class=cited-paper (PDG 2024, representative values).
  - Chau-Keung parametrization: class=cited-paper (the SM's own standard form).
  - "Weak basis vs mass basis" reading: class=paper-defined (the paper's
    encounter-indexing interpretation of the SM's basis structure).

CONTINUUM_USE (v24 FORTRESS — explicit disclosure, Dervis's "disclose why"):
  - WHAT: complex exponentials (the CP phase e^{-iδ}), square roots in the
    Chau-Keung parametrization, complex matrix unitarity check (V V† = I).
  - WHY NEEDED: the exhibit IS the SM's own CKM matrix — a complex unitary
    matrix built from measured real mixing angles and a physical phase. The
    paper's claim is "the CKM matrix IS the encounter-indexing, written in the
    Lagrangian": exhibiting that requires the SM's object as the SM states it.
    The PDG inputs are measured reals; the phase is irreducibly complex. The
    continuum is not scaffolding around the exhibit; it is the exhibit.
  - WHAT WOULD BE LOST INTEGER-NATIVE: the exhibited object itself. A
    rational toy matrix would demonstrate *a* basis-dependence, but no longer
    the CKM matrix — and the paper's point is what the SM's own formalism
    says about flavor. The unitarity check (VV† = I over ℂ) has no
    integer-native form that remains the CKM matrix.
"""
import numpy as np
import sys


def ckm_matrix(s12=0.225, s23=0.041, s13=0.0037, delta=1.14):
    """Standard parametrization (Chau-Keung)."""
    c12 = np.sqrt(1 - s12**2)
    c23 = np.sqrt(1 - s23**2)
    c13 = np.sqrt(1 - s13**2)
    V = np.array([
        [c12*c13, s12*c13, s13*np.exp(-1j*delta)],
        [-s12*c23 - c12*s23*s13*np.exp(1j*delta), c12*c23 - s12*s23*s13*np.exp(1j*delta), s23*c13],
        [s12*s23 - c12*c23*s13*np.exp(1j*delta), -c12*s23 - s12*c23*s13*np.exp(1j*delta), c23*c13],
    ])
    return V


def main():
    print("=" * 70)
    print("P.5 — CKM BASIS ROTATION EXECUTABLE")
    print("=" * 70)

    V = ckm_matrix()
    print("\nCKM matrix (magnitudes):")
    print(np.abs(V).round(4))
    print("\nUnitarity check (V V^dagger = I):")
    print(np.abs(V @ V.conj().T).round(6))

    # The weak "down" quark: what the W boson couples to
    # |d'_weak> = V_ud|d> + V_us|s> + V_ub|b>
    d_weak = V[0, :]  # first row: couplings of u to (d,s,b)
    print("\nThe W boson couples the u quark to:")
    print(f"  |d'_weak> = {V[0,0]:.4f}|d> + {V[0,1]:.4f}|s> + {V[0,2]:.4f}|b>")
    print(f"  (showing magnitudes: {np.abs(V[0,0]):.4f}, {np.abs(V[0,1]):.4f}, {np.abs(V[0,2]):.4f})")

    print("\n" + "-" * 70)
    print("INTERPRETATION")
    print("-" * 70)
    print("Ask the strong interaction: 'what flavor is this quark?'")
    print("  Answer: 'down' (mass eigenstate |d>).")
    print("Ask the weak interaction: 'what flavor is this quark?'")
    print("  Answer: a superposition V_ud|d> + V_us|s> + V_ub|b>.")
    print("\nThe 'flavor' depends on which interaction is asking.")
    print("It is not a label on the quark; it is a label on the")
    print("quark-interaction pair. Change the interaction, change the flavor.")
    print("\nK0 oscillations make this temporal: a 'strange' quark produced")
    print("in a strong encounter becomes a different superposition by the")
    print("time it decays weakly. An 'intrinsic' property does not do this.")
    print("\nP.5 VERDICT: flavor is encounter-indexed by construction.")
    print("  The CKM matrix IS the encounter-indexing, written in the Lagrangian.")

    # Verify unitarity
    assert np.allclose(V @ V.conj().T, np.eye(3), atol=1e-10)
    return 0


if __name__ == "__main__":
    sys.exit(main())
