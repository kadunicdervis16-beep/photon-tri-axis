#!/usr/bin/env python3
"""G.3 — No-strawman audit for Paper 11.5.

Checks: every Standard Model position critiqued in §3 is attributed to an actual
source (textbook/paper). The audit fails if a critiqued claim has no citation —
that would be attacking a position nobody holds.
Scoping (v24): the attribution search covers ONLY the (a) textbook-statement
block (the claim plus its Textual evidence), not the whole subsection body.
Searching (b)–(d) would let a subsection pass on a name that appears only in
the paper's own rebuttal voice (e.g. a cited refutation), which is not an
attribution of the SM position being critiqued.
Draft resolution (v19 fallback chain): argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft file is printed on every run.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


# Portable draft resolution (v14 hardening; v19 fallback chain):
# argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
# newest paper_11_5_v<N>.md. $PAPER_MD at a nonexistent file falls through;
# argv[1] is honored verbatim (unchanged pre-v19 behavior, including
# fail-on-nonexistent input). The helper is inlined: scripts stay
# standalone, no shared imports.
DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()

# Extract §3 (the audit section)
s3_start = text.find("## 3 &nbsp; THE AUDIT")
s3_end = text.find("## 4 &nbsp;", s3_start)
s3 = text[s3_start:s3_end]

# Each property subsection (3.1–3.6) must contain at least one citation-like reference
# (author name, book title, or paper reference) in its (a) textbook-statement part.
subsections = re.findall(r"### 3\.(\d) ([^\n]+)\n(.*?)(?=\n### 3\.|\n---\n## 4 |\Z)",
                         s3, re.S)

print(f"Draft: {DRAFT}")
print(f"Audit subsections found: {len(subsections)}")
issues = []
for num, title, body in subsections:
    # v24 scoping: attribution is searched ONLY in the (a) textbook-statement
    # block — from "**(a)**" to the "(b) Equation breakdown" marker — not the
    # whole subsection body. Textual evidence is part of the (a) block.
    a_start = body.find("**(a)**")
    b_start = body.find("**(b)", a_start)
    a_block = body[a_start:b_start] if a_start != -1 and b_start != -1 else body
    # Look for attribution: capitalized name, italic book title, or (Author, year)
    has_attribution = bool(re.search(
        r"(Griffiths|Peskin|Schroeder|Halzen|Martin|Thomson|Cahn|Gilman|PDG|"
        r"\([A-Z][a-z]+,? \d{4}\)|\*[A-Z][^*]{5,}\*)", a_block))
    if not has_attribution:
        issues.append(f"§3.{num} ({title.strip()}): no source attribution for the SM position")

if issues:
    print("ISSUES:")
    for i in issues:
        print(f"  - {i}")
    sys.exit(1)
print("G.3 PASS: every critiqued SM position is attributed to a real source.")
