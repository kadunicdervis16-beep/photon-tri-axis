#!/usr/bin/env python3
"""H.4 — Honesty Comparison for Paper 11.5 (v24 FORTRESS rebuild).

Scores Paper 11's native ledger against the Standard Model's "intrinsic"
prose gloss on seven honesty criteria C1-C7. This rebuild answers Dervis's
v24 must: no hardcoded scorecard verdicts. Every scored cell is COMPUTED at
run time against the draft text supplied on the command line (argv[1]); no
draft content is hardcoded and no author dict literal carries a verdict.

CELL KINDS (printed beside every verdict):
  COMPUTED        — a predicate evaluated against the input draft text.
                    The script prints the predicate and the evidence locator
                    (draft line numbers), so a reader can re-run the check.
                    What the machine establishes is ANCHOR PRESENCE: that the
                    draft carries the compliance machinery the criterion
                    names (declared-assumption labels, null-result anchors,
                    badge tokens, falsification statements, the Stage N/P
                    boundary declaration, encounter-indexing language).
                    Anchor presence is not semantic adequacy: whether the
                    labels are correctly applied, the falsification
                    conditions adequate, or the boundary real is author
                    judgment, stated as such in each cell's note.
  INHERITED       — a verdict re-computed at THIS execution from a sibling
                    script's output, not copied from prose. C1/C4-SM re-run
                    H.1's badge rule (audit_sm) over H.1's claim table;
                    C2-SM re-runs the rebuilt H.3 (verdict-layer consistency)
                    and inherits the consistently-RECORDED author verdict
                    (FAIL) iff H.3 reports CONSISTENT — inheriting a
                    bookkeeping-consistency result, not a proof the verdict
                    is correct. Each inherited cell carries the sibling's
                    own disclosed limit: H.1's DERIVED/DECLARED/SMUGGLED
                    mechanism labels are H.1's author classification (H.4
                    computes the F.49 badge rule over them; it does not
                    re-derive the labels); the rebuilt H.3 proves the
                    paper's verdict layers agree, not that the verdicts are
                    correct or that any prose overreaches any equation
                    (TEAM H.3 owns H.3's checks).
  HUMAN-JUDGMENT  — no machine predicate exists for this cell. The script
                    does NOT compute a fake pass: it locates the paper's own
                    stated verdict (the **PASS**/**FAIL** bold markers in the
                    §8.5 table row) and reports it, labeled as the author's
                    judgment, with the row's line number as the locator.
                    If the row or its markers are absent the cell is
                    UNVERIFIABLE (fail closed), never guessed.

WHAT THIS ANSWERS (§8.5's question): "If the SM's intrinsic-property claims
were held to Paper 11's declared epistemic standards, what does the
comparison show — stated only as far as the machine can check?" The honest
answer is now two-part: (a) on the machine-evaluated cells, Paper 11's draft
carries the named compliance anchors on 6/6 criteria while the SM gloss
earns 0/3; (b) five cells (C2-Paper-11; C3/C5/C6/C7-SM) remain author
judgment, reported as such. The old "7/7 vs. 0/7" headline is RETIRED: it
counted author-typed verdicts as machine results. The new headline counts
only what the machine evaluated and labels the rest — it is weaker, and
honest about being weaker.

INPUT_PROVENANCE (per Paper 11 V17/P2 staple):
  - Criterion-to-anchor predicate mappings (C1..C7, Paper-11 side):
    class=declared-assumption (the author's design choice of which text
    anchors count as the compliance machinery for each criterion; the
    thresholds — >=1 hit, >=2 hits, +-3 lines — are the author's chosen
    strictness, declared here, not derived).
  - H.1 claim table + DERIVED/DECLARED/SMUGGLED mechanism labels:
    class=declared-assumption (H.1's author classification, consumed as
    data; H.4 re-computes the F.49 badge rule over it at run time).
  - H.3 subprocess output (the "H.3 RESULT: ..." line):
    class=control (sibling script H3_prose_equation_consistency.py — the v24
    verdict-layer consistency rebuild — run at H.4's execution on the same
    draft; TEAM H.3 owns H.3's checks. H.4 consumes only CONSISTENT vs
    INCONSISTENT and inherits the consistently-recorded FAIL verdict; it
    inherits no prose/equation verdict from H.3, which no longer computes one).
  - §8.5 table-row **PASS**/**FAIL** bold markers (HUMAN-JUDGMENT cells):
    class=paper-defined (the paper's own stated verdicts, parsed from the
    input draft text at run time).
  - No arbitrary-representative inputs; no cited-paper constants.

What is verified: (1) every verdict string in the output was produced by an
evaluator function at run time — the module contains no verdict-carrying
dict literals (the --self-test asserts this structurally: any cell without
the evaluator stamp, or with an empty/unresolvable evidence locator, fails
the run); (2) each COMPUTED cell's predicate and evidence locator are
printed, re-runnable by the reader; (3) each INHERITED cell names the
sibling run it was computed from; (4) each HUMAN-JUDGMENT cell points at
the draft line carrying the author's stated verdict.

What stays outside the machine check: semantic adequacy of the anchors
(whether declared assumptions are well-declared, falsification conditions
adequate, the Stage N/P boundary real); H.1's mechanism labels; H.3's
prose/equation link; all HUMAN-JUDGMENT cells' content; whether the seven
criteria are the right criteria (the stacked-deck framing, §8.5 prose).

Exit 0 on success. Usage: H4_honesty_comparison.py <draft-text-path>
[--self-test]
"""
import importlib
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
H1_MODULE = "H1_sm_badge_audit"
H3_NAME = "H3_prose_equation_consistency.py"


def sibling_paths(draft_path):
    """Sibling scripts live beside the draft (paper_11_5_draft/scripts/);
    fall back to H.4's own directory for standalone testing. Resolved at
    run time from the draft argument — never hardcoded."""
    beside = Path(draft_path).parent / "scripts"
    if (beside / H3_NAME).is_file():
        return beside
    return HERE

COMPUTED = "COMPUTED"
INHERITED = "INHERITED"
JUDGMENT = "HUMAN-JUDGMENT"

# Evaluator stamp: make_cell is the ONLY constructor that sets it.
# A hand-built cell dict (a reintroduced baked verdict) lacks the stamp and
# is rejected by validate_cells. This is the anti-regression mechanism.
_EVAL_STAMP = object()

VERDICT_OK = {"PASS", "FAIL", "UNVERIFIABLE"}


def make_cell(criterion, side, kind, verdict, evidence, predicate):
    """Sole cell constructor. Verdicts exist only as its return values."""
    if kind not in (COMPUTED, INHERITED, JUDGMENT):
        raise ValueError(f"unknown cell kind: {kind!r}")
    if not (verdict in VERDICT_OK or verdict.startswith("PARTIAL")):
        raise ValueError(f"unknown verdict: {verdict!r}")
    return {
        "criterion": criterion,
        "side": side,
        "kind": kind,
        "verdict": verdict,
        "evidence": evidence,
        "predicate": predicate,
        "_eval": _EVAL_STAMP,
    }


def validate_cells(cells, n_lines):
    """Fail closed. Returns (ok, problems)."""
    problems = []
    for c in cells:
        tag = f"{c.get('criterion')}/{c.get('side')}"
        if c.get("_eval") is not _EVAL_STAMP:
            problems.append(
                f"{tag}: no evaluator stamp — baked verdict rejected")
            continue
        if c.get("kind") not in (COMPUTED, INHERITED, JUDGMENT):
            problems.append(f"{tag}: unknown kind {c.get('kind')!r}")
        v = c.get("verdict", "")
        if not (v in VERDICT_OK or v.startswith("PARTIAL")):
            problems.append(f"{tag}: unknown verdict {v!r}")
        ev = c.get("evidence") or ""
        if not ev.strip():
            problems.append(f"{tag}: empty evidence locator")
        for m in re.finditer(r"L(\d+)", ev):
            ln = int(m.group(1))
            if not 1 <= ln <= n_lines:
                problems.append(
                    f"{tag}: evidence line L{ln} outside draft (1..{n_lines})")
    return (not problems), problems


# ---------------------------------------------------------------- draft I/O

def load_draft(path):
    p = Path(path)
    if not p.is_file():
        print(f"H.4: draft not found: {p}", file=sys.stderr)
        sys.exit(2)
    return p, p.read_text(encoding="utf-8").splitlines()


def find_lines(lines, pattern, flags=0):
    rx = re.compile(pattern, flags)
    return [i + 1 for i, l in enumerate(lines) if rx.search(l)]


def evidence_str(hits, label, max_show=3):
    shown = ", ".join(f"L{n}" for n in hits[:max_show])
    more = f" (+{len(hits) - max_show} more)" if len(hits) > max_show else ""
    return f"{label}: {len(hits)} hit(s) at {shown}{more}"


# ------------------------------------------------- Paper-11 side: COMPUTED

def eval_c1_p11(lines):
    ip = find_lines(lines, r"INPUT_PROVENANCE")
    da = find_lines(lines, r"declared assumption", re.IGNORECASE)
    verdict = "PASS" if (ip and da) else "FAIL"
    evidence = (evidence_str(ip, "INPUT_PROVENANCE") + "; "
                + evidence_str(da, "'declared assumption'"))
    return verdict, evidence


def eval_c3_p11(lines):
    f57 = set(find_lines(lines, r"\bF\.57\b"))
    null = set(find_lines(lines, r"\bnull\b", re.IGNORECASE))
    near = sorted(n for n in f57 if any(abs(n - m) <= 3 for m in null))
    verdict = "PASS" if near else "FAIL"
    if near:
        loc = ", ".join(f"L{n}" for n in near[:3])
        evidence = f"F.57 within 3 lines of 'null' at {loc}"
    else:
        evidence = "check ran: no F.57/null-result anchor found in draft"
    return verdict, evidence


def eval_c4_p11(lines):
    la = find_lines(lines, r"\[LEVEL A")
    lb = find_lines(lines, r"\[LEVEL B")
    lc = find_lines(lines, r"\[LEVEL C")
    f38 = find_lines(lines, r"\bF\.38\b")
    verdict = "PASS" if (la and lb and lc and f38) else "FAIL"
    evidence = (f"[LEVEL A]x{len(la)} [LEVEL B]x{len(lb)} "
                f"[LEVEL C]x{len(lc)} F.38x{len(f38)}; "
                + evidence_str(la, "first [LEVEL A]"))
    return verdict, evidence


def eval_c5_p11(lines):
    fc = find_lines(lines, r"falsification condition", re.IGNORECASE)
    verdict = "PASS" if len(fc) >= 2 else "FAIL"
    evidence = evidence_str(fc, "'falsification condition'")
    return verdict, evidence


def eval_c6_p11(lines):
    sn = find_lines(lines, r"\bStage N\b")
    sp = find_lines(lines, r"\bStage P\b")
    f42 = find_lines(lines, r"\bF\.42\b")
    verdict = "PASS" if (sn and sp and f42) else "FAIL"
    evidence = (f"Stage N x{len(sn)}, Stage P x{len(sp)}, F.42 x{len(f42)}; "
                + evidence_str(sn, "first Stage N"))
    return verdict, evidence


def eval_c7_p11(lines):
    ei = find_lines(lines, r"encounter-index", re.IGNORECASE)
    verdict = "PASS" if ei else "FAIL"
    evidence = evidence_str(ei, "'encounter-index'")
    return verdict, evidence


# ------------------------------------------------- SM side: INHERITED (H.1)

def import_h1(scripts_dir):
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    return importlib.import_module(H1_MODULE)


def h1_badge_counts(claims, audit_fn):
    """Re-compute the F.49 badge rule over H.1's claim table at run time."""
    badged = 0
    for claim in claims:
        badge, _ = audit_fn(claim)
        if not badge.startswith("NO BADGE"):
            badged += 1
    return badged, len(claims) - badged


def eval_sm_h1(scripts_dir):
    """Run H.1's badge rule now; return (badged, total, evidence)."""
    h1 = import_h1(scripts_dir)
    badged, no_badge = h1_badge_counts(h1.CLAIMS, h1.audit_sm)
    total = len(h1.CLAIMS)
    evidence = (
        f"H.1 badge rule re-run this execution over {total} claims: "
        f"{no_badge}/{total} NO BADGE, {badged}/{total} badged. "
        f"Mechanism labels (DERIVED/DECLARED/SMUGGLED) are H.1's author "
        f"classification; H.4 computed the F.49 rule over them, it did not "
        f"re-derive the labels.")
    return badged, no_badge, total, evidence


# ------------------------------------------------- SM side: INHERITED (H.3)

def run_h3(draft_path, scripts_dir):
    """Re-run the rebuilt H.3 (verdict-layer consistency) on the same draft.

    The v24 H.3 is NOT a prose/equation check: it proves the paper's
    tabulated verdict layers agree with each other (7/7 record cells match
    across §8.1/§8.2/§8.3/§8.4/§8.5-C2/§3.x). It does NOT prove the verdicts
    correct, H.2's chains valid, or any prose/equation overreach — the
    mismatch claim remains the author's classification (§8.4). TEAM H.3 owns
    H.3's checks; H.4 consumes only the CONSISTENT/INCONSISTENT result and
    inherits no prose/equation verdict from it.

    Returns (True, evidence) on CONSISTENT, (False, evidence) on
    INCONSISTENT, (None, evidence) when the result line is missing
    (fail closed)."""
    h3_file = scripts_dir / H3_NAME
    if not h3_file.is_file():
        return None, f"H.3 script not found in {scripts_dir}"
    r = subprocess.run([sys.executable, str(h3_file), str(draft_path)],
                       capture_output=True, text=True)
    out = r.stdout
    if re.search(r"H\.3 RESULT:\s*CONSISTENT", out):
        evidence = (
            "H.3 (verdict-layer consistency) re-run this execution: CONSISTENT — "
            "7/7 record cells match across §8.1, §8.2, §8.3, §8.4, §8.5-C2, and "
            "the §3.x verdict sentences; Check D confirms the §8.5 C2 row carries "
            "the author's FAIL verdict citing H.2. What H.3 proves: the paper's "
            "tabulated verdict layers agree. What it does NOT prove: that the "
            "verdicts are correct, or that any prose overreaches any equation — "
            "the mismatch claim remains the author's classification (§8.4).")
        return True, evidence
    m = re.search(r"H\.3 RESULT:\s*(\d+)\s+INCONSISTENCY", out)
    if m or r.returncode != 0:
        n = m.group(1) if m else "?"
        evidence = (
            f"H.3 re-run this execution: INCONSISTENT ({n} inconsistencies) — "
            f"the verdict layers disagree, so no consistently-recorded C2 verdict "
            f"exists to inherit. Failing closed.")
        return False, evidence
    return None, "H.3 output lacked an 'H.3 RESULT:' line — refusing to guess"


# ------------------------------------------------- HUMAN-JUDGMENT cells

def eval_judgment(lines, crit, side_idx):
    """No machine predicate exists: report the paper's own stated verdict,
    parsed from the §8.5 table row's **PASS**/**FAIL** markers."""
    rows = [(i + 1, l) for i, l in enumerate(lines)
            if re.match(r"\|\s*" + re.escape(crit) + r"\s*:", l.lstrip())
            and "**" in l]
    if not rows:
        return ("UNVERIFIABLE",
                f"check ran: no **-marked {crit} table row found — "
                f"author's stated judgment absent",
                f"locate the {crit} row in §8.5 and state the verdict")
    ln, row = rows[0]
    # Column layout is version-tolerant: the v23 table is
    # | Cn: label | P11 | SM |, the v24 table adds a Kind column
    # | Cn: label | Kind | P11 | SM |. The Kind column carries no
    # **PASS**/**FAIL** markers, so sides are the non-kind columns.
    cols = [p.strip() for p in row.split("|")[1:-1]]
    rest = cols[1:]  # drop the criterion-label column
    if (len(rest) >= 3
            and re.search(r"COMPUTED|INHERITED|HUMAN-JUDGMENT", rest[0])):
        rest = rest[1:]  # drop the Kind column
    if len(rest) < 2:
        return ("UNVERIFIABLE",
                f"L{ln}: {crit} row lacks two side columns",
                "repair the §8.5 table row")
    cell_text = rest[side_idx]
    m = re.search(r"\*\*(PASS|FAIL)\*\*", cell_text)
    if not m:
        return ("UNVERIFIABLE",
                f"L{ln}: {crit} row side lacks a **PASS**/**FAIL** marker",
                "author must state the judgment in the row")
    verdict = m.group(1)
    reason = re.sub(r"\*\*(PASS|FAIL)\*\*\s*—?\s*", "", cell_text).strip()
    # The note already labels this the author's stated reason; drop a
    # redundant in-row "author's judgment/assessment:" prefix if present.
    reason = re.sub(r"^author's (judgment|assessment):\s*", "", reason,
                    flags=re.IGNORECASE)
    if len(reason) > 220:
        reason = reason[:217] + "..."
    evidence = f"L{ln}: author's stated verdict parsed from the §8.5 table row"
    return verdict, evidence, f"author's stated reason: {reason}"


# ---------------------------------------------------------------- assembly

P11_SIDE = "Paper 11"
SM_SIDE = "SM gloss"

P11_EVALUATORS = {
    "C1": (eval_c1_p11,
           "draft carries INPUT_PROVENANCE blocks and 'declared assumption' labels"),
    "C3": (eval_c3_p11,
           "draft publishes an F.57-tradition null result (F.57 within 3 lines of 'null')"),
    "C4": (eval_c4_p11,
           "draft carries [LEVEL A/B/C] badge tokens and the F.38 registry anchor "
           "(the '[LEVEL A' prefix count includes the formalized "
           "[LEVEL A, author-authorized] subtype form)"),
    "C5": (eval_c5_p11,
           "draft states falsification conditions (>=2 'falsification condition' hits)"),
    "C6": (eval_c6_p11,
           "draft declares the Stage N / Stage P boundary (Stage N, Stage P, F.42 anchors)"),
    "C7": (eval_c7_p11,
           "draft claims encounter-indexing ('encounter-index' language present)"),
}

# Cells with no machine predicate: (criterion, side, side_idx_in_row)
JUDGMENT_CELLS = [
    ("C2", P11_SIDE, 0,
     "no machine check of Paper-11 prose/equation alignment exists; "
     "the old scorecard already recorded this as the author's assessment"),
    ("C3", SM_SIDE, 1,
     "whether textbooks acknowledge H.2's failed derivation is a literature "
     "claim, not checkable from this draft"),
    ("C5", SM_SIDE, 1,
     "whether any textbook states a falsification condition for the "
     "intrinsic-possession gloss is a literature claim, not checkable here"),
    ("C6", SM_SIDE, 1,
     "whether the SM gloss reifies bookkeeping is a characterization of "
     "textbook prose, argued in §3/§8.5, not machine-checkable"),
    ("C7", SM_SIDE, 1,
     "the EFT-trap argument is philosophical/argumentative, not "
     "machine-checkable"),
]


def evaluate(draft_path):
    """Run every cell evaluator. Returns (cells, n_lines)."""
    _, lines = load_draft(draft_path)
    n_lines = len(lines)
    scripts_dir = sibling_paths(draft_path)
    cells = []

    for crit, (fn, pred) in P11_EVALUATORS.items():
        verdict, evidence = fn(lines)
        note = ("anchor presence only — whether the machinery is correctly "
                "applied stays author judgment")
        cells.append(make_cell(crit, P11_SIDE, COMPUTED, verdict, evidence,
                               f"{pred}; {note}"))
    # C2 Paper-11: judgment (no predicate)
    verdict, evidence, note = eval_judgment(lines, "C2", 0)
    cells.append(make_cell("C2", P11_SIDE, JUDGMENT, verdict, evidence,
                           JUDGMENT_CELLS[0][3] + "; " + note))

    # SM side, inherited from H.1
    badged, no_badge, total, ev_h1 = eval_sm_h1(scripts_dir)
    v_c1 = "FAIL" if no_badge == total else f"PARTIAL ({no_badge}/{total} no-badge)"
    cells.append(make_cell("C1", SM_SIDE, INHERITED, v_c1, ev_h1,
                           "H.1's badge rule re-computed at this execution; "
                           "FAIL iff every claim is NO BADGE"))
    v_c4 = "FAIL" if badged == 0 else f"PARTIAL ({badged}/{total} badged)"
    cells.append(make_cell("C4", SM_SIDE, INHERITED, v_c4, ev_h1,
                           "same H.1 re-run; FAIL iff zero claims earn A/B/C"))

    # SM side, inherited from the rebuilt H.3 (verdict-layer consistency).
    # The inherited verdict is the consistently-RECORDED author verdict
    # (FAIL, per Check D) — not a machine proof that the verdict is correct.
    h3_ok, ev_h3 = run_h3(draft_path, scripts_dir)
    h3_pred = ("rebuilt H.3 verdict-layer consistency re-run on the input draft; "
               "verdict FAIL iff H.3 reports CONSISTENT — the consistently recorded "
               "author verdict for the SM gloss on C2 is FAIL (Check D confirms the "
               "C2 row carries FAIL citing H.2); UNVERIFIABLE iff the layers "
               "disagree, or the H.3 run itself fails")
    if h3_ok is None:
        cells.append(make_cell("C2", SM_SIDE, INHERITED, "UNVERIFIABLE", ev_h3,
                               h3_pred))
    elif h3_ok:
        cells.append(make_cell("C2", SM_SIDE, INHERITED, "FAIL", ev_h3, h3_pred))
    else:
        cells.append(make_cell("C2", SM_SIDE, INHERITED, "UNVERIFIABLE", ev_h3,
                               h3_pred))

    # SM side, judgment cells
    for crit, side, side_idx, why in JUDGMENT_CELLS[1:]:
        verdict, evidence, note = eval_judgment(lines, crit, side_idx)
        cells.append(make_cell(crit, side, JUDGMENT, verdict, evidence,
                               why + "; " + note))
    return cells, n_lines


def print_report(cells, draft_path):
    print("=" * 70)
    print("H.4 — HONESTY COMPARISON (v24 rebuild: computed, not printed)")
    print("Paper 11 native ledger vs. Standard Model 'intrinsic' gloss")
    print(f"Draft: {draft_path}")
    print("=" * 70)
    order = {"C1": 1, "C2": 2, "C3": 3, "C4": 4, "C5": 5, "C6": 6, "C7": 7}
    for c in sorted(cells, key=lambda c: (order[c["criterion"]], c["side"])):
        print(f"\n[{c['kind']}] {c['criterion']} ({c['side']}): {c['verdict']}")
        print(f"  predicate: {c['predicate']}")
        print(f"  evidence:  {c['evidence']}")
    print("\n" + "=" * 70)
    comp_p11 = [c for c in cells
                if c["side"] == P11_SIDE and c["kind"] == COMPUTED]
    inh_sm = [c for c in cells
              if c["side"] == SM_SIDE and c["kind"] == INHERITED]
    jud = [c for c in cells if c["kind"] == JUDGMENT]
    p11_pass = sum(1 for c in comp_p11 if c["verdict"] == "PASS")
    sm_pass = sum(1 for c in inh_sm if c["verdict"] == "PASS")
    print("TALLY (machine-evaluated cells only):")
    print(f"  Paper 11 COMPUTED: {p11_pass}/{len(comp_p11)} PASS")
    print(f"  SM gloss INHERITED: {sm_pass}/{len(inh_sm)} PASS")
    print("HUMAN-JUDGMENT cells (author's stated verdicts, not machine findings):")
    for c in sorted(jud, key=lambda c: (order[c["criterion"]], c["side"])):
        print(f"  {c['criterion']} ({c['side']}): {c['verdict']} — {c['evidence']}")
    print("=" * 70)
    print("The old '7/7 vs. 0/7' headline is retired: it counted author-typed")
    print("verdicts as machine results. What the machine evaluated is above;")
    print("the rest is labeled judgment. See the docstring for what stays")
    print("outside the check.")


def self_test(draft_path):
    """Structural anti-regression test: no baked verdict can pass."""
    print("H.4 --self-test: structural anti-regression checks")
    cells, n_lines = evaluate(draft_path)
    failures = []

    ok, problems = validate_cells(cells, n_lines)
    print(f"  [1] live cells validate: {'PASS' if ok else 'FAIL'}")
    if not ok:
        failures += problems

    # Mutant A: a reintroduced baked verdict (hand-built dict, no stamp).
    baked = {"criterion": "C1", "side": P11_SIDE, "kind": COMPUTED,
             "verdict": "PASS", "evidence": "L1",
             "predicate": "smuggled verdict"}
    ok_b, _ = validate_cells([baked], n_lines)
    print(f"  [2] baked-verdict mutant rejected: "
          f"{'PASS' if not ok_b else 'FAIL'}")
    if ok_b:
        failures.append("baked-verdict mutant was NOT rejected")

    # Mutant B: verdict without an evidence locator.
    no_ev = make_cell("C9", P11_SIDE, COMPUTED, "PASS", "",
                      "no locator")
    ok_e, _ = validate_cells([no_ev], n_lines)
    print(f"  [3] missing-locator mutant rejected: "
          f"{'PASS' if not ok_e else 'FAIL'}")
    if ok_e:
        failures.append("missing-locator mutant was NOT rejected")

    # Mutant C: evidence locator pointing outside the draft.
    bad_ln = make_cell("C9", P11_SIDE, COMPUTED, "PASS",
                       f"L{n_lines + 5000}", "dangling locator")
    ok_l, _ = validate_cells([bad_ln], n_lines)
    print(f"  [4] dangling-locator mutant rejected: "
          f"{'PASS' if not ok_l else 'FAIL'}")
    if ok_l:
        failures.append("dangling-locator mutant was NOT rejected")

    if failures:
        print("SELF-TEST FAILED:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("SELF-TEST: all structural checks passed.")
    return 0


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print("usage: H4_honesty_comparison.py <draft-text-path> [--self-test]",
              file=sys.stderr)
        return 2
    draft_path = argv[1]
    if "--self-test" in argv[2:]:
        return self_test(draft_path)
    cells, n_lines = evaluate(draft_path)
    ok, problems = validate_cells(cells, n_lines)
    if not ok:
        print("H.4 VALIDATION FAILED (fail closed):", file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        return 1
    print_report(cells, draft_path)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
