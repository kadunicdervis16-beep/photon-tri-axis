#!/usr/bin/env python3
"""H.3 — Verdict-Layer Consistency Check for Paper 11.5.

WHAT THIS VERIFIES — exactly. The paper states per-property derivation verdicts
in several places: the H.2 derivation-attempt records (authored chains, §8.2),
the §8.2 summary table, the line-anchored **Verdict (a)/(b)** lines of §8.3,
the §8.4 alignment table, the C2 row of §8.5's honesty table, the §8.1 spin
row's split citations, and sentences of the syntactic form "H.2's verdict for X
is Y" in §3.x. This script proves those layers AGREE WITH EACH OTHER: every
parsed verdict is compared, cell by cell, against the extraction map of H.2's
records embedded below. It is a machine-enforced transcription invariant:

  - every REFUTED claim has a REFUTED record cell,
  - no layer asserts DERIVED where the record says GAP (or REFUTED),
  - no chain is dropped (every map cell has a row in §8.2 and §8.4),
  - no unmapped row appears (no silent extra claims),
  - no property is misattributed (verdicts stay on their property x chain),
  - the §8.3 spin split is not collapsed anywhere (both sub-verdicts cited),
  - each record cell's bottoming-out witness phrase is anchored in the §8.2
    table's own witness column (the map is tied to the paper's record text,
    not floating free of it).

The checks operate on PARSED DOCUMENT STRUCTURE — markdown table rows under a
located section heading, line-anchored verdict lines, a syntactic sentence
pattern — never on whole-document substring presence. A verdict token counts
only when it appears in the structural slot the paper assigns to verdicts
(the verdict cell of a table row, a **Verdict (x):** line, the verdict slot of
a "verdict for" sentence). The same token elsewhere (e.g. §8.3's prose
discussing the old single label) is not a verdict claim and is ignored.

WHAT THIS DOES NOT VERIFY — stated plainly, no overdescription.

  1. Whether H.2's chains are GOOD derivations. The chains are authored prose
     records; the verdict cells (GAP/REFUTED) are the author's classifications.
     The machine checks that the paper repeats them faithfully, not that they
     are true. (Classified column, §0.5.5: the machine checks the bookkeeping,
     not the judgment.)
  2. Whether any prose OVERREACHES any equation. The v23 marker scan's claim is
     dropped, not repaired: no per-property prose/equation linkage is computed
     here. The paper's prose/equation mismatch claim remains the author's
     classification, stated as such in §8.4.
  3. Anything about Paper 11's own prose or equations. Only the SM-gloss
     verdict layers listed above are checked.
  4. The extraction map itself is DECLARED INPUT (see INPUT_PROVENANCE), not a
     derived result. Check G validates the map's SHAPE (completeness,
     vocabulary, non-empty witnesses) — a typo'd map fails loudly — but the
     verdict values are the author's and stay the author's.

INPUT_PROVENANCE
  - H.2's derivation chains (ATTEMPTS in H2_intrinsic_derivation_attempt.py):
    paper-defined. The map's seven (property x chain -> verdict) cells classify
    the author's own chains: spin splits into (a) axis-constituted -> GAP and
    (b) pre-existing-local -> REFUTED per §8.3; charge/mass/magnetic-moment ->
    GAP; color/flavor -> REFUTED per §8.2.
  - §8.2 summary table, §8.3 verdict lines, §8.4 alignment table, §8.5 C2 row,
    §8.1 spin row, §3.x "H.2's verdict for X is Y" sentences: paper-defined
    (the draft text under test; resolved by the v14/v19 fallback chain below).
  - The RECORD_MAP below: declared-assumption. The author's classification of
    H.2's chains into verdict cells, with a bottoming-out witness key-phrase per
    cell. Witnesses are key phrases (not full quotes) anchored by normalized
    containment in the §8.2 table's witness column.
  - No cited-paper, control, or arbitrary-representative inputs.

Draft resolution (v14 hardening; v19 fallback chain): argv[1] -> $PAPER_MD ->
paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft
file is printed on every run.
"""
import re
import sys
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()
lines = text.splitlines()

VERDICT_VOCAB = ("GAP", "REFUTED", "DERIVED")

# ---------------------------------------------------------------------------
# Extraction map: (property, chain) -> {verdict, witness}.
# DECLARED INPUT — the author's classification of H.2's derivation-attempt
# records. Seven cells: six properties; spin carries two chains (§8.3).
# "witness" is a key phrase from the cell's bottoming-out location, anchored
# by Check A inside the §8.2 table's own witness column.
# ---------------------------------------------------------------------------
RECORD_MAP = {
    ("spin", "axis-constituted"): {
        "verdict": "GAP",
        "witness": '"up" without n\u0302 is undefined',
    },
    ("spin", "pre-existing-local"): {
        "verdict": "REFUTED",
        "witness": "Bell's theorem (P.2); measured S=2.7 > 2",
    },
    ("charge", "scale-free"): {
        "verdict": "GAP",
        "witness": "No scale-free value exists; bare charge diverges",
    },
    ("color", "gauge-free"): {
        "verdict": "REFUTED",
        "witness": "Elitzur: no gauge-invariant colored state",
    },
    ("flavor", "basis-free"): {
        "verdict": "REFUTED",
        "witness": "K\u2070 oscillations: intrinsic flavor would forbid what occurs",
    },
    ("mass", "encounter-free"): {
        "verdict": "GAP",
        "witness": "Both derivations (kinematics, Higgs) run through encounters",
    },
    ("magnetic moment", "virtual-free"): {
        "verdict": "GAP",
        "witness": "Subtract all diagrams; remainder is undefined, not zero",
    },
}

EXPECTED_PROPS = ("spin", "charge", "color", "flavor", "mass", "magnetic moment")
PROP_ALIASES = {"mag. moment": "magnetic moment"}
# §8.3 sub-verdict markers -> the map chain they denote.
SPIN_SUBCHAINS = {"a": "axis-constituted", "b": "pre-existing-local"}


def _norm(s):
    """Normalize for comparison: NFKC, casefold, collapse whitespace."""
    return " ".join(unicodedata.normalize("NFKC", s).casefold().split())


def _canon_prop(s):
    p = _norm(s)
    return PROP_ALIASES.get(p, p)


def _verdict_in(cell):
    """Extract the verdict token from a structural cell.

    Primary shape: BOTTOMS OUT (V) — the paper's verdict-cell idiom.
    Fallback: the whole normalized cell is exactly one vocabulary token
    (used by the §8.4 alignment table's compact record cells). Both are
    whole-cell structural reads, never substring scans.
    """
    m = re.search(r"BOTTOMS OUT\s*\((GAP|REFUTED|DERIVED)\)", cell, re.I)
    if m:
        return m.group(1).upper()
    if _norm(cell) in ("gap", "refuted", "derived"):
        return _norm(cell).upper()
    return None


def _section_span(sec):
    """Return the line list of section `sec` ('8.2'): from its '### 8.2' heading
    to the next '### ' or '## ' heading. Fails loudly if the heading is absent."""
    start = None
    head_re = re.compile(r"^###\s+" + re.escape(sec) + r"\b")
    next_re = re.compile(r"^#{2,3}\s+\d")
    for i, ln in enumerate(lines):
        if head_re.match(ln):
            start = i
            break
    if start is None:
        return None
    span = []
    for ln in lines[start + 1:]:
        if next_re.match(ln):
            break
        span.append(ln)
    return span


def _table_rows(span):
    """Parse markdown table data rows from a section span. Drops the header row
    and any separator row; requires >= 3 cells per row (fails loudly if a
    table row is malformed — structure, not content, is being enforced)."""
    rows = []
    for ln in span:
        s = ln.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [c.strip() for c in s[1:-1].split("|")]
            rows.append(cells)
    data = []
    for cells in rows:
        if all(re.fullmatch(r":?-+:?", c) for c in cells):
            continue  # separator row
        data.append(cells)
    if data:
        data = data[1:]  # header row
    for cells in data:
        if len(cells) < 3:
            return None
    return data


FAILURES = []


def _fail(check, witness):
    FAILURES.append((check, witness))
    print(f"  FAIL [{check}]: {witness}")


def _ok(check, msg):
    print(f"  ok   [{check}]: {msg}")


# ---------------------------------------------------------------------------
# Check G — the extraction map's own shape (runs first; everything else
# assumes a well-formed map). Completeness: every expected property x chain
# cell is filled or the run fails — no silent gaps, no unmapped placeholders.
# ---------------------------------------------------------------------------
def check_G():
    print("\n[G] extraction-map self-check (shape, not truth)")
    props = {}
    for key, cell in RECORD_MAP.items():
        if not (isinstance(key, tuple) and len(key) == 2):
            _fail("G", f"map key {key!r} is not a (property, chain) pair")
            return
        prop, chain = key
        props.setdefault(prop, []).append(chain)
        if not isinstance(cell, dict) or "verdict" not in cell or "witness" not in cell:
            _fail("G", f"map cell {key!r} is unmapped/placeholder — no silent gaps allowed")
            return
        if cell["verdict"] not in VERDICT_VOCAB:
            _fail("G", f"map cell {key!r}: verdict {cell['verdict']!r} outside vocabulary")
            return
        if not _norm(cell.get("witness", "")):
            _fail("G", f"map cell {key!r}: empty bottoming-out witness")
            return
    if tuple(sorted(props)) != tuple(sorted(EXPECTED_PROPS)):
        _fail("G", f"map properties {sorted(props)} != expected {sorted(EXPECTED_PROPS)}")
        return
    for prop in EXPECTED_PROPS:
        want = 2 if prop == "spin" else 1
        if len(props[prop]) != want:
            _fail("G", f"property {prop!r}: {len(props[prop])} chains, expected {want}")
            return
    # Computed headline (reported, not adjudicated): a property counts as
    # DERIVED only if every one of its chains is DERIVED.
    derived_props = [p for p in EXPECTED_PROPS
                     if all(RECORD_MAP[(p, c)]["verdict"] == "DERIVED" for c in props[p])]
    _ok("G", f"map complete: 7 cells, vocabulary clean, witnesses non-empty; "
             f"properties with all-chains-DERIVED: {len(derived_props)}/6 "
             f"({', '.join(derived_props) if derived_props else 'none'})")


# ---------------------------------------------------------------------------
# Check A — §8.2 summary table vs the map.
# ---------------------------------------------------------------------------
def check_A():
    print("\n[A] §8.2 summary table vs extraction map")
    span = _section_span("8.2")
    if span is None:
        _fail("A", "§8.2 heading not found")
        return
    rows = _table_rows(span)
    if rows is None:
        _fail("A", "§8.2 table has a malformed row (< 3 cells)")
        return
    seen = {}
    for cells in rows:
        prop = _canon_prop(cells[0])
        if prop in EXPECTED_PROPS:
            if prop in seen:
                _fail("A", f"§8.2 table: duplicate row for property {prop!r}")
                return
            seen[prop] = (cells[1], cells[2])
        else:
            _fail("A", f"§8.2 table: row for {cells[0]!r} has no record cell — unmapped claim")
            return
    for prop in EXPECTED_PROPS:
        if prop not in seen:
            _fail("A", f"§8.2 table: DROPPED CHAIN — no row for property {prop!r}")
            return
    ok = True
    for (prop, chain), cell in RECORD_MAP.items():
        verdict_cell, witness_cell = seen[prop]
        want = cell["verdict"]
        if prop == "spin":
            if "split" not in _norm(verdict_cell):
                _fail("A", f"spin row: verdict cell {verdict_cell!r} does not mark the §8.3 SPLIT")
                ok = False
                continue
            # Parse the (a)/(b) sub-verdicts out of the witness cell structurally.
            parts = re.split(r"\(([ab])\)", witness_cell)
            sub = {}
            for i in range(1, len(parts) - 1, 2):
                v = _verdict_in(parts[i + 1])
                if v:
                    sub[SPIN_SUBCHAINS[parts[i]]] = v
            if sub.get(chain) != want:
                _fail("A", f"spin/({chain}): §8.2 witness sub-verdict is {sub.get(chain)!r}, "
                           f"record says {want}")
                ok = False
        else:
            got = _verdict_in(verdict_cell)
            if got != want:
                _fail("A", f"{prop}: §8.2 verdict cell says {got!r}, record says {want}")
                ok = False
        # Witness anchoring: the map's key phrase must occur in the paper's
        # own witness column (normalized containment).
        if _norm(cell["witness"]) not in _norm(witness_cell):
            _fail("A", f"{prop}/({chain}): witness phrase not anchored in §8.2 witness cell")
            ok = False
    if ok:
        _ok("A", "6 rows present, verdicts and witnesses match the 7 record cells")


# ---------------------------------------------------------------------------
# Check B — §8.3 line-anchored verdict lines vs the map.
# ---------------------------------------------------------------------------
def check_B():
    print("\n[B] §8.3 Verdict (a)/(b) lines vs extraction map")
    span = _section_span("8.3")
    if span is None:
        _fail("B", "§8.3 heading not found")
        return
    pat = re.compile(r"^\*\*Verdict \(([ab])\):\s*BOTTOMS OUT\s*\((GAP|REFUTED|DERIVED)\)", re.I)
    found = {}
    for ln in span:
        m = pat.match(ln.strip())
        if m:
            tag = m.group(1).lower()
            if tag in found:
                _fail("B", f"§8.3: duplicate Verdict ({tag}) line")
                return
            found[tag] = m.group(2).upper()
    ok = True
    for tag, chain in SPIN_SUBCHAINS.items():
        want = RECORD_MAP[("spin", chain)]["verdict"]
        if tag not in found:
            _fail("B", f"§8.3: Verdict ({tag}) line missing — dropped sub-chain")
            ok = False
        elif found[tag] != want:
            _fail("B", f"§8.3: Verdict ({tag}) says {found[tag]!r}, record says {want} "
                       f"(misattributed sub-verdict)")
            ok = False
    if ok:
        _ok("B", f"(a)->{found['a']}, (b)->{found['b']}: split verdicts match the record")


# ---------------------------------------------------------------------------
# Check C — §8.4 alignment table vs the map.
# ---------------------------------------------------------------------------
def check_C():
    print("\n[C] §8.4 alignment table vs extraction map")
    span = _section_span("8.4")
    if span is None:
        _fail("C", "§8.4 heading not found")
        return
    rows = _table_rows(span)
    if rows is None:
        _fail("C", "§8.4 table has a malformed row (< 3 cells)")
        return
    seen = {}
    ok = True
    for cells in rows:
        if len(cells) < 4:
            _fail("C", f"§8.4 table: row has {len(cells)} cells, need 4 "
                       f"(property/chain | record | restatement | H.3)")
            return
        left = cells[0]
        if "/" not in left:
            _fail("C", f"§8.4 table: row {left!r} lacks the 'property / chain' shape")
            ok = False
            continue
        p_raw, c_raw = left.split("/", 1)
        key = (_canon_prop(p_raw), _norm(c_raw))
        if key not in RECORD_MAP:
            _fail("C", f"§8.4 table: row {left!r} names no record cell — unmapped claim")
            ok = False
            continue
        if key in seen:
            _fail("C", f"§8.4 table: duplicate row for {key!r}")
            ok = False
            continue
        seen[key] = True
        want = RECORD_MAP[key]["verdict"]
        rec_v = _verdict_in(cells[1])
        rest_v = _verdict_in(cells[2])
        agree = (rec_v == want) and (rest_v == want)
        claims_match = _norm(cells[3]) == "match"
        if not agree:
            _fail("C", f"§8.4 table: {key!r} record={rec_v!r} restatement={rest_v!r}, "
                       f"map says {want}")
            ok = False
        elif not claims_match:
            _fail("C", f"§8.4 table: {key!r} agrees with the map but does not say MATCH")
            ok = False
    for key in RECORD_MAP:
        if key not in seen:
            _fail("C", f"§8.4 table: DROPPED CHAIN — no row for {key!r}")
            ok = False
    if ok:
        _ok("C", f"{len(seen)}/7 rows: record and restatement cells match the map, all MATCH")


# ---------------------------------------------------------------------------
# Check D — §8.5 C2 row vs the map's no-DERIVED invariant.
# ---------------------------------------------------------------------------
def check_D():
    print("\n[D] §8.5 C2 row vs extraction map")
    span = _section_span("8.5")
    if span is None:
        _fail("D", "§8.5 heading not found")
        return
    rows = _table_rows(span)
    if rows is None:
        _fail("D", "§8.5 table has a malformed row (< 3 cells)")
        return
    c2 = None
    for cells in rows:
        if _norm(cells[0]).startswith("c2"):
            c2 = cells
            break
    if c2 is None:
        _fail("D", "§8.5 table: no C2 row — dropped criterion")
        return
    sm_cell = c2[2]
    derived_cells = [k for k, v in RECORD_MAP.items() if v["verdict"] == "DERIVED"]
    ok = True
    if "fail" not in _norm(sm_cell):
        _fail("D", f"C2 SM-gloss cell does not carry FAIL: {sm_cell[:80]!r}")
        ok = False
    if "h.2" not in _norm(sm_cell):
        _fail("D", "C2 SM-gloss cell does not cite H.2")
        ok = False
    if derived_cells:
        _fail("D", f"map has DERIVED cells {derived_cells} but C2 issues blanket FAIL — "
                   f"the row needs qualification")
        ok = False
    if ok:
        _ok("D", f"C2 carries FAIL citing H.2; consistent with {len(derived_cells)} DERIVED "
                 f"cells in the map")


# ---------------------------------------------------------------------------
# Check E — §3.x verdict sentences of the form "H.2's verdict for X is Y".
# A verdict token counts only in this syntactic slot — the same token in
# running prose is not a verdict claim and is ignored.
# ---------------------------------------------------------------------------
def check_E():
    print("\n[E] 'H.2's verdict for X is Y' sentences vs extraction map")
    flat = _norm(text)
    pat = re.compile(
        r"h\.2's verdict for ([a-z][a-z ]*?) is (gap|refuted|derived)"
        r"(, not (gap|refuted|derived))?")
    found = list(pat.finditer(flat))
    if not found:
        print("  note [E]: no 'H.2's verdict for X is Y' sentences present — nothing to check")
        return
    ok = True
    chains_by_prop = {}
    for (p, c) in RECORD_MAP:
        chains_by_prop.setdefault(p, []).append(c)
    for m in found:
        prop = _canon_prop(m.group(1))
        claimed = m.group(2).upper()
        denied = m.group(4).upper() if m.group(4) else None
        if prop not in chains_by_prop:
            _fail("E", f"verdict sentence names {m.group(1)!r} — no record cell (unmapped property)")
            ok = False
            continue
        if len(chains_by_prop[prop]) > 1:
            # Ambiguous property: the sentence must name exactly one chain.
            sent = flat[max(0, m.start() - 200):m.end() + 200]
            named = [c for c in chains_by_prop[prop] if _norm(c) in sent]
            if len(named) != 1:
                _fail("E", f"verdict sentence for {prop!r} does not disambiguate its chain "
                           f"(spin has two)")
                ok = False
                continue
            key = (prop, named[0])
        else:
            key = (prop, chains_by_prop[prop][0])
        want = RECORD_MAP[key]["verdict"]
        if claimed != want:
            _fail("E", f"verdict sentence: {key!r} claimed {claimed!r}, record says {want}")
            ok = False
        if denied is not None and want == denied:
            _fail("E", f"verdict sentence: {key!r} says 'not {denied}' but the record IS {want}")
            ok = False
    if ok:
        _ok("E", f"{len(found)} verdict sentence(s) agree with the record")


# ---------------------------------------------------------------------------
# Check F — §8.1 spin row must cite both §8.3 sub-verdicts (anti-collapse:
# the split must not be silently reduced to one label in the H.1 table).
# ---------------------------------------------------------------------------
def check_F():
    print("\n[F] §8.1 spin row: both §8.3 sub-verdicts cited (anti-collapse)")
    span = _section_span("8.1")
    if span is None:
        _fail("F", "§8.1 heading not found")
        return
    rows = _table_rows(span)
    if rows is None:
        _fail("F", "§8.1 table has a malformed row (< 3 cells)")
        return
    spin_row = None
    for cells in rows:
        if _canon_prop(cells[0]).startswith("intrinsic spin"):
            spin_row = cells
            break
    if spin_row is None:
        _fail("F", "§8.1 table: no spin row — dropped property")
        return
    badge_cell = _norm(" ".join(spin_row))
    ok = True
    for tag in ("8.3a", "8.3b"):
        if tag not in badge_cell:
            _fail("F", f"§8.1 spin row does not cite §{tag} — the split is collapsed")
            ok = False
    if ok:
        _ok("F", "spin row cites §8.3a and §8.3b — no verdict collapse")


def main():
    print("=" * 70)
    print("H.3 — VERDICT-LAYER CONSISTENCY (structural, not substring)")
    print("Cross-layer transcription invariant over the paper's verdict claims.")
    print(f"Draft: {DRAFT}")
    print("=" * 70)

    check_G()  # map shape first — everything else assumes it
    check_A()  # §8.2 table
    check_B()  # §8.3 verdict lines
    check_C()  # §8.4 alignment table
    check_D()  # §8.5 C2 row
    check_E()  # §3.x verdict sentences
    check_F()  # §8.1 spin row anti-collapse

    print("\n" + "=" * 70)
    if FAILURES:
        print(f"H.3 RESULT: {len(FAILURES)} INCONSISTENCY(IES) — the paper's verdict")
        print("  layers disagree with the H.2 record (or a layer is missing).")
        print("  Each FAIL above names the check, the section, and the witness.")
        return 1
    print("H.3 RESULT: CONSISTENT — 7/7 record cells match across §8.1, §8.2,")
    print("  §8.3, §8.4, §8.5-C2, and the §3.x verdict sentences.")
    print("  What was proven: the paper's tabulated verdict layers say the same")
    print("  thing. What was NOT proven: that the verdicts are correct, that")
    print("  H.2's chains are good derivations, or that any prose overreaches")
    print("  any equation — those remain the author's classifications.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
