#!/usr/bin/env python3
"""PA.1 — Parsing Agent for Paper 11.5.

Takes Standard Model property claims (as stated in textbooks/prose) and parses
each into: (1) the formal content (what the equations actually say),
(2) the gloss (what the prose adds), (3) the badge verdict under Paper 11's
discipline.

This is the mechanical reader Dervis asked for: feed it SM claims, it separates
derived content from smuggled gloss, and reports the honesty verdict.

Usage: python3 PA1_parsing_agent.py [--claim "text"]
  Without --claim, runs the six canonical SM claims from the paper.

Draft resolution (v19 fallback chain): --draft -> $PAPER_MD ->
paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md.
The resolved draft file is printed on every run.

v24 FORTRESS hardening (V23-20): subsection parsing is fail-loud — every
§3.1–3.6 subsection must carry its (a)/(b)/(c) markers in order; a subsection
that doesn't is skipped with a printed WARNING naming it (the totals never
silently shrink), and zero parsed subsections exits nonzero.
"""
import re
import sys
import argparse


# Knowledge base: for each property, the formal content and the gloss
KB = {
    "spin": {
        "formal": "S.n-hat has eigenvalues +-h/2; n-hat is the field axis (constitutive).",
        "gloss": "Drop n-hat; claim 'spin-1/2' as a standalone possession.",
        "badge": "NO BADGE (REFUTED by Bell, local scope — pre-existing local values, §8.3b; "
                 "the axis-constituted reading itself is GAP, §8.3a)",
        "paper11": "RELATIONAL_ROLE_THEOREM [A]",
    },
    "charge": {
        "formal": "L_int = -e(mu) psi-bar gamma psi A; e runs with scale mu.",
        "gloss": "Drop mu; claim 'charge -e' as scale-free possession.",
        "badge": "NO BADGE (SMUGGLED)",
        "paper11": "PORT_PARTITION_EXACTNESS [A]",
    },
    "color": {
        "formal": "SU(3) gauge label; cancels from S-matrix (Elitzur); N_c=3 in rates.",
        "gloss": "Promote gauge label to 'intrinsic color charge' possession.",
        "badge": "NO BADGE (SMUGGLED)",
        "paper11": "STRUCTURAL_INSULATION [A]",
    },
    "flavor": {
        "formal": "V_CKM rotates weak vs mass bases; flavor is basis-relative.",
        "gloss": "Treat basis-dependence as correction; claim 'intrinsic flavor'.",
        "badge": "NO BADGE (SMUGGLED)",
        "paper11": "RELATIONAL_ROLE_THEOREM [A]",
    },
    "mass": {
        "formal": "m^2 from decay kinematics; m_f = y_f v/sqrt(2) with VEV background.",
        "gloss": "Forget VEV/kinematics; claim 'intrinsic mass' as possession.",
        "badge": "NO BADGE (SMUGGLED)",
        "paper11": "Paper 8 mass-as-ledger [A]",
    },
    "magnetic moment": {
        "formal": "a_e = sum over 12,672 virtual-encounter loop diagrams.",
        "gloss": "Attribute encounter sum to 'the electron' alone.",
        "badge": "NO BADGE (SMUGGLED)",
        "paper11": "ASPECT_AGGREGATION [A]",
    },
}


def parse_claim(text):
    """Parse an SM claim. Returns (property, formal, gloss, badge, paper11),
    or ("AMBIGUOUS", ...) if the input matches more than one property
    (fail closed: never silently misroute), or None if nothing matches.

    Routing fix (v15): color-specific terms participate in matching, and a
    documented priority resolves exactly one known subsumption: when the
    input matches ONLY color and generic charge (e.g. "color charge"),
    color wins — "charge" is a substring of "color charge", so without
    priority the generic entry would swallow the specific one. Any OTHER
    multi-property match (color+spin, charge+flavor, ...) fails closed
    as AMBIGUOUS. The priority is a resolution rule for a known overlap,
    not a bypass of ambiguity detection (v15 loop repair).
    """
    text_lower = text.lower()

    matches = []
    # Color-specific terms (no fast-path return; ambiguity is counted below).
    color_terms = ["color", "colour", "chromo", "qcd", "su(3)"]
    if any(t in text_lower for t in color_terms):
        matches.append("color")

    for prop, data in KB.items():
        if prop == "color":
            continue  # handled above
        # Match property name or related terms
        terms = [prop]
        if prop == "magnetic moment":
            terms += ["g-2", "g minus 2", "anomalous moment"]
        if prop == "charge":
            terms += ["electric charge"]
        if any(t in text_lower for t in terms):
            matches.append(prop)

    if not matches:
        return None

    # Documented priority: the ONLY resolved overlap is color-over-charge.
    if set(matches) <= {"color", "charge"} and "color" in matches:
        prop = "color"
    elif len(matches) > 1:
        # Fail closed on any other ambiguity: never silently pick one.
        return ("AMBIGUOUS",
                f"input matches {len(matches)} properties: "
                f"{', '.join(matches)}",
                "disambiguate before parsing",
                "NO BADGE (UNPARSEABLE — ambiguous input)",
                "—")
    else:
        prop = matches[0]

    data = KB[prop]
    # Check if it claims intrinsicality
    if re.search(r"\bintrinsic\b", text_lower):
        return (prop, data["formal"], data["gloss"], data["badge"],
                data["paper11"])
    return (prop, data["formal"], "(no intrinsic gloss detected)",
            "NOT APPLICABLE", data["paper11"])



def _resolve_draft_noargv(here):
    """Fallback chain (v19), no-argv variant: $PAPER_MD -> candidate filenames.

    argparse already consumed argv, so --draft is honored verbatim by the
    caller; this variant runs only when --draft was not given. $PAPER_MD
    pointing at a nonexistent file falls through to the candidates.
    Candidate order: paper_11_5_draft.md, paper.md, then paper_11_5_v<N>.md
    newest-first. Inlined: scripts stay standalone, no shared imports.
    """
    import os, re
    from pathlib import Path
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried --draft, $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


def divergence_ratio(draft_path=None):
    """GLOSS-TO-EQUATION DIVERGENCE RATIO.

    Mechanically scans §3 of the paper: counts possession/intrinsic patterns
    inside the textbook-claim blocks (a) + Textual evidence of each §3.1–3.6
    property subsection, vs encounter-index patterns inside the equation
    breakdown blocks (b) of the same subsections. The paper's rebuttal voice
    — (c) inference chains, (d) Paper 11 counterparts, the §3 intro, the §3.7
    audit summary, §3.8/§3.9, and inter-subsection prose — is excluded from
    BOTH counts, so the textbook's voice is never conflated with the paper's
    reply. Both counts are mechanical regex scans over the actual paper text —
    nothing hand-coded.

    SCOPING RULE (v24, F-39): possession patterns are counted ONLY in a
    subsection's (a) block — the span between the **(a)** and **(b) markers
    (the claim plus its "Textual evidence" block, where one exists);
    encounter-index patterns ONLY in its (b) block — the span between the
    **(b) and **(c) markers. Block membership is the ONLY routing criterion.

    TIE-BREAKS (documented):
    1. A line matching patterns from BOTH sets counts only toward its own
       block's category: in an (a) block it can add a possession hit and
       never an index hit; in a (b) block the reverse. Cross-category
       double-counting cannot happen by construction. Within one category,
       overlapping patterns each count (e.g. "e(mu)" matches both \\(mu\\)
       and e\\(mu\\)), so the totals are pattern-hit aggregates — not
       distinct-line counts and not a 1:1 claim-to-index mapping (the §8.9
       prose states the aggregates reading explicitly).
    2. Subsection parsing is fail-loud (V23-20 repair): every §3.1–3.6
       subsection must carry its (a)/(b)/(c) markers, in order. A subsection
       failing the check is skipped with a printed WARNING naming the
       subsection and the failed check — the totals never silently shrink.
       If some (but not all) subsections parse, the run warns (exit 0) with
       the explicit parsed count; if ZERO parse, this function returns None
       and main() exits nonzero rather than print a vacuous 0/0.

    WHAT STAYS OUTSIDE THE MACHINE CHECK:
    - Within-block voice attribution. The machine cannot tell the paper's
      meta-voice from textbook/formalism voice inside a block: the coined
      term "encounter-index" is itself a counted pattern, so the paper's own
      (b)-block framing sentences using it count by design; likewise the
      paper's meta-descriptions inside Textual-evidence blocks count by
      design. Whether a given hit is the target voice is human-audit
      territory (audited once against v23: 19/20 possession hits are
      unambiguously textbook voice; the 6 "encounter-index" index hits are
      the paper's own label for the formalism's indexing).
    - The pattern lists themselves: which regexes capture "possession" or
      "encounter-index" is declared design, not machine-verified.
    - The §3 extraction assumes the first "## 3 " / "## 4 " headings delimit
      §3 (true of the v23 text; same-string occurrences inside later
      code-block listings do not interfere because extraction is first-match).
    - §3.3 and §3.6 carry no "Textual evidence" block; their (a) count covers
      the claim plus attribution only — the (a)->(b) span, whatever it holds.

    Portable draft resolution (v14 hardening; v19 fallback chain):
    --draft -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
    newest paper_11_5_v<N>.md. --draft is honored verbatim (unchanged
    pre-v19 behavior, including fail-on-nonexistent input).
    """
    from pathlib import Path
    here = Path(__file__).resolve().parent
    DRAFT = Path(draft_path) if draft_path else _resolve_draft_noargv(here)
    print(f"  Draft: {DRAFT}")
    text = open(DRAFT, encoding="utf-8").read()
    # Extract §3 (between "## 3" header and "## 4" header)
    m = re.search(r"## 3\s.*?(?=## 4\s)", text, re.S)
    if not m:
        print("  §3 not found — cannot compute divergence ratio.")
        return None
    s3 = m.group(0)

    # Possession patterns in textbook prose
    poss_patterns = [
        r"\bintrinsic\b", r"\bcarries\b", r"\bpossesses\b", r"\bhas intrinsic\b",
        r"intrinsic propert", r"\bpossession\b",
    ]
    # Encounter-index patterns in equations
    index_patterns = [
        r"\(mu\)", r"n-hat", r"n̂", r"Q\^2", r"Q²", r"\\xi", r"V_CKM", r"CKM",
        r"\bgauge\b", r"\bbasis\b", r"\bframe\b", r"\bscale\b", r"alpha\(mu\)",
        r"e\(mu\)", r"encounter-index",
    ]
    # v24 scoping: split §3 into property subsections; count possession
    # patterns ONLY in each subsection's (a) textbook-statement block
    # (claim + Textual evidence) and index patterns ONLY in its (b)
    # equation-breakdown block. V23-20: every subsection's markers are
    # validated loudly — a marker miss or order violation skips that
    # subsection with a printed WARNING, never silently.
    parts = re.split(r"(?m)^### 3\.(\d)\s", s3)
    spans = {}
    for i in range(1, len(parts), 2):
        spans[parts[i]] = parts[i + 1] if i + 1 < len(parts) else ""
    claim_text, eq_text = "", ""
    parsed = 0
    for n in ["1", "2", "3", "4", "5", "6"]:
        body = spans.get(n, "")
        try:
            claim_blk, eq_blk = _subsection_blocks(body, n)
        except _MarkerError as e:
            print(f"  WARNING: {e} — subsection excluded from both counts.")
            continue
        claim_text += "\n" + claim_blk
        eq_text += "\n" + eq_blk
        parsed += 1
    if parsed == 0:
        print("  ERROR: 0/6 §3.1–3.6 subsections parsed — totals would be "
              "vacuous. Failing loudly instead of printing a silent 0/0.")
        return None
    if parsed < 6:
        print(f"  WARNING: only {parsed}/6 §3.1–3.6 subsections parsed; "
              f"the totals below cover the parsed subsections only.")
    poss = sum(len(re.findall(p, claim_text, re.I)) for p in poss_patterns)
    idx = sum(len(re.findall(p, eq_text, re.I)) for p in index_patterns)
    return poss, idx


class _MarkerError(Exception):
    """Raised when a §3.N subsection's (a)/(b)/(c) markers fail validation."""


def _subsection_blocks(body, n):
    """Split one §3.N subsection body into ((a) claim block, (b) equation block).

    Returns (claim_block, eq_block) or raises _MarkerError naming the
    subsection and the failed check. V23-20 repair: the old chained
    find("**(b)", a_start) silently skipped a subsection on any marker
    mismatch (shrinking the totals with no trace); this version validates
    each marker independently and requires a<b<c ordering, failing the
    subsection loudly instead.
    """
    a_start = body.find("**(a)**")
    b_start = body.find("**(b)")
    c_start = body.find("**(c)")
    missing = []
    if a_start == -1:
        missing.append("**(a)**")
    if b_start == -1:
        missing.append("**(b)")
    if c_start == -1:
        missing.append("**(c)")
    if missing:
        raise _MarkerError(
            f"§3.{n}: marker(s) not found: {', '.join(missing)}")
    if not (a_start < b_start < c_start):
        raise _MarkerError(
            f"§3.{n}: markers out of order "
            f"((a)@{a_start}, (b)@{b_start}, (c)@{c_start})")
    return body[a_start:b_start], body[b_start:c_start]


def selftest():
    """Routing regression battery: routing must be exact, ambiguity must fail closed.

    Each (input, expected_property) pair asserts the router's verdict.
    The color-charge case is the v15 defect: it previously routed to the
    generic electric-charge entry.
    """
    cases = [
        # (input claim, expected routed property)
        ("The electron carries intrinsic charge -e.", "charge"),
        ("Quarks carry intrinsic color charge.", "color"),
        ("Quarks have intrinsic flavor.", "flavor"),
        ("The electron has intrinsic magnetic moment.", "magnetic moment"),
        ("The electron has intrinsic spin-1/2.", "spin"),
        ("The electron has intrinsic mass 511 keV.", "mass"),
        # Ambiguous input must fail closed, not silently pick one.
        ("The electron has intrinsic spin-1/2 and intrinsic charge -e.",
         "AMBIGUOUS"),
        # v15 loop repair: color + another property must ALSO fail closed
        # (the color priority resolves only the color/charge subsumption).
        ("Quarks carry intrinsic color charge and intrinsic spin.",
         "AMBIGUOUS"),
    ]
    failures = []
    for claim, expected in cases:
        result = parse_claim(claim)
        got = result[0] if result else None
        status = "PASS" if got == expected else "FAIL"
        print(f"  [{status}] {claim!r} -> {got} (expected {expected})")
        if got != expected:
            failures.append((claim, expected, got))
    if failures:
        print(f"  REGRESSION: {len(failures)} routing failure(s).")
        return 1
    print("  All routing regression tests pass.")
    return 0


def main():
    parser = argparse.ArgumentParser(description="PA.1 Parsing Agent")
    parser.add_argument("--claim", type=str, help="SM claim to parse")
    parser.add_argument("--draft", type=str, default=None,
                        help="path to the paper draft (honored verbatim). Without --draft, "
                             "the v19 fallback chain runs: $PAPER_MD -> paper_11_5_draft.md -> "
                             "paper.md -> newest paper_11_5_v<N>.md.")
    args = parser.parse_args()

    print("=" * 70)
    print("PA.1 — PARSING AGENT")
    print("Separating derived content from smuggled gloss in SM property claims")
    print("=" * 70)

    # Routing regression battery runs first: routing must be exact.
    print("\nROUTING REGRESSION TESTS")
    print("-" * 70)
    if selftest() != 0:
        return 1

    claims = []
    if args.claim:
        claims = [args.claim]
    else:
        claims = [
            "The electron has intrinsic spin-1/2.",
            "The electron carries intrinsic charge -e.",
            "Quarks carry intrinsic color charge.",
            "Quarks have intrinsic flavor.",
            "The electron has intrinsic mass 511 keV.",
            "The electron has intrinsic magnetic moment.",
        ]

    for claim in claims:
        result = parse_claim(claim)
        print(f"\nINPUT: {claim}")
        if result:
            prop, formal, gloss, badge, p11 = result
            print(f"  Property: {prop}")
            print(f"  Formal content (derived): {formal}")
            print(f"  Gloss (smuggled): {gloss}")
            print(f"  Badge: {badge}")
            print(f"  Paper 11 counterpart: {p11}")
        else:
            print(f"  UNRECOGNIZED: no property matched.")

    # Divergence ratio: mechanical scan of §3
    print("\n" + "=" * 70)
    print("GLOSS-TO-EQUATION DIVERGENCE RATIO (§3 mechanical scan)")
    print("=" * 70)
    r = divergence_ratio(args.draft)
    if r is None:
        # Fail loudly: zero parsed subsections (or no §3) must not exit 0
        # with a silent skip. V23-20.
        print("\nPA.1 FAILED: divergence ratio could not be computed — "
              "see ERROR above.")
        return 1
    poss, idx = r
    print(f"  Possession/intrinsic patterns in (a) textbook-claim blocks: {poss}")
    print(f"  Encounter-index patterns in (b) equation breakdowns: {idx}")
    if idx > 0:
        print(f"  DIVERGENCE RATIO: {poss} textbook possession-claims vs. {idx} "
              f"equation encounter-indices.")
        print(f"  Counts are scoped: (a)+Textual-evidence vs (b) only, per §3.1–3.6;")
        print(f"  the paper's rebuttal voice ((c), (d)) is excluded from both.")
    print("  (Counts are mechanical regex scans over §3's actual text.)")

    print("\n" + "=" * 70)
    print("PA.1 complete. The agent separates what equations say from what prose adds.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
