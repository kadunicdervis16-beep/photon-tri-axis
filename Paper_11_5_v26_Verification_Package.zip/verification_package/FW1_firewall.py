#!/usr/bin/env python3
"""FW.1 — Paper 11.5 Firewall (cf. Paper 11 F.42).

Self-policing script: scans Paper 11.5's own text for language that would
violate its own critique. The paper attacks "intrinsic" as smuggled ontology —
it must not smuggle it back in. It identifies continuous calculus as the
enabler — it must not lean on continuum language uncritically.

Three sweep groups:

  Group A — "Intrinsic" usage audit.
    Every occurrence of "intrinsic" must be either:
    (1) in a quoted SM claim being critiqued, or
    (2) in the paper's own negative use ("not intrinsic", "intrinsic only in prose",
        "the intrinsic illusion", etc.), or
    (3) in Appendix F (the glossary, which surveys usages).
    Any other use — especially a positive ascription by the paper itself — is a breach.
    SENTENCE-PATTERN GATE (v24 disclosure): only a line matching `is`/`are` +
    "intrinsic"/"intrinsically" (modulo an adjacent negation) can breach Group A.
    Adjectival forms ("carries intrinsic X", "has intrinsic Y") never trigger the
    gate — they pass through it, not through any exemption. The six §3 (a)-lines
    are the audit's designated textbook-claim statements, so their silence is
    semantics-preserving: each quoted sentence is mention (the quoted-token test),
    and the one unquoted gloss ("the electron's intrinsic properties", §3.1(a))
    passes through the gate. Residual risk, stated: an unquoted adjectival
    ascription in the paper's own voice would pass the gate silently — zero live
    instances in v23 (verified: no unquoted carries/has/possesses + intrinsic in
    prose), human-audit territory.

  Group B — Continuum language audit.
    Flags continuum-enabling language: "at a point", "smooth", "continuous",
    "infinitesimal", "differentiable", "in the limit" — where used to ground
    a property ascription (not merely in historical exposition).
    The paper's thesis (§9): continuous calculus gives license to the intrinsic
    habit by picturing fields-with-values-at-points. Using that picture
    uncritically while critiquing its consequences is a breach.
    ONE INVENTORY ON ALL THREE SURFACES (v24 reconciliation): all six terms are
    implemented in code — "continuous" and "in the limit" were docstring-promised
    but code-missing, now implemented (the prose, this docstring, and the code
    agree). §9 consequence, stated: §9 uses "continuous" throughout in the
    paper's own analytic voice to NAME the enabler; the breach condition requires
    a property word on the same line (the grounding test), so naming the target
    does not breach. A future "continuous"+property line in the paper's own voice
    WILL breach — that is the firewall working, not a false positive.

  Group C — Possessive grammar audit.
    Flags "the electron's X", "the quark's Y", "its spin/charge/mass" where X/Y
    is one of the seven audited properties AND the possessive is the paper's own
    voice (not a quoted SM claim). The paper's §5 identifies possessive
    predication as reification step 3 — it must not perform it.
    Properties (v24): spin, charge, mass, color, flavor, magnetic moment, moment.
    "moment" was added v24 (triage: safe hardening) — "the electron's moment" is
    the same reification step with the adjective dropped.
    QUOTED-"intrinsic" EXEMPTION (v24 disclosure): a possessive hit is exempt when
    its line contains "intrinsic" in quotes anywhere on the line — mention-not-use
    (such a line discusses the idiom, not the paper's own ascribing voice).
    Residual risk, stated: a genuine ascription sharing a line with a quoted
    "intrinsic" would slip through — zero live instances in v23, human-audit
    territory.

Each breach prints a witness. Zero breaches = PASS.
Draft resolution (v19 fallback chain): argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft file is printed on every run.

EXEMPTION BREADTH — design decision with rationale (v24 disclosure):
The firewall exempts MENTION of banned language from USE of it; the
exemptions below are deliberate and each has a stated reason. Breadth is
the known trade-off: a narrower exemption set risks false positives on the
paper's own critique (which must quote and rebut the SM idiom); a broader
set risks missing a real breach. This script chooses the middle: exemptions
are structural (where the text is, not what it says) and fail-closed where
a violation is still possible.

  (i) Quoted-context exemptions (Group A, Group C): lines that are blockquotes
      (leading ">") or fall inside a "Textual evidence" span are the SM claim
      being critiqued, not the paper's own voice — policing them would forbid
      quoting the target. Group C adds a quoted-span test with delimiter-quote
      counting (word-internal apostrophes are not delimiters; the mutant C1
      case pins this). Group A's quoted-token test (odd quote count before the
      match) applies only to the current line.
  (ii) Critical-window token list (Group A): a ±2-line window around an
       "intrinsic" hit containing critical tokens ("not intrinsic", "refut",
       "smuggl", "versus", ...) exempts the hit as negative/critical use.
       Rationale: the paper's thesis REQUIRES negative uses ("not intrinsic",
       "intrinsic only in prose"); requiring exact "not intrinsic" phrasing
       would freeze the prose. The window is ±2 lines because a rebuttal's
       negation can sit on a neighboring line in markdown (line-wrapped
       sentences); a wider window would let distant negation wash a positive
       ascription. The residual risk — a genuinely positive ascription
       adjacent to critique prose — is human-audit territory, stated here
       rather than hidden.
  (iii) Group B window sizes: the history exclusion looks back 30 lines for
       "2.7"/"historical arc" (a subsection span, not a single line); the
       Appendix B exclusion looks back 50 lines (appendix context); the
       firewall-doc exclusion looks back 10 lines (§8.8 discusses the firewall
       itself). The changelog exemption is the narrowest: a line is exempt
       ONLY if it is a changelog entry ("- vNN (date)") inside the Appendix D
       span AND the matched pattern is quoted on that line — an unquoted
       ascription in a changelog entry stays caught (fail-closed). Window
       sizes are heuristic and recorded here so a reader can see the floor.
  (iv) Sentence-pattern gate (Group A): only `is`/`are` + "intrinsic" can
       breach — adjectival forms pass through the gate, not through an
       exemption (see Group A above). Disclosed, with the residual risk stated.
  (v) Quoted-"intrinsic" exemption (Group C): a possessive hit is exempt when
       its line contains "intrinsic" in quotes anywhere on the line (see Group C
       above). Disclosed, with the residual risk stated.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


# Portable draft resolution (v14 hardening; v19 fallback chain):
# argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
# newest paper_11_5_v<N>.md. $PAPER_MD at a nonexistent file falls through;
# argv[1] is honored verbatim (unchanged pre-v19 behavior, including
# fail-on-nonexistent input). The helper is inlined: scripts stay
# standalone, no shared imports.
DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()
lines = text.split("\n")

breaches = []


def is_quoted_sm_claim(line, idx, lines):
    """Check if this line is part of a blockquote or textual-evidence section."""
    if line.strip().startswith(">"):
        return True
    for j in range(max(0, idx-10), idx):
        if "Textual evidence" in lines[j]:
            return True
    return False


def is_glossary(line, idx, lines):
    """Check if in Appendix F."""
    for j in range(max(0, idx-50), idx):
        if "APPENDIX F" in lines[j]:
            return True
    return False


def scan_groupA(lines):
    """Group A: no positive 'intrinsic' ascription in the paper's own voice."""
    breaches = []
    for i, line in enumerate(lines):
        for m in re.finditer(r"\bintrinsic(ally)?\b", line, re.I):
            before = line[:m.start()]
            if before.count('"') % 2 == 1:
                continue
            if is_quoted_sm_claim(line, i, lines):
                continue
            if is_glossary(line, i, lines):
                continue
            window = " ".join(lines[max(0,i-2):i+3])
            critical = ["not intrinsic", "no intrinsic", "never intrinsic", "not intrinsically",
                        "intrinsic only in prose", "intrinsic illusion", "against",
                        "critique", "refut", "falsif", "smuggl", "reifi", "fallacy",
                        "audit", "denies", "deny", "reject", "contradict", "versus",
                        "vs\\.", "comparison", "contrast", "in name only"]
            if any(re.search(p, window, re.I) for p in critical):
                continue
            if "Ontology A" in window or "intrinsic)" in line[:50]:
                continue
            # SENTENCE-PATTERN GATE (v24 disclosure): only `is`/`are` +
            # "intrinsic" can breach. Adjectival forms ("carries intrinsic X")
            # pass through this gate, not through any exemption — the six §3
            # (a)-lines are the audit's designated textbook-claim statements,
            # so their silence is semantics-preserving. Documented in the
            # docstring and §0.5.3; diagnostic mutant A2 pins the boundary.
            sent = line.strip()
            if re.search(r"\b(is|are)\s+(intrinsic|intrinsically)\b", sent, re.I):
                if not re.search(r"\b(not|no|never|n't)\b.{0,30}\b(is|are)\s+(intrinsic|intrinsically)\b", sent, re.I):
                    breaches.append(f"A intrinsic-assertion [{i+1}]: {sent[:100]}")
    return breaches


def scan_groupB(lines):
    """Group B: no continuum language grounding property ascriptions."""
    breaches = []
    continuum_terms = [
        (r"\bat a point\b", "point-localization"),
        # v13: the v10 loop found the orthographic variant "at every point"
        # slipped the "at a point" pattern. The firewall is a floor, not a
        # ceiling — variants get added as they are found, and each addition
        # is recorded so the reader sees the floor being raised.
        (r"\bat every point\b", "point-localization (orthographic variant)"),
        (r"\bsmooth\b", "smoothness assumption"),
        # v24 reconciliation: "continuous" and "in the limit" were
        # docstring-promised but code-missing. All three surfaces (prose §0.5.3,
        # docstring, code) now carry one inventory. "in the limit" has zero
        # live instances in v23 prose; "continuous" is §9's thesis vocabulary
        # (naming the enabler) — the property-co-occurrence requirement below is
        # what keeps §9's naming-of-the-target from breaching.
        (r"\bcontinuous\b", "continuum-ascription"),
        (r"\binfinitesimal", "infinitesimal"),
        (r"\bdifferentiable\b", "differentiability"),
        (r"\bin the limit\b", "limit-talk"),
    ]
    for i, line in enumerate(lines):
        in_history = any("2.7" in lines[j] or "historical arc" in lines[j].lower()
                         for j in range(max(0, i-30), i))
        in_appB = any("APPENDIX B" in lines[j] for j in range(max(0, i-50), i))
        in_fwdoc = any("8.8" in lines[j] or "firewall" in lines[j].lower()
                       for j in range(max(0, i-10), i))
        # v22: Appendix D changelog entries quote the firewall's own patterns
        # to record their addition (mention-not-use; the v21 false positive
        # on the v13 entry). Narrow per red-team G1 + DA charge: a line is
        # exempt ONLY if it is a changelog entry ('- vNN (date)') inside the
        # Appendix D span AND the matched pattern is quoted on it — an
        # unquoted ascription stays caught (fail-closed). Bare "changelog"
        # mentions (including this script's own comments) never trigger.
        _entry = any(re.match(r"\s*-\s+v\d+\s*\(", lines[j])
                     for j in range(max(0, i-30), i))
        _in_d = any("## APPENDIX D" in lines[j] for j in range(max(0, i-60), i))
        for pat, label in continuum_terms:
            if not re.search(pat, line, re.I):
                continue
            _quoted = bool(re.search(r"""["'][^"'\n]*""" + pat + r"""[^"'\n]*["']""",
                                     line, re.I))
            if in_history or in_appB or in_fwdoc or (_entry and _in_d and _quoted):
                continue
            if re.search(r"\b(spin|charge|mass|color|flavor|moment|property|properties)\b",
                         line, re.I):
                breaches.append(f"B continuum [{i+1}] ({label}): {line.strip()[:100]}")
    return breaches


def scan_groupC(lines):
    """Group C: no possessive reification in the paper's own voice."""
    breaches = []
    # v24: "moment" added (triage: safe hardening) — "the electron's moment" is
    # the same reification step with the adjective dropped. "magnetic moment"
    # keeps its own entry; the possessive+property shape means the two never
    # double-count the same span ("the electron's magnetic moment" matches only
    # the longer entry — after the possessive comes "magnetic", not "moment").
    properties = ["spin", "charge", "mass", "color", "flavor", "magnetic moment", "moment"]
    for i, line in enumerate(lines):
        if is_quoted_sm_claim(line, i, lines):
            continue
        for prop in properties:
            m = re.search(rf"\b(the electron's|the quark's|its)\s+({prop})\b", line, re.I)
            if m:
                # Exempt when the phrase is MENTIONED (quoted) rather than USED.
                # Two tests: (a) directly wrapped in a quote char; (b) inside a
                # quoted span (delimiter quotes only — word-internal apostrophes
                # like Paper's/electron's are not delimiters; mutant C1 caught
                # the old bug of counting them).
                before = line[:m.start()]
                stripped = re.sub(r"\w'\w", "", before)
                delim_before = stripped.count('"') + stripped.count("'")
                wrapped = before.rstrip().endswith(('"', "'"))
                in_quotes = wrapped or (delim_before % 2 == 1)
                # v24 disclosure (docstring + §0.5.3): the intrinsic_quoted
                # exemption — any possessive hit is exempt when "intrinsic"
                # appears in quotes anywhere on the line (mention-not-use: the
                # line discusses the idiom). Residual risk, stated: a genuine
                # ascription sharing a line with a quoted "intrinsic" would
                # slip through — zero live instances in v23, human-audit
                # territory.
                intrinsic_quoted = bool(re.search(r"""['"]intrinsic['"]""", line, re.I))
                if not (in_quotes or intrinsic_quoted):
                    breaches.append(f"C possessive [{i+1}]: {line.strip()[:100]}")
    return breaches

# --- Refactored: use the scan functions for the real paper ---
# Exclude fenced code blocks (Appendix G listings): the firewall polices the
# paper's prose voice, not embedded code (including its own mutant test data).
prose_lines = []
_in_fence = False
for _ln in lines:
    if _ln.strip().startswith("```"):
        _in_fence = not _in_fence
        continue
    if not _in_fence:
        prose_lines.append(_ln)
breaches = scan_groupA(prose_lines) + scan_groupB(prose_lines) + scan_groupC(prose_lines)


def mutant_battery():
    """PLANTED MUTANTS: genuine spec violations the firewall must catch.

    Each mutant is a real violation of the paper's own discipline —
    the kind of slip a tired author makes. Each must be REJECTED
    (caught) with a printed witness. Plus one negative control
    (legitimate critical prose) that must NOT be flagged.
    DIAGNOSTIC mutants document a disclosed design boundary: they pass BY
    DESIGN and are labeled diagnostic — never printed as REJECTED, never
    counted among rejections, and never allowed to flip all_ok.
    Returns True iff all must-catch mutants caught, diagnostics behave as
    documented, and control clean.
    """
    print("\n" + "=" * 70)
    print("PLANTED MUTANT BATTERY")
    print("=" * 70)

    mutants = [
        ("A1", ["The electron is intrinsically charged, independent of any encounter."],
         scan_groupA, "positive intrinsic ascription in assertoric voice"),
        ("B1", ["Spin is a smooth property at a point in the electron field."],
         scan_groupB, "continuum language grounding a property"),
        ("B2", ["The charge is defined at every point of the field."],
         scan_groupB, "orthographic variant 'at every point' (v10 loop gap, fixed v13)"),
        ("B3", ["The continuum picture treats charge as a continuous property of the field."],
         scan_groupB, "'continuous' grounding a property ascription "
         "(v24: docstring-promised term, now implemented)"),
        ("C1", ["The quark's color determines how it scatters."],
         scan_groupC, "possessive reification in own voice"),
        ("C2", ["The electron's moment is measured to ten decimals."],
         scan_groupC, "possessive + 'moment' "
         "(v24: 'moment' added to the audited properties)"),
    ]
    diagnostics = [
        ("A2", ["The electron carries intrinsic charge \u2212e."],
         scan_groupA, "adjectival 'carries intrinsic X' — passes the "
         "sentence-pattern gate BY DESIGN (the gate needs is/are + intrinsic); "
         "this is the six §3 (a)-lines' designated shape"),
    ]
    all_ok = True
    for mid, doc, scanner, desc in mutants:
        hits = scanner(doc)
        if hits:
            print(f"  Mutant {mid} REJECTED (caught): {desc}")
            print(f"    Witness: {hits[0]}")
        else:
            print(f"  Mutant {mid} SURVIVED — firewall blind to: {desc}. FAIL.")
            all_ok = False
    for mid, doc, scanner, desc in diagnostics:
        hits = scanner(doc)
        if hits:
            print(f"  Diagnostic {mid} FLAGGED — the disclosed gate boundary moved. FAIL: {hits[0]}")
            all_ok = False
        else:
            print(f"  Diagnostic {mid} survived BY DESIGN (disclosed limitation): {desc}")

    # Negative control: legitimate critical prose must NOT be flagged
    control = ["The 'intrinsic' reading is refuted by Bell; no intrinsic property survives the audit."]
    hits = scan_groupA(control) + scan_groupB(control) + scan_groupC(control)
    if not hits:
        print("  Negative control CLEAN (critical prose not flagged).")
    else:
        print(f"  Negative control FLAGGED — false positive. FAIL: {hits[0]}")
        all_ok = False

    return all_ok


print("=" * 70)
print("FW.1 — PAPER 11.5 FIREWALL")
print("=" * 70)
print(f"Draft: {DRAFT}")
print(f"\nScanned {len(lines)} lines.")
if breaches:
    print(f"\nBREACHES: {len(breaches)}")
    for b in breaches:
        print(f"  - {b}")
    sys.exit(1)
else:
    print("\nFW.1 PASS: no firewall breaches.")
    print("  The paper does not smuggle 'intrinsic' in its own voice,")
    print("  does not lean on continuum language for property ascriptions,")
    print("  and does not perform possessive reification.")

if not mutant_battery():
    print("\nFW.1 MUTANT BATTERY FAILED.")
    sys.exit(1)
print("\nFW.1 COMPLETE: paper clean, all mutants caught, control clean.")
sys.exit(0)
