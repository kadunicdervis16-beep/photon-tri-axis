#!/usr/bin/env python3
"""P.4 — Renormalization Group running executable for Paper 11.5.

Numerically integrates the QED beta function to show alpha(mu) running.
Demonstrates: there is no scale-free "intrinsic charge" — every finite value
is indexed to an encounter scale mu. The "bare" (scale-free) value diverges.

INPUT_PROVENANCE:
  - beta_qed / run_alpha: paper-defined schematic model (one-loop QED,
    fixed n_f, thresholds ignored). DECLARED ASSUMPTION: this is a
    schematic illustration of scale-dependence, not a precision
    prediction of alpha(M_Z); the physical point (no scale-free value
    exists) does not depend on the n_f choice.
  - alpha(m_e) = 1/137.036: cited-paper (PDG).
  - m_e, M_Z: cited-paper (PDG).

CONTINUUM_USE (v24 FORTRESS — explicit disclosure, Dervis's "disclose why"):
  - WHAT: Euler integration of the differential RG equation
    mu d/dmu alpha = beta(alpha), stepped in log-mu (math.log/math.exp for
    the log-scale grid); alpha itself a real variable.
  - WHY NEEDED: the exhibit IS the Standard Model's own differential RG
    equation. The paper's claim here is "QED's OWN equations encounter-index
    the charge" — exhibiting that requires running the SM's equation as the
    SM states it, and the SM states it as a differential equation in a
    continuous scale mu. The continuum is not scaffolding around the exhibit;
    it is the exhibit.
  - WHAT WOULD BE LOST INTEGER-NATIVE: the identity of the exhibited object.
    A rational-step map alpha_{n+1} = alpha_n + beta(alpha_n)*Delta would
    demonstrate *a* scale-dependence, but no longer the SM's RG equation —
    and the paper's point is precisely what the SM's own formalism says.
    The Landau-pole statement (mu -> infinity) is likewise intrinsically
    about the continuum limit. An integer-native rewrite would change the
    claim being exhibited, not just its precision.

Single-model fix (v15): ONE explicitly defined running model (N_F) is used for
every call in this script. Previously the headline used n_f=3 while the
scale table silently used the default n_f=1 — two beta functions in one
script. A regression assertion now pins headline alpha(M_Z) to the
table's alpha(M_Z).

  mu d/dmu alpha = beta(alpha) = (2*n_f/3pi) * alpha^2  [1-loop QED]
"""
import sys
import math


# THE running model for this script (v15): one n_f, used everywhere.
# Schematic one-loop choice; thresholds ignored. The verdict (scale-indexed,
# no scale-free value) is independent of this choice.
N_F = 3


def beta_qed(alpha, n_f=N_F):
    """1-loop QED beta function with the script's single running model."""
    return (2 * n_f / (3 * math.pi)) * alpha**2


def run_alpha(alpha_0, mu_0, mu_1, n_steps=10000, n_f=N_F):
    """Integrate RG equation from mu_0 to mu_1 using Euler (fine steps)."""
    alpha = alpha_0
    mu = mu_0
    dlnmu = math.log(mu_1 / mu_0) / n_steps
    for _ in range(n_steps):
        alpha += beta_qed(alpha, n_f) * dlnmu
        mu *= math.exp(dlnmu)
    return alpha


def main():
    print("=" * 70)
    print("P.4 — RG RUNNING EXECUTABLE")
    print("=" * 70)

    # Start at electron mass scale
    alpha_me = 1/137.036
    m_e = 0.511e-3  # GeV
    m_z = 91.2  # GeV

    # Headline: run with THE script's model (N_F), not a per-call override.
    alpha_mz = run_alpha(alpha_me, m_e, m_z)

    print(f"\nalpha(m_e = {m_e} GeV) = 1/{1/alpha_me:.3f}")
    print(f"alpha(M_Z = {m_z} GeV) = 1/{1/alpha_mz:.3f}")
    print(f"\nThe 'intrinsic charge' changed by ~6% between encounter scales.")
    print(f"At mu -> infinity (no encounter scale): alpha diverges (Landau pole).")

    # Show running at several scales — same model, no silent default.
    print("\nScale dependence (encounter-indexing made explicit):")
    table = {}
    for mu, label in [(0.511e-3, "m_e"), (1.0, "1 GeV"), (91.2, "M_Z")]:
        a = run_alpha(alpha_me, m_e, mu) if mu > m_e else alpha_me
        table[label] = a
        print(f"  alpha({label:>5}) = 1/{1/a:.2f}")

    # v15 regression: the headline MUST equal the table's M_Z entry.
    # One model, one beta function, one answer.
    assert table["M_Z"] == alpha_mz, (
        f"REGRESSION FAIL: headline alpha(M_Z)=1/{1/alpha_mz:.3f} != "
        f"table alpha(M_Z)=1/{1/table['M_Z']:.3f} — two models in one script."
    )
    print("\nREGRESSION PASS: headline and table use one running model.")

    print("\n" + "-" * 70)
    print("INTERPRETATION")
    print("-" * 70)
    print("Ask: 'what is the intrinsic charge, independent of encounter scale?'")
    print("The RG equation answers: there is no such thing.")
    print("  - At every finite mu: alpha(mu) is finite but mu-indexed.")
    print("  - At mu -> inf (scale-free): alpha diverges (meaningless).")
    print("The 'intrinsic charge -e' of textbooks is alpha(m_e) with the")
    print("(m_e) subscript dropped. The subscript IS the encounter-indexing.")
    print("Dropping it doesn't reveal the intrinsic value — it hides the")
    print("fact that there isn't one.")
    print("\nP.4 VERDICT: QED's own equations encounter-index the charge.")
    print("  'Intrinsic charge' is the mu -> dropped limit, which does not exist.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
