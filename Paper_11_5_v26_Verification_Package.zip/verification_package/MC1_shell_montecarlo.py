#!/usr/bin/env python3
"""MC.1 — Structural Monte Carlo: inverse-square scaling from shell counting.

Paper 11 §8.5 derives S(d) = s^2 / (4d^2 + 2): the per-position share of scan
workload over relay-hop shells, with N(d) = 4d^2 + 2 from Paper 10 §5.3.1
(taxicab shell count) and uniform load partition (Paper 10 §2.4.7).

HEADLINE [LEVEL A: MACHINE / AUTHOR]: the fitted exponent -1.9886 — the REAL number, recomputed
live by this script. MACHINE half: step 3 fits a least-squares line to
(log d, log(1/(4d^2+2))) over d = 5..20, prints the slope (-1.9885612518827713),
and asserts it rounds to -1.9886. AUTHOR half: the slope IS the handshake cost,
and -1.9886 at 4dp IS the real number — author-stipulated 2026-10-18
("we're not rounding nothing"). This is the cost of the
communicative handshake between discrete shells producing emergent
inverse-square; nothing is lost, -2 recovers asymptotically (D2 handshake
framing). The number IS the fit.

KEEP+DISCLOSE (author-authorized 2026-10-18 — "use it when we need it, and
disclose why"): this script DOES use continuum-adjacent machinery — math.log
and a least-squares fit — because the handshake cost is defined as the fitted
exponent, and no integer-only route yields it. The fit is the computation, not
scaffolding around the computation. It is used only here, and it is disclosed
fully here. Per the §0.5.1 framework-wide rule, no approximation or translator
ever stands in for the real number: the real -1.9886 is badged [LEVEL A: MACHINE / AUTHOR]
beside every auxiliary form.

Steps:
1. Shell count: brute-force integer lattice count vs 4d^2+2 (unchanged).
2. Workload sampling: seeded INTEGER rng (random.Random.randrange, which draws
   from the Mersenne Twister bit-generator via getrandbits — integer-native,
   never a float). Genuine sampling check: every shell position's time-averaged
   share must concentrate within a rational tolerance of 1/N(d), verified by
   exact integer comparisons. (The v23 script's printed "MC share" was
   algebraically identical to theory by construction — sum(totals) is forced —
   so it tested nothing; this step now tests what the sampling actually does.)
3. Fitted exponent [LEVEL A: MACHINE / AUTHOR]: log-log least-squares slope of 1/(4d^2+2) over
   d = 5..20 — recomputed, printed, asserted to round to -1.9886.
4. [LEVEL B] AUXILIARY: the exact-rational bound |R(d) - 1| < 1/d^2,
   decreasing monotonically, for d = 5..19, where
       R(d) = [N(d+1)/N(d)] / [(d+1)^2/d^2].
   Why it exists: it states the +2 correction's decay in exact rational
   arithmetic — a translator/convenience bound for readers who want the gap
   without the fit. It is NOT the headline. The real number is the fitted
   exponent -1.9886 [LEVEL A: MACHINE / AUTHOR], badged right beside it.

HONEST SCOPE (unchanged from v23):
- The uniformity assumption is inherited (Paper 10 Uniform Load Partition).
  The MC assumes uniform random selection, so it verifies
  "uniform sampling -> 1/d^2 frequencies" (consistency), not uniformity itself.
- The shell count check (step 1) IS independent: brute force vs formula.
- This is structural MC (ledger consistency), not dynamical MC (no detector
  predictions). Absolute scale is out of scope (Paper 11 §0.5 architecture).
- The fill rules — which encounter actualizes with what probability at a
  given tick — are Paper 12's work (§11.6); nothing here certifies them.

INPUT_PROVENANCE:
  - N(d) = 4d^2+2: class=cited-paper (Paper 10 §5.3.1).
  - Uniform load partition: class=cited-paper (Paper 10 §2.4.7; assumed here).
  - S(d) = s^2/N(d): class=paper-defined (Paper 11 §8.5 derivation).
  - RNG: class=control (seeded Mersenne Twister, integer draws only).
  - Fitted exponent -1.9886: class=paper-defined (Paper 11.5 §11.4; the D2
    handshake cost, author-authorized 2026-10-18 — defined as the log-log
    fitted exponent, which is why math.log/least-squares are used and
    disclosed rather than integer-native).
  - Exact-rational bound: class=cited-paper (Paper 10 §5.3.1 N(d), exact
    rational arithmetic; carried as a [LEVEL B] translator, not the headline).
"""
import math
import random
import sys
from fractions import Fraction


def taxicab_shell_count(d):
    """Brute-force count of integer lattice points with |x|+|y|+|z| = d."""
    count = 0
    for x in range(-d, d + 1):
        for y in range(-d, d + 1):
            for z in range(-d, d + 1):
                if abs(x) + abs(y) + abs(z) == d:
                    count += 1
    return count


def formula_N(d):
    return 4 * d * d + 2


def mc_workload_counts(d, s2=36, n_ticks=20000, seed=12345):
    """Integer-native workload sampling. Returns per-position tick totals.

    Uses random.Random(...).randrange(N) ONLY. CPython's randrange draws from
    getrandbits (the Mersenne Twister bit-generator): pure integer arithmetic,
    no float RNG, no continuous sampling measure.
    """
    rng = random.Random(seed + d)
    N = formula_N(d)
    totals = [0] * N
    for _ in range(n_ticks):
        for _ in range(s2):
            totals[rng.randrange(N)] += 1
    return totals


def loglog_fit_exponent(d_min=5, d_max=20):
    """Least-squares slope of log(1/(4d^2+2)) against log(d).

    [LEVEL A: MACHINE / AUTHOR] computation: the fitted exponent is the real number this script
    badges. math.log and the normal equations are used AND disclosed — the
    number IS the fit (see KEEP+DISCLOSE in the docstring).
    """
    xs, ys = [], []
    for d in range(d_min, d_max + 1):
        xs.append(math.log(d))
        ys.append(math.log(1 / (4 * d * d + 2)))
    n = len(xs)
    sx = sum(xs)
    sy = sum(ys)
    sxx = sum(x * x for x in xs)
    sxy = sum(x * y for x, y in zip(xs, ys))
    return (n * sxy - sx * sy) / (n * sxx - sx * sx)


def planted_mutants():
    """Mutant battery. Each mutant breaks a load-bearing assumption; the
    script's checks must catch it (report the failure) — proving the checks
    are genuine, not vacuous."""
    print("\n--- PLANTED MUTANTS ---")
    results = []

    # M1: wrong shell formula N(d) = 4d^2+3. Step 1 must MISMATCH.
    m1_caught = any(taxicab_shell_count(d) != 4 * d * d + 3 for d in range(1, 11))
    results.append(("M1: wrong shell formula (4d^2+3) rejected by brute force",
                    m1_caught))

    # M2: degenerate RNG (all workload to position 0). Step 2's concentration
    # check must FAIL — proving it tests the sampling, not the algebra.
    s2, n_ticks = 36, 20000
    d = 10
    N = formula_N(d)
    totals = [0] * N
    totals[0] = s2 * n_ticks  # mutant: everything piles on one position
    worst = max(abs(N * t - s2 * n_ticks) for t in totals)
    m2_caught = not (Fraction(worst, s2 * n_ticks) < Fraction(1, 4))
    results.append(("M2: degenerate sampler rejected by concentration check",
                    m2_caught))

    # M3: wrong scaling theory — cubic shells N(d) = 4d^3+2. Step 4's
    # correction bound must FAIL somewhere: the analysis discriminates d^2
    # from d^3 shells, proving it tests the shell geometry, not just
    # arithmetic.
    def N_cubic(d):
        return 4 * d ** 3 + 2

    m3_caught = any(
        abs(Fraction(N_cubic(d + 1), N_cubic(d))
            / Fraction((d + 1) * (d + 1), d * d) - 1) >= Fraction(1, d * d)
        for d in range(5, 20))
    results.append(("M3: cubic-shell theory rejected by correction bound",
                    m3_caught))

    # M4: cubic-shell data 1/(4d^3+2) through the step-3 fit. The fitted
    # exponent must NOT land on -1.9886 — proving the fit discriminates shell
    # geometry (d^2 vs d^3), i.e. the fit tests something real rather than
    # echoing its own input.
    xs = [math.log(d) for d in range(5, 21)]
    ys = [math.log(1 / (4 * d ** 3 + 2)) for d in range(5, 21)]
    n = len(xs)
    sx, sy = sum(xs), sum(ys)
    sxx = sum(x * x for x in xs)
    sxy = sum(x * y for x, y in zip(xs, ys))
    cubic_exp = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    m4_caught = round(cubic_exp, 4) != -1.9886
    results.append((f"M4: cubic-shell fit ({round(cubic_exp, 4)}) != -1.9886 — "
                    "fit discriminates shell geometry",
                    m4_caught))

    all_caught = True
    for name, caught in results:
        print(f"  [{'CAUGHT' if caught else 'NOT CAUGHT — INVESTIGATE'}] {name}")
        all_caught &= caught
    return all_caught


def main():
    print("=" * 70)
    print("MC.1 — STRUCTURAL MONTE CARLO: INVERSE-SQUARE FROM SHELL COUNTING")
    print("  (v24 rulings fold-in: fitted exponent -1.9886 restored as the real")
    print("   [LEVEL A: MACHINE / AUTHOR] number; fit machinery KEEP+DISCLOSED — the number IS the fit)")
    print("=" * 70)

    # Step 1: independent shell count verification
    print("\n--- Step 1: Taxicab shell count (brute force vs Paper 10 formula) ---")
    step1_ok = True
    for d in range(1, 11):
        brute = taxicab_shell_count(d)
        form = formula_N(d)
        match = "OK" if brute == form else "MISMATCH"
        if brute != form:
            step1_ok = False
        print(f"  d={d:2d}: brute force = {brute:4d},  4d^2+2 = {form:4d}  [{match}]")
    if not step1_ok:
        print("SHELL COUNT MISMATCH — Paper 10 formula fails. FAIL.")
        return 1
    print("  Paper 10 §5.3.1 N(d) = 4d^2+2 independently confirmed.")

    # Step 2: genuine sampling check — concentration of per-position shares.
    # Per-position time-average share_i = totals[i]/(s2*n_ticks); theory 1/N.
    # Exact integer check: |N*totals[i] - s2*n_ticks| < (s2*n_ticks)/4
    # i.e. every position within relative 1/4 of the uniform share.
    print("\n--- Step 2: Integer-native workload sampling (concentration) ---")
    print("  (seeded integer RNG; exact rational deviation bound 1/4)")
    s2, n_ticks, seed = 36, 20000, 12345
    step2_ok = True
    for d in range(1, 21):
        totals = mc_workload_counts(d, s2, n_ticks, seed)
        N = formula_N(d)
        if sum(totals) != s2 * n_ticks:
            print(f"  d={d:2d}: WORKLOAD NOT CONSERVED — FAIL.")
            step2_ok = False
            continue
        worst = max(abs(N * t - s2 * n_ticks) for t in totals)
        rel = Fraction(worst, s2 * n_ticks)
        ok = rel < Fraction(1, 4)
        step2_ok &= ok
        print(f"  d={d:2d}: N={N:4d}, worst relative deviation = {rel} "
              f"≈ {float(rel):.4f}  [{'OK' if ok else 'FAIL'}]")
    if not step2_ok:
        print("SAMPLING CONCENTRATION FAILED — investigate.")
        return 1
    print("  Discrete uniform sampling concentrates on 1/N(d) at every d.")

    # Step 3: the fitted exponent [LEVEL A: MACHINE / AUTHOR] — recomputed live.
    # KEEP+DISCLOSE: math.log and least squares are USED and DISCLOSED because
    # the handshake cost is defined as the fitted exponent — no integer-only
    # route yields it. The number IS the fit.
    print("\n--- Step 3: Log-log fit of 1/(4d^2+2), d = 5..20 [LEVEL A: MACHINE / AUTHOR] ---")
    print("  (fit machinery used and disclosed: the number IS the fit)")
    exp = loglog_fit_exponent(5, 20)
    print(f"  fitted exponent = {exp!r}")
    if round(exp, 4) != -1.9886:
        print(f"FITTED EXPONENT {exp} does not round to -1.9886 — FAIL.")
        return 1
    print("  rounds to -1.9886 [LEVEL A: MACHINE / AUTHOR] — the handshake's price, recomputed live.")

    # Step 4: exact-rational translator [LEVEL B] — auxiliary, not the headline.
    # Why it exists: the +2 correction's decay in exact rational arithmetic,
    # for readers who want the gap without the fit. The real number -1.9886
    # [LEVEL A: MACHINE / AUTHOR] stands badged beside it (§0.5.1 rule).
    print("\n--- Step 4: Exact rational bound [LEVEL B auxiliary] ---")
    print("  (|R(d)-1| < 1/d^2, decreasing, d = 5..19 — the convenience")
    print("   translator beside the real number -1.9886 [LEVEL A: MACHINE / AUTHOR]; see docstring)")
    step4_ok = True
    prev_corr = None
    for d in range(5, 20):
        ratio = Fraction(formula_N(d + 1), formula_N(d))
        R = ratio / Fraction((d + 1) * (d + 1), d * d)
        corr = abs(R - 1)
        bound_ok = corr < Fraction(1, d * d)
        mono_ok = (prev_corr is None) or (corr < prev_corr)
        step4_ok &= bound_ok and mono_ok
        print(f"  d={d:2d}: N({d+1})/N({d}) = {ratio} ; correction |R-1| = {corr} "
              f"< 1/{d*d} [{'OK' if bound_ok and mono_ok else 'FAIL'}]")
        prev_corr = corr
    if not step4_ok:
        print("AUXILIARY BOUND FAILED — investigate.")
        return 1

    print("\n" + "=" * 70)
    print("MC.1 VERDICT: inverse-square scaling from discrete uniform sampling")
    print("  over taxicab shells.")
    print("  Headline [LEVEL A: MACHINE / AUTHOR]: the fitted exponent -1.9886, recomputed live —")
    print("  the handshake's price at the communication between discrete shells;")
    print("  -2 recovered asymptotically. The fit machinery is used and disclosed")
    print("  (KEEP+DISCLOSE): the number IS the fit.")
    print("  Beside it [LEVEL B]: the exact-rational translator |R(d)-1| < 1/d^2,")
    print("  decreasing — the convenience bound, labeled with why it exists.")
    print("  The shell formula N(d) = 4d^2+2 is independently confirmed (step 1);")
    print("  uniform integer sampling concentrates on 1/N(d) (step 2).")
    print("  (Uniformity assumed per Paper 10; absolute scale out of scope.)")

    mutants_ok = planted_mutants()
    return 0 if mutants_ok else 1


if __name__ == "__main__":
    sys.exit(main())
