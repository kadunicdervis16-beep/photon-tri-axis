#!/usr/bin/env python3
"""P.10 — g-2 loop spectrum: QED vertex-diagram counts per loop order.

Tabulates how many Feynman diagrams the QED vertex correction contains at
each loop order: 1, 7, 72, 891, 12672.

INPUT_PROVENANCE:
  - Diagram generator (1- and 2-loop counts): paper-defined. The encoded
    rules are DECLARED ASSUMPTIONS of the counting exercise, printed below:
      (a) every internal vertex is a QED 3-point vertex (2 fermion stubs +
          1 photon stub);
      (b) external legs fixed: 1 incoming fermion, 1 outgoing fermion,
          1 photon; isomorphisms must fix all three (fermion direction
          fixes the open line pointwise);
      (c) Furry's theorem: a closed fermion loop carries an even number
          (>= 2) of photon vertices — C-odd amplitudes vanish;
      (d) proper-vertex filter: the amputated (internal-line) graph must be
          connected and bridgeless (1PI) — external-leg self-energies and
          vertex-reducible graphs are not counted, matching the
          Kinoshita-program convention for a_e.
    The COUNTS (1 and 7) are DERIVED: the generator enumerates every
    stub-pairing at the given loop order and quotients by graph
    isomorphism via brute-force canonical labeling. Nothing about the
    answers is hardcoded; the assertions check the machine's results.
  - 72 / 891 / 12672 (3-, 4-, 5-loop): class=cited-paper, reproduced as
    the published record, explicitly NOT derived here:
      72:    T. Kinoshita, Phys. Rev. Lett. 75, 4728 (1995) — numerical
             sixth order; analytic: S. Laporta & E. Remiddi,
             Phys. Lett. B 379, 283 (1996).
      891:   T. Kinoshita & W. B. Lindquist, Phys. Rev. Lett. 47, 1573
             (1981); revised: T. Aoyama, M. Hayakawa, T. Kinoshita &
             M. Nio, Phys. Rev. D 77, 053012 (2008).
      12672: T. Aoyama, M. Hayakawa, T. Kinoshita & M. Nio,
             Phys. Rev. Lett. 109, 111807 (2012);
             Phys. Rev. D 85, 033007 (2012).
    Enumerating 72+ diagrams by hand-generation is beyond this script's
    scope; the literature values are carried as oracle with provenance.

Structural point (v15 honest-scope narrowing, machine-backed): the vertex correction at
every loop order IS a sum over N discrete diagrams — 1 -> 7 -> 72 -> 891 ->
12672. Each diagram is evaluated by continuum loop integrals (the paper's
own §3.6(b); §11.6 admits the continuum upstream in the formulas); the
integer count N is the discrete, convention-indexed signature — the
proper-vertex (1PI) count used by the Kinoshita program. The growth is
visible at order one no less than order five, not a 5-loop accident.
"""
import sys
import itertools


# ---------------------------------------------------------------------------
# Small graph utilities (brute force; graphs are tiny)
# ---------------------------------------------------------------------------

def _pairings(items):
    """Yield all perfect matchings of `items` (length must be even)."""
    if not items:
        yield []
        return
    a = items[0]
    for i in range(1, len(items)):
        b = items[i]
        rest = items[1:i] + items[i + 1:]
        for sub in _pairings(rest):
            yield [(a, b)] + sub


def _compositions(total, parts):
    """Yield all compositions of `total` into `parts` positive parts."""
    if parts == 1:
        yield (total,)
        return
    for first in range(1, total - parts + 2):
        for sub in _compositions(total - first, parts - 1):
            yield (first,) + sub


def _connected(n, edges):
    adj = [[] for _ in range(n)]
    for a, b in edges:
        adj[a].append(b)
        adj[b].append(a)
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for w in adj[u]:
            if w not in seen:
                seen.add(w)
                stack.append(w)
    return len(seen) == n


def _has_bridge(n, edges):
    """True if any edge is a bridge (brute force; n is tiny)."""
    adj = [[] for _ in range(n)]
    for a, b in edges:
        adj[a].append(b)
        adj[b].append(a)
    for (a, b) in edges:
        seen = {a}
        stack = [a]
        while stack:
            u = stack.pop()
            for w in adj[u]:
                if (u == a and w == b) or (u == b and w == a):
                    continue
                if w not in seen:
                    seen.add(w)
                    stack.append(w)
        if b not in seen:
            return True
    return False


# ---------------------------------------------------------------------------
# QED vertex-diagram generator
# ---------------------------------------------------------------------------

def _canonical(E0, loop_v, partner, ext):
    """Canonical signature under all allowed relabelings.

    The open line is fixed pointwise: fermion edges are directed and the
    external in/out legs are fixed, so the directed f_in -> f_out path is
    unique. Only closed loops may be permuted / rotated / reflected.
    """
    nj = len(loop_v)
    best = None
    for perm in itertools.permutations(range(nj)):
        dihedral = []
        for j in perm:
            m = len(loop_v[j])
            opts = []
            for s in range(m):
                opts.append(tuple((s + r) % m for r in range(m)))
                opts.append(tuple((s - r) % m for r in range(m)))
            dihedral.append((j, opts))
        for combo in itertools.product(*[o for _, o in dihedral]):
            newloops = []
            for (j, _), order in zip(dihedral, combo):
                newloops.append([loop_v[j][r] for r in order])

            def rep(v):
                if v == ext:
                    return ("X",)
                p = partner[v]
                if p < E0:
                    return ("o", p)
                for pi, nl in enumerate(newloops):
                    if p in nl:
                        return ("l", pi, nl.index(p))
                raise AssertionError("partner vertex not found")

            open_sig = tuple(rep(i) for i in range(E0))
            loop_sig = tuple(tuple(rep(v) for v in nl) for nl in newloops)
            sig = (open_sig, loop_sig)
            if best is None or sig < best:
                best = sig
    return best


def vertex_diagrams(L):
    """Return the set of canonical signatures of proper QED vertex
    diagrams at L loops.  Empty-loop edge cases and tadpoles are
    excluded by the Furry filter (even >= 2 vertices per closed loop)."""
    E_total = 2 * L + 1  # one endpoint carries the external photon
    sigs = set()
    for k in range(1, L + 2):  # k fermion lines; closed loops <= L
        for comp in _compositions(E_total, k):
            E0 = comp[0]
            loop_lens = comp[1:]
            if any(m % 2 == 1 or m < 2 for m in loop_lens):
                continue  # Furry: closed loop needs even >= 2 vertices
            open_v = list(range(E0))
            loop_v = []
            base = E0
            for m in loop_lens:
                loop_v.append([base + r for r in range(m)])
                base += m
            assert base == E_total
            # internal fermion segments
            fsegs = [(i, i + 1) for i in range(E0 - 1)]
            for lv in loop_v:
                m = len(lv)
                fsegs += [(lv[r], lv[(r + 1) % m]) for r in range(m)]
            verts = list(range(E_total))
            for ext in verts:
                rest = [v for v in verts if v != ext]
                for pairing in _pairings(rest):
                    partner = {}
                    for a, b in pairing:
                        partner[a] = b
                        partner[b] = a
                    pedges = [(min(a, b), max(a, b)) for a, b in pairing]
                    edges = fsegs + pedges
                    if not _connected(E_total, edges):
                        continue
                    if _has_bridge(E_total, edges):
                        continue  # not a proper (1PI) vertex diagram
                    sigs.add(_canonical(E0, loop_v, partner, ext))
    return sigs


# Cited literature oracle (NOT derived here; see INPUT_PROVENANCE).
ORACLE = {
    3: (72, "Kinoshita PRL 75, 4728 (1995); Laporta-Remiddi PLB 379, 283 (1996)"),
    4: (891, "Kinoshita-Lindquist PRL 47, 1573 (1981); Aoyama et al. PRD 77, 053012 (2008)"),
    5: (12672, "Aoyama-Hayakawa-Kinoshita-Nio PRL 109, 111807 (2012); PRD 85, 033007 (2012)"),
}


def main():
    print("=" * 70)
    print("P.10 — g-2 LOOP SPECTRUM")
    print("QED vertex-diagram counts per loop order")
    print("=" * 70)
    print("\nRules (declared assumptions): QED 3-point vertices; external")
    print("legs fixed (f_in, f_out, photon); Furry (even >= 2 vertices per")
    print("closed fermion loop); proper-vertex filter (amputated graph")
    print("connected and bridgeless). Counts are DERIVED by the generator,")
    print("not hardcoded.\n")

    derived = {}
    for L in (1, 2):
        sigs = vertex_diagrams(L)
        derived[L] = len(sigs)
        print(f"  {L}-loop: {len(sigs)} diagrams (derived by enumeration)")

    # The generator must reproduce the textbook counts — or fail loudly.
    assert derived[1] == 1, f"1-loop count came out {derived[1]}, expected 1"
    assert derived[2] == 7, f"2-loop count came out {derived[2]}, expected 7"
    print("\nDERIVATION CHECK PASS: 1-loop -> 1, 2-loop -> 7.")

    print("\nLoop-order spectrum (derived + cited oracle):")
    print("-" * 70)
    print(f"  {'order':>5} | {'diagrams':>8} | status")
    print("-" * 70)
    for L in range(1, 6):
        if L in derived:
            print(f"  {L:>5} | {derived[L]:>8} | DERIVED (this script)")
        else:
            n, ref = ORACLE[L]
            print(f"  {L:>5} | {n:>8} | CITED ORACLE — {ref}")
    print("-" * 70)

    print("\nP.10 VERDICT: the vertex correction at every loop order IS a sum")
    print("over N discrete diagrams — each evaluated by continuum loop")
    print("integrals; the integer count N (1 -> 7 -> 72 -> 891 -> 12672) is")
    print("the discrete, convention-indexed signature. The 'intrinsic' moment")
    print("is the sum; there is no bare remainder.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
