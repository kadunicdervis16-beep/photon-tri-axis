#!/usr/bin/env python3
"""G.1 — Quote integrity verifier for Paper 11.5.

Checks: every subsection of §2 that contains blockquotes also contains at least
one attribution line ("> —" with work and year). Multiple quotes may share one
attribution from the same work — the gate is coverage, not 1:1 pairing.
Draft resolution (v19 fallback chain): argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft file is printed on every run.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


# Portable draft resolution (v14 hardening; v19 fallback chain):
# argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
# newest paper_11_5_v<N>.md. $PAPER_MD at a nonexistent file falls through;
# argv[1] is honored verbatim (unchanged pre-v19 behavior, including
# fail-on-nonexistent input). The helper is inlined: scripts stay
# standalone, no shared imports.
DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()

s2_start = text.find("## 2 &nbsp; HISTORICAL DISSENT")
s2_end = text.find("## 3 &nbsp;", s2_start)
s2 = text[s2_start:s2_end]

# Split into subsections
subs = re.split(r"(### 2\.\d+)", s2)
issues = []
total_quotes = 0
for i in range(1, len(subs), 2):
    header = subs[i]
    body = subs[i+1] if i+1 < len(subs) else ""
    quotes = len(re.findall(r"^> [^—]", body, re.M))
    # Attribution can be: "> — *Work* (year)" line OR "Author, *Work* (year):" in subsection intro
    attrs = re.findall(r"^> — .+\(\d{4}\)", body, re.M)
    header_attrs = re.findall(r"\*[^*]{5,}\* \(\d{4}\)", body)
    total_attrs = len(attrs) + len(header_attrs)
    total_quotes += quotes
    if quotes > 0 and total_attrs == 0:
        issues.append(f"{header.strip()}: {quotes} quotes but no attribution")
    for a in attrs:
        if not re.search(r"\*", a):
            issues.append(f"{header.strip()}: attribution not naming a work: {a[:60]}")

print(f"Draft: {DRAFT}")
print(f"Quote lines in §2: {total_quotes}")
if issues:
    print("ISSUES:")
    for iss in issues:
        print(f"  - {iss}")
    sys.exit(1)
print(f"G.1 PASS: all quoted subsections carry sourced attributions.")
