#!/usr/bin/env python3
"""P.9 — Ternary-outcome and tether analysis of Bell-CHSH for Paper 11.5.

Formalizes the framework's 3-axis critique of Bell-type tests as machine checks.

The framework's position (lab notes: "The Bell Test Fallacy"; "The Binary Trap"):
  (a) Per measurement axis there are THREE states: +1, -1, and 0 (neutral).
      The neutral is load-bearing (the (0,0,0) photon baseline; Gluon 4 anchor).
      CHSH admits only binary (+-1) outcomes: zeros are erased (P.2 assigns
      ties by fiat) and nulls are discarded unpublished.
  (b) Bell assumes the two particles are independent ("container-void").
      In SPDC they are one tethered geometric structure; the violation evidences
      the tether's rigidity, not "spooky action."

INTEGER-NATIVE (v24 FORTRESS): no arccos, no uniform-sphere RNG, no floats.
The hidden-variable ensemble is DETERMINISTIC: all nonzero integer triples
(i,j,k) with i^2+j^2+k^2 <= 12^2 (7,152 orientations — no sampling, no seed).
All projections are exact integer comparisons (squaring with sign care);
all correlators are exact Fractions. DELTA = 3/20 is an exact rational
threshold, not a float. The v23 "assumed scaffolding [CLASSIFIED]"
(uniform-over-the-sphere measure) is GONE — there is no measure to assume.

What this script checks:
  1. PROJECTION-DEPENDENCE: a local ternary hidden-variable model (definite
     tilt axis per particle, neutral band for near-orthogonal tilts) generates
     ternary data; CHSH's S is then computed under four handlings of 0.
     Result: the verdict moves with the projection rule -> the binary verdict
     is conditional on a data-processing choice absent from the physics.
     Verified at DELTA in {1/10, 3/20, 1/5}: the spread scales with DELTA.
  2. LOCAL TERNARY BOUND (machine-proved): brute force over all 81 deterministic
     {+1,-1,0} assignments shows max|S| = 2. Ternary outcomes do NOT lift the
     local bound. (Honesty: the "binary trap" is representational; the
     phenomenon is not a binary artifact.)
  3. TETHER MODEL: one shared geometric hidden variable (the tether state),
     outcomes computed jointly from BOTH settings (non-separable). Deterministic,
     reproduces E(a,b) = -a.b (exact rational bracket) and S within 0.04 of
     2*sqrt(2). This is an existence proof: deterministic + pre-existing
     structure + CHSH violation is consistent. Bell excludes SEPARABILITY,
     not structure. The |S - 2√2| < TOL check is done by exact rational
     bracketing (see S_IN_BRACKET below) — no floats.

What this script does NOT show (stated limits):
  - It does not derive the tether's gear-mechanics; the tether response is
    schematic (a joint threshold). It formalizes the LOGICAL point
    (non-separability suffices), not the full mechanical model.
  - The ternary-local bound means "add the neutral" alone does not reproduce QM.
    A critic citing CGLMP (ternary Bell inequalities, also violated) is correct
    about the phenomenon; our point is about the TEST's representational scope.
  - Bell's theorem (the mathematics) is not refuted and cannot be: it is proven.
    What is refuted is its USE as an ontological verdict ("Ontology B won").
    The test adjudicates separable binary-outcome models. Nothing more.
  - On the integer lattice, exact ties (orthogonality) carry positive weight —
    the v23 "measure-zero" language does not transfer. Tie-handling is by fiat
    and stated; Part 1's verdict is checked robust across DELTA values.

INPUT_PROVENANCE:
  - Ternary-outcome structure (+1/-1/0 per axis): class=paper-defined
    (framework posit; the neutral anchor).
  - DELTA = 3/20 neutral-band half-width: class=declared-assumption
    (a framework posit — the neutral anchor's width — not derived; exact
    rational, not a float; finding verified at 1/10 and 1/5 as well).
  - Tether joint-threshold response: class=paper-defined (schematic; the
    logical point is non-separability, not the mechanism).
  - Orientation ensemble: class=control (deterministic integer lattice R=12).
  - CHSH bound / singlet E(a,b) = -a.b: class=cited-paper.
"""
import sys
from fractions import Fraction
from itertools import product

GRID_R = 12          # deterministic integer-lattice radius (7,152 orientations)
DELTA = Fraction(3, 20)   # neutral band half-width: |m.n| <= DELTA -> 0 (exact)
TOL = Fraction(1, 25)     # = 0.04, exact


def lattice_orientations(R=GRID_R):
    """Deterministic hidden-variable ensemble: every nonzero integer triple
    (i,j,k) with i^2+j^2+k^2 <= R^2. Returns (i, j, k, i^2+j^2+k^2)."""
    pts = []
    R2 = R * R
    for i in range(-R, R + 1):
        for j in range(-R, R + 1):
            for k in range(-R, R + 1):
                n2 = i * i + j * j + k * k
                if 0 < n2 <= R2:
                    pts.append((i, j, k, n2))
    return pts


def sgn(v):
    """sign with ties -> +1 by fiat (stated)."""
    return 1 if v >= 0 else -1


# ---------------------------------------------------------------------------
# Part 1: local ternary model. Projections as exact integer comparisons.
# Neutral iff (m.n)^2 <= DELTA^2 (m.m)(n.n); DELTA^2 = 9/400.
#   axis a=(0,0,1): m.n = k            -> 400 k^2        <= 9 n2
#   axis a'=(1,0,0): m.n = i           -> 400 i^2        <= 9 n2
#   axis b (45°): m.n = (i+k)/√2       -> 200 (i+k)^2   <= 9 n2
#   axis b' (135°): m.n = (i-k)/√2     -> 200 (i-k)^2    <= 9 n2
# ---------------------------------------------------------------------------
def gen_local_ternary(pts, delta=DELTA):
    """Local ternary hidden-variable model. Each particle carries its own
    definite tilt axis (m1 = lattice orientation; m2 = -m1, singlet-like).
    Outcomes depend ONLY on own state + own setting. Ternary, deterministic."""
    dn, dd = delta.numerator, delta.denominator
    out = {"a": [], "ap": [], "b": [], "bp": []}
    for (i, j, k, n2) in pts:
        o_a = 0 if (k * k * dd * dd <= dn * dn * n2) else (1 if k > 0 else -1)
        o_ap = 0 if (i * i * dd * dd <= dn * dn * n2) else (1 if i > 0 else -1)
        sp, sm = i + k, i - k
        o_b = 0 if (sp * sp * dd * dd <= 2 * dn * dn * n2) else (1 if sp > 0 else -1)
        o_bp = 0 if (sm * sm * dd * dd <= 2 * dn * dn * n2) else (1 if sm > 0 else -1)
        out["a"].append(o_a)
        out["ap"].append(o_ap)
        out["b"].append(o_b)
        out["bp"].append(o_bp)
    return out


def E_of(X, Y, rule):
    """Correlator under projection rule for zeros. Exact Fraction."""
    n = len(X)
    if rule == "zero_to_plus1":
        return Fraction(sum((1 if x == 0 else x) * (1 if y == 0 else y)
                            for x, y in zip(X, Y)), n)
    if rule == "zero_to_minus1":
        return Fraction(sum((-1 if x == 0 else x) * (-1 if y == 0 else y)
                            for x, y in zip(X, Y)), n)
    if rule == "drop_zeros":
        vals = [x * y for x, y in zip(X, Y) if x != 0 and y != 0]
        return Fraction(sum(vals), len(vals))
    if rule == "keep_zeros":
        return Fraction(sum(x * y for x, y in zip(X, Y)), n)
    raise ValueError(rule)


def S_under_rule(out, rule):
    Eab = E_of(out["a"], out["b"], rule)
    Eabp = E_of(out["a"], out["bp"], rule)
    Eapb = E_of(out["ap"], out["b"], rule)
    Eapbp = E_of(out["ap"], out["bp"], rule)
    return abs(Eab - Eabp + Eapb + Eapbp)


def brute_force_ternary_bound():
    """Max |AB - AB' + A'B + A'B'| over all deterministic {+1,-1,0}
    assignments. Machine-proved local ternary bound."""
    best = 0
    witness = None
    for vals in product((-1, 0, 1), repeat=4):
        A, Ap, B, Bp = vals
        s = abs(A * B - A * Bp + Ap * B + Ap * Bp)
        if s > best:
            best = s
            witness = vals
    return best, witness


# ---------------------------------------------------------------------------
# Part 3: tether. T = +1 iff tau.d > -(a.b), d = z-axis, tau.d = k/|tau|.
# Threshold specs: ("s", +1) means a.b = +1/√2; ("q", num, den) means a.b =
# num/den exactly. All comparisons integer-exact (squaring with sign care).
# E[A*B] = -E[T] since B = -A*T and A^2 = 1.
# ---------------------------------------------------------------------------
def tether_T(k, n2, spec):
    kind = spec[0]
    if kind == "s":
        s = spec[1]  # +1 or -1: threshold ±1/√2
        if s == 1:
            return 1 if (k >= 0 or 2 * k * k < n2) else -1
        else:
            return -1 if (k <= 0 or 2 * k * k <= n2) else 1
    else:
        num, den = spec[1], spec[2]
        if num > 0:
            return 1 if (k >= 0 or k * k * den * den < num * num * n2) else -1
        else:
            m = -num
            return 1 if (k > 0 and k * k * den * den > m * m * n2) else -1


def tether_correlator(pts, A_fn, spec):
    tot = 0
    for (i, j, k, n2) in pts:
        A = A_fn(i, j, k)
        assert A * A == 1, "binary-outcome premise violated"
        T = tether_T(k, n2, spec)
        tot += -T  # A*B = -A*A*T = -T
    return Fraction(tot, len(pts))


def tether_S(pts):
    Eab = tether_correlator(pts, lambda i, j, k: sgn(k), ("s", +1))    # a.b=+1/√2
    Eabp = tether_correlator(pts, lambda i, j, k: sgn(k), ("s", -1))   # a.b=−1/√2
    Eapb = tether_correlator(pts, lambda i, j, k: sgn(i), ("s", +1))   # a'.b=+1/√2
    Eapbp = tether_correlator(pts, lambda i, j, k: sgn(i), ("s", +1))  # a'.b'=+1/√2
    return abs(Eab - Eabp + Eapb + Eapbp)


def S_in_bracket(S):
    """Exact check |S − 2√2| < TOL via rational bracketing — no floats.

    S > 279/100 implies S > 2√2 − 1/25 because 279/100 ≥ 2√2 − 1/25
      ⟺ 283/100 ≥ 2√2 ⟺ 283² ≥ 8·100² ⟺ 80089 ≥ 80000. ✓
    S < 286/100 implies S < 2√2 + 1/25 because 286/100 ≤ 2√2 + 1/25
      ⟺ 282/100 ≤ 2√2 ⟺ 282² ≤ 8·100² ⟺ 79524 ≤ 80000. ✓
    """
    assert 283 * 283 >= 8 * 100 * 100, "bracket witness (lower) broken"
    assert 282 * 282 <= 8 * 100 * 100, "bracket witness (upper) broken"
    return Fraction(279, 100) < S < Fraction(286, 100)


def mutant_severed_tether(pts):
    """PLANTED MUTANT: sever the tether. Bob's outcome uses ONLY his own side
    (own hidden-variable read + own setting): genuinely separable.
    S must fall to the local bound (<= 2). If it does, separability --
    not determinism, not pre-existing structure -- was the load-bearing
    assumption."""
    n = len(pts)

    def E(Xfn, Yfn):
        return Fraction(sum(Xfn(i, j, k) * Yfn(i, j, k)
                            for (i, j, k, n2) in pts), n)

    A = lambda i, j, k: sgn(k)            # noqa: E731
    Ap = lambda i, j, k: sgn(i)           # noqa: E731
    Bb = lambda i, j, k: sgn(-i - k)      # noqa: E731
    Bbp = lambda i, j, k: sgn(-i + k)     # noqa: E731
    return abs(E(A, Bb) - E(A, Bbp) + E(Ap, Bb) + E(Ap, Bbp))


def mutant_joint_blind_tether(pts):
    """PLANTED MUTANT 2: keep the tether structure but make the joint response
    blind to the settings — T = sign(tau.d), the a.b threshold removed.
    If S collapses, the JOINT (both-settings) dependence of T — not merely
    determinism — was load-bearing."""
    n = len(pts)

    def E(A_fn):
        tot = 0
        for (i, j, k, n2) in pts:
            A = A_fn(i, j, k)
            assert A * A == 1, "binary-outcome premise violated"
            tot += -sgn(k)  # T = sign(tau.d), no a.b threshold
        return Fraction(tot, n)

    Eab = E(lambda i, j, k: sgn(k))
    Eapb = E(lambda i, j, k: sgn(i))
    return abs(Eab - Eab + Eapb + Eapb)


def mutant_neutral_erased(pts):
    """PLANTED MUTANT 3 (Part 1): erase the neutral band up front (0 -> +1
    before any projection rule). All four rules then coincide exactly, so the
    spread must be 0 — proving the projection-dependence was carried by the
    neutral band, not by code artifacts."""
    out = gen_local_ternary(pts)
    out_bin = {name: [1 if v == 0 else v for v in vals]
               for name, vals in out.items()}
    rules = ["zero_to_plus1", "zero_to_minus1", "drop_zeros", "keep_zeros"]
    S_vals = [S_under_rule(out_bin, r) for r in rules]
    return max(S_vals) - min(S_vals)


def main():
    print("=" * 70)
    print("P.9 — TERNARY-OUTCOME AND TETHER ANALYSIS OF BELL-CHSH")
    print("  (v24 FORTRESS: integer-native — deterministic lattice, no floats)")
    print("=" * 70)

    pts = lattice_orientations()
    print(f"\nDeterministic orientation ensemble: {len(pts)} integer-lattice "
          f"orientations (R={GRID_R}). No RNG, no sphere sampling.")

    # ---- Part 1: projection-dependence ----
    print("\n--- PART 1: the binary verdict moves with the projection rule ---")
    rules = ["zero_to_plus1", "zero_to_minus1", "drop_zeros", "keep_zeros"]
    for delta in (Fraction(1, 10), DELTA, Fraction(1, 5)):
        out = gen_local_ternary(pts, delta)
        n_zero = sum(1 for a, b in zip(out["a"], out["b"]) if a == 0 or b == 0)
        S_vals = {r: S_under_rule(out, r) for r in rules}
        spread = max(S_vals.values()) - min(S_vals.values())
        print(f"  DELTA={delta}: neutral frac={Fraction(n_zero, len(pts))} "
              f"≈ {n_zero / len(pts):.3f}; " +
              "; ".join(f"S[{r}]={v}≈{float(v):.4f}" for r, v in S_vals.items()))
        print(f"    spread = {spread} ≈ {float(spread):.4f}")
    out = gen_local_ternary(pts)
    S_vals = {r: S_under_rule(out, r) for r in rules}
    spread = max(S_vals.values()) - min(S_vals.values())
    proj_dependent = spread > Fraction(1, 20)
    print("  => " + ("VERDICT IS PROJECTION-CONDITIONAL: the binary S depends on "
                      "how 0 is handled — a data-processing choice, not physics."
                      if proj_dependent else
                      "no projection dependence detected."))

    inflated = S_vals["drop_zeros"] > S_vals["keep_zeros"] + TOL
    print("  drop-zeros vs keep-zeros: "
          + ("INFLATED — post-selection artifact flagged (detection-loophole analog)."
             if inflated else "no inflation."))

    # ---- Part 2: machine-proved local ternary bound ----
    print("\n--- PART 2: machine-proved local ternary bound ---")
    best, witness = brute_force_ternary_bound()
    print(f"  max |AB − AB' + A'B + A'B'| over all 81 deterministic "
          f"{{+1,−1,0}} assignments = {best}  (witness {witness})")
    print("  => ternary outcomes do NOT lift the local bound. The binary trap is")
    print("     representational; the phenomenon is not a binary artifact.")

    # ---- Part 3: tether ----
    print("\n--- PART 3: the tether (non-separable, deterministic) ---")
    S_t = tether_S(pts)
    print(f"  tether S = {S_t} ≈ {float(S_t):.4f}  (target 2√2 ≈ 2.8284)")
    tether_ok = S_in_bracket(S_t)
    print(f"  exact rational bracket 2.79 < S < 2.86 holds: {tether_ok} "
          f"=> |S − 2√2| < 0.04 by the integer-square witnesses.")
    # full correlator check at non-CHSH settings (rational unit vectors,
    # exact thresholds — same logical check as the v23 angle pairs)
    check_pairs = [
        (lambda i, j, k: 3 * i + 4 * k, ("q", 4, 5), "a=(3/5,0,4/5), b=(0,0,1)",
         Fraction(-4, 5)),
        (lambda i, j, k: k, ("q", -4, 5), "a=(0,0,1), b=(3/5,0,−4/5)",
         Fraction(4, 5)),
        (lambda i, j, k: 5 * i + 12 * k, ("q", 12, 13), "a=(5/13,0,12/13), b=(0,0,1)",
         Fraction(-12, 13)),
    ]
    corr_ok = True
    for A_fn, spec, label, target in check_pairs:
        e = tether_correlator(pts, lambda i, j, k: sgn(A_fn(i, j, k)), spec)
        ok = abs(e - target) < TOL
        corr_ok &= ok
        print(f"  E[{label}] = {e} ≈ {float(e):+.4f} vs −a·b = {target}  "
              f"{'OK' if ok else 'MISMATCH'}")
    print("  => deterministic + pre-existing structure + CHSH violation is "
          "consistent. Bell excludes SEPARABILITY, not structure.")
    print("  NOTE (loop-caught, kept): this tether model as coded uses BINARY")
    print("  outcomes; it witnesses non-separability, not the ternary structure —")
    print("  the ternary critique lives in Parts 1–2. The two prongs are presented")
    print("  separately and honestly, not conflated.")

    # ---- Mutants ----
    print("\n--- PLANTED MUTANT 1 (Part 1): erase the neutral up front ---")
    m1 = mutant_neutral_erased(pts)
    m1_caught = (m1 == 0)
    print(f"  spread with neutral erased: {m1}  "
          + ("=> MUTANT KILLED the effect: projection-dependence was carried "
             "by the neutral band, not by code artifacts." if m1_caught
             else "=> UNEXPECTED: spread survives without neutrals."))

    print("\n--- PLANTED MUTANT 2: sever the tether (force separability) ---")
    S_sev = mutant_severed_tether(pts)
    print(f"  severed-tether S = {S_sev} ≈ {float(S_sev):.4f}")
    m2_caught = S_sev <= 2 + TOL and S_t > 2 + TOL
    print("  => " + ("MUTANT REJECTED AS LOCAL: S collapses when separability is "
                      "forced. Separability — not determinism — was load-bearing."
                      if m2_caught else
                      "UNEXPECTED: severed tether still violates. Investigate."))

    print("\n--- PLANTED MUTANT 3: joint response blind to settings ---")
    S_jb = mutant_joint_blind_tether(pts)
    print(f"  joint-blind S = {S_jb} ≈ {float(S_jb):.4f}")
    m3_caught = S_jb <= 2 + TOL
    print("  => " + ("MUTANT REJECTED: without the both-settings threshold, no "
                      "violation — the JOINT dependence was load-bearing."
                      if m3_caught else
                      "UNEXPECTED: joint-blind tether still violates."))

    # ---- Verdicts ----
    print("\n" + "=" * 70)
    print("P.9 VERDICT")
    print("=" * 70)
    checks = [
        ("projection-dependence demonstrated", proj_dependent),
        ("local ternary bound = 2 (machine-proved)", best == 2),
        ("tether reproduces QM correlations", tether_ok and corr_ok),
        ("mutant 1 (neutral erased) kills the spread", m1_caught),
        ("mutant 2 (severed tether) caught as local", m2_caught),
        ("mutant 3 (joint-blind) caught", m3_caught),
    ]
    all_ok = True
    for name, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
        all_ok &= ok

    print("\nINTERPRETATION (what the machine states):")
    print("  1. CHSH as run (P.2) tests SEPARABLE, BINARY-OUTCOME models.")
    print("     Zeros are erased and nulls unpublished — by construction,")
    print("     not by nature. The verdict is conditional on that projection.")
    print("  2. Adding the neutral does not save LOCAL models (bound stays 2).")
    print("     The tether — non-separable by construction — was never in")
    print("     Bell's scope. 'Ontology B won because of Bell' is unwarranted;")
    print("     'Bell excludes all pre-existing structure' is false, witnessed")
    print("     by the tether reaching 2√2-bracket deterministically.")
    print("  3. Limits: the tether response is schematic (joint threshold), not")
    print("     the full gear-mechanics; Bell's mathematics is untouched — only")
    print("     its USE as an ontological verdict is refuted.")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
