#!/usr/bin/env python3
"""P.3 — R-ratio executable for Paper 11.5.

Computes R = sigma(e+e- -> hadrons) / sigma(e+e- -> mu+mu-)
         = N_c * sum_q e_q^2
for active quarks u, d, s (below charm threshold).

Demonstrates: the factor N_c = 3 ("three colors") is doing ALL the work.
It is a representation dimension in a rate formula — not a possessed property.

INTEGER-NATIVE (v24 FORTRESS): charges as exact Fractions; R = 3·(6/9) = 2
exactly. The v23 float arithmetic (2/3 etc.) is replaced by exact rational
arithmetic — the verdict is now an identity, not an approximation.

INPUT_PROVENANCE:
  - R = N_c·Σe_q^2: class=cited-paper (textbook QFT, leading order).
  - Quark charges (+2/3, −1/3): class=cited-paper (established).
  - "Measured R ≈ 2.0 below charm threshold": class=cited-paper (PDG).
"""
import sys
from fractions import Fraction


def r_ratio(n_colors, quarks):
    """quarks: list of (name, charge as Fraction). Returns R as a Fraction."""
    return n_colors * sum(q[1] ** 2 for q in quarks)


def main():
    print("=" * 70)
    print("P.3 — R-RATIO EXECUTABLE")
    print("  (v24 FORTRESS: integer-native — exact rational arithmetic)")
    print("=" * 70)

    # Below charm threshold: u, d, s
    quarks = [("u", Fraction(2, 3)), ("d", Fraction(-1, 3)), ("s", Fraction(-1, 3))]

    R_3 = r_ratio(3, quarks)
    R_1 = r_ratio(1, quarks)

    print(f"\nQuarks (u,d,s): charges {[q[1] for q in quarks]}")
    print(f"sum e_q^2 = (2/3)^2 + (-1/3)^2 + (-1/3)^2 = 4/9 + 1/9 + 1/9 = 6/9 = 2/3")
    print(f"\nR with N_c = 3 ('three colors'): R = 3 × 2/3 = {R_3} (exact)")
    print(f"R with N_c = 1 (no color):       R = 1 × 2/3 = {R_1} (exact)")
    print("\nMeasured R (below charm threshold): R ≈ 2.0")
    print(f"  N_c = 3: MATCHES (R = {R_3}, exactly)")
    print(f"  N_c = 1: RULED OUT (R = {R_1})")

    print("\n" + "-" * 70)
    print("INTERPRETATION")
    print("-" * 70)
    print("The '3' is doing all the empirical work. Without it, the prediction")
    print("fails. With it, the prediction succeeds.")
    print("\nBut what IS the '3'?")
    print("  It is the dimension of the fundamental representation of SU(3).")
    print("  It is a group-theory integer in a cross-section formula.")
    print("  It is NOT observed as 'three things the quark possesses.'")
    print("  No experiment has ever isolated 'a red quark' or counted 'three colors'")
    print("  on a single quark. The '3' is inferred from the RATE, not observed")
    print("  as a property.")
    print("\nThe inference chain:")
    print("  OBSERVED: R ≈ 2.0 (a rate ratio)")
    print("  DERIVED:  N_c = 3 fits the rate (representation dimension)")
    print("  SMUGGLED: 'quarks carry three intrinsic colors' (possession)")
    print("\nThe derived step (N_c = 3 in the formula) is solid.")
    print("The smuggled step (intrinsic possession) adds nothing and is")
    print("untestable — confinement forbids isolating a colored quark.")
    print("\nP.3 VERDICT: the '3' works in the equation; 'intrinsic color'")
    print("  is the prose gloss on the '3', not a finding.")

    assert R_3 == 2, "R(N_c=3) must be exactly 2"
    assert R_1 == Fraction(2, 3), "R(N_c=1) must be exactly 2/3"

    # --- Planted mutant: N_c = 2 ("two colors") must NOT give R = 2 ---
    print("\n--- PLANTED MUTANT ---")
    R_2 = r_ratio(2, quarks)
    m_caught = (R_2 != 2)
    print(f"  [{'CAUGHT' if m_caught else 'NOT CAUGHT — INVESTIGATE'}] "
          f"M1: N_c=2 gives R = {R_2} ≠ 2 — the R=2 assertion is load-bearing, "
          f"not hardcoded.")
    return 0 if m_caught else 1


if __name__ == "__main__":
    sys.exit(main())
