#!/usr/bin/env python3
"""H.2 — Intrinsic Derivation Attempt for Paper 11.5.

Tries to DERIVE encounter-independence ("intrinsic") for each SM property from
the standard formalism. Models each derivation as a chain of logical steps.
Reports exactly where each chain bottoms out — the step where "intrinsic"
would need to be derived but cannot be.

This mirrors F.57 (Paper 11's null result for blanket port exclusion):
an honest failed derivation is a result, not a failure to try.

Derivation rules (strict):
- A step is VALID if it follows from equations, definitions, or measured data.
- A step is GAP if it introduces "encounter-independence" without derivation.
- The chain SUCCEEDS only if "intrinsic" (encounter-independent property)
  appears as a VALID conclusion, not as a GAP.
"""
import sys


def attempt_spin():
    """Try to derive: 'spin-1/2 exists independently of measurement axis.'"""
    steps = []
    steps.append(("VALID", "Pauli matrices sigma_x, sigma_y, sigma_z form su(2) algebra."))
    steps.append(("VALID", "Eigenstates |up_n>, |down_n> defined relative to axis n-hat."))
    steps.append(("VALID", "Stern-Gerlach measures S.n-hat = +-h/2 along field axis."))
    steps.append(("VALID", "Poincare Casimir W_mu W^mu = -m^2 s(s+1): classifies spin-1/2 rep."))
    # Attempt the intrinsic step:
    steps.append(("GAP", "Conclude 'spin-1/2' without axis: INVALID — |up> without n-hat "
                         "is undefined. The axis is constitutive, not contextual."))
    steps.append(("GAP", "Appeal to 'representation dimension 2 is intrinsic': INVALID — "
                         "dimension is a fact about SO(3), not a possessed value."))
    steps.append(("GAP", "Appeal to Casimir W^2 as intrinsic spin: INVALID — the Casimir "
                         "classifies the representation; the reading 'spin up' still "
                         "requires S.n-hat (P.6). Classifier != possession."))
    steps.append(("REFUTED", "Bell's theorem: pre-existing LOCAL spin values violate CHSH (P.2). "
                             "Measured S=2.7 > 2. Intrinsic (pre-existing, local) spin falsified."))
    return steps


def attempt_charge():
    """Try to derive: 'charge -e exists independently of encounter scale.'"""
    steps = []
    steps.append(("VALID", "L_int = -e psi-bar gamma psi A: e is the vertex coupling."))
    steps.append(("VALID", "RG: e -> e(mu); alpha(m_e)=1/137, alpha(M_Z)=1/128."))
    steps.append(("VALID", "Bare charge e_0 diverges (unobservable)."))
    steps.append(("GAP", "Conclude 'charge -e' without scale mu: INVALID — every finite "
                         "value is e(mu) at some mu. No scale-free value exists."))
    steps.append(("GAP", "Appeal to 'bare charge is the real one': INVALID — "
                         "bare charge is infinite (meaningless)."))
    return steps


def attempt_color():
    """Try to derive: 'color charge exists independently of gauge/encounter.'"""
    steps = []
    steps.append(("VALID", "QCD Lagrangian has color index i in {r,g,b}."))
    steps.append(("VALID", "Gauge transformation: psi_i -> U_ij psi_j mixes colors."))
    steps.append(("VALID", "Elitzur: physical states are color singlets; S-matrix has no free color index."))
    steps.append(("GAP", "Conclude 'quark carries color r': INVALID — 'r' is gauge-dependent. "
                         "In a different gauge, the bookkeeping differs."))
    steps.append(("REFUTED", "Confinement: no asymptotic colored states. An 'intrinsic' "
                             "property that can never be isolated is structurally "
                             "encounter-bound, not intrinsic."))
    return steps


def attempt_flavor():
    """Try to derive: 'flavor exists independently of interaction basis.'"""
    steps = []
    steps.append(("VALID", "Charged current: J = u-bar V_CKM d."))
    steps.append(("VALID", "V_CKM rotates weak eigenbasis vs mass eigenbasis."))
    steps.append(("VALID", "K0 oscillations: flavor label changes with time."))
    steps.append(("GAP", "Conclude 'quark IS strange' (basis-independent): INVALID — "
                         "'strange' means 'weak eigenstate s', which is basis-relative by definition."))
    steps.append(("REFUTED", "If flavor were intrinsic (basis-independent), K0 oscillations "
                             "would be impossible. They occur."))
    return steps


def attempt_mass():
    """Try to derive: 'mass 511 keV exists independently of encounters.'"""
    steps = []
    steps.append(("VALID", "m^2 = E^2 - p^2 reconstructed from decay products (encounters)."))
    steps.append(("VALID", "Higgs: m_f = y_f v/sqrt(2); v is VEV (background field)."))
    steps.append(("VALID", "Poincare Casimir P_mu P^mu = m^2: frame-independent classifier."))
    steps.append(("GAP", "Conclude 'intrinsic mass' without VEV/kinematics: INVALID — "
                         "both derivations run through encounters."))
    steps.append(("GAP", "Appeal to 'VEV is just the vacuum': INVALID — the vacuum "
                         "is a field configuration (encounter with background)."))
    steps.append(("GAP", "Appeal to Casimir P^2 as intrinsic mass: INVALID — the invariant "
                         "classifies the rep; every reading (E, p^i) is frame-indexed, "
                         "and the contraction needs eta^munu (P.6). Classifier != possession."))
    return steps


def attempt_magmom():
    """Try to derive: 'magnetic moment exists independently of virtual encounters.'"""
    steps = []
    steps.append(("VALID", "a_e = sum C_n (alpha/pi)^n; each C_n sums loop diagrams."))
    steps.append(("VALID", "5-loop: 12,672 diagrams, all virtual encounters."))
    steps.append(("GAP", "Conclude 'intrinsic moment' minus encounters: INVALID — "
                         "subtract all diagrams and the remainder is undefined, not zero."))
    steps.append(("GAP", "Appeal to 'Dirac value g=2 is the intrinsic part': INVALID — "
                         "g=2 is the free-field idealization (no interactions by construction)."))
    return steps


ATTEMPTS = {
    "spin": attempt_spin,
    "charge": attempt_charge,
    "color": attempt_color,
    "flavor": attempt_flavor,
    "mass": attempt_mass,
    "magnetic moment": attempt_magmom,
}


def validate_chain(name, steps):
    """Enforce the derivation rules mechanically.

    V1: No step marked VALID may conclude intrinsicality. Describing a
        Casimir as a classifier is VALID; moving classifier -> possession
        ("therefore intrinsic") as VALID is the smuggle — reject it.
    V2: Every chain must bottom out (contain GAP or REFUTED). A chain of
        all-VALID steps concluding "intrinsic" is a spec violation.
    Returns (ok, witness).
    """
    import re
    for status, desc in steps:
        if status == "VALID":
            # Smuggle pattern: "therefore/however ... intrinsic" as VALID conclusion
            if re.search(r"(therefore|thus|hence|so)\b.{0,60}\bintrinsic\b", desc, re.I):
                return (False, f"V1 violated in '{name}': VALID step concludes "
                               f"intrinsicality: {desc[:80]}")
            if re.search(r"\bintrinsic\b.{0,40}\b(derived|established|proven)\b", desc, re.I):
                return (False, f"V1 violated in '{name}': VALID step claims intrinsic "
                               f"derived: {desc[:80]}")
    # V2: chain must bottom out
    statuses = [s for s, _ in steps]
    if "GAP" not in statuses and "REFUTED" not in statuses:
        return (False, f"V2 violated in '{name}': chain never bottoms out "
                       f"(no GAP or REFUTED).")
    return (True, "")


def mutant_casimir_smuggle():
    """PLANTED MUTANT: the Casimir defense done dishonestly.

    Marks the classifier->possession move as VALID: 'P^2 = m^2 is
    frame-independent, THEREFORE mass is intrinsic.' This is the exact
    smuggle §3.8 rebuts. The validator must reject it.
    """
    steps = []
    steps.append(("VALID", "P_mu P^mu = m^2 is a Poincare Casimir, frame-independent."))
    steps.append(("VALID", "Therefore mass is intrinsic, derived from group theory."))
    return steps


def main():
    print("=" * 70)
    print("H.2 — INTRINSIC DERIVATION ATTEMPT")
    print("Trying to derive encounter-independence from the standard formalism")
    print("=" * 70)

    results = {}
    for prop, fn in ATTEMPTS.items():
        steps = fn()
        print(f"\n--- {prop.upper()} ---")
        valid = sum(1 for s, _ in steps if s == "VALID")
        gaps = sum(1 for s, _ in steps if s == "GAP")
        refuted = sum(1 for s, _ in steps if s == "REFUTED")
        for status, desc in steps:
            print(f"  [{status}] {desc}")
        if prop == "spin":
            # §8.3 — THE SPIN SPLIT. Two distinct claims, two verdicts.
            # (a) the axis-constituted reading ("spin along n-hat" requires
            #     n-hat): the GAP steps; Bell never tested this claim.
            # (b) pre-existing LOCAL spin values: the REFUTED step (Bell/P.2).
            # No REFUTED-priority collapse: one verdict must not overwrite
            # the other.
            results[prop] = ("SPLIT: (a) BOTTOMS OUT (GAP) — axis-constituted "
                             "reading | (b) BOTTOMS OUT (REFUTED) — pre-existing "
                             "local values")
        elif refuted:
            results[prop] = "BOTTOMS OUT (REFUTED)"
        elif gaps:
            results[prop] = "BOTTOMS OUT (GAP)"
        else:
            results[prop] = "DERIVED"
        print(f"  => {results[prop]}")

    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    derived = sum(1 for r in results.values() if r == "DERIVED")
    print(f"Properties where 'intrinsic' was derived: {derived}/6")
    for prop, res in results.items():
        print(f"  {prop}: {res}")

    if derived == 0:
        print("\nH.2 VERDICT: encounter-independence cannot be derived for any property.")
        print("  Every chain bottoms out at a GAP or REFUTATION.")
        print("  Spin is SPLIT (§8.3): BOTTOMS OUT (GAP) on the axis-constituted")
        print("  reading; BOTTOMS OUT (REFUTED) on pre-existing local values.")
        print("  This is an honest null result (cf. F.57).")
    else:
        print(f"\nH.2: unexpected derivation for some properties — review needed.")
        return 1

    # --- Chain validator: all six real chains must pass ---
    print("\n" + "=" * 70)
    print("CHAIN VALIDATOR (V1: no VALID->intrinsic smuggle; V2: must bottom out)")
    print("=" * 70)
    for prop, fn in ATTEMPTS.items():
        ok, witness = validate_chain(prop, fn())
        status = "PASS" if ok else "FAIL"
        print(f"  {prop}: {status}")
        if not ok:
            print(f"    Witness: {witness}")
            return 1

    # --- Planted mutant: the dishonest Casimir chain must be REJECTED ---
    print("\n" + "=" * 70)
    print("PLANTED MUTANT: classifier->possession marked VALID")
    print("=" * 70)
    ok, witness = validate_chain("mutant_casimir_smuggle", mutant_casimir_smuggle())
    if ok:
        print("  MUTANT SURVIVED — validator is broken. FAIL.")
        return 1
    print(f"  MUTANT REJECTED. Witness: {witness}")
    print("  The validator catches the §3.8 smuggle when done dishonestly.")

    print("\nH.2 COMPLETE: 0/6 derived (spin SPLIT: GAP on the axis-constituted")
    print("reading, REFUTED on pre-existing local values), validator green,")
    print("mutant rejected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
