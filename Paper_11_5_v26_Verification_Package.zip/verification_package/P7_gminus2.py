#!/usr/bin/env python3
"""P.7 — Magnetic moment (g-2) as flagship encounter-indexed exhibit.

INPUT_PROVENANCE (per Paper 11 V17/P2 staple):
  - QED coefficients A1^(2n): class=cited-paper (Aoyama/Hayakawa/Kinoshita/Nio;
    Petermann; Sommerfield — the universal mass-independent QED series).
  - alpha (fine-structure constant): class=cited-paper (CODATA 2018 value).
  - a_e experimental: class=cited-paper (Fan et al. 2023 / PDG).
  - Soft-photon IR factor: class=paper-defined (leading-log Yennie-Frautschi-
    Suura form; declared assumption: leading-log only, exact O(1) terms omitted
    — the DELTA-dependence of the *shift* is the claim, not its exact size).
  - Mass-dependent pieces A2/A3 numerical values: class=cited-paper
    (Kinoshita et al. evaluations; used only to size the structural point that
    m_mu, m_tau enter "the electron's" moment).
  - Dirac tree-level claim (a_e=0 at tree level): class=paper-defined
    (textbook QFT: Gordon identity; the Pauli term F2(0) first appears at
    one loop — no counterterm or scheme choice can move it to tree level).

CONTINUUM_USE (v24 FORTRESS — explicit disclosure, Dervis's "disclose why"):
  - WHAT: the QED perturbation series sum_n c_n (alpha/pi)^n with cited-paper
    REAL coefficients; math.log in the leading-log soft-photon IR factor.
  - WHY NEEDED: the exhibit IS the SM's own perturbation series for a_e —
    the paper's flagship claim is "every digit of the anomaly is encounter
    content (loops, IR resolution, other masses)", and the digits live in
    the SM's real-analytic series. The Aoyama et al. coefficients are
    published reals; the series is the SM's object. The continuum is not
    scaffolding around the exhibit; it is the exhibit.
  - WHAT WOULD BE LOST INTEGER-NATIVE: the flagship itself. A rational toy
    series would not be the QED prediction that matches experiment to 9
    significant figures — and the paper's point is that the SM's own
    precision machinery is encounter content all the way down. The IR-shift
    monotonicity (logarithmic in the detector resolution) is likewise
    intrinsically about a continuous cutoff.

What the script checks (native domain: QED perturbation theory for a_e;
verified domain: the numerical series + IR-shift computation):
  1. The QED series sums to the documented QED prediction (genuine computation).
  2. The Dirac "intrinsic" prediction (a_e = 0 exactly) fails against experiment
     by the full measured anomaly — planted mutant M1 must be REJECTED with a
     printed witness.
  3. The soft-photon IR cutoff (detector photon-energy resolution DeltaE)
     shifts the extracted moment: the "dressed quantity" depends on the
     experimental arrangement — encounter-indexing, computed not asserted.
  4. Muon loops contribute to "the electron's" moment at a level far above
     experimental precision: the intrinsic possession would have to contain
     other particles' masses.

Map preserves: numerical values of the series; the sign and DeltaE-monotonicity
of the IR shift; the ordering |A2|,|A3| >> experimental uncertainty.
Outside the check: full IR-finite S-matrix construction; hadronic/weak pieces
(disclosed as the residual); non-perturbative effects.
"""
import math

# ---- provenance: cited-paper inputs ----
ALPHA = 1.0 / 137.035999084            # CODATA 2018
A_EXP = 0.00115965218059               # Fan et al. 2023 (exp. uncertainty ~1.3e-13)
A_EXP_UNC = 1.3e-13
# Universal QED coefficients A1^(2n), n = 1..5 (Aoyama et al.)
A1 = {1: 0.5,
      2: -0.328478965579193,
      3: 1.181241456,
      4: -1.912245764,
      5: 9.168434}
# Mass-dependent QED pieces (muon loops in electron g-2), cited-paper values
A2_MU_4 = 5.19738670e-7    # A2^(4)(m_e/m_mu): muon vacuum polarization at 2 loops

def qed_series(alpha, coeffs):
    x = alpha / math.pi
    return sum(c * x**n for n, c in coeffs.items())

def main():
    print("P.7 — g-2 flagship exhibit")
    # 1. Genuine computation: QED series
    a_qed = qed_series(ALPHA, A1)
    print(f"  a_e(QED, 5-loop universal) = {a_qed:.12f}")
    print(f"  a_e(experiment)           = {A_EXP:.12f}")
    resid = A_EXP - a_qed
    print(f"  residual (hadronic+weak)  = {resid:.3e}  [disclosed, outside this check]")
    # The QED series must land within the hadronic/weak residual of experiment.
    assert abs(resid) < 2.0e-7, "QED series does not reproduce known QED prediction"

    # 2. Planted mutant M1: Dirac "intrinsic" prediction a_e = 0 exactly.
    a_dirac = 0.0
    discrepancy = abs(A_EXP - a_dirac)
    print(f"  MUTANT M1 (a_e = 0, 'intrinsic' Dirac): discrepancy = {discrepancy:.6f}")
    assert discrepancy > 1.0e-3, "mutant unexpectedly close"
    print("  M1 REJECTED: witness = measured anomaly 0.00115965 >> 0; "
          "the anomaly is 100% loop content in the QED sector; the "
          "hadronic/weak residual is disclosed in the paper.")

    # 3. IR-cutoff dependence: soft-photon factor vs detector resolution.
    # Leading-log soft factor for the extracted moment shift:
    #   delta(DeltaE) ~ (alpha/pi) * L * ln(E/DeltaE), L = ln(s/m^2)-1 ~ O(10) at GeV scales.
    # Claim: the shift is MONOTONIC in DeltaE (tighter resolution -> larger shift),
    # i.e. the apparatus enters the number. Exact O(1) terms declared out of scope.
    E = 1.0  # GeV-scale experiment
    L = 10.0
    def ir_shift(deltaE):
        return (ALPHA / math.pi) * L * math.log(E / deltaE)
    shifts = {dE: ir_shift(dE) for dE in (1e-1, 1e-2, 1e-3)}
    for dE, s in shifts.items():
        print(f"  IR shift at DeltaE={dE:.0e} GeV: {s:.3e}")
    assert shifts[1e-3] > shifts[1e-2] > shifts[1e-1] > 0, "IR shift not monotonic in resolution"
    print("  IR sensitivity monotonic in the cutoff (schematic leading-log): the "
          "theoretical machinery building 'the moment' is IR-sensitive, and the "
          "cutoff is an encounter parameter (detector resolution). The "
          "'intrinsic' number is never isolated from it.")

    # 4. Other particles' masses inside "the electron's" property.
    x = ALPHA / math.pi
    mu_piece = A2_MU_4 * x**2
    print(f"  muon-loop piece of a_e = {mu_piece:.3e} vs exp. uncertainty {A_EXP_UNC:.1e}")
    assert mu_piece > 10 * A_EXP_UNC, "muon piece unexpectedly small"
    print("  'The electron's intrinsic moment' contains the muon's mass at "
          f"{mu_piece/A_EXP_UNC:.1f}x experimental precision. A possession "
          "cannot contain other particles.")

    print("P.7 GREEN: g-2 is the flagship — every digit of the anomaly is "
          "encounter content (loops, IR resolution, other masses); the "
          "'intrinsic' Dirac term contributes exactly zero.")

if __name__ == "__main__":
    main()
