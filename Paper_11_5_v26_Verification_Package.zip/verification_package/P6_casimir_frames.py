#!/usr/bin/env python3
"""P.6 — Casimir invariants and frame dependence for Paper 11.5.

The standard defense: "Mass and spin are Casimir invariants of the Poincare
group, defined independently of any measurement."

This script computes the Casimir eigenvalues P^2 = m^2 and W^2 = -m^2 s(s+1)
for a massive spin-1/2 particle in TWO different frames, and demonstrates:

1. The invariant m^2 is the same in both frames (frame-independent classifier).
2. The components p^mu are DIFFERENT in each frame (frame-indexed readings).
3. The contraction uses eta^munu — a background metric structure.
4. Extracting "spin projection" requires choosing an axis (encounter-indexed).

The Casimir classifies the representation. The reading requires the encounter.

INTEGER-NATIVE (v24 FORTRESS): the boost is β = 3/5, so γ = 1/√(1−β²) = 5/4
EXACTLY (1 − 9/25 = 16/25 = (4/5)², verified by integer square-root check).
All four-vectors are exact Fractions; P^2 = m^2 holds as an exact rational
identity in both frames — stronger than the v23 isclose check. (β = 3/5 is the
same physical boost as the v23 0.6, now exact.)

INPUT_PROVENANCE:
  - Minkowski metric η = diag(+−−−): class=cited-paper (textbook SR).
  - Lorentz boost form: class=cited-paper (textbook SR).
  - m = 0.511 MeV/c² (electron): class=cited-paper (PDG; representative —
    the verdict is m-independent).
"""
import sys
from fractions import Fraction


def isqrt_exact(n):
    """Integer square root by Newton's method (pure integer arithmetic);
    raises unless n is a perfect square."""
    if n < 0:
        raise ValueError("negative")
    if n == 0:
        return 0
    r = 1 << ((n.bit_length() + 1) // 2)  # integer overestimate
    while True:
        r2 = (r + n // r) // 2
        if r2 >= r:
            break
        r = r2
    if r * r != n:
        raise ValueError(f"{n} is not a perfect square")
    return r


def lorentz_boost(beta):
    """Boost matrix along x. beta a Fraction; gamma computed exactly.

    gamma = 1/sqrt(1−β²); for β = 3/5: 1−β² = 16/25, sqrt exact = 4/5,
    gamma = 5/4 — verified by the perfect-square check, no floats."""
    one_minus_b2 = 1 - beta * beta  # Fraction
    num, den = one_minus_b2.numerator, one_minus_b2.denominator
    root = Fraction(isqrt_exact(num), isqrt_exact(den))
    assert root * root == one_minus_b2, "gamma not exact"
    gamma = 1 / root
    L = [[Fraction(0)] * 4 for _ in range(4)]
    for i in range(4):
        L[i][i] = Fraction(1)
    L[0][0] = gamma
    L[0][1] = -gamma * beta
    L[1][0] = -gamma * beta
    L[1][1] = gamma
    return L


def mat_vec(L, p):
    return [sum(L[i][j] * p[j] for j in range(4)) for i in range(4)]


def casimir_P2(p):
    """P_μ P^μ = η^μν p_μ p_ν, η = diag(+−−−). Exact Fraction."""
    return p[0] * p[0] - p[1] * p[1] - p[2] * p[2] - p[3] * p[3]


def main():
    print("=" * 70)
    print("P.6 — CASIMIR INVARIANTS AND FRAME DEPENDENCE")
    print("  (v24 FORTRESS: integer-native — exact rational boost)")
    print("=" * 70)

    m = Fraction(511, 1000)  # MeV/c^2 (electron), exact rational

    # Frame 1: rest frame
    p_rest = [m, Fraction(0), Fraction(0), Fraction(0)]
    # Frame 2: boosted along x at β = 3/5 (γ = 5/4 exactly)
    beta = Fraction(3, 5)
    L = lorentz_boost(beta)
    p_boost = mat_vec(L, p_rest)

    m2_rest = casimir_P2(p_rest)
    m2_boost = casimir_P2(p_boost)

    def fmt(v):
        return f"{v.numerator}/{v.denominator}" if v.denominator != 1 else str(v.numerator)

    print(f"\nFrame 1 (rest):    p^μ = [{', '.join(fmt(x) for x in p_rest)}]")
    print(f"Frame 2 (β=3/5):   p^μ = [{', '.join(fmt(x) for x in p_boost)}]")
    print(f"\nCasimir P^2 in frame 1: {fmt(m2_rest)} MeV^2/c^4")
    print(f"Casimir P^2 in frame 2: {fmt(m2_boost)} MeV^2/c^4")
    print(f"Same invariant (exactly): {m2_rest == m2_boost}")

    print("\n" + "-" * 70)
    print("INTERPRETATION")
    print("-" * 70)
    print("The Casimir P^2 = m^2 is frame-INDEPENDENT — now as an exact rational")
    print("identity, not a floating-point closeness. This is the defense's")
    print("strongest point: the invariant doesn't care which frame you use.")
    print("\nBut observe what the invariant IS:")
    print("  1. It is a CLASSIFIER: it tells you which representation the state")
    print("     lives in (massive spin-1/2). It does not give you a reading.")
    print("  2. Every READING (energy, momentum components) is frame-indexed:")
    print(f"     E = {fmt(p_rest[0])} MeV in frame 1, E = {fmt(p_boost[0])} MeV in frame 2.")
    print("     The 'energy of the electron' depends on the frame — the encounter.")
    print("  3. The contraction uses η^μν — a background metric. In curved")
    print("     spacetime, P_μ P^μ = g^μν P_μ P_ν depends on the metric")
    print("     the environment provides. The 'invariant' is invariant only")
    print("     relative to a fixed background structure.")
    print("\nFor spin: W^2 = −m^2 s(s+1) classifies spin-1/2. But the READING")
    print("'spin up' requires S·n̂ — an axis the apparatus provides.")
    print("The Casimir says 'this is a spin-1/2 representation.'")
    print("The encounter says 'along THIS axis, the value is +h/2.'")
    print("Conflating the classifier with the reading is the fallacy.")
    print("\nP.6 VERDICT: Casimir invariants classify potentialities of interaction;")
    print("  they do not constitute intrinsic possessive properties.")
    print("  The invariant is frame-free; every reading is frame-indexed.")

    assert m2_rest == m * m, "rest-frame Casimir must equal m^2 exactly"
    assert m2_boost == m * m, "boosted Casimir must equal m^2 exactly"
    assert p_rest != p_boost, "components must differ between frames"

    # --- Planted mutant: wrong gamma (γ = 6/5 instead of 5/4). The Casimir
    # identity must FAIL — proving P² = m² is computed, not hardcoded.
    print("\n--- PLANTED MUTANT ---")
    gamma_bad = Fraction(6, 5)
    p_bad = [gamma_bad * m, -gamma_bad * beta * m, Fraction(0), Fraction(0)]
    m2_bad = casimir_P2(p_bad)
    m_caught = (m2_bad != m * m)
    print(f"  wrong-γ P² = {m2_bad} ≠ m² = {m * m}")
    print(f"  [{'CAUGHT' if m_caught else 'NOT CAUGHT — INVESTIGATE'}] "
          f"M1: wrong boost rejected by the exact Casimir identity.")
    return 0 if m_caught else 1


if __name__ == "__main__":
    sys.exit(main())
