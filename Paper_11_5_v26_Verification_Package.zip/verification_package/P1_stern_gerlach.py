#!/usr/bin/env python3
"""P.1 — Stern-Gerlach executable for Paper 11.5.

Computes spin measurement along an axis n-hat using Pauli matrices.
Demonstrates: the spin VALUE requires the axis; without n-hat the question
"what is the spin?" is ill-posed (not unknown — undefined).

Then attempts the "intrinsic" move: define spin without any axis.
Reports where it fails.

INTEGER-NATIVE (v24 FORTRESS): no numpy, no float eigensolver. For an integer
axis triple n = (nx, ny, nz), S = nx·σx + ny·σy + nz·σz is a 2x2 matrix over
the Gaussian integers Z[i]; the Pauli algebra gives S^2 = (n·n)·I EXACTLY, so
every eigenvalue λ satisfies λ^2 = n·n — hence λ = ±1 for the unit axis
n̂ = n/|n|. The "eigenvalues are always ±1" is now an exact integer identity,
stronger than the v23 allclose check.

INPUT_PROVENANCE:
  - Pauli matrices: class=cited-paper (textbook QM; integer entries).
  - Pauli algebra (σi σj + σj σi = 2δij): class=cited-paper (textbook QM).
  - No measured inputs; the claim is structural.
"""
import sys

# Pauli matrices as nested tuples over Z[i] (Gaussian integers: complex ints).
SX = ((0, 1), (1, 0))
SY = ((0, -1j), (1j, 0))
SZ = ((1, 0), (0, -1))


def mat_add(A, B):
    return tuple(tuple(a + b for a, b in zip(ra, rb)) for ra, rb in zip(A, B))


def mat_scale(c, A):
    return tuple(tuple(c * a for a in ra) for ra in A)


def mat_mul(A, B):
    return tuple(
        tuple(sum(A[i][k] * B[k][j] for k in range(2)) for j in range(2))
        for i in range(2)
    )


def mat_eq(A, B):
    return all(A[i][j] == B[i][j] for i in range(2) for j in range(2))


def spin_operator(n):
    """S = n·σ for an integer axis triple n. Returns (S, n·n)."""
    nx, ny, nz = n
    S = mat_add(mat_add(mat_scale(nx, SX), mat_scale(ny, SY)), mat_scale(nz, SZ))
    return S, nx * nx + ny * ny + nz * nz


def eigenvalues_squared_plus_minus_one(n):
    """Exact check: S^2 = (n·n)·I, so eigenvalues λ satisfy λ^2 = n·n.

    For the UNIT axis n̂ = n/sqrt(n·n): λ^2 = 1, i.e. λ = ±1 exactly.
    trace(S) = 0 confirms both signs occur (n != 0). Returns (n·n, ok)."""
    S, n2 = spin_operator(n)
    S2 = mat_mul(S, S)
    ident = ((n2, 0), (0, n2))
    ok_square = mat_eq(S2, ident)
    tr = S[0][0] + S[1][1]
    ok_trace = (tr == 0)
    return n2, ok_square and ok_trace


def main():
    print("=" * 70)
    print("P.1 — STERN-GERLACH EXECUTABLE")
    print("  (v24 FORTRESS: integer-native — exact Pauli algebra, no floats)")
    print("=" * 70)

    axes = {
        "z": (0, 0, 1),
        "x": (1, 0, 0),
        "(1,1,1)": (1, 1, 1),
    }
    for name, n in axes.items():
        S, n2 = spin_operator(n)
        print(f"\nAxis n = {name}: S^2 = {n2}·I exactly "
              f"(eigenvalues of S·n̂: ±1, since n̂·n̂ = 1)")

    print("\nThe eigenvalues are ALWAYS ±1 (i.e., ±h/2) — now as an exact")
    print("integer identity S^2 = (n·n)·I, not a floating-point eigensolve.")
    print("But 'spin up' MEANS 'up along n-hat'. Change n-hat, change what 'up' means.")
    print("The axis is not a parameter of the measurement.")
    print("It is constitutive of the measured quantity.")

    # The intrinsic attempt: spin without axis
    print("\n" + "-" * 70)
    print("ATTEMPT: define 'the spin' without any axis.")
    print("-" * 70)
    print("S = (Sx, Sy, Sz) is a vector operator, not a scalar.")
    print("Asking 'what is the spin?' without n-hat is like asking")
    print("'what is the slope?' without a curve.")
    print("Not unknown. UNDEFINED. The question is ill-posed.")
    print("\nP.1 VERDICT: 'intrinsic spin-1/2' (no axis) is not a quantity.")
    print("  It is a dimension label (2D representation) mistaken for a value.")
    intrinsic_derived = False

    # Verify the exact identity for 6 axes (incl. non-axis-aligned integer triples)
    print("\nExact verification: S^2 = (n·n)·I and tr(S) = 0 for 6 axes:")
    all_ok = True
    for axis in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 1, 1), (3, -7, 5)]:
        n2, ok = eigenvalues_squared_plus_minus_one(axis)
        all_ok &= ok
        print(f"  axis {axis}: n·n = {n2:3d}, S^2 = {n2}·I exactly, "
              f"eigenvalues ±1 [{'OK' if ok else 'FAIL'}]")
    if not all_ok:
        print("PAULI IDENTITY FAILED — investigate.")
        return 1
    print("\nVerified exactly: eigenvalues ±1 for every axis.")
    print("The CAPABILITY (2 outcomes) is axis-independent.")
    print("The VALUE (±1 along n-hat) is axis-indexed.")
    print("Paper 11: capability vs. actuality (CAPABILITY_ACTUALITY_SEPARATION).")

    # --- Planted mutants: the identity check must be non-vacuous ---
    print("\n--- PLANTED MUTANTS ---")
    mutants_ok = True
    # M1: tampered identity S^2 = (n·n+1)·I — must be REJECTED.
    S, n2 = spin_operator((1, 1, 1))
    S2 = mat_mul(S, S)
    tampered = ((n2 + 1, 0), (0, n2 + 1))
    m1_caught = not mat_eq(S2, tampered)
    print(f"  [{'CAUGHT' if m1_caught else 'NOT CAUGHT — INVESTIGATE'}] "
          f"M1: tampered S^2=(n·n+1)I rejected (the identity check is genuine)")
    mutants_ok &= m1_caught
    # M2: scaled impostor — 2·σx instead of σx. S^2 = 4·I ≠ 1·I, so the
    # identity check must reject it: the matrices really are the Pauli
    # matrices (coefficient 1), not rescaled lookalikes.
    SX_bad = ((0, 2), (2, 0))  # 2*σx
    S_bad = mat_scale(1, SX_bad)
    m2_caught = not mat_eq(mat_mul(S_bad, S_bad), ((1, 0), (0, 1)))
    print(f"  [{'CAUGHT' if m2_caught else 'NOT CAUGHT — INVESTIGATE'}] "
          f"M2: rescaled Pauli impostor (2σx) rejected")
    mutants_ok &= m2_caught

    return 0 if (not intrinsic_derived and mutants_ok) else 1


if __name__ == "__main__":
    sys.exit(main())
