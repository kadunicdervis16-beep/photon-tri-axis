#!/usr/bin/env python3
"""G.4 — Terminology consistency verifier for Paper 11.5.

Checks: none of four hedge spellings of "intrinsic" appear in the paper's
prose (outside fenced code): "intrinsic ... in some sense", "intrinsic ...
in the sense of", "effectively intrinsic", "quasi-intrinsic".
That is ALL this check establishes: the absence of four specific hedge
patterns. It does not check sense-consistency of "intrinsic" beyond that —
e.g. whether every unhedged occurrence is used in the ontological sense —
so its verdict claims only the absence of the hedges.
Draft resolution (v19 fallback chain): argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md -> newest paper_11_5_v<N>.md. The resolved draft file is printed on every run.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _resolve_draft(here):
    """Fallback chain: argv[1] -> $PAPER_MD -> candidate filenames."""
    import os, re
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    env = os.environ.get("PAPER_MD")
    if env and Path(env).is_file():
        return Path(env)
    cands = [here.parent / "paper_11_5_draft.md",
             here.parent / "paper.md"]
    def _vkey(p):
        m = re.search(r"v(\d+)\.md$", p.name)
        return int(m.group(1)) if m else -1
    cands += sorted(here.parent.glob("paper_11_5_v*.md"), key=_vkey, reverse=True)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError(
        "no paper draft found; tried argv[1], $PAPER_MD, and: "
        + ", ".join(str(c) for c in cands))


# Portable draft resolution (v14 hardening; v19 fallback chain):
# argv[1] -> $PAPER_MD -> paper_11_5_draft.md -> paper.md ->
# newest paper_11_5_v<N>.md. $PAPER_MD at a nonexistent file falls through;
# argv[1] is honored verbatim (unchanged pre-v19 behavior, including
# fail-on-nonexistent input). The helper is inlined: scripts stay
# standalone, no shared imports.
DRAFT = _resolve_draft(HERE)
text = open(DRAFT, encoding="utf-8").read()

# Exclude fenced code blocks (Appendix G script listings) — the scan covers prose only
lines = text.split("\n")
prose_lines = []
in_fence = False
for line in lines:
    if line.strip().startswith("```"):
        in_fence = not in_fence
        continue
    if not in_fence:
        prose_lines.append(line)
text = "\n".join(prose_lines)

# Find all sentences containing "intrinsic"
sentences = re.split(r"(?<=[.!?])\s+", text)
hits = [(i, s) for i, s in enumerate(sentences) if re.search(r"\bintrinsic\b", s, re.I)]

print(f"Draft: {DRAFT}")
print(f"Sentences containing 'intrinsic': {len(hits)}")

# Banned hedges: uses that smuggle alternative senses
banned_patterns = [
    (r"intrinsic.{0,30}in some sense", "hedged sense"),
    (r"intrinsic.{0,30}in the sense of", "alternative sense definition"),
    (r"effectively intrinsic", "weasel qualifier"),
    (r"quasi-intrinsic", "weasel qualifier"),
]

issues = []
for i, s in hits:
    for pat, label in banned_patterns:
        if re.search(pat, s, re.I):
            issues.append(f"Sentence {i} [{label}]: {s[:100]}...")

if issues:
    print("ISSUES:")
    for i in issues:
        print(f"  - {i}")
    sys.exit(1)
print("G.4 PASS: none of the four hedge patterns found "
      "('intrinsic ... in some sense', 'intrinsic ... in the sense of', "
      "'effectively intrinsic', 'quasi-intrinsic'). "
      "Sense-consistency beyond these patterns is not checked.")
