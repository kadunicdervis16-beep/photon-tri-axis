#!/usr/bin/env python3
"""Run the full Paper 11.5 v26 verification suite (21 scripts).

Usage:  python3 run_all.py

Runs every script from this package folder, in sorted order, with the
packaged paper (paper_11_5_v26.md) supplied to the scripts that read the
draft:
  - positional argument:  FW1, G1, G2, G3, G4, H3, H4
  - --draft <path>:       PA1 (argparse)
  - no argument:          H1, H2, MC1, P1-P10 (standalone computations
                          that read no file)
Prints PASS/FAIL with the exit code for each script and exits nonzero
if any script fails. Green = 21/21 exit 0.
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
DRAFT = HERE / "paper_11_5_v26.md"

SCRIPTS = [
    "FW1_firewall.py",
    "G1_quote_integrity.py",
    "G2_contrast_completeness.py",
    "G3_no_strawman.py",
    "G4_terminology.py",
    "H1_sm_badge_audit.py",
    "H2_intrinsic_derivation_attempt.py",
    "H3_prose_equation_consistency.py",
    "H4_honesty_comparison.py",
    "MC1_shell_montecarlo.py",
    "P10_g2_loop_spectrum.py",
    "P1_stern_gerlach.py",
    "P2_bell_chsh.py",
    "P3_r_ratio.py",
    "P4_rg_running.py",
    "P5_ckm_basis.py",
    "P6_casimir_frames.py",
    "P7_gminus2.py",
    "P8_mass_scheme.py",
    "P9_bell_ternary_tether.py",
    "PA1_parsing_agent.py",
]

POSITIONAL = {
    "FW1_firewall.py", "G1_quote_integrity.py", "G2_contrast_completeness.py",
    "G3_no_strawman.py", "G4_terminology.py",
    "H3_prose_equation_consistency.py", "H4_honesty_comparison.py",
}
DRAFT_FLAG = {"PA1_parsing_agent.py"}


def main():
    if not DRAFT.is_file():
        print(f"run_all: packaged paper not found: {DRAFT}", file=sys.stderr)
        return 2
    results = []
    for name in sorted(SCRIPTS):
        script = HERE / name
        if not script.is_file():
            print(f"\n===== {name} =====\nMISSING — FAIL")
            results.append((name, None))
            continue
        cmd = [sys.executable, str(script)]
        if name in POSITIONAL:
            cmd.append(str(DRAFT))
        elif name in DRAFT_FLAG:
            cmd += ["--draft", str(DRAFT)]
        print(f"\n===== {name} =====", flush=True)
        t0 = time.time()
        proc = subprocess.run(cmd, cwd=str(HERE))
        dt = time.time() - t0
        status = "PASS" if proc.returncode == 0 else "FAIL"
        print(f"----- {name}: {status} (exit {proc.returncode}, {dt:.1f}s) -----",
              flush=True)
        results.append((name, proc.returncode))
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    n_pass = 0
    for name, rc in results:
        if rc == 0:
            n_pass += 1
            print(f"  PASS  {name}")
        else:
            print(f"  FAIL  {name}  (exit {rc})")
    print(f"\n{n_pass}/{len(results)} scripts green.")
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
