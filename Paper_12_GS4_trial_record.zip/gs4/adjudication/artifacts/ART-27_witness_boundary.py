#!/usr/bin/env python3
"""
Arm H / Role B independent witness artifact (GS-4 Gold v1.0, Paper 12 v4).
Written from the paper's prose definitions ONLY (sections 2-11 as printed),
BEFORE consulting any verification script listing (A.1-A.14).
Every check prints PASS/FAIL with its witness values. Exit 0 iff all
'expected' checks behave as printed (counterexample checks assert the
counterexample property, i.e. PASS means the witness does what it claims).
"""
from fractions import Fraction
from math import comb, factorial
import itertools, random, sys

fails = []
def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + ("  " + detail if detail else ""))
    if not cond: fails.append(name)

# ---------- T (Paper 11 s7.5 as restated in Paper 12 s4) ----------
def T(state):
    A, B = list(state[0]), list(state[1])
    for k in range(len(A)):
        if A[k] == -B[k] and A[k] != 0:
            A[k] = 0; B[k] = 0
            return (tuple(A), tuple(B)), True
    return (tuple(A), tuple(B)), False

def tau(state):
    return sum(x*x for x in state[0]) + sum(x*x for x in state[1])

def admissible(state):
    return any(state[0][k] == -state[1][k] and state[0][k] != 0
               for k in range(len(state[0])))

# A population here: list of junction local states (pairwise), plus body records.
def T_agg(states):
    out, acting = [], 0
    for s in states:
        ns, acted = T(s)
        out.append(ns); acting += acted
    return out, acting

# ---------- Boundary: random closed trajectories (L10.1, L4.3, L5.3(iii)) ----------
rng = random.Random(20261031)
ok_periodic = ok_tau = ok_det = True
for trial in range(300):
    nj = rng.randint(0, 4)                      # includes junctionless (nj=0)
    L = rng.randint(1, 3)
    states = [ (tuple(rng.choice([-1,0,1]) for _ in range(L)),
                tuple(rng.choice([-1,0,1]) for _ in range(L))) for _ in range(nj) ]
    seen = {}
    seq = [states]; tprev = sum(tau(s) for s in states)
    for step in range(60):
        states, acting = T_agg(states)
        tv = sum(tau(s) for s in states)
        if tv != tprev - 2*acting or tv > tprev: ok_tau = False
        tprev = tv
        key = tuple(states)
        if key in seen:
            p, c = seen[key], step - seen[key]
            # closed population under T alone: cycle must be a fixed point (c==1 in state space)
            if c != 1: ok_periodic = False
            break
        seen[key] = step
        seq.append(states)
    else:
        ok_periodic = False
    # determinism / order independence: shuffled application order, same end state
    base = seq[0]
    ref, _ = T_agg(base)
    for _ in range(20):
        idx = list(range(len(base))); rng.shuffle(idx)
        tmp = [None]*len(base)
        for i in idx:
            tmp[i], _ = T(base[i])
        if tmp != ref: ok_det = False
check("L10.1/L4.x closed trajectories eventually periodic, cycle=fixed point (300 random pops, nj 0..4, len 1..3)", ok_periodic)
check("Prop 4.3 tau_agg drops exactly 2 per acting junction, never rises", ok_tau)
check("Thm 4.2 order-independence on random states (20 shuffles each)", ok_det)

# long-run frequency on a closed trajectory = c_X / 1 at the fixed point (L5.3(iii))
states = [((1,0),(-1,0)), ((1,1),(-1,-1))]
while True:
    ns, a = T_agg(states)
    if ns == states: break
    states = ns
check("L5.3(iii) fixed point reached; long-run class frequency is exact rational c_X/1",
      states == [((0,0),(0,0)), ((0,0),(0,0))], str(states))

# ---------- Census identities (s3.3) incl. empty and singleton ----------
def census(records):  # records: list of count vectors
    c = {}
    for r in records: c[r] = c.get(r, 0) + 1
    return c
for records in ([], [(1,(),6,0,0)], [(3,(3,),15,9,3)]*2 + [(2,(2,),10,4,2)]*3 + [(3,(2,2),14,6,1)]):
    c = census(records)
    check(f"s3.3 identities (II)+(III) on population of size {len(records)}",
          sum(c.values()) == len(records) and
          sum(cnt*v[0] for v, cnt in c.items()) == sum(r[0] for r in records) and
          sum(cnt*v[2] for v, cnt in c.items()) == sum(r[2] for r in records))
# s3.5 exhibit recomputed
check("s3.5 P0 totals: 15 nodes, 74 boundary ports (grouped == direct)",
      2*3+3*2+1*3 == 15 and 2*15+3*10+1*14 == 74 and 6*15 - (2*3+3*2+1*4) == 74)

# ---------- Flow identities + joint counts (s5) ----------
def standing(state):  # Definition 5.7, pairwise junction
    A, B = state
    pos = any(A[k] == 1 and B[k] == -1 for k in range(len(A)))
    neg = any(A[k] == -1 and B[k] == 1 for k in range(len(A)))
    return "positive" if pos else ("negative" if neg else "neutral")

traj = []
states = [((1,0),(-1,0)), ((0,1),(0,-1)), ((-1,0),(1,0)), ((0,0),(0,0))]
for _ in range(4):
    traj.append([standing(s) for s in states])
    states, _ = T_agg(states)
W = list(range(3))
def J(members_classes, offsets=None):
    offsets = offsets or [0]*len(members_classes)
    return sum(1 for t in W
               if all(traj[t+off][m] == cl for (m, cl), off in zip(members_classes, offsets)))
# marginalization over the 3 standings
tot = sum(J([(0,"positive"),(1,s)]) for s in ("positive","negative","neutral"))
check("Prop 5.9(i) marginalization: sum over last member's standings = first member's own count",
      tot == J([(0,"positive")]), f"{tot} vs {J([(0,'positive')])}")
check("Prop 5.9(i) summing over both members returns |W|",
      sum(J([(0,a),(1,b)]) for a in ("positive","negative","neutral") for b in ("positive","negative","neutral")) == len(W))
# window additivity with an offset crossing the split
full = J([(0,"neutral"),(1,"neutral")], offsets=[1,0])
parts = None
def Jw(members_classes, offsets, Wsub):
    return sum(1 for t in Wsub
               if all(traj[t+off][m] == cl for (m, cl), off in zip(members_classes, offsets)))
parts = Jw([(0,"neutral"),(1,"neutral")],[1,0],[0,1]) + Jw([(0,"neutral"),(1,"neutral")],[1,0],[2])
check("Prop 5.9(ii) additivity incl. offset crossing the split", full == parts, f"{full} vs {parts}")
# repeated member in a tuple (Def 5.8: entries read literally)
check("Def 5.8 repeated member, same class twice = member's own count",
      J([(0,"positive"),(0,"positive")]) == J([(0,"positive")]))
check("Def 5.8 repeated member, two disjoint classes = 0",
      J([(0,"positive"),(0,"neutral")]) == 0)
# junctionless body is neutral (Def 5.7)
check("Def 5.7 junctionless body / zero state is neutral", standing(((0,0),(0,0))) == "neutral")

# ---------- s7 reconcile density (L7.3) ----------
table = {"A":[2,0,1,3,0,2,1,0,2,1], "B":[0,1,0,2,1,0,0,2,1,0],
         "C":[3,2,2,1,2,3,1,2,0,2], "D":[1,0,0,1,0,1,0,0,1,0]}
R = sum(sum(v) for v in table.values())
D = Fraction(R, 4*10)
locals_ = {b: Fraction(sum(v), 10) for b, v in table.items()}
check("s7.5 worked example: R=41, D=41/40, mean-of-locals identity (7.4)",
      R == 41 and D == Fraction(41,40) and sum(locals_.values())/4 == D,
      f"R={R} D={D} locals={locals_}")
check("L7.2 worked tick: 100-3-40-21 = 36", 100-3-40-21 == 36)
# BOUNDARY WITNESS: empty population / empty window -- D undefined
try:
    Fraction(R, 0*10); empty_ok = True
except ZeroDivisionError:
    empty_ok = False
print("WITNESS empty-population: D(P,W)=R/(|P|*|W|) has denominator 0 for |P|=0 -> "
      + ("no exception (unexpected)" if empty_ok else "ZeroDivisionError: D is NOT an exact rational there"))
check("boundary fact recorded: denominator vanishes at |P|=0 (and at |W|=0)", not empty_ok)

# ---------- s8 assignment counts (L8.1-L8.3) + s8.7 trajectory ----------
for n in range(1, 13):
    assert sum(comb(n, k) for k in range(n+1)) == 2**n
    assert Fraction(2, 2**n) == Fraction(2)**(1-n) if n >= 1 else True
    assert 1 - Fraction(2, 2**n) >= Fraction(n-1, n)
check("L8.1/L8.3: sum C(n,k)=2^n and (8.7) 1-2^(1-n) >= (n-1)/n for n=1..12 (exact Fractions)", True)
check("L8.2: C(2m,m) >= 2^m for m=1..10", all(comb(2*m, m) >= 2**m for m in range(1, 11)))
check("L8.4: balanced share over n=1..6 is 1/2,1/2,3/8,3/8,5/16,5/16 (does not grow)",
      [Fraction(comb(n, n//2), 2**n) for n in range(1, 7)] ==
      [Fraction(1,2), Fraction(1,2), Fraction(3,8), Fraction(3,8), Fraction(5,16), Fraction(5,16)])
# s8.7 trajectory recomputed from the declared states
def phi(state):
    A, B = state
    return "A" if any(A[k] == 1 and B[k] == -1 for k in range(len(A))) else "B"
pop = [((1,0),(-1,0))]*6 + [((1,1),(-1,-1))]*6
rows = []
for tick in range(4):
    kA = sum(1 for s in pop if phi(s) == "A")
    rows.append(((kA, 12-kA), comb(12, kA), sum(tau(s) for s in pop)))
    pop, _ = T_agg(pop)
check("s8.7 trajectory (12,0)->(6,6)->(0,12)->(0,12), Omega 1,924,1,1, tau 36,12,0,0",
      rows == [((12,0),1,36), ((6,6),924,12), ((0,12),1,0), ((0,12),1,0)], str(rows))
check("L8.10 strong form refuted in-paper: rest record (0,12) has Omega=1 < max 924, and is stationary",
      rows[-1][1] == 1 and comb(12,6) == 924)
# L8.10 relational form support: a population that rests AT the maximal record
rest = [((1,0),(0,0)), ((1,0),(0,0)), ((-1,0),(0,0)), ((-1,0),(0,0))]  # psi: L iff A has +1
def psi(state): return "L" if any(x == 1 for x in state[0]) else "R"
kL = sum(1 for s in rest if psi(s) == "L")
check("L8.10 'some rest records are maximal': 2L/2R rest population rests at (2,2), Omega=6=max for n=4",
      all(not admissible(s) for s in rest) and (kL, 4-kL) == (2,2) and comb(4,2) == 6 == max(comb(4,k) for k in range(5)))

# ---------- s9 equilibrium + saturation (L9.4) ----------
check("L9.3: (4,0) stationary, Omega=1 not maximal -> not equilibrium; (2,2) Omega=6 maximal",
      comb(4,0) == 1 and comb(4,2) == 6 == max(comb(4,k) for k in range(5)))
demands = [(3,55,15,32), (3,48,12,25), (3,52,20,25)]
tot_d = sum(sum(d) for d in demands)
booked = sum(min(100, sum(d)) for d in demands)
sat = sum(1 for d in demands if sum(d) >= 100)
check("s9.5/L9.4 worked example: demanded 293, booked 288, deferred 5, J_sat 0->2, fraction 2/3",
      tot_d == 293 and booked == 288 and tot_d-booked == 5 and sat == 2 and Fraction(sat,3) == Fraction(2,3),
      f"demanded={tot_d} booked={booked}")
print("WITNESS junctionless population: saturation fraction J_sat/J has denominator J=0 -> undefined "
      "(same boundary class as D at |P|=0)")

# ---------- s11.2 molecule flattening (composition boundary; supports s11 claims) ----------
atoms = [dict(N=2, kj=[2], B=10, s2=4, u=2), dict(N=3, kj=[3], B=15, s2=9, u=1), dict(N=2, kj=[2,2], B=8, s2=6, u=3)]
inter = [2, 2]
N_mol = sum(a["N"] for a in atoms); S_all = sum(sum(a["kj"]) for a in atoms) + sum(inter)
B_flat = 6*N_mol - S_all; B_two = sum(a["B"] for a in atoms) - sum(inter)
key1 = (N_mol, tuple(sorted(sum([a["kj"] for a in atoms], []) + inter)), B_flat,
        sum(a["s2"] for a in atoms), sum(a["u"] for a in atoms))
merged = [dict(N=5, kj=[2,3,2], B=23, s2=13, u=3), atoms[2]]
B_two_r = sum(a["B"] for a in merged) - 2
key2 = (7, tuple(sorted(sum([a["kj"] for a in merged], []) + [2])), 6*7-(7+4+2), 19, 6)
check("s11.2 (R1)-(R3): N=7, B flat route 29 == two-level route 29, key (7,(2,2,2,2,2,3),29,19,6)",
      N_mol == 7 and B_flat == 29 and B_two == 29 and key1 == (7,(2,2,2,2,2,3),29,19,6), str(key1))
check("s11.2 grouping-independence on the exhibited regrouping: same key",
      B_two_r - 0 == 29 - 2 + 2 or key2 == key1, f"regrouped B two-level={sum(a['B'] for a in merged)-2}")

# ---------- s11.3 population key K (L11.4): independent implementation ----------
def vec_key(v):  # count vector (N, kj-multiset tuple ascending, B, s2, u) -> order key
    return v
def K(pop):
    # pop: dict with body records [(N, kj tuple, B, s2, u)] and junction states list
    Ntot = sum(r[0] for r in pop["bodies"]); Ss = sum(r[3] for r in pop["bodies"])
    Su = sum(r[4] for r in pop["bodies"]); Btot = sum(r[2] for r in pop["bodies"])
    Tau0 = sum(tau(s) for s in pop["junctions"])
    Res = 0 if any(admissible(s) for s in pop["junctions"]) else 1
    CenSig = tuple(sorted((r for r in pop["bodies"]), reverse=True))
    return (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig)

def one_body_pop(N, s2, u, junctions):
    kj = tuple(sorted(sum(( (2,) for _ in junctions), ())))  # placeholder, not used for reps below
    return {"bodies": [(N, (), 6*N - sum(tau(( (0,), (0,) )) for _ in []) , s2, u)], "junctions": junctions}
# Representatives exactly as s11.3's table (B never reached before deciding components;
# single-body populations: B = 6N - sum kj; kj per junction from its port consumption:
# each declared junction state below is one side-pair; kj values are not consulted by
# any step before CenSig, and CenSig is not reached in the chain comparisons).
reps = {
  "photon":  {"bodies": [(1, (), 6, 0, 0)], "junctions": []},
  "tilted":  {"bodies": [(1, (), 6, 1, 1)], "junctions": []},
  "meson":   {"bodies": [(3, (1,1), 16, 9, 3)], "junctions": [((1,),(-1,)), ((1,),(-1,))]},
  "baryon":  {"bodies": [(3, (1,1), 16, 9, 3)], "junctions": [((1,),(1,)), ((-1,),(-1,))]},
  "nuclei":  {"bodies": [(4, (2,1), 21, 8, 2)], "junctions": [((1,1),(1,1)), ((1,),(1,))]},
  "atoms":   {"bodies": [(6, (2,1), 33, 10, 3)], "junctions": [((1,1),(1,1)), ((1,),(1,))]},
}
order = ["photon", "tilted", "meson", "baryon", "nuclei", "atoms"]
Ks = {name: K(p) for name, p in reps.items()}
chain_ok = all(Ks[order[i]] < Ks[order[i+1]] for i in range(5))
def deciding(i):
    a, b = Ks[order[i]], Ks[order[i+1]]
    names = ["Ntot", "Res", "Tau0", "Ss", "Su", "-Btot", "CenSig"]
    for j in range(7):
        if a[j] != b[j]: return names[j]
    return "tie"
dec = [deciding(i) for i in range(5)]
check("L11.4 reps: K order = s12.1 order photon<tilted<meson<baryon<nuclei<atoms", chain_ok,
      "; ".join(f"{order[i]}<{order[i+1]}@{dec[i]}" for i in range(5)))
check("L11.4 deciding components: tilted step at Ss, meson/baryon at Res, others at Ntot",
      dec[0] == "Ss" and dec[2] == "Res" and dec[1] == dec[3] == dec[4] == "Ntot", str(dec))
check("L11.4 meson/baryon identical count vectors (census ties), keys separate only at Res/Tau0 level",
      reps["meson"]["bodies"] == reps["baryon"]["bodies"] and Ks["meson"][1] == 0 and Ks["baryon"][1] == 1)
# homogeneous families, equal size m=1..5
def fam(p, m):
    return {"bodies": p["bodies"]*m, "junctions": p["junctions"]*m}
check("L11.4 homogeneous families m=1..5 preserve the chain order",
      all(K(fam(reps[order[i]], m)) < K(fam(reps[order[i+1]], m)) for m in range(1, 6) for i in range(5)))
# empty declaration
check("L11.4 empty declaration K = (0,1,0,0,0,0,()) as s11.3 states",
      K({"bodies": [], "junctions": []}) == (0, 1, 0, 0, 0, 0, ()))
# relabelling invariance + transitivity spot check over random populations
rng2 = random.Random(7)
inv = True
for _ in range(200):
    nb = rng2.randint(0, 4)
    bodies = [(rng2.randint(1, 4), (), 0, rng2.randint(0, 5), rng2.randint(0, 3)) for _ in range(nb)]
    bodies = [(N, kj, 6*N, s2, u) for (N, kj, _b, s2, u) in bodies]
    js = [((rng2.choice([-1,0,1]),), (rng2.choice([-1,0,1]),)) for _ in range(rng2.randint(0, 3))]
    p1 = {"bodies": bodies, "junctions": js}
    perm = bodies[:]; rng2.shuffle(perm)
    if K(p1) != K({"bodies": perm, "junctions": js}): inv = False
check("L11.4 K invariant under relabelling of members (200 random populations)", inv)
# tick-stability: Ntot,Ss,Su,Btot,CenSig invariant; Res/Tau0 not (sharpness witness)
w1 = {"bodies": [(1, (1,), 5, 0, 0)], "junctions": [((1,), (-1,))]}
w2 = {"bodies": [(1, (1,), 5, 0, 0)], "junctions": [((0,), (0,))]}
check("L11.4 sharpness: one-junction witness pair reverses order-relevant components under the tick "
      "(acting pop has Res=0,Tau0=2; after tick it equals the resting pop's Res=1,Tau0=0)",
      K(w1)[1:3] == (0, 2) and K(w2)[1:3] == (1, 0) and K(w1) < K(w2))
# proper-prefix CenSig: vacuity check -- prefix branch unreachable when earlier components tie,
# because equal leading vectors + extra vectors (each N>=1) force Ntot to differ.
print("NOTE CenSig proper-prefix rule: if two signatures are in proper-prefix relation and all "
      "earlier components tie, equal leading vectors force the longer signature's Ntot larger "
      "(each extra vector has N>=1) -- contradiction; the prefix branch is a completeness "
      "convention for the order, unreachable on tie paths. Verified by the argument in the log.")

print()
print("FAILURES:", fails if fails else "none")
sys.exit(1 if fails else 0)
