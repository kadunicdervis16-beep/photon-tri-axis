#!/usr/bin/env python3
"""Arm N Role D -- independent reimplementation (c): an A.5-class
assignment-count computation, from §8.2-8.4 of the frozen Paper 12 v4.

Two routes, neither importing any paper code:
  ROUTE 1 (enumeration): literally enumerate assignments of named bodies.
    Two-class: all 2^n assignments of bodies {0..n-1} to classes A/B,
    counted per record k.  Multi-class: all r^n assignments counted per
    record (n1,...,nr). This is the definition of §8.2 read literally:
    "choose which k of the n named bodies are the ones in A".
  ROUTE 2 (closed form): Omega(k;n) by the product form of eq. (8.1),
    prod_{j=1..k} (n-k+j)/j in exact integer steps; multinomial
    n!/(n1!...nr!) by sequential choosing.
The printed table of §8.3 (lines 1704-1711) and the §8.3/§8.7 printed
values are the comparison oracle only.
Checks: the n=1..6 table (counts, totals, maxima, polarized and
balanced shares); ratio eq. (8.3); bound C(2m,m) >= 2^m (8.5);
inequality (8.7) for n=1..60 as exact fractions; multinomial values
incl. the (2,2,2) record at n=6 and the n=12 maximum 924 at (6,6)
with share 231/1024 (printed at §8.7 / registry L8.8).
"""
from fractions import Fraction
from itertools import product as cart
from math import factorial

def omega_enum_2class(n):
    counts = [0] * (n + 1)
    for assign in cart((0, 1), repeat=n):
        counts[sum(assign)] += 1
    return counts

def omega_closed(k, n):
    # eq. (8.1) product form, exact integer at every step
    res = 1
    for j in range(1, k + 1):
        res = res * (n - k + j) // j
    return res

def omega_enum_multi(n, r):
    counts = {}
    for assign in cart(range(r), repeat=n):
        rec = tuple(assign.count(c) for c in range(r))
        counts[rec] = counts.get(rec, 0) + 1
    return counts

def omega_multi_closed(record):
    n = sum(record)
    res = factorial(n)
    for c in record:
        res //= factorial(c)
    return res

PRINTED = {  # §8.3 table, lines 1706-1711
    1: ([1, 1], 2, 1, Fraction(1, 1), Fraction(0, 1), Fraction(1, 2)),
    2: ([1, 2, 1], 4, 2, Fraction(1, 2), Fraction(1, 2), Fraction(1, 2)),
    3: ([1, 3, 3, 1], 8, 3, Fraction(1, 4), Fraction(3, 4), Fraction(3, 8)),
    4: ([1, 4, 6, 4, 1], 16, 6, Fraction(1, 8), Fraction(7, 8), Fraction(3, 8)),
    5: ([1, 5, 10, 10, 5, 1], 32, 10, Fraction(1, 16), Fraction(15, 16), Fraction(5, 16)),
    6: ([1, 6, 15, 20, 15, 6, 1], 64, 20, Fraction(1, 32), Fraction(31, 32), Fraction(5, 16)),
}

def main():
    fails = []
    def check(label, got, want):
        ok = got == want
        print(f"{label}: got {got} | printed/expected {want} | {'MATCH' if ok else 'MISMATCH'}")
        if not ok:
            fails.append(label)

    print("== §8.3 table by enumeration (route 1) vs closed form (route 2) vs printed ==")
    for n in range(1, 7):
        enum = omega_enum_2class(n)
        closed = [omega_closed(k, n) for k in range(n + 1)]
        total = sum(enum)
        pol = Fraction(enum[0] + enum[n], total)
        bal = Fraction(max(enum), total)
        got = (enum, total, max(enum), pol, 1 - pol, bal)
        check(f"n={n} full row", got, PRINTED[n])
        check(f"n={n} enum == closed form", enum, closed)

    print("== eq. (8.3) ratios, n=6 ==")
    c6 = omega_enum_2class(6)
    ratios = [Fraction(c6[k + 1], c6[k]) for k in range(6)]
    check("ratios", ratios, [Fraction(6, 1), Fraction(5, 2), Fraction(4, 3),
                             Fraction(3, 4), Fraction(2, 5), Fraction(1, 6)])
    check("ratio formula (n-k)/(k+1) for n=1..12, all k",
          all(Fraction(omega_closed(k + 1, n), omega_closed(k, n)) == Fraction(n - k, k + 1)
              for n in range(1, 13) for k in range(n)), True)

    print("== eq. (8.5): C(2m,m) >= 2^m ==")
    check("m=1..20", all(omega_closed(m, 2 * m) >= 2 ** m for m in range(1, 21)), True)
    check("spot values m=1,2,3", [omega_closed(m, 2 * m) for m in (1, 2, 3)], [2, 6, 20])

    print("== eq. (8.7): 1 - 2^(1-n) >= (n-1)/n, exact fractions ==")
    check("n=1..60", all(1 - Fraction(2, 2 ** n) >= Fraction(n - 1, n)
                         for n in range(1, 61)), True)
    check("polarized share formula 2^(1-n), n=1..12",
          all(Fraction(2, 2 ** n) == Fraction(1, 2 ** (n - 1)) for n in range(1, 13)), True)

    print("== multinomial (§8.4) by enumeration vs closed form ==")
    enum3 = omega_enum_multi(6, 3)
    check("(2,2,2) at n=6 (the E-MID Omega-maximal record shape)",
          (enum3[(2, 2, 2)], omega_multi_closed((2, 2, 2))), (90, 90))
    check("3-class total at n=6 = 3^6", sum(enum3.values()), 729)
    enum2_12 = omega_enum_2class(12)
    check("n=12: total, max at (6,6), max share",
          (sum(enum2_12), max(enum2_12), Fraction(max(enum2_12), sum(enum2_12))),
          (4096, 924, Fraction(231, 1024)))
    check("n=12 polarized share", Fraction(2, 4096), Fraction(1, 2048))

    print(f"REIMPL-A5 RESULT: {'ALL ASSIGNMENT COUNTS MATCH' if not fails else 'MISMATCHES: ' + str(fails)}")
    return 1 if fails else 0

if __name__ == "__main__":
    raise SystemExit(main())
