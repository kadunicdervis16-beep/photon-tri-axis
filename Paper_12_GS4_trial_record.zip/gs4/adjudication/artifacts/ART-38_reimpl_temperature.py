#!/usr/bin/env python3
"""Arm H independent reimplementation (b): population temperature /
census ratios for one Spine population (E-SMALL), from Paper 12's
prose definitions only -- s7.2 eq. (7.1)-(7.2), s7.3 eq. (7.3)-(7.4),
Appendix F's E-SMALL declarations. No paper code imported.

Definitions used:
  r_b(tau) = 97 - v2_contact - s2 at a contact tick (eq. 7.2, from
             Paper 10 eq. (2.4): N_total = 3 + v2 + s2 + r = 100);
             0 at a tick with no occasion.
  R(P, W)  = sum over bodies and window ticks of r_b(tau)   (7.1)
  D(P, W)  = R(P, W) / (|P| * |W|)  in Q                    (7.3)
  D(P, W)  = mean of the local densities D_b over same W    (7.4)
Window for E-SMALL per Appendix F: W = ticks 1-3 (|W| = 3).
Declarations (Appendix F, E-SMALL): S1 contact tick 1 (91, 5);
S2 contact tick 1 (93, 3); S3 contact tick 2 (90, 4). |P| = 3.
Printed values under test: bookings 1, 1, 3; R = 5; D = 5/9;
locals 1/3, 1/3, 1; mean 5/9.
"""
from fractions import Fraction

CONTACTS = {  # body -> {tick: (v2_contact, s2)}
    "S1": {1: (91, 5)},
    "S2": {1: (93, 3)},
    "S3": {2: (90, 4)},
}
W = [1, 2, 3]
PRINTED_BOOKINGS = {"S1": 1, "S2": 1, "S3": 3}
PRINTED_R, PRINTED_D = 5, Fraction(5, 9)
PRINTED_LOCALS = {"S1": Fraction(1, 3), "S2": Fraction(1, 3), "S3": Fraction(1, 1)}

def r_b(body, tick):
    if tick in CONTACTS[body]:
        v2, s2 = CONTACTS[body][tick]
        return 97 - v2 - s2
    return 0

def main():
    bookings = {}
    for b in CONTACTS:
        for t in W:
            r = r_b(b, t)
            if r:
                bookings[b] = bookings.get(b, 0) + r
            # budget identity check at contact ticks: 3 + v2 + s2 + r = 100
            if t in CONTACTS[b]:
                v2, s2 = CONTACTS[b][t]
                assert 3 + v2 + s2 + r == 100, (b, t)
    print("bookings recomputed:", bookings, "| printed:", PRINTED_BOOKINGS,
          "| MATCH:", bookings == PRINTED_BOOKINGS)
    R = sum(r_b(b, t) for b in CONTACTS for t in W)
    D = Fraction(R, len(CONTACTS) * len(W))
    print(f"R(P,W) = {R} (printed {PRINTED_R}, match {R == PRINTED_R})")
    print(f"D(P,W) = {D} (printed {PRINTED_D}, match {D == PRINTED_D})")
    locals_ = {b: Fraction(sum(r_b(b, t) for t in W), len(W)) for b in CONTACTS}
    mean = sum(locals_.values()) / len(locals_)
    print("local densities:", {k: str(v) for k, v in locals_.items()},
          "| printed:", {k: str(v) for k, v in PRINTED_LOCALS.items()},
          "| MATCH:", locals_ == PRINTED_LOCALS)
    print(f"mean of locals = {mean} | eq. (7.4) identity D == mean: {mean == D}")
    # hostile probe: window sensitivity -- D is a window-relative ratio;
    # s7.3 defines it only over a declared window, so a different declared
    # window giving a different value is NOT a defect. Recorded, not filed.
    W2 = [0, 1, 2, 3]
    D2 = Fraction(sum(r_b(b, t) for b in CONTACTS for t in W2), len(CONTACTS) * len(W2))
    print(f"[probe] same population, window ticks 0-3: D = {D2} (definition is window-indexed; no claim violated)")

if __name__ == "__main__":
    main()
