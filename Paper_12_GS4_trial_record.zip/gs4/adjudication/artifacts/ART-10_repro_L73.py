#!/usr/bin/env python3
"""GS4-D independent reproduction for L7.3-P12 (Role C, Arm N).
Independent of Paper 12's script A.6: re-derives eq. (7.4) from eq. (7.3)'s
definition using exact Fraction arithmetic, on (a) the Appendix D exhibit's
printed local densities (LD.5-P12) and (b) 2000 random instances.
Definition used (Paper 12 SS0.5 construction row / SS7.3):
  R(P,W) = sum_b sum_{tau in W} r_b(tau);  D(P,W) = R / (|P|*|W|);
  local density of body b over shared window W: d_b = (sum_tau r_b(tau))/|W|.
Claim checked: D(P,W) == mean_b d_b  exactly, and D is an exact rational.
"""
from fractions import Fraction
import random

# (a) Appendix D exhibit (LD.5-P12 printed values)
locals_printed = [Fraction(1), Fraction(1), Fraction(2), Fraction(2,3),
                  Fraction(5,3), Fraction(5,3), Fraction(7,3), Fraction(5,3),
                  Fraction(1), Fraction(2,3), Fraction(1), Fraction(11,3)]
D_printed = Fraction(55,36)
mean_locals = sum(locals_printed) / len(locals_printed)
print("exhibit: mean of printed locals =", mean_locals,
      "| printed D =", D_printed, "| equal:", mean_locals == D_printed)
assert mean_locals == D_printed

# (b) random instances, exact rational arithmetic
rng = random.Random(20261031)
for trial in range(2000):
    npop = rng.randrange(1, 9)
    nwin = rng.randrange(1, 7)
    r = [[rng.randrange(0, 50) for _ in range(nwin)] for _ in range(npop)]
    R = sum(sum(row) for row in r)
    D = Fraction(R, npop * nwin)
    locals_ = [Fraction(sum(row), nwin) for row in r]
    assert D == sum(locals_) / npop, (trial, D)
    assert isinstance(D, Fraction)
print("random: 2000/2000 instances — (7.4) identity exact, D rational in all")
print("VERDICT: finite-range reproduction PASS (independent implementation)")
