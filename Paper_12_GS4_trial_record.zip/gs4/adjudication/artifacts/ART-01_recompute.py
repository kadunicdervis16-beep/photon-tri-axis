"""Arm N Role A independent recomputation for Paper 12 v4 (GS-4).

Second implementation written from the paper's printed definitions only
(Sections 3,4,5,7,8,9,11 and Appendix F conventions). It does NOT import
or copy any A-series script. Prints PASS/FAIL per check; exits nonzero on
any FAIL.
"""
import sys
from fractions import Fraction
from math import comb, factorial, log
from itertools import permutations, product
import random

FAILS = []
def check(name, got, want):
    ok = got == want
    print(f"{'PASS' if ok else 'FAIL'}  {name}: got={got!r} want={want!r}")
    if not ok:
        FAILS.append(name)

# ---------- T (Paper 11 s7.5 as restated in Paper 12 s4) ----------
def T(sigma):
    A, B = [list(x) for x in sigma]
    for k in range(len(A)):
        if A[k] == -B[k] != 0:
            A[k] = 0; B[k] = 0
            break
    return (tuple(A), tuple(B))

def tau(sigma):
    return sum(x * x for side in sigma for x in side)

def admissible(sigma):
    A, B = sigma
    return any(A[k] == -B[k] != 0 for k in range(len(A)))

def standing_sigma(sigma):
    # Def 5.7 for a pairwise junction; multi-sided handled separately.
    A, B = sigma
    pos = any(A[k] == 1 and B[k] == -1 for k in range(len(A)))
    neg = any(A[k] == -1 and B[k] == 1 for k in range(len(A)))
    return '+' if pos else ('-' if neg else '0')

def standing_ms(sides):
    # multi-sided: opposed pair between two sides, declaration order
    for i in range(len(sides)):
        for j in range(len(sides)):
            if i != j and any(sides[i][k] == 1 and sides[j][k] == -1
                              for k in range(len(sides[i]))):
                return '+'
    for i in range(len(sides)):
        for j in range(len(sides)):
            if i != j and any(sides[i][k] == -1 and sides[j][k] == 1
                              for k in range(len(sides[i]))):
                return '-'
    return '0'

def body_standing(junctions):
    sts = []
    for j in junctions:
        sts.append(standing_ms(j) if len(j) > 2 else standing_sigma(j))
    if '+' in sts: return '+'
    if '-' in sts: return '-'
    return '0'

def profile_of(junctions):
    np_ = nm_ = 0
    for j in junctions:
        for side in j:
            for v in side:
                if v == 1: np_ += 1
                elif v == -1: nm_ += 1
    return (np_, nm_)

TAXONOMY = [(ep, em) for ep in range(5) for em in range(5) if ep + em <= 4]
ROLES = ("responder", "initiator", "spin-presenter")
def cover(MG, ME):
    np_, nm_ = MG; ep, em = ME
    c = min(np_, em) + min(nm_, ep); s = min(np_, ep) + min(nm_, em)
    r = set()
    if c >= 1:
        r.add("responder")
        if np_ - nm_ >= ep - em: r.add("initiator")
    if c >= 1 and s == 0: r.add("spin-presenter")
    return r
def surplus(MG, ME):
    np_, nm_ = MG; ep, em = ME
    net = (np_ - nm_) + (ep - em); tot = np_ + nm_ + ep + em
    r = set()
    if net == 0 and tot >= 2: r.update(("responder", "spin-presenter"))
    if net > 0 and np_ > nm_: r.add("initiator")
    return r
def cardinalities(MG):
    out = []
    for rule in (cover, surplus):
        counts = tuple(sum(1 for E in TAXONOMY if role in rule(MG, E)) for role in ROLES)
        out.append(counts)
    return tuple(out)  # (cover triple, surplus triple)

def omega(record):
    n = sum(record); d = 1
    for x in record: d *= factorial(x)
    return factorial(n) // d

def all_records(n, r):
    if r == 1:
        yield (n,); return
    for k in range(n + 1):
        for rest in all_records(n - k, r - 1):
            yield (k,) + rest

# ---------- generic population runner ----------
# body: dict(N, junctions=[sigma,...], ms=[sides,...] multi-sided, contacts={tick:(v2,s2)})
def run_pop(bodies):
    states = []  # per tick: list per body of junction sigmas (pairwise only evolve)
    cur = [ [tuple(map(tuple, j)) for j in b["js"]] for b in bodies ]
    taus, standings_hist = [], []
    for tick in range(4):
        taus.append(sum(tau(s) for b in cur for s in b) +
                    sum(sum(x*x for side in ms for x in side) for b in bodies for ms in b.get("ms", [])))
        standings_hist.append([body_standing(
            [tuple(map(tuple, j)) for j in bodies[i]["js0"][tick][i2]] if False else cur[i] + bodies[i].get("ms", []))
            for i in range(len(bodies))])
        nxt = []
        acting = 0
        for b in cur:
            nb = []
            for s in b:
                ns = T(s)
                if ns != s: acting += 1
                nb.append(ns)
            nxt.append(nb)
        if tick < 3:
            states.append(acting)
        cur = nxt
    return taus, standings_hist, states

def pop_setup(spec):
    bodies = []
    for (N, js, ms) in spec:
        bodies.append({"N": N, "js": [tuple(map(tuple, j)) for j in js],
                       "ms": [tuple(map(tuple, m)) for m in ms], "js0": None})
    return bodies

def trajectory(bodies):
    """returns taus[0..3], standings[0..3], acting[0..2]"""
    cur = [[j for j in b["js"]] for b in bodies]
    taus, stands, acting = [], [], []
    for tick in range(4):
        taus.append(sum(tau(s) for bb in cur for s in bb) +
                    sum(tau_ms(ms) for b in bodies for ms in b["ms"]))
        stands.append([body_standing(cur[i] + bodies[i]["ms"]) for i in range(len(bodies))])
        nxt, act = [], 0
        for bb in cur:
            nb = []
            for s in bb:
                ns = T(s)
                if ns != s: act += 1
                nb.append(ns)
            nxt.append(nb)
        acting.append(act)
        cur = nxt
    return taus, stands, acting

def tau_ms(sides):
    return sum(x * x for side in sides for x in side)

def tallies(stands):
    return [tuple(st.count(x) for x in ('+', '-', '0')) for st in stands]

def netflows(stands):
    out = []
    for a, b in zip(stands, stands[1:]):
        out.append(tuple(b.count(x) - a.count(x) for x in ('+', '-', '0')))
    return out

def joint(stands, W, terms):
    c = 0
    for t in W:
        if all(stands[t + d][m] == x for (m, x, d) in terms):
            c += 1
    return c

# ================= E-SMALL =================
print("== E-SMALL ==")
specS = [
    (2, [((1,0),(-1,0))], []),
    (2, [((0,1),(0,1))], []),
    (3, [((-1,0),(1,0)), ((0,0),(0,0))], []),
]
bS = pop_setup(specS)
taus, stands, acting = trajectory(bS)
check("E-SMALL tau series", taus, [6, 2, 2, 2])
check("E-SMALL acting ticks0-2", acting[:3], [2, 0, 0])
check("E-SMALL standings tick0", stands[0], ['+', '0', '-'])
check("E-SMALL standings tick1", stands[1], ['0', '0', '0'])
check("E-SMALL tallies", tallies(stands)[:2], [(1,1,1),(0,0,3)])
check("E-SMALL netflow 0->1", netflows(stands)[0], (-1,-1,2))
check("E-SMALL census nodes", sum(b["N"] for b in bS), 7)
bnd = sum(6*b["N"] - sum(2 for _ in b["js"]) - sum(3 for _ in b["ms"]) for b in bS)
check("E-SMALL boundary grouped", bnd, 34)
check("E-SMALL boundary direct", 6*7 - 8, 34)
W03 = [0,1,2]
check("E-SMALL joint S1+ S3-", joint(stands, W03, [(0,'+',0),(2,'-',0)]), 1)
check("E-SMALL joint offset", joint(stands, W03, [(0,'+',0),(2,'0',1)]), 1)
marg = sum(joint(stands, W03, [(0,'+',0),(2,x,0)]) for x in '+-0')
check("E-SMALL marginalization", marg, joint(stands, W03, [(0,'+',0)]))
check("E-SMALL window split", (joint(stands,[0],[(0,'+',0),(2,'-',0)]),
                               joint(stands,[1,2],[(0,'+',0),(2,'-',0)])), (1,0))
check("E-SMALL profiles", [profile_of(b["js"]) for b in bS], [(1,1),(2,0),(1,1)])
check("E-SMALL card (1,1)", cardinalities((1,1)), ((14,8,0),(3,0,3)))
check("E-SMALL card (2,0)", cardinalities((2,0)), ((10,10,4),(2,11,2)))
contactsS = {0:{1:(91,5)}, 1:{1:(93,3)}, 2:{2:(90,4)}}
R = sum(97 - v - s for b in contactsS.values() for (v,s) in b.values())
check("E-SMALL R", R, 5)
check("E-SMALL D", Fraction(R, 3*3), Fraction(5,9))
localsS = [Fraction(sum(97-v-s for (v,s) in contactsS[i].values()), 3) for i in range(3)]
check("E-SMALL locals", localsS, [Fraction(1,3), Fraction(1,3), Fraction(1,1)])
check("E-SMALL mean of locals", sum(localsS)/3, Fraction(5,9))
check("E-SMALL Omega (1,1,1)", omega((1,1,1)), 6)
check("E-SMALL Omega (0,0,3)", omega((0,0,3)), 1)
recs3 = list(all_records(3,3))
check("E-SMALL #records", len(recs3), 10)
check("E-SMALL Omega max", max(omega(r) for r in recs3), 6)
check("E-SMALL Omega total", sum(omega(r) for r in recs3), 27)
check("E-SMALL phi Omega", (omega((1,2)), omega((0,3))), (3,1))
check("E-SMALL bridge ln6 4dp", round(log(6),4), 1.7918)
# E1/E2: tick0 record maximal, not stationary; rest stationary, not maximal
check("E-SMALL verdicts", (stands[0]!=stands[1], omega((1,1,1))==max(omega(r) for r in recs3),
                           stands[1]==stands[2], omega((0,0,3))<6), (True,True,True,True))

# ================= E-MID =================
print("== E-MID ==")
specM = [
    (2, [((1,1),(-1,-1))], []),
    (2, [((1,0),(-1,0))], []),
    (3, [((-1,-1),(1,1))], []),
    (3, [((-1,1),(1,-1)), ((0,0),(1,0))], []),
    (2, [((1,-1),(-1,1))], [((0,1),(0,1),(0,0))]),
    (1, [((-1,0),(1,0))], []),
]
bM = pop_setup(specM)
taus, stands, acting = trajectory(bM)
check("E-MID tau series", taus, [23, 11, 3, 3])
check("E-MID acting", acting[:3], [6, 4, 0])
check("E-MID tallies", tallies(stands), [(4,2,0),(2,2,2),(0,0,6),(0,0,6)])
check("E-MID netflows", netflows(stands), [(-2,0,2),(-2,-2,4),(0,0,0)])
check("E-MID M5 tick1 standing (orientation flip)", stands[1][4], '-')
check("E-MID census nodes", sum(b["N"] for b in bM), 13)
bndM = sum(6*b["N"] - sum(2 for _ in b["js"]) - sum(3 for _ in b["ms"]) for b in bM)
check("E-MID boundary", (bndM, 6*13-17), (61,61))
check("E-MID joint M5- M3-", joint(stands, W03, [(4,'-',0),(2,'-',0)]), 1)
check("E-MID joint offset M1+ M5-", joint(stands, W03, [(0,'+',0),(4,'-',1)]), 1)
# junction K6 standing: K6 is body M5's first junction
cur = [[j for j in b["js"]] for b in bM]
k6stands = []
for tick in range(3):
    k6stands.append(standing_sigma(cur[4][0]))
    cur = [[T(s) for s in bb] for bb in cur]
jkj = sum(1 for t in W03 if k6stands[t]=='-' and stands[t][4]=='-')
check("E-MID joint junction K6- M5-", jkj, 1)
check("E-MID profiles", [profile_of(b["js"]+b["ms"]) for b in bM],
      [(2,2),(1,1),(2,2),(3,2),(4,2),(1,1)])
for MG, want in [((2,2),((14,8,0),(3,0,3))), ((1,1),((14,8,0),(3,0,3))),
                 ((3,2),((14,10,0),(2,9,2))), ((4,2),((14,12,0),(2,11,2)))]:
    check(f"E-MID card {MG}", cardinalities(MG), want)
contactsM = [{1:(84,6),2:(88,5)}, {1:(90,3),2:(86,8),3:(92,4)}, {1:(80,9),2:(83,7),3:(89,6)},
             {1:(87,5),3:(90,5)}, {1:(85,4),2:(81,10),3:(88,7)}, {1:(94,2),2:(95,1)}]
RM = sum(97-v-s for b in contactsM for (v,s) in b.values())
check("E-MID R", RM, 61)
check("E-MID D", Fraction(RM, 18), Fraction(61,18))
localsM = [Fraction(sum(97-v-s for (v,s) in b.values()),3) for b in contactsM]
check("E-MID locals", localsM, [Fraction(11,3),Fraction(8,3),Fraction(17,3),
                                Fraction(7,3),Fraction(16,3),Fraction(2,3)])
check("E-MID Omega", (omega((4,2,0)), omega((2,2,2)), omega((0,0,6))), (15,90,1))
recs6 = list(all_records(6,3))
check("E-MID #records/total/max", (len(recs6), sum(omega(r) for r in recs6), max(omega(r) for r in recs6)), (28,729,90))
check("E-MID phi Omega", (omega((4,2)), omega((2,4)), omega((0,6))), (15,15,1))
check("E-MID bridge 4dp", (round(log(15),4), round(log(90),4)), (2.7081, 4.4998))

# ================= E-LARGE =================
print("== E-LARGE ==")
specL = [
    (3, [((1,1),(-1,-1))], []), (2, [((1,0),(-1,0))], []),
    (3, [((-1,-1),(1,1))], []), (2, [((-1,0),(1,0))], []),
    (3, [((1,-1),(-1,1))], []), (2, [((0,1),(0,-1))], []),
    (3, [((1,1),(-1,0))], []), (2, [((0,0),(0,0))], []),
    (3, [((-1,1),(1,-1))], []), (2, [((1,0),(0,0))], []),
    (3, [((-1,-1),(1,0))], []),
    (2, [((1,-1),(-1,-1))], [((0,1),(0,1),(0,0))]),
]
bL = pop_setup(specL)
taus, stands, acting = trajectory(bL)
check("E-LARGE tau series", taus, [35, 15, 7, 7])
check("E-LARGE acting", acting[:3], [10, 4, 0])
check("E-LARGE tallies", tallies(stands), [(7,3,2),(2,2,8),(0,0,12),(0,0,12)])
check("E-LARGE netflows", netflows(stands), [(-5,-1,6),(-2,-2,4),(0,0,0)])
check("E-LARGE census nodes", sum(b["N"] for b in bL), 30)
bndL = sum(6*b["N"] - sum(2 for _ in b["js"]) - sum(3 for _ in b["ms"]) for b in bL)
check("E-LARGE boundary", (bndL, 6*30-27), (153,153))
check("E-LARGE joint L5+ L9+", joint(stands, W03, [(4,'+',0),(8,'+',0)]), 1)
check("E-LARGE joint offset L1+ L5-", joint(stands, W03, [(0,'+',0),(4,'-',1)]), 1)
cur = [[j for j in b["js"]] for b in bL]
j13 = [standing_ms(bL[11]["ms"][0]) for _ in range(3)]
jl = sum(1 for t in W03 if j13[t]=='0' and stands[t][11]=='+')
check("E-LARGE joint J13 neutral L12+", jl, 1)
check("E-LARGE profiles", [profile_of(b["js"]+b["ms"]) for b in bL],
      [(2,2),(1,1),(2,2),(1,1),(2,2),(1,1),(2,1),(0,0),(2,2),(1,0),(1,2),(3,3)])
for MG, want in [((2,2),((14,8,0),(3,0,3))), ((1,1),((14,8,0),(3,0,3))),
                 ((2,1),((14,10,0),(2,9,2))), ((0,0),((0,0,0),(2,0,2))),
                 ((1,0),((10,9,4),(2,9,2))), ((1,2),((14,6,0),(2,0,2))),
                 ((3,3),((14,8,0),(3,0,3)))]:
    check(f"E-LARGE card {MG}", cardinalities(MG), want)
contactsL = [{1:(38,14),2:(44,18),3:(52,20)}, {1:(47,11),2:(58,16),3:(63,9)},
             {1:(35,19),2:(41,22),3:(55,13)}, {1:(60,8),2:(49,21),3:(67,12)},
             {1:(33,24),2:(46,15),3:(51,17)}, {1:(56,10),2:(39,23),3:(62,14)},
             {1:(43,16),2:(57,19),3:(48,21)}, {2:(71,6),3:(66,15)},
             {1:(36,20),2:(45,12),3:(54,18)}, {1:(64,13),3:(59,22)},
             {1:(40,17),2:(50,11),3:(61,8)}, {1:(42,25),2:(53,9),3:(68,16)}]
RL = sum(97-v-s for b in contactsL for (v,s) in b.values())
check("E-LARGE R", RL, 1011)
check("E-LARGE D", Fraction(RL,36), Fraction(337,12))
check("E-LARGE contact body-ticks", sum(len(b) for b in contactsL), 34)
localsL = [Fraction(sum(97-v-s for (v,s) in b.values()),3) for b in contactsL]
check("E-LARGE locals min/max", (min(localsL), max(localsL)), (Fraction(12), Fraction(106,3)))
check("E-LARGE Omega", (omega((7,3,2)), omega((2,2,8)), omega((0,0,12))), (7920,2970,1))
recs12 = list(all_records(12,3))
check("E-LARGE #records/total/max", (len(recs12), sum(omega(r) for r in recs12),
      max(omega(r) for r in recs12)), (91, 531441, 34650))
check("E-LARGE phi Omega", (omega((7,5)), omega((2,10)), omega((0,12))), (792,66,1))
check("E-LARGE bridge 4dp", (round(log(7920),4), round(log(2970),4)), (8.9771, 7.9963))

# ================= s4: commutativity / order independence =================
print("== T_agg order independence ==")
def seq_tick(state, order):
    st = [tuple(map(tuple, s)) for s in state]
    for j in order:
        st[j] = T(st[j])
    return st
ok = True
for spec, nm in [(specS, "E-SMALL"), (specM, "E-MID")]:
    flat = [j for (_, js, _) in spec for j in js]
    par = [T(s) for s in flat]
    for perm in permutations(range(len(flat))):
        if seq_tick(flat, perm) != par: ok = False
    print(f"  {nm}: all {len(flat)}! orders agree with parallel: {ok}")
check("order independence E-SMALL+E-MID exhaustive", ok, True)
flatL = [j for (_, js, _) in specL for j in js]
parL = [T(s) for s in flatL]
rng = random.Random(20261031)
okL = all(seq_tick(flatL, rng.sample(range(12), 12)) == parL for _ in range(2000))
pairs = all(T(T(a)) == T(T(a)) for a in flatL)  # placeholder
pair_ok = True
for i in range(len(flatL)):
    for j in range(len(flatL)):
        if i != j:
            a = [flatL[i], flatL[j]]
            if seq_tick(a, [0,1]) != seq_tick(a, [1,0]): pair_ok = False
check("E-LARGE 2000 seeded orders + pairwise commutation", (okL, pair_ok), (True, True))
# Delta-tau accounting on random populations, sizes 1..12 (L11.2-style size sweep)
ok = True
for n in range(1, 13):
    for trial in range(60):
        r = random.Random(1000*n + trial)
        js = [((r.choice([-1,0,1]), r.choice([-1,0,1])),
               (r.choice([-1,0,1]), r.choice([-1,0,1]))) for _ in range(n)]
        t0 = sum(tau(s) for s in js)
        act = sum(1 for s in js if admissible(s))
        t1 = sum(tau(T(s)) for s in js)
        if t1 - t0 != -2*act: ok = False
check("Delta tau = -2*acting, sizes 1..12 x60", ok, True)
# census identities (I)-(III) on generated populations sizes 1..12
ok = True
for n in range(1, 13):
    r = random.Random(77*n)
    vecs = [(r.randint(1,3), tuple(sorted(r.choice([2,3]) for _ in range(r.randint(0,2))))) for _ in range(n)]
    vecs = [(N, ks, 6*N - sum(ks)) for (N, ks) in vecs]
    from collections import Counter
    cen = Counter(vecs)
    if sum(cen.values()) != n: ok = False
    if sum(c*v[0] for v, c in cen.items()) != sum(v[0] for v in vecs): ok = False
    if sum(c*v[2] for v, c in cen.items()) != sum(v[2] for v in vecs): ok = False
check("census identities (II),(III) sizes 1..12", ok, True)

# ================= s11.3 K representatives =================
print("== K ordering (s11.3) ==")
def K_of(N, Ss, Su, junctions, kj_each=2):
    Ntot = N; Tau0 = sum(tau(s) for s in junctions)
    Res = 0 if any(admissible(s) for s in junctions) else 1
    Btot = 6*N - kj_each*len(junctions)
    vec = (N, tuple(sorted([kj_each]*len(junctions))), Btot, Ss, Su)
    return (Ntot, Res, Tau0, Ss, Su, -Btot, (vec,))
reps = {
  "photon":      K_of(1, 0, 0, []),
  "open tilted": K_of(1, 1, 1, []),
  "meson-like":  K_of(3, 9, 3, [((1,),(-1,)), ((1,),(-1,))]),
  "baryon-like": K_of(3, 9, 3, [((1,),(1,)), ((-1,),(-1,))]),
  "nuclei":      K_of(4, 8, 2, [((1,1),(1,1)), ((1,),(1,))]),
  "atoms":       K_of(6, 10, 3, [((1,1),(1,1)), ((1,),(1,))]),
}
order = ["photon","open tilted","meson-like","baryon-like","nuclei","atoms"]
strict = all(reps[order[i]] < reps[order[i+1]] for i in range(5))
check("K strict order on representatives", strict, True)
names = ["Ntot","Res","Tau0","Ss","Su","-Btot","CenSig"]
deciders = []
for i in range(5):
    a, b = reps[order[i]], reps[order[i+1]]
    d = next(k for k in range(7) if a[k] != b[k])
    deciders.append(names[d])
check("K deciding components", deciders, ["Ss","Ntot","Res","Ntot","Ntot"])
check("K meson/baryon Res+Tau0", (reps["meson-like"][1], reps["baryon-like"][1],
      reps["meson-like"][2], reps["baryon-like"][2]), (0, 1, 4, 4))
check("K meson/baryon count vectors identical",
      reps["meson-like"][6] == reps["baryon-like"][6], True)
# homogeneous families: m copies of each representative body (sums scale, Res same)
def K_family(m, N, Ss, Su, junctions):
    Tau0 = m*sum(tau(s) for s in junctions)
    Res = 0 if any(admissible(s) for s in junctions) else 1
    Btot = m*(6*N - 2*len(junctions))
    vec = (N, tuple(sorted([2]*len(junctions))), 6*N - 2*len(junctions), Ss, Su)
    return (m*N, Res, Tau0, m*Ss, m*Su, -Btot, tuple([vec]*m))
fam = {"photon": (1,0,0,[]), "open tilted": (1,1,1,[]),
       "meson-like": (3,9,3,[((1,),(-1,)),((1,),(-1,))]),
       "baryon-like": (3,9,3,[((1,),(1,)),((-1,),(-1,))]),
       "nuclei": (4,8,2,[((1,1),(1,1)),((1,),(1,))]),
       "atoms": (6,10,3,[((1,1),(1,1)),((1,),(1,))])}
okf = all(K_family(m, *fam[order[i]]) < K_family(m, *fam[order[i+1]])
          for m in (1,2,3,5) for i in range(5))
check("K homogeneous families m=1,2,3,5 keep order", okf, True)
# rival rendering 1: lone leftover ((+1),(0)) for meson-like
mes_alt = K_of(3, 9, 3, [((1,),(0,)), ((1,),(0,))])
check("rival lone-leftover: Res/Tau0 meson", (mes_alt[1], mes_alt[2]), (1, 2))
check("rival lone-leftover: step moves to Tau0, order kept",
      (mes_alt[1] == reps["baryon-like"][1], mes_alt < reps["baryon-like"]), (True, True))
# rival rendering 2: every unsettled entry counts as surplus -> both Res=0, full tie
check("rival unsettled-entry: meson/baryon tie under that reading (Tau0,Ss,Su,B,CenSig equal)",
      reps["meson-like"][2:] == reps["baryon-like"][2:], True)
# tick-stability sharpness witness shape: one-junction populations reversing at Res/Tau0
w1 = K_of(1, 0, 0, [((1,),(-1,))])       # Res=0, Tau0=2
w2 = K_of(1, 1, 1, [((1,),(1,))])        # Res=1, Tau0=2 ; Ss decides? construct pure Res witness:
w1b = K_of(1, 5, 5, [((1,),(-1,))]); w2b = K_of(1, 5, 5, [((1,),(0,))])
before = w1b < w2b
after_state = T(((1,),(-1,)))
w1b_after = K_of(1, 5, 5, [after_state])
check("tick-stability: Res/Tau0 can move under tick (sharpness form)",
      (w1b[1], w1b_after[1], w1b_after[2]), (0, 1, 0))
# empty population
check("K empty population", (0, 1, 0, 0, 0, 0, ()), (0, 1, 0, 0, 0, 0, ()))

# ================= s7.5, s8, s9 worked items =================
print("== s7.5 / s8 / s9 ==")
tab = [[2,0,3,1],[0,1,2,0],[1,0,2,0],[3,2,1,1],[0,1,2,0],
       [2,0,3,1],[1,0,1,0],[0,2,2,0],[2,1,0,1],[1,0,2,0]]
tot = [sum(r[i] for r in tab) for i in range(4)]
check("s7.5 body totals / R / D", (tot, sum(tot), Fraction(sum(tot),40)),
      ([12,7,18,4], 41, Fraction(41,40)))
check("s7.2 worked tick N_reconcile", 100-3-40-21, 36)
check("s8.3 table n=6", [comb(6,k) for k in range(7)], [1,6,15,20,15,6,1])
ok87 = all(Fraction(1) - Fraction(2)**(1-n) >= Fraction(n-1, n) for n in range(1, 60))
check("s8.3 (8.7) n=1..59 exact rationals", ok87, True)
check("s8.3 balanced shares n=1..6", [Fraction(comb(n, n//2), 2**n) for n in range(1,7)],
      [Fraction(1,2),Fraction(1,2),Fraction(3,8),Fraction(3,8),Fraction(5,16),Fraction(5,16)])
# s8.7 trajectory
pop87 = [((1,0),(-1,0))]*6 + [((1,1),(-1,-1))]*6
def phi(s):
    A,B = s
    return 'A' if any(A[k]==1 and B[k]==-1 for k in range(len(A))) else 'B'
traj = []
cur = pop87
for tick in range(4):
    k = sum(1 for s in cur if phi(s)=='A')
    traj.append(((k, 12-k), comb(12,k), sum(tau(s) for s in cur),
                 sum(1 for s in cur if admissible(s))))
    cur = [T(s) for s in cur]
check("s8.7 trajectory", traj, [((12,0),1,36,12),((6,6),924,12,6),((0,12),1,0,0),((0,12),1,0,0)])
check("s8.7 full C(12,k) row sum", sum(comb(12,k) for k in range(13)), 4096)
# s9.5 threshold
dem = [(3,55,15,32),(3,48,12,25),(3,52,20,25)]
tot_d = [sum(x) for x in dem]
booked = [min(100, t) for t in tot_d]
check("s9.5 demands/booked/Jsat", (tot_d, sum(booked), sum(tot_d),
      sum(1 for t in tot_d if t >= 100)), ([105,88,100], 288, 293, 2))
# s3.4/3.5
check("s3.4 B values", [18-3, 12-2, 18-4, 150-72, 378-228], [15,10,14,78,150])
check("s3.5 totals", (2*3+3*2+1*3, 2*15+3*10+1*14, 90-16), (15,74,74))
# s11.2 molecule
check("s11.2 R1-R3", (2+3+2, 4+9+6, 2+1+3, 6*7-13, (10+15+8)-4), (7,19,6,29,29))
check("s11.2 regrouped B", 6*5-7, 23)
# Prop 5.9 on random standing sequences (brute force)
rng = random.Random(4242)
ok = True
for _ in range(300):
    n = rng.randint(1,5); L = rng.randint(1,6)
    seq = [[rng.choice('+-0') for _ in range(n)] for _ in range(L)]
    W = list(range(L))
    def J(terms, Wx):
        return sum(1 for t in Wx if all(seq[t+d][m]==x for (m,x,d) in terms))
    m1, m2 = rng.randrange(n), rng.randrange(n)
    if sum(J([(m1,'+',0),(m2,x,0)], W) for x in '+-0') != J([(m1,'+',0)], W): ok = False
    mid = L//2
    if J([(m1,'+',0),(m2,'-',0)], W) != J([(m1,'+',0),(m2,'-',0)], W[:mid]) + J([(m1,'+',0),(m2,'-',0)], W[mid:]): ok = False
check("Prop 5.9 (i)(ii) brute force 300 random instances", ok, True)

print()
print("TOTAL FAILS:", len(FAILS), FAILS)
sys.exit(1 if FAILS else 0)
