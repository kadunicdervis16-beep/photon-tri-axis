#!/usr/bin/env python3
"""GS4-D independent reproduction for L11.4-P12 (Role C, Arm N).
Independent mini-implementation of the SS11.3 population key K from the
printed definition only (no use of Paper 12's script A.14):
  K(P) = (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig), lexicographic.
Representatives taken from SS11.3's printed table (N, Ss, Su, junction data).
B for a one-member population is not printed in the table; steps checked
below are exactly those SS11.3 says are decided before -Btot is consulted,
plus Res/Tau0 behaviour under T (Paper 11 SS7.5 rule as restated in SS4:
zero the canonically first admissible pair; tau = sum of squares).
"""
from itertools import permutations

def tau_of(junctions):
    return sum(a*a + b*b for (A, B) in junctions for a, b in zip(A, B))

def admissible(junctions):
    return any(a == -b != 0 for (A, B) in junctions for a, b in zip(A, B))

def key_prefix(N, Ss, Su, junctions):
    """Components of K up to Su (all steps SS11.3 names are decided here)."""
    return (N, 0 if admissible(junctions) else 1, tau_of(junctions), Ss, Su)

REPS = {  # name: (N, Ss, Su, junctions) from SS11.3's table
    "photon":      (1, 0, 0, []),
    "open tilted": (1, 1, 1, []),
    "meson-like":  (3, 9, 3, [((1,), (-1,)), ((1,), (-1,))]),
    "baryon-like": (3, 9, 3, [((1,), (1,)), ((-1,), (-1,))]),
    "nuclei":      (4, 8, 2, [((1, 1), (1, 1)), ((1,), (1,))]),
    "atoms":       (6, 10, 3, [((1, 1), (1, 1)), ((1,), (1,))]),
}
ORDER = ["photon", "open tilted", "meson-like", "baryon-like", "nuclei", "atoms"]
keys = {n: key_prefix(*REPS[n]) for n in ORDER}
for n in ORDER: print(f"{n:12s} K-prefix {keys[n]}")
for a, b in zip(ORDER, ORDER[1:]):
    assert keys[a] < keys[b], (a, b)
    dec = next(i for i, (x, y) in enumerate(zip(keys[a], keys[b])) if x != y)
    print(f"step {a} -> {b}: decided at component index {dec} "
          f"({'Ntot Res Tau0 Ss Su'.split()[dec]})")
print("SS12.1 order reproduced at the named components: PASS")

# Name invariance + transitivity over populations built from the representatives
def pop_key(members):
    N = sum(REPS[m][0] for m in members); Ss = sum(REPS[m][1] for m in members)
    Su = sum(REPS[m][2] for m in members)
    js = [j for m in members for j in REPS[m][3]]
    return (N, 0 if admissible(js) else 1, tau_of(js), Ss, Su)
pops = [[a, b] for a in ORDER for b in ORDER] + [[a] for a in ORDER]
for p in pops:
    for perm in permutations(p):
        assert pop_key(list(perm)) == pop_key(p)
print(f"name invariance: PASS over {len(pops)} populations x all permutations")
ks = sorted(pop_key(p) for p in pops)
assert all(ks[i] <= ks[i+1] for i in range(len(ks)-1))
print("total preorder on the enumerated population set: PASS (sorted, no inversions)")

# Tick action (T: zero canonically first admissible pair per junction) and
# the sharpness search: a pair whose order reverses between declaration and rest.
def tick(junctions):
    out = []
    for (A, B) in junctions:
        A, B = list(A), list(B)
        for k in range(len(A)):
            if A[k] == -B[k] != 0:
                A[k] = B[k] = 0
                break
        out.append((tuple(A), tuple(B)))
    return out

def rest(junctions):
    while admissible(junctions):
        junctions = tick(junctions)
    return junctions

singles = [(((1,), (-1,)),), (((1,), (1,)),), (((-1,), (-1,)),),
           (((1, 1), (1, -1)),), (((1, 1), (-1, 1)),), (((0,), (1,)),)]
def sk(js):  # one-body population, fixed record (N,Ss,Su)=(1,0,0)
    return (1, 0 if admissible(list(js)) else 1, tau_of(list(js)), 0, 0)
found = None
for p in singles:
    for q in singles:
        if sk(p) < sk(q) and sk(rest(list(p))) > sk(rest(list(q))):
            found = (p, q)
print("sharpness (order reversal declaration->rest):", 
      "FOUND " + str(found) if found else "none in search space")
if found:
    p, q = found
    print("  before:", sk(p), "<", sk(q), " after rest:", sk(rest(list(p))), ">", sk(rest(list(q))))
print("VERDICT: finite-range reproduction PASS (independent implementation)")
