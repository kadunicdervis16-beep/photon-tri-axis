#!/usr/bin/env python3
"""Arm N Role D -- independent reimplementation (a): the population ordering key K.

Written ONLY from the prose of Paper 12 v4:
  - §11.3 Definition (population ordering key), lines 2645-2651 of the frozen paper;
  - §3.1-3.2 (ledger record; count vector), lines 310-326;
  - §4 (admissible(k) iff A[k] = -B[k] != 0; tau(sigma) = sum of squares;
    Proposition 4.3 incl. the multi-sided carry-through sentence), lines 419-578.
No paper script was imported, read, or copied. In particular this file was
written and run BEFORE any inspection of script A.14's listing.

Neutral reading adopted (Arm N, spec 6.2):
  K(P) = (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig), read lexicographically.
  - Ntot, Ss, Su, Btot: population sums of the body record components
    (N, sum s^2, sum u, B), with B(G) = 6N(G) - sum_j k_j.
  - Tau0: aggregate tau at the declared tick = sum over junctions of the
    sum of squares of all presented entries of the junction's local state
    (for a multi-sided junction, over all its sides' entries: Prop. 4.3's
    proof calls tau(sigma_j) "the same sum of squares over its presented
    entries").
  - Res = 1 if NO junction of P presents an admissible index, else 0.
    A junction of more than two sides presents no admissible index
    (§11.3's parenthetical clause).
  - CenSig: the multiset of bodies' count vectors, sorted descending.
    Count vector v(G) = (N, k_j multiset as ascending sorted tuple, B,
    sum s^2, sum u), ordered lexicographically as a tuple (by N, then the
    k_j tuple, then B, then Ss, then Su) -- the order §11.3 states.
    Signatures of different lengths compare vector-by-vector; a proper
    prefix is the smaller (Python's sequence comparison implements
    exactly this convention).
  - Junction arity k_j for a pairwise junction in this implementation is
    the port-vector length (the number of presented port positions);
    for a multi-sided junction it is the side count. This choice is
    immaterial to every deciding component tested below: the two
    representatives whose count vectors must tie (meson-like /
    baryon-like) are given identical junction shapes, and every other
    representative step is decided at or before Ss.
  P precedes Q iff K(P) < K(Q) (lexicographic).
"""
from fractions import Fraction
from itertools import permutations

# ---------- junction / body model ----------
# pairwise junction: ("pair", A tuple, B tuple)
# multi-sided junction: ("multi", (side1 tuple, side2 tuple, ...))

def arity(j):
    if j[0] == "pair":
        return len(j[1])
    return len(j[1])  # number of sides

def tau_junction(j):
    if j[0] == "pair":
        return sum(x * x for x in j[1]) + sum(x * x for x in j[2])
    return sum(x * x for side in j[1] for x in side)

def presents_admissible(j):
    if j[0] != "pair":
        return False  # §11.3: >2 sides presents no admissible index
    A, B = j[1], j[2]
    return any(a == -b != 0 for a, b in zip(A, B))

def tick_junction(j):
    """T of §4: zero the canonically first admissible pair; else unchanged.
    Multi-sided junctions are carried through unchanged (Def. 4.1 scope)."""
    if j[0] != "pair":
        return j
    A, B = list(j[1]), list(j[2])
    for k in range(len(A)):
        if A[k] == -B[k] != 0:
            A[k] = 0
            B[k] = 0
            break
    return ("pair", tuple(A), tuple(B))

class Body:
    def __init__(self, name, N, Ss, Su, junctions):
        self.name, self.N, self.Ss, self.Su = name, N, Ss, Su
        self.junctions = list(junctions)
    def B(self):
        return 6 * self.N - sum(arity(j) for j in self.junctions)
    def count_vector(self):
        kj = tuple(sorted(arity(j) for j in self.junctions))
        return (self.N, kj, self.B(), self.Ss, self.Su)

def K(pop):
    """pop: list of Body. Returns the key tuple of §11.3."""
    Ntot = sum(b.N for b in pop)
    Ss = sum(b.Ss for b in pop)
    Su = sum(b.Su for b in pop)
    Btot = sum(b.B() for b in pop)
    Tau0 = sum(tau_junction(j) for b in pop for j in b.junctions)
    Res = 0 if any(presents_admissible(j) for b in pop for j in b.junctions) else 1
    CenSig = tuple(sorted((b.count_vector() for b in pop), reverse=True))
    return (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig)

def tick_pop(pop):
    return [Body(b.name, b.N, b.Ss, b.Su, [tick_junction(j) for j in b.junctions])
            for b in pop]

COMPONENTS = ["Ntot", "Res", "Tau0", "Ss", "Su", "-Btot", "CenSig"]

def deciding_component(p, q):
    kp, kq = K(p), K(q)
    for i, (x, y) in enumerate(zip(kp, kq)):
        if x != y:
            return COMPONENTS[i], kp, kq
    return "EQUAL", kp, kq

# ---------- §11.3 representatives (table at lines 2655-2662) ----------
def pair(a, b):
    return ("pair", tuple(a), tuple(b))

REPS = {
    "photon":      [Body("photon", 1, 0, 0, [])],
    "open tilted": [Body("tilted", 1, 1, 1, [])],
    "meson-like":  [Body("meson", 3, 9, 3, [pair((1,), (-1,)), pair((1,), (-1,))])],
    "baryon-like": [Body("baryon", 3, 9, 3, [pair((1,), (1,)), pair((-1,), (-1,))])],
    "nuclei":      [Body("nuclei", 4, 8, 2, [pair((1, 1), (1, 1)), pair((1,), (1,))])],
    "atoms":       [Body("atoms", 6, 10, 3, [pair((1, 1), (1, 1)), pair((1,), (1,))])],
}
ORDER = ["photon", "open tilted", "meson-like", "baryon-like", "nuclei", "atoms"]
EXPECTED_DECIDER = {
    ("photon", "open tilted"): "Ss",
    ("open tilted", "meson-like"): "Ntot",
    ("meson-like", "baryon-like"): "Res",
    ("baryon-like", "nuclei"): "Ntot",
    ("nuclei", "atoms"): "Ntot",
}

def main():
    out = []
    def log(s=""):
        out.append(s)
        print(s)

    log("== Representative keys (one-member populations) ==")
    for name in ORDER:
        log(f"{name:12s} K = {K(REPS[name])}")
    log("")
    log("== Adjacent steps vs §11.3's stated deciding components ==")
    ok = True
    for a, b in zip(ORDER, ORDER[1:]):
        dec, ka, kb = deciding_component(REPS[a], REPS[b])
        want = EXPECTED_DECIDER[(a, b)]
        good = (dec == want) and ka < kb
        ok &= good
        log(f"{a} < {b}: decided at {dec} (paper states {want}) "
            f"order holds: {ka < kb}  {'OK' if good else 'MISMATCH'}")
    log("")
    log("== Homogeneous families (m copies, m=1..4): order preserved ==")
    fam_ok = True
    for m in (1, 2, 3, 4):
        keys = []
        for name in ORDER:
            pop = [Body(f"{name}#{i}", REPS[name][0].N, REPS[name][0].Ss,
                        REPS[name][0].Su, REPS[name][0].junctions) for i in range(m)]
            keys.append(K(pop))
        fam_ok &= all(keys[i] < keys[i + 1] for i in range(5))
        log(f"m={m}: strictly increasing along §12.1 order: "
            f"{all(keys[i] < keys[i+1] for i in range(5))}")
    log("")
    log("== Empty population (§11.3: K = (0,1,0,0,0,0,())) ==")
    log(f"K([]) = {K([])}  match: {K([]) == (0, 1, 0, 0, 0, 0, ())}")
    log("")
    log("== Name invariance: all permutations + renamings of a mixed population ==")
    mixed = [Body("alpha", 2, 3, 1, [pair((1, 0), (-1, 0))]),
             Body("beta", 3, 9, 3, [pair((1,), (1,)), pair((-1,), (-1,))]),
             Body("gamma", 1, 0, 0, []),
             Body("delta", 2, 2, 2, [("multi", ((0, 1), (0, 1), (0, 0)))])]
    base = K(mixed)
    inv = True
    for perm in permutations(mixed):
        renamed = [Body(f"renamed{i}", b.N, b.Ss, b.Su, b.junctions)
                   for i, b in enumerate(perm)]
        inv &= (K(renamed) == base)
    log(f"base K = {base}")
    log(f"all 24 permutations with fresh names give identical K: {inv}")
    log("")
    log("== Totality + transitivity over constructed populations ==")
    pops = [REPS[n] for n in ORDER]
    pops += [[Body(f"{n}#{i}", REPS[n][0].N, REPS[n][0].Ss, REPS[n][0].Su,
                   REPS[n][0].junctions) for i in range(2)] for n in ORDER]
    pops += [mixed, [], [Body("solo", 5, 5, 5, [pair((0,), (0,))])]]
    keys = [K(p) for p in pops]
    total = all((a < b) or (a == b) or (a > b) for a in keys for b in keys)
    trans = all(not (a <= b and b <= c) or a <= c
                for a in keys for b in keys for c in keys)
    log(f"{len(pops)} populations, {len(pops)**3} triples: "
        f"totality {total}, transitivity {trans}")
    log("")
    log("== Tick-stability (§11.3 theorem): invariant components ==")
    stab = True
    for name, pop in list(REPS.items()) + [("mixed", mixed)]:
        k0, k1 = K(pop), K(tick_pop(pop))
        invariant = (k0[0] == k1[0] and k0[3] == k1[3] and k0[4] == k1[4]
                     and k0[5] == k1[5] and k0[6] == k1[6])
        stab &= invariant
        log(f"{name:12s} invariants (Ntot,Ss,Su,Btot,CenSig) hold under tick: "
            f"{invariant}; Res {k0[1]}->{k1[1]}, Tau0 {k0[2]}->{k1[2]}")
    log("")
    log("== Sharpness witness (own construction): order decided at Res reverses at rest ==")
    X = [Body("X", 1, 5, 0, [pair((1,), (-1,))])]   # admissible pair stands
    Y = [Body("Y", 1, 1, 0, [pair((0,), (0,))])]    # no admissible pair, Tau0 = 0
    d0, kx0, ky0 = deciding_component(X, Y)
    Xr, Yr = tick_pop(X), tick_pop(Y)
    d1, kx1, ky1 = deciding_component(Xr, Yr)
    log(f"declaration: K(X)={kx0} < K(Y)={ky0}, decided at {d0}")
    log(f"at rest:     K(X)={kx1} > K(Y)={ky1}, decided at {d1}")
    log(f"reversal witnessed: {kx0 < ky0 and kx1 > ky1}")
    log("")
    all_ok = ok and fam_ok and inv and total and trans and stab and (kx0 < ky0 and kx1 > ky1)
    log(f"REIMPL-K RESULT: {'ALL CHECKS MATCH §11.3 AS READ' if all_ok else 'DISCREPANCY -- see above'}")
    return 0 if all_ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
