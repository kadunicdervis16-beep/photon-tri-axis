#!/usr/bin/env python3
"""
Arm H / Role B, second artifact: GS4-F alternative-representative analysis
for L11.4-P12, and the L6.2-P12 profile-reading witness.
Independent implementation from the prose of Paper 12 v4 ss11.3 / s6 and
Paper 11 s8.6's coverage statement (packet paper_11_v69.md L771).
"""
import sys
fails = []
def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + ("  " + detail if detail else ""))
    if not cond: fails.append(name)

def tau(state): return sum(x*x for x in state[0]) + sum(x*x for x in state[1])
def admissible(state):
    return any(state[0][k] == -state[1][k] and state[0][k] != 0 for k in range(len(state[0])))

def K(Ntot, junctions, Ss, Su, Btot, bodies):
    Res = 0 if any(admissible(s) for s in junctions) else 1
    Tau0 = sum(tau(s) for s in junctions)
    CenSig = tuple(sorted(bodies, reverse=True))
    return (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig)

BODY = (3, (1, 1), 16, 9, 3)   # identical count vector for both reps, as in s11.3

# --- Baseline (the paper's constructed representatives) ---
meson_base  = K(3, [((1,), (-1,)), ((1,), (-1,))], 9, 3, 16, [BODY])
baryon_base = K(3, [((1,), (1,)), ((-1,), (-1,))], 9, 3, 16, [BODY])
check("baseline: meson < baryon, decided at Res (0 vs 1), Tau0 tied 4=4",
      meson_base < baryon_base and meson_base[1] == 0 and baryon_base[1] == 1
      and meson_base[2] == baryon_base[2] == 4, f"{meson_base[:3]} vs {baryon_base[:3]}")

# --- ALT-1 (named in s11.3 itself): lone-leftover rendering of surplus ---
# meson surplus as asymmetric lone leftovers ((+1),(0)) at both junctions.
meson_alt1  = K(3, [((1,), (0,)), ((1,), (0,))], 9, 3, 16, [BODY])
check("ALT-1 lone-leftover: meson Res=1, Tau0=2; step vs baryon decided at Tau0 (2<4), order preserved",
      meson_alt1[1] == 1 and meson_alt1[2] == 2 and meson_alt1 < baryon_base
      and meson_alt1[:2] == baryon_base[:2] and meson_alt1[2] < baryon_base[2],
      f"{meson_alt1[:3]} vs {baryon_base[:3]}")

# --- ALT-2 (named in s11.3 itself): unsettled-entry reading ---
# every unsettled entry counts as surplus, incl. same-sign pairs:
# then baryon's same-sign pairs are also 'surplus' -> both reps present
# admissible-or-surplus data identically; rendering gives same Res for both.
# Modelled directly: under that reading Res_meson == Res_baryon == 0 and
# Tau0 tied (4=4), Ss/Su tied -> step decided NOWHERE before CenSig, and the
# census vectors are identical, so CenSig ties too: K_meson == K_baryon.
meson_alt2  = K(3, [((1,), (-1,)), ((1,), (-1,))], 9, 3, 16, [BODY])
baryon_alt2 = (3, 0, 4, 9, 3, -16, (BODY,))  # Res forced to 0 under unsettled-entry reading
check("ALT-2 unsettled-entry reading: keys tie exactly (step decided nowhere)",
      meson_alt2 == baryon_alt2, f"{meson_alt2} vs {baryon_alt2}")

# --- ALT-3 (GS4-F, new): surplus carried in Sigma_u (unmatched sum) ---
# Paper 2's differentia in its own words: surplus = 'unresolved integers
# left at the junction'. Sigma_u is the record's unmatched sum. Render
# meson surplus as Sigma_u = 4 vs baryon Sigma_u = 3, both junction
# presentations free of opposed pairs, Tau0 tied at 2:
#   meson junctions ((+1),(0)),((-1),(0))  -- lone leftovers, Res=1, Tau0=2
#   baryon junctions ((+1),(0)),((-1),(0)) -- same shape, Res=1, Tau0=2
# Keys then reach Su, where 4 > 3 puts meson AFTER baryon: REVERSED.
meson_alt3  = K(3, [((1,), (0,)), ((-1,), (0,))], 9, 4, 16, [(3, (1, 1), 16, 9, 4)])
baryon_alt3 = K(3, [((1,), (0,)), ((-1,), (0,))], 9, 3, 16, [(3, (1, 1), 16, 9, 3)])
check("ALT-3 Sigma_u-carried surplus: all components tie through Ss, Su decides 4>3, meson AFTER baryon (REVERSED vs s12.1)",
      meson_alt3[:4] == baryon_alt3[:4] and meson_alt3[4] == 4 and baryon_alt3[4] == 3
      and meson_alt3 > baryon_alt3, f"{meson_alt3[:5]} vs {baryon_alt3[:5]}")

# --- ALT-4: orientation-swapped opposed pair (robustness control) ---
meson_alt4 = K(3, [((-1,), (1,)), ((-1,), (1,))], 9, 3, 16, [BODY])
check("ALT-4 orientation swap ((-1),(+1)): Res still 0, Tau0 still 4, step still at Res (orientation-blind admissibility)",
      meson_alt4 == meson_base, f"{meson_alt4[:3]}")

# --- ALT-5: baryon with a lone leftover (no opposed pair) ---
baryon_alt5 = K(3, [((1,), (0,)), ((1,), (1,))], 9, 3, 16, [BODY])
check("ALT-5 baryon lone-leftover: Res still 1 (step still at Res vs baseline meson), Tau0 drops to 3",
      baryon_alt5[1] == 1 and baryon_alt5[2] == 3 and meson_base < baryon_alt5)

print()
print("GS4-F conclusion: the s12.1 agreement of L11.4 is a property of the")
print("constructed representatives under the disclosed opposed-pair")
print("identification. ALT-1 moves the deciding component (Res -> Tau0),")
print("ALT-2 makes the step undecidable, ALT-3 REVERSES the step. None of")
print("these contradicts L11.4 as written, which scopes the agreement to")
print("'the representatives constructed at s11.3' under that identification")
print("and claims no rendering-independence (s11.3 states this in terms).")
print()

# ================= L6.2 profile-reading witness =================
# Paper 11 s8.6 (packet L771): the encounter selection rule factors through
# the PAIR's presented count vector M = (n+, n-) of the encounter;
# 'same-count encounters always select the same outcome'.
# Paper 12 Thm 6.2 hypothesis, read least favourably (own-side reading):
# G and G' present equal OWN count profiles. Witness: both present (n+,n-)=(1,0)
# on their own side; the other sides differ, so the PAIR profiles differ and
# s8.6 itself licences different outcomes.
def pair_profile(own, other):
    vals = list(own) + list(other)
    return (sum(1 for v in vals if v == 1), sum(1 for v in vals if v == -1))
def complementary_cover(own, other):
    # s8.6 tension analysis: attraction requires full complementary cover
    return len(own) == len(other) and all(o == -t for o, t in zip(own, other))
G_own  = (1,)     # G presents one +1
Gp_own = (1,)     # G' presents one +1  -> own profiles equal: (1,0) == (1,0)
other_G  = (-1,)  # encounter partner of G: full complementary cover
other_Gp = (0,)   # encounter partner of G': no cover
check("L6.2 witness preconditions (own-side reading): G and G' own presented-count profiles are equal (1,0)",
      (sum(1 for v in G_own if v == 1), sum(1 for v in G_own if v == -1)) ==
      (sum(1 for v in Gp_own if v == 1), sum(1 for v in Gp_own if v == -1)) == (1, 0))
check("L6.2 witness: PAIR profiles differ ((1,1) vs (1,0)) and cover differs (True vs False) -> "
      "s8.6 licences different outcome classes for the two encounters",
      pair_profile(G_own, other_G) == (1, 1) and pair_profile(Gp_own, other_Gp) == (1, 0)
      and complementary_cover(G_own, other_G) and not complementary_cover(Gp_own, other_Gp))
print("Under the pair-profile reading of Thm 6.2's hypothesis the witness's")
print("precondition FAILS (pair profiles (1,1) != (1,0)) and no counterexample")
print("stands. Under the own-side reading the precondition HOLDS and the")
print("conclusion fails. The theorem's proof (s6) moves from 'equal profiles'")
print("to 'the encounter presented to G and the encounter presented to G'")
print("have the same profile' without stating which reading is meant, and")
print("without fixing the encounter's other side or the side (incoming /")
print("neighbour) on which the body stands -- s8.6's rule is directional")
print("(incoming-side guard, Paper 11 s8.6 Theorems G/A). Filed as LIMIT (B).")
print()
print("FAILURES:", fails if fails else "none")
sys.exit(1 if fails else 0)
