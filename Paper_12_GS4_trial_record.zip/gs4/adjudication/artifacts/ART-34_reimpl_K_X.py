#!/usr/bin/env python3
"""Arm H (hostile) independent reimplementation of the Paper 12 s11.3
population ordering key K -- written ONLY from the paper's prose
definitions (ss3.1-3.2 records, s4 T/tau/admissibility, s11.3 key
definition). No paper code imported; A.14's listing was NOT consulted
(spec s6.2).

READING CHOICES (least-favourable readings the text admits, per the
Arm H overlay s3 item 3 -- each choice stated, with its textual basis):

 R-K1 (k_j of a representative junction). s11.3's table presents only
   sigma data, ((+1),(-1)) etc.: port vectors of length 1. It nowhere
   declares an arity or a ports-per-side count for these junctions.
   HOSTILE CHOICE: k_j = port-vector length (=1), the only count the
   s11.3 presentation itself supplies. The alternative (k_j = total
   ports consumed at one port per side = 2, by s11.2 clause (ii)'s
   'total number of boundary ports it consumes' and s3.4's examples)
   is implemented as variant B for comparison. The two readings give
   DIFFERENT count vectors / B / CenSig (values), shown below.
 R-K2 (k_j-tuple comparison inside a count vector). s11.3 states the
   proper-prefix rule ONLY for census signatures, not for the k_j
   ascending tuples inside vectors. HOSTILE CHOICE (variant L):
   longer k_j tuple is SMALLER (length-first, descending spirit);
   variant P uses the standard prefix rule (shorter prefix smaller).
   A population pair below flips order between L and P.
 R-K3 (admissibility). Per s4: index k admissible iff A[k] = -B[k] != 0,
   over pairwise junctions only; a junction of >2 sides presents no
   admissible index (s11.3's parenthetical, Def 4.1 scope). Sides of
   unequal length: missing entries cannot satisfy !=0, so they are
   never admissible (zip semantics); tau still sums every entry.
 R-K4 (Tau0). tau(sigma) = sum of squares of ALL presented entries,
   including multi-sided junctions (Prop 4.3's carry-through case:
   'the same sum of squares over its presented entries').
 R-K5 (Res). Res = 1 iff NO junction of P presents an admissible
   index (vacuously 1 for the empty / junctionless declaration).
"""
from fractions import Fraction
import itertools, copy

# ---------- s4 operator T and tau ----------
def admissible(A, B):
    return [k for k in range(min(len(A), len(B))) if A[k] == -B[k] != 0]

def tau_sigma(sigma):
    return sum(x * x for side in sigma for x in side)

def T_sigma(sigma):
    A, B = list(sigma[0]), list(sigma[1])
    adm = admissible(A, B)
    if adm:
        k = adm[0]
        A[k] = 0; B[k] = 0
    return (tuple(A), tuple(B))

def junction_acts(sigma):
    return len(sigma) == 2 and len(admissible(sigma[0], sigma[1])) > 0

# ---------- s3 record / count vector ----------
def count_vector(body, k_mode):
    """body: dict(N, Ss, Su, junctions=[sigma,...]).
    k_mode 'len': k_j = port-vector length (HOSTILE main reading).
    k_mode 'side': k_j = total entries // sides == entries per side summed
    over sides at one port per position-side... implemented as
    sum(len(side) for side in sigma)//len(sigma) * len(sigma) is wrong;
    'side' = number of sides x 1 port (exhibit convention) = len(sigma)
    for the representatives (2 sides -> k=2); for a length-L pairwise
    junction in the Spine convention this would give 2, NOT L -- so
    'side' is used ONLY for the s11.3 representatives, whose sides
    present exactly one entry each (one port per side per s11.2's
    worked exhibit)."""
    ks = []
    for sigma in body["junctions"]:
        if k_mode == "len":
            ks.append(len(sigma[0]))
        elif k_mode == "side":
            ks.append(len(sigma))  # one consumed port per presenting side
        else:
            raise ValueError(k_mode)
    B = 6 * body["N"] - sum(ks)
    return (body["N"], tuple(sorted(ks)), B, body["Ss"], body["Su"])

# ---------- vector / signature comparison ----------
def cmp_k_tuple(a, b, mode):
    """Compare ascending k_j tuples. mode 'P': prefix rule.
    mode 'L': longer tuple smaller when one is a proper prefix."""
    for x, y in zip(a, b):
        if x != y:
            return -1 if x < y else 1
    if len(a) == len(b):
        return 0
    if mode == "P":
        return -1 if len(a) < len(b) else 1
    else:  # 'L'
        return -1 if len(a) > len(b) else 1

def cmp_vector(v, w, kmode):
    if v[0] != w[0]:
        return -1 if v[0] < w[0] else 1
    c = cmp_k_tuple(v[1], w[1], kmode)
    if c:
        return c
    for i in (2, 3, 4):  # B, Ss, Su
        if v[i] != w[i]:
            return -1 if v[i] < w[i] else 1
    return 0

def cmp_signature(s1, s2, kmode):
    for v, w in zip(s1, s2):
        c = cmp_vector(v, w, kmode)
        if c:
            return c
    if len(s1) == len(s2):
        return 0
    return -1 if len(s1) < len(s2) else 1  # s11.3: shorter prefix is smaller

def K(pop, k_mode="len", kmode="P"):
    """pop: list of bodies. Returns key as a comparable structure:
    (Ntot, Res, Tau0, Ss, Su, -Btot, signature-as-tuple) plus a
    comparator-aware wrapper via KKey."""
    Ntot = sum(b["N"] for b in pop)
    Ss = sum(b["Ss"] for b in pop)
    Su = sum(b["Su"] for b in pop)
    vecs = [count_vector(b, k_mode) for b in pop]
    Btot = sum(v[2] for v in vecs)
    Tau0 = sum(tau_sigma(s) for b in pop for s in b["junctions"])
    Res = 0 if any(junction_acts(s) for b in pop for s in b["junctions"]) else 1
    # signature: sort descending under vector order
    sig = sorted(vecs, key=VectorSortKey(kmode), reverse=True)
    return (Ntot, Res, Tau0, Ss, Su, -Btot, tuple(sig)), vecs

class VectorSortKey:
    def __init__(self, kmode):
        self.kmode = kmode
    def __call__(self, v):
        return _VecWrap(v, self.kmode)

class _VecWrap:
    def __init__(self, v, kmode):
        self.v = v; self.kmode = kmode
    def __lt__(self, other):
        return cmp_vector(self.v, other.v, self.kmode) < 0
    def __eq__(self, other):
        return cmp_vector(self.v, other.v, self.kmode) == 0

def cmp_populations(p, q, k_mode="len", kmode="P"):
    kp, _ = K(p, k_mode, kmode)
    kq, _ = K(q, k_mode, kmode)
    for a, b in zip(kp[:6], kq[:6]):
        if a != b:
            return -1 if a < b else 1
    return cmp_signature(kp[6], kq[6], kmode)

def deciding_component(p, q, k_mode="len", kmode="P"):
    names = ["Ntot", "Res", "Tau0", "Ss", "Su", "-Btot", "CenSig"]
    kp, _ = K(p, k_mode, kmode)
    kq, _ = K(q, k_mode, kmode)
    for i, nm in enumerate(names):
        if i < 6:
            if kp[i] != kq[i]:
                return nm
        else:
            if cmp_signature(kp[6], kq[6], kmode) != 0:
                return nm
    return "TIE"

# ---------- s11.3 representatives (table at s11.3) ----------
def rep(N, Ss, Su, junctions):
    return {"N": N, "Ss": Ss, "Su": Su, "junctions": junctions}

REPS = {
    "photon":      rep(1, 0, 0, []),
    "open tilted": rep(1, 1, 1, []),
    "meson-like":  rep(3, 9, 3, [((+1,), (-1,)), ((+1,), (-1,))]),
    "baryon-like": rep(3, 9, 3, [((+1,), (+1,)), ((-1,), (-1,))]),
    "nuclei":      rep(4, 8, 2, [((+1, +1), (+1, +1)), ((+1,), (+1,))]),
    "atoms":       rep(6, 10, 3, [((+1, +1), (+1, +1)), ((+1,), (+1,))]),
}
ORDER = ["photon", "open tilted", "meson-like", "baryon-like", "nuclei", "atoms"]

def main():
    print("=== (1) Representative keys, HOSTILE k reading ('len': k_j = port-vector length) ===")
    for name in ORDER:
        key, vecs = K([REPS[name]], "len", "P")
        print(f"  {name:12s} vec={vecs[0]}  K[:6]={key[:6]}")
    print("=== (1B) Same, variant 'side' (k_j = one port per side) ===")
    for name in ORDER:
        key, vecs = K([REPS[name]], "side", "P")
        print(f"  {name:12s} vec={vecs[0]}  K[:6]={key[:6]}")
    print("=== (2) Adjacent steps: order + deciding component (both k readings) ===")
    for k_mode in ("len", "side"):
        for a, b in zip(ORDER, ORDER[1:]):
            c = cmp_populations([REPS[a]], [REPS[b]], k_mode, "P")
            print(f"  [{k_mode}] {a} < {b}: {c == -1}  decided at {deciding_component([REPS[a]], [REPS[b]], k_mode, 'P')}")
    print("=== (3) Homogeneous families {G x n}, n=1..4: class order preserved? ===")
    for k_mode in ("len", "side"):
        ok = True
        for n in (1, 2, 3, 4):
            fam = {name: [copy.deepcopy(REPS[name]) for _ in range(n)] for name in ORDER}
            for a, b in zip(ORDER, ORDER[1:]):
                if cmp_populations(fam[a], fam[b], k_mode, "P") != -1:
                    ok = False
        print(f"  [{k_mode}] all multiplicities preserve order: {ok}")
    print("=== (4) Tick-stability: invariant components vs Res/Tau0 ===")
    def tick_pop(pop):
        out = []
        for b in pop:
            nb = dict(b)
            nb["junctions"] = [T_sigma(s) if len(s) == 2 else s for s in b["junctions"]]
            out.append(nb)
        return out
    # reversal witness (independent of A.14's W1): P Ss=1 acting twice, Q Ss=9 acting once
    P = [rep(2, 1, 0, [((+1, +1), (-1, -1))])]
    Q = [rep(2, 9, 0, [((+1,), (-1,))])]
    print(f"  declaration: cmp(P,Q)={cmp_populations(P, Q)} decided at {deciding_component(P, Q)}")
    P2, Q2 = tick_pop(tick_pop(P)), tick_pop(tick_pop(Q))
    print(f"  at rest:     cmp(P,Q)={cmp_populations(P2, Q2)} decided at {deciding_component(P2, Q2)}")
    print(f"  REVERSAL WITNESS (order flips declaration->rest): {cmp_populations(P, Q) != cmp_populations(P2, Q2)}")
    # invariance spot check over representative ticks
    inv_ok = True
    for name in ORDER:
        pop = [copy.deepcopy(REPS[name])]
        k0, _ = K(pop); k1, _ = K(tick_pop(pop))
        if (k0[0], k0[3], k0[4], k0[5]) != (k1[0], k1[3], k1[4], k1[5]):
            inv_ok = False
        if cmp_signature(k0[6], k1[6], "P") != 0:
            inv_ok = False
    print(f"  Ntot/Ss/Su/-Btot/CenSig invariant declaration->tick on all representatives: {inv_ok}")
    print("=== (5) k_j-tuple prefix divergence (R-K2): order flips between readings P and L ===")
    # Minimal witness (found by exhaustive search over tied scalar keys,
    # 52,002 tied pairs checked, 6,012 flips; this pair verified by hand):
    # zero sigma everywhere (Res=1, Tau0=0, Ss=Su=0); Ntot=4, Btot=21 both.
    def zbody(N, lens):
        return {"N": N, "Ss": 0, "Su": 0,
                "junctions": [((0,) * L, (0,) * L) for L in lens]}
    PA = [zbody(2, []), zbody(2, [1, 2])]   # vecs (2,(),12), (2,(1,2),9)
    PB = [zbody(2, [1]), zbody(2, [2])]     # vecs (2,(1),11), (2,(2),10)
    for kmode in ("P", "L"):
        kp, vp = K(PA, "len", kmode); kq, vq = K(PB, "len", kmode)
        print(f"  [kmode={kmode}] PA vecs={vp} PB vecs={vq}")
        print(f"  [kmode={kmode}] scalar keys PA={kp[:6]} PB={kq[:6]}  cmp(PA,PB)={cmp_populations(PA, PB, 'len', kmode)} decided at {deciding_component(PA, PB, 'len', kmode)}")
    print("=== (5B) Third k reading for representatives: k_j = total presented entries ===")
    for name in ("meson-like", "nuclei", "atoms"):
        b = REPS[name]
        ks = sorted(sum(len(s) for s in j) for j in b["junctions"])
        print(f"  {name:12s} vec under 'total-entries' = {(b['N'], tuple(ks), 6 * b['N'] - sum(ks), b['Ss'], b['Su'])}"
              f"  (vs 'len' {count_vector(b, 'len')}, vs 'side' {count_vector(b, 'side')})")
    print("=== (6) Empty declaration ===")
    key, _ = K([], "len", "P")
    print(f"  K(empty) = {key}  (s11.3 states (0, 1, 0, 0, 0, 0, ()))")
    print("=== (7) Transitivity spot check over representative + witness populations ===")
    pops = [[REPS[n]] for n in ORDER] + [P, Q, PA, PB]
    viol = 0
    for a, b, c in itertools.permutations(pops, 3):
        if cmp_populations(a, b) <= 0 and cmp_populations(b, c) <= 0 and cmp_populations(a, c) > 0:
            viol += 1
    print(f"  transitivity violations over {len(pops)} populations (ordered triples): {viol}")

if __name__ == "__main__":
    main()
