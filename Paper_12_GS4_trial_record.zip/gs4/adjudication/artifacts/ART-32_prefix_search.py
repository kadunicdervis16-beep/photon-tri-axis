import sys, itertools
sys.path.insert(0, "/home/hatch/workspace/your_files/paper_12_draft/gs4/submissions/H/D")
from reimpl_K_hostile import cmp_populations, count_vector
# zero-sigma bodies: Res=1 Tau=0 Ss=Su=0 always. Vectors vary via (N, junction lengths).
def zbody(N, lens):
    return {"N": N, "Ss": 0, "Su": 0, "junctions": [((0,)*L,(0,)*L) for L in lens]}
bodies = []
for N in (2,3,4):
    for lens in [(), (1,), (2,), (3,), (1,1), (2,2), (1,2), (2,3), (3,3), (1,1,1), (2,2,2), (1,3), (4,), (1,4), (2,4)]:
        bodies.append(zbody(N, lens))
pops = [[b] for b in bodies] + [[a,b] for a in bodies for b in bodies]
# index by scalar key (Ntot, Btot) to only compare tied pairs
from collections import defaultdict
groups = defaultdict(list)
for p in pops:
    Ntot = sum(b["N"] for b in p); Btot = sum(count_vector(b,"len")[2] for b in p)
    groups[(Ntot,Btot)].append(p)
flips = 0; checked = 0
examples = []
for key, ps in groups.items():
    for a, b in itertools.combinations(ps, 2):
        checked += 1
        cp = cmp_populations(a, b, "len", "P"); cl = cmp_populations(a, b, "len", "L")
        if (cp < 0) != (cl < 0) or (cp == 0) != (cl == 0):
            flips += 1
            if len(examples) < 3: examples.append((a,b,cp,cl))
print("tied pairs checked:", checked, "flips:", flips)
for a,b,cp,cl in examples:
    print("PA", [count_vector(x,'len') for x in a], "PB", [count_vector(x,'len') for x in b], "cmpP", cp, "cmpL", cl)
