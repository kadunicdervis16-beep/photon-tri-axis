#!/usr/bin/env python3
"""
Examiner Arm N Role B -- L0.3 spot scan (independent of script FW.1).
Counts occurrences of the sec.0.5 locked words in the paper's own prose
region (lines 1..2903: sections 0-13, Appendix A, Appendix B) and prints
every line containing the rarer locked tokens so the examiner can classify
contexts by eye. This is a SPOT scan: the full sweep with the firewall's
exemption rules is FW.1's job, not reproduced here.
"""
import re, sys

PATH = '/home/hatch/workspace/your_files/paper_12_draft/gs4/packet/Paper_12_v4.md'
lines = open(PATH, 'rb').read().decode('utf-8', errors='replace').splitlines()
region = lines[:2903]

WORDS = {
    'temperature': r'\btemperature\b',
    'entropy/entropies': r'\bentrop',
    'ensemble': r'\bensemble',
    'microstate/macrostate': r'\b(microstate|macrostate)',
    'Gibbs': r'\bGibbs',
    'Boltzmann': r'\bBoltzmann',
    'k_B': r'k_B',
    'probability distribution': r'probability distribution',
    'thermal equilibrium': r'thermal equilibrium',
}
for name, pat in WORDS.items():
    hits = [i + 1 for i, l in enumerate(region) if re.search(pat, l, re.IGNORECASE)]
    print(f'{name}: {len(hits)} lines in L1-2903 -> {hits[:40]}')
print()
print('--- every "ensemble" line (context classification by eye) ---')
for i, l in enumerate(region, 1):
    if re.search(r'\bensemble', l, re.IGNORECASE):
        print(f'{i}: {l[:170]}')
print()
print('--- every "entropy" line outside sec.0.5 (L106-148) ---')
for i, l in enumerate(region, 1):
    if i < 150: continue
    if re.search(r'\bentrop', l, re.IGNORECASE):
        print(f'{i}: {l[:170]}')
