#!/usr/bin/env python3
"""
Examiner Arm N Role B -- independent witness artifact (GS-4 Gold v1.0).

Every function below was written by the examiner from the DEFINITIONS in
Paper 12 v4's prose (sections 3, 4, 5, 7, 8, 9, 10, 11.3) BEFORE opening
any Appendix C verification listing. No paper script is imported, copied,
or consulted. Stdlib only. Run: python3 witness_boundary.py
Exit 0 iff every check prints PASS (edge-case demonstrations that are
expected to raise are caught and reported as DEMONSTRATED, not PASS).
"""
import itertools, random, sys
from fractions import Fraction
from math import comb, factorial

random.seed(20261031)
FAIL = []

def check(name, cond, detail=""):
    print(("PASS  " if cond else "FAIL  ") + name + ((" | " + str(detail)) if detail else ""))
    if not cond:
        FAIL.append(name)

# ---------------------------------------------------------------- T (sec.4)
# T acts on sigma=(A,B), equal-length tuples over {-1,0,1}:
# admissible(k) iff A[k] == -B[k] != 0; zero the canonically first such pair.
def T(sigma):
    A, B = list(sigma[0]), list(sigma[1])
    for k in range(len(A)):
        if A[k] != 0 and A[k] == -B[k]:
            A[k] = 0; B[k] = 0
            return (tuple(A), tuple(B)), True
    return (tuple(A), tuple(B)), False

def tau(sigma):
    return sum(x * x for x in sigma[0]) + sum(x * x for x in sigma[1])

def admissible_exists(sigma):
    return any(a != 0 and a == -b for a, b in zip(sigma[0], sigma[1]))

# Population state: tuple of pairwise sigmas + tuple of multi-sided sigmas
# (each a tuple of >=3 side-tuples). T_agg applies T at pairwise junctions
# and carries multi-sided junctions through unchanged (Def. 4.1 scope).
def T_agg(state):
    pair, multi = state
    out, acting = [], 0
    for s in pair:
        ns, acted = T(s)
        out.append(ns); acting += 1 if acted else 0
    return (tuple(out), tuple(multi)), acting

def tau_agg(state):
    pair, multi = state
    t = sum(tau(s) for s in pair)
    for sides in multi:                      # sum of squares over presented entries
        t += sum(x * x for side in sides for x in side)
    return t

def rand_sigma(rng, maxlen=2):
    L = rng.randint(1, maxlen)
    return (tuple(rng.choice((-1, 0, 1)) for _ in range(L)),
            tuple(rng.choice((-1, 0, 1)) for _ in range(L)))

print("== A. Aggregate tick: commutation, tau accounting, carry-through ==")
rng = random.Random(1)
ok_comm = ok_tau = ok_carry = True
for _ in range(300):
    n = rng.randint(0, 5)
    pair = tuple(rand_sigma(rng) for _ in range(n))
    multi = ((((1, -1), (0, 1), (1, 1))),) if rng.random() < 0.3 else ()
    state = (pair, multi)
    end, acting = T_agg(state)
    # every permutation order of sequential application agrees
    for perm in itertools.permutations(range(n)):
        seq = list(pair)
        for j in perm:
            seq[j], _ = T(seq[j])
        if tuple(seq) != end[0]:
            ok_comm = False
    if tau_agg(end) - tau_agg(state) != -2 * acting:
        ok_tau = False
    if end[1] != multi:
        ok_carry = False
check("A1 pairwise actions commute (300 pops, all orders)", ok_comm)
check("A2 dtau_agg = -2 * acting junctions, multi-sided carried at dtau=0", ok_tau)
check("A3 multi-sided junctions carried through unchanged", ok_carry)

print("== B. Census identities (sec.3.3) incl. empty / singleton / repeats ==")
def census(records):
    c = {}
    for r in records:
        c[r] = c.get(r, 0) + 1
    return c
ok = True
rng = random.Random(2)
pool = [(2, (2,), 10, 4, 2), (3, (3,), 15, 9, 1), (2, (2, 2), 8, 6, 3), (1, (), 6, 0, 0)]
for trial in range(200):
    m = rng.choice((0, 1, 2, 5, 9))
    recs = [rng.choice(pool) for _ in range(m)]          # repeats allowed
    c = census(recs)
    if sum(c.values()) != m: ok = False                  # (II)
    for comp in range(5):                                # (III), componentwise
        direct = sum(r[comp] if not isinstance(r[comp], tuple) else 0 for r in recs)
        if comp == 1: continue
        grouped = sum(cnt * vec[comp] for vec, cnt in c.items())
        if direct != grouped: ok = False
check("B1 identities (II),(III) on 200 families incl. |P|=0,1 and duplicates", ok)

print("== C. Assignment counts (sec.8.2-8.3) ==")
ok = all(sum(comb(n, k) for k in range(n + 1)) == 2 ** n for n in range(0, 31))
check("C1 sum_k C(n,k) = 2^n, n=0..30", ok)
ok = True
for n in range(1, 41):
    for k in range(0, n):
        if Fraction(comb(n, k + 1), comb(n, k)) != Fraction(n - k, k + 1): ok = False
    # strict rise to balance, strict fall after (8.3)
    seq = [comb(n, k) for k in range(n + 1)]
    mid = seq.index(max(seq))
    if any(seq[i] >= seq[i + 1] for i in range(mid)): ok = False
check("C2 ratio (8.3) exact, n=1..40; counts rise strictly to the maximum", ok)
ok = all(comb(2 * m, m) >= 2 ** m for m in range(1, 61))
check("C3 C(2m,m) >= 2^m (8.5), m=1..60", ok)
ok = all(Fraction(1) - Fraction(2, 2 ** n) >= Fraction(n - 1, n) for n in range(1, 81))
check("C4 non-polarized share 1-2^(1-n) >= (n-1)/n (8.7), n=1..80 exact", ok)
shares = [Fraction(comb(n, n // 2), 2 ** n) if n % 2 == 0 else Fraction(comb(n, n // 2), 2 ** n) for n in range(1, 7)]
check("C5 balanced record's own share, n=1..6 (paper: 1/2,1/2,3/8,3/8,5/16,5/16)",
      shares == [Fraction(1, 2), Fraction(1, 2), Fraction(3, 8), Fraction(3, 8), Fraction(5, 16), Fraction(5, 16)],
      shares)

print("== D. Sec.8.7 two-level trajectory, recomputed from sec.4's T ==")
bodies = [((1, 0), (-1, 0))] * 6 + [((1, 1), (-1, -1))] * 6
def phi(sigma):   # class A iff some k with A[k]=+1, B[k]=-1
    return any(a == 1 and b == -1 for a, b in zip(sigma[0], sigma[1]))
state = tuple(bodies)
rows = []
for t in range(4):
    na = sum(1 for s in state if phi(s))
    rows.append(((na, 12 - na), comb(12, na), sum(tau(s) for s in state)))
    state = tuple(T(s)[0] for s in state)
check("D1 trajectory records (12,0)->(6,6)->(0,12)->(0,12)",
      [r[0] for r in rows] == [(12, 0), (6, 6), (0, 12), (0, 12)], rows)
check("D2 Omega along trajectory = 1, 924, 1, 1 (rises then falls back)",
      [r[1] for r in rows] == [1, 924, 1, 1])
check("D3 tau_agg = 36, 12, 0, 0 while Omega falls 924 -> 1 (open joint exhibit)",
      [r[2] for r in rows] == [36, 12, 0, 0])
check("D4 full n=12 table sums to 4096, max 924 at k=6, share 231/1024",
      sum(comb(12, k) for k in range(13)) == 4096 and comb(12, 6) == 924
      and Fraction(924, 4096) == Fraction(231, 1024))
# equilibrium verdicts: E1 = next record equals record; E2 = Omega maximal (=924)
verdicts = []
for i in range(3):
    e1 = rows[i + 1][0] == rows[i][0]
    e2 = rows[i][1] == 924
    verdicts.append((rows[i][0], e1, e2, e1 and e2))
check("D5 no visited record is an equilibrium; clauses separate both ways",
      verdicts == [((12, 0), False, False, False), ((6, 6), False, True, False),
                   ((0, 12), True, False, False)], verdicts)
# (p,c) by visited-state enumeration on the sigma-state
seen, s, t = {}, tuple(bodies), 0
while s not in seen:
    seen[s] = t; s = tuple(T(x)[0] for x in s); t += 1
p, c = seen[s], t - seen[s]
check("D6 (p,c) = (2,1)", (p, c) == (2, 1), (p, c))
# STRONG FORM of the open joint refuted: trajectory rests at Omega=1, not maximal
check("D7 strong form refuted in-paper: rest record (0,12) has Omega=1 < 924",
      rows[2][1] == 1 and rows[2][0] == (0, 12))

print("== E. Reconcile density D(P,W) (sec.7) ==")
table = {  # sec.7.5 worked example, transcribed from the home text
 'A': [2, 0, 1, 3, 0, 2, 1, 0, 2, 1], 'B': [0, 1, 0, 2, 1, 0, 0, 2, 1, 0],
 'C': [3, 2, 2, 1, 2, 3, 1, 2, 0, 2], 'D': [1, 0, 0, 1, 0, 1, 0, 0, 1, 0]}
tot = {b: sum(v) for b, v in table.items()}
R = sum(tot.values())
D = Fraction(R, 4 * 10)
mean_locals = sum(Fraction(tot[b], 10) for b in table) / 4
check("E1 sec.7.5 totals 12,7,18,4; R=41; D=41/40", tot == {'A': 12, 'B': 7, 'C': 18, 'D': 4} and R == 41 and D == Fraction(41, 40))
check("E2 mean-of-locals (7.4) on the worked example", mean_locals == D)
rng = random.Random(3)
ok = True
for _ in range(300):
    np_, nw = rng.randint(1, 8), rng.randint(1, 9)
    rb = {(b, t): rng.randint(0, 97) for b in range(np_) for t in range(nw)}
    Rr = sum(rb.values())
    lhs = Fraction(Rr, np_ * nw)
    rhs = sum(Fraction(sum(rb[(b, t)] for t in range(nw)), nw) for b in range(np_)) / np_
    if lhs != rhs: ok = False
    if np_ == 1 and lhs != Fraction(sum(rb[(0, t)] for t in range(nw)), nw): ok = False
check("E3 (7.4) + |P|=1 reduction on 300 random ledgers (exact Fractions)", ok)
check("E4 contact cap: worked tick 100-3-40-21 = 36; N_reconcile <= 97 iff v2,s2 >= 0",
      100 - 3 - 40 - 21 == 36 and all(97 - v - s <= 97 for v in range(0, 98) for s in range(0, 98 - v)))
for label, np_, nw in (("empty population", 0, 4), ("empty window", 3, 0)):
    try:
        _ = Fraction(0, np_ * nw); edge = "returned a value (unexpected)"
    except ZeroDivisionError:
        edge = "ZeroDivisionError: D is NOT a rational here"
    print(f"DEMONSTRATED E5 {label}: D(P,W) with |P|*|W|=0 -> {edge}")

print("== F. Equilibrium clauses (sec.9.2-9.3) and saturation census (sec.9.4-9.5) ==")
F = {('A', 'A'): 1, ('A', 'B'): 1, ('B', 'A'): 1, ('B', 'B'): 1}
def stationary(F, classes=('A', 'B')):
    return all(sum(F.get((i, j), 0) for j in classes) == sum(F.get((j, i), 0) for j in classes)
               for i in classes)
check("F1 flowing example (2,2): (9.3) holds; Omega=C(4,2)=6 is maximal -> equilibrium",
      stationary(F) and comb(4, 2) == max(comb(4, k) for k in range(5)))
F0 = {('A', 'A'): 4}
check("F2 frozen (4,0): stationary, Omega=1 not maximal -> NOT equilibrium",
      stationary(F0) and comb(4, 0) == 1 and comb(4, 0) < comb(4, 2))
rows95 = [('J1', 3, 55, 15, 32), ('J2', 3, 48, 12, 25), ('J3', 3, 52, 20, 25)]
dem = [a + b + c + d for _, a, b, c, d in rows95]
booked = [min(100, x) for x in dem]
deferred = [x - y for x, y in zip(dem, booked)]
jsat = sum(1 for x in dem if x >= 100)
check("F3 sec.9.5: demands 105/88/100, booked 288/293, deferred 5, J_sat 0->2, fraction 2/3",
      dem == [105, 88, 100] and sum(booked) == 288 and sum(dem) == 293
      and sum(deferred) == 5 and jsat == 2 and Fraction(jsat, 3) == Fraction(2, 3))
try:
    _ = Fraction(0, 0); edge = "returned a value (unexpected)"
except ZeroDivisionError:
    edge = "ZeroDivisionError: fraction is NOT a rational at J=0"
print(f"DEMONSTRATED F4 junctionless population: J_sat/J with J=0 -> {edge}")

print("== G. Eventual periodicity (sec.10.1 / L10.1) ==")
rng = random.Random(4)
ok = True
for _ in range(200):   # arbitrary deterministic maps on finite sets
    n = rng.randint(1, 30)
    f = [rng.randrange(n) for _ in range(n)]
    s0 = rng.randrange(n)
    seen = {}; s = s0; t = 0
    while s not in seen:
        seen[s] = t; s = f[s]; t += 1
    pp, cc = seen[s], t - seen[s]
    traj = [s0]
    for _ in range(pp + 2 * cc + 5):
        traj.append(f[traj[-1]])
    if cc < 1: ok = False
    for tt in range(pp, pp + cc + 5):
        if traj[tt] != traj[tt + cc]: ok = False
check("G1 200 random finite deterministic maps: (p,c) decomposition, c>=1", ok)
ok = True; cycles_seen = set()
rng = random.Random(5)
for _ in range(300):   # closed populations under T_agg alone
    n = rng.randint(0, 6)
    pair = tuple(rand_sigma(rng) for _ in range(n))
    multi = ((((1, 0), (-1, 0), (1, 1))),) if rng.random() < 0.25 else ()
    state = (pair, multi); seen = {}; t = 0; prev_tau = tau_agg(state)
    while state not in seen:
        seen[state] = t
        state, acting = T_agg(state)
        if tau_agg(state) > prev_tau: ok = False
        if acting == 0 and tau_agg(state) != prev_tau: ok = False
        prev_tau = tau_agg(state); t += 1
        if t > 500: ok = False; break
    cycles_seen.add(t - seen[state])
check("G2 300 closed T_agg trajectories: tau monotone; every cycle has c=1",
      ok and cycles_seen == {1}, cycles_seen)

print("== H. Standings and joint counts (Def. 5.7, 5.8; Prop. 5.9) ==")
def standing(sigma):
    A, B = sigma
    if any(a == 1 and b == -1 for a, b in zip(A, B)): return '+'
    if any(a == -1 and b == 1 for a, b in zip(A, B)): return '-'
    return '0'
def body_standing(junctions):
    ss = [standing(s) for s in junctions]
    if '+' in ss: return '+'
    if '-' in ss: return '-'
    return '0'
check("H1 standings precedence; junctionless body neutral; opposed pair inside one sigma only",
      body_standing([]) == '0'
      and body_standing([((1,), (0,)), ((0,), (-1,))]) == '0'   # pooled pair must NOT count
      and body_standing([((-1,), (1,))]) == '-'
      and body_standing([((-1,), (1,)), ((1,), (-1,))]) == '+')
# sequences: member -> list of standings over a horizon; joint count per Def. 5.8
def joint(seqs, entries, W):
    return sum(1 for t in W if all(seqs[m][t + d] == X for m, X, d in entries))
rng = random.Random(6)
ok_marg = ok_add = ok_off = True
for _ in range(400):
    horizon = 14
    seqs = {m: [rng.choice('+-0') for _ in range(horizon)] for m in ('m1', 'm2', 'm3')}
    W = list(range(3, 9))
    X1 = rng.choice('+-0')
    tot = sum(joint(seqs, [('m1', X1, 0), ('m2', X2, 0)], W) for X2 in '+-0')
    if tot != joint(seqs, [('m1', X1, 0)], W): ok_marg = False          # 5.9(i)
    if sum(joint(seqs, [('m1', X1, 0), ('m2', X2, 0), ('m3', X3, 0)], W)
           for X2 in '+-0' for X3 in '+-0') != joint(seqs, [('m1', X1, 0)], W): ok_marg = False
    W1, W2 = W[:3], W[3:]
    if joint(seqs, [('m1', X1, 0), ('m2', '+', 0)], W) != \
       joint(seqs, [('m1', X1, 0), ('m2', '+', 0)], W1) + joint(seqs, [('m1', X1, 0), ('m2', '+', 0)], W2):
        ok_add = False                                                  # 5.9(ii)
    d = rng.choice((-2, -1, 1, 2))
    if joint(seqs, [('m1', X1, d)], W) != sum(1 for t in W if seqs['m1'][t + d] == X1): ok_off = False
    # repeated name, read literally (Def. 5.8)
    if joint(seqs, [('m1', X1, 0), ('m1', X1, 0)], W) != joint(seqs, [('m1', X1, 0)], W): ok_off = False
    if joint(seqs, [('m1', '+', 0), ('m1', '-', 0)], W) != 0: ok_off = False
check("H2 Prop.5.9(i) marginalization incl. k=3 chain, 400 random tables", ok_marg)
check("H3 Prop.5.9(ii) window additivity", ok_add)
check("H4 offsets and repeated names read literally", ok_off)
# C32-type witness (examiner's own, record level): swap two bodies' whole
# standing-sequences. Census (per tick) and flow table (class-transition
# counts) are functions of the multiset of sequences, so they agree; the
# NAMED joint count is not.
seqA = {'B1': ['+', '+'], 'B2': ['-', '-'], 'B3': ['0', '0']}
seqB = {'B1': seqA['B2'], 'B2': seqA['B1'], 'B3': seqA['B3']}
W = [0, 1]
def census_seq(seqs):
    return [tuple(sorted(seqs[m][t] for m in seqs)) for t in W]
def flow_table(seqs):
    ft = {}
    for t in range(len(W) - 1):
        for m in seqs: ft[(seqs[m][t], seqs[m][t + 1])] = ft.get((seqs[m][t], seqs[m][t + 1]), 0) + 1
    return ft
ja = joint(seqA, [('B1', '+', 0), ('B2', '-', 0)], W)
jb = joint(seqB, [('B1', '+', 0), ('B2', '-', 0)], W)
check("H5 census+flow agree on both, joint counts differ (2 vs 0): joint not recoverable from census/flow",
      census_seq(seqA) == census_seq(seqB) and flow_table(seqA) == flow_table(seqB) and (ja, jb) == (2, 0),
      (ja, jb))

print("== I. Capability factorization logic (sec.6 / L6.2) ==")
# Premises as stated: outcome = f(pair profile M) only; role attached by outcome class.
def outcome(pairM):
    nplus, nminus = pairM
    return 'balanced' if nplus == nminus and nplus > 0 else ('plus-led' if nplus > nminus else 'minus-led')
ROLE = {'balanced': 'resolver', 'plus-led': 'active', 'minus-led': 'passive'}
rng = random.Random(7)
ok = True
for _ in range(1000):
    pairM = (rng.randint(0, 4), rng.randint(0, 4))
    interior_G, interior_Gp = rng.random(), rng.random()   # interiors differ arbitrarily
    if ROLE[outcome(pairM)] != ROLE[outcome(pairM)]: ok = False
check("I1 given the two premises, equal pair-profile M => equal role (composition of functions)", ok)
# Own-profile reading probe: same OWN presented counts, different counterpart -> different pair M.
own = (1, 1)
pair_with_X = (own[0] + 1, own[1] + 0)   # counterpart presents (1,0)
pair_with_Y = (own[0] + 0, own[1] + 1)   # counterpart presents (0,1)
check("I2 own-profile reading is NOT sufficient: pair M (2,1) vs (1,2) give different outcomes",
      outcome(pair_with_X) != outcome(pair_with_Y),
      (outcome(pair_with_X), outcome(pair_with_Y)))
def outcome_mutant(pairM, interior_parity):   # interior-dependent mutant (carried capability)
    return 'plus-led' if interior_parity else outcome(pairM)
check("I3 interior-dependent mutant breaks factorization (premise is load-bearing)",
      outcome_mutant((1, 1), True) != outcome_mutant((1, 1), False))

print("== J. Population ordering key K (sec.11.3) ==")
# Body record: dict(N, k=tuple of junction arities (port counts), Ss, Su, sigmas=[...])
def B_of(b): return 6 * b['N'] - sum(b['k'])
def vec_of(b): return (b['N'], tuple(sorted(b['k'])), B_of(b), b['Ss'], b['Su'])
def K(pop):
    Ntot = sum(b['N'] for b in pop)
    Ss = sum(b['Ss'] for b in pop); Su = sum(b['Su'] for b in pop)
    Btot = sum(B_of(b) for b in pop)
    Res = 0 if any(admissible_exists(s) for b in pop for s in b['sigmas']) else 1
    Tau0 = sum(tau(s) for b in pop for s in b['sigmas'])
    CenSig = tuple(sorted((vec_of(b) for b in pop), reverse=True))
    return (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig)
def decider(ka, kb):
    names = ['Ntot', 'Res', 'Tau0', 'Ss', 'Su', '-Btot', 'CenSig']
    for i, (x, y) in enumerate(zip(ka, kb)):
        if x != y: return names[i]
    return 'tie'
REP = {
 'photon':  [dict(N=1, k=(), Ss=0, Su=0, sigmas=[])],
 'tilted':  [dict(N=1, k=(), Ss=1, Su=1, sigmas=[])],
 'meson':   [dict(N=3, k=(2, 2), Ss=9, Su=3, sigmas=[((1,), (-1,)), ((1,), (-1,))])],
 'baryon':  [dict(N=3, k=(2, 2), Ss=9, Su=3, sigmas=[((1,), (1,)), ((-1,), (-1,))])],
 'nuclei':  [dict(N=4, k=(4, 2), Ss=8, Su=2, sigmas=[((1, 1), (1, 1)), ((1,), (1,))])],
 'atoms':   [dict(N=6, k=(4, 2), Ss=10, Su=3, sigmas=[((1, 1), (1, 1)), ((1,), (1,))])],
}
ORDER = ['photon', 'tilted', 'meson', 'baryon', 'nuclei', 'atoms']
keys = {name: K(pop) for name, pop in REP.items()}
print("   exemplar keys:", {n: k[:6] for n, k in keys.items()})
ok = all(keys[ORDER[i]] < keys[ORDER[i + 1]] for i in range(5))
decs = [decider(keys[ORDER[i]], keys[ORDER[i + 1]]) for i in range(5)]
check("J1 exemplar order reproduced; deciders = Ss, Ntot, Res, Ntot, Ntot",
      ok and decs == ['Ss', 'Ntot', 'Res', 'Ntot', 'Ntot'], decs)
check("J2 meson/baryon: identical count vectors, Tau0 equal (4=4, sign-blind), separated ONLY at Res",
      vec_of(REP['meson'][0]) == vec_of(REP['baryon'][0]) and keys['meson'][2] == keys['baryon'][2] == 4)
ok = True
for m in range(1, 6):
    fam = {name: K([dict(b) for b in pop] * m) for name, pop in REP.items()}
    if not all(fam[ORDER[i]] < fam[ORDER[i + 1]] for i in range(5)): ok = False
check("J3 homogeneous families, equal size m=1..5: same order", ok)
check("J4 empty declaration: K = (0,1,0,0,0,0,()) as sec.11.3 states", K([]) == (0, 1, 0, 0, 0, 0, ()))
# name invariance + transitivity on random populations
rng = random.Random(8)
def rand_pop(rng):
    pop = []
    for _ in range(rng.randint(0, 4)):
        sig = [rand_sigma(rng) for _ in range(rng.randint(0, 2))]
        kk = tuple(2 * len(s[0]) for s in sig)
        pop.append(dict(N=rng.randint(1, 4), k=kk, Ss=rng.randint(0, 9), Su=rng.randint(0, 4), sigmas=sig))
    return pop
ok_inv = ok_tr = True
for _ in range(300):
    p, q, r = rand_pop(rng), rand_pop(rng), rand_pop(rng)
    pp = list(p); rng.shuffle(pp)
    if K(pp) != K(p): ok_inv = False
    if K(p) <= K(q) and K(q) <= K(r) and not K(p) <= K(r): ok_tr = False
check("J5 name invariance (300 shuffled populations)", ok_inv)
check("J6 transitivity of the preorder (300 random triples)", ok_tr)
# tick stability: records fixed (sec.4 states no tick-dynamics for (N,Ss,Su)); sigmas evolve by T
ok_stab = True; res_moves = tau_moves = 0
rng = random.Random(9)
for _ in range(300):
    pop = rand_pop(rng)
    before = K(pop)
    pop2 = [dict(b, sigmas=[T(s)[0] for s in b['sigmas']]) for b in pop]
    after = K(pop2)
    if (before[0], before[3], before[4], before[5], before[6]) != (after[0], after[3], after[4], after[5], after[6]):
        ok_stab = False
    if before[1] != after[1]: res_moves += 1
    if before[2] != after[2]: tau_moves += 1
check("J7 tick-invariance of Ntot,Ss,Su,-Btot,CenSig; Res/Tau0 move", ok_stab and res_moves > 0 and tau_moves > 0,
      (res_moves, tau_moves))
# sharpness: order reversal between declaration and rest (examiner's own witness)
P = [dict(N=3, k=(2, 4), Ss=9, Su=3, sigmas=[((1,), (-1,)), ((1, 1), (1, 1))])]
Q = [dict(N=3, k=(2,), Ss=9, Su=3, sigmas=[((1,), (1,))])]
P1 = [dict(P[0], sigmas=[T(s)[0] for s in P[0]['sigmas']])]
check("J8 reversal witness: K(P)<K(Q) at Res, after one tick K(P')>K(Q) at Tau0 (4>2)",
      K(P) < K(Q) and decider(K(P), K(Q)) == 'Res' and K(P1) > K(Q) and decider(K(P1), K(Q)) == 'Tau0',
      (K(P)[:3], K(Q)[:3], K(P1)[:3]))
# CenSig as decider needs exact ties on the six earlier components, so use a
# targeted family: junctionless bodies, Ss=Su=0, N in 1..3 (Btot then ties
# whenever Ntot ties). Plus one hand-built pair.
Pcs = [dict(N=1, k=(), Ss=0, Su=0, sigmas=[]), dict(N=3, k=(), Ss=0, Su=0, sigmas=[])]
Qcs = [dict(N=2, k=(), Ss=0, Su=0, sigmas=[]), dict(N=2, k=(), Ss=0, Su=0, sigmas=[])]
hand = decider(K(Pcs), K(Qcs)) == 'CenSig' and K(Qcs) < K(Pcs)
rng = random.Random(10)
prefix_decided = censig_decided = pairs = 0
def rand_pop_tied(rng):
    return [dict(N=rng.randint(1, 3), k=(), Ss=0, Su=0, sigmas=[]) for _ in range(rng.randint(1, 3))]
for _ in range(20000):
    p, q = rand_pop_tied(rng), rand_pop_tied(rng)
    kp, kq = K(p), K(q); pairs += 1
    if kp[:6] == kq[:6] and kp[6] != kq[6]:
        censig_decided += 1
        sp, sq = kp[6], kq[6]
        if len(sp) != len(sq) and (sp[:min(len(sp), len(sq))] == sq[:min(len(sp), len(sq))]):
            prefix_decided += 1
check("J9 CenSig decides comparisons (hand pair + random tied family); prefix-related signatures never the decider",
      hand and censig_decided > 0 and prefix_decided == 0, (censig_decided, prefix_decided, pairs))
# ---- alternative constructions (same premises, different results) ----
def K_variant(pop, drop=None, ss_first=False, su_first=False, tau_first=False, plus_b=False):
    k = list(K(pop))
    if drop == 'Res': k = k[:1] + k[2:]
    if ss_first: k = [k[3], k[0], k[1], k[2], k[4], k[5], k[6]]   # Ss promoted ahead of Ntot
    if su_first: k = [k[4], k[0], k[1], k[2], k[3], k[5], k[6]]   # Su promoted ahead of Ntot
    if tau_first: k = [k[2], k[0], k[1], k[3], k[4], k[5], k[6]]  # Tau0 promoted ahead of Ntot
    if plus_b: k[5] = -k[5]
    return tuple(k)
check("J10 ALT-1 (drop Res): meson/baryon TIE -- strict step lost (Res is forced for this step)",
      K_variant(REP['meson'], drop='Res') == K_variant(REP['baryon'], drop='Res'))
check("J11a ALT-2 (Ss ahead of Ntot): baryon Ss=9 > nuclei Ss=8 REVERSES the required step",
      K_variant(REP['baryon'], ss_first=True) > K_variant(REP['nuclei'], ss_first=True))
check("J11b ALT-2b (Su ahead of Ntot): baryon Su=3 > nuclei Su=2 also REVERSES the step",
      K_variant(REP['baryon'], su_first=True) > K_variant(REP['nuclei'], su_first=True))
check("J11c ALT-2c (Tau0 ahead of Ntot): exemplar order PRESERVED -- Ntot-first is not uniquely forced",
      all(K_variant(REP[ORDER[i]], tau_first=True) < K_variant(REP[ORDER[i + 1]], tau_first=True) for i in range(5)))
X = [dict(N=2, k=(), Ss=0, Su=0, sigmas=[])]                       # B=12
Y = [dict(N=2, k=(2,), Ss=0, Su=0, sigmas=[((0,), (0,))])]        # B=10
check("J12 ALT-3 (+Btot instead of -Btot): flips X/Y, which the exemplars never reach (sign is a choice)",
      K(X) < K(Y) and K_variant(X, plus_b=True) > K_variant(Y, plus_b=True))
# rival rendering of the differentia (paper's own named rival, recomputed):
meson_lone = [dict(N=3, k=(2, 2), Ss=9, Su=3, sigmas=[((1,), (0,)), ((1,), (0,))])]
check("J13 lone-leftover rival: meson Res=1, Tau0=2; step vs baryon decided at Tau0 (2<4), order preserved",
      K(meson_lone)[1] == 1 and K(meson_lone)[2] == 2 and K(meson_lone) < K(REP['baryon'])
      and decider(K(meson_lone), K(REP['baryon'])) == 'Tau0')
def Res_unsettled(pop):
    # Rival reading disclosed at sec.11.3: EVERY unsettled entry counts as
    # surplus -- a lone entry against a zero side, a same-sign pair. Formalized:
    # surplus stands iff some junction has any nonzero presented entry that is
    # not part of a (0,0) position; both representatives then carry surplus.
    for b in pop:
        for A, B in b['sigmas']:
            if any(a != 0 or bb != 0 for a, bb in zip(A, B)):
                return 0
    return 1
def K_unsettled(pop):
    k = list(K(pop)); k[1] = Res_unsettled(pop); return tuple(k)
check("J14 unsettled-entry rival: both representatives get Res=0 and their keys TIE outright (step decided nowhere)",
      K_unsettled(REP['meson']) == K_unsettled(REP['baryon'])
      and K_unsettled(REP['meson'])[1] == 0)

print()
print("FAILURES:", FAIL if FAIL else "none")
sys.exit(1 if FAIL else 0)
