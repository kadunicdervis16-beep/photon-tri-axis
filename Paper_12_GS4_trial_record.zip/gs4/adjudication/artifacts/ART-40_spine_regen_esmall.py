#!/usr/bin/env python3
"""Arm H independent regeneration of ONE Spine thread (E-SMALL) from
Appendix F's DECLARATIONS -- not from its printed results. The printed
values are used only as the comparison oracle at the end of each step.
Definitions from prose: s3 census/B, s4 T/tau, Def 5.7 standings,
Def 5.8 joint counts, s6 capability rules as Appendix F states them,
s7 eq. (7.2)-(7.4), s8.4 multinomial Omega, s9.3 (E1)/(E2).
No paper code imported.

Capability encounter kinds: Appendix F says 'the 15 declared encounter
kinds' but does not list their profiles in prose; script A.4's
docstring (Appendix C) declares the test taxonomy as all profiles
(e+, e-) with e+ + e- <= 4 -- exactly 15 kinds. That declared set is
used here as DATA (not code); see SUBMISSION.md coverage note.
"""
from fractions import Fraction
from math import factorial, log
import itertools

# ---------------- declarations (Appendix F, E-SMALL) ----------------
BODIES = {  # name: (N, [(junction name, sigma), ...])
    "S1": (2, [("J1", ((+1, 0), (-1, 0)))]),
    "S2": (2, [("J2", ((0, +1), (0, +1)))]),
    "S3": (3, [("J3", ((-1, 0), (+1, 0))), ("J4", ((0, 0), (0, 0)))]),
}
CONTACTS = {"S1": {1: (91, 5)}, "S2": {1: (93, 3)}, "S3": {2: (90, 4)}}
NAMES = ["S1", "S2", "S3"]
results = []
def check(label, got, printed):
    ok = got == printed
    results.append(ok)
    print(f"  [{'MATCH' if ok else 'MISMATCH'}] {label}: computed {got} | printed {printed}")

# ---------------- s4: T, tau ----------------
def admissible(A, B):
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]
def T(sigma):
    A, B = list(sigma[0]), list(sigma[1])
    adm = admissible(A, B)
    if adm:
        A[adm[0]] = 0; B[adm[0]] = 0
    return (tuple(A), tuple(B))
def tau(sigma):
    return sum(x * x for side in sigma for x in side)

print("== Census (s3) ==")
vecs = {}
for name in NAMES:
    N, js = BODIES[name]
    ks = tuple(sorted(len(s[0]) for _, s in js))  # pairwise: k_j = port-vector length
    vecs[name] = (N, ks, 6 * N - sum(ks))
check("count vectors", vecs, {"S1": (2, (2,), 10), "S2": (2, (2,), 10), "S3": (3, (2, 2), 14)})
from collections import Counter
check("census classes", Counter(vecs.values()), Counter({(2, (2,), 10): 2, (3, (2, 2), 14): 1}))
tn = sum(v[0] for v in vecs.values()); tb = sum(v[2] for v in vecs.values())
check("totals (III) nodes/boundary", (tn, tb), (7, 34))
check("direct route 6*7-8", 6 * 7 - 8, 34)

print("== Aggregate tick (s4), ticks 0..3 ==")
state = {n: [s for _, s in BODIES[n][1]] for n in NAMES}
jnames = {n: [j for j, _ in BODIES[n][1]] for n in NAMES}
series, states = [], []
for t in range(4):
    states.append({n: list(state[n]) for n in NAMES})
    series.append(sum(tau(s) for n in NAMES for s in state[n]))
    if t == 0:
        acting = [(jnames[n][i], admissible(*state[n][i]))
                  for n in NAMES for i in range(len(state[n])) if admissible(*state[n][i])]
        print(f"  acting at tick 1: {acting}")
    state = {n: [T(s) for s in state[n]] for n in NAMES}
check("tau_agg series", series, [6, 2, 2, 2])
check("Delta tau tick 0->1 = -2 x 2 acting", series[1] - series[0], -4)

print("== Standings (Def 5.7), tallies, flows (s5) ==")
def jstanding(sigma):
    A, B = sigma
    if any(A[k] == 1 and B[k] == -1 for k in range(len(A))):
        return "+"
    if any(A[k] == -1 and B[k] == 1 for k in range(len(A))):
        return "-"
    return "0"
def bstanding(sigmas):
    js = [jstanding(s) for s in sigmas]
    if "+" in js: return "+"
    if "-" in js: return "-"
    return "0"
stand = {t: {n: bstanding(states[t][n]) for n in NAMES} for t in range(4)}
for t in range(4):
    print(f"  tick {t}: {[stand[t][n] for n in NAMES]}")
check("standings tick 0", [stand[0][n] for n in NAMES], ["+", "0", "-"])
check("standings ticks 1-3", [[stand[t][n] for n in NAMES] for t in (1, 2, 3)], [["0", "0", "0"]] * 3)
tallies = [tuple(sum(1 for n in NAMES if stand[t][n] == s) for s in "+-0") for t in range(4)]
# printed tallies are (pos, neg, neu) in the appendix's listing order (1,1,1) then (0,0,3) over (+,-,0) counts:
tallies_paper = [tuple(sum(1 for n in NAMES if stand[t][n] == s) for s in ("+", "-", "0")) for t in range(4)]
check("tallies", tallies_paper, [(1, 1, 1), (0, 0, 3), (0, 0, 3), (0, 0, 3)])
flows = Counter((stand[0][n], stand[1][n]) for n in NAMES)
check("flows 0->1 (+->0, -->0, 0->0 each once)",
      (flows[("+", "0")], flows[("-", "0")], flows[("0", "0")]), (1, 1, 1))
net = tuple(tallies_paper[1][i] - tallies_paper[0][i] for i in range(3))
check("net flows (dpos, dneg, dneu)", net, (-1, -1, 2))

print("== Joint counts (Def 5.8), window (0,3) = ticks {0,1,2} ==")
W = [0, 1, 2]
J1 = sum(1 for t in W if stand[t]["S1"] == "+" and stand[t]["S3"] == "-")
check("J_W(S1 +, S3 -)", (J1, Fraction(J1, len(W))), (1, Fraction(1, 3)))
J2 = sum(1 for t in W if stand[t]["S1"] == "+" and stand[t + 1]["S3"] == "0")
check("J_W(S1 + d0, S3 0 d+1)", (J2, Fraction(J2, len(W))), (1, Fraction(1, 3)))
marg = sum(1 for t in W if stand[t]["S1"] == "+")
check("marginalization J_W(S1 +)", marg, 1)
split = (sum(1 for t in [0] if stand[t]["S1"] == "+" and stand[t]["S3"] == "-"),
         sum(1 for t in [1, 2] if stand[t]["S1"] == "+" and stand[t]["S3"] == "-"))
check("window split of J1 over {0}|{1,2}", split, (1, 0))

print("== Capability (s6; rules as Appendix F states them) ==")
KINDS = [(a, b) for a in range(5) for b in range(5) if a + b <= 4]
print(f"  encounter kinds: {len(KINDS)} (all (e+,e-) with e++e- <= 4)")
def profile(name, t=0):
    tup = []
    for s in states[t][name]:
        tup.extend(s[0]); tup.extend(s[1])
    return (tup.count(1), tup.count(-1)), tuple(tup)
def cap_counts(M):
    npos, nneg = M
    cover = [0, 0, 0]; surplus = [0, 0, 0]
    for (epos, eneg) in KINDS:
        c = min(npos, eneg) + min(nneg, epos)
        s = min(npos, epos) + min(nneg, eneg)
        if c >= 1:
            cover[0] += 1
            if npos - nneg >= epos - eneg: cover[1] += 1
            if s == 0: cover[2] += 1
        net_ = (npos - nneg) + (epos - eneg); tot = npos + nneg + epos + eneg
        if net_ == 0 and tot >= 2:
            surplus[0] += 1; surplus[2] += 1
        if net_ > 0 and npos > nneg:
            surplus[1] += 1
    return tuple(cover), tuple(surplus)
profs = {}
for n in NAMES:
    M, tup = profile(n)
    profs[n] = M
    print(f"  {n}: presented {tup}  M = {M}")
check("profiles", profs, {"S1": (1, 1), "S2": (2, 0), "S3": (1, 1)})
check("capability at M=(1,1) (cover; surplus)", cap_counts((1, 1)), ((14, 8, 0), (3, 0, 3)))
check("capability at M=(2,0) (cover; surplus)", cap_counts((2, 0)), ((10, 10, 4), (2, 11, 2)))
check("S1 and S3 equal capability (equal profiles)", cap_counts(profs["S1"]) == cap_counts(profs["S3"]), True)

print("== Population temperature (s7) ==")
def r_b(name, t):
    if t in CONTACTS[name]:
        v2, s2 = CONTACTS[name][t]
        return 97 - v2 - s2
    return 0
Wt = [1, 2, 3]
R = sum(r_b(n, t) for n in NAMES for t in Wt)
D = Fraction(R, len(NAMES) * len(Wt))
check("R(P,W)", R, 5)
check("D(P,W)", D, Fraction(5, 9))
locals_ = {n: Fraction(sum(r_b(n, t) for t in Wt), len(Wt)) for n in NAMES}
check("local densities", locals_, {"S1": Fraction(1, 3), "S2": Fraction(1, 3), "S3": Fraction(1, 1)})
check("mean of locals == D (7.4)", sum(locals_.values()) / 3, D)

print("== Omega and equilibrium (ss8-9) ==")
def omega(counts):
    nn = sum(counts); d = 1
    for c in counts: d *= factorial(c)
    return factorial(nn) // d
recs = [(a, b, 3 - a - b) for a in range(4) for b in range(4 - a)]
check("number of records", len(recs), 10)
check("Omega(1,1,1) / Omega(0,0,3)", (omega((1, 1, 1)), omega((0, 0, 3))), (6, 1))
check("max Omega over all records at (1,1,1)", max(omega(r) for r in recs), 6)
check("record totals sum = 3^3", sum(omega(r) for r in recs), 27)
phi = [(tallies_paper[t][0], tallies_paper[t][1] + tallies_paper[t][2]) for t in (0, 1)]
check("phi thread", phi, [(1, 2), (0, 3)])
check("Omega_phi thread", [omega((p, q)) for p, q in phi], [3, 1])
def E1(t):  # stationary: record at t equals record at t+1
    return tallies_paper[t] == tallies_paper[t + 1]
def E2(t):
    return omega(tallies_paper[t]) == max(omega(r) for r in recs)
check("tick-0 record: (E1, E2)", (E1(0), E2(0)), (False, True))
check("rest record: (E1, E2)", (E1(1), E2(1)), (True, False))
check("no visited record is an equilibrium",
      any(E1(t) and E2(t) for t in (0, 1)), False)
check("bridge S/k_B at tick 0 = ln 6 (4dp)", round(log(6), 4), 1.7918)
check("bridge S/k_B at rest = ln 1", round(log(1), 4), 0.0)
print(f"\nALL E-SMALL CHECKS MATCH: {all(results)} ({sum(results)}/{len(results)})")
