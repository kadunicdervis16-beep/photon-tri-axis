#!/usr/bin/env python3
"""GS4-D independent reproduction — Arm H Role C.
Written from the printed definitions alone (Paper 12 ss11.3 key definition
and s7.3 eqs. (7.3)-(7.4) and the s7.5 table). Does NOT use scripts A.14
or A.6 or their code. L11.4: representatives' data are exactly the s11.3
table (N, Ss, Su, presented junction data); Res and Tau0 computed from the
printed definitions (Res=1 iff no junction presents an admissible index,
admissible iff A=-B!=0 per Paper 11 s7.5 as restated in s4; Tau0 = sum of
squares of presented entries). Btot/CenSig are not consulted: every step
of the six-class order is decided at an earlier component, which this
script verifies by reporting the deciding component per step.
L7.3: recomputes D and the mean-of-locals from the s7.5 table cells.
"""
from fractions import Fraction

# ---------- L11.4 ----------
def tau_of(junctions):
    return sum(x * x for pair in junctions for side in pair for x in side)

def res_of(junctions):
    for a, b in junctions:
        # canonical local state: sides are tuples; admissible index exists
        # iff some position has A = -B != 0 (s7.5 admissibility as printed)
        for x, y in zip(a, b):
            if x == -y != 0:
                return 0
    return 1

def key_partial(rep):
    n, ss, su, junctions = rep
    return (n, res_of(junctions), tau_of(junctions), ss, su)

REPS = {  # name: (N, Ss, Su, [((A...),(B...)), ...])  — s11.3 table verbatim
    "photon":      (1, 0, 0, []),
    "open tilted": (1, 1, 1, []),
    "meson-like":  (3, 9, 3, [((1,), (-1,)), ((1,), (-1,))]),
    "baryon-like": (3, 9, 3, [((1,), (1,)), ((-1,), (-1,))]),
    "nuclei":      (4, 8, 2, [((1, 1), (1, 1)), ((1,), (1,))]),
    "atoms":       (6, 10, 3, [((1, 1), (1, 1)), ((1,), (1,))]),
}
ORDER = ["photon", "open tilted", "meson-like", "baryon-like", "nuclei", "atoms"]
COMP = ["Ntot", "Res", "Tau0", "Ss", "Su"]
print("L11.4 representatives — partial keys (Ntot, Res, Tau0, Ss, Su):")
keys = {}
for name in ORDER:
    keys[name] = key_partial(REPS[name])
    print(f"  {name:12s} {keys[name]}")
print("Steps (Paper 11 s12.1 order must be strictly increasing in K):")
ok = True
for lo, hi in zip(ORDER, ORDER[1:]):
    a, b = keys[lo], keys[hi]
    dec = next(i for i in range(5) if a[i] != b[i])
    good = a[dec] < b[dec] and a[:dec] == b[:dec]
    ok &= good
    print(f"  {lo} < {hi}: decided at {COMP[dec]} ({a[dec]} vs {b[dec]}) strict={good}")
print("  meson/baryon step decided at Res:", COMP[next(i for i in range(5) if keys['meson-like'][i]!=keys['baryon-like'][i])] == "Res")
# tick action on representatives (T: zero the canonically first admissible
# pair per junction; T_agg applies at every junction in parallel)
def tick(junctions):
    out = []
    for a, b in junctions:
        a, b = list(a), list(b)
        for i, (x, y) in enumerate(zip(a, b)):
            if x == -y != 0:
                a[i] = 0; b[i] = 0
                break
        out.append((tuple(a), tuple(b)))
    return out
print("Tick-stability on representatives (Ntot,Ss,Su invariant by construction"
      " — records untouched; Res/Tau0 may move):")
for name in ORDER:
    n, ss, su, j = REPS[name]
    j2 = tick(j)
    print(f"  {name:12s} Res {res_of(j)}->{res_of(j2)}, Tau0 {tau_of(j)}->{tau_of(j2)}")
print("L11.4 order agreement on representatives:", "PASS" if ok else "FAIL")

# ---------- L7.3 ----------
table = {  # s7.5 worked example, body totals as printed (recomputed below)
    "A": [2,0,1,3,0,2,1,0,2,1], "B": [0,1,0,2,1,0,0,2,1,0],
    "C": [3,2,2,1,2,3,1,2,0,2], "D": [1,0,0,1,0,1,0,0,1,0]}
W = 10
totals = {b: sum(v) for b, v in table.items()}
R = sum(totals.values()); P = len(table)
D = Fraction(R, P * W)
locals_ = {b: Fraction(t, W) for b, t in totals.items()}
mean = sum(locals_.values()) / P
print(f"\nL7.3 worked example: totals={totals} R={R} |P|={P} |W|={W}")
print(f"  D(P,W) = {D} ; locals = {locals_} ; mean of locals = {mean}")
print("  (7.4) identity on exhibited window:", "PASS" if D == mean else "FAIL")
