"""Arm H Role A independent reconstruction check (second implementation, from the paper's printed definitions only).
Covers: T/T_agg on E-SMALL + s8.7 population, census/flow/joint, K on representatives + rivals, D(P,W), Omega, equilibrium."""
from fractions import Fraction
from math import comb, factorial, log
from itertools import permutations

def T(sigma):
    A,B=[list(x) for x in sigma]
    for k in range(len(A)):
        if A[k]!=0 and A[k]==-B[k]:
            A[k]=0; B[k]=0; break
    return (tuple(A),tuple(B))
def tau(sigma): return sum(x*x for v in sigma for x in v)
def standing(sigma):
    A,B=sigma
    if any(A[k]==1 and B[k]==-1 for k in range(len(A))): return '+'
    if any(A[k]==-1 and B[k]==1 for k in range(len(A))): return '-'
    return '0'
def agg(pop): # pop list of sigma
    return [T(s) for s in pop], sum(tau(T(s))-tau(s) for s in pop)

# --- E-SMALL (Appendix F, L69339) ---
J=[((1,0),(-1,0)),((0,1),(0,1)),((-1,0),(1,0)),((0,0),(0,0))]
# bodies: S1=[J1], S2=[J2], S3=[J3,J4]
bodies=[[J[0]],[J[1]],[J[2],J[3]]]
def body_standing(js):
    ss=[standing(s) for s in js]
    if '+' in ss: return '+'
    if '-' in ss: return '-'
    return '0'
traj=[]; cur=[s for b in bodies for s in b]
# track per-body
state=bodies
for t in range(4):
    traj.append(([body_standing(b) for b in state], sum(tau(s) for b in state for s in b)))
    state=[[T(s) for s in b] for b in state]
print("E-SMALL traj (standings, tau_agg):", traj)
assert traj[0]==(['+','0','-'],6) and traj[1]==(['0','0','0'],2) and traj[2][1]==2
# census totals: nodes 2+2+3=7, consumed 2+2+2+2=8, B=42-8=34
assert 6*7-8==34
# joint count over window ticks 0..2: S1 pos & S3 neg
stands=[x[0] for x in traj]
Jc=sum(1 for t in range(3) if stands[t][0]=='+' and stands[t][2]=='-')
assert Jc==1 and Fraction(Jc,3)==Fraction(1,3)
Jo=sum(1 for t in range(3) if stands[t][0]=='+' and stands[t+1][2]=='0')
assert Jo==1
# reconcile: r = 97-v2-s2
r=[97-91-5, 97-93-3, 97-90-4]; assert r==[1,1,3]
R=sum(r); D=Fraction(R,3*3); assert D==Fraction(5,9)
locals_=[Fraction(1,3),Fraction(1,3),Fraction(3,3)]; assert sum(locals_)/3==D
# Omega standings records: multinomial
def multinomial(ns): 
    d=factorial(sum(ns))
    for n in ns: d//=factorial(n)
    return d
assert multinomial([1,1,1])==6 and multinomial([0,0,3])==1
# all 10 records sum to 27
tot=sum(multinomial([a,b,3-a-b]) for a in range(4) for b in range(4-a)); assert tot==27, tot
print("E-SMALL: census/tick/flow/joint/D/Omega/equilibrium-separation REPRODUCED; ln6=",round(log(6),4))

# --- Section 8.7 population ---
pop=[((1,0),(-1,0))]*6+[((1,1),(-1,-1))]*6
def phi(s): return 'A' if any(s[0][k]==1 and s[1][k]==-1 for k in range(2)) else 'B'
for t in range(4):
    cen=(sum(1 for s in pop if phi(s)=='A'), sum(1 for s in pop if phi(s)=='B'))
    print("s8.7 tick",t,"census",cen,"Omega",comb(12,cen[0]),"tau",sum(tau(s) for s in pop))
    pop=[T(s) for s in pop]
assert [comb(12,k) for k in range(13)]==[1,12,66,220,495,792,924,792,495,220,66,12,1] and sum(comb(12,k) for k in range(13))==4096

# --- K ordering (s11.3) ---
# representative: (Ntot, Res, Tau0, Ss, Su, -Btot, CenSig) ; Btot/CenSig not reached at any claimed step - set None sentinel that raises if consulted before Ss except Res step
def K(N,Res,Tau0,Ss,Su): return (N,Res,Tau0,Ss,Su)
photon=K(1,1,0,0,0); tilted=K(1,1,0,1,1)
meson=K(3,0,4,9,3); baryon=K(3,1,4,9,3)   # Tau0: meson 2+2, baryon 2+2
nuclei=K(4,1,6,8,2); atoms=K(6,1,6,10,3)
order=[photon,tilted,meson,baryon,nuclei,atoms]
assert order==sorted(order) and len(set(order))==6
steps=[("photon<tilted","Ss"),("tilted<meson","Ntot"),("meson<baryon","Res"),("baryon<nuclei","Ntot"),("nuclei<atoms","Ntot")]
print("K steps:",steps)
# deciding component check
names=["Ntot","Res","Tau0","Ss","Su"]
for (a,b,lab) in [(photon,tilted,"photon<tilted"),(tilted,meson,"tilted<meson"),(meson,baryon,"meson<baryon"),(baryon,nuclei,"baryon<nuclei"),(nuclei,atoms,"nuclei<atoms")]:
    dec=[names[i] for i in range(5) if a[i]!=b[i]][0]; print(lab,"decided at",dec)
# rival 1: lone-leftover meson ((+1),(0)) x2 : Res=1, Tau0=2
meson_rival=K(3,1,2,9,3); print("rival lone-leftover meson vs baryon: decided at", [names[i] for i in range(5) if meson_rival[i]!=baryon[i]][0], meson_rival<baryon)
# rival 2: unsettled-entry (any nonzero unmatched counts as surplus, both reps have nonzero entries) -> Res equal, Tau0 equal (4=4), Ss/Su equal -> step decided NOWHERE before Btot/CenSig (paper-silent)
print("rival unsettled-entry: meson Res==baryon Res, Tau0 4==4, Ss/Su equal -> no decider in (Ntot,Res,Tau0,Ss,Su)")
# Res vs standing distinction: junction ((+1,-1),(-1,+1)) standing '+' (first index), also '-' present in Def5.7 body aggregation precedence; Res=0 (admissible exists); phi=A
s=((1,-1),(-1,1)); assert standing(s)=='+' and T(s)!=s
# body with junctions standing + and - : body standing '+' by precedence, Res still 0
# neutral body with tau>0: ((0,1),(0,1)) standing 0, tau 2, Res contribution none admissible
assert standing(((0,1),(0,1)))=='0' and tau(((0,1),(0,1)))==2
print("Res/standing/phi distinctions REPRODUCED")
# L7.3 worked example
tot=[12,7,18,4]; assert Fraction(sum(tot),40)==Fraction(41,40)
assert sum(Fraction(x,10) for x in tot)/4==Fraction(41,40)
# L9.5 saturation arithmetic
dem=[3+55+15+32,3+48+12+25,3+52+20+25]; assert dem==[105,88,100] and sum(dem)==293
booked=[100,88,100]; assert sum(booked)==288 and dem[0]-booked[0]==5
# L8.3 inequality spot: all n to 50 analytic check of closed form
for n in range(1,51): assert 1-Fraction(2)**(1-n) >= Fraction(n-1,n)
print("ALL RECONSTRUCTION CHECKS PASS")
