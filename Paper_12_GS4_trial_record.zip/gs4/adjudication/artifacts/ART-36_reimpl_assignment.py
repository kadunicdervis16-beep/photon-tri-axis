#!/usr/bin/env python3
"""Arm H independent reimplementation (c): one A.5-class assignment-count
computation, from Paper 12's prose only -- s8.2 eq. (8.1)-(8.2), s8.3
eq. (8.3)-(8.7) and its printed trend table, s8.4's general multinomial.
No paper code imported. Three independent routes:
  Route 1: factorial closed form.
  Route 2: Pascal recurrence (no factorials).
  Route 3: brute-force enumeration of assignments of named bodies
           (itertools.product over classes) for n <= 6 (two-class)
           and for the three-class Spine records of Appendix F.
Printed table under test (s8.3): n=1..6 rows of C(n,k), totals 2^n,
max, polarized share 2^(1-n), non-polarized share, balanced share.
"""
from fractions import Fraction
from math import factorial
import itertools

PRINTED = {  # n: (row, total, max, polarized share, nonpol share, balanced share)
    1: ([1, 1], 2, 1, Fraction(1, 1), Fraction(0, 1), Fraction(1, 2)),
    2: ([1, 2, 1], 4, 2, Fraction(1, 2), Fraction(1, 2), Fraction(1, 2)),
    3: ([1, 3, 3, 1], 8, 3, Fraction(1, 4), Fraction(3, 4), Fraction(3, 8)),
    4: ([1, 4, 6, 4, 1], 16, 6, Fraction(1, 8), Fraction(7, 8), Fraction(3, 8)),
    5: ([1, 5, 10, 10, 5, 1], 32, 10, Fraction(1, 16), Fraction(15, 16), Fraction(5, 16)),
    6: ([1, 6, 15, 20, 15, 6, 1], 64, 20, Fraction(1, 32), Fraction(31, 32), Fraction(5, 16)),
}

def omega_fact(k, n):
    return factorial(n) // (factorial(k) * factorial(n - k))

def omega_pascal(k, n):
    row = [1]
    for _ in range(n):
        row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
    return row[k]

def omega_brute(k, n):
    return sum(1 for a in itertools.product((0, 1), repeat=n) if sum(a) == k)

def multinomial_fact(counts):
    n = sum(counts)
    d = 1
    for c in counts:
        d *= factorial(c)
    return factorial(n) // d

def multinomial_brute(counts):
    n = sum(counts)
    target = tuple(counts)
    cnt = 0
    for a in itertools.product(range(len(counts)), repeat=n):
        if tuple(a.count(i) for i in range(len(counts))) == target:
            cnt += 1
    return cnt

def main():
    allok = True
    for n, (row, total, mx, pol, nonpol, bal) in PRINTED.items():
        r1 = [omega_fact(k, n) for k in range(n + 1)]
        r2 = [omega_pascal(k, n) for k in range(n + 1)]
        r3 = [omega_brute(k, n) for k in range(n + 1)]
        tot = sum(r1)
        pol_c = Fraction(2, 2 ** n)
        nonpol_c = 1 - pol_c
        bal_c = Fraction(max(r1), tot) if n % 2 == 0 else Fraction(r1[n // 2], tot)
        # s8.3's 'balanced record's own share': for odd n the table prints
        # ONE central record's share (3/8 at n=3 = 3/8, 5/16 at n=5 = 10/32)
        ok = (r1 == row == r2 == r3 and tot == total == 2 ** n and max(r1) == mx
              and pol_c == pol and nonpol_c == nonpol and bal_c == bal)
        allok &= ok
        print(f"n={n}: routes agree {r1 == r2 == r3}; row match {r1 == row}; "
              f"total {tot}=={total}; max {max(r1)}=={mx}; pol {pol_c}=={pol}; "
              f"nonpol {nonpol_c}=={nonpol}; balanced {bal_c}=={bal}; ROW OK: {ok}")
        # (8.3) ratios
        for k in range(n):
            assert Fraction(r1[k + 1], r1[k]) == Fraction(n - k, k + 1)
        # (8.7) finite inequality
        assert nonpol_c >= Fraction(n - 1, n), n
    print("(8.3) ratios and (8.7) verified for all printed n: True")
    # (8.4)-(8.5): balanced count >= 2^m for even n = 2m, m = 1..10 (beyond table)
    ok85 = all(omega_fact(m, 2 * m) >= 2 ** m for m in range(1, 11))
    print(f"(8.5) C(2m,m) >= 2^m for m=1..10 (beyond the printed table): {ok85}")
    # Three-class multinomial (s8.4 general form) on Appendix F Spine records
    print("Spine three-class records (fact route vs brute force):")
    for rec in [(1, 1, 1), (0, 0, 3), (4, 2, 0), (2, 2, 2), (0, 0, 6), (7, 3, 2), (2, 2, 8), (0, 0, 12)]:
        f, b = multinomial_fact(rec), multinomial_brute(rec)
        print(f"  Omega{rec} = {f}  brute = {b}  match {f == b}")
    # record totals: sum of Omega over all records = 3^n
    for n in (3, 6):
        tot = sum(multinomial_fact((a, b, n - a - b))
                  for a in range(n + 1) for b in range(n + 1 - a))
        print(f"  sum over all records, n={n}: {tot} == 3^{n} = {3 ** n}: {tot == 3 ** n}")
    print("ALL PRINTED s8.3 TABLE ROWS REPRODUCED:", allok)

if __name__ == "__main__":
    main()
