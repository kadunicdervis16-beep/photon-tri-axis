#!/usr/bin/env python3
"""Arm N Role D -- independent regeneration of the E-SMALL Spine thread.

Sources used (prose of the frozen Paper 12 v4 only; no paper script read):
  - Appendix F, E-SMALL declarations (line 69339) and conventions (line 69337);
  - §3.1-3.3 census/count vectors; §4 T and tau_agg (admissible iff
    A[k] = -B[k] != 0, first such k zeroed; tau = sum of squares);
  - Definition 5.7 standings (positive: an opposed (+1,-1) pair inside one
    local state; else negative: an opposed (-1,+1) pair; else neutral;
    body precedence positive > negative > neutral);
  - Definition 5.8 joint counts over a window; window (0,3) read as the
    half-open tick set {0,1,2} (the only reading under which the printed
    joint frequency 1/3 = J_W/|W| is consistent);
  - §7 eq. (7.2) r_b = 97 - v2_contact - s2 at contact ticks, eq. (7.3)
    D = R/(|P||W|), eq. (7.4) mean of locals;
  - §8.4 multinomial Omega = n!/(n1!...nr!) for a standings record;
    §8.7's feature phi: class A = positive standing alone, B = the rest;
  - §9.3 equilibrium = (E1) stationary census + (E2) Omega maximal among
    ALL records of the population;
  - Appendix D (line 61348): the encounter taxonomy is the 15 profiles
    (e+, e-) with e+ + e- <= 4; Appendix F conventions give both outcome
    rules (complementary-cover and surplus) in prose.
Everything printed by Appendix F for E-SMALL is recomputed here from the
declarations and compared. The printed fixture values appear ONLY as the
comparison oracle at the end of each block.
"""
from fractions import Fraction
from math import factorial
from itertools import product as cart

# ---------------- declarations (Appendix F, line 69339) ----------------
# body: (name, N, [sigma,...]) with sigma = (A, B), port vectors length 2
BODIES = [
    ("S1", 2, [((1, 0), (-1, 0))]),
    ("S2", 2, [((0, 1), (0, 1))]),
    ("S3", 3, [((-1, 0), (1, 0)), ((0, 0), (0, 0))]),
]
CONTACTS = {("S1", 1): (91, 5), ("S2", 1): (93, 3), ("S3", 2): (90, 4)}
NAMES = [b[0] for b in BODIES]

# ---------------- machinery from the definitions ----------------
def B_of(N, sigmas):
    return 6 * N - sum(len(A) for A, B in sigmas)

def count_vector(N, sigmas):
    kj = tuple(sorted(len(A) for A, B in sigmas))
    return (N, kj, B_of(N, sigmas))

def tau_sigma(sigma):
    A, B = sigma
    return sum(x * x for x in A) + sum(x * x for x in B)

def tick_sigma(sigma):
    A, B = list(sigma[0]), list(sigma[1])
    for k in range(len(A)):
        if A[k] == -B[k] != 0:
            A[k] = 0
            B[k] = 0
            break
    return (tuple(A), tuple(B))

def standing_sigma(sigma):
    A, B = sigma
    if any(a == 1 and b == -1 for a, b in zip(A, B)):
        return "+"
    if any(a == -1 and b == 1 for a, b in zip(A, B)):
        return "-"
    return "0"

def standing_body(sigmas):
    sts = [standing_sigma(s) for s in sigmas]
    if "+" in sts:
        return "+"
    if "-" in sts:
        return "-"
    return "0"

def omega_record(record_counts):
    n = sum(record_counts)
    den = 1
    for c in record_counts:
        den *= factorial(c)
    return factorial(n) // den

def presented_profile(sigmas):
    tup = []
    for A, B in sigmas:
        tup += list(A) + list(B)
    return (tup.count(1), tup.count(-1))

TAXONOMY = [(eplus, eminus) for s in range(5)
            for eplus in range(s + 1) for eminus in [s - eplus]]

def capability_counts(M):
    nplus, nminus = M
    comp = [0, 0, 0]   # responder, initiator, spin-presenter
    surp = [0, 0, 0]
    for eplus, eminus in TAXONOMY:
        c = min(nplus, eminus) + min(nminus, eplus)
        s = min(nplus, eplus) + min(nminus, eminus)
        if c >= 1:
            comp[0] += 1
            if nplus - nminus >= eplus - eminus:
                comp[1] += 1
            if s == 0:
                comp[2] += 1
        net = (nplus - nminus) + (eplus - eminus)
        total = nplus + nminus + eplus + eminus
        if net == 0 and total >= 2:
            surp[0] += 1
            surp[2] += 1
        if net > 0 and nplus > nminus:
            surp[1] += 1
    return tuple(comp), tuple(surp)

def main():
    fails = []
    def check(label, got, want):
        ok = got == want
        print(f"{label}: got {got} | printed {want} | {'MATCH' if ok else 'MISMATCH'}")
        if not ok:
            fails.append(label)

    print("== Census (§3) ==")
    cvs = {name: count_vector(N, sig) for name, N, sig in BODIES}
    check("count vectors S1,S2", (cvs["S1"], cvs["S2"]), ((2, (2,), 10), (2, (2,), 10)))
    check("count vector S3", cvs["S3"], (3, (2, 2), 14))
    from collections import Counter
    census = Counter(cvs.values())
    check("census classes", sorted(census.values()), [1, 2])
    tot_nodes = sum(N for _, N, _ in BODIES)
    tot_B_grouped = sum(census[cv] * cv[2] for cv in census)
    tot_B_direct = 6 * tot_nodes - sum(len(A) for _, _, sig in BODIES for A, B in sig)
    check("totals (nodes, boundary grouped, boundary direct)",
          (tot_nodes, tot_B_grouped, tot_B_direct), (7, 34, 34))

    print("== Aggregate tick (§4): trajectory ticks 0..3 ==")
    states = {name: list(sig) for name, N, sig in BODIES}
    tau_series, standings_series = [], []
    for t in range(4):
        tau_series.append(sum(tau_sigma(s) for sig in states.values() for s in sig))
        standings_series.append(tuple(standing_body(states[n]) for n in NAMES))
        states = {n: [tick_sigma(s) for s in sig] for n, sig in states.items()}
    check("tau_agg series", tau_series, [6, 2, 2, 2])
    check("standings tick0 (S1,S2,S3)", standings_series[0], ("+", "0", "-"))
    check("standings ticks1-3", standings_series[1:], [("0", "0", "0")] * 3)
    tallies = [tuple(standings_series[t].count(x) for x in "+-0") for t in range(4)]
    check("tallies (pos,neg,neutral) ticks 0,1", tallies[:2], [(1, 1, 1), (0, 0, 3)])
    # flow counts tick 0->1
    flows = Counter()
    for i in range(3):
        flows[(standings_series[0][i], standings_series[1][i])] += 1
    check("flows 0->1 (+->0, -->0, 0->0)",
          (flows[("+", "0")], flows[("-", "0")], flows[("0", "0")]), (1, 1, 1))
    net = tuple(sum(flows[(a, x)] for a in "+-0") - sum(flows[(x, b)] for b in "+-0")
                for x in "+-0")
    check("net flows (pos,neg,neutral)", net, (-1, -1, 2))

    print("== Joint counts (Def. 5.8), window (0,3) = ticks {0,1,2} ==")
    W = [0, 1, 2]
    def J(entries):
        # entries: (body_index, standing, offset)
        return sum(1 for t in W if all(
            standings_series[t + off][i] == st for i, st, off in entries))
    j1 = J([(0, "+", 0), (2, "-", 0)])
    j2 = J([(0, "+", 0), (2, "0", 1)])
    jm = J([(0, "+", 0)])
    check("J_W(S1 pos, S3 neg), freq", (j1, Fraction(j1, 3)), (1, Fraction(1, 3)))
    check("J_W(S1 pos d0, S3 neutral d+1), freq", (j2, Fraction(j2, 3)), (1, Fraction(1, 3)))
    split = (sum(1 for t in [0] if standings_series[t][0] == "+"),
             sum(1 for t in [1, 2] if standings_series[t][0] == "+"))
    check("marginal J_W(S1 pos) and window split", (jm, split), (1, (1, 0)))

    print("== Capability (§6, both rules, taxonomy of 15) ==")
    check("taxonomy size", len(TAXONOMY), 15)
    profs = {name: presented_profile(sig) for name, N, sig in BODIES}
    check("profiles S1,S2,S3", (profs["S1"], profs["S2"], profs["S3"]),
          ((1, 1), (2, 0), (1, 1)))
    check("capability at M=(1,1) (comp, surplus)", capability_counts((1, 1)),
          ((14, 8, 0), (3, 0, 3)))
    check("capability at M=(2,0) (comp, surplus)", capability_counts((2, 0)),
          ((10, 10, 4), (2, 11, 2)))
    check("S1 and S3 equal capability (Thm 6.2 on the thread)",
          capability_counts(profs["S1"]) == capability_counts(profs["S3"]), True)

    print("== Population temperature (§7) -- task (3b) for this Spine population ==")
    r = {}
    for (b, t), (v2, s2) in CONTACTS.items():
        r[(b, t)] = 97 - v2 - s2
        check(f"budget {b} tick{t}: 3+{v2}+{s2}+r = 100", 3 + v2 + s2 + r[(b, t)], 100)
    R = sum(r.get((b, t), 0) for b in NAMES for t in (1, 2, 3))
    D = Fraction(R, 3 * 3)
    locals_ = {b: Fraction(sum(r.get((b, t), 0) for t in (1, 2, 3)), 3) for b in NAMES}
    mean_locals = sum(locals_.values()) / 3
    check("bookings (S1,S2,S3)", tuple(sum(r.get((b, t), 0) for t in (1, 2, 3)) for b in NAMES),
          (1, 1, 3))
    check("R(P,W), D(P,W)", (R, D), (5, Fraction(5, 9)))
    check("local densities", tuple(locals_[b] for b in NAMES),
          (Fraction(1, 3), Fraction(1, 3), Fraction(1, 1)))
    check("mean of locals = D (eq. 7.4)", mean_locals, Fraction(5, 9))

    print("== §7.5 worked example (second census-ratio check, §7 table) ==")
    table = {  # lines 1515-1527 of the frozen paper
        "A": [2, 0, 1, 3, 0, 2, 1, 0, 2, 1], "B": [0, 1, 0, 2, 1, 0, 0, 2, 1, 0],
        "C": [3, 2, 2, 1, 2, 3, 1, 2, 0, 2], "D": [1, 0, 0, 1, 0, 1, 0, 0, 1, 0]}
    tots = {b: sum(v) for b, v in table.items()}
    R75 = sum(tots.values())
    D75 = Fraction(R75, 4 * 10)
    loc75 = {b: Fraction(tots[b], 10) for b in table}
    check("body totals", tuple(tots[b] for b in "ABCD"), (12, 7, 18, 4))
    check("R, D for §7.5", (R75, D75), (41, Fraction(41, 40)))
    check("locals §7.5", tuple(loc75[b] for b in "ABCD"),
          (Fraction(6, 5), Fraction(7, 10), Fraction(9, 5), Fraction(2, 5)))
    check("mean of locals §7.5", sum(loc75.values()) / 4, Fraction(41, 40))

    print("== Omega and equilibrium (§§8-9) ==")
    rec0, rec_rest = tallies[0], tallies[1]
    check("Omega of visited records", (omega_record(rec0), omega_record(rec_rest)), (6, 1))
    all_records = [(a, b, 3 - a - b) for a in range(4) for b in range(4 - a)]
    check("number of records, total Omega", (len(all_records),
          sum(omega_record(x) for x in all_records)), (10, 27))
    check("Omega-maximal record", max(all_records, key=omega_record), (1, 1, 1))
    phi = [(tallies[t][0], 3 - tallies[t][0]) for t in range(2)]
    check("phi thread, Omega_phi", (phi, [omega_record(p) for p in phi]),
          ([(1, 2), (0, 3)], [3, 1]))
    E1 = {rec0: rec0 == tallies[1], rec_rest: tallies[1] == tallies[2]}
    E2 = {rec: omega_record(rec) == max(omega_record(x) for x in all_records)
          for rec in (rec0, rec_rest)}
    check("(E1,E2) tick-0 record", (E1[rec0], E2[rec0]), (False, True))
    check("(E1,E2) rest record", (E1[rec_rest], E2[rec_rest]), (True, False))
    check("no visited record is an equilibrium",
          any(E1[x] and E2[x] for x in (rec0, rec_rest)), False)
    from math import log
    check("Stage P reading S/kB at tick0 (printed 1.7918, rounded)",
          round(log(6), 4), 1.7918)

    print(f"REIMPL-SPINE RESULT: {'ALL E-SMALL VALUES REGENERATED AND MATCH' if not fails else 'MISMATCHES: ' + str(fails)}")
    return 1 if fails else 0

if __name__ == "__main__":
    raise SystemExit(main())
