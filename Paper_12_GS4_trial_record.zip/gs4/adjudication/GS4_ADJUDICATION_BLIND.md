# GS-4 Gold v1.0 — BLIND ADJUDICATION

**Trial:** GS-4 Gold v1.0 (house execution, two-arm isolated-context trial) — Paper 12, *The Aggregated Ledger*, v4 frozen tree.
**Adjudicator:** blinded adjudicator, spawned fresh; ran no attack and executed no examiner work (§10.3).
**Protocol:** spec §§9, 10.1, 10.3, 10.4, 14, as extracted in `adjudicator_extract.md`, followed exactly.
**Frozen paper:** `Paper_12_v4.md`, SHA-256 `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150` — recomputed by this adjudicator and matching the freeze value; 69,425 lines.
**Materials used (only these):** the 87 anonymized finding cards GS4-F-001…GS4-F-087; the anonymized evidence documents EV-01…EV-14; the witness artifacts ART-01…ART-41 under neutral names; the frozen paper and the packet sources beside it; the sealed mutation log (24 pre-registered mutations: 14 expectation met, 7 boundary-confirmed, 3 not met — M8, M14, M23; witness-countersigned 24/24 confirmed). Nothing under `gs4/submissions/`, `gs4/briefs/`, `KEY_SEALED.md`, or `ARTIFACT_INDEX_SEALED.md` was opened. No attempt was made to learn which examiner or arm produced any card; stance, fluency, and filing volume were not treated as evidence (§10.1).

## Method, applied per card (§10.3)

(i) The §9.5 category was verified against the frozen text; where wrong, the card is re-categorized **in the open** (original category, corrected category, and reason printed in the card's record). The strict rule was applied in reverse: a finding that cannot name the exact claim, a requirement of that claim, and a failure under the paper's declared premises is category D in substance whatever it calls itself. (ii) The §9 evidence standard was applied: five-part coverage map present and honest; witness complete; for any proposed BROKE, a genuinely independent second route (§9.3) — failing which the badge was downgraded to LIMIT with the reason recorded. Category C/D/E findings can never sustain a BROKE (§9.5 mapping). HELD was assigned only where the evidence reproduces the claim over its stated domain; evidence covering only a proper subset is LIMIT with the boundary named (§9.2). (iii) The adjudicated badge was assigned. (iv) The evidence that sustained or defeated the finding is recorded, quoting the argument where its exact wording matters. Duplicate charges across cards were adjudicated card by card on each card's own evidence, with convergence noted.

**Process status (§9.4, kept separate from claim status):** READ (protocol extract; all 87 cards; EV-01…EV-14; mutation log; frozen paper at every cited site relied on below) / NOT RUN (no examiner script or suite was executed by the adjudicator; computational witnesses were assessed from the filed artifacts and their printed outputs, and textual witnesses were verified by inspection of the frozen paper) / SOURCE-VERIFIED (frozen-paper hash recomputed; every load-bearing quotation in a sustained BROKE and in each re-categorization checked at its line in the frozen paper).

---

## Per-card records (87)

### GS4-F-001
- **Target claim:** L9.4-P12 (§9 claim list, line 2288; registry line 2871)
- **Self-classified category:** A
- **Verified category:** **B** (re-categorized from A — see evidence summary)
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Textual witness pair verified in the frozen paper: §0.2 (L45–57) defines a closed badge list with no 'Construction' category, while L9.4 carries '[Construction — Paper 12; components inherited as cited]' at home (L2288) and registry (L2871); second route — H.1's docstring supplements the taxonomy §0.2 never mints. RE-CATEGORIZED A→B in the open: in substance this is a missing definition required by the claim's own apparatus (§9.5 B), exactly as the convergent card GS4-F-020 files it; the construction's content and cited components are not impugned, so LIMIT (badge unpriceable from §0.2), not BROKE.

### GS4-F-002
- **Target claim:** L9.4-P12 (§9 claim list, L2288–2299; registry L2871)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Independent reconstruction of the §9.4 construction on the §9.5 worked population (all three demand regimes, incl. at-capacity) reproduces the claim's exact integer bookkeeping; the pressed hostile notes (cap-relativity, unbooked-demand blind spot) are the paper's own §9.6 disclosures. Coverage map complete and honest; no counterexample. Converges with GS4-F-004/-033 on content; the badge-pricing charge is a different target property (GS4-F-001/-020).

### GS4-F-003
- **Target claim:** L11.4-P12 (§11.3) — the overlap component ("on the representatives constructed at §11.3 it agrees with Paper 11 §12.1's ordering at every step")
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Attack (bridge-rule pricing of the §12.1 order as a proved premise) verified as category D in substance: the agreement claim's truth rests on this paper's own representatives and on §12.1's statement as a fixed target list (data), not on a proved premise whose grade transmits; ALT/reversal material is disclosed in the claim itself. Category D can never sustain a defect; the claim as written was reproduced (Workbook 5), so the adjudicated badge for the claim is HELD and the D-attack is recorded as a framework disagreement.

### GS4-F-004
- **Target claim:** L9.4-P12 (§9 claim list, L2288)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Construction reconstructed from its two licensed ingredients (Paper 9 §6 local behaviour; Paper 10 eq. (2.4) entries, threshold cited not redefined, no cross-source sum); the exhibit's arithmetic, including the at-capacity boundary row, reproduces exactly. Coverage map honest (fraction at J(τ)=0 expressly outside, and disclosed). HELD on the construction's content.

### GS4-F-005
- **Target claim:** L5.4-P12 (§5 claim list), with the same objection directed at L7.3-P12 and L10.1-P12
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Filer's own strict-rule concession is decisive: the demanded properties (large-population predictive limit, operational measurement procedure, continuum limit) are 'requirements of my framework, not of the claim', and the coverage map states no property of the paper was tested ('preserves: nothing'). Category D verified (the embedded Stage P bridge-thinness strand is C in substance, as the filer notes, and maps to the same disposition here). Tested properties not asserted by L5.4/L7.3/L10.1 as graded: OUTSIDE; never a defect.

### GS4-F-006
- **Target claim:** L11.4-P12 (§11 claim list)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** ALT-3 reversal witness is real but defeats only rendering-independence, which the claim does not assert: L11.4 asserts agreement on the constructed representatives under a disclosed, AUTHOR-graded identification and itself prints the reversal possibility. Requirement (ii) of the strict rule fails for the attack; category D verified; OUTSIDE.

### GS4-F-007
- **Target claim:** L8.10-P12 (§8 claim list, L2011–2023; registry L2867)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category E verified: L8.10 is the paper's explicit open-question marker for the §8.6/§9.6 joint; the filer's §J record (dynamics goes to Ω-minimal rest on the paper's own exhibits) contradicts only a future dynamics presentation, not the claim as written, whose strong form the paper itself refutes in-paper. E can never be a defect: OUTSIDE for the attacked property; the claim's honesty as an open marker is not impugned.

### GS4-F-008
- **Target claim:** L11.2-P12 (§11.3, L2630; claim list L2675)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.2 over its stated domain: identities checked by the filer's independent computations at sizes 0–12 and the definitions read in full contain no size-triggered branch for a check to miss; beyond the enumerated range the claim itself assigns AUTHOR strength (Edge 1), so no LIMIT arises from the machine horizon. Coverage map honest. HELD. (The uneven per-script size coverage of the named trio is a separate, narrower charge — GS4-F-031.)

### GS4-F-009
- **Target claim:** L5.4-P12 (§5 claim list, L1131)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Dissolution re-derived as a scoping result: each apparent measure-need resolves to deterministic dynamics or exact counting; the v3 gap (named-tuple joint frequencies) is reached by the v4 extended family whose identities the filer verified, and Prop. 5.9 identities were computed over random tables. Domain-general case analysis, not enumeration alone. HELD over the claim's stated scope.

### GS4-F-010
- **Target claim:** L7.3-P12 (§7.3) and L10.1-P12 (§10.1)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Objections (continuity, convergence, operational measurement) measure the claims against requirements of the framework the paper departs from; the filer concedes they are not requirements of L7.3/L10.1 as written. Category D verified under the strict rule in reverse; tested properties not asserted: OUTSIDE.

### GS4-F-011
- **Target claim:** L8.10-P12, §8 claims (L2011; registry L2867)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Textual witness pair verified: L8.10's own words ('Conjecture… The joint itself is not claimed', [LEVEL B]) against §0.2's two overlapping definitions — [NO BADGE] ('conjecture — do not cite as established') and [LEVEL B] (expressly including 'declared programme'). Second route is the counter-reading itself, also textual: the two definitions genuinely overlap and the paper does not say which governs. Category A verified (a tension within the paper's own rules, at the weakest strength the evidence supports). LIMIT: taxonomy-application ambiguity; no reader is misled about the joint's status, so not BROKE. Distinguished from GS4-F-049/-051/-063, which verify the claim's factual clauses and stand HELD on that property.

### GS4-F-012
- **Target claim:** L6.2-P12 (§6 claim list, L1344; Theorem 6.2, L1236)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified. The proof is sound under the pair-profile (encounter-level) reading — the reading Paper 11 §8.6's M supports and A.4 implements — but the claim's hypothesis is phrased at body level ('the same presented counts to the encounters'), and on the own-profile reading the load-bearing step is a missing derivation, counterexemplified by the filer's witness (equal own profiles (1,1); pair profiles (2,1) vs (1,2); outcomes separate). Second route: analytic source-text witness (§8.6's definition of M). LIMIT with exact boundary: counterpart/kind profile held fixed. Converges with GS4-F-066; distinguished from GS4-F-026/-038, which verify the conditional proof under its stated premises and stand HELD on that property.

### GS4-F-013
- **Target claim:** L7.3-P12 (§7 claim list, L1577–1579; registry L2854)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Every machine-typed component of L7.3 reproduced exactly; the one non-arithmetic component (identification with Paper 9 §4) is carried at exactly the AUTHOR grade the claim itself assigns it. No contradiction or missing derivation required by the claim as graded. HELD.

### GS4-F-014
- **Target claim:** L11.3-P12 (§11 claim list)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.3 read with its three stated edges: the extension is definitional and size-free; the hostile reading (that 'extends by construction' smuggles unbounded machine verification) is answered by Edge 1 in the claim's own section. What stays outside (taxonomy admission, packing) is expressly reserved by the claim, not asserted. HELD as an AUTHOR verdict at its stated strength.

### GS4-F-015
- **Target claim:** L0.3-P12 (§0.5 claim list)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** DOWNGRADED HELD→LIMIT under §9.1/§9.2. The filer's own coverage map confines the verified domain to the home sections of the twelve sampled claims and places the appendices outside ('a violation there would not be visible to this finding'); HELD requires reproduction over the stated domain (the whole paper's native voice), and evidence supporting only a proper subset is LIMIT with the boundary named. The boundary is not hypothetical: the defeating sites for this very claim sit in the excluded span (Appendix F; see GS4-F-021). Within the verified span the discipline holds, as filed.

### GS4-F-016
- **Target claim:** L5.4-P12 (§5 list L1131; registry L2840) and L10.1-P12 (§10 list L2510; registry L2875), via §0.4(b) (L91)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category E verified: §0.4(b) states the transitive-pricing residue in the open, names the two events that would discharge it (author ruling on the bridge rule's registry-keyed reading, or registration of the premise at its source), and records that neither has occurred — a question the paper explicitly leaves open, hence never a defect and incapable of sustaining a BROKE. Witness pair (§0.4(b) L91 vs the printed badges of L5.4/L10.1) and second route (round-5 history entry; no discharging ruling in rounds 6–10) both check out against the frozen text. LIMIT on both badges' present printed strength, exactly as §0.4(b) bounds it.

### GS4-F-017
- **Target claim:** L10.1-P12 (§10.1, L2331; registry L2875)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Mathematical content of L10.1 fully reconstructed (finiteness argument general; closed-population sharpening c=1 verified on computed trajectories, §8.7 (p,c)=(2,1) as printed). The LIMIT attaches only to badge pricing: §0.4(b) names L10.1 expressly among the claims standing one grade below their printed conditional badges under transitive pricing, pending the author's ruling. Category E verified (explicitly left open). Converges with GS4-F-016 and, on the residue's existence, GS4-F-045; the badge-width charge against the same claim is GS4-F-027/-078.

### GS4-F-018
- **Target claim:** L5.4-P12 (§5 claim list, L1131–1143; registry L2840)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Category B is the attack class (missing instrument/derivation required by the claim — the C32 pattern); it fired against the v3 form and the v4 claim is a different claim (extended instrument family, firing on the record). Against the v4 claim as written the filer found no missing instrument, resolving each attack family by a named instrument. HELD over the claim's stated scope only, as filed.

### GS4-F-019
- **Target claim:** L7.3-P12 (§7 claims, L1579)
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category C verified: the tested property (a discriminating observation / physical bridge for the temperature identification) is not asserted by L7.3, which asserts an identification at AUTHOR strength and disclaims a scale in its own scope section. Under §9.5 a C finding sustains at most LIMIT/OUTSIDE; per the claim's own Stage discipline the verdict is OUTSIDE. The claim itself stands HELD on its asserted content (GS4-F-013/-079/-083).

### GS4-F-020
- **Target claim:** L9.4-P12, §9 claims (L2288; registry L2871), as the sampled instance of a paper-wide badge family
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing definition required by the paper's own architecture): §0.2 purports to define every badge; H.1's embedded TAXONOMY recognizes classes §0.2 never defines ('Construction', 'Definition', 'Scope statement', etc.); whole-paper census of the 'Construction — Paper 12' string (12 occurrences) confirms a paper-wide family. Second route: L9.4's string honestly describes its content — what is missing is only the §0.2-level statement of what the badge guarantees. LIMIT: no Level A strength is asserted by these marks, so nothing is overclaimed. Converges with GS4-F-001 (same charge, re-categorized to B there).

### GS4-F-021
- **Target claim:** L0.3-P12 (§0.5, L145) and L8.5-P12 (§8 claim list, L1971–1975; registry L2862)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** BROKE
- **Adjudicated badge:** **BROKE**
- **Evidence summary:** BROKE SUSTAINED. Verified directly in the frozen paper: §0.5's entropy row (L128) admits the word/formula at §8.4's bridge sentence and §8.7's attributed application 'and nowhere else'; L8.5-P12 (registry L2862) repeats the two-site exclusivity; Appendix A's k_B row (L2789) states the token 'appears in Paper 12 only inside the entropy bridge sentence'. Appendix F applies the bridge three further times in the paper's own voice, printing the formula and Stage P values (L69351: S/k_B = 1.7918; L69365: 2.7081, 4.4998, 0; L69379: 8.9771, 7.9963, 0) — sites that are neither §8.4 nor §8.7. The invocation defence fails on the claim's own counting: §8.7's application is itself an invocation, yet the claim lists it as a separate permitted site. §9.3 second route present and independent in kind: exhaustive mechanical enumeration (k_B 29, entropy 41 occurrences, each zone-classified — counts independently confirmed) plus the direct textual witness pair, verifiable by inspection; L0.3's own falsifier (L145) is the self-supplied test these sites meet. Scope of the break, as filed: the exclusivity wording of L8.5-P12, L0.3-P12 and Appendix A's k_B row only; Ω's native counting, §8.4's sentence itself, and every Stage N derivation are untouched (no native claim uses the values; the S/k_B arithmetic itself recomputes correctly). Category A verified. Note on the filer's stated outside item: FW.1's generic BRIDGE-paragraph zone would classify these flagged paragraphs for sweep purposes, but a sweep zone is not the §0.5 disposition the claims assert, and no Appendix-F-specific exemption exists in the disposition text.

### GS4-F-022
- **Target claim:** L11.2-P12 (§11.3, L2630; registry L2882) and L11.3-P12 (§11.3, L2641; registry L2883)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Both claims verified as written and as graded (machine leg bounded to sizes 1–12; general leg AUTHOR via the proofs' uniformity in N). The filer's strongest attack — the thermodynamic-limit demand — is verified as category D in substance (the claims assert exact finite statements and expressly refuse the limit), so it is recorded as a framework disagreement; the claims themselves stand HELD. Category D here classifies the attack, per the filer's own filing; it sustains no defect.

### GS4-F-023
- **Target claim:** L9.4-P12 (§9 claims, L2288–2299)
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category C verified: the tested physical-regime/threshold property is not asserted by L9.4, which asserts a census in its own terms and disclaims the threshold identification in its own scope section. A bridge absence cannot break a claim that asserts no bridge (§9.5). OUTSIDE; the claim's asserted content stands HELD (GS4-F-002/-004/-033).

### GS4-F-024
- **Target claim:** L11.4-P12, §11.3/§11.4 (claim list L2677; registry L2884)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified: L11.4's AUTHOR leg asserts a general tick-stability theorem 'carried by §11.3's prose proof', but for two of the five invariants the printed proof's only step is a summarizing assertion, and the paper itself records that the dynamics premise for those record fields is not stated in §4 — a missing derivation step where the claim asserts the establishment. LIMIT, not BROKE: Ntot/Btot/CenSig stand as argued, and the invariants themselves were independently derived/computed by other examiners (GS4-F-053/-060) — the limit attaches to the printed proof as written, which is this card's target.

### GS4-F-025
- **Target claim:** L5.4-P12 (§5 claim list)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The restated (v4) dissolution was re-derived case by case; the strongest hostile constructions under the paper's own expressibility test are expressible by the extended family. The one-grade transitive residue through §0.4(b) is printed in the claim's own pricing and at §0.4(b) — a disclosed pricing boundary (adjudicated at GS4-F-016/-017/-045), not a failure of the dissolution's content. HELD on content over the stated scope.

### GS4-F-026
- **Target claim:** L6.2-P12 (§6 claims, L1344–1348; registry L2849)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L6.2's conditional proof reconstructed gapless as printed: its one extra premise is declared as inherited at the point of use, matching the claim's conditional badge; exhibit-level content independently reproduced across ten profiles × two licensed rules, including the case where the two rules disagree with each other while both factor through M. HELD at the claim's stated conditionality. (The hypothesis-phrasing gap is GS4-F-012/-066, a different target property.)

### GS4-F-027
- **Target claim:** L10.1-P12, §10 (claim list L2510; registry L2875)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category A verified (contradiction with the paper's own §0.2 rule, L48: a MACHINE badge 'is exactly as wide as its validation artifact'). Textual witness pair: L10.1's badge asserts the general statement over arbitrary finite populations, while A.3's own coverage map confines its verified domain to single-junction T-systems and three declared toy systems, placing many-junction well-definedness outside its check and concluding the badge it supports is the decomposition/frequency arithmetic conditional on A.2; the general leg is §5's prose argument plus Theorem 4.2. Second route: the paper's own allocation precedent (L8.3/L11.4 place such general content in an AUTHOR leg; L10.1 has no split). LIMIT, not BROKE: the missing leg exists in the paper and is merely unpriced in this badge; the claim's content is not impugned (GS4-F-039/-052/-075). Converges with GS4-F-078.

### GS4-F-028
- **Target claim:** L2.1-P12 (§2 claims, L298; registry L2826)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The inherited single-regime rule is quoted faithfully from a [LEVEL A] home, and every aggregate construction in the reconstructed sections (§§3–11) is exhibited as an exact finite sum, count, or rational ratio over the licensed list — which is all L2.1 asserts. HELD.

### GS4-F-029
- **Target claim:** L11.2-P12 (§11.3, L2630–2631; claim list L2675; registry L2882)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.2's stated domain verified by two independent routes: the filer's own code over sizes 1–12 (the claim's stated machine domain) and full reading of the definitions establishing the no-branch property. The claim asserts no machine coverage beyond that range (Edge 1, in the claim's own section), so no LIMIT arises. HELD. (Contrast GS4-F-031: the collective attribution to A.1/A.2/A.6, a narrower target.)

### GS4-F-030
- **Target claim:** L11.4-P12 (§11.3), via falsification condition C33 (§12)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified. GS4-H reconstruction (before/after from the version block, rounds 6–7) plus the textual witness pair (§11.3's definition, k_j as Paper 11 §4.1 port count, vs C33's scope note conceding the two readings 'separate, first at the −Btot component' on the divergence domain while placing that domain outside the killer's scope) establish the boundary; second route: the version block itself records the scoping as a repair after a witness in the exempted domain was produced. Concessions recorded by the filer stand: the log describes the change accurately and L11.4's claim scopes its machine content to A.14's disclosed domains, so the badged claim does not assert what C33 no longer tests. LIMIT: over the divergence domain (consumed-port count ≠ side count) the definition's key is computed by no script and killable by no condition — a Gate 7 reach boundary, named exactly. Converges with GS4-F-048/-055/-068.

### GS4-F-031
- **Target claim:** L11.2-P12, §11.3
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing establishment for part of a badged claim). Route 1, source inspection against run outputs: A.1 delivers sizes 1–12 exactly for §3; A.2 reaches junction-populations of 1–8, not 12; A.6 contains no population-size variation (fixed exhibits only). Route 2, independent: the filer's reimplementation verifies §7's identities at |P|=3,4 and the prose proof does not case on |P| — the mathematics is not in doubt; what is missing is the machine enumeration the claim's parenthetical attributes to the named trio. LIMIT with the boundary as filed (exact for §3; partial for §4; exhibited sizes only for §7).

### GS4-F-032
- **Target claim:** L10.1-P12, §10 claim list (frozen paper line 2331)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** A disagreement over what a true theorem is worth (finiteness triviality) is a foundations/ontology disagreement: category D verified, never a defect. The claim's stated content held under the filer's independent verification. OUTSIDE for the attacked property; recorded with its defeat, as filed.

### GS4-F-033
- **Target claim:** L9.4-P12 (§9 claims, L2288–2299; registry L2871)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Construction reconstructed from its two licensed ingredients; the §9.5 worked example reproduces exactly including the boundary row. The claim asserts a census, not a threshold location and not a physical transition, and says so in its own text. HELD on content.

### GS4-F-034
- **Target claim:** L11.4-P12, §11.3 (population ordering key K)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Two sealed independent implementations of K (§6.2 divergent-reading comparison) disagree on VALUES under a σ-derived port-vector-length reading (shared count vector (3,(2,2),14,9,3) vs (3,(1,1),16,9,3)) and agree on every ORDER outcome (deciders, family orders, name invariance, transitivity, stability invariants, empty-population key). Second route, textual: §0.5's terminology note, §3.4 and §3.1 show the text does not admit identifying k_j with port-vector length (k_j is a component of the declared record), so the divergence is a reading disagreement — category D verified for the attack — and on the text's own reading every machine-asserted order property reproduces: HELD for the claim, with the value-level boundary (key values under σ-only declarations; the clause-(ii) regime) recorded. This card is the §6.2 comparison Gate 4 names.

### GS4-F-035
- **Target claim:** L7.3-P12, §7 claims (frozen paper lines 1581–1585) and §7.4
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category C verified: L7.3 asserts a textual identification with a verbal definition plus exact rational arithmetic — both held under independent recomputation — and asserts no bridge to a measurable temperature. The gatekeeper objection ('not yet a temperature anyone can measure') is true of the framework's present state and is recorded as the bridge verdict the spec requires: OUTSIDE for the tested property, no defect.

### GS4-F-036
- **Target claim:** L11.4-P12, §11.3 / §11.4 claim list (frozen paper line 2677)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing specification required by the claim). Three readings of k_j, each admitted by some part of the corpus, give three different Btot/CenSig values for the paper's own exhibited representatives (meson-like (3,(1,1),16,9,3) vs (3,(2,2),14,9,3); nuclei likewise three-valued); §11.3 presents the representatives' junction data as σ alone and states no rule deriving k_j from σ, while A.14 silently adopts one reading. Second route (textual): §11.2 makes k_j a total-consumed-ports count requiring a ports-per-side datum the presentation does not supply. LIMIT with exact boundary: K's Btot/CenSig VALUES where ports-per-side are not separately declared. The order content survives under every admitted reading (deciders identical), so not BROKE. Converges in part with GS4-F-034 (value divergence) and GS4-F-048/-055/-068 (machine-leg boundary).

### GS4-F-037
- **Target claim:** L11.2-P12 (§11 claim list)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.2 is explicitly a claim about constructions/implementations over an enumerated range; over exactly that domain it holds by the filer's independent re-implementations plus full textual reading (one set of definitions, no size branch). Astronomical N is reserved by Edge 1 to AUTHOR-level argument in the claim's own grading. HELD.

### GS4-F-038
- **Target claim:** L6.2-P12 (§6 claim list, L1344–1348; registry L2849)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** No equal-profile/different-capability witness exists within the paper's declared premises: the proof's two premises (both named in the badge) jointly exclude it, and premise verification was performed at the Paper 11 source. HELD at the claim's stated conditionality.

### GS4-F-039
- **Target claim:** L10.1-P12 (§10.1, L2331; claim list L2510)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L10.1's content is a finite functional-graph fact with a complete analytic proof whose premises are precisely the inherited ones the badge names (T_agg well-definedness via A.2/Theorem 4.2); computational stress agrees everywhere, including the sharper closed-population consequence c=1. HELD on content. (Badge-width and pricing charges against the same claim: GS4-F-017/-027/-078.)

### GS4-F-040
- **Target claim:** L11.4-P12 (§11.3, L2677; registry L2884)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Category A attack class run in full (genuine-contradiction hunt under the paper's own rules) and produced no witness: L11.4 as written — including its AUTHOR-graded identification and stated-dynamics qualifier — was reproduced at every point the filer could reach, general properties by the printed finite-arithmetic proof checked step by step. HELD over the stated domain, in §9.2's exact sense.

### GS4-F-041
- **Target claim:** L11.4-P12, §11.3 (frozen paper line 2649)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing convention required by an asserted total preorder). Computational witness: two implementations of the count-vector order differing only in the proper-prefix rule for k_j tuples order 6,012 of 52,002 tied scalar-component pairs oppositely, decided at CenSig, with a hand-verified minimal witness (PA vs PB as filed; cmp −1 under P, +1 under L). Second route (textual): §11.3 legislates the prefix rule expressly for census SIGNATURES and is silent for the k_j tuples inside vectors. LIMIT, not BROKE: the conventional reading P is available and corroborated by everything A.14 prints; the boundary is exactly prefix-related k_j tuples at a CenSig decision point. (Distinct from GS4-F-076: whether the SIGNATURE prefix convention ever does deciding work — it does not — which stands OUTSIDE as filed.)

### GS4-F-042
- **Target claim:** The round-10 change record (version block, line 69425) and the content it changed — scripts A.15/A.7/A.14/A.10 INPUT_PROVENANCE blocks; component-split allocations of L8.3, L3.4, L7.3, L11.1, L11.4
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (test-correspondence gap, Gate 6 evidence). The round-10 change record is accurate — the filer verified its central items against the tree and found no discrepancy, and the log discloses the gap in its own text ('no script compares component-split text or provenance classes… not machine-checked content'), so no concealment and no BROKE. Second route: H.1's printed checks (1)–(4) independently confirm no check compares split text or provenance classes; A.9 covers listing byte-identity only. LIMIT: log integrity held; the 18/18 PASS closing the round tests none of the provenance classes or split allocations the round changed. Mutation-log corroboration: M1 (provenance relabel) and M2 (split move) pass the suite silently — boundary-confirmed as declared no-control zones.

### GS4-F-043
- **Target claim:** L1.2-P12 (§1 claim list; registry L2819) and L2.1-P12 (§2 claim list, L298; registry L2826)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Both citations verified at source; L2.1's governance survived a construction-by-construction hunt over the reconstructed sections. The filer's hostile note (L2.1's bare [LEVEL A] by inheritance) is answered by §0.4 itself: the source records it at [LEVEL A] with machine check F.41 — among the cleanest inheritances in the paper, unlike the §0.4(b) receipt chain. HELD.

### GS4-F-044
- **Target claim:** L0.3-P12 (§0.5 claim list, L145)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** LIMIT as filed, and correctly so under §9.2: the filer's independent spot scan (ART-04/-05) covers lines 1–2903 with every rarer-token line classified and no native-voice violation found — HELD over that span — but the claim's stated domain is the whole final tree, and Appendices C–J plus the FW.1 exemption adjudication itself stay outside this card's evidence. Convergence note: the defeating sites for this claim (GS4-F-021) lie in Appendix F, outside this card's verified span; nothing in this card's evidence contradicts them.

### GS4-F-045
- **Target claim:** L5.4-P12 (§5; Theorem 5.4, line 777; claim list lines 1131–1143; registry line 2840) — with L0.2-P12 (§0 claim list, line 102) as the rule claim it violates
- **Self-classified category:** A
- **Verified category:** **E** (re-categorized from A — see evidence summary)
- **Proposed badge:** BROKE
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** RE-CATEGORIZED A→E in the open, and the proposed BROKE is DOWNGRADED to LIMIT under the §9.5 binding mapping (category E can never sustain a BROKE and is never a defect). Reason: the charge's own counter-text is §0.4(b) (L91), where the paper states the transitive-pricing residue in its normative text, names the two events that would discharge it (an author ruling that the bridge rule's registry-keyed reading governs, or registration of the premise at its source), and records that neither has occurred. Which reading governs is therefore a question the paper explicitly leaves open — category E in substance, exactly as the convergent cards GS4-F-016/-017 file the identical residue. The filer's textual witness pair (§0.3 L73 + L0.2 L102 vs §0.4(b) L91) and the H.1 observation (its four checks contain no pricing check, so L0.2's named enforcement artifact cannot fire on a mispriced row) are both verified as facts and are recorded; they establish the LIMIT — L5.4's and L10.1's printed badges stand one grade above their transitively priced value on the paper's own diagnosis, pending the named ruling — but under the paper's declared premises the governing reading is expressly unresolved, so the strict rule's 'failure under declared premises' is not met for a BROKE. L5.4's content (the dissolution) is not impugned by any card.

### GS4-F-046
- **Target claim:** the sampled native claims collectively (L5.4-P12, L7.3-P12, L9.4-P12, L10.1-P12, L11.4-P12)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Collective gatekeeper demands (continuum limit, convergence, operational measurement, real-valued temperature) filed in full and correctly self-sorted: disagreements over mathematical foundations and ontology, category D verified; they sustain no BROKE and the tested properties are not asserted by any of the five sampled native claims. OUTSIDE.

### GS4-F-047
- **Target claim:** L2.1-P12 (§2 claim list, §2.3)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Quotation verbatim, lineage complete, registry agrees with home; the hostile reading (licensed list honoured only where convenient) found no instance across the sampled claims' constructions — every sampled aggregate quantity is a sum, count, or rational ratio over the licensed components. HELD over the inheritance as relied on by §§3–9 (whole-paper obedience sweep expressly outside, and not part of this claim's quote-and-lineage content).

### GS4-F-048
- **Target claim:** L11.4-P12 (§11.4 claim list, L2677) — its MACHINE component; and C33's first disjunct (§12)
- **Self-classified category:** A
- **Verified category:** **B** (re-categorized from A — see evidence summary)
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** RE-CATEGORIZED A→B in the open: in substance the charge is a missing machine computation/derivation of the defined key over the divergence domain (§9.5 B), identically to the convergent cards GS4-F-030/-055/-068 filed as B; no contradiction under the paper's own rules is shown, since the claim's MACHINE component is expressly bounded to 'the enumerated domains A.14's coverage states' and A.14's map prints the divergence (side-count reading, exact only where each side consumes one port). The filer's own analysis confirms the exemplar deciders are insensitive to the reading and its §J implementation independently checks the definition. LIMIT: outside the one-port-per-side regime the key's computation in the machine sense does not exist; the prose-carried definition stands HELD (GS4-F-040/-053/-060).

### GS4-F-049
- **Target claim:** L8.10-P12 (§8 claims, L2011–2023; registry L2867)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Category E verified (the substance is the explicitly open joint). HELD proposed and sustained for the claim AS WRITTEN — a [LEVEL B] statement that the joint is open, with its strong form refuted in-paper: both clauses verified by recomputation (§8.7 and the three Spine populations; (E1)/(E2) separation and Ω non-monotonicity preserved, e.g. 1→924→1). An E finding alleges no defect, and none is found in the statement's accuracy. (The badge-taxonomy ambiguity over the same claim is GS4-F-011, a different target property.)

### GS4-F-050
- **Target claim:** L8.10-P12, §8.6 / Appendix B registry row
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category E verified. The paper's own scoping answers the hostile reading: §8's claims are the finite counting facts plus Paper 9's boundary condition, C29 states that scope on its face, and L8.10 is badged [LEVEL B] as a conjecture whose joint is expressly unproved. The attacked property (a dynamics-to-Ω-drift theorem earning the arrow) is not asserted: OUTSIDE.

### GS4-F-051
- **Target claim:** L8.10-P12 (§8 claim list)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Category E verified; no BROKE proposed and none sustainable. The claim's checkable clauses are true (joint unproved everywhere in the claim surface; strong form refuted by a recomputed witness; conditional consequences stated as conditionals). HELD in the filer's stated sense: the open-question STATEMENT is accurate as written — not that the joint is settled.

### GS4-F-052
- **Target claim:** L10.1-P12 (§10.1, L2331; registry L2875)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The general proof of L10.1 was checked line by line and two exhibited trajectories recomputed; the strongest hostile reading (open populations under undeclared external driving) is answered by the claim's own section text in the same subsection — that regime is outside the claim as written. HELD on content.

### GS4-F-053
- **Target claim:** L11.4-P12 (§11 claim list)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Independent implementation of K from §11.3's definition (written before reading A.14; uses the declared k_j values directly, so it does not share A.14's side-count restriction): representatives' keys, chain order and named deciders (Ss, Ntot, Res, Ntot, Ntot) reproduce; homogeneous families m≤5; empty declaration; 200 random relabelling populations; Res/Tau0 sharpness pair re-witnessed; totality/transitivity/stability in general by the analytic argument. HELD over the stated domain.

### GS4-F-054
- **Target claim:** L11.4-P12 (§11.3 claim list, L2677; registry L2884)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** All six representatives' keys recomputed independently from the printed records; pairwise deciding components extracted; families m∈{1,2,3,5}; both rival renderings named at L2664 behave exactly as §11.3 states (lone-leftover moves the step to Tau0, order preserved; unsettled-entry decides the step nowhere — the 'decided at Res' assertion is expressly under the disclosed opposed-pair identification, graded in the claim's AUTHOR component). Paper 2 quotations checked verbatim. HELD over the exhibited domain, as scoped.

### GS4-F-055
- **Target claim:** L11.4-P12's machine content (§11.3 claim list L2677; falsification condition C33, L2706)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified. Textual witness pair (definition L2649/L141: k_j as consumed-port count ↔ C33 scope note L2706 stating the separation and its first point, −Btot) plus recomputation on the agreeing domain (representatives, homogeneous families, Spine populations, where port count = side count) establish exactly the filed boundary. LIMIT, not BROKE, for the filer's stated reason, which the text confirms: the claim as written scopes its machine content to A.14's disclosed domains and the note discloses the separation; what is missing is a machine derivation of the key for the port-count-distinct subdomain, which the claim does not assert. Converges with GS4-F-030/-048/-068.

### GS4-F-056
- **Target claim:** L7.3-P12 (§7 claim list)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing domain qualification). Computational witness (ART-06/-27: R/(|P|·|W|) at |P|=0 raises ZeroDivisionError in exact arithmetic) plus analytic second route (identity (7.4) also divides by |P|; §7.6's scope list names three limits and nonemptiness is none of them) plus precondition check (§2.2 states no nonemptiness clause; §11.3 expressly admits the empty declaration for a sibling definition, showing the paper's own standard on this point). LIMIT as filed, not BROKE: no exhibited population or drawn consequence touches the boundary. Exact boundary: verified for |P|≥1, |W|≥1; unstated and false-as-written at |P|=0 or |W|=0. Independent corroboration in the mutation log: M8 (A.15 crashes on the empty population, ZeroDivisionError — expectation NOT met). Converges with GS4-F-062.

### GS4-F-057
- **Target claim:** L0.3-P12 / L8.5-P12 bridge discipline (§0.5 construction list L125–135; §7.4 L1502–1507; §8.4 L1737–1741)
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** HELD
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** DOWNGRADED HELD→LIMIT, on a split verdict the filer's own method makes visible. Sustained: the Gate 8 presentation property — no native or computational pass is presented as experimental confirmation anywhere in the inspected material, §1.9 (L241) states the opposite ('no new empirical prediction is claimed in this paper'), and no native derivation uses a bridge value. Defeated: the card's further assertion that each admitted word enters 'only through its single declared bridge' as a site discipline — the filer's inventory itself lists the three Appendix F Spine applications, and GS4-F-021's witness establishes that those sites breach the two-site exclusivity L8.5/L0.3 assert as written. Category C verified (the finding is about the discrete-to-physical bridge; C sustains at most LIMIT/OUTSIDE). LIMIT with the boundary exactly there; the Gate 8 gate assessment below rests on the sustained presentation property only.

### GS4-F-058
- **Target claim:** L11.4-P12, §11.4 (claim list L2677; registry L2884)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing required dependency listing at the claim site, in its disclosure form). §0.2 requires a resting claim to list its declared assumptions among its dependencies (§0.2 [Declared assumption]: 'any claim resting on one lists it among its dependencies'); the three F.37 declared assumptions under the general nuclei/atoms step are listed in the prose (§11.3) and at §0.3's label, but not in L11.4's claim entry or registry row — both Role C dependency-break tables confirm ('not in the claim's own dependency text'). LIMIT, not BROKE: the assumptions are disclosed in the open at two other sites and the step's mathematics is untouched.

### GS4-F-059
- **Target claim:** L0.3-P12 (§0.5 claim list, L145; registry L2816)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** DOWNGRADED HELD→LIMIT under §9.2. Two independent grounds, both on the filer's own record: (i) coverage — the verified domain (§§0–13, Appendices A–B, Appendix F by reading) is a proper subset of the stated domain (the whole frozen paper including Appendices C–J listings), which this examiner did not occurrence-sweep and for which FW.1's run is expressly 'NOT RUN here'; evidence for a proper subset is LIMIT. (ii) Within the read span, the Appendix F bridge applications defeat the full claim as written (GS4-F-021), under the reading the claim's own falsifier invites; this card's contrary classification of those flagged segments is the invocation reading that GS4-F-021 argues down on the claim's own counting. The card's L1–2904 span is clean and converges with GS4-F-044's span result.

### GS4-F-060
- **Target claim:** L11.4-P12 (§11.4 claim list, L2677; definition §11.3, L2645)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Strongest independent verification of L11.4 in the set: general properties proved analytically (preorder, name-invariance, stability split), exemplar order and deciders (Ss, Ntot, Res, Ntot, Ntot) recomputed exactly, families, empty case returning (0,1,0,0,0,0,()) as §11.3 states, 300-population invariance/transitivity/tick-stability enumerations, and the stability boundary's sharpness re-witnessed with the filer's own pair (order reverses between declaration and rest, decided at Tau0) rather than taken from A.14. Source verification of the agreement target at Paper 11 §§12.1–12.3 and Paper 2's differentiae. HELD.

### GS4-F-061
- **Target claim:** L11.4-P12 (§11.3; claim list line 2677; registry line 2884) — lead instance; L7.3-P12 (sampled) and L3.4-P12, L8.3-P12, L11.1-P12 (same class, outside the sample) as the pattern
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** BROKE
- **Adjudicated badge:** **BROKE**
- **Evidence summary:** BROKE SUSTAINED, scoped exactly as filed: against the hybrid badge FORM as §0.2 defines it, instantiated by L11.4 (lead) and L7.3. Verified in the frozen text: §0.2 (L49) defines [LEVEL A: AUTHOR] as 'Declaration-backed, not derivation-backed'; §0.2 (L50) carries the hybrid's declared part 'under the [LEVEL A: AUTHOR] discipline'; yet L11.4's AUTHOR leg carries 'the tick-stability theorem in general, carried by §11.3's prose proof' and 'the general order properties… §11.3's finite-arithmetic reading of the definition', and L7.3's AUTHOR leg carries the (7.4) identity in general 'carried by §7.3's prose (exact rational arithmetic…)'. §9.3 second route, independent in kind: the paper's own version block (round 10, L69425) records this identical charge as standing 'parked for the author's ruling, unrepaired: that prose-proved general content carried in an AUTHOR leg sits against §0.2's text for that subtype'; third instance: L8.3's AUTHOR leg carries the all-n generality 'carried by §8.3's printed induction' — an induction is a derivation in anyone's vocabulary. Coverage is complete: all nine hybrid claims' splits read in full (native domain = verified domain). Category A verified (genuine contradiction under the paper's own rules — its subtype definition vs its allocations). Distinguished from GS4-F-045: there the normative text (§0.4(b)) itself suspends the pricing question pending a ruling; here no normative text qualifies §0.2's definition — the parking is recorded in the changelog, not enacted as a qualification of the definition the claims invoke. Concessions stand as filed: the allocations are printed in full (nothing about which content sits in which leg is hidden), and the underlying claims' contents are separately HELD (GS4-F-013/-040/-053/-060/-079/-083); the break is in the badge form's conformance to its own definition, and L0.1-P12's falsifier ('any claim… carrying a badge its stated backing does not support is a defect against this declaration') is the claim-level hook.

### GS4-F-062
- **Target claim:** L7.3-P12 (§7 claim list, L1577); also touching L5.3-P12's ratios and §7.2's setup
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified (missing domain statement). Complete witness: P=∅ (admitted by §2.2's 'finite family of bodies' as written, and by §11.3's express admission of the empty declaration for K) gives D=0/0, not a rational; likewise the empty window (§5.2 states no m≥1, while Definition 5.8 does state 'at least one tick' for joint counts — the paper states such restrictions where it intends them). Demonstrated computationally (ART-06/-27, ZeroDivisionError in exact Fraction arithmetic for both cases); second route: direct textual inspection of §§2, 5, 7. LIMIT as filed: over |P|≥1, |W|≥1 the claim is HELD (GS4-F-013/-079/-083); the defect is an unstated quantifier restriction at the extreme boundary. Converges with GS4-F-056.

### GS4-F-063
- **Target claim:** L8.10-P12 (§8 claim list, L2011; home text §8.6)
- **Self-classified category:** E
- **Verified category:** E
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Category E verified. The claim is an explicit open-question statement and its factual presuppositions check out exactly: the joint is unproved everywhere in the claim surface (claim lists §§1–13 read in full), the strong form is refuted by a recomputed in-paper witness (one refuting witness is complete for a universal strong form), and the conditional consequences are stated as conditionals. HELD in the filer's stated sense — the statement as written (a [LEVEL B] target statement) is accurate; the joint itself is not thereby settled.

### GS4-F-064
- **Target claim:** L9.4-P12 (§9 claim list)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified, same defect class as GS4-F-056/-062 at a distinct claim and sites: L9.4's fraction-as-exact-rational component lacks its domain qualification at the junctionless boundary (J(τ)=0); the census, regime change, and all exhibited arithmetic hold (GS4-F-002/-004/-033). LIMIT with the boundary named; the count content is unaffected.

### GS4-F-065
- **Target claim:** L7.4-P12 (§7.4, L1580–1582) with L7.3-P12's identification leg
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category C verified, disposition LIMIT as filed: the native claim L7.3 stands HELD (GS4-F-013), and the physical-facing reach of §7 is limited to exactly the boundary named — an author's identification (graded AUTHOR in the claim) plus a deferred scale; no scale, calibration, unit, or discriminating observation is asserted anywhere in §§7, 13 or Appendix A. C cannot sustain a BROKE; LIMIT names the bridge boundary, per the target's Stage discipline.

### GS4-F-066
- **Target claim:** L6.2-P12 (§6 claim list; Theorem 6.2)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified. Line-by-line re-derivation locates the gap in the printed proof itself: the load-bearing step (L1263–1265) follows only if 'profile' is the encounter's pair profile AND E fixes the other side; Definition 6.1's membership condition (L1230–1232) depends on 'the encounter's other side', which the theorem's hypothesis never mentions, and side-position is nowhere fixed. Computational witness (ART-26) prints both readings: under the pair-profile reading the witness's precondition FAILS and no counterexample stands (so BROKE, argued first, does not stand — no witness satisfies every precondition under the claim's own cited premise); under the own-side reading the precondition holds and the conclusion fails. LIMIT with exact boundary: established where E fixes the pair profile (and side-position); not established as the bodies' own presented counts. Converges with GS4-F-012.

### GS4-F-067
- **Target claim:** Appendix F Spine exhibit (no claim registered — Appendix F registers no claims, per A.15's header at L14020–14021; the exhibit's stated purpose at L69335)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified, exhibit-level only. Reader-only reconstruction of all three Spine paths: every station verifies from Appendix F plus the body sections except the capability cardinalities, whose input (the 15 encounter kinds' profiles) is never listed in the exhibit and must be mined from A.4's listing (L4976 taxonomy); with it supplied, every printed cardinality in all three exhibits reproduces (all checks PASS), corroborated by the paper's internal profile-sharing statements. LIMIT on the exhibit's stated 'without leaving the exhibit' property (L69335) only: no number is wrong, no claim's badge turns on it. Converges with the Role A boundary finding in the evidence documents (Appendix F capability station).

### GS4-F-068
- **Target claim:** L11.4-P12, §11.3/§11.4 (claim list L2677; registry L2884); falsification condition C33 (L2706)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified. The C33 scope note (L2706) is the paper's own witness: it names the parting domain, the first separating component (−Btot), and declares the machine content unasserted there; second route: A.14's provenance block independently prints the side-count reading as a disclosed reading of class paper-defined, distinct from the definition's cited-paper (port-count) reading. LIMIT, not BROKE, as filed: the disclosure is complete in the paper, but L11.4's claim text and registry row do not themselves carry the restriction — the verified (machine) domain is a proper subset of the defined domain, boundary named at C33. Converges with GS4-F-030/-048/-055.

### GS4-F-069
- **Target claim:** L1.2-P12 (§1 claim list, L246)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Every quoted element of L1.2 — both named items (microstate-counting rule; sampling-measure postulate) and the fill rules — is present at the cited Paper 11.5 source in the quoted words (direct textual comparison, packet source located and read). A [CITED] claim asserts the source says it; the source does. HELD. Converges with GS4-F-084/-087.

### GS4-F-070
- **Target claim:** L11.3-P12 (§11.3 verdict, L2641; claim list L2676; registry L2883)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.3's verdict read with its three edges was reconstructed without residue: the extension is definitional and size-free, and the one apparent internal tension (a census conferring no rank beside a population key built partly from census data) is resolved by the paper's own distinction, stated at both sites, between a partition conferring rank and data feeding a definition — the second clause confirmed constructively, not only by reading. HELD.

### GS4-F-071
- **Target claim:** L5.4-P12 (§5 claim list, L1131)
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category C verified: the absence of a predictive bridge over undeclared populations is real but is not a defect of L5.4 — the claim's own Stage discipline asserts no bridge, and the paper concedes the undeclared-population territory expressly (L5.8-P12; §1.9). Under §9.5 C cannot sustain a BROKE; the attacked property stands OUTSIDE the claim.

### GS4-F-072
- **Target claim:** L11.4-P12 (§11.3, L2653–2666)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category D verified: the tested property (rendering-independence of the §11.3 agreement) is not asserted by L11.4, which asserts the opposite — agreement under one disclosed construction. D can never sustain a BROKE and none is proposed. OUTSIDE; recorded so the gatekeeper's strongest §11.3 argument and its strict-rule disposition stand side by side. Converges with GS4-F-006.

### GS4-F-073
- **Target claim:** L2.1-P12 (§2 claim list, L298)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L2.1's inheritance is exactly as cited, at the strength cited (quotation, inheritance line, registry in agreement), and the reliance is real: the paper's aggregate quantities are, construction by construction, of the licensed forms (§§3–9 read at their definition sites). HELD. Paper 11's own F.41 check was not re-run — it is the source's artifact, consumed as inherited, and is outside this claim's quote-and-lineage content.

### GS4-F-074
- **Target claim:** L9.4-P12 (§9 claim list, L2288)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified, same shape as GS4-F-064 at this card's sites: L9.4's construction is exact on its interior domain, but the ratio's domain restriction (J(τ)≥1) and the window-initial convention for 'change' are unstated at the claim's sites. LIMIT with both boundaries named; the count content is unaffected (HELD at GS4-F-002/-004/-033).

### GS4-F-075
- **Target claim:** L10.1-P12 (§10.1)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The finite-function argument for L10.1 is complete and gapless over the stated domain; the filer's computational search (300 random small populations in the parallel verification; analytic argument covering all cases) found no counterexample and confirms the c=1 closed-case clarification. Enlarged transitions under undeclared external re-presentation are outside the claim as written ('under T_agg'), as §10.1's clarification states. HELD on content.

### GS4-F-076
- **Target claim:** L11.4-P12 (§11.4 claim list, L2677); definition §11.3 (L2645)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** The tested property — that §11.3's signature prefix convention does deciding work in the key — is not asserted by the claim; §11.3 states the convention to make the order total, and the filer's proof shows it is a completeness clause, never a live decider (the boundary is empty). Category A is the attack class run; the disposition is OUTSIDE (property not asserted), with no defect. Distinguished from GS4-F-041, which concerns the unstated prefix rule for k_j TUPLES inside vectors, where the order genuinely flips.

### GS4-F-077
- **Target claim:** L11.3-P12 (§11.3 verdict, L2641; claim list L2676)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L11.3's verdict is an accurate statement about the paper's own machinery: the definitions are size-free, the three edges are real and printed in the claim, and the census confers no rank — the last confirmed constructively over the representative pair and in general from the census's definition (a count function defines no order). HELD.

### GS4-F-078
- **Target claim:** L10.1-P12 (§10.1, line 2331; registry line 2875)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category A verified (§0.2's MACHINE definition, L48, is the paper's own rule the badge breaches). Textual witness pair: the universal claim sentence (L2331, 'Every aggregate trajectory of a finite population') against A.3's provenance/coverage (toy systems as controls; test populations), with the prose Ground (L2332) standing between them as the actual carrier of the generality. Second route: §10.1's own bracket concedes the division of labour — neighbouring parts of the same apparatus carry non-MACHINE badges, and the bracket 'covers only the A.3 items it enumerates'. LIMIT, not BROKE, as filed: the claim is established — by the prose the badge fails to credit — so the disposition is a badge correction. Converges with GS4-F-027; the claim's content stands HELD (GS4-F-039/-052/-075).

### GS4-F-079
- **Target claim:** L7.3-P12 (§7 claims, L1579; registry L2854)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** L7.3's arithmetic reproduced in full over four populations (§7.5 example and the three Spine populations), and the identity's proof is size- and window-free; the identification content is carried at exactly the AUTHOR grade the claim assigns it. No contradiction under the paper's own rules. HELD. (The empty-domain qualification gap is GS4-F-056/-062, a boundary the exhibited domain does not touch.)

### GS4-F-080
- **Target claim:** L7.3-P12 (§7 claim list, L1577)
- **Self-classified category:** C
- **Verified category:** C
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Category C verified: a numerical temperature scale is a property the paper explicitly does not assert for L7.3 (the identification is AUTHOR-graded; the scope section disclaims a scale). An unbuilt bridge cannot break a claim asserting no bridge; under §9.5 C sustains at most LIMIT/OUTSIDE, and the tested property is OUTSIDE.

### GS4-F-081
- **Target claim:** Appendix F, E-SMALL joint counts (exhibit values under A.15; Definition 5.8, §5)
- **Self-classified category:** B
- **Verified category:** B
- **Proposed badge:** LIMIT
- **Adjudicated badge:** **LIMIT**
- **Evidence summary:** Category B verified, minor and exhibit-level. Independent regeneration of E-SMALL under both readings of the window '(0, 3)': counts are 1 under either, but the printed frequency 1/3 requires the half-open reading |W|=3 over {0,1,2} (inclusive reading gives 1/4), and no sentence in Appendix F's conventions or §§5–9 states which reading the notation carries — while the same appendix writes the reconcile window inclusively. LIMIT: reader-side reproducibility of the frequencies (not the counts) rests on inference from the printed values; no claim's badge turns on it, A.15 machine-checking the values under its declared representation. Converges with the Role D finding in the evidence documents (ART-20/-40 regeneration).

### GS4-F-082
- **Target claim:** L0.3-P12 (§0.5 claim list, L145; registry L2816)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** BROKE
- **Adjudicated badge:** **BROKE**
- **Evidence summary:** BROKE SUSTAINED, following GS4-F-021 as the filer expressly conditioned it ('if the adjudicator sustains Finding 1… this finding's badge should follow it'). The witness is identical and is not double-counted as an independent defect: it is the same Appendix F breach applied to L0.3-P12, the §0.5 claim that supplies the falsifier ('a locked word found in this paper's native voice outside its disposition… standing uncorrected in a final tree', L145). This card's own additional evidence — the sweep of the remaining locked words' routes (temperature only as the §7.4 construction; thermal equilibrium only as the (E1)+(E2) construction; ensemble/microstate/probability distribution/Gibbs/Boltzmann in own voice only in quotations, Stage C history, and exclusion statements) — stands verified and bounds the break to the entropy/k_B family exactly. Category A verified; §9.3 is satisfied through GS4-F-021's witness pair plus independent enumeration, incorporated here by the filer's own reference.

### GS4-F-083
- **Target claim:** L7.3-P12 (§7 claim list, L1577)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The arithmetic content of L7.3 is proved, not merely sampled: the identity is a rearrangement of a finite sum over a shared denominator (analytic derivation, domain-general), the worked example recomputes exactly, and the cap arithmetic and its Paper 10 source check out; r_b(τ) is read under §7.2's declared identification, whose AUTHOR grading the claim itself carries, and the Paper 9 §4 identification is carried at exactly that grade. HELD.

### GS4-F-084
- **Target claim:** L1.2-P12 (§1 claim list, §1.2)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Direct textual comparison: the three quoted blocks at §1.2 match the packet Paper 11.5 text at the cited addresses word for word. A [CITED] claim asserts the source says it; the source does. HELD. (Whether §§3/5 discharge the debt is L5.4's content, expressly outside this citation claim.) Converges with GS4-F-069/-087.

### GS4-F-085
- **Target claim:** L5.4-P12 (§5 claim list, L1131–1143; registry L2840)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** The v4 discharge reconstructed case by case; its one historically fired point (C32 against the v3 form) is repaired by an instrument extension (Def. 5.8 + Prop. 5.9) whose defining identities the filer verified independently, the definitions and proofs being stated for all tuples and windows (machine domain k≤3 tuples as A.12 states). Within the framework's own scope, no inexpressible frequency was found or constructed. HELD.

### GS4-F-086
- **Target claim:** Theorem 4.2 / L4-series, §4 (frozen paper lines 423–432 and Theorem 4.2 statement)
- **Self-classified category:** D
- **Verified category:** D
- **Proposed badge:** OUTSIDE
- **Adjudicated badge:** **OUTSIDE**
- **Evidence summary:** Filed and verified as category D: the absence of a continuous limit for the aggregate tick is a defect only if Theorem 4.2 / the L4-series entails one, and it does not — the claims assert exact finite statements. D can never sustain a defect; the tested property is not asserted: OUTSIDE. Recorded with its defeat, as filed.

### GS4-F-087
- **Target claim:** L1.2-P12 (§1 claims, L246; registry L2819)
- **Self-classified category:** A
- **Verified category:** A
- **Proposed badge:** HELD
- **Adjudicated badge:** **HELD**
- **Evidence summary:** Direct textual comparison of §1.2's quotations against the packet Paper 11.5 source at its L2806–2807: both numbered items and the sampling-measure sentence match verbatim, and the §1.5 roadmap sentence was checked to the same standard. A [CITED] claim stands or falls on its source saying what is quoted; it does. HELD. G.1's full quote-integrity sweep is Role D's run and is expressly outside this card (see Gate 4 note on mutation M23).

---

## Tally

### Adjudicated badges, overall (87 cards)

| Badge | Count |
|---|---|
| HELD | 38 |
| BROKE | 3 |
| LIMIT | 31 |
| OUTSIDE | 15 |
| **Total** | **87** |

Per §9.2 these verdicts are not summed into a score or percentage; the three BROKEs are not cancelled by any number of HELDs.

### Adjudicated badges by verified category

| Category | HELD | BROKE | LIMIT | OUTSIDE | Total |
|---|---|---|---|---|---|
| A — genuine contradiction under MSDS's own rules | 31 | 3 | 6 | 1 | 41 |
| B — missing derivation required by a claim | 1 | 0 | 20 | 0 | 21 |
| C — unestablished bridge to physical measurement | 0 | 0 | 2 | 5 | 7 |
| D — disagreement over foundations/ontology | 3 | 0 | 0 | 7 | 10 |
| E — question the paper explicitly leaves open | 3 | 0 | 3 | 2 | 8 |
| **Total** | **38** | **3** | **31** | **15** | **87** |

Notes on the table's shape: category D/HELD and B/HELD and E/HELD cells record cards whose *attack* resolves into that category (or whose B-class attack found nothing missing) while the target claim itself stands — the category classifies the finding, the badge the claim on the property that card tested; each such record says so in its evidence summary. No C, D, or E card sustains a BROKE, per the §9.5 binding mapping.

### Re-categorizations: 3 (printed in the open in the card records)

| Card | Original | Corrected | Reason (short form) |
|---|---|---|---|
| GS4-F-001 | A | B | The charge is a missing definition (§0.2 never defines the 'Construction' badge family) required by the claim's own apparatus — §9.5 B in substance; identical charge to GS4-F-020, filed as B. |
| GS4-F-045 | A | E | The governing pricing reading is expressly left open by the paper's normative text itself (§0.4(b) names the residue and its two discharge events, neither of which has occurred) — §9.5 E in substance; identical residue to GS4-F-016/-017, filed as E. |
| GS4-F-048 | A | B | The charge is a missing machine computation of the defined key over the divergence domain — §9.5 B in substance; identical boundary to GS4-F-030/-055/-068, filed as B. No contradiction is shown, the claim's machine component being expressly scoped to A.14's disclosed domains. |

### BROKE proposals: 4 filed, 3 sustained, 1 downgraded

| Card | Proposed | Adjudicated | Reason |
|---|---|---|---|
| GS4-F-021 | BROKE | **BROKE** | Sustained: two-site exclusivity of L8.5-P12/L0.3-P12 breached at three Appendix F sites (L69351, L69365, L69379), verified by inspection; independent second route present (exhaustive occurrence enumeration + textual witness pair, §9.3). Scope: exclusivity wording only. |
| GS4-F-082 | BROKE | **BROKE** | Sustained: same witness as GS4-F-021 applied to L0.3-P12, the claim supplying the falsifier; expressly conditioned by the filer on GS4-F-021 being sustained, and not double-counted as an independent defect. |
| GS4-F-061 | BROKE | **BROKE** | Sustained: §0.2's AUTHOR subtype ('Declaration-backed, not derivation-backed') vs prose derivations carried in hybrid AUTHOR legs (L11.4, L7.3, + L8.3 instance); second route independent in kind (the paper's own round-10 record of the identical charge standing unrepaired); coverage complete over all nine hybrid claims. Scope: the badge form's conformance to its own definition; contents separately HELD. |
| GS4-F-045 | BROKE | **LIMIT** (downgraded) | Re-categorized A→E (above): category E can never sustain a BROKE (§9.5). The residue is real and is recorded as a LIMIT on L5.4's and L10.1's printed badge strength pending the author ruling §0.4(b) names. |

### Other badge changes (HELD → LIMIT, on the §9 evidence standard): 3

| Card | Proposed | Adjudicated | Reason |
|---|---|---|---|
| GS4-F-015 | HELD | **LIMIT** | The card's own coverage map confines verification to the sampled claims' home sections and places the appendices outside; HELD requires reproduction over the stated domain (whole paper's native voice). The defeating sites sit in the excluded span (GS4-F-021). |
| GS4-F-057 | HELD | **LIMIT** | Split verdict: the Gate 8 presentation property is sustained, but the card's 'only through its single declared bridge' site discipline is defeated by the Appendix F applications its own inventory lists (GS4-F-021). Category C sustains at most LIMIT/OUTSIDE in any case. |
| GS4-F-059 | HELD | **LIMIT** | Verified domain is a proper subset of the stated domain (Appendices C–J not swept; FW.1 expressly NOT RUN by this examiner), and the Appendix F sites defeat the full claim as written (GS4-F-021). The L1–2904 span result (clean) stands and converges with GS4-F-044. |

All other 80 cards: adjudicated badge = proposed badge, verified category = self-classified category.

### Sustained BROKEs — author's list (defects, §9.5 categories A)

1. **L8.5-P12 / L0.3-P12 bridge-site exclusivity** (GS4-F-021, GS4-F-082 — one underlying defect, two claim sites): the two-site admission ('§8.4's bridge sentence and §8.7's attributed application, and nowhere else') is breached by three further own-voice applications in Appendix F (L69351, L69365, L69379), and Appendix A's k_B row ('appears in Paper 12 only inside the entropy bridge sentence') falls with it. The filer's one-line repair is noted for the author, not enacted here: admit 'and its attributed applications at §8.7 and Appendix F' in all three texts.
2. **Hybrid badge form vs §0.2's AUTHOR definition** (GS4-F-061): prose-proved general content (tick-stability in general; the all-n induction; grouping-independence in general; identity (III) in general) is carried in AUTHOR legs that §0.2 defines as declaration-backed, not derivation-backed — a charge the paper's own round-10 record already carries as parked for the author's definitional ruling.

---

## Acceptance gates (§14)

Assessed from the cards, the evidence documents, and the mutation log. Per-arm readings are noted where the evidence differs; no gate is inferred from another gate.

| Gate | Verdict | Deciding evidence |
|---|---|---|
| **1 — Identity** | **PASS** | Frozen hash independently recomputed by both Role D examiners (EV-06 §1, EV-13 §1) and by this adjudicator: `fc0499af…f473150`, matching the freeze value. Packet source hashes recomputed and matching (EV-01, EV-06, EV-13 identity tables). Extraction from the frozen paper's own Appendix C reproduces all 24 manifest rows byte-identically (sha256 + byte count, 24/24 — EV-06 §1; mutation-log baseline independently confirms 24 Appendix C + 8 Appendix E rows). Environment recorded (Python 3.12.3, Ubuntu 24.04, stdlib only — EV-06 §2, EV-13 §1). Mutation M13 confirms the hash-verification control itself fires: it flags a packet/paper9.txt MISMATCH (1 of 10) as pre-registered. |
| **2 — Reconstruction** | **PASS** | Both Role A examiners reconstructed the native definitions and the selected load-bearing derivations from the packet alone (EV-01 workbook (1)–(6); EV-08 workbook (1)–(6)), including the aggregate tick, the K ordering and its deciding components, census/flow/joint definitions, and a complete end-to-end Spine path (E-SMALL) reconstructed reader-only (GS4-G in both). Every sampled claim's reconstruction is filed as a card and adjudicated above. Named boundaries do not defeat the gate: Appendix F's capability station requires A.4's taxonomy from Appendix C (GS4-F-067, LIMIT on the exhibit's self-containment sentence only, all values reproducing once supplied), and K's Btot/CenSig values under σ-only declarations are reading-sensitive while every order outcome is not (GS4-F-034/-036). |
| **3 — Badge honesty** | **NOT DECIDED** | Blind-side component complete: both sealed blind classification sets (EV-03, EV-10) were revealed and every discrepancy resolved and recorded against §0.2 in the reveal addenda (EV-04: five examiner-misses, three paper-defects — L8.10, L9.4, L10.1, each at LIMIT; EV-11: examiner-misses incl. one packet-caused, paper-defects sustained on L5.4/L10.1 badge grade and form, L9.4's label, and the hybrid AUTHOR-leg practice). This adjudication concurs in substance: the paper-side discrepancies stand as adjudicated LIMITs (GS4-F-001/-011/-020/-027/-045/-078) and one BROKE (GS4-F-061). What it waits for: §14 completes Gate 3's discrepancy record **after unblinding**, which this blinded adjudicator does not have; the final discrepancy record is a post-unblinding act. |
| **4 — Computational independence** | **NOT DECIDED** (computational limb PASS on the blind evidence; charter-integrity component NOT DECIDED) | Reproduction limb: selected machine results reproduce through genuinely second implementations in both arms — K (incl. the §6.2 divergent-reading comparison: values diverge under the σ-derived reading, every order outcome agrees; GS4-F-034, ART-17/-33/-34), A.5-class assignment counts (ART-14, ART-36), population temperature/census ratios (ART-38), the assignment and Spine regenerations (ART-20/-21, ART-39/-40), all with printed outputs; the full suite reproduces 18/18 in both arms' clean extractions (ART-23/-41). Mutation limb: controls demonstrably can fail when expected — 14 expectation-met firings (incl. H.1 on M3/M7, A.15 on M4, A.9 on M5, A.14 on M20/M21, FW.1 on M18) and 7 boundary-confirmed declared no-control zones; **3 expectations NOT met, recorded as limits on specific controls, not concealed**: M8 (A.15 crashes on the empty population, ZeroDivisionError — converges with GS4-F-056/-062), M14 (a duplicate declaration is silently double-counted in direct totals and silently collapsed in grouped totals; no rejection, no stated duplicate rule), M23 (G.1 still reports a mid-phrase-truncated quotation as FOUND — prefix/substring property). No card among the 87 files the M14 or M23 defects; they stand on the mutation log alone and are carried here so the record is complete. What the gate waits for: the charter-integrity input to Gate 4, which is an attribution-dependent, post-unblinding audit (§14) outside this adjudicator's materials. |
| **5 — Dependency integrity** | **NOT DECIDED** | Graph limb substantially sustained: both Role C dependency graphs and break tables (EV-05 §§2/6, EV-12 Workbooks 1/4) find no sampled claim with an *unnamed* load-bearing dependency whose removal silently collapses it — every collapse point is named in the claim, its badge, or §0.4(b) — with two recorded exceptions of degree (L7.3's consumption of L7.2's identification not named in L7.3's own split; L10.1's badge crediting the corroborating script rather than the prose carrier, GS4-F-027/-078) and one claim-site listing omission (L11.4's F.37 declared assumptions disclosed at §11.3/§0.3 but not in the claim entry or registry row, GS4-F-058). Pricing limb undecidable on the blind evidence: whether any claim outranks its weakest dependency turns on the transitive-vs-registry-keyed reading of the bridge rule, which the paper expressly leaves open at §0.4(b) pending an author ruling or registration of the premise at its source (GS4-F-016/-017, LIMIT; GS4-F-045 as re-categorized). The gate therefore waits on that ruling, not on further examination. Mutations M15/M19 (removed dependency edge; omitted assumption name) are boundary-confirmed declared no-script-control zones, assigned by the spec to the Role C audit that was in fact performed. |
| **6 — Change integrity** | **FAIL** (test-correspondence limb; tracing and disposition limbs pass) | Tracing: both Role C examiners reconstructed the sampled changes old text → new text from the version block and verified the after-states against the frozen tree, with dispositions recorded (EV-05 §8; EV-12 Workbook 6 — round-7 C33 scoping, round-10 provenance re-classing and L8.3 split conformance, round-9 L6.2 conditionality conformance, the last HELD outright). The change logs themselves are accurate — no discrepancy was found in any checked item (GS4-F-042). Tests: the gate's test limb fails on the paper's own admission, recorded at GS4-F-042 (adjudicated LIMIT): the round-10 record states that no script compares component-split text or provenance classes, so the 18/18 PASS closing that round tests none of the substance that round changed; the mutation log corroborates with boundary-confirmed silent passes for exactly these shapes (M1 provenance relabel, M2 split move, M6 unlogged scope edit — the last caught by no script and assigned to audit). A sampled change whose substance no corresponding test covers does not meet Gate 6 as written. |
| **7 — Falsification reach** | **PASS** | An independent-context reader can state a real falsifier for every selected Level A claim from the paper alone: both Role A falsifier tables do so claim by claim (EV-01 Gate 7 support; EV-08 gate readings), each falsifier being a finite exhibit producible in the ledger's own terms (C33, C28, C25/C32, C30, C26, and L0.3's own falsifier at L145 — the last in fact fired, GS4-F-021). Where no falsifier is available over a claim's full native domain, the paper explicitly names the boundary, as the gate's alternative allows: C33's scope note bounds L11.4's machine falsifier to A.14's disclosed domains (GS4-F-030, LIMIT records the reach boundary exactly), and L8.10 — [LEVEL B], not Level A — names both outcomes that would decide it in its own text. |
| **8 — Physical separation** | **PASS** (on presentation only, per the gate's text) | No card, evidence document, or mutation record shows a native or computational pass presented as experimental confirmation: the paper states the opposite at §1.9 (L241, 'no new empirical prediction is claimed in this paper'), every bridge token sits in a flagged [BRIDGE — Stage P] segment with 'no native statement uses those values' at its site, and the adjudicated bridge cards (GS4-F-019/-023/-035/-057/-065/-071/-080) uniformly record unbuilt bridges as unbuilt — their verdicts concern presentation and assertion, not experimental warrant. (GS4-F-057's LIMIT concerns site exclusivity, not presentation as confirmation, and does not touch this gate.) Whether any bridge is *established* is not this gate's question and is not decided here. |

**Gate summary:** PASS — Gates 1, 2, 7, 8. FAIL — Gate 6 (test-correspondence limb only). NOT DECIDED — Gate 3 (waits for the post-unblinding discrepancy record) and Gate 4 (waits for the post-unblinding charter-integrity audit; its computational limb passes on the blind evidence), and Gate 5 (waits for the author's ruling on the §0.4(b) bridge-rule reading, or registration of the bonding-mode premise at its source).

---

*Badges freeze on the sealing of this file (§10.4). Nothing after this step — not unblinding, not the charter-integrity audit, not report assembly — may change a badge; a badge change after freezing is a new trial, not an edit.*
