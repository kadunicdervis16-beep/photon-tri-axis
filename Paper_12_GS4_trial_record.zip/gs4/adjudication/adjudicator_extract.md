# ADJUDICATOR PROTOCOL EXTRACT (spec sections 9, 10.1, 10.3, 10.4, 14 -- verbatim)

## 9. Evidence standard, verdict rules, and the five categories

### 9.1 Attack record (required fields, every attack)

Attack ID and target claim; exact target text and location (section and
line in the frozen paper); claim domain and required property; source files
used with verified hashes; method and complete test space; the executable
program and inputs wherever computation is involved; output and logs; for
a proposed BROKE, the independent second route (§9.3); a five-part coverage
map — **(1) native domain, (2) verified domain, (3) the map between them,
(4) what the map preserves, (5) what stays outside the check**; the
finding's category under §9.5 (self-classified by the filing examiner,
verified by the adjudicator); proposed badge and reason. No count is
accepted without its producing artifact; no hash without independent
recomputation; no source is marked READ unless the examiner actually
inspected it; a missing source is a coverage boundary, not evidence against
a claim, unless the paper asserts the source is present.

### 9.2 Verdicts (claim status)

- **HELD** — independently reconstructed or reproduced over the stated
  domain; no counterexample found within that verified domain. Never means
  physically true.
- **BROKE** — a reproducible witness or logical contradiction against the
  claim as written, all preconditions satisfied, second route confirming.
- **LIMIT** — evidence supports only a proper subset of the stated domain,
  or the claim cannot be decided at the available scope; the exact boundary
  is named.
- **OUTSIDE** — the tested property is not asserted by the target claim.

Verdicts are never summed into a score or percentage; one broken
load-bearing claim is not cancelled by any number of held bookkeeping
checks.

### 9.3 Second-route rule

Every BROKE requires reproduction by a route independent of the first: a
different implementation, an analytic derivation, or a direct textual
witness pair (home vs registry, script block vs script block) verifiable
by inspection. The adjudicator checks the second route exists and is
genuinely independent before sustaining; a single-route BROKE is
downgraded to LIMIT with the reason recorded.

### 9.4 Process status (kept separate from claim status, always)

`READ / NOT READ`, `RUN / NOT RUN`, `REPRODUCED / NOT REPRODUCED`,
`SOURCE-VERIFIED / SOURCE-REPORTED`, `SEALED / UNSEALED`. NOT RUN is a
process status, never a badge. No report may let a process word do a
verdict's work or a verdict do a process word's work. **Neither an
examiner's confidence nor an arm's identity is evidence** (§10.1).

### 9.5 The framework-translation classification — five categories, never merged

*(Refinement from GPT-6's review of the two-arm design, adopted by the
author.)* Every finding filed by either arm — every Arm H objection and,
for symmetry, every Arm N finding — must be classified into **exactly one**
of five categories. The categories must not be merged, averaged, or
blended:

- **(A)** A genuine contradiction under MSDS's own rules.
- **(B)** A missing derivation required by a claim.
- **(C)** An unestablished bridge from the discrete mathematics to physical
  measurement.
- **(D)** A disagreement over mathematical foundations or ontology.
- **(E)** A question the paper explicitly leaves open.

**Badge mapping (binding):**

| Category | Can it sustain a BROKE against a claim as written? | Disposition |
|---|---|---|
| A | **Yes** — with witness and second route (§9.3) | Defect; author's list |
| B | **Yes** — where the claim asserts the establishment the missing derivation was required for | Defect; author's list |
| C | **No** | Bridge verdict: LIMIT or OUTSIDE, per the target claim's own Stage discipline (a native claim that asserts no bridge cannot be broken by the bridge's absence; a Stage P claim that asserts one is judged by what it asserts) |
| D | **No — never a defect** | Recorded as a framework disagreement |
| E | **No — never a defect** | Recorded as an open question the paper itself declares |

The filing examiner self-classifies; **the adjudicator verifies the
category as part of adjudication** (§10.3). A mis-categorized finding is
re-categorized **in the open**: the adjudication record prints the original
category, the corrected category, and the reason. Category verification is
not a courtesy check — most hostile-arm volume is expected to arrive as
category D in substance, and the record must show the sorting, finding by
finding.

---


### 10.1 The rule

The adjudicator examines every alleged failure **without seeing which
agent or arm produced it**. Neither the gatekeeper's confidence nor the
defenders' confidence may function as evidence; neither may an arm's
reputation, an examiner's fluency, or the volume of an arm's filings.


### 10.3 The adjudicator's work

One adjudicator, spawned fresh, who ran no attack. Working only from the
anonymized cards, the frozen paper (full, unblinded), and the mutation
log, the adjudicator, for each card: (i) verifies the category (§9.5) and
re-categorizes in the open where wrong; (ii) applies the single evidence
standard of §9 (coverage map present and honest; witness complete;
second route present and independent for any BROKE); (iii) assigns the
adjudicated badge; (iv) records the evidence that sustained or defeated
the finding, quoting the argument where its exact wording matters. The
adjudicator applies the **strict rule in reverse**: a finding that fails
the three-part test of §3 (exact claim / requirement of the claim /
failure under declared premises) is category D in substance whatever its
self-classification, and is recorded as such.

### 10.4 Freezing the badges

The adjudicator's output, `gs4/adjudication/GS4_ADJUDICATION_BLIND.md`
(per-card: key, verified category, badge, evidence), is hashed and sealed.
**Badges are frozen at this moment.** Nothing after this step — not
unblinding, not the charter-integrity audit, not report assembly — may
change a badge. A badge change after freezing is a new trial, not an edit.


## 14. Acceptance gates

Assessed by the adjudicator from the anonymized evidence where a gate
concerns findings, and completed after unblinding where a gate concerns
attribution (Gate 3's discrepancy record, the charter-integrity input to
Gate 4). A gate is marked PASS, FAIL, or NOT DECIDED (with the deciding
evidence named) — never inferred from another gate.

| Gate | Test | Evidence owned by |
|---|---|---|
| 1 — Identity | Frozen release, hashes, source versions, environment independently verified | Role D (both arms) |
| 2 — Reconstruction | Native definitions and selected load-bearing derivations reconstructed without private author knowledge | Roles A, B (both arms) |
| 3 — Badge honesty | Blind classifications match the paper's evidence, or every discrepancy is resolved and recorded | Role C (both arms) + adjudicator |
| 4 — Computational independence | Selected machine results reproduce through second implementations (including the divergent-reading K comparison, §6.2); mutation tests show the controls can fail when expected | Role D (both arms) + mutation log |
| 5 — Dependency integrity | Sampled claim graphs have no omitted load-bearing dependencies; no claim outranks its weakest dependency | Role C (GS4-C, both arms) |
| 6 — Change integrity | Sampled changes trace old text → new text, with corresponding tests and dispositions | Role C (GS4-H, both arms) |
| 7 — Falsification reach | An independent-context reader can identify a real falsifier for every selected Level A claim, or the paper explicitly names the boundary where none is available | Roles A, C (both arms) |
| 8 — Physical separation | No native or computational pass is presented as experimental confirmation without an independent physical bridge and a discriminating observation | Roles A (GS4-I/J, both arms) + adjudicator |

Per-arm readings are recorded where a gate's evidence differs by arm; the
joint assessment closes the gate table. Passing Gates 1–7 with Gate 8 open
is the expected maximum outcome of this trial and is reported as exactly
that.

---

