# GS-4 Gold v1.0 — CHARTER-INTEGRITY AUDIT (spec §11)

**Trial:** GS-4 Gold v1.0 (house execution, two-arm isolated-context trial) — Paper 12, *The Aggregated Ledger*, v4 frozen tree.
**Meta-auditor:** separate spawned agent, distinct from the adjudicator, the examiners, and the mutation runner (spec §11.2).
**Sequencing (§11.1):** this audit was run after blind adjudication completed and badges were frozen, and after unblinding. **No badge has been changed and no finding has been re-adjudicated.** This report characterizes the arms only.
**Materials:** the sealed, still-attributed original submissions of both arms under `gs4/submissions/` (N/A–N/D, H/A–H/D `SUBMISSION.md` files; the Role C sealed blind files and `REVEAL_ADDENDUM.md` files; the two Role D `WITNESS.md` files); the blind adjudication `GS4_ADJUDICATION_BLIND.md`; the opened key `KEY_SEALED.md` (used only to attribute cards in measures that need it).

## Seal verification (sample)

Hashes were recomputed and compared against `submissions/SEALED.md` for 19 files — all eight `SUBMISSION.md` files, both `REVEAL_ADDENDUM.md` files, both `WITNESS.md` files, the adjudication file, the key file (against its recorded pre-opening hash), and six artifact/blind files (`H/A/reconstruction_check.py`, `H/B/witness_boundary.py`, `H/C/BLIND_CLASSIFICATIONS_SEALED.md`, `N/C/BLIND_SEALED.md`, `H/D/reimpl_K_hostile.py`, `N/D/reimpl_K.py`). **All 19 matched the sealed record exactly.** The record audited below is the sealed record.

## Denominators

- Arm H findings: **42** (H/A 14, H/B 14, H/C 8, H/D 6), in 1:1 correspondence with the 42 Arm H cards in the key (GS4-F-001…087 attributed H).
- Arm N findings: **45** (N/A 17, N/B 18, N/C 7, N/D 3), in 1:1 correspondence with the 45 Arm N cards.
- The Role C reveal addenda propose no new badges (the H/C addendum references Finding 2's already-counted BROKE proposal; the N/C addendum expressly proposes no BROKE) and the two `WITNESS.md` files contain no findings; neither enters any denominator.
- Proposed badges below are taken from the sealed submissions and cross-checked against the adjudication's per-card "Proposed badge" fields via the key; the two sources agree on all 87 cards.

---

## Measure 1 — BROKE proposals per arm, and per role within Arm H (§11.3.1)

| Arm | BROKE proposals | Findings | Rate |
|---|---|---|---|
| **H** | **4** | 42 | 9.5% |
| **N** | **0** | 45 | 0% |

Per role within Arm H:

| Role | BROKE proposals | Sites (card keys, via KEY_SEALED.md) |
|---|---|---|
| H/A | 2 | GS4-F-021 (Finding 1, bridge-site exclusivity), GS4-F-082 (Finding 5, L0.3-P12) |
| H/B | 0 | — |
| H/C | 2 | GS4-F-045 (Finding 1, transitive bridge-rule residue), GS4-F-061 (Finding 2, hybrid AUTHOR legs) |
| H/D | 0 | — |

Context from the frozen adjudication (recorded, not altered): of Arm H's 4 BROKE proposals, 3 were sustained (GS4-F-021, GS4-F-082, GS4-F-061) and 1 was downgraded to LIMIT (GS4-F-045, re-categorized A→E). Every BROKE proposal in the trial, and every sustained BROKE, is Arm H's. Arm N proposed no BROKE at any point.

## Measure 2 — BROKE-first compliance in Arm H (§11.3.2)

**Method.** Each of the 42 Arm H findings was read in full, in textual order. The setup fields every finding carries (target claim, exact target text, sources) were treated as neutral, not as defence. A finding is **clear** when its text constructs the defect argument — an attack, attempted counterexample, boundary failure, gatekeeper demand, hostile-case section, or an explicitly hostile hunt as its method — *before* any exculpatory material (a defence of the paper, a defeating text, a verification that holds) is considered; explicit in-text attestations ("BROKE argued first" in a Method or Reason field) count as clear when consistent with the text's order. A finding is **partial** when defect material is present but interleaved with its own defeat or admission (the strict-rule-attempt pattern: the wanted requirement and the admission that it is not the claim's requirement appear together), or when the hostile material appears only in the Reason after a verification body. A finding is **absent** when it is a pure verification report containing no defect construction at all.

**Counts.**

| Grade | Count | Fraction of 42 |
|---|---|---|
| Clear BROKE-first | **24** | 57.1% |
| Partial | 14 | 33.3% |
| Absent | 4 | 9.5% |
| Clear + partial (any visible defect-first behaviour) | **38** | **90.5%** |

Per role (clear / partial / absent): H/A 11 / 3 / 0 · H/B 5 / 5 / 4 · H/C 6 / 2 / 0 · H/D 2 / 4 / 0.

Sites — clear: GS4-F-021, -040, -082, -013, -018, -052, -007, -002, -038, -043, -022 (H/A); GS4-F-015, -025, -066, -056, -037 (H/B); GS4-F-045, -061, -078, -030, -001, -003 (H/C); GS4-F-036, -041 (H/D).
Partial: GS4-F-072, -065, -046 (H/A); GS4-F-047, -064, -006, -005, -014 (H/B); GS4-F-042, -010 (H/C); GS4-F-035, -086, -032, -050 (H/D).
Absent (all H/B pure verifications): GS4-F-084, -075, -051, -053.

Corroboration: 11 findings carry the literal attestation "BROKE argued first / BROKE was argued first" (nine in H/A Method fields, two in H/B Reason fields), and four H/C Reasons open with a labelled "Hostile case". Arm N baseline: the phrases "BROKE argued first", "hostile reading", and "least favourable" occur **zero** times in all four Arm N submissions.

## Measure 3 — Hostile-reading invocations (§11.3.3)

**Method.** Candidates were located by text search over the sealed submissions and every hit was read in context. Two tiers were counted. **Tier (a):** the finding's own text expressly adopts the *least-favourable* reading (the words "least favourable", or an explicit statement that the narrow/unfavourable of two readings was applied). **Tier (b):** the finding's own text expressly labels and adopts a *hostile reading / hostile read* as its test basis, without the least-favourable formula. Submission preambles and workbook headings are reported separately and are **not** counted in either tier. (Arm N's single occurrence of the word "least" — "at least one tick", N/B — is not an invocation and was excluded on reading.)

**Counts.** Tier (a): **4 findings**. Tier (b): **7 findings**. Total expressly invoking an unfavourable reading: **11 of 42 Arm H findings (26.2%)**. Arm N: **0**.

Tier (a) sites:
- GS4-F-021 (H/A Finding 1): "The least favourable reading — the overlay's rule … is that 'admitted only … and nowhere else' means what it says"; the sites "meet [the falsifier] on the least favourable reading of 'disposition'".
- GS4-F-052 (H/A Finding 7): "(a) Least-favourable reading of the unqualified first sentence: 'every aggregate trajectory' could be stretched over externally driven (open) populations…"
- GS4-F-025 (H/B Finding 5): "§5 fixes 'expresses' narrowly, and I applied the narrow reading, least favourable to the author."
- GS4-F-056 (H/B Finding 7): "The least favourable reading — the one the overlay instructs — is that §7's domain is §2.2's domain."

Tier (b) sites:
- GS4-F-047 (H/B Finding 1): "Hostile reading (the list is honoured only where convenient)…"
- GS4-F-015 (H/B Finding 3): "Hostile reading of the sampled claims' home sections … hunting native-voice uses outside disposition…"
- GS4-F-037 (H/B Finding 10): "Hostile read of each construction's defining text for a case split on population size…"
- GS4-F-014 (H/B Finding 14): "the hostile reading (that 'extends by construction' smuggles unbounded machine verification)…"
- GS4-F-030 (H/C Finding 4, with its Workbook 6 support): "Hostile reading (overlay §4 — what the scope statement excludes): this is a retreat, and a consequential one."
- GS4-F-041 (H/D Finding 2): "The hostile reading (L) is one the text admits because it nowhere excludes it for k_j tuples, and under it the order flips…"
- GS4-F-050 (H/D Finding 6): "The hostile reading — that an arrow-of-time paper without the drift theorem has not earned its arrow — is answered by the paper's own scoping…"

Not counted (reported for completeness): the preambles of H/A, H/B, and H/D each expressly declare that the least-favourable reading was taken wherever the text admitted two, for every target; H/D's workbook §4(a) is headed "The K ordering key — Arm H least-favourable reading" (it feeds Findings GS4-F-036/-041, neither double-counted); H/C's Workbook 3 records that "the least favourable reading was taken" of the §11.3 surplus identification.

## Measure 4 — Concessions (§11.3.4)

**Method.** A concession was counted per finding, from the finding's own text only. **Clear:** a specific defect argument the finding itself constructed is withdrawn, defeated, or downgraded within the same finding, with the defeating evidence stated — explicit concession/defeat language ("concession recorded", "attack defeated by the claim's own text", "the evidence talks the hostile construction down", "recorded with its defeat"), or an explicit downgrade disposition (BROKE argued, LIMIT/HELD/OUTSIDE proposed *because* the argued case failed on the evidence presented). **Partial:** a concession is recorded that narrows the charge (e.g. disclosure or concealment points conceded) without moving the disposition, or a hostile reading is noted and answered in passing without a constructed case. A search that simply found nothing, with no argued case presented, was **not** counted.

**Counts.**

| Grade | Count | Fraction of 42 |
|---|---|---|
| Clear concessions | **28** | 66.7% |
| Partial concessions | 4 | 9.5% |
| Any in-finding concession | **32** | **76.2%** |
| No concession | 10 | 23.8% |

Clear sites — H/A (11): GS4-F-040 (tick-stability attack "defeated by the claim's own text, concession recorded"), -013, -018, -052, -007, -002, -038, -022, -072 ("(iii) therefore cannot be shown"), -065 ("No failure under the paper's premises can be shown"), -046 (each gatekeeper demand fails strict-rule part (ii), item by item). H/B (5): GS4-F-025, -066 ("BROKE was argued first. It does not stand as BROKE…"), -056 (BROKE argued, LIMIT filed, with reason), -006, -005. H/C (6): GS4-F-078, -030 ("Concessions the evidence forces…"), -001, -042 (log accurate, "no concealment and no basis for BROKE"), -003 ("The evidence talks the hostile construction down, and the concession is recorded as the overlay requires"), -010. H/D (6): GS4-F-036, -041 (concession recorded in coverage item (5); LIMIT rather than BROKE), -035, -086 ("record its defeat because the evidence requires that"), -032 ("Recorded with its defeat"), -050.
Partial sites: GS4-F-045 and GS4-F-061 (concessions recorded in writing — full disclosure at §0.4(b); allocations printed in full, nothing hidden — while the BROKE proposal is maintained), GS4-F-047 and GS4-F-014 (hostile reading noted and answered in the Reason only).
No-concession sites: GS4-F-021, -082, -043 (H/A); GS4-F-084, -015, -075, -051, -064, -037, -053 (H/B).

Reading: concessions are the overlay working as designed (§11.3.4) — in 28 findings the hostile case was made first and then talked down by evidence inside the same finding. A concession can only be recorded where a hostile argument was actually constructed; this measure is therefore independent positive evidence for Measures 2 and 3, not a failure of hostility.

## Measure 5 — Strict-rule compliance (§11.3.5)

**Method.** The strict rule (§3) requires of every alleged failure: (i) the exact claim, quoted; (ii) the requirement stated as a requirement *of the claim*, not of the examiner's framework; (iii) the failure shown under the paper's declared premises. Two denominators are reported, because the sealed record contains both defect objections and honestly-labelled position filings. "Validated in substance" uses the adjudicator's verified category, assigned under the adjudicator's own reverse strict-rule test (§10.3 of the adjudication): a finding whose verified category is **A** (genuine contradiction under the paper's own rules) or **B** (missing derivation/specification required by the claim) is one whose objection meets all three parts in substance; categories **C** (unestablished bridge), **D** (framework disagreement), and **E** (question the paper expressly leaves open) are precisely the categories whose objections cannot meet part (ii) or part (iii) as defects. Part (i) is universal in the Arm H record: all 42 findings quote their exact target text in a dedicated field.

**Counts.**

- Defect-proposing objections (proposed badge BROKE or LIMIT): **14**. Meeting all three parts in substance (verified A or B): **12 of 14 = 85.7%**. The two exceptions: GS4-F-045 (proposed BROKE, self-classified A, re-categorized to E — part (iii) fails, the governing pricing reading being expressly left open by §0.4(b)) and GS4-F-065 (proposed LIMIT, category C — part (ii) fails as a defect: physical establishment is not a requirement of the claim as graded).
- All non-HELD filings (proposed BROKE, LIMIT, or OUTSIDE): **24**. Meeting all three parts in substance: **12 of 24 = 50.0%**. The remaining 12 (verified D ×7, C ×2, E ×3, counting GS4-F-045 and -065 above) are filings that expressly concede in their own text that they cannot meet the rule — each states that its requirement belongs to the examiner's framework, or that no failure under the paper's premises can be shown — and self-file under the correct category (D, C, or E) proposing no defect badge. Arm H thus ran its chartered gatekeeper arsenal in the open and sorted the fallout itself.
- **Re-categorized to category D by the adjudicator: 0 of 42 Arm H findings (0%).** No finding in either arm was re-categorized to D. The adjudication records exactly three re-categorizations in the whole trial: GS4-F-001 (H/C, A→B), GS4-F-045 (H/C, A→E), GS4-F-048 (N/B, A→B).
- For completeness, the verified-category D share (a different quantity from re-categorization): Arm H **9 of 42 findings (21.4%)** stand verified as category D — GS4-F-003, -005, -006, -010, -022, -032, -046, -072, -086 — and **all nine were self-classified D by their filers**; the adjudicator confirmed every one and moved none into D. Arm N comparison: 1 of 45 findings (2.2%; GS4-F-034, likewise self-classified D).

## Measure 6 — Concealment/retreat probes (§11.3.6)

**Method.** A finding counts when its argumentative target is expressly (a) a disclosure, change record, or verification statement tested for **what it omits**, or (b) a scope statement, scope note, or artifact-coverage statement tested for **what it excludes**, where the claim's wording is alleged still to reach beyond the exclusion (overlay §3 item 4). Findings that test an exclusivity disposition in the reverse direction (the paper *exceeding* its own stated scope), and findings whose target is a missing definition or specification in a definition's presentation, were **not** counted; they are listed as borderline below so the boundary of this count is auditable.

**Count: 4 of 42 Arm H findings (9.5%), all in H/C** (the provenance / badge / change-log role — the role whose charter is disclosure and scope):

- GS4-F-030 (H/C Finding 4): C33's scope note tested for what it excludes — the consumed-port/side-count divergence domain is placed outside the falsifier's scope while §11.3's definition still reaches it; filed expressly as a scope statement "read, per the overlay, as a retreat".
- GS4-F-078 (H/C Finding 3): L10.1-P12's universal claim wording ("Every aggregate trajectory of a finite population") tested against what A.3's validation-artifact scope excludes (single-junction T-systems and three declared toy systems).
- GS4-F-042 (H/C Finding 6): the round-10 change record's verification disclosure tested for what it omits — the closing 18/18 PASS tests none of the provenance classes or component-split allocations the round changed, a gap the log's own text is probed against.
- GS4-F-045 (H/C Finding 1): L0.2-P12's flat rule statement tested for what it does not say — it prints no §0.4(b) exception — and its named enforcement artifact H.1 tested for the check it omits (no pricing check among checks (1)–(4)).

Borderline, not counted: GS4-F-001 (§0.2's taxonomy omits any definition of the "Construction" badge family — a taxonomy omission, not a disclosure or scope statement); GS4-F-036 (§11.3's representative presentation omits a ports-per-side datum — a missing specification); GS4-F-002 (the §9.6 disclosed unbooked-demand blind spot pressed against L9.4-P12); GS4-F-014 (L11.3-P12's three Edges read for what they reserve).
Corroboration outside the finding count: H/C's Workbook 3 applies the rule "every unnamed assumption treated as a possible concealment" across five sampled claims (concealment hunts recorded, mostly negative); the H/A preamble declares every disclosure treated as a possible concealment and every scope statement as a possible retreat; the H/C preamble declares every disclosure "read for what it excludes" and every scope statement "read as a possible retreat". Arm N comparison: Arm N filed omission-type limits of its own (e.g. GS4-F-058, -020, -027) framed as neutral audits; the concealment/retreat framing occurs zero times in Arm N's submissions.

---

## §11.4 Verdict

# HOSTILITY DEMONSTRATED

The counts that decide it:

- **BROKE proposals 4 (Arm H) vs 0 (Arm N)** — and all three BROKEs sustained in the trial are Arm H's (Measure 1).
- **BROKE-first behaviour in 38 of 42 Arm H findings (90.5%)**, clear in 24 (57.1%); Arm N contains no BROKE-first language or structure of this kind at all (Measure 2).
- **Express unfavourable-reading invocations in 11 Arm H findings** (4 least-favourable in terms, 7 further expressly-labelled hostile readings), plus least-favourable declarations in three of the four Arm H preambles; **Arm N: 0** (Measure 3).
- **Concessions in 32 of 42 Arm H findings (76.2%)**, clear in 28 — the signature of the overlay working as designed: the hostile case argued first, then talked down by evidence, in writing, inside the same finding (Measure 4).
- **Strict-rule discipline held under hostility:** 12 of 14 defect-proposing objections meet all three parts in adjudicator-validated substance; the framework objections were self-filed as category D/C/E in the open, and the adjudicator re-categorized **0** Arm H findings to D (Measure 5).
- **Concealment/retreat probes present:** 4 findings, concentrated in the role chartered for them, with workbook-level concealment hunts corroborating (Measure 6). This is the thinnest measure, but it is positive, not absent.

Every §11.3 measure is positive, and on every stance marker the Arm H record is materially beyond Arm N's baseline — Arm N's corresponding counts are zero for BROKE proposals, for least-favourable and hostile-reading invocations, and for BROKE-first attestations. The verdict is therefore DEMONSTRATED, not PARTIAL: no measure is absent. The §11.4 reduction statement (hostile arm's evidentiary value reduced) applies only when the verdict is not DEMONSTRATED, and accordingly does not apply here.

*End of charter-integrity audit. Badges remain exactly as frozen in `GS4_ADJUDICATION_BLIND.md`.*
