GS4-B CLASSIFICATION PACKET
Twelve claims are reproduced below with their statements, dependency
statements, and the coverage statements of the scripts they name.
Classify each claim under the paper's own epistemic-status definitions
(protocol extract, sections 1 and 9), using only what is printed here.

======================================================================
CLAIM L11.4-P12

Statement and dependency text:
Population ordering key K (§11.3): total preorder on declared populations, name-invariant, computed from ledger data alone; tick-stability exact (Ntot, Ss, Su, Btot, CenSig invariant; Res and Tau0 not, sharpness witness printed by A.14); on the representatives constructed at §11.3 it agrees with Paper 11 §12.1's ordering at every step, each step at its named component, no paper-silent value consulted. Component split — MACHINE (A.14): the key's computation and behaviour over A.14's enumerated domains; witnesses W1/W4 re-verified; mutants rejected. AUTHOR: the definition itself (author's ruling, 2026-10-28); the native representative construction over Paper 2 §§11.4–11.5's surplus differentia, under §11.3's declared identification; the general order properties as §11.3's finite-arithmetic reading of the definition, A.14's enumeration corroborating; and the general tick-stability theorem, carried by §11.3's prose proof under §4's stated dynamics (§4 states no tick-dynamics for body records' (N, Σs², Σu)), A.14's enumeration corroborating over its enumerated domains Population ordering key K (§11.3): total preorder on declared populations, name-invariant, computed from ledger data alone; tick-stability exact (Ntot, Ss, Su, Btot, CenSig invariant; Res and Tau0 not, sharpness witness printed by A.14); on the representatives constructed at §11.3 it agrees with Paper 11 §12.1's ordering at every step, each step at its named component, no paper-silent value consulted. Component split — MACHINE (A.14): the key's computation and behaviour over A.14's enumerated domains; witnesses W1/W4 re-verified; mutants rejected. AUTHOR: the definition itself (author's ruling, 2026-10-28); the native representative construction over Paper 2 §§11.4–11.5's surplus differentia, under §11.3's declared identification; the general order properties as §11.3's finite-arithmetic reading of the definition, A.14's enumeration corroborating; and the general tick-stability theorem, carried by §11.3's prose proof under §4's stated dynamics (§4 states no tick-dynamics for body records' (N, Σs², Σu)), A.14's enumeration corroborating over its enumerated domains

Named script: A.14
Named script's printed coverage statement (provenance block):
INPUT_PROVENANCE:   - T, tau, admissibility (A = -B != 0, canonical-first):     class=cited-paper (Paper 11 §7.5, as restated in Paper 12     §4; the same conventions as scripts A.2/A.10/A.12). - The boundary formula B = 6N - sum_j k_j and the count vector:     class=cited-paper (Paper 11 §4.1 via Paper 12 §§3.1-3.2). The k_j multiset is read from the side count, as THE MAP     states: class=paper-defined (disclosed reading, as in A.12). - Standings (Definition 5.7) where the named-pair exhibit uses     them: class=paper-defined (Paper 12 §5). - The key's component order and the Res reading:     class=paper-defined (Paper 12 §11.3, on the author's ruling     of 2026-10-28). - The F1 family's fixed body data (N = 1, Ss = 0, Su = 0) and     the sample seeds: class=control (declared controls isolating     sigma behaviour; seeds fixed and printed at run time). """

======================================================================
CLAIM L7.3-P12

Statement and dependency text:
- **L7.3-P12** — D(P, W) (7.3) is an exact rational; for |P| = 1 it   reduces to Paper 9's §4 definition at the single body, and over a   shared window it equals the mean of the local densities (7.4). Component split — MACHINE (A.6): the (7.4) mean-of-locals identity on the exhibited window and the worked example's arithmetic; AUTHOR: the (7.4) identity in general, carried by §7.3's prose (exact rational arithmetic over the shared denominator |W|); D(P, W)'s exact rationality in general, carried by §7's prose (immediate from (7.3) as a ratio of two integer counts; A.6 verifies it on the exhibited window); and the identification of D's |P| = 1 case with Paper 9 §4's verbal definition. D(P, W) (eq. 7.3) is an exact rational; for a one-body population it reduces to Paper 9's §4 definition at the single body, and over a shared window it equals the mean of the local densities (eq. 7.4). Component split — MACHINE (A.6): the (7.4) mean-of-locals identity on the exhibited window and the worked example's arithmetic; AUTHOR: the (7.4) identity in general, carried by §7.3's prose (exact rational arithmetic over the shared denominator | W | ); D(P, W)'s exact rationality in general, carried by §7's prose (immediate from (7.3) as a ratio of two integer counts; A.6 verifies it on the exhibited window); and the identification of D's one-body case with Paper 9 §4's verbal definition.

Named script: A.6
Named script's printed coverage statement (provenance block):
INPUT_PROVENANCE:   - §7.5 and §9.5 table cells, §7.2 worked-tick inputs, §9.3 flow     counts: class=paper-defined (Paper 12 DRAFT_C, staging_v1 — the     oracle under test; parsed from the draft file at run time). ASSEMBLY ADJUSTMENT (2026-10-24, disclosed): the oracle file is now chosen at import — with no argument, the assembled paper (staging_v1/Paper_12_v1.md, which carries §§7/9 verbatim); with "--drafts", the original oracle DRAFT_C_s7-9.md; with any other argument, that file. The checks are untouched. V2 ADJUSTMENT (2026-10-25, disclosed): the default oracle file is now the v2 assembly (staging_v3/Paper_12_v2.md), which carries the §§7/9 worked passages verbatim from v1. The checks are untouched. V2 EXTRACTION REPAIR (2026-10-25, disclosed): the §7.5 and §9.5 table selections were document-global — the LAST table in the file whose header matched the signature won. That was safe while the §7.5/§9.5 tables were the last of their signatures; Appendix D's same-signature tables (a "tick" reconcile table, a "junction" tick table) silently hijacked both selections and A.6 failed on the v2 assembly. Selection is now scoped to the §7.5 and §9.5 section spans — the tables this header always named ("the §7.5 reconcile table, the §9.5 junction-demand table"). No check, oracle pattern, or recomputation changed; the v1 assembly still passes under the repair (verified at the repair), so the verified domain did not move. - N_total = 100 CU, N_id = 3, C_exec = 97, eqs. (2.2a)/(2.2c)/(2.4):     class=cited-paper (Paper 10 §2.2; paper10.txt L933–985). - S(d) = s²_node/N(d), N(d) = 4d²+2, eq. (2.6): class=cited-paper     (Paper 10 §2.2 eq. 2.6, §2.4.1, §2.4.7 eq. 2.7). - Shell points counted by direct ℤ³ enumeration in this script:     class=paper-defined (independent oracle; no input from the draft). V4 NOTE (2026-10-26, disclosed): default paper target is now the v4 assembly; no check logic changed. """

======================================================================
CLAIM L0.3-P12

Statement and dependency text:
- **L0.3-P12** — The construction list above fixes, for each word locked by Paper 11 §0.5, its sole permitted route into this paper; any use of a locked word outside its listed disposition is a defect against this section, swept by FW.1. The §0.5 construction list fixes each word locked by Paper 11 §0.5 to its sole permitted route into this paper

Named script: —

======================================================================
CLAIM L11.2-P12

Statement and dependency text:
Size-invariance of the §§3–5 and §7 constructions across the enumerated population range: same definitions, identities checked across population sizes 1–12, no size-triggered branch Size-invariance of the §§3–5 and §7 constructions across the enumerated population range: same definitions, identities checked across population sizes 1–12, no size-triggered branch

Named script: A.1, A.2, A.6

======================================================================
CLAIM L11.3-P12

Statement and dependency text:


Named script: —

======================================================================
CLAIM L5.4-P12

Statement and dependency text:
- **L5.4-P12** — The sampling-measure postulate pre-registered in Paper   11.5 §11.6 is unnecessary: long-run frequencies resolve to orbit   counts, the single-tick "ensemble" resolves to the census, the fill   rules resolve to the deterministic dynamics, and named-tuple joint   frequencies resolve to joint counts over the named members' records   (Definition 5.8, added in v4 after falsification condition C32 fired   against this claim's v3 form — the firing record stands at §12). The   debt is discharged by dissolution over the extended instrument family   (census, flow, joint counts), with no postulate adopted. The sampling-measure postulate pre-registered in Paper 11.5 §11.6 is unnecessary and is not adopted; the debt is discharged by dissolution over the extended instrument family (census, flow, and joint counts — §5 as extended in v4 after C32 fired against the v3 form; firing record at §12)

Named script: —

======================================================================
CLAIM L8.10-P12

Statement and dependency text:
- **L8.10-P12** — Conjecture, stated as a target (§8.6): a proof of   the open joint would need a statement over Proposition 5.3's orbit   structure, coupling the acting-junction structure of T_agg steps to   the assignment counts of the records they produce — a statement   about rest records, in relational form: a characterisation, for a   given population, of the records its own junction structure permits   it to rest at; whether a population's rest record is maximal is a   property of that population, and no universal balance is claimed. (The strong form — rest only at (E2)-maximal records — is already   refuted inside this paper.) If the joint is underivable in general,   the arrow stands as a boundary-condition fact inherited from   Paper 9's received asymmetry, and §9's predicate as a construction   with no approach content. The joint itself is not claimed. Conjecture (§8.6): a proof of the open joint would need a statement over Proposition 5.3's orbit structure coupling acting junctions to assignment-count changes — about rest records, in relational form: a characterisation, per population, of the records its own junction structure permits it to rest at, maximality being population-relative and no universal balance claimed; if underivable in general, the arrow is a boundary-condition fact and §9's predicate a construction with no approach content; the joint is not claimed

Named script: —

======================================================================
CLAIM L9.4-P12

Statement and dependency text:
- **L9.4-P12** — The saturation census J_sat(τ), the saturation   fraction, and regime change (a tick where J_sat changes) are exact   counts/ratios built by summation over Paper 9 §6's local saturation   behaviour, with per-junction capacity and demanded load from the   junction's own entries under Paper 10 eq. (2.4) — relayed work   entering only as executed inside a junction's own scan   allocation; Paper 10 §2.4.7's partition is cited in its   single-source, isotropic form only, and no sum of its shares   over sources is formed at any junction (anisotropic corrections   remain Paper 23's). The Threshold is cited   to Paper 7 and not redefined; its exact point is Paper 14's. The saturation census J_sat(τ), the saturation fraction, and regime change (a tick where J_sat changes) are exact counts/ratios summed over Paper 9 §6's local saturation behaviour, capacity and demanded load from the junction's own entries under Paper 10 eq. (2.4) — relayed work entering only as executed inside a junction's own scan allocation; Paper 10 §2.4.7's partition cited in its single-source, isotropic form only, no sum of its shares over sources formed at any junction; the Threshold is cited to Paper 7 and not redefined, its exact point Paper 14's

Named script: —

======================================================================
CLAIM L6.2-P12

Statement and dependency text:
- **L6.2-P12** — Equal presented-count profiles at a tick imply equal   capabilities at that tick, for every role and encounter kind:   capability factors through the presented-count profile. Equal presented-count profiles at a tick imply equal capabilities at that tick, for every role and encounter kind: capability factors through the presented-count profile

Named script: A.4
Named script's printed coverage statement (provenance block):
INPUT_PROVENANCE:   - Aggregates (a), (b), (c) — node states, junction tables, B values:     class=cited-paper (Paper 11 Appendix B.1/B.2/B.3; F.33/F.34/F.35     document the same constructions; B recomputed here from     B = 6N - sum(k_j), Paper 11 §4.1). - Outcome factors through M = (n+, n-): class=cited-paper     (Paper 11 §8.6 — the theorem's one premise, inherited). - Outcome rules 1 and 2 (below): class=arbitrary-representative     (two disagreeing members of the profile-factoring class §8.6     licenses; the claim checked is rule-independent within the class). - Test taxonomy (profiles with e+ + e- <= 4): class=control     (declared finite test set standing in for §8's taxonomy). - Interior variation axes (labels, tags, histories, port indices):     class=control (constructed variation; none of it is framework     data — that is the point of the probe). - Roles {responder, initiator, spin-presenter}: responder/initiator     are Paper 11's relational active/passive roles read off the     encounter (class=cited-paper, Paper 11 role taxonomy);     spin-presenter is the §6.3 worked case (class=paper-defined,     Paper 12 §6.3: the encounter kinds whose profiles complete the     spin-presentation outcome class — here, purely complementary     encounters with at least one complementary pair and no same-sign     overlap). """

======================================================================
CLAIM L1.2-P12

Statement and dependency text:
- **L1.2-P12** — The count→weight debt is as quoted at §1.2, including its two named items and the fill rules. **** (Paper 11.5 v26 §§11.5–11.6.) The count→weight debt (Paper 11.5 §§11.5–11.6), with its two named items and the fill rules, is as quoted at §1.2

Named script: —

======================================================================
CLAIM L10.1-P12

Statement and dependency text:
Eventual periodicity of aggregate trajectories on finite populations; the pre-period/cycle decomposition (p, c) is exact counting Eventual periodicity of aggregate trajectories on finite populations; the pre-period/cycle decomposition (p, c) is exact counting

Named script: A.3
Named script's printed coverage statement (provenance block):
INPUT_PROVENANCE:   - T's rule (admissible iff A = -B != 0; zero the canonically     first admissible pair; tau = sum of squares of presented entries,     dropping by exactly 2 per action): class=cited-paper     (Paper 11 §7.5). - Port values in {-1, 0, +1}: class=cited-paper (Paper 11 §7.5 —     unit port values; the admissible pair contributes 2*a^2 = 2). - Proposition 5.3(iii) frequency form c_X / ell and §10's 1/c     per-record frequency: class=paper-defined (Paper 12 §5, §10) —     these are the PREDICTIONS UNDER TEST, computed against below,     never used as inputs to the computation. - TOY1, TOY2 transition tables: class=control (declared toy systems,     chosen to exhibit cycles of length 2 and 5 with transient tails). - TOY3 re-presentation rule: class=control (declared toy rule     layered on T; not a framework rule). - Mutant RNG seed: class=control (seeded Mersenne Twister, integer     draws only). """

======================================================================
CLAIM L2.1-P12

Statement and dependency text:
- **L2.1-P12** — The single-regime rule and the licensed aggregate list of Paper 11 §4.1 (quoted at §2.3) govern every aggregate quantity in this paper. **** — inherited. Dependencies: . Paper 11 §4.1's single-regime rule and licensed aggregate list govern every aggregate quantity in this paper

Named script: —

