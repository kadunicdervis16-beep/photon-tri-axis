# GS-4 GOLD v1.0 -- SEAL RECORD (spec section 2.4)

Hashes computed by the coordinator from the files on disk at sealing;
each matches the examiner's own emitted hash list.

## H/A -- sealed 2026-10-31T22:36Z
- SUBMISSION.md -- e5b79886e95ca4123e63480e7141483f3893e64e2676f35b8bee3877c6614533
- reconstruction_check.py -- 2160e11eac50150ce2ad5747ab513d1d0f7157f625db91926fd8e828f24950bd
- run_log.txt -- b2fe5425561e050673d25819d22a7aee7aecb7798ad1bc6ee78f7542210770e0

## H/B -- sealed 2026-10-31T22:36Z
- SUBMISSION.md -- 7b2360889b6ef24602a67202ffc6977501999bdb2f661cec656bc8392b6f4db2
- witness_boundary.py -- 0ed5af501868efa8161b288e410614a4e2442f750de1f8da83169f7a489ab6bf
- witness_alternatives.py -- 1af5d7a700253aff3658888430f640f072be47e49fb21518af87d4473d8a6af4

## N/C -- sealed 2026-10-31T22:36Z (main submission; reveal addendum to follow separately)
- SUBMISSION.md -- 86368217e12fe2208d795c327320e46e5de2eb63e5b4399f81a9e2136b926f2d
- BLIND_SEALED.md -- 988fa8396c880ced8cb7388adbb0f8982a60554e70f5f811fc4d0bca6532f63b
- repro_L73.py -- 022d395e55ba972a7a0464b355504c6287a49894cdf5078aa3f309b09c3dd0d8
- repro_L73.out -- 13b14076bf50971da04123c53e79199c18cf9c2ca065018a60c676144a29654d
- repro_L114.py -- 1a0f4a1a48d8fe86f1ed061dc8b083ed81417767d151e32426e9935abcef2384
- repro_L114.out -- 64b774122f572d312c40e698262ae6895dd959ad7274845a8f12d65ea411cc10

## H/C -- sealed 2026-10-31T22:37Z (main submission; reveal addendum to follow separately)
- SUBMISSION.md -- 870475c37aaa28cdec0de71c483b995a72899311dc6b7899913e45b3fdbfe04a
- BLIND_CLASSIFICATIONS_SEALED.md -- ef6562f464c8f7a469a023893c627e6c069461213b718e499b04ea292bc3947f
- gs4d_independent_check.py -- 899b6e30a4c4de48e50ece17f6248c80907d4d1326397ef8e40b9120ab10be06
- gs4d_independent_check_output.txt -- 0b4385e69d78e70d2d94432baca53a590b0f39410e429034f4edb5a0fc6633d9

## N/A -- sealed 2026-10-31T22:37Z
- SUBMISSION.md -- 07f116c29db2a6df3084890aec905caebc1306e82140ea12b9711e5b77755b90
- recompute.py -- 756a219e60a34c1fb453a3c0369712a79a2676783bb3fb67c5609c4bd3a7d470
- recompute_output.txt -- 46045cbd033debb8751ebae51bccc70f1ed76eca973f3e857f2c9f152e1bb86c

## N/D -- sealed 2026-10-31T22:38Z (mutation witness duty M1-M12 to follow by continuation agent)
- SUBMISSION.md -- 462feea6490be04ff307aa12e7ea883ec0536a5dc3637d37cd65e759a1815ea1
- extraction_manifest_check.txt -- a3739e0d9f014c6948d9040e4aab3839b071cb0fae686676e9c8967e9264b475
- individual_stdout_logs.txt -- f3874a013c2b5e9c6080730c25375838c12d64d9f7244d32731e676f3f4928b1
- individual_summary.json -- 7b2f49f41374fce1f854ece9268329f3e7be69e6afec2ca6ad30b4439ab01b59
- reimpl_A5.py -- 0dac625186e7db16e7835323b52d0e35436ec62850b0f1973ea271001c235b8f
- reimpl_A5_output.txt -- caa0e3ec56ea9f641ec1ed20ca42469f2de77495301d31b337bce5464e60f7fe
- reimpl_A5_stderr.txt -- e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- reimpl_K.py -- cc7f10ecb80d095e0f32c6ab630902a7aaeaaa9c8a717d683a34a51ab33a481f
- reimpl_K_output.txt -- 4e6530af4b81f048d45054cdde3530e11e6aa177c156e599dd9267b68badb045
- reimpl_K_stderr.txt -- e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- reimpl_spine_esmall.py -- 1c8377dada4498d5eaa3cd532ff8bed066eeb4c1a0b7aba87775bc8a2dd8c657
- reimpl_spine_output.txt -- 5f72f2c895e31c70717c6c21034d8e5bc9bea9d25bc23b4931483a6ac1b4ef84
- reimpl_spine_stderr.txt -- e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- run_all_stdout.txt -- e5fcdf778cbf766185ab5ff2389ccb17b978273a9a8653b8a4db5b3113e12570

## N/C REVEAL_ADDENDUM -- sealed 2026-10-31T22:39Z (continuation agent, PE-1)
- REVEAL_ADDENDUM.md -- 5c854115ee6979f10d586f8e059f8460847d701f481fc942ee787e898c0d6616
- (BLIND_SEALED.md and SUBMISSION.md re-verified unchanged at addendum sealing.)

## H/C REVEAL_ADDENDUM -- sealed 2026-10-31T22:40Z (continuation agent, PE-1)
- REVEAL_ADDENDUM.md -- cec6f7c14c5349b52fe7e3bcc556db16d8c4e8e958575f96954343f3d9b801c6
- (BLIND_CLASSIFICATIONS_SEALED.md and SUBMISSION.md re-verified unchanged at addendum sealing.)

## H/D -- sealed 2026-10-31T22:40Z (mutation witness duty M13-M24 to follow by continuation agent)
- SUBMISSION.md -- 05a114522c3ba85fac264f32b1208ed7bfe7033f18125bb1a6e03e3ec868481b
- reimpl_K_hostile.py -- 170f859951dbcdd79537a2abcc7f11c55bf097f71e1c117189aa8f971992d7da
- reimpl_K_hostile.out.txt -- c56a9e4c807c2cba4fbf1c679f1cb098d70b54abf7cc3829f0e6819467aa3c41
- reimpl_temperature.py -- 3948c21a16aab75f8991b7507e847a9924e3014785109a591badbc4792e978b9
- reimpl_temperature.out.txt -- a41619878ea1c17134955549b8d73dc1131bd685a259f1304a8cbbe0dfce9bcf
- reimpl_assignment.py -- 0b6336e1094914f7f9c891e896ea2406671d5fdaad358334c63f1b8bebe655e3
- reimpl_assignment.out.txt -- 26c858dd39ad9400f29b66676c5da451b4a4966d07be43ff3a9b909d2c57107f
- spine_regen_esmall.py -- f378509a37488c93f13e4819a33f10bebfe3a045074566ba4ef675f3e0166313
- spine_regen_esmall.out.txt -- 6e9b9167d6cb8cbc8f5bef7206d660c5ffdcb45d91d8ccf22c248b5daad69dc4
- prefix_search.py -- d0c31736e3e3d56289640e4daffa8b06f397df3d28a3e69bcff42e185db7d0e6
- prefix_search.out.txt -- cc465ed988ab895a7663c884dfda973efa292e7138c3ee6e1f5f85c1773c5177
- suite_run_all_stdout.txt -- e5fcdf778cbf766185ab5ff2389ccb17b978273a9a8653b8a4db5b3113e12570
- per_script_runs.json -- 91d189061e038ed55905667cb9e3946b9fdd1b3183ac131e2bdf7180b17e7b01

## N/B -- sealed 2026-10-31T22:42Z
- SUBMISSION.md -- 3ec180f1372ac641159718232ab6a4b88d94f5e337d6fc41bfc654b65e1a236d
- witness_boundary.py -- f2267b92e023afbc4ea574c30caa820b6a11a739584866da03003cecc141c58c
- run_log.txt -- 1775f4488900001bd6c9c27bf2fd903a4c68a1abbbb7d59f04fd4755cc4435bb
- scan_locked.py -- 26d591534192abd31573e00e5c9ed4725eb5cdf93c88cc079e58949148ca6847
- scan_locked_out.txt -- db5c446fb671a0e83ef2456df2371c548f3d517b12143b1e032924d7ba882493

ALL EIGHT MAIN SUBMISSIONS SEALED (N/A, N/B, N/C, N/D, H/A, H/B, H/C, H/D),
plus both Role C reveal addenda sealed separately above.

## MUTATION RUN LOG -- runner's record sealed 2026-10-31T23:04Z (pre-witness hash)
- mutations/RUN_LOG.md -- 7e64801b784753a7664191fc8264b05e8a9ab8a197c5cb6c236088776fe213b8
- (Witness countersignatures are appended to RUN_LOG.md after split witnessing; the final sealed hash is recorded below the append.)

## WITNESS FILES -- sealed 2026-10-31T23:06Z
- N/D/WITNESS.md -- 4b6be0bf9b6a89527538f7f2f7c3dfe854b5a96a5726d53d63d32c1b1aadd322 (M1-M12: 12 CONFIRMED, 0 DISPUTED)
- H/D/WITNESS.md -- 50580ac6936b98ee833c87b11ed31e50998f2bd4fdf7b2191a917b3b67f6ede0 (M13-M24: 12 CONFIRMED, 0 DISPUTED)

## MUTATION RUN LOG -- FINAL SEAL (with countersignatures appended)
- mutations/RUN_LOG.md -- 5fd7889d4bc3b22a834638e12cbcce034375c6ac0be36db49023bad4283e8cfa

MUTATION LOG SEALED. ANONYMIZATION MAY BEGIN (spec 10.2).

## BLIND ADJUDICATION -- BADGES FROZEN 2026-10-31T23:11Z (spec 10.4)
- adjudication/GS4_ADJUDICATION_BLIND.md -- 67aab0a01ed67af450e029618428a09a6297b1c80c2a54b08d3d3affc19aa3cf
- Adjudicated arithmetic: HELD 38 / LIMIT 31 / OUTSIDE 15 / BROKE 3 (87 cards).
- KEY_SEALED.md sha256 (pre-opening): 8f3357c10e9578c977eab0a4435abd6cd7c13d5a74ef3d6c6efffda9af684c0a
