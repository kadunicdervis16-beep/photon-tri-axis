# GS-4 GOLD v1.0 — REVEAL ADDENDUM — ARM H, ROLE C
## GS4-B reveal pass: sealed blind classifications vs. the paper's actual Appendix B labels

Trial label (spec §1): *GS-4 Gold v1.0 (house execution, two-arm
isolated-context trial).* This addendum is not external validation and
awards no badge; it resolves the blind-vs-actual record for Gate 3
(badge honesty) and leaves every badge decision to the blinded
adjudicator.

**Standing of this pass.** The original Role C agent's session ended
when it sealed its submission; this addendum is executed by a fresh
agent on the identical Arm H, Role C charter, working from that agent's
sealed record (`BLIND_CLASSIFICATIONS_SEALED.md`, SHA-256 as recorded
in `SUBMISSION.md`: ef6562f464c8f7a469a023893c627e6c069461213b718e499b04ea292bc3947f;
`SUBMISSION.md` in the same directory). No sealed file has been edited.
The frozen paper's hash was recomputed in this pass:
`packet/Paper_12_v4.md` SHA-256
fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150 —
matches the freeze hash in the brief.

**Stance.** Per the Arm H overlay, the hostile case is argued first for
every claim below: each blind/actual pair was read for the reading
least favourable to the author before any concession. Per the strict
rule, every paper-defect verdict in this addendum names (i) the exact
claim, (ii) the requirement that claim entails under the paper's own
§0.2/§0.3/§0.4, and (iii) the failure under the paper's declared
premises. A disagreement between the sealed blind classification and
the actual label is **not** automatically a paper defect: where the
full paper's text supports the actual label and the blind packet did
not contain that text, the disagreement is recorded as an
**examiner-miss**. Where the actual label itself fails §0.2, it is
recorded as a **paper-defect**, even if the blind classification
happened to match its string.

## The governing definitions — Paper 12 §0.2 (frozen paper, lines 43–58)

- **[LEVEL A]** (line 47): "Machine-checked (script exits 0), or
  inherited from a cited source paper's Level A result with lineage
  cited (inheritance line, §0.4), or prose-proved with no gaps. The
  strongest claim this paper makes."
- **[LEVEL A: MACHINE]** (line 48): "The claim's content is the output
  of a named verification script… The badge is exactly as wide as its
  validation artifact: the script checks what the script checks, and
  the prose around it claims no more."
- **[LEVEL A: AUTHOR]** (line 49): "Declaration-backed, not
  derivation-backed." It guarantees the declaration was made in the
  open, is traceable, and is stable (the subtype propagates
  downstream); every such claim states its falsifiers or explicitly
  names the limit instead.
- **[LEVEL A: MACHINE / AUTHOR]** (line 50): hybrid; "The components
  are listed explicitly at the claim site… The halves do not cover
  each other, and the mark splits rather than averages."
- **[CITED]** (line 51): "a quotation or a faithful restatement of a
  named source… A [CITED] claim asserts that the source says it; the
  claim's own epistemic weight is whatever the source's badge is,
  traced through the inheritance line."
- **[LEVEL B]** (line 52): "Illustration, conditional reading, declared
  programme, or author-authorized declaration of weaker standing than
  [LEVEL A: AUTHOR]."
- Universality (line 45): "Every claim in this paper carries an
  epistemic badge:" — followed by the closed list above (plus
  [Declared assumption], [LEVEL C], [NO BADGE], Denied [Level A]).
- **Bridge rule** (§0.3, line 73): "L_claim ≤ min(L_i) — a claim cannot
  outrank its weakest dependency." L0.2-P12 (line 102) prints the same
  rule flat at [LEVEL A: AUTHOR], with script H.1 named as its
  enforcement artifact.

## Summary table

| Claim | Sealed blind classification | Actual Appendix B label | Resolution |
|---|---|---|---|
| L0.3-P12 | [LEVEL A: AUTHOR] | [LEVEL A: AUTHOR] (script: —; FINAL) | Agreement; both govern jointly — no disagreement |
| L1.2-P12 | [CITED] | [CITED — L4-P12] (script: —; FINAL) | Material agreement; actual adds the lineage label — minor examiner incompleteness, not a defect |
| L2.1-P12 | [LEVEL A] by inheritance ([CITED] source) | [LEVEL A] (script: —; FINAL) | Agreement — no disagreement |
| L5.4-P12 | [LEVEL A: AUTHOR] | [LEVEL A — scoping result, resting on L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, and §3 — through Theorem 4.2, on §4.3 as received at §4, its bonding-mode condition standing as §0.4(b)'s declared receipt] (script: —; FINAL) | **Form disagreement: examiner-miss.** **Grade/pricing: paper-defect** (Finding 1 of SUBMISSION.md, sustained — separate axis, see §4 below) |
| L6.2-P12 | [LEVEL A: MACHINE] (on an inherited premise) | [LEVEL A — conditional on Paper 11 §8.6 and on Paper 11 §8's role-occupancy assignment] (script: A.4; FINAL) | **Examiner-miss** — actual label governs |
| L7.3-P12 | [LEVEL A: MACHINE / AUTHOR] | [LEVEL A: MACHINE / AUTHOR — script A.6] (script: A.6; FINAL) | String agreement; §0.2-conformance defect in the paper's hybrid practice recorded separately (Finding 2) |
| L8.10-P12 | CONJECTURE — no Level A justifiable ([LEVEL B] at most) | [LEVEL B] (script: —; FINAL) | Agreement — no disagreement |
| L9.4-P12 | [LEVEL A] by inheritance ([CITED] components) | [Construction — Paper 12; components inherited as cited] (script: —; FINAL) | **Blind overgrade: examiner-miss.** **Actual label's taxonomic status: paper-defect** (Finding 5, sustained — separate axis, see §8 below) |
| L10.1-P12 | [LEVEL A: MACHINE] (with reservation) | [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)] (script: A.3; FINAL) | String agreement, reservation vindicated; §0.2-conformance **paper-defect** (Findings 3 and 1) |
| L11.2-P12 | [LEVEL A: MACHINE] | [LEVEL A: MACHINE] (scripts: A.1, A.2, A.6; FINAL) | Agreement — no disagreement |
| L11.3-P12 | UNDETERMINED — no badge justifiable | [LEVEL A: AUTHOR] (script: —; FINAL) | **Examiner-miss, packet-caused** — actual label governs (see §10, flagged verdict) |
| L11.4-P12 | [LEVEL A: MACHINE / AUTHOR] | [LEVEL A: MACHINE / AUTHOR] (script: A.14; FINAL) | String agreement; blind reservation withdrawn on the paper's text (SUBMISSION.md Workbook 5); §0.2-conformance defect in the hybrid practice recorded separately (Finding 2) |

Count, stated without summing verdicts into a score: string/material
agreement on seven claims (L0.3, L1.2, L2.1, L7.3, L8.10, L11.2,
L11.4) and on an eighth by string (L10.1, whose badge the blind
examiner's own reservation disputed); blind-vs-actual classification
disagreements on four claims (L5.4, L6.2, L9.4, L11.3), resolved as
examiner-misses in whole (L6.2, L11.3), in form (L5.4), or in part
(L9.4, blind overgrade). Paper-defect verdicts sustained from the
sealed submission's findings attach to L5.4 (grade, Finding 1), L9.4
(label taxonomy, Finding 5), L10.1 (badge form, Finding 3; grade,
Finding 1) and the hybrid badge form instantiated by L7.3 and L11.4
(Finding 2). This addendum sustains those findings on §0.2's text; it
does not discover them.

---

## 1. L0.3-P12 — agreement

- **Blind:** [LEVEL A: AUTHOR]. **Actual:** [LEVEL A: AUTHOR].
- **Hostile probe:** the disposition rule for Paper 11 §0.5-locked
  words is "swept by FW.1" — is a machine sweep being silently
  converted into AUTHOR cover, or vice versa?
- **Resolution:** no disagreement to resolve. The claim's content is a
  declaration about this paper's own usage (each locked word's sole
  permitted route), which is exactly §0.2 line 49's declaration-backed
  content; the FW.1 sweep is enforcement of the declaration, not the
  claim's carrier, and the claim states a falsifier (a locked word in
  native voice outside its disposition, uncorrected in a final tree).
  §0.2's AUTHOR definition governs and both classifications satisfy
  it. **Record: agreement, HELD as badged** (as in SUBMISSION.md
  Workbook 1).

## 2. L1.2-P12 — material agreement, minor examiner incompleteness

- **Blind:** [CITED]. **Actual:** [CITED — L4-P12].
- **Hostile probe:** is the suffix "— L4-P12" a grade upgrade smuggled
  into a citation mark?
- **Resolution:** no. §0.2 line 51 defines [CITED] as a quotation or
  faithful restatement whose weight is the source's, "traced through
  the inheritance line"; §0.3 defines [L4-P12] as the dependency label
  for Paper 11.5 v26, the commissioning text containing the
  count→weight debt at §§11.5–11.6. The suffix names the lineage the
  definition requires; it changes no grade. The blind classification
  got the category right and omitted only the lineage specification
  the blind packet did not print. **Record: material agreement;
  examiner-miss of specification only (minor), not a paper-defect.**
  The actual label governs in its fuller form.

## 3. L2.1-P12 — agreement

- **Blind:** [LEVEL A] by inheritance ([CITED] source).
  **Actual:** [LEVEL A].
- **Hostile probe:** the blind gloss "[CITED] source" against a plain
  [LEVEL A] badge — is the paper laundering a citation into a proved
  result?
- **Resolution:** no disagreement. §0.2 line 47 expressly admits
  [LEVEL A] for a claim "inherited from a cited source paper's Level A
  result with lineage cited (inheritance line, §0.4)". L2.1's home
  carries the full §0.4-form inheritance line (Paper 11 §4.1 / claim
  41 / R15; Level A at source; machine check F.41 named there —
  traced in SUBMISSION.md Workbook 1). The blind gloss and the actual
  badge are the same classification in two notations, and the badge
  does not outrank its source. **Record: agreement, HELD as badged.**
  The actual label governs.

## 4. L5.4-P12 — FLAGGED VERDICT: form disagreement = examiner-miss; grade = paper-defect (Finding 1 sustained)

- **Blind:** [LEVEL A: AUTHOR] — "a dissolution is a declared
  identification of instruments, not a derivation printed in the
  packet and not a machine output."
- **Actual:** [LEVEL A — scoping result, resting on L5.3-P12 as
  restated, Proposition 5.9, Theorem 4.2, and §3 — through Theorem
  4.2, on §4.3 as received at §4, its bonding-mode condition standing
  as §0.4(b)'s declared receipt].
- **Hostile case first:** the blind reading is the least favourable
  one and it is not frivolous. The claim announces that a
  pre-registered debt is "discharged by dissolution" — by the author's
  reframing of what a frequency *is* — enacted in part by a definition
  (Def. 5.8) added in v4 after falsification condition C32 fired
  against the v3 form. Read on the blind packet alone, nothing in that
  is a derivation; reframing is declaration-class work, and §0.2 line
  49's AUTHOR subtype is where declaration-class Level A content
  lives.
- **Why the actual label's form nevertheless governs —
  examiner-miss.** The frozen paper does not rest L5.4 on the
  reframing alone: Theorem 5.4 (frozen paper line 777) prints a case
  analysis, and the badge itself names the derivation chain —
  L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, §3. That is
  prose derivation, and §0.2 supplies exactly one un-subtyped home
  for it: line 47's third clause, "prose-proved with no gaps", under
  plain [LEVEL A]. Conversely, [LEVEL A: AUTHOR] is *defined* at line
  49 as "Declaration-backed, not derivation-backed" — applying it to
  a claim whose carrier is a printed case analysis would misdescribe
  the backing type, whatever one thinks of the proof. The predecessor
  recorded this expectation in the sealed submission itself (blind
  notes (ii): "the frozen paper in fact rests it on a printed case
  analysis (Theorem 5.4) — the blind classification of L5.4 is the
  one this examiner expects the reveal to move, and the reason is the
  packet's stripping, not the paper's text"). That prediction is
  confirmed by the reveal. **The form disagreement (AUTHOR vs. plain
  LEVEL A) is an examiner-miss, caused by the blind packet's
  stripping of the derivation the paper prints. It is not a
  paper-defect.**
- **The separate grade question — paper-defect, Finding 1
  sustained, under the strict rule.** (i) *Exact claim:* L5.4's badge
  as quoted above, printing [LEVEL A] while naming, in its own chain,
  Theorem 4.2 → §4.3 as received at §4 → the §0.4(b) bonding-mode
  declared receipt. (ii) *Requirement the claim entails:* §0.3 line
  73's bridge rule — "L_claim ≤ min(L_i) — a claim cannot outrank its
  weakest dependency" — restated flat by L0.2-P12 (line 102); the
  rule is stated over dependencies, and L5.4's badge prints the chain
  along which the price must run transitively. (iii) *Failure under
  the paper's declared premises:* §0.4(b) (line 91) itself computes
  the price and concedes it: "Priced transitively through this
  receipt, the claims consuming the premise stand one grade below
  their printed conditional badges; that residue, recorded by the X2
  diagnosis, stands until the author rules…". The paper's own text
  therefore gives both the rule and its violation, unresolved, on the
  same record; and H.1 — the artifact L0.2 names as the rule's
  enforcement — contains no pricing check capable of failing the row
  (SUBMISSION.md Finding 1, witness pair (ii)). **Record:
  paper-defect against the badge's grade (not its form, and not the
  claim's content, which Finding 1 expressly does not impugn).**
- **Why the two records do not collapse into each other:** AUTHOR is
  a *backing-type* subtype (declaration vs. derivation); "one grade
  below" is a *grade* statement. Even if the author's pending bridge-
  rule ruling prices L5.4 down a grade, the remedy is a grade ruling
  — it would not convert a prose-proved scoping result into a
  declaration, and it does not rehabilitate the blind AUTHOR
  classification. The axes are independent, and this addendum records
  them independently: **form — examiner-miss; grade — paper-defect.**

## 5. L6.2-P12 — examiner-miss; actual label governs

- **Blind:** [LEVEL A: MACHINE] (on an inherited premise) — script
  A.4 named, factoring "checked rule-independently over a declared
  finite test taxonomy (e+ + e− ≤ 4)".
- **Actual:** [LEVEL A — conditional on Paper 11 §8.6 and on Paper 11
  §8's role-occupancy assignment] (script: A.4).
- **Hostile case first:** a named script, a printed finite coverage
  statement, a check that passes — the MACHINE reading is the one the
  blind packet's surface invites, and the hostile examiner took it.
- **Why it fails against §0.2:** line 48 defines [LEVEL A: MACHINE]
  as a claim whose *content is the output* of the named script, "exactly
  as wide as its validation artifact". Theorem 6.2's content is not
  A.4's output: the theorem quantifies over the encounter taxonomy as
  Paper 11 §8.6 defines it, and its carrier — as traced in
  SUBMISSION.md Workbooks 1 and 4 — is the complete prose proof from
  the two named inherited premises (§8.6's outcome-factoring, Level A
  at source; §8's role-occupancy assignment, marked before use in the
  proof). Remove A.4 and the claim still stands on that proof (A.4 is
  corroboration over a finite taxonomy); remove §8.6 and nothing
  stands. A badge whose width is A.4's finite taxonomy cannot be the
  badge of that theorem. The actual label is precisely the §0.2 form
  the content requires: plain [LEVEL A] under line 47's
  prose-proved/inherited clauses, with *both* load-bearing
  dependencies named as conditions in the badge itself (the
  post-round-9 conformed form; SUBMISSION.md Workbook 6, Change 3,
  verified the conformance and its mechanical guard). The script
  column's "A.4" records the corroborating check; it does not assert
  the MACHINE subtype, and the paper does not print it.
  **Record: examiner-miss. The actual label governs; no paper-defect
  in this claim's badge.**

## 6. L7.3-P12 — string agreement; conformance defect recorded separately (Finding 2)

- **Blind:** [LEVEL A: MACHINE / AUTHOR]. **Actual:** [LEVEL A:
  MACHINE / AUTHOR — script A.6].
- **Resolution of the classification question:** agreement. Both
  sides print the hybrid mark §0.2 line 50 defines, the claim site
  prints the explicit component split line 50 requires, and the
  predecessor's split audit (SUBMISSION.md Workbook 2) verified the
  allocation is complete and candid. No blind-vs-actual disagreement
  exists for Gate 3 to resolve.
- **What the agreement does not settle:** agreement with the paper's
  label is not agreement with §0.2. Finding 2 of the sealed submission
  is sustained here under the strict rule: (i) *exact claim* —
  L7.3's AUTHOR leg as printed in its split: "the (7.4) identity in
  general, carried by §7.3's prose (exact rational arithmetic over
  the shared denominator |W|); D(P, W)'s exact rationality in
  general, carried by §7's prose"; (ii) *requirement* — §0.2 line 49
  defines the AUTHOR discipline the hybrid's declared part is
  carried under (line 50) as "Declaration-backed, not
  derivation-backed"; (iii) *failure* — exact rational arithmetic
  carried by prose is a derivation in the paper's own vocabulary
  (Workbook 5 independently verified that derivation and found it
  correct — the defect is the filing, not the mathematics). One of
  L7.3's three AUTHOR-leg items (the one-body identification with
  Paper 9 §4) is genuinely declaration-class; the other two are not.
  **Record: no classification disagreement (agreement); paper-defect
  in the hybrid badge form as §0.2 defines it, per Finding 2 —
  proposed LIMIT/BROKE disposition left exactly as Finding 2 filed
  it (BROKE against the badge form, contents HELD).**

## 7. L8.10-P12 — agreement

- **Blind:** CONJECTURE — no Level A badge justifiable ([LEVEL B] at
  most), on the blind text's own words ("Conjecture, stated as a
  target (§8.6)… The joint itself is not claimed", strong form
  "already refuted inside this paper").
- **Actual:** [LEVEL B].
- **Resolution:** agreement, and the actual label is the §0.2-correct
  one: line 52's [LEVEL B] covers a "declared programme" and
  conditional readings of exactly this kind. The hostile reading —
  that a refuted strong form is being kept warm — fails on the text:
  the claim badged is the open joint itself, stated as not claimed,
  which is category-E territory (a question the paper explicitly
  leaves open) and cannot be a defect under spec §9.5.
  **Record: agreement, HELD as badged.**

## 8. L9.4-P12 — both sides wrong, in different ways: blind overgrade = examiner-miss; actual label = paper-defect (Finding 5 sustained)

- **Blind:** [LEVEL A] by inheritance ([CITED] components) — "built
  by summation over Paper 9 §6's local saturation behaviour", capacity
  /load "under Paper 10 eq. (2.4)", Threshold "cited to Paper 7".
- **Actual:** [Construction — Paper 12; components inherited as
  cited].
- **Hostile case first, against the paper:** "Construction" is the
  softest word in the registry — no grade, no falsifier discipline, no
  pricing — attached to a load-bearing construction (§9's
  regime-change apparatus, C30's target). If any sampled label were
  concealing an unpriced claim, it would be this one.
- **Sub-disagreement 1 — the blind classification is an
  examiner-miss.** The actual label's *description* is right and the
  blind grade is wrong, for a reason §0.2 makes mechanical: line 47
  admits inherited [LEVEL A] for a claim "inherited from a cited
  source paper's Level A result" — i.e. the *claim* must be the
  source's result. L9.4's claim is not Paper 9's or Paper 10's
  result: the per-junction saturation criterion is Paper 9 §6's first
  step and the budget is Paper 10 eq. (2.4) (both verified in the
  packet, SUBMISSION.md Workbook 1), but the population-scale
  summation over junctions — J_sat, the saturation fraction, regime
  change as a J_sat change — is this paper's own construction, built
  at §9.4 and stated in §0.3's [L2-P12] entry to be "this paper's,
  badged as such at §9". Inherited components do not transmit a Level
  A grade to a new construction assembled from them; that is the
  §0.4 modular principle ("inherited content is carried at no
  strength above the strength its home records", line 97) applied to
  the whole-vs-parts direction. The blind examiner priced the parts
  and graded the whole. **Record: examiner-miss. On what the claim
  *is*, the actual label governs over the blind classification.**
- **Sub-disagreement 2 — the actual label is a paper-defect, under
  the strict rule (Finding 5 sustained).** (i) *Exact claim:*
  L9.4-P12 (§9 claim list, frozen paper line 2288; registry line
  2871), marked "[Construction — Paper 12; components inherited as
  cited]". (ii) *Requirement the claim entails:* §0.2 line 45 —
  "Every claim in this paper carries an epistemic badge:" — followed
  by the closed list at lines 47–57, reinforced by L0.1-P12's
  falsifier (line 101: a claim "carrying a badge its stated backing
  does not support is a defect against this declaration"). A reader
  must be able to find the mark's backing rules in §0.2. (iii)
  *Failure under the paper's declared premises:* "Construction"
  appears nowhere in §0.2's list and is defined nowhere at §0.2's
  level; its only taxonomic home is script H.1's docstring, which
  lists it among "the paper's declared non-grade categories" while
  H.1's own provenance cites §0.2 as the taxonomy's source — the
  supplement's sole home is the script that enforces it
  (SUBMISSION.md Finding 5, witness pair). The construction's
  mathematics is not impugned (components check out as cited; the
  Paper 7 Threshold is expressly non-load-bearing, Workbook 4), and
  the claim text discloses its components honestly — what is missing
  is the price tag: no grade, no falsifier discipline, no bridge-rule
  arithmetic a reader can apply from §0.2 alone. **Record:
  paper-defect against the label's taxonomic status; Finding 5's
  proposed disposition (LIMIT — content supported as far as traced,
  badge not decidable at §0.2's scope) stands.**

## 9. L10.1-P12 — string agreement, reservation vindicated; paper-defect (Findings 3 and 1 sustained)

- **Blind:** [LEVEL A: MACHINE] (with reservation) — the reservation
  recording that A.3's printed coverage runs declared toy systems
  (TOY1/TOY2/TOY3, class=control) and that "a general claim over all
  finite populations needs a prose leg the blind packet does not
  print."
- **Actual:** [LEVEL A: MACHINE — script A.3, conditional on A.2
  (well-definedness of T_agg)].
- **Resolution of the classification question:** the strings agree.
  The reveal does not vindicate the badge, however — it confirms the
  blind reservation was the correct hostile instinct, because the
  frozen paper *does* print the prose leg: the Ground at line 2332
  ("T_agg is a total deterministic function on a finite set;
  iterating a function on a finite set revisits a record within
  (number of records + 1) steps, and determinism then forces the
  trajectory onto the cycle…") is a complete proof of the universal
  claim, and A.3 verifies enumerated items on test populations.
- **Paper-defect, under the strict rule (Finding 3 sustained).**
  (i) *Exact claim:* "**Claim L10.1-P12 [LEVEL A: MACHINE — script
  A.3, conditional on A.2…].** *Every aggregate trajectory of a finite
  population under T_agg is eventually periodic…*" (line 2331).
  (ii) *Requirement:* §0.2 line 48 — a MACHINE badge's content is the
  named script's output, "exactly as wide as its validation
  artifact… the prose around it claims no more." (iii) *Failure:*
  A.3's artifact covers test populations and declared toy systems;
  the claim's generality is carried by the prose Ground, which the
  badge credits to A.3. The honest marks available under §0.2 were
  plain [LEVEL A] (line 47, prose-proved with no gaps) or an explicit
  split; neither was used. Finding 3's disposition stands: **LIMIT,
  not BROKE** — the claim's content is established, by the prose the
  badge fails to credit. **Record: no blind-vs-actual disagreement;
  paper-defect in the actual badge.**
- **Transitive pricing:** L10.1 is also a Finding 1 claim at one
  further remove — §0.4(b) names it among the claims resting on
  Theorem 4.2 through A.2, covered by the same "one grade below their
  printed conditional badges" residue. Same record as §4 above:
  **paper-defect in grade, per Finding 1**, independent of the
  MACHINE-width defect in form.

## 10. L11.3-P12 — FLAGGED VERDICT: examiner-miss, packet-caused; actual label governs

- **Blind:** UNDETERMINED — no badge justifiable. "The blind packet
  prints NO statement and NO dependency text and names NO script for
  this claim. From the blind packet alone there is nothing to
  classify; any badge the paper carries for it is unsupported by
  blind evidence."
- **Actual:** [LEVEL A: AUTHOR] (script: —; FINAL).
- **Hostile case first:** an empty blind entry is exactly where a
  badge could hide — a claim the packet-generation silently dropped
  is a claim no blind examiner priced, and the hostile examiner
  refused to classify on nothing. That refusal was procedurally
  correct *as a sealed blind verdict*: GS4-B requires classification
  from the blind packet alone, and from that packet alone
  UNDETERMINED is the only honest entry. Any agent that had
  "classified" L11.3 from the empty entry would have been inventing
  evidence.
- **Why the actual label nevertheless governs — examiner-miss, with
  the cause named.** The emptiness is a packet artifact, not a paper
  fact. `blind_verification.txt` records that the blind packet's
  generation dropped 1 sentence for L11.3-P12 (noted in the sealed
  submission's blind-pass notes, before the reveal). The frozen paper
  itself is not empty: L11.3's home is the §11.3 verdict (line 2641),
  its content is the extension verdict stated there, and its limits
  are printed as Edges 1–3 (enumeration horizon; taxonomy admission;
  packing deferred to Paper 16) with the claim stated "subject to
  Edges 1–3". Against §0.2, that content prices exactly at line 49:
  it is a *verdict* — declaration-class content, author-issued, with
  its limits/falsifier-class conditions stated at the site (Edges
  1–3), machine-checked by nothing and derived from nothing beyond
  the construction's own sentences. The predecessor's main
  submission, working from the full paper, reached the same
  conclusion independently of this reveal: "On the paper's text the
  AUTHOR grade is the honest one… HELD as badged" (Workbook 1). No
  §0.2 requirement is unmet by the actual badge: it is not MACHINE
  (nothing claims it is), it is not plain derivation-backed LEVEL A
  (nothing claims that either), and its stated limits satisfy line
  49's falsifier-or-limit requirement.
- **On the disclosed incidental exposure:** the sealed submission's
  PROCESS STATUS discloses that an early taxonomy grep surfaced §11
  home lines for L11.2/L11.3 in its tail. The reveal prices that
  incident as follows: the sealed blind entry for L11.3 is
  UNDETERMINED — the one entry the incidentally seen home text (which
  prints the AUTHOR badge's claim statement at line 2641) would have
  made *classifiable* — so the exposure demonstrably did not drive
  the blind classification, and this addendum's resolution rests on
  the full-paper reading recorded in Workbook 1, not on the grep.
- **Record: disagreement resolved as examiner-miss, caused by a
  packet-generation artifact (1 dropped sentence), expressly not a
  paper-defect. The sealed UNDETERMINED stands as the correct blind
  procedure and is superseded, on the paper's text, by the actual
  [LEVEL A: AUTHOR], which governs.**

## 11. L11.2-P12 — agreement

- **Blind:** [LEVEL A: MACHINE]. **Actual:** [LEVEL A: MACHINE]
  (scripts: A.1, A.2, A.6).
- **Hostile probe:** a MACHINE badge is, per §0.2 line 48, "exactly
  as wide as its validation artifact" — does this claim's wording
  reach past population sizes 1–12?
- **Resolution:** no disagreement, and the hostile probe is answered
  by the claim as badged: the statement is expressly bounded to the
  enumerated range (identities "checked across population sizes
  1–12", no size-triggered branch), and §11.3's Edge 1 discloses that
  beyond the enumerated range the carrying argument is AUTHOR-level
  prose — which the badged claim does not assert. (The home
  sentence's loose "from two bodies" phrase against A.1's stated
  sizes 1–12 was probed in the sealed submission and conceded there:
  A.1's coverage supports the 1–12 clause.) **Record: agreement, HELD
  as badged.**

## 12. L11.4-P12 — string agreement; blind reservation withdrawn; conformance defect recorded separately (Finding 2)

- **Blind:** [LEVEL A: MACHINE / AUTHOR], with a reservation: the
  blind text's parenthetical says §4 states no tick-dynamics for body
  records' (N, Σs², Σu), yet the AUTHOR leg's general tick-stability
  theorem is said to be carried by prose proof "under §4's stated
  dynamics" — "on the blind text alone the AUTHOR leg's premise base
  is not shown to exist."
- **Actual:** [LEVEL A: MACHINE / AUTHOR] (script: A.14).
- **Resolution of the classification question:** agreement on the
  hybrid mark, and the reservation does not survive the full paper —
  the predecessor's Workbook 5 withdrew it on the paper's text, and
  this addendum adopts that withdrawal: §4 defines the tick as T
  applied at junctions; a function defined on junction local states
  does not rewrite body records, so the absence of stated body-record
  dynamics *is* the invariance premise, and the reading is forced
  within the paper's declared premises ("Conceded as sound under the
  declared premises; the blind-pass reservation is withdrawn"). The
  GS4-D pair in Workbook 5 independently reproduced both the general
  proof's content and A.14's finite range (representative agreement:
  all five §12.1 steps strict, each decided at the component §11.3
  names). Finding 7's hostile construction on the §12.1 agreement
  target (LEVEL B at home) was likewise argued and conceded there;
  Finding 4's LIMIT on falsification reach after the round-7 C33
  scoping is a Gate 7 matter about the condition, not a badge
  disagreement, and is left exactly as filed.
- **What the agreement does not settle:** Finding 2, sustained as at
  §6 above with L11.4 as its lead instance: (i) L11.4's split (line
  2677) carries in its AUTHOR leg "the tick-stability theorem in
  general, carried by §11.3's prose proof" and "the general order
  properties… §11.3's finite-arithmetic reading of the definition";
  (ii) §0.2 line 49 requires AUTHOR-leg content to be
  declaration-backed, not derivation-backed; (iii) prose proofs and
  finite-arithmetic readings are derivations. The definition-by-
  ruling and representative-construction items in the same leg are
  genuinely declaration-class; the two derivation items are not.
  **Record: no classification disagreement (agreement), blind
  reservation withdrawn; paper-defect in the hybrid badge form as
  §0.2 defines it, per Finding 2 (BROKE proposed against the badge
  form; the claim's contents separately HELD, Workbook 5).**

---

## Closing resolution statement

Gate 3's question for this sample is whether the blind classifications
match the paper's evidence, with every discrepancy resolved and
recorded. The record now stands: **examiner-misses** — L5.4 (form
only), L6.2, L9.4 (blind overgrade only), L11.3 (packet artifact),
plus L1.2's minor specification omission; **paper-defects sustained
from the sealed submission and re-resolved against §0.2 here** —
L5.4 and L10.1 badge grade (Finding 1, bridge-rule residue the paper
itself records at §0.4(b) as standing), L10.1 badge form (Finding 3,
MACHINE width), L9.4 label taxonomy (Finding 5), and the hybrid
AUTHOR-leg practice instantiated by L7.3 and L11.4 (Finding 2);
**agreements with no defect alleged in the badge** — L0.3, L1.2,
L2.1, L8.10, L11.2, and (as to classification and reservation) L11.3
and L11.4. No disagreement in this addendum was resolved by averaging
the two sides: in every case one text — the blind packet, the frozen
paper, or §0.2 itself — was identified as governing, and the reason
stated.

**Process status:** Frozen paper READ and SOURCE-VERIFIED (hash recomputed, matches freeze); §0.2 READ at lines 43–58; sealed H/C files (brief, BLIND_CLASSIFICATIONS_SEALED.md, SUBMISSION.md) READ, NOT EDITED; no other submission directory opened; suite NOT RUN / NOT REPRODUCED in this pass; this addendum (REVEAL_ADDENDUM.md) written to the H/C submission directory as the sole new file.
