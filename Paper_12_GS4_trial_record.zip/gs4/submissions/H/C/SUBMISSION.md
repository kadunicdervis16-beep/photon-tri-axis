# GS-4 GOLD v1.0 — SUBMISSION — ARM H, ROLE C
## Provenance, Badge and Change-Log Examiner (hostile arm)

Trial label (spec §1): *GS-4 Gold v1.0 (house execution, two-arm
isolated-context trial).* This submission is not external validation and
awards no badge; every badge below is a proposal to the blinded
adjudicator.

**Frozen paper verified:** `packet/Paper_12_v4.md`, SHA-256 recomputed by
this examiner: `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150`
— matches the brief's freeze hash. 69,425 lines.

**Sources used (all hashes recomputed by this examiner):**

| File | SHA-256 |
|---|---|
| packet/Paper_12_v4.md | fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150 |
| packet/roleC_only/blind_claims.md | 4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f |
| packet/sample_selection.txt | 588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766 |
| packet/protocol_examiner_extract.md | f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1 |
| packet/paper2_section11.txt | ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e |
| packet/paper9.txt | defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6 |
| packet/paper10.txt | f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82 |
| packet/paper_11_v69.md | f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb |
| packet/paper_11_5_v26.md | 9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60 |
| packet/blind_verification.txt | 97424de9a2d51d2a0e7ad043383ba5e024ed0235a328a208b70fd9c1c19e9dcb |

**Stance.** Per the Arm H overlay: every badge was presumed to outrank its
dependencies until the text forced a concession; every disclosure was read
for what it excludes; every scope statement was read as a possible retreat.
Concessions are recorded in writing where the evidence forced them. Every
defect claim below meets the strict rule: exact claim quoted, the claim's
own requirement stated, failure shown under the paper's declared premises.

**Sample (packet/sample_selection.txt):** L11.4-P12, L7.3-P12, L0.3-P12,
L11.2-P12, L11.3-P12, L5.4-P12, L8.10-P12, L9.4-P12, L6.2-P12, L1.2-P12,
L10.1-P12, L2.1-P12.

---

# GS4-B BLIND PASS — BLIND CLASSIFICATIONS (sealed first)

Classified from `packet/roleC_only/blind_claims.md` **alone**, plus the
badge taxonomy printed at Paper 12 §0.2 (lines 45–58), before any
consultation of Appendix B rows or claim-list badge strings for the
sampled claims. The sealed artifact is `BLIND_CLASSIFICATIONS_SEALED.md`
in this directory, SHA-256
`ef6562f464c8f7a469a023893c627e6c069461213b718e499b04ea292bc3947f` —
written and hashed before the main examination began. Its content is
reproduced here unchanged:

| Claim | Blind classification | Basis in blind packet alone |
|---|---|---|
| L11.4-P12 | [LEVEL A: MACHINE / AUTHOR] | Explicit printed split: MACHINE (A.14 enumerated domains, W1/W4, mutants); AUTHOR (definition by author's ruling 2026-10-28; representative construction under a *declared identification*; general order properties as prose finite-arithmetic reading; general tick-stability theorem by prose proof). RESERVATION: the blind text's own parenthetical says §4 states no tick-dynamics for body records' (N, Σs², Σu), yet the tick-stability theorem is said to be carried by prose proof "under §4's stated dynamics" — on the blind text alone the AUTHOR leg's premise base is not shown to exist. |
| L7.3-P12 | [LEVEL A: MACHINE / AUTHOR] | Explicit printed split: MACHINE (A.6: (7.4) identity on the exhibited window, worked-example arithmetic); AUTHOR (general (7.4) identity by prose; general rationality by prose; identification of the \|P\|=1 case with Paper 9 §4's *verbal* definition — an identification, i.e. declaration-class content). |
| L0.3-P12 | [LEVEL A: AUTHOR] | No named script. Content is a disposition rule (each Paper 11 §0.5-locked word's sole permitted route) — a declaration about this paper's own usage, "swept by FW.1" but with no machine coverage statement printed. Declaration-backed, not derivation-backed, on the blind text. |
| L11.2-P12 | [LEVEL A: MACHINE] | Statement is explicitly bounded to the enumerated range: identities "checked across population sizes 1–12", no size-triggered branch; scripts A.1, A.2, A.6 named. Machine badge exactly as wide as the enumerated domain. |
| L11.3-P12 | UNDETERMINED — no badge justifiable | The blind packet prints NO statement and NO dependency text and names NO script for this claim. From the blind packet alone there is nothing to classify; any badge the paper carries for it is unsupported by blind evidence. |
| L5.4-P12 | [LEVEL A: AUTHOR] | No script. The claim is that a pre-registered debt is "discharged by dissolution" — i.e. by the author's reframing of what discharges it (frequencies *resolve to* orbit counts etc.), enacted in part by a definition added in v4 (Def. 5.8) after C32 fired against the v3 form. A dissolution is a declared identification of instruments, not a derivation printed in the packet and not a machine output. |
| L8.10-P12 | CONJECTURE — no Level A badge justifiable ([LEVEL B] at most) | The blind text itself: "Conjecture, stated as a target (§8.6)… The joint itself is not claimed", and the strong form is "already refuted inside this paper". |
| L9.4-P12 | [LEVEL A] by inheritance ([CITED] components) | No script; the construction is "built by summation over Paper 9 §6's local saturation behaviour" with capacity/load "under Paper 10 eq. (2.4)" — inherited source content; the Threshold is "cited to Paper 7 and not redefined". Epistemic weight is whatever the sources carry, traced by inheritance. |
| L6.2-P12 | [LEVEL A: MACHINE] (on an inherited premise) | Script A.4 named with coverage: outcome factors through M=(n+,n−) is "class=cited-paper (Paper 11 §8.6 — the theorem's one premise, inherited)"; the factoring claim itself is checked rule-independently over a declared finite test taxonomy (e+ + e− ≤ 4) with two disagreeing arbitrary-representative outcome rules. Machine check over a finite domain on a cited premise. |
| L1.2-P12 | [CITED] | The claim asserts only that the count→weight debt "is as quoted at §1.2, including its two named items and the fill rules" (Paper 11.5 §§11.5–11.6). A quotation-fidelity claim; its weight is the source's. |
| L10.1-P12 | [LEVEL A: MACHINE] (with reservation) | Script A.3 named; but its printed coverage shows the framework inputs are T's rule (cited, Paper 11 §7.5) while the trajectory systems actually run are TOY1/TOY2/TOY3, "class=control (declared toy systems)". The blind text prints no component split separating a general prose proof from the toy-domain machine check. Reservation: as printed, the machine evidence covers toy systems; a general claim over all finite populations needs a prose leg the blind packet does not print. |
| L2.1-P12 | [LEVEL A] by inheritance ([CITED] source) | Blind text: "**** — inherited. Dependencies: Paper 11 §4.1's single-regime rule and licensed aggregate list govern every aggregate quantity in this paper." A governance-by-inheritance claim; weight is Paper 11 §4.1's. |

Blind-pass notes for the adjudicator (not classifications): (i) the blind
packet's L11.3 entry is empty — `blind_verification.txt` records that its
generation dropped 1 sentence for L11.3-P12; the emptiness is a packet
artifact, recorded here so the reveal addendum can price it correctly.
(ii) The blind packet prints L5.4's discharge as a reframing; the frozen
paper in fact rests it on a printed case analysis (Theorem 5.4) — the
blind classification of L5.4 is the one this examiner expects the reveal
to move, and the reason is the packet's stripping, not the paper's text.

---

# WORKBOOK 1 — CLAIM → HOME → DEPENDENCY → EVIDENCE GRAPH (sample)

Dependency types: **[INH]** inherited fact (cited paper) · **[DEF]** Paper 12
definition · **[AUTH]** author declaration/identification · **[CTRL]**
arbitrary control choice · **[MACH]** machine output · **[OPEN]** declared
open/deferred.

## L11.4-P12 — home §11.3 (claim list line 2677; registry line 2884)
- Dependencies: K's definition **[AUTH]** (author's ruling 2026-10-28);
  representative construction over Paper 2 §§11.4–11.5 surplus differentia
  **[INH — text]** under the surplus→opposed-pair rendering **[AUTH —
  declared identification, §11.3]**; Paper 11 §12.1's six-class ordering as
  agreement target **[INH — LEVEL B at home, Paper 11 v69 line 1008
  "§12.1 The Ordering [LEVEL B]"; fenced at Paper 12 §0.3 as "not a Level A
  inheritance"]**; F.37 declared assumptions M > 3, S ≥ 1, atoms = nuclei +
  incorporated simple states **[Declared assumption — named at the use
  site, §11.3]**; Paper 11 Table 5.1 sign facts **[INH — cited]**; §4's
  dynamics and Proposition 4.3 (τ falls by exactly 2) **[DEF/INH chain]**;
  A.14 enumeration, W1/W4 witnesses, 3 mutant keys **[MACH]**.
- Evidence: A.14 over its disclosed domains (representatives, homogeneous
  families, σ family); prose finite-arithmetic reading for general order
  properties; prose proof for general tick-stability.
- Printed badge: [LEVEL A: MACHINE / AUTHOR]. Weakest dependency: the
  declared identification and the ruling (AUTHOR grade) — the hybrid mark
  names exactly that leg, so the mark does not outrank it. The §12.1
  target's LEVEL B grade is argued and conceded at Finding 7.

## L7.3-P12 — home §7.3 (claim list §7 claims, ~line 1579; registry)
- Dependencies: eq. (7.3) definition **[DEF]**; r_b(τ) booked reconcile
  counts, whose meaning rides on L7.2-P12's declared identification
  (occasion = contact tick; booked value = N_reconcile under Paper 10
  §2.2) **[AUTH — consumed but NOT named in L7.3's own split]**; Paper 9
  §4 verbal temperature definition **[INH — text; verified in paper9.txt
  line 244]** under the author's one-body identification **[AUTH]**;
  Paper 10 eq. (2.4) **[INH; verified paper10.txt line 985]** via L7.2;
  A.6 exhibited-window identity + worked-example arithmetic **[MACH]**.
- Printed badge: [LEVEL A: MACHINE / AUTHOR — script A.6]. Weakest
  dependency: the two identifications (AUTHOR) — carried in the AUTHOR
  leg. See Finding 2 for what else the AUTHOR leg carries.

## L0.3-P12 — home §0.5 claim list (line 145); registry line 2816
- Dependencies: Paper 11 §0.5 lock text **[INH — CITED via L0.4-P12]**;
  the construction list itself **[AUTH — this paper's disposition
  ruling]**; FW.1 sweep **[MACH — paper-wide]**.
- Printed badge: [LEVEL A: AUTHOR], with a stated falsifier (a locked
  word in native voice outside its disposition, uncorrected in a final
  tree). Matches §0.2's AUTHOR discipline exactly. HELD.

## L11.2-P12 — home §11.3 (line 2630); registry line 2882
- Dependencies: §§3–5, §7 constructions **[DEF]**; A.1 (generated
  populations, "seeded RNG, sizes 1–12, 8 body types" — script listing
  line 3504), A.2, A.6 **[MACH]**; single-regime rule via L2.1 **[INH]**.
- Printed badge: [LEVEL A: MACHINE]. The claim sentence is bounded to
  test populations; Edge 1 (§11.3) discloses that beyond the enumerated
  range the carrying argument is AUTHOR-level prose — and the claim as
  badged does not assert the beyond-range part. Hostile probe: the home
  sentence says test populations run "from two bodies" while identities
  are "checked across population sizes 1–12"; A.1's own coverage states
  sizes 1–12, so the 1–12 clause is supported and the "from two bodies"
  phrase describes the battery span loosely. Conceded — HELD (Finding 8
  records the framework objection instead).

## L11.3-P12 — home §11.3 verdict (line 2641); registry line 2883
- Dependencies: §§3–5/§7 machinery **[DEF]**; Edges 1–3 (enumeration
  horizon; taxonomy admission; packing = Paper 16) **[OPEN — declared
  limits]**; Paper 11 §12.2 scope permission + §16 firewall **[INH]**.
- Printed badge: [LEVEL A: AUTHOR] — a verdict, with falsifier-class
  content in Edges 1–3. The blind packet printed nothing for this claim
  (see blind notes). On the paper's text the AUTHOR grade is the honest
  one: nothing here is machine-checked and nothing is derived beyond the
  construction's own sentences. HELD as badged.

## L5.4-P12 — home §5 claim list (lines 1131–1143); Theorem 5.4 (line 777)
- Dependencies: Proposition 5.3 (L5.3-P12) **[DEF/prose]**; Proposition
  5.9 **[DEF/prose]**; §3 counting rule **[DEF]**; Theorem 4.2
  (well-definedness of T_agg) → §4.3 Port-Partition as received at §4 →
  the §6.1 bonding-mode premise **[declared receipt — AUTH-strength,
  unbadged at source, §0.4(b)]**; Paper 11.5 §11.6 debt text **[INH —
  CITED]**; Definition 5.8 joint counts (v4 repair after C32 fired)
  **[DEF]**.
- Printed badge: [LEVEL A — scoping result, resting on … its
  bonding-mode condition standing as §0.4(b)'s declared receipt].
  Weakest dependency: the declared receipt. §0.4(b) itself states the
  transitive price is one grade below the printed badge and that the
  residue "stands". Finding 1.

## L8.10-P12 — home §8.6 (line 1821); registry line 2867
- Dependencies: Proposition 5.3's orbit structure (named as what a proof
  would need) **[DEF]**; Paper 9 §5 asymmetry (what the arrow becomes if
  the joint is underivable) **[INH — boundary condition]**.
- Printed badge: [LEVEL B] — conjecture, "the joint is not claimed".
  Exactly honest. Category E territory by design. HELD.

## L9.4-P12 — home §9 claims (line 2288); registry line 2871
- Dependencies: Paper 9 §6 saturation cascade's first step **[INH —
  verified paper9.txt lines 461–466, "Step 1, local budget
  saturation"]**; Paper 10 eq. (2.4) capacity/load **[INH — verified
  paper10.txt line 985]**; Paper 10 §2.4.7 partition in single-source
  isotropic form only **[INH — scoped]**; Paper 10 §2.2 relay-execution
  accounting **[INH]**; the Threshold **[CITED to Paper 7 — NOT in the
  packet; expressly not redefined and not load-bearing: regime change
  is defined as a J_sat change, not a threshold crossing]**; §9.4's
  summation construction **[DEF — this paper's]**.
- Printed badge: [Construction — Paper 12; components inherited as
  cited] — a label that appears nowhere in §0.2's taxonomy. Finding 5.

## L6.2-P12 — home Theorem 6.2 (line 1236); claim list line 1344
- Dependencies: Paper 11 §8.6 outcome-factoring **[INH — Level A at
  source; 710,090 machine-checked encounters cited at the theorem]**;
  Paper 11 §8 role-occupancy assignment **[INH — consumed as an
  inherited premise, marked before use in the proof]**; Definition 6.1
  **[DEF]**; A.4 finite-taxonomy check with two arbitrary-representative
  outcome rules **[MACH + CTRL]**.
- Printed badge: [LEVEL A — conditional on Paper 11 §8.6 and on Paper
  11 §8's role-occupancy assignment]. Both load-bearing dependencies
  are named in the badge itself (post-round-9 form; see GS4-H).
  The prose proof is complete from the two named premises; A.4 is
  corroboration, not the carrier. HELD.

## L1.2-P12 — home §1 claim list (line 246); registry line 2819
- Dependencies: Paper 11.5 §§11.5–11.6 quotation **[INH — CITED;
  verified: paper_11_5_v26.md line 2806 prints "(1) a microstate-counting
  rule, and (2) a sampling-measure postulate. Both are Paper 12's
  work", matching §1.2's blockquotes]**.
- Printed badge: [CITED — L4-P12]. Quote-fidelity is the whole claim;
  G.1 machine-checks quote integrity paper-wide. HELD.

## L10.1-P12 — home §10.1 claim (line 2331); registry line 2875
- Dependencies: T_agg well-definedness (A.2 / Theorem 4.2) **[named in
  the badge as a condition]** → transitively the §0.4(b) declared
  receipt (Finding 1); finiteness of the record set **[DEF — §10.1
  prose]**; the general eventual-periodicity step **[prose Ground,
  line 2332 — a complete finite-set argument]**; A.3 orbit enumeration
  on test populations, TOY1/TOY2/TOY3 controls **[MACH + CTRL]**.
- Printed badge: [LEVEL A: MACHINE — script A.3, conditional on A.2].
  The general content is carried by the prose Ground, not by A.3's
  artifact. Finding 3.

## L2.1-P12 — home §2 claim list (line 298); registry line 2826
- Dependencies: Paper 11 §4.1 / claim 41 / R15 **[INH — Level A at
  source, machine check F.41 named in the inheritance line; R15 text
  verified in paper_11_v69.md line 1693]**.
- Printed badge: [LEVEL A] — inherited, with a full §0.4-form
  inheritance line at the home site (source, badge at source,
  validation, reliance). Does not outrank its source. HELD.

## Weakest-dependency tracing — summary
Of the twelve: nine badges sit at or below their weakest *named*
dependency (L11.4, L7.3, L0.3, L11.2, L11.3, L8.10, L6.2, L1.2, L2.1 —
with L9.4 unpriceable for a different reason, Finding 5). Two printed
badges (L5.4, L10.1) stand above the transitive price the paper itself
computes at §0.4(b) (Finding 1). One (L10.1) wears a subtype its own
evidence does not match (Finding 3). No sampled claim was found resting
on a dependency it nowhere names — the §0.4(b) receipt is named at every
direct consumption site §0.4(b) lists, and this examiner verified the
L5.4 and L10.1 chains against that list.

---

# WORKBOOK 2 — MACHINE/AUTHOR SPLIT AUDIT — ALL HYBRID CLAIMS IN THE PAPER

§0.2 (line 50) requires of every [LEVEL A: MACHINE / AUTHOR] claim: "The
components are listed explicitly at the claim site… The halves do not
cover each other." §0.2 (line 49) defines the AUTHOR subtype as
"Declaration-backed, not derivation-backed." The audit question is
twofold: (a) is a split printed at the claim site, naming the exact
content each leg carries? (b) is the AUTHOR leg's content in fact
declaration-class?

All hybrid-badged claims in Appendix B (registry lines 2816–2905):
L3.4-P12, L7.2-P12, L7.3-P12, L8.3-P12, L9.5-P12, L11.1-P12, L11.4-P12,
LD.8-P12, LE.2-P12 (plus OR-1, a resolution row, not a claim).

| Claim | Split at claim site? | MACHINE leg carries (exact) | AUTHOR leg carries (exact) | Audit |
|---|---|---|---|---|
| L3.4-P12 (§3 list, line 415) | Yes | A.1: identities over valued components (N, junction arity multiset, B); worked counts | (i) identification of the rule as the discharge of 11.5's "(1) a microstate-counting rule" under §0.5's corrected name — declaration-class ✓; (ii) **identity (III) over Σs² and Σu components, "carried by §3.3's prose proof"** — derivation ✗ | Split complete; AUTHOR leg mixes declaration + prose derivation (Finding 2 pattern) |
| L7.2-P12 (§7 list) | Yes | A.6: (7.2) arithmetic under Paper 10 eq. (2.4), worked tick (40, 21 → 36) | §7.2's declared identification (occasion books reconcile exactly at contact ticks; booked value = N_reconcile) — declaration-class ✓ | Cleanest split in the paper; this claim was itself a round-5 one-grade fall, i.e. the pricing machinery working |
| L7.3-P12 (§7 list) | Yes | A.6: (7.4) identity on the exhibited window; worked-example arithmetic | (i) **(7.4) identity in general, "carried by §7.3's prose"** — derivation ✗; (ii) **general rationality, "carried by §7's prose"** — derivation ✗; (iii) one-body identification with Paper 9 §4 — declaration-class ✓ | Split complete and candid; AUTHOR leg is 2/3 derivation (Finding 2) |
| L8.3-P12 (§8 list, line 1964) | Yes — home and registry now identical in allocation (round-8 H1 + round-10 D6 repairs verified in this tree) | A.5: counts enumerated n = 1…6; closed forms + (8.7) checked n = 1…12 | (i) **all-n generality of (8.7), "carried by §8.3's printed induction"** — derivation ✗; (ii) the reading of counts as concentration + non-growth honesty entry — declaration-class ✓ | Split complete; derivation in AUTHOR leg (Finding 2 pattern) |
| L9.5-P12 (§9 list, line ~2302) | Yes | A.6: §9.5 threshold arithmetic (105/88/100 → booked 288/293, deferred 5, J_sat 0→2) | "The worked example's status as an exhibit of the §9.4 construction" — neither a declaration with falsifiers nor a derivation; it is a framing assertion | Split printed, but the AUTHOR leg carries no content that §0.2's AUTHOR discipline can grade: no falsifier is or could be stated for "status as an exhibit". Minor: the hybrid mark here splits a computation from a caption |
| L11.1-P12 (§11.2 verdict, line 2616) | Yes, fullest in the paper | A.8: (R1)–(R3) over enumerated groupings; worked example + regrouping | (i) the definition itself (ruling 2026-10-25) ✓; (ii) **grouping-independence in general, "carried by §11.2's prose argument"** — derivation ✗; (iii) **"the proposition that Φ is a Paper 11 Bonded Aggregate, established by this section's prose proof"** — derivation ✗; (iv) the narrowed ordering verdict ✓ | Split complete; two derivations in AUTHOR leg (Finding 2 pattern) |
| L11.4-P12 (§11.3, line 2677) | Yes | A.14: key computation/behaviour over enumerated domains; W1/W4; mutants | (i) definition (ruling) ✓; (ii) representative construction under declared identification ✓; (iii) **general order properties as "finite-arithmetic reading"** — derivation ✗; (iv) **general tick-stability theorem, "carried by §11.3's prose proof"** — derivation ✗ | Finding 2's lead instance |
| LD.8-P12 (App. D list, line 61517) | Yes | A.7: printed Ω path (1 → 924 → 1) and τ_agg series | "The non-tendency reading" — an interpretive reading, declaration-adjacent ✓/borderline | Acceptable; the reading is disclosed as a reading |
| LE.2-P12 (App. E list, line 61611) | Partial | A.12: the recomputation (G8 witness returns 1/4 and 0 under Def. 5.7) | "The code-reading verdicts are the audit's" — the AUTHOR leg is *an audit's verdicts*, not an author declaration, identification, or proof; no falsifier stated | Weakest split in the paper: the leg's content is third-party-style code reading carried at AUTHOR strength with no §0.2-conforming statement of what would falsify it |

**Split-audit conclusion.** On axis (a) — splits printed, contents named —
the paper is strong: 8 of 9 hybrid claims print a complete split at the
claim site, and the round-7/8/10 repairs to L8.3, L3.4, L7.3, L11.1,
L11.4 allocations are all verifiably present in this tree. On axis (b)
the system has one systematic defect, Finding 2: the AUTHOR leg
routinely carries prose *derivations*, which §0.2's own subtype text
forbids it to be. The paper's version block (round 10) records this
exact charge as parked for the author's ruling, unrepaired.

---

# WORKBOOK 3 — DECLARED-ASSUMPTION USE-SITE CHECKS (sample)

§0.2: a declared assumption is "badged at every use site"; §0.3: "any
claim resting on one lists it among its dependencies." Hostile rule
applied: every unnamed assumption treated as a possible concealment.

| Sampled claim | Assumption/premise consumed | Named at use site? |
|---|---|---|
| L11.4-P12 | F.37's M > 3; S ≥ 1; atoms = nuclei + incorporated simple states | **Yes** — §11.3 names all three in the open at the representatives paragraph, states the nuclei/atoms step "for every u ≥ 0 and every S ≥ 1", and §0.3 records that F.37's third home assumption (equal tilt counts) is *not* consumed, with the reason. Concealment hunt: negative |
| L11.4-P12 | Surplus→opposed-pair identification | **Yes** — declared identification, stated with its reason, its load-bearing character, and two rival renderings with their consequences (§11.3). The least favourable reading was taken (Finding 4 concerns its falsification scope, not its disclosure) |
| L5.4 / L10.1 | Bonding-mode premise (declared receipt) | **Yes** at every direct site (§0.4(b)'s list verified); the defect is pricing, not naming (Finding 1) |
| L6.2-P12 | §8 role-occupancy as inherited premise | **Yes** — "One premise is marked before it is used" (proof, line ~1257) |
| L7.3-P12 | L7.2's occasion=contact identification, consumed via r_b | **Partially** — §7.3(i) names the one-body identification and its grade, but L7.3's split does not name its dependence on L7.2's identification for what r_b *means*; a reader of L7.3 alone sees D built on "booked reconcile counts" whose booking rule is another claim's declaration. Recorded as a graph observation; not filed as a defect finding because §7.2 immediately precedes §7.3 and C28 names the joint site |
| L9.4-P12 | Single-source/isotropic restriction on §2.4.7 | **Yes** — stated in the claim text itself, with the anisotropic remainder deferred to Paper 23 |
| L10.1-P12 | Re-presentation for c > 1 cycles | **Yes** — the clarification paragraph scopes it as A.3's declared control and excludes arbitrary external re-presentation expressly |
| L0.3, L1.2, L2.1, L8.10, L11.2, L11.3 | — | No unnamed load-bearing assumption found; L11.3's Edges 1–3 are named limits, L8.10's openness is the claim |

---

# WORKBOOK 4 — GS4-C DEPENDENCY-BREAK TABLE (sample)

Method: for each sampled claim, remove one dependency at a time from the
working packet and ask whether the claim remains derivable from what is
left. "Badge reflects it" = the printed badge/claim text names the
dependency or its conditionality.

| Claim | Dependency removed | Derivable without it? | Precise dependency | Badge reflects it? |
|---|---|---|---|---|
| L11.4 | A.14 (machine leg) | Partially — definition, representatives, order properties and tick-stability all stand as AUTHOR/prose content; the *machine* content (W1/W4, mutants, enumerated behaviour) is gone | A.14's enumerated-domain verification | Yes — split names A.14's exact share |
| L11.4 | Declared identification (surplus→opposed pair) | **No** — the meson-like/baryon-like step is decided nowhere (paper's own text: the unsettled-entry reading decides the step nowhere; the lone-leftover reading moves it to Tau0) | The identification is load-bearing for the overlap's deciding component | Yes — AUTHOR leg, disclosed as load-bearing |
| L11.4 | Paper 11 §12.1 ordering | The key stands entire; only the *agreement* sentence loses its target | §12.1 as target text (CITED-grade content) | Yes — §0.3 fence + §11.3 text |
| L11.4 | F.37 declared assumptions | **No** for the nuclei/atoms step in general (only the exhibited u=0, S=2 point survives) | M > 3, S ≥ 1 | Yes — named at §11.3 |
| L7.3 | Paper 9 §4 definition | D and (7.4) stand as pure construction; the *reduction* clause ("reduces to Paper 9's §4 definition") becomes unstateable | Paper 9 §4 verbal definition + author's identification | Yes — AUTHOR leg |
| L7.3 | A.6 | Yes — general identity and rationality are prose-carried; only the exhibited-window verification is lost | A.6 as corroboration | Yes — split states A.6 verifies "on the exhibited window" |
| L7.3 | L7.2 identification (occasion = contact) | D remains an exact rational of *booked counts*, but the counts' claim to be Paper 9 reconcile events fails | L7.2-P12's declared identification | **No** — not named in L7.3's split (Workbook 3) |
| L0.3 | Paper 11 §0.5 lock text | **No** — the list's authority is the lock; without the quoted lock there is nothing to fix routes *for* | L0.4-P12's CITED lock text | Yes — claim text names Paper 11 §0.5 |
| L0.3 | FW.1 | The disposition rule stands as AUTHOR declaration; its sweep enforcement is gone | FW.1 | Yes — "swept by FW.1" in the claim text |
| L11.2 | A.1/A.2/A.6 | **No** — size-invariance as *machine-checked* content is exactly the batteries; prose alone would be Edge 1's AUTHOR argument, a different (weaker) claim | The three scripts jointly | Yes — named in claim and registry |
| L11.3 | Edges 1–3 | The verdict's content changes: unscoped, it would assert what Edge 2 (taxonomy admission) and Edge 3 (packing) expressly withhold | The edges are part of the claim, not premises | Yes — "subject to Edges 1–3" in the claim |
| L5.4 | Proposition 5.3(iii) | **No** for case (a): long-run frequencies would have no orbit-count resolution | Prop. 5.3(iii) | Yes — badge names L5.3 |
| L5.4 | Definition 5.8 / Prop. 5.9 (joint counts) | **No** — this is exactly C32's v3 firing: the named-pair joint frequency (1/4 vs 0 on identical census/flow data) is inexpressible without joint counts | Def. 5.8 + Prop. 5.9 | Yes — claim text names Def. 5.8 and the C32 history |
| L5.4 | Bonding-mode receipt (via Thm 4.2) | The dissolution's case (a) rests on Prop. 5.3(iii), which rests on Thm 4.2, whose §4.3 condition includes the receipt; remove it and the chain's base is an unbadged premise | §0.4(b) declared receipt | Named in the badge — but priced above it (Finding 1) |
| L8.10 | — (conjecture) | Nothing to break: the claim asserts a target and two conditional consequences, both stated as conditionals | — | Yes — [LEVEL B] |
| L9.4 | Paper 9 §6 first step | **No** — the per-junction saturation criterion is Paper 9's step; without it J_sat has no local predicate to sum | Paper 9 §6 (verified in packet) | Yes — claim text names it |
| L9.4 | Paper 10 eq. (2.4) | **No** — capacity and demanded load lose their defining budget | Paper 10 §2.2 eq. (2.4) (verified in packet) | Yes — claim text names it |
| L9.4 | Paper 7 Threshold | Yes, entirely — the Threshold is cited, not used; regime change is defined by J_sat's change, and no exhibited number routes through a threshold point | None (decorative dependency) | Yes — claim text itself says "cited… not redefined; its exact point Paper 14's". A named non-dependency, honestly labelled |
| L6.2 | Paper 11 §8.6 | **No** — the proof's only factoring premise is gone; A.4 checks the factoring on a finite taxonomy but the theorem quantifies over the taxonomy as §8.6 defines it | §8.6 (Level A at source) | Yes — badge conditionality |
| L6.2 | Paper 11 §8 role-occupancy | **No** for the role conclusion — outcomes would factor while roles might not follow outcomes | §8 inherited premise | Yes — badge conditionality (restored round 9; GS4-H) |
| L6.2 | A.4 | Yes — the prose proof from §8.6 + §8 stands; Paper 11's own 710,090-encounter check stands at source. A.4 is this paper's corroboration | A.4 | Yes — registry script column only; the claim does not overstate A.4's role |
| L1.2 | Paper 11.5 §§11.5–11.6 | **No** — a quotation claim with its source removed is empty | The quoted debt text | Yes — [CITED — L4-P12] |
| L10.1 | A.3 | Yes in substance — the prose Ground (line 2332) is a complete proof; what is lost is the enumerated verification of (p, c) counts and fixed-point counts | A.3 as verifier, not as carrier | **No** — the badge [LEVEL A: MACHINE] credits A.3 with the claim (Finding 3) |
| L10.1 | A.2 / Thm 4.2 | **No** — T_agg must be a total function before iteration means anything | Well-definedness of T_agg | Yes — badge conditionality; transitive pricing at Finding 1 |
| L2.1 | Paper 11 §4.1 | **No** — the claim is the governance of that source | Paper 11 §4.1/claim 41/R15 | Yes — inheritance line |

**GS4-C conclusion.** No sampled claim has an *unnamed* load-bearing
dependency whose removal silently collapses it — every collapse point
found is named in the claim, its badge, or §0.4(b), with two exceptions
of degree: L7.3's silent consumption of L7.2's identification, and
L10.1's badge crediting the corroborator instead of the carrier. The
dependency *graph* is honest; the dependency *pricing* is not, at
exactly the point the paper itself flags (Finding 1).

---

# WORKBOOK 5 — GS4-D PROOF–CODE SEPARATION PAIRS (sampled hybrid claims)

The sampled hybrid claims are L11.4-P12 and L7.3-P12. For each: (P) the
general proof from printed premises, written without citing the script;
(C) an independent reproduction of the finite machine-checked range,
written without citing the proof. My reproduction artifact:
`gs4d_independent_check.py` + `gs4d_independent_check_output.txt` in
this directory (written from the printed definitions alone; it does not
import, extract, or read A.14 or A.6).

## L7.3-P12
**(P) General proof (prose leg, restated from §7's printed premises).**
Eq. (7.3) defines D(P, W) = R(P, W)/(|P|·|W|) with R(P, W) = Σ_b R_b,
R_b = Σ_{τ∈W} r_b(τ), all counts integers; a ratio of two integers is an
exact rational — rationality in general, no script involved. For the
mean-of-locals: each local density over the *shared* window is
D_b = R_b/|W|; hence (1/|P|)·Σ_b D_b = (Σ_b R_b)/(|P|·|W|) = D(P, W) —
one line of exact rational algebra over the shared denominator |W|,
valid for every finite P and W. The |P| = 1 reduction is arithmetic
(D({b}, W) = (Σ_τ r_b(τ))/|W|); its *identification* with Paper 9 §4's
verbal definition is not part of the proof — it is the AUTHOR leg's
declared identification and the proof neither needs nor supplies it.
**(C) Independent reproduction (finite range).** From §7.5's printed
table (40 cells), my artifact recomputes body totals A=12, B=7, C=18,
D=4; R = 41; |P|·|W| = 40; D = 41/40; locals 6/5, 7/10, 9/5, 2/5;
mean of locals = 41/40. Output: "(7.4) identity on exhibited window:
PASS". Neither deliverable cites the other: (P) never mentions the
exhibited window; (C) never invokes the general algebra.

## L11.4-P12
**(P) General proof (prose leg, restated from §11.3's printed
premises).** K(P) is a lexicographic tuple of components each taking
values in a totally ordered set (integers; Res ∈ {0,1}; CenSig under the
printed descending lexicographic convention with the shorter-is-smaller
prefix rule); a lexicographic product of total orders is a total
preorder — totality and transitivity are finite arithmetic on the
definition. Name-invariance: every component is a population sum, a
junction-set aggregate, or a sorted multiset, so no component reads the
listing order of members. Tick-stability: under §4's stated dynamics
the tick acts on junction local states alone — it creates and destroys
no junction and changes no junction's consumed ports — so each body's
k_j multiset stands, with N standing B = 6N − Σk_j stands, and a count
vector's components (N, k_j multiset, B, Σs², Σu) therefore stand
componentwise, so Ntot, Ss, Su, Btot and CenSig stand; Res and Tau0
need not (T removes admissible pairs; τ falls by exactly 2 per acting
junction, Proposition 4.3). Note, hostilely: the proof's body-record
step is an *absence* argument — §4 states no tick-dynamics for
(N, Σs², Σu), and the proof reads that silence as invariance. Within
the paper's own architecture (the tick is *defined* as T applied at
junctions, §4) the reading is forced: a function defined on junction
states does not rewrite body records. Conceded as sound under the
declared premises; the blind-pass reservation is withdrawn on the
paper's text.
**(C) Independent reproduction (finite range).** From §11.3's printed
representative table alone, my artifact computes Res and Tau0 from the
printed definitions (admissible iff A = −B ≠ 0 at a position; τ = sum of
squares of presented entries) and the partial keys
(Ntot, Res, Tau0, Ss, Su): photon (1,1,0,0,0); open tilted (1,1,0,1,1);
meson-like (3,0,4,9,3); baryon-like (3,1,4,9,3); nuclei (4,1,6,8,2);
atoms (6,1,6,10,3). All five §12.1 steps are strict, each decided at
exactly the component §11.3 names (Ss; Ntot; **Res**; Ntot; Ntot), and
one parallel tick on the representatives moves only Res/Tau0
(meson-like: Res 0→1, Tau0 4→0; all other representatives' Res/Tau0
stand, baryon-like Tau0 standing at 4 as §11.3's Stutter reading
requires). Output: "L11.4 order agreement on representatives: PASS".
Btot and CenSig are never consulted by the reproduction — which is
itself the check that no step needs them. Neither deliverable cites
the other.

---

# WORKBOOK 6 — GS4-H CHANGE-LOG INTEGRITY

**Selection (recorded here before the analysis, per §6.1).** From the
frozen paper's version block (lines 69385–69425), applying the rule —
most recent change that (i) altered a claim's scope; (ii) altered a
verification script or fixture; (iii) altered a badge, dependency, or
falsification statement; one change filling two classes yields the
second class to the next most recent:

- **Class (i) SCOPE → Corrections round 7 (2026-10-28), item (1):**
  C33's killer scoped in its own text to the domain A.14's coverage
  discloses. (Rounds 8–10 record no claim-scope alteration: round 8's
  items are a script invariant, a receipt, and two text conformances;
  round 9's are register completions; round 10 expressly changed "no
  claim's content".) Round 7 item (1) also alters a falsification
  statement, so class (iii) passes down.
- **Class (ii) SCRIPT → Corrections round 10 (2026-10-31):** the
  provenance re-classing of scripts A.15, A.7, A.14, A.10 — the most
  recent change altering verification scripts (their INPUT_PROVENANCE
  blocks, listings re-embedded, Appendix C manifest rows conformed).
- **Class (iii) BADGE/DEPENDENCY/FALSIFICATION → Corrections round 9
  (2026-10-30):** L6.2-P12's claim entry and registry row conformed to
  Theorem 6.2's stated conditionality — the most recent alteration of a
  dependency statement not already selected. (Round 10 expressly
  changed no badge string; rounds 7–8's falsification/badge texts are
  either the class-(i) change itself or conformances of wording, and
  round 9's L6.2 conformance is the most recent *dependency-statement*
  alteration in the history.)

## Change 1 — Round 7, C33 scoping (scope class)
**Before (round-6 form, as the version block and §12's scope note jointly
reconstruct it):** C33's first disjunct killed L11.4's machine content
on *any* finite declared population where A.14's computed key differed
from §11.3's definition. **After (current §12 text):** the disjunct is
scoped to A.14's disclosed domain — its side-count reading of the
record's k_j component; "wherever a junction's §3 record carries a
consumed-port count different from that side count… the §11.3
definition, which reads k_j as Paper 11 §4.1's port count, and A.14's
disclosed reading separate, first at the −Btot component — such a
population stands outside this disjunct's scope".
**Log accuracy:** the round-7 entry describes exactly this difference,
names the mechanism (consumed-port count ≠ side count) and the battery
witness space (two-sided k_j = 3, 4). Accurate.
**Hostile reading (overlay §4 — what the scope statement excludes):**
this is a retreat, and a consequential one. §11.3's *definition* reads
k_j as a port count, generally. A.14 computes with a different reading.
On the divergence domain the definition's key is computed by no script,
and — after this change — can be falsified by no condition either: the
killer was amended to exempt exactly the domain where the computation
and the definition part. The claim's registry text does scope its
machine content to "A.14's enumerated domains", so the claim *as
badged* is not contradicted; what shrank is Gate 7's falsification
reach over the definition as written at §11.3. Filed as Finding 4.
**Test correspondence:** A.14 itself was not changed by item (1); the
suite tests the claim inside the disclosed domain (18/18 on the final
tree per the round-7 entry) and, by construction, nothing outside it.

## Change 2 — Round 10, provenance re-classing (script class)
**Before:** A.15's INPUT_PROVENANCE assigned single class tokens to
compound bindings (GS-3 attack Y2); L8.3's claim-list split misallocated
the all-n generality (attack D6). **After (verified by this examiner in
the current tree):** A.15's block (listing lines 14135 ff.) now classes
each member separately — T cited-paper via A.12; standings/joint counts
paper-defined via A.12; capability profile paper-defined via A.4;
outcome rules arbitrary-representative via A.4, disclosed as copies in
the verify path; taxonomy control via A.4; roles split
cited-paper/paper-defined; assignment counts paper-defined via A.5;
fixture and anchors paper-defined. A.14's block carries the regime's
standard tokens including "class=declared-assumption, inherited from
Paper 11's F.37" for the representatives' assumptions. L8.3's home
split (line 1964) and registry row now allocate identically.
**Log accuracy:** accurate, including its two self-indictments — that
one charge (Finding 2's) "stands parked… unrepaired", and that "no
script compares component-split text or provenance classes".
**Test correspondence — the hostile point:** the round's own record
concedes the current suite does **not** test the changed content. The
18/18 PASS covers script execution and (via A.9) listing/manifest
byte-identity — A.9 did in fact catch this round's own first-build
manifest lag — but the *classes themselves*, the substance of the
change, are verified by "the loop's reading", i.e. by exactly the kind
of human/agent reading this trial exists to double-check. Filed as
Finding 6.

## Change 3 — Round 9, L6.2 conditionality conformance (dependency class)
**Before:** L6.2-P12's claim entry and registry row printed a badge
shorter than Theorem 6.2's own (the §8 role-occupancy condition
dropped). **After (verified in this tree):** claim list (line 1344)
and registry row both read "[LEVEL A — conditional on Paper 11 §8.6
and on Paper 11 §8's role-occupancy assignment]", identical to the
theorem's badge (line 1236 ff.).
**Log accuracy:** the round-9 entry describes the change exactly
("the L6.2-P12 conformances restoring Theorem 6.2's stated
conditionality"), and discloses that it was found by the round's own
loop sweep, not by the two register items the author had ruled on.
**Test correspondence:** this class of error is now mechanically
guarded — H.1's check (4) (added round 4) compares every registry badge
against its home badge in full, conditional clauses included, with
planted mutants; the L6.2 seam is precisely its target class. The
suite's 18/18 on the round-9 final tree therefore does test the changed
surface. **Verdict: change-log integrity HELD for Change 3** — log
accurate, before/after reconstructible from the paper alone, test
correspondence present.

---

# FINDINGS

### FINDING 1 -- Transitive bridge-rule residue: L5.4-P12 (and L10.1-P12) printed above the price the paper itself computes
- Target claim: L5.4-P12 (§5; Theorem 5.4, line 777; claim list lines 1131–1143; registry line 2840) — with L0.2-P12 (§0 claim list, line 102) as the rule claim it violates
- Exact target text: L5.4 registry badge: "[LEVEL A — scoping result, resting on L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, and §3 — through Theorem 4.2, on §4.3 as received at §4, its bonding-mode condition standing as §0.4(b)'s declared receipt]". Rule text (§0.3, line 73): "**Bridge rule** (from Paper 10.5, carried through 11.5): L_claim ≤ min(L_i) — a claim cannot outrank its weakest dependency." L0.2-P12 (line 102): "No claim in this paper outranks its weakest dependency (bridge rule, §0.3). **[LEVEL A: AUTHOR]** — procedural declaration; its enforcement artifact is the registry audit (script H.1), and a registry row violating the rule fails that script." Counter-text (§0.4(b), line 91): "Priced transitively through this receipt, the claims consuming the premise stand one grade below their printed conditional badges; that residue, recorded by the X2 diagnosis, stands until the author rules the bridge rule's registry-keyed reading governs or the premise is registered at its source."
- Domain and required property: Badge pricing over the sample. The claim's own requirement — from §0.3's bridge rule and L0.2's declaration, both the paper's, not this examiner's framework — is that no printed badge exceed the weakest dependency's grade, transitively, since the rule is stated over dependencies and L5.4's own badge prints the chain (Theorem 4.2 → §4.3 → the bonding-mode premise) along which the price must run.
- Sources used: packet/Paper_12_v4.md (SHA-256 fc0499af…f473150, recomputed); packet/paper2_section11.txt (ad4c0e3d…) for the premise's unbadged home status
- Method and complete test space: Textual tracing of every sampled claim's full dependency chain against §0.3's rule (Workbook 1); inspection of H.1's printed check list (listing at line 16886 ff.: checks (1) taxonomy, (2) machine grounding, (3) scope-fit heuristic, (4) registry-vs-home identity — no pricing check exists among them). Test space: all twelve sampled chains; the residue touches two (L5.4 directly, L10.1 at one further remove, exactly as §0.4(b) names them).
- Witness / artifacts: Textual witness pair verifiable by inspection — (i) §0.3 line 73 + L0.2 line 102 versus §0.4(b) line 91's concession that transitive pricing puts the consuming claims "one grade below their printed conditional badges" with the residue standing unresolved; (ii) second, independent route: L10.1-P12's badge (line 2331) prints "[LEVEL A: MACHINE — script A.3, conditional on A.2]" while §0.4(b) names L10.1 among the claims resting on Theorem 4.2 through A.2 and covered by the same residue — and H.1's four checks, the artifact L0.2 names as the rule's enforcement, contain no check capable of failing a mispriced row, so L0.2's stated falsifier mechanism cannot fire on the very violation §0.4(b) records.
- Coverage map: (1) native domain: all claims consuming the §6.1 bonding-mode premise directly or at one remove, as §0.4(b) enumerates them. (2) verified domain: the two sampled members of that class (L5.4, L10.1) plus the rule texts and H.1's check list. (3) map between them: §0.4(b)'s own enumeration names the class; the sample intersects it in exactly the two claims traced. (4) what the map preserves: badge strings, chain structure, and the paper's own transitive-pricing statement, verbatim. (5) what stays outside: the non-sampled consuming claims (L4.2, L4.3, L4.4, L5.3 item (iii), §11.2's clause (i)) — the same residue applies to them by §0.4(b)'s text, but this examiner did not independently re-trace their badges.
- Category (self-classified, spec section 9.5): A
- Proposed badge: BROKE
- Reason: Hostile case first: L5.4's *content* (the dissolution, Theorem 5.4's case analysis) is not impugned — what is broken is its badge under the paper's own pricing rule, and L0.2's declaration that the rule holds and is enforced by H.1. The paper's defence is disclosure: §0.4(b) prints the residue in the open and awaits an author ruling on the bridge rule's "registry-keyed reading". Disclosure does not cure the contradiction, because L0.2 does not print "no claim outranks its weakest dependency except as §0.4(b) records"; it prints the rule flat, at [LEVEL A: AUTHOR], with a falsifier mechanism (H.1) that cannot detect the recorded exception. Two of the paper's own sentences cannot both be true: either pricing is transitive (bridge rule + §0.4(b)'s computation) and L5.4/L10.1 are mispriced by one grade, or pricing is registry-keyed and §0.3's rule as printed does not say what governs. Until the author's ruling lands, the badge as written fails requirement (ii) under the paper's declared premises — the strict rule is met on the paper's text alone. Concession recorded: the defect is fully disclosed at §0.4(b); nothing is concealed, and no content claim falls with the badge.

### FINDING 2 -- Hybrid AUTHOR legs carry prose derivations, against §0.2's definition of the AUTHOR subtype
- Target claim: L11.4-P12 (§11.3; claim list line 2677; registry line 2884) — lead instance; L7.3-P12 (sampled) and L3.4-P12, L8.3-P12, L11.1-P12 (same class, outside the sample) as the pattern
- Exact target text: §0.2 (line 49): "**[LEVEL A: AUTHOR]**: The declared-axiom subtype of Level A… Declaration-backed, not derivation-backed." §0.2 (line 50): the hybrid's declared part "is carried under the [LEVEL A: AUTHOR] discipline". L11.4's split (line 2677): "AUTHOR: … and the tick-stability theorem in general, carried by §11.3's prose proof from §4…; the general order properties as properties of the definition (totality, transitivity, name invariance), which are §11.3's finite-arithmetic reading of the definition". L7.3's split: "AUTHOR: the (7.4) identity in general, carried by §7.3's prose (exact rational arithmetic over the shared denominator |W|); D(P, W)'s exact rationality in general, carried by §7's prose".
- Domain and required property: All hybrid claims. The requirement is the paper's own (§0.2): content carried in an AUTHOR leg is declaration-backed; a prose proof is derivation-backed by definition. The requirement is of the badge system, not of this examiner's framework.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150)
- Method and complete test space: Full split audit of all nine hybrid-badged claims in Appendix B (Workbook 2), reading each AUTHOR leg's contents against §0.2's subtype text. Test space: L3.4, L7.2, L7.3, L8.3, L9.5, L11.1, L11.4, LD.8, LE.2 — the paper's complete hybrid population.
- Witness / artifacts: Textual witness pair — §0.2 line 49 ("Declaration-backed, not derivation-backed") against L11.4 line 2677 ("carried by §11.3's prose proof") and L7.3's split ("carried by §7.3's prose (exact rational arithmetic…)"). Second, independent route: the paper's own version block, round 10 (line 69425), records this identical charge as standing "parked for the author's ruling, unrepaired: that prose-proved general content carried in an AUTHOR leg sits against §0.2's text for that subtype ('Declaration-backed, not derivation-backed') — its settlement is a definitional ruling… outside this round's repair scope." A third route: L8.3's AUTHOR leg carries "the all-n generality of (8.7)… carried by §8.3's printed induction" (line 1964) — an induction is a derivation in anyone's vocabulary.
- Coverage map: (1) native domain: the hybrid badge form as §0.2 defines it, over all hybrid claims. (2) verified domain: all nine hybrid claims' splits, read in full. (3) map between them: identity — the audit population is the whole hybrid population of the registry. (4) what the map preserves: the exact allocation text of each leg, home and registry. (5) what stays outside: whether the prose derivations themselves are *correct* — for the two sampled hybrids this examiner verified them independently (Workbook 5) and they are; the finding is about the badge form's conformance to its own definition, not about mathematical content.
- Category (self-classified, spec section 9.5): A
- Proposed badge: BROKE
- Reason: The hostile case: a reader who trusts §0.2 learns that whatever sits in an AUTHOR leg is a declaration — an author's act, with falsifiers of the declaration kind. In fact the legs carry the paper's general theorems (tick-stability in general; the all-n induction; grouping-independence in general; identity (III) in general), i.e. the strongest derivation-class content in the paper is systematically filed under the subtype §0.2 defines as *not* derivation-backed. The halves therefore do cover each other in the one way §0.2 forbids rhetorically: the AUTHOR mark lends declaration-grade cover to derivations a reader may not think to re-check, and the derivations lend the declarations a proved air. Concessions, in writing: (i) the allocations themselves are printed in full — nothing about *which* content sits in which leg is hidden, and the round-7/8/10 repairs made the allocations exact; the defect is the subtype definition's fit to the practice, not the disclosure of the practice. (ii) The paper itself has this charge on its author's list (round-10 record), parked for a definitional ruling; this finding sustains the charge, it does not discover it. The BROKE is proposed against the hybrid badge *form as §0.2 defines it*, instantiated by L11.4 and L7.3; the underlying claims' contents are separately assessed (Workbook 5: both sampled hybrids' contents HELD).

### FINDING 3 -- L10.1-P12 wears a MACHINE badge for a claim whose general content is carried by prose
- Target claim: L10.1-P12 (§10.1, line 2331; registry line 2875)
- Exact target text: "**Claim L10.1-P12 [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)].** *Every aggregate trajectory of a finite population under T_agg is eventually periodic…*" §0.2 (line 48): "**[LEVEL A: MACHINE]**: The claim's content is the output of a named verification script… The badge is exactly as wide as its validation artifact: the script checks what the script checks, and the prose around it claims no more." The claim's Ground (line 2332): "T_agg is a total deterministic function on a finite set; iterating a function on a finite set revisits a record within (number of records + 1) steps, and determinism then forces the trajectory onto the cycle through that record forever… Verified by A.3 (orbit/census counts: enumeration of trajectories on test populations…)".
- Domain and required property: All finite populations under T_agg. The requirement is §0.2's own MACHINE definition: a MACHINE badge's content must be the named script's output, as wide as its artifact and no wider.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150), including A.3's INPUT_PROVENANCE in its Appendix C listing (T's rule class=cited-paper; TOY1/TOY2 transition tables and TOY3 re-presentation rule class=control, "declared toy systems")
- Method and complete test space: Reading of the claim, its Ground, its §10.1 clarification bracket (which enumerates what A.3 in fact verifies: every cycle of the T-systems is a fixed point; on-cycle counts 7, 49, 343 at port-vector lengths 1, 2, 3; c > 1 cycles only under the declared re-presentation control), and A.3's provenance block. Test space: the claim's full stated domain versus A.3's full stated coverage.
- Witness / artifacts: Textual witness pair — the universal claim sentence (line 2331, "Every aggregate trajectory of a finite population") against A.3's provenance (toy systems as controls; test populations), with the Ground paragraph (line 2332) standing between them as the actual carrier. Second route: §10.1's own bracket concedes the division of labour — the scope exclusion in the same paragraph is separately badged "[LEVEL A: AUTHOR]" and the bracket "covers only the A.3 items it enumerates", an admission that parts of this claim's apparatus need non-MACHINE badges; the general periodicity sentence, whose proof is the prose Ground, is the one part that did not get one.
- Coverage map: (1) native domain: every finite population's every trajectory under T_agg. (2) verified domain: A.3's test populations and toy systems, plus the prose Ground's domain — which is the whole native domain, since the finite-set argument quantifies over no particular population. (3) map between them: the Ground is the map; A.3 samples it. (4) what the map preserves: eventual periodicity and the exactness of (p, c) as counts. (5) what stays outside: nothing about the claim's *truth* — the prose argument is a complete and correct finite-arithmetic proof, and this examiner concedes the claim's content HELD; what is outside A.3's artifact is the generality the badge credits to it.
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: This is the mirror image of the defect class this role was chartered to reopen: there, prose content hid inside a machine leg's enumeration verbs; here, a complete prose proof is badged as if it were a script's output. Under §0.2, [LEVEL A] plain (prose-proved with no gaps) or an explicit split is the honest mark; [LEVEL A: MACHINE] asserts the content is A.3's output, and A.3's output covers test populations and declared toy systems. The badge is therefore wider than its validation artifact in exactly the dimension §0.2 names. LIMIT, not BROKE: the claim is established — by the prose the badge fails to credit — so the correct disposition is a badge correction, not a claim failure. Concession: the paper's practice elsewhere (L10.3's scope sentence badged AUTHOR in the same paragraph) shows the apparatus knows how to make this distinction; L10.1 is the seam it missed.

### FINDING 4 -- GS4-H Change 1: round-7 scoping of C33 exempted exactly the domain where A.14's computation and §11.3's definition separate
- Target claim: L11.4-P12 (§11.3), via falsification condition C33 (§12)
- Exact target text: C33's scope note (§12): "wherever a junction's §3 record carries a consumed-port count different from that side count (the two-sided junctions with k_j = 3 or 4 of the battery's witness space; a junction of any side count consuming more ports than its sides), the §11.3 definition, which reads k_j as Paper 11 §4.1's port count, and A.14's disclosed reading separate, first at the −Btot component — such a population stands outside this disjunct's scope, the disjunct's scope being the claim's: L11.4-P12's machine content is asserted over A.14's disclosed domains, and outside them no machine content is claimed for this condition to kill."
- Domain and required property: Falsification reach over §11.3's definition, whose domain is all declared populations and whose k_j is Paper 11 §4.1's port count (§0.5's terminology note; §11.3 definition). The claim-as-written at round 6 (when C33 was created) made A.14's fidelity to that definition killable on any finite declared population; the requirement tested here is Gate 7's: a real falsifier identifiable for the Level A claim's stated content.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150) — §11.3 definition and key, §12 C33 with its round-7 scope note, version block rounds 6–7 (lines 69419–69420)
- Method and complete test space: GS4-H reconstruction (Workbook 6, Change 1): before/after of C33 from the version block and the current text; comparison of the definition's k_j reading against A.14's disclosed side-count reading (A.14's provenance/coverage and C33's own note). Test space: the divergence domain the note itself defines (consumed-port count ≠ side count).
- Witness / artifacts: Textual witness pair — §11.3's definition (K computed from §3 records, k_j as port count) versus C33's scope note conceding the two readings "separate, first at the −Btot component" on the divergence domain while placing that domain outside the killer's scope. Second route: the version block's round-6 entry records C33 created with the key "machine-checked over the enumerated domains of new script A.14" and round 7's entry records the scoping as a repair of a battery BROKE — i.e. the falsifier was narrowed *after* a witness in the exempted domain was produced, the classic shape of a retreat, however disclosed.
- Coverage map: (1) native domain: all declared populations under §11.3's definition. (2) verified domain: A.14's disclosed domains, where side count and port count coincide or the reading is otherwise as disclosed. (3) map between them: A.14's reading of the record's k_j component. (4) what the map preserves: the key's values wherever the two counts agree. (5) what stays outside: every population with a junction whose consumed-port count differs from its side count — there the definition's −Btot (and CenSig, via B in the count vector) is computed by no script and killable by no condition.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: Hostile case: a scope statement was read, per the overlay, as a retreat — and it is one in effect: the one region where the machine check is known *not* to implement the definition as written has been placed beyond falsification, rather than the computation being extended to the definition or the definition's claim being narrowed at §11.3 itself. Concessions the evidence forces: the change log describes the difference accurately and by its mechanism (Workbook 6); L11.4's registry and claim-list texts do scope the machine content to A.14's disclosed domains, so the *badged claim* does not assert what C33 no longer tests; and on A.14's actual domains this examiner's independent reproduction (Workbook 5) confirms the key. The LIMIT attaches to L11.4's machine content read against §11.3's general definition: evidence supports it on a proper subset of the definition's domain, and the exact boundary is the side-count/port-count divergence named above. Category B: what is missing is a derivation/computation of the definition's key over the divergence domain, which the claim's general definition requires and no artifact supplies.

### FINDING 5 -- L9.4-P12 carries a label that §0.2's badge taxonomy does not define
- Target claim: L9.4-P12 (§9 claim list, line 2288; registry line 2871)
- Exact target text: "[Construction — Paper 12; components inherited as cited]". §0.2 (line 45): "Every claim in this paper carries an epistemic badge:" — followed by the complete list (lines 47–57): [LEVEL A], [LEVEL A: MACHINE], [LEVEL A: AUTHOR], [LEVEL A: MACHINE / AUTHOR], [CITED], [LEVEL B], [Declared assumption], [LEVEL C], [NO BADGE], Denied [Level A]. "Construction" is not among them, and §0.2 nowhere defines non-grade categories.
- Domain and required property: The saturation census construction (Paper 9 §6 + Paper 10 eq. (2.4) summation). The requirement is §0.2's own universality sentence plus L0.1-P12's falsifier (line 101: "any claim in this paper found carrying a badge its stated backing does not support is a defect against this declaration"): a claim's mark must be one whose backing rules a reader can find in §0.2.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150); packet/paper9.txt (defe9cdc…) lines 461–466 and packet/paper10.txt (f4b1372f…) line 985 verifying the inherited components exist as cited
- Method and complete test space: Comparison of L9.4's mark against §0.2's taxonomy; search of the paper for any §0.2-level definition of the "Construction" category (found only inside script H.1's docstring, listing lines ~16890–16894, where "[Construction]" appears among "the paper's declared non-grade categories" — declared, in the event, by the checking script's own docstring in Appendix C, not by §0.2). Test space: all sampled claims' marks checked against the taxonomy (L9.4 is the only sampled instance; the same label family serves L7.4, L8.5, L9.2, LD/LC definitions paper-wide).
- Witness / artifacts: Textual witness pair — §0.2 lines 45–57 (the closed taxonomy) versus line 2288/2871 (the extra-taxonomic mark). Second route: H.1's docstring concedes the taxonomy needs supplementing ("or one of the paper's declared non-grade categories") while §0.2 — the section H.1's own provenance block cites as the taxonomy's source ("Badge taxonomy: class=paper-defined (Paper 12 §0.2…)") — contains no such categories; the supplement's only home is the script that enforces it.
- Coverage map: (1) native domain: the claim's construction content (J_sat, saturation fraction, regime change). (2) verified domain: the inherited components (Paper 9 §6 step 1 verified in the packet; Paper 10 eq. (2.4) verified in the packet) and the mark's textual status. (3) map between them: none needed — the finding is about the mark, not the mathematics. (4) what the map preserves: the construction itself is untouched; its components check out as cited. (5) what stays outside: Paper 7 (the Threshold), not in the packet — but the claim expressly makes the Threshold non-load-bearing (Workbook 4), so its absence is a coverage boundary, not evidence.
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: Hostile case: "Construction — components inherited as cited" carries no grade, no falsifier discipline, no pricing rule, and no subtype propagation — a reader applying §0.4's inheritance rule to L9.4 cannot compute what the claim is worth, because §0.2 never tells them what a Construction is worth. Every other sampled claim can be priced from §0.2 alone; L9.4 cannot, and it is load-bearing paper-wide (§9's regime-change construction, C30's target). Concession: the label is used consistently, H.1 recognizes it, and the claim's text fully discloses its components and their sources — the construction is honest; its *epistemic price tag is missing from the price list*. LIMIT: the claim's content is supported by its cited components as far as this examiner traced them; its badge cannot be decided at §0.2's scope, which is the exact boundary.

### FINDING 6 -- GS4-H Change 2: round-10's provenance repairs are accurately logged but tested by no script
- Target claim: The round-10 change record (version block, line 69425) and the content it changed — scripts A.15/A.7/A.14/A.10 INPUT_PROVENANCE blocks; component-split allocations of L8.3, L3.4, L7.3, L11.1, L11.4
- Exact target text: Version block, round 10: "It is likewise recorded plainly that no script compares component-split text or provenance classes — H.1's registry check covers badge strings — so the splits and classes repaired in this round are text records verified by the loop's reading, not machine-checked content." And: "Verification status (corrections round 10): … extraction to the layout of §C.1 and the full suite were run on this final tree: 18/18 PASS (2026-10-31)."
- Domain and required property: GS4-H / Gate 6 — sampled changes trace old text → new text *with corresponding tests*. The requirement is the trial's (§6 charter item (6): "checking… that the current suite tests the changed claim"), applied to the change the §6.1 rule selected.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150) — version block line 69425; A.15's current INPUT_PROVENANCE (listing lines 14135 ff.); A.14's current provenance classes; L8.3's home split (line 1964) versus its registry row; H.1's check list (line 16886 ff.)
- Method and complete test space: Before/after reconstruction from the version block; direct verification of the *after* state in the frozen tree (A.15's block now classes compound bindings per member, as the log says; L8.3's allocations now agree home↔registry); enumeration of what the 18-script suite checks (H.1 checks (1)–(4); A.9 listing/manifest byte-identity) against the change's substance (provenance classes; split allocation text).
- Witness / artifacts: Textual witness pair — the round-10 record's own two sentences quoted above: the change's substance is "not machine-checked content", while the same entry's verification status reports the suite green on the final tree, a juxtaposition a reader can misread as the suite covering the repair. Second route: H.1's printed checks confirm independently that no check compares split text or provenance classes; A.9's check, which *did* catch this round's manifest lag, covers byte-identity of listings, not the correctness of the classes inside them.
- Coverage map: (1) native domain: the round-10 change's full content. (2) verified domain: the after-state of A.15/A.14 provenance text and the L8.3 allocation, verified by this examiner's reading (not by any script). (3) map between them: the version block's itemization, which this examiner confirmed item-by-item for A.15 and L8.3 and spot-confirmed for A.14. (4) what the map preserves: the log's accuracy — every checked item in the log matches the tree. (5) what stays outside: A.7's and A.10's edited blocks (described in the log; not independently re-read by this examiner), and any machine test of the changed substance — none exists.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: The change log is *accurate* — this examiner verified its central items against the tree and found no discrepancy, and the log discloses the test gap in its own text, so there is no concealment and no basis for BROKE. But Gate 6's test-correspondence limb fails for this change on the paper's own admission: the 18/18 PASS that closes the round does not test a single provenance class or split allocation the round changed; the verification of record is an agent loop's reading. A change whose substance no script tests is a change the next silent edit can undo without any gate firing — the exact failure mode H.1's check (4) was built, in round 4, to close for badge strings and has not been extended to the text classes round 10 repaired. LIMIT: log integrity held; test correspondence absent, boundary exactly as named.

### FINDING 7 -- L11.4's agreement with Paper 11 §12.1: the LEVEL B target does not cap the agreement claim (argued hostile, conceded)
- Target claim: L11.4-P12 (§11.3) — the overlap component ("on the representatives constructed at §11.3 it agrees with Paper 11 §12.1's ordering at every step")
- Exact target text: §0.3's [L1-P12] entry (line ~71): Paper 11's "§12 ordering material — the six-class ordering of §12.1 ([LEVEL B] at its home), which §11.3 takes as the agreement target… Entered under this label for §11's consumption, at its home standing — not a Level A inheritance… Each item stands in this list at the standing its home gives it; being listed upgrades nothing." Paper 11 v69, line 1008: "### §12.1 The Ordering [LEVEL B]".
- Domain and required property: The overlap sentence of L11.4. Hostile construction (overlay instruction 1–2): the bridge rule (line 73) caps a claim at its weakest dependency; the agreement's content depends on §12.1's ordering, which stands at LEVEL B at home; therefore the overlap component may not ride at Level A in any leg, and its machine verification by A.14 verifies agreement with a Level B text.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150); packet/paper_11_v69.md (f77c473e…) lines 1008, 1052
- Method and complete test space: Dependency tracing of the overlap component (Workbook 1, Workbook 4 row: remove §12.1 and the key stands, only the agreement sentence loses its target); reading of §0.3's fence and §11.3's overlap paragraph; this examiner's independent reproduction of the agreement itself (Workbook 5: all five steps strict, decided at the named components).
- Witness / artifacts: `gs4d_independent_check.py` / `gs4d_independent_check_output.txt` (agreement reproduced from §11.3's printed table and Paper 11's printed order, PASS); textual pair §0.3's fence versus §0.3's bridge rule.
- Coverage map: (1) native domain: the six-class overlap on representatives and homogeneous families. (2) verified domain: the representatives (Workbook 5 reproduction); homogeneous families stand on A.14's record, not independently re-run by this examiner. (3) map between them: the representatives are §11.3's own constructions; §12.1 enters only as a printed list of six names in an order. (4) what the map preserves: the order relation and each step's deciding component. (5) what stays outside: §12.1's own *derivation* in Paper 11 (its Level B grounds — the §12.1 record values and declared assumptions there), which the agreement claim does not consume as a premise.
- Category (self-classified, spec section 9.5): D
- Proposed badge: HELD
- Reason: The evidence talks the hostile construction down, and the concession is recorded as the overlay requires. The bridge rule prices *dependencies* — premises a claim's truth rests on. The agreement claim's truth rests on (a) this paper's representatives (its own construction, AUTHOR leg) and (b) the *statement* of §12.1's order, which functions as data — a fixed target list — not as a proved premise whose grade transmits. Checking that a computed order matches a printed list is a computation whose reliability does not inherit the list's epistemic grade, any more than checking a quotation inherits the quoted paper's grade (cf. L1.2, priced [CITED] for its fidelity claim, correctly). The paper fences the point itself: §12.1 is entered "not [as] a Level A inheritance", "being listed upgrades nothing", and §11.2/§11.3 disclose "[LEVEL B] at its home" at the consumption sites; the round-9 version-block entry records the same pricing question (GS-3's Y5) adjudicated on this reasoning. What survives of the hostile argument is only the observation that a careless reader could mistake "agrees with §12.1" for "§12.1 is Level A" — a reader-risk the paper's fences address at every site this examiner checked. Classified D (a disagreement about how the pricing rule should be read, i.e. about the framework's foundations of badge arithmetic) and proposed HELD.

### FINDING 8 -- Conventional-gatekeeper objections to L7.3 and L10.1, filed under the strict rule as framework disagreements
- Target claim: L7.3-P12 (§7.3) and L10.1-P12 (§10.1)
- Exact target text: L7.3: "D(P, W) (7.3) is an exact rational; for |P| = 1 it reduces to Paper 9's §4 definition at the single body, and over a shared window it equals the mean of the local densities (7.4)." L10.1 (line 2331): "Every aggregate trajectory of a finite population under T_agg is eventually periodic…"
- Domain and required property: As the overlay directs, this examiner pressed the conventional arsenal: (i) D(P, W) is window-relative with no thermodynamic limit, no continuity in W, and no demonstrated convergence to any intensive quantity — a "temperature" that changes when the window moves is, conventionally, not a state function; (ii) eventual periodicity of a finite deterministic system is a triviality that buys no approach to equilibrium, no ergodicity, and no mixing — the conventional content of statistical mechanics is absent.
- Sources used: packet/Paper_12_v4.md (fc0499af…f473150) — §7.6 scope bullets; §10.1 clarification; L8.10/L9.6 open-joint statements
- Method and complete test space: Strict-rule test applied to each objection: (i) exact claim quoted (above); (ii) the requirement must be a requirement *of the claim* — neither claim asserts a limit, a state function, window-independence, ergodicity, or approach content; §7.6 expressly disclaims a window-free density, and §§8.6/9.6 expressly disclaim any drift/approach theorem; (iii) no failure under the paper's declared premises is constructible — this examiner attempted witnesses (window-dependence of D; fixed-point rest in Appendix D's exhibit) and each is not merely consistent with the claims but printed in the paper as their stated scope.
- Witness / artifacts: §7.6 ("D(P, W) is a property of the pair (population, window)… there is no window-free density in the ledger, and this paper does not define one"); §9 list L9.6/L8.10 (the open joint, not claimed). No artifact can witness a defect the claims do not assert.
- Coverage map: (1) native domain: the claims as written. (2) verified domain: the claims as written — both reproduce/prove clean at their stated scope (Workbooks 4–5). (3) map between them: identity. (4) what the map preserves: everything the claims assert. (5) what stays outside: everything the conventional framework would want asserted — limits, state functions, ergodicity, a Stage P bridge from D to a measured kelvin scale beyond §7.4's single declared bridge sentence (a category C observation about the bridge sentence's thinness is available to the adjudicator, but the bridge sentence asserts representation, not calibration, and is priced as a bridge, so no LIMIT is proposed on it here).
- Category (self-classified, spec section 9.5): D
- Proposed badge: OUTSIDE
- Reason: Filed so the record shows the hostile arm ran its chartered arsenal and where it landed: these objections measure the paper against requirements of the continuous-calculus framework it departs from, not against requirements of its claims. Under the strict rule they are statements of philosophical incompatibility (category D), and the tested properties are not asserted by the target claims (OUTSIDE). They move no badge. The genuine defects this arm found are Findings 1–6, every one of them internal to the paper's own rules.

---

# PROCESS STATUS

Process vocabulary only (spec §9.4), per item:

- Frozen paper `Paper_12_v4.md`: READ; hash independently recomputed and matched to the brief (SOURCE-VERIFIED).
- `protocol_examiner_extract.md`: READ (SOURCE-VERIFIED by hash).
- `sample_selection.txt`: READ (SOURCE-VERIFIED by hash).
- `roleC_only/blind_claims.md`: READ (SOURCE-VERIFIED by hash); blind classifications SEALED in `BLIND_CLASSIFICATIONS_SEALED.md` (SHA-256 ef6562f464c8f7a469a023893c627e6c069461213b718e499b04ea292bc3947f) before Appendix B or claim-list badge strings for sampled claims were consulted for the blind pass. One incidental exposure is disclosed: an early taxonomy grep for §0.2's badge definitions surfaced, in its tail, §11 home-section lines for L11.2/L11.3 (their in-text claim statements at lines 2630/2641) — home text, not Appendix B or a claim list; the sealed blind classifications were nevertheless written from the blind packet's contents and reasoning alone, and for L11.3 the blind classification recorded is UNDETERMINED, which the incidentally seen home text would not have produced. The reveal addendum will price any effect.
- `blind_verification.txt`: READ (SOURCE-VERIFIED by hash).
- `paper2_section11.txt`: READ in part — the §11 preamble surplus definition, §§11.4–11.5 passages quoted at Paper 12 §11.3 verified at the source (SOURCE-VERIFIED for those passages; the full file NOT READ end-to-end).
- `paper9.txt`: READ in part — §4 temperature definition (line 244) and §6 cascade step 1 (lines 461–466) verified (SOURCE-VERIFIED for those passages; full file NOT READ).
- `paper10.txt`: READ in part — eq. (2.4) (line 985) and §2.2 partition verified (SOURCE-VERIFIED for those passages; full file NOT READ).
- `paper_11_v69.md`: READ in part — §12.1's [LEVEL B] standing (lines 1008, 1052), R15 (line 1693), F.41 summary (line 1619) verified (SOURCE-VERIFIED for those passages; full file NOT READ). Paper 7 (the Threshold, a cited non-dependency of L9.4) is NOT in the packet: NOT READ — recorded as a coverage boundary, not as evidence.
- `paper_11_5_v26.md`: READ in part — §11.6 debt text (line 2806) verified against §1.2's quotations (SOURCE-VERIFIED for that passage; full file NOT READ).
- Paper 12: READ — §§0–13 claim lists and homes for all twelve sampled claims, Appendix B registry in full, Appendix C listings for H.1, A.15, A.14 (provenance/coverage), A.3 (provenance), FW.1 (site), Appendix D/E claim lists for the hybrid audit, and the complete version block (lines 69385–69425). The paper's embedded suite was NOT RUN by this examiner (Role D's charter); all suite results cited are SOURCE-REPORTED from the version block and registry preamble, and no finding above rests on a suite result except Finding 6, which rests on the paper's own statement of what the suite does not check. NOT RUN / NOT REPRODUCED as to the suite.
- Own computation: `gs4d_independent_check.py` RUN by this examiner; output in `gs4d_independent_check_output.txt` — L7.3 exhibited-window identity REPRODUCED independently of A.6; L11.4 representative agreement and deciding components REPRODUCED independently of A.14. A.14's and A.6's full domains: NOT REPRODUCED (Role D's charter).
- GS4-B blind pass: SEALED (see above). The paper's actual labels are known to this examiner from the main examination; the REVEAL_ADDENDUM.md resolving each disagreement will be written only on the coordinator's follow-up reveal, without editing this submission or the sealed blind file.
- Files written (all in this submission directory): SUBMISSION.md; BLIND_CLASSIFICATIONS_SEALED.md; gs4d_independent_check.py; gs4d_independent_check_output.txt. SHA-256 of each is listed in the final reply to the coordinator.
