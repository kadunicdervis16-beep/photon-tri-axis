# GS4-B BLIND CLASSIFICATIONS — ARM H, ROLE C — SEALED BEFORE LABEL REVEAL

Basis: packet/roleC_only/blind_claims.md ONLY (SHA-256
4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f), plus the
badge taxonomy printed at Paper 12 §0 (lines 45-58 of the frozen paper:
[LEVEL A], [LEVEL A: MACHINE], [LEVEL A: AUTHOR],
[LEVEL A: MACHINE / AUTHOR], [CITED], [LEVEL B], [Declared assumption],
Denied [Level A]). No Appendix B row and no claim-list badge string for any
sampled claim was consulted for this section. One incidental exposure is
disclosed in the PROCESS STATUS of SUBMISSION.md.

Method (hostile): a claim gets the strongest badge its *printed blind
evidence* forces, and no stronger. A named script with a finite coverage
statement supports MACHINE only over that finite domain. A component split
printed in the blind text is taken at face value for classification, but
any gap the blind text itself discloses is recorded as a reservation.

| Claim | Blind classification | Basis in blind packet alone |
|---|---|---|
| L11.4-P12 | [LEVEL A: MACHINE / AUTHOR] | Explicit printed split: MACHINE (A.14 enumerated domains, W1/W4, mutants); AUTHOR (definition by author's ruling 2026-10-28; representative construction under a *declared identification*; general order properties as prose finite-arithmetic reading; general tick-stability theorem by prose proof). RESERVATION: the blind text's own parenthetical says §4 states no tick-dynamics for body records' (N, Σs², Σu), yet the tick-stability theorem is said to be carried by prose proof "under §4's stated dynamics" — on the blind text alone the AUTHOR leg's premise base is not shown to exist. |
| L7.3-P12 | [LEVEL A: MACHINE / AUTHOR] | Explicit printed split: MACHINE (A.6: (7.4) identity on the exhibited window, worked-example arithmetic); AUTHOR (general (7.4) identity by prose; general rationality by prose; identification of the \|P\|=1 case with Paper 9 §4's *verbal* definition — an identification, i.e. declaration-class content). |
| L0.3-P12 | [LEVEL A: AUTHOR] | No named script. Content is a disposition rule (each Paper 11 §0.5-locked word's sole permitted route) — a declaration about this paper's own usage, "swept by FW.1" but with no machine coverage statement printed. Declaration-backed, not derivation-backed, on the blind text. |
| L11.2-P12 | [LEVEL A: MACHINE] | Statement is explicitly bounded to the enumerated range: identities "checked across population sizes 1–12", no size-triggered branch; scripts A.1, A.2, A.6 named. Machine badge exactly as wide as the enumerated domain. |
| L11.3-P12 | UNDETERMINED — no badge justifiable | The blind packet prints NO statement and NO dependency text and names NO script for this claim. From the blind packet alone there is nothing to classify; any badge the paper carries for it is unsupported by blind evidence. |
| L5.4-P12 | [LEVEL A: AUTHOR] | No script. The claim is that a pre-registered debt is "discharged by dissolution" — i.e. by the author's reframing of what discharges it (frequencies *resolve to* orbit counts etc.), enacted in part by a definition added in v4 (Def. 5.8) after C32 fired against the v3 form. A dissolution is a declared identification of instruments, not a derivation printed in the packet and not a machine output. |
| L8.10-P12 | CONJECTURE — no Level A badge justifiable ([LEVEL B] at most) | The blind text itself: "Conjecture, stated as a target (§8.6)… The joint itself is not claimed", and the strong form is "already refuted inside this paper". |
| L9.4-P12 | [LEVEL A] by inheritance ([CITED] components) | No script; the construction is "built by summation over Paper 9 §6's local saturation behaviour" with capacity/load "under Paper 10 eq. (2.4)" — inherited source content; the Threshold is "cited to Paper 7 and not redefined". Epistemic weight is whatever the sources carry, traced by inheritance. |
| L6.2-P12 | [LEVEL A: MACHINE] (on an inherited premise) | Script A.4 named with coverage: outcome factors through M=(n+,n−) is "class=cited-paper (Paper 11 §8.6 — the theorem's one premise, inherited)"; the factoring claim itself is checked rule-independently over a declared finite test taxonomy (e+ + e− ≤ 4) with two disagreeing arbitrary-representative outcome rules. Machine check over a finite domain on a cited premise. |
| L1.2-P12 | [CITED] | The claim asserts only that the count→weight debt "is as quoted at §1.2, including its two named items and the fill rules" (Paper 11.5 §§11.5–11.6). A quotation-fidelity claim; its weight is the source's. |
| L10.1-P12 | [LEVEL A: MACHINE] (with reservation) | Script A.3 named; but its printed coverage shows the framework inputs are T's rule (cited, Paper 11 §7.5) while the trajectory systems actually run are TOY1/TOY2/TOY3, "class=control (declared toy systems)". The blind text prints no component split separating a general prose proof from the toy-domain machine check. Reservation: as printed, the machine evidence covers toy systems; a general claim over all finite populations needs a prose leg the blind packet does not print. |
| L2.1-P12 | [LEVEL A] by inheritance ([CITED] source) | Blind text: "**** — inherited. Dependencies: Paper 11 §4.1's single-regime rule and licensed aggregate list govern every aggregate quantity in this paper." A governance-by-inheritance claim; weight is Paper 11 §4.1's. |

Sealed: written before any consultation of Appendix B or of claim-list
badge strings for the sampled claims, and before the coordinator's reveal.
