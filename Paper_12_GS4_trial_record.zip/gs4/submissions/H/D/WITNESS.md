# WITNESS — GS-4 Gold v1.0, ARM H, ROLE D — Mutation Witness, M13–M24 (spec §8.3)

Trial label: *GS-4 Gold v1.0 (house execution, two-arm isolated-context trial).*

Witness duty only: for each of M13–M24 I independently checked the runner's
record in `gs4/mutations/RUN_LOG.md` (summary table and the M13–M24 records)
against the artifacts under `gs4/mutations/artifacts/`, and checked whether
the observed behaviour so evidenced matches the pre-registered §8.2
expectation as recorded by the runner (expectation met / expectation NOT
met / boundary-confirmed). No badges are proposed and no findings about the
paper are filed here.

Method per mutation: read the decisive artifact(s) named in the runner's
record — the verification/probe output where one exists, the per-mutation
suite output (`Mxx_suite.txt`) in every case, and the standalone control
detail where one exists (M18 FW.1, M20/M21 A.14, M23 G.1, M17 A.5
baseline-vs-mutated outputs) — and compared the decisive lines, counts and
values character-for-character with the runner's quoted observation.

## Per-mutation witness table

| ID | Runner's verdict | Witness verdict |
|---|---|---|
| M13 | expectation met | **CONFIRMED** — `M13_manifest_corrupted.md` shows exactly one corrupted hash: `packet/paper9.txt` `0efe9cdc…` in place of `defe9cdc…` (first hex digit changed), the other nine entries uncorrupted. `M13_verify.txt` reports `MISMATCH packet/paper9.txt: manifest 0efe9cdc6ad3e29d… actual defe9cdc6ad3e29d…`, OK for the other 9 entries, and `RESULT: 1 mismatch(es): ['packet/paper9.txt']`. `M13_suite.txt`: 18/18 PASS. The behaviour matches the artifact evidence and the §8.2 expectation (Gate 1 hash verification flags the corruption). |
| M14 | expectation NOT met | **CONFIRMED** — `M14_probe.txt` shows the duplicated-S1 declaration `RETURNED without exception and without any duplicate rejection`; direct totals `tot_N = 9, tot_B = 44` against undisturbed `7 / 34`; census vector keys `['S1', 'S2', 'S3']` (name-keyed collapse, grouped route 7 / 34 in the FAIL lines); `R = 6, D = 1/2` against undisturbed `R = 5, D = 5/9`; and exactly the four downstream internal FAIL entries the log names — `(II) census sums to |P| = 4`, `(III) nodes grouped 7 == direct 9`, `(III) boundary grouped 34 == direct 44`, `mean of locals 5/12 == D 1/2`. No rejection and no stated duplicate rule appear. `M14_suite.txt` (baseline tree): 18/18 PASS. Observed behaviour and the NOT-met expectation both match the evidence. |
| M15 | boundary-confirmed | **CONFIRMED** — `M15_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); no script fires on the removed L11.2-P12 A.2 dependency edge. This matches the runner's record and the §8.2 declared scope boundary (no control expected; dependency completeness is Role C's audit). |
| M16 | expectation met | **CONFIRMED** — `M16_probe.txt` shows standings tick 0 `(+, 0, −)`, ticks 1–4 `(0, 0, 0)`, and counts `J_(0, 3) = 1`, `J_(0, 2) = 1`, `J_(0, 4) = 1`, `J_(1, 4) = 0` for `J(S1 = +, S3 = −)`, with the offset form likewise `J_(0, 3) = 1`, `J_(1, 4) = 0` — the tick-0 event excluded whole when the window shifts to (1, 4), no partial credit, exactly as the log records under Definition 5.8's declared-horizon rule. `M16_suite.txt`: 18/18 PASS. |
| M17 | boundary-confirmed | **CONFIRMED** — `M17_suite.txt`: 18/18 PASS, no script fires. The runner's decisive supporting claim is independently verified: `M17_A5_baseline.txt` and `M17_A5_mutated.txt` are byte-identical (`cmp` clean; both 3,058 bytes), so the proxied A.5 check passes with output text unchanged, exactly as pre-registered. No script control was expected; the control is the examiner (Role D item 6) — boundary-confirmed as recorded. |
| M18 | expectation met | **CONFIRMED** — `M18_suite.txt`: 17/18 PASS, `FW.1 FAIL (exit 1) — FW.1 VERDICT: FAIL — 1 SUSPECT hit(s)`. `M18_FW1_detail.txt` carries the decisive line at paper line 932: `[entropy] SUSPECT — orientation — the member's entropy class at that tick.`, repeated in the detail's verdict block; the only other entropy/temperature hits shown are in the controlled embedded-listing zone (line 15900). FW.1 fired on the inserted bridge word at the native definition site, as recorded. |
| M19 | boundary-confirmed | **CONFIRMED** — `M19_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); no script fires on the omission of the `S ≥ 1` assumption name at the §11.3 use site. Matches the runner's record and the §8.2 declared scope boundary (no control expected; Role C item 5 audit). |
| M20 | expectation met | **CONFIRMED** — `M20_suite.txt`: 17/18 PASS. `M20_A14_detail.txt` shows exactly the four failed checks the log names — (1a) representatives' order, (1b) named deciding components, (2) homogeneous families n = 1..4, (5) stability invariants with `violations: 2128` — and `A.14 VERDICT: FAIL — 4 check(s) failed` listing the same four. A.14's representative/order checks fired under the Ntot ↔ Res reordering, as recorded. |
| M21 | expectation met | **CONFIRMED** — `M21_suite.txt`: 17/18 PASS. `M21_A14_detail.txt` shows exactly the two failed checks the log names — (1a) representatives' order (with the tilted<meson step now deciding at Ntot) and (2) homogeneous families — with (1b) and (5) PASS, and `A.14 VERDICT: FAIL — 2 check(s) failed` listing the same two. At least one representative comparison failed under the flipped tilted sign fact, as recorded. |
| M22 | expectation met | **CONFIRMED** — `M22_probe.txt` shows the pairwise readings `sides (0,1): +`, `sides (0,2): 0`, `sides (1,2): -`; the pairwise instrument on the whole 3-sided record `REJECTED: ValueError - too many values to unpack (expected 2)`; Definition 5.7's multi-sided clause via `A15.ms_standing: +`; and the both-orientations pair `((1, -1), (-1, 1))` reading `+` under A.12 (positive precedence). Both halves of §8.2's disjunction are exhibited, as recorded. `M22_suite.txt`: 18/18 PASS. |
| M23 | expectation NOT met | **CONFIRMED** — `M23_suite.txt`: 18/18 PASS, G.1 verdict unchanged (`PASS — all 29 verbatim quotations … FOUND`). `M23_G1_detail.txt` shows at paper line 2653 one `[FOUND] inline … attributed=Paper 11` entry alongside the four advisory `[NOT FOUND]` entries for the out-of-sweep Paper 2 segments, and the closing `G.1 VERDICT: PASS`. G.1 did not fire on the mid-phrase-truncated §11.3 quotation — the truncated remainder still verifies as FOUND, consistent with the log's prefix/substring explanation for an advisory inline (not hard-verdict) quotation. Observed behaviour and the NOT-met expectation both match the evidence. |
| M24 | boundary-confirmed | **CONFIRMED** — `M24_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); neither FW.1 nor G.1 fires on the receipt→citation wording replacement at the Theorem 4.2 badge site. Matches the runner's record and the §8.2 declared scope boundary (no control expected; Role C audit). |

Summary of this witness: 12 of 12 records (M13–M24) CONFIRMED, 0 DISPUTED —
in each case the observed behaviour recorded by the runner matches the
artifact evidence, and the runner's classification against the
pre-registered §8.2 expectation (6 expectation met: M13, M16, M18, M20,
M21, M22; 2 expectation NOT met: M14, M23; 4 boundary-confirmed: M15, M17,
M19, M24) is the classification the evidence supports.

## PROCESS STATUS

READ (Role D brief; predecessor SUBMISSION.md; RUN_LOG summary table and M13–M24 records; M13–M24 artifacts as cited above) / RUN (artifact comparisons, byte-identity and hash spot-checks performed by this witness; no suite or probe re-executed — witnessing rests on the runner's preserved artifacts) / REPRODUCED (decisive lines, counts and values in every M13–M24 record reproduced from the artifacts) / SOURCE-REPORTED (mutation diffs and probe constructions as recorded in the run log; decisive observed behaviour SOURCE-VERIFIED against the artifacts) — witness complete for M13–M24.
