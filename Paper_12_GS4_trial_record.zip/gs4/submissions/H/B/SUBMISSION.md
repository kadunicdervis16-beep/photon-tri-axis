# GS-4 GOLD v1.0 — ARM H, ROLE B SUBMISSION
## Proof and Counterexample Examiner (hostile arm)

Trial label (spec §1, used exactly): *GS-4 Gold v1.0 (house execution,
two-arm isolated-context trial).* This submission is not external
validation and awards no badge; every badge below is a proposal to the
blinded adjudicator.

**Stance.** Per the hostility overlay (spec §3, printed in my brief), I
presumed every sampled claim defective, argued BROKE first for each, took
the reading least favourable to the author wherever the text admits two,
and treated disclosures as possible concealments. The overlay's strict
rule binds every finding: (i) the exact claim quoted, (ii) the requirement
the claim itself entails, (iii) the failure shown under the paper's
declared premises. Objections failing that test are filed as framework
disagreements (category D), never as defects.

**Frozen paper verified by my own recomputation:**
`Paper_12_v4.md` SHA-256 =
`fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150`
(matches the brief's freeze value), 69,425 lines.

**Packet source hashes (recomputed by me):**
- Paper_12_v4.md — fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150
- paper_11_v69.md — f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb
- paper_11_5_v26.md — 9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60
- paper9.txt — defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6
- paper10.txt — f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82
- paper2_section11.txt — ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e
- protocol_examiner_extract.md — f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1
- sample_selection.txt — 588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766

**The twelve-claim sample** (packet/sample_selection.txt):
L11.4-P12, L7.3-P12, L0.3-P12, L11.2-P12, L11.3-P12, L5.4-P12, L8.10-P12,
L9.4-P12, L6.2-P12, L1.2-P12, L10.1-P12, L2.1-P12.

**Artifacts in this directory:**
- `witness_boundary.py` — independent implementation of T, T_agg, census,
  flow/joint counts, standings, D(P,W), Ω, the equilibrium predicate, the
  saturation census, the molecule flattening, and K, written from the
  prose definitions only, before any script consultation. Exit 0; 34
  checks PASS, 0 FAIL (run log reproduced in the derivation log below).
- `witness_alternatives.py` — GS4-F alternative representatives for
  L11.4-P12 and the L6.2-P12 profile-reading witness. Exit 0; 8 checks PASS.

---

# DERIVATION AND BOUNDARY LOG (non-finding material)

## Method and script-consultation log (charter item 1)

Each selected theorem was derived independently from the paper's prose
(§§0–11 home sections and claim lists) **before** any verification script
was opened. Script consultation afterwards, logged honestly:

- A.4 (for L6.2-P12): docstring/coverage block read AFTER my derivation
  and after `witness_alternatives.py` was written. A.4's model represents
  an encounter kind by its profile M(E) and runs outcome rules that are
  functions of (M(G), M(E)); see Finding 6 for what that does and does
  not settle.
- A.14 (for L11.4-P12): docstring/coverage block read AFTER my
  independent K implementation reproduced the representatives' order,
  deciding components, homogeneous families, empty-declaration value,
  relabelling invariance, and the sharpness witness. A.14's coverage
  discloses that its declarations read the k_j multiset from the side
  count (exact where each side consumes one port) — the same disclosed
  reading C33 is scoped to; my implementation used the declared k_j
  values of §11.3's exhibit directly.
- A.1, A.2, A.3, A.6 listings: NOT READ. Their content was assessed only
  through the claim-site component splits printed in the claim lists.

## Independent derivations, claim by claim (summary)

- **L2.1-P12 (inheritance).** The §2.3 quotation was checked character-
  for-character against Paper 11 v69 §4.1 (packet paper_11_v69.md, its
  L342): the single-regime text, the licensed list (N_nodes, N_edges,
  B = 6N − Σ_j k_j, Σs², Σu), "No aggregate state alphabet. No aggregate
  budget rule. No emergence mechanism. (Audit rule R15, Appendix H;
  machine check F.41.)" — verbatim. Inheritance line at §2.3 names
  source, badge, and reliance. No derivation of my own is owed beyond
  the quote and lineage check; both pass.
- **L1.2-P12 (inheritance).** The three §1.2 quotations checked against
  Paper 11.5 v26 §§11.5–11.6 (packet paper_11_5_v26.md L2805–2818):
  "Combinatorics supplies the *counts*; the count→weight step is not
  certified here. It needs two things this paper does not build: (1) a
  microstate-counting rule, and (2) a sampling-measure postulate. Both
  are Paper 12's work."; the fill-rules sentence; and "the fill rules
  and the sampling measure are Paper 12's work, named above, not
  smuggled in here." — all verbatim.
- **L0.3-P12 (AUTHOR declaration).** The construction list at §0.5 was
  read in full; each locked word's disposition (temperature constructed
  §7; entropy bridged §8; ensemble/microstate excluded; thermal
  equilibrium constructed §9; probability distribution excluded as
  primitive; Gibbs/Boltzmann excluded as method; k_B bridged §8) is
  stated with a site. My spot sweep of the native prose found locked
  words only inside the disposition machinery itself, quotations, the
  §5 objection passage (Stage C in substance), and Theorem 5.4(b)'s
  quoted frame name. A full FW.1 sweep is Role D's artifact, not mine;
  the boundary is recorded in Finding 3.
- **L5.4-P12 / L5.3 (dissolution).** Derived the three cases from
  Definitions 5.1–5.2 and Proposition 5.3: (i)/(ii) are definitions read
  aloud — numerator and denominator are counts of actual (member, tick)
  pairs / events / ticks. (iii): fixed declared population (premise
  named in the proof), finite state set (finite inventory × finitely
  many junctions of fixed port-vector length), deterministic T_agg
  (Theorem 4.2) ⇒ eventually periodic; long-run frequency = c_X/ℓ
  exactly on whole-period windows after the transient. My artifact
  confirms the closed case (cycle = fixed point, ℓ = 1) on 300 random
  populations. (iv): joint counts marginalize and add (artifact:
  marginalization, both-members sum = |W|, additivity with an offset
  crossing the split, repeated-member tuples read literally — all
  PASS). The v3 scope sentence was falsified by C32 and the claim
  restated over the extended family; the firing is on the record at
  §12 and the restated claim is the one I examined.
- **L6.2-P12 (Theorem 6.2).** Derivation attempted from Definition 6.1
  plus Paper 11 §8.6. §8.6's coverage theorem (packet paper_11_v69.md
  L771) states the selection rule factors through the **encounter's**
  presented count vector M — same-count *encounters* select the same
  outcome, over 710,090 native→model preservation checks. Theorem 6.2's
  hypothesis speaks of what two *bodies* present. The step between
  them is where my hostile reading bites; see Finding 6 (LIMIT).
- **L7.3-P12.** Arithmetic re-derived: D_b over a shared window gives
  (1/|P|)·Σ_b (R_b/|W|) = R/(|P|·|W|) exactly; §7.5's table recomputed
  (R = 41, D = 41/40, locals 6/5, 7/10, 9/5, 2/5, mean 41/40 — artifact
  PASS). |P| = 1 reduction is the same formula at |P| = 1. The
  identification with Paper 9 §4's verbal definition is AUTHOR, graded
  as such in the claim itself. Boundary failure at |P| = 0 / |W| = 0:
  Finding 7.
- **L8.10-P12.** Not a theorem; a LEVEL B conjecture statement. I
  verified its internal factual load: (a) the strong form (rest only at
  (E2)-maximal records) is refuted inside the paper — my recomputation
  of §8.7's trajectory gives (12,0) → (6,6) → (0,12) → (0,12),
  Ω = 1, 924, 1, 1, τ_agg = 36, 12, 0, 0, and the rest record (0,12)
  is stationary with Ω = 1 < 924 (artifact PASS); (b) the relational
  form's "some populations' rest records are maximal" is constructible
  in-framework: four resting bodies under the L/R feature ψ of §10.4's
  kind, 2 in L and 2 in R, rest at (2,2) with Ω = C(4,2) = 6 = max
  (artifact PASS). The claim asserts neither the joint nor its
  negation. Category E territory, correctly labelled by the paper.
- **L9.4-P12.** §9.5's arithmetic recomputed exactly: demands
  105/88/100, total 293, booked 288, deferred 5, J_sat 0 → 2, fraction
  2/3 (artifact PASS). The construction's per-junction reading (own
  entries only, no cross-source sum of Paper 10 §2.4.7 shares) is
  stated at §9.4 and its boundary (unbookable relay demand stands in
  no category) at §9.6. Boundary failure at J(τ) = 0: Finding 9.
- **L10.1-P12.** Analytic derivation: T_agg is a total deterministic
  function on the finite record set of a finite declared population
  (multi-sided junctions enter by carry-through, still a function);
  iteration of a function on a finite set revisits a record within
  (records + 1) steps; determinism forces the cycle. Under T alone,
  τ-monotonicity (Proposition 4.3) forces c = 1 on closed trajectories
  — confirmed computationally on 300 random populations (artifact).
  Quantifier domain: trajectories *under T_agg*; open populations
  driven by undeclared external re-presentation are outside the claim
  as written ("under T_agg"), and §10.1's clarification states the
  condition for the enlarged case.
- **L11.2-P12 (§11 machine claim).** The §§3–5/§7 definitions were
  read for size-triggered branches: census (§3.3/5.1), T_agg (§4),
  flow counts (§5.2), τ_agg (§4), R and D (§7) contain no case split
  on population size or body size; each is a sum, count, or ratio over
  the declared population. The claim as written is about the
  constructions and their implementations over the enumerated range
  (sizes 1–12), and says so.
- **L11.3-P12 (§11 AUTHOR verdict).** Checked the two halves: (1)
  machinery extension — same definitional sentences as L11.2, plus
  Edges 1–3 stated (enumeration horizon; taxonomy admission of very
  large bodies; packing presupposes a declared junction graph).
  (2) "census confers no rank": the census of §3.2/§5.1 is a partition
  into count-classes; no order on classes is defined by it. The
  verdict's qualification — census data may feed a *definition* (as
  CenSig feeds K) — is exactly the L11.4 situation, and the two
  claims do not contradict each other.
- **L11.4-P12.** K implemented independently (artifact). Results:
  representatives' keys reproduce §12.1's order (photon < tilted <
  meson-like < baryon-like < nuclei < atoms) with deciding components
  Ss, Ntot, Res, Ntot, Ntot exactly as §11.3 names; meson/baryon carry
  identical count vectors and separate at Res; homogeneous families
  m = 1..5 preserve the chain; empty declaration returns
  (0, 1, 0, 0, 0, 0, ()) as §11.3 states; K invariant under relabelling
  on 200 random populations; the Res/Tau0 sharpness witness behaves as
  stated. Tick-stability of (Ntot, Ss, Su, Btot, CenSig) follows from
  §4's stated dynamics (the tick acts on junction local states alone;
  §4 states no tick-dynamics for (N, Σs², Σu)) — an AUTHOR-carried
  premise the claim's component split names. GS4-F alternatives:
  Finding 11.

## Boundary search (charter item 2) — test-space summary

All rows executed in `witness_boundary.py` unless noted; every row PASS
except the two denominator boundaries filed as Findings 7 and 9.

| Boundary | Result |
|---|---|
| Empty population | Census identities (I)–(III) hold (0 = 0); K returns the value §11.3 states; **D(P,W) undefined (denominator 0)** → Finding 7 |
| Empty window | **D undefined at \|W\| = 0** → Finding 7; joint counts exclude it by Def 5.8's ≥ 1-tick condition |
| Singleton population | Census identities hold; D reduces per (7.3); Ω(n=1) table exact |
| Unequal sides / port-vector lengths 1–3 | T and T_agg total and deterministic; τ drop exactly 2 per acting junction on all random states |
| Repeated members | Joint tuple with a member named twice: same class twice = member's own count; two disjoint classes = 0 (Def 5.8 literal reading confirmed) |
| Junctionless bodies | Standing neutral (Def 5.7); Res = 1; trajectory frozen; **saturation fraction undefined at J = 0** → Finding 9 |
| Multi-sided junctions | Outside T's scope by Def 4.1 (carry-through); τ contribution 0; standings for side count > 2 are prose-only (A.12's coverage excludes them, disclosed at Prop 5.9) — no claim in the sample asserts a machine check there |
| Tied deciding components | Meson/baryon representatives tie at Ntot, Tau0, Ss, Su and on the full census vector; separated only at Res — as §11.3 states |
| Proper-prefix comparisons | CenSig prefix rule shown **vacuous on tie paths**: proper-prefix signatures with all earlier components tied would force Ntot to differ (each extra vector has N ≥ 1). A completeness convention for the order, not a reachable case; argued as a defect, conceded in writing — a total order may carry unreachable clauses without falsity |
| Relabellings | K invariant under member permutation (200 random populations); census/flow identities label-free by construction |
| Disconnected populations | Population definition requires no connectedness (only bodies/molecules are connected); census, tick, and K computed on junctionless and partially junctioned populations without incident |
| Composition boundaries | §11.2 molecule exhibit recomputed: (R1)–(R3) hold, B = 29 by both routes, key (7, (2,2,2,2,2,3), 29, 19, 6); exhibited regrouping (α+β merged) returns the same key — grouping-independence confirmed on the exhibit |
| Tick-offset joint counts | Additivity holds with an offset crossing the window split (Prop 5.9(ii) horizon reading) |

## Quantifier domains (charter item 3)

- L6.2-P12: ∀ bodies G, G′, ∀ ticks t, ∀ roles R, ∀ encounter kinds E
  of Paper 11's taxonomy — *provided* the hypothesis "present equal
  count profiles" is read as §8.6 requires (encounter-level profiles,
  with the encounter's other side and the body's side-position fixed by
  E). Under the own-side reading the proof does not cover the domain.
  Finding 6.
- L5.4-P12: ∀ frequency questions "inside the framework's own scope" as
  fixed by §5's expressibility calculus, over declared populations and
  windows. The calculus is a stated definition, and inexpressibility
  has a stated proof shape (two declarations agreeing on all instrument
  data, differing on the answer). No question of that shape was found
  by me that the extended family fails; the C32 precedent shows the
  shape is live, and the restated claim is the one examined.
- L7.3-P12: ∀ declared (P, W) — with |P| ≥ 1 and |W| ≥ 1 required by
  the formula and nowhere stated. Finding 7.
- L9.4-P12: ∀ ticks τ of a declared population — saturation fraction
  requires J(τ) ≥ 1, nowhere stated. Finding 9.
- L10.1-P12: ∀ finite populations, ∀ trajectories under T_agg
  (enlarged transitions only under §10.1's stated condition). Covered.
- L11.4-P12: ∀ finite declared populations at a declared tick (empty
  included, by name). Totality/transitivity are lexicographic-order
  facts; the vector-level comparison of k_j multisets of unequal
  length takes the ordinary tuple convention (shorter proper prefix is
  smaller) — §11.3 states that convention expressly for CenSig and
  A.14 implements tuple comparison throughout; I argued this as an
  unstated-convention defect and concede it: the convention is the
  standard meaning of "lexicographic as tuples," and the one place a
  nonstandard choice could hide (signature length) is stated in terms.
- L11.2-P12: ∀ test populations in the A-series batteries, sizes 1–12
  — the claim's own stated domain. Covered as written.
- L8.10-P12: no universal assertion; a conjecture about what a proof
  would need, plus two factual clauses (strong form refuted in-paper;
  maximality is population-dependent), both verified above.

## Hostile arguments argued first and conceded in writing (overlay §3.2)

1. *"D is a mean, and a mean over an imagined ensemble in disguise."*
   Conceded as a defect: D is a ratio of two actual counts over a
   declared population and window; nothing is imagined, and §7.6
   states the (population, window)-relativity in terms. The objection
   survives only as category D (Finding 13).
2. *"No continuum limit is taken anywhere, so the 'temperature' and
   'arrow' cannot connect to physics."* Conceded as a defect under the
   strict rule: the paper asserts no native bridge beyond §7.4's and
   §8.4's single declared Stage P sentences, and §1.9 states no new
   empirical prediction is claimed. Category C/D (Finding 13).
3. *"L11.4's agreement with §12.1 is an artefact of a chosen
   representative."* Partly stands as a *scope* fact (Finding 11,
   OUTSIDE/D): ALT-3 reverses the step under a different rendering.
   It does not break the claim, because the claim scopes the agreement
   to the constructed representatives under the disclosed
   identification and §11.3 itself names this rival class and its
   possible reversal. A disclosure I treated as concealment turned
   out to contain the very witness I constructed.
4. *"Theorem 5.4(b) refuses the single-tick question instead of
   answering it."* Conceded: refusing a frame and replacing it with
   the census is the claim's stated content (a scoping result); the
   refusal is printed, not hidden. Category D if filed; not filed
   separately — Finding 13 covers the class.
5. *"CenSig's prefix rule and the vector-level tuple convention are
   implementation choices dressed as a definition."* Conceded per the
   quantifier note above: the prefix branch is unreachable on tie
   paths, and the tuple convention is the standard one.

---

# FINDINGS

### FINDING 1 -- L2.1-P12 inheritance verified verbatim
- Target claim: L2.1-P12 (§2 claim list, §2.3)
- Exact target text: "The single-regime rule and the licensed aggregate list of Paper 11 §4.1 (quoted at §2.3) govern every aggregate quantity in this paper. [LEVEL A] — inherited. Inheritance: Paper 11 v69 §4.1 / claim 41 / R15 — badge at source [LEVEL A], machine check F.41 — reliance: constitution of §§3–9." (frozen paper L298; quotation at L282)
- Domain and required property: The §2.3 quotation must be Paper 11 §4.1's text, and the inheritance line must name source, source badge, and reliance.
- Sources used: Paper_12_v4.md (sha256 fc0499af…7150, recomputed); paper_11_v69.md (sha256 f77c473e…adbb, recomputed), its §4.1 at packet L342.
- Method and complete test space: Character-level comparison of the quoted block (single-regime sentence; licensed list N_nodes(G), N_edges(G), B = 6N − Σ_j k_j with pairwise corollary, Σs², Σu; the three "No aggregate…" sentences; R15/F.41 attribution) against the source passage; registry row at Appendix B (L2826 of the frozen paper) compared with the home claim.
- Witness / artifacts: Textual witness pair — frozen paper L282 vs paper_11_v69.md L342: identical in substance and wording. No computation involved.
- Coverage map: (1) native domain: the inheritance as relied on by §§3–9. (2) verified domain: the quoted passage and the inheritance line at §2.3, and the registry row. (3) map between them: direct textual identity. (4) what the map preserves: wording, the licensed list, and the source badge. (5) what stays outside: Paper 11's own F.41 check (Role D / source-paper scope); whether every later section in fact obeys the list (a whole-paper sweep, beyond this claim's quote-and-lineage content).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Quote verbatim, lineage complete, registry agrees with home. Hostile reading (the list is honoured only where convenient) found no instance in the sampled claims' constructions: every sampled aggregate quantity is a sum, count, or rational ratio over the licensed components.

### FINDING 2 -- L1.2-P12 debt quotations verified verbatim
- Target claim: L1.2-P12 (§1 claim list, §1.2)
- Exact target text: "The count→weight debt is as quoted at §1.2, including its two named items and the fill rules. [CITED — L4-P12] (Paper 11.5 v26 §§11.5–11.6.)" (frozen paper L246; quotations at L168–L172)
- Domain and required property: The three quoted passages must be Paper 11.5's text, including item (1) microstate-counting rule, item (2) sampling-measure postulate, and the fill rules.
- Sources used: Paper_12_v4.md (fc0499af…7150); paper_11_5_v26.md (9225cd8d…e60, recomputed), §§11.5–11.6 at packet L2805–L2818.
- Method and complete test space: Direct comparison of all three quotations in §1.2 against the source lines.
- Witness / artifacts: Textual witness pair — frozen paper L168/L170/L172 vs paper_11_5_v26.md L2805–L2818: verbatim, including "Both are Paper 12's work" and "not smuggled in here."
- Coverage map: (1) native domain: the debt as discharged at §§3/5. (2) verified domain: the three quotations and the claim's restatement of their contents. (3) map: textual identity. (4) preserves: the debt's two items and the fill-rules clause, unparaphrased. (5) outside: whether §§3/5 in fact discharge the debt — that is L5.4-P12's content (Finding 5), not this citation claim's.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: A [CITED] claim asserts the source says it; the source does, word for word.

### FINDING 3 -- L0.3-P12 construction-list discipline: no violation found in sampled scope
- Target claim: L0.3-P12 (§0.5 claim list)
- Exact target text: "The construction list above fixes, for each word locked by Paper 11 §0.5, its sole permitted route into this paper; any use of a locked word outside its listed disposition is a defect against this section, swept by FW.1. [LEVEL A: AUTHOR] — declared discipline; falsifier: a locked word found in this paper's native voice outside its disposition and outside a firewall exemption, standing uncorrected in a final tree." (frozen paper L145)
- Domain and required property: Every use of a locked word (temperature, entropy, Gibbs, Boltzmann, k_B, ensemble, microstate/macrostate, thermal equilibrium, probability distribution) in the paper's native voice must follow its §0.5 disposition.
- Sources used: Paper_12_v4.md (fc0499af…7150) — §§0–13 home sections read in full for the sampled claims.
- Method and complete test space: Hostile reading of the sampled claims' home sections (§§0,1,2,5,6,7,8,9,10,11) hunting native-voice uses outside disposition: "temperature" appears only as the constructed D or in disposition/quotation contexts; "entropy" only at §8.4's bridge and §8.7's attributed application; "ensemble" only in exclusion, quotation, and the §5 objection passage; "probability" only in exclusion/quotation/dissolution contexts. This is a section-level spot sweep, not the FW.1 whole-paper machine sweep.
- Witness / artifacts: None (negative search); the falsifier remains well-defined and checkable by FW.1.
- Coverage map: (1) native domain: the whole paper's native voice. (2) verified domain: the home sections of the twelve sampled claims. (3) map: same prose, read directly. (4) preserves: wording and voice (native vs quotation vs Stage C context). (5) outside: appendices, version block, and embedded listings — FW.1's domain, owned by Role D; a violation there would not be visible to this finding.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Within the verified domain the discipline holds and the claim carries its own falsifier, as [LEVEL A: AUTHOR] requires. The badge is proposed over the verified domain only; the whole-tree sweep is a process matter for Role D, recorded in the PROCESS STATUS section.

### FINDING 4 -- L10.1-P12 eventual periodicity: derived independently, domain covered
- Target claim: L10.1-P12 (§10.1)
- Exact target text: "Every aggregate trajectory of a finite population under T_agg is eventually periodic: there exist integers p ≥ 0 (the pre-period) and c ≥ 1 (the cycle length) such that the record at tick t + c equals the record at tick t for all t ≥ p. The pair (p, c) is an exact count, computable by enumeration of the trajectory." (frozen paper L2331)
- Domain and required property: For every finite population and every trajectory under T_agg (Definition 4.1, multi-sided junctions by carry-through), eventual periodicity with exact (p, c).
- Sources used: Paper_12_v4.md (fc0499af…7150), §§4, 10.1.
- Method and complete test space: Analytic derivation (total deterministic function on a finite record set ⇒ revisit within records+1 steps ⇒ cycle; τ-monotonicity ⇒ c = 1 for closed trajectories) plus computational search: 300 random populations (0–4 junctions, port-vector lengths 1–3, entries in {−1,0,+1}), full trajectory iteration to first revisit, checking periodicity, c = 1, τ drop of exactly 2 per acting junction, and order-independence under 20 shuffles per population.
- Witness / artifacts: witness_boundary.py (checks 1–4 PASS; exit 0).
- Coverage map: (1) native domain: all finite populations and all their T_agg trajectories. (2) verified domain: the analytic argument (all cases) corroborated on 300 random small populations. (3) map: populations represented by their junction local-state lists; body records do not enter T_agg's action. (4) preserves: T's action, τ, determinism, finiteness. (5) outside: enlarged transitions under undeclared external re-presentation — outside the claim as written ("under T_agg"); §10.1's clarification states the condition under which the enlarged case is covered, and §10.4's exhibit is L10.5-P12, not in this sample. A failed attack is not a proof; the analytic argument, not the 300 cases, carries the universal.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The finite-function argument is complete and gapless over the stated domain; the computational search found no counterexample and confirms the c = 1 closed-case clarification.

### FINDING 5 -- L5.4-P12 dissolution over the extended instrument family: no inexpressible frequency found
- Target claim: L5.4-P12 (§5 claim list)
- Exact target text: "The sampling-measure postulate pre-registered in Paper 11.5 §11.6 is unnecessary: long-run frequencies resolve to orbit counts, the single-tick 'ensemble' resolves to the census, the fill rules resolve to the deterministic dynamics, and named-tuple joint frequencies resolve to joint counts over the named members' records (Definition 5.8, added in v4 after falsification condition C32 fired against this claim's v3 form — the firing record stands at §12). The debt is discharged by dissolution over the extended instrument family (census, flow, joint counts), with no postulate adopted. [LEVEL A — scoping result, resting on L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, and §3 …]" (frozen paper L1131–L1143)
- Domain and required property: Every frequency question inside the framework's own scope, as fixed by §5's expressibility calculus (finite arithmetic over census, flow, and joint counts: cell sums, products over independently chosen ticks, ratios), must be expressible by the family; inexpressibility requires two declarations agreeing on all instrument data while the question's answers differ.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§3–5; paper_11_5_v26.md (9225cd8d…e60) for the debt text.
- Method and complete test space: Independent derivation of Proposition 5.3(i)–(iv) (see log); attempted counter-constructions under the calculus's own test: existence-at-a-tick frequencies (expressible: |W| minus the full-tuple joint count of the complementary standings), census-record frequencies (full-tuple joint counts), tick-pair frequencies (the calculus's product case), conditional frequencies with zero marginal (undefined by Prop 5.9(iv)'s stated condition — a stated boundary, not a silent gap), multi-sided-junction standings (Def 5.7 states them in prose; outside A.12's machine domain, disclosed at Prop 5.9). Computational confirmation of marginalization, additivity (including offset crossing a split), and repeated-member tuples in witness_boundary.py.
- Witness / artifacts: witness_boundary.py (joint-count checks PASS; exit 0).
- Coverage map: (1) native domain: all frequency questions inside the framework's scope over declared populations/windows. (2) verified domain: the four Proposition 5.3 cases as derived, plus the counter-construction classes above. (3) map: questions translated into the expressibility calculus's operations exactly as §5 defines them. (4) preserves: the distinction between counted frequencies and any function of instrument data (§5 fixes "expresses" narrowly, and I applied the narrow reading, least favourable to the author). (5) outside: systems known only by a coarse description — expressly excluded by L5.8-P12 and the §5 objection passage; questions about undeclared populations. A finite search is not a universal theorem: the HELD rests on the case analysis (a)–(c) plus Prop 5.9, which I re-derived, not on my failure to find a fifth case.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The claim as restated (the v3 form is dead, killed by C32 on the record) is a scoping result whose cases I could each derive, and the strongest hostile constructions I could build under the paper's own inexpressibility test are expressible by the extended family. The one-grade transitive residue through the §0.4(b) declared receipt (via Theorem 4.2) is printed in the claim's own pricing and at §0.4(b); it is a disclosed pricing fact, not a concealed defect.

### FINDING 6 -- L6.2-P12: proof covers the pair-profile reading only; the own-side reading is unproved and counterexemplified
- Target claim: L6.2-P12 (§6 claim list; Theorem 6.2)
- Exact target text: "Equal presented-count profiles at a tick imply equal capabilities at that tick, for every role and encounter kind: capability factors through the presented-count profile. [LEVEL A — conditional on Paper 11 §8.6 and on Paper 11 §8's role-occupancy assignment]" (frozen paper L1344–L1348); theorem statement at L1236–L1244: "If two bodies G and G′ present equal count profiles at tick t — the same presented counts to the encounters of the taxonomy — then for every role R and every encounter kind E, (E, t) ∈ Cap(G, R) ⟺ (E, t) ∈ Cap(G′, R)."
- Domain and required property: For all bodies G, G′, ticks t, roles R, encounter kinds E: the theorem's proof must establish the implication from its stated hypothesis. The hypothesis's quantifier domain is the point at issue: §8.6 of Paper 11 — the cited premise — factors outcomes through the **encounter's** presented count vector M (both sides' presentations; packet paper_11_v69.md L771: "same-count encounters always select the same outcome", 710,090 preservation checks). The claim's hypothesis speaks of what the two **bodies** present.
- Sources used: Paper_12_v4.md (fc0499af…7150), §6 (Definition 6.1 at L1218–L1234, proof at L1253–L1268); paper_11_v69.md (f77c473e…adbb), §8.6 coverage statement at its L771.
- Method and complete test space: (1) Line-by-line re-derivation: the proof's load-bearing step is "for each encounter kind E the encounter presented to G and the encounter presented to G′ have the same profile" (L1263–L1265). That step follows if "profile" means the encounter's pair profile AND E fixes the other side's presentation; it does not follow if "present equal count profiles" means the bodies' own presented counts, because the pair profile also contains the other side's counts, which nothing in the hypothesis fixes. (2) Counterexample under the own-side reading (witness_alternatives.py): G and G′ each present the single entry +1 (own profile (n+, n−) = (1, 0) for both — precondition satisfied). G's encounter partner presents (−1): pair profile (1, 1), full complementary cover. G′'s partner presents (0): pair profile (1, 0), no cover. By §8.6's own tension analysis (cover vs no cover select different outcome classes), the two encounters can land in different outcome classes; with role occupancy attaching by outcome class (the proof's inherited §8 premise), (E, t) ∈ Cap(G, R) and (E, t) ∉ Cap(G′, R) for the corresponding kind/role — conclusion fails. (3) Second route (analytic, independent of the artifact): the same gap appears in the proof text itself — Definition 6.1 decides membership by E's condition "evaluated on what G presents to E at tick t **against the encounter's other side**" (L1230–L1232), a quantity the theorem's hypothesis never mentions; and §8.6's rule is directional (incoming-side guard; Paper 11 §8.6 Theorems G/A), while the theorem nowhere fixes whether G and G′ stand on the same side of their encounters. Post-derivation consultation (logged): script A.4's docstring models an encounter kind by its profile M(E) and rules as functions of (M(G), M(E)) — i.e., the machine companion silently adopts the strong reading on which E carries a fixed profile; the prose proof does not state that adoption.
- Witness / artifacts: witness_alternatives.py, L6.2 section (both checks PASS; exit 0). Precondition check printed by the artifact: under the pair-profile reading the witness's precondition FAILS (pair profiles (1,1) ≠ (1,0)) and no counterexample stands; under the own-side reading the precondition HOLDS and the conclusion fails. Both readings are printed; I do not hide the favourable one.
- Coverage map: (1) native domain: all bodies, ticks, roles, and encounter kinds of Paper 11's taxonomy. (2) verified domain: the theorem under the pair-profile reading with E fixing the other side (derivable, and A.4's model adopts it); the own-side reading (counterexemplified). (3) map: bodies mapped to presented tuples; encounters to pair count vectors per §8.6's M. (4) preserves: §8.6's factorization and §8's role-occupancy premise, both consumed as inherited, as the claim's badge states. (5) outside: Paper 11 §8.6's own correctness (inherited premise, Level A at source); whether Paper 11's taxonomy in fact individuates kinds by profile — a source-paper question the packet's §8.6 statement does not settle for kinds defined as conditions (directional residue, threshold interval, domain guard), since one such condition can be satisfied by encounters of several pair profiles.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: BROKE was argued first. It does not stand as BROKE: under the reading §8.6 forces (encounter-level profiles), the derivation goes through and my witness's precondition fails, so there is no witness satisfying every precondition under the claim's own cited premise. What stands is a genuine proof gap of category B: the printed proof does not state which reading its hypothesis carries, does not fix the encounter's other side, and does not fix side-position, although Definition 6.1's own membership condition depends on the other side. The claim is therefore established only over the subdomain where E fixes the pair profile — a proper subset of the stated domain as a reader without A.4's docstring would naturally read it. Exact boundary: hypothesis read as pair profiles with the other side (and side-position) fixed by E — covered; read as the bodies' own presented counts — not covered, counterexample above.

### FINDING 7 -- L7.3-P12: D(P, W) is not an exact rational on the empty population or empty window; the claim states no nonemptiness condition
- Target claim: L7.3-P12 (§7 claim list)
- Exact target text: "D(P, W) (7.3) is an exact rational; for |P| = 1 it reduces to Paper 9's §4 definition at the single body, and over a shared window it equals the mean of the local densities (7.4). [LEVEL A: MACHINE / AUTHOR — script A.6] …" (frozen paper L1577–L1579); definition at L1463–L1467: "D(P, W) = R(P, W) / (|P| · |W|) ∈ ℚ, D ≥ 0".
- Domain and required property: The claim asserts D(P, W) is an exact rational for the (P, W) the definition ranges over. §2.2 defines a population as "a finite family of bodies" with a declared window (L266) and states no nonemptiness clause for either; §11.3 expressly treats the empty membership list as a population declaration inside a sibling definition's domain ("a population whose membership list is empty…", L2651). The formula's denominator |P| · |W| is 0 when |P| = 0 or |W| = 0.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§2.2, 7.2–7.3, 11.3.
- Method and complete test space: (1) Computational witness (witness_boundary.py): R/(|P|·|W|) at |P| = 0 raises ZeroDivisionError — D is not a rational there, it is undefined. (2) Second route (analytic): the mean-of-locals identity (7.4) divides by |P| as well, and the |P| = 1 reduction the claim names is the smallest case the formula actually reaches; §7.6's scope list (window-relativity; fixed population; no numerical scale) names three limits and nonemptiness is none of them. (3) Precondition check: is the empty population admitted by the paper's premises? §2.2's definition contains no exclusion; the census identities of §3.3 hold trivially at |P| = 0 (verified in the artifact); §11.3 admits the empty declaration by name for K. The least favourable reading — the one the overlay instructs — is that §7's domain is §2.2's domain.
- Witness / artifacts: witness_boundary.py (empty-population witness printed; exit 0).
- Coverage map: (1) native domain: all declared (P, W) under §2.2. (2) verified domain: |P| ≥ 1, |W| ≥ 1 — there the arithmetic is exact and I verified it, including §7.5's exhibit. (3) map: identity on declared populations/windows. (4) preserves: counts R, |P|, |W| as defined. (5) outside: nothing about the |P| ≥ 1 subdomain is impugned; the AUTHOR identification with Paper 9 §4 is untouched by this finding.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: BROKE was argued first (an unqualified "is an exact rational" that is undefined on part of its domain). I file LIMIT, not BROKE, because the defect is a missing domain qualification at a degenerate boundary the paper nowhere uses, not a failure on any population the paper exhibits or any consequence drawn from D; but the qualification is genuinely missing — §11.3 bothered to state the empty case for K, which shows the paper's own standard on exactly this point, and §7 does not meet it. Exact boundary: claim verified for |P| ≥ 1 and |W| ≥ 1; unstated and false-as-written at |P| = 0 or |W| = 0.

### FINDING 8 -- L8.10-P12: the open joint is stated as a conjecture, and its factual clauses check out
- Target claim: L8.10-P12 (§8 claim list)
- Exact target text: "Conjecture, stated as a target (§8.6): a proof of the open joint would need a statement over Proposition 5.3's orbit structure, coupling the acting-junction structure of T_agg steps to the assignment counts of the records they produce — a statement about rest records, in relational form: a characterisation, for a given population, of the records its own junction structure permits it to rest at; whether a population's rest record is maximal is a property of that population, and no universal balance is claimed. (The strong form — rest only at (E2)-maximal records — is already refuted inside this paper.) … The joint itself is not claimed. [LEVEL B]" (frozen paper L2011–L2023)
- Domain and required property: As a LEVEL B conjecture statement, the claim must (a) assert no theorem, (b) have its embedded factual clauses true: the strong form refuted in-paper; rest-record maximality population-dependent.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§8.6–8.7, 9.3, 10.4.
- Method and complete test space: Recomputed §8.7's trajectory from its declared states (witness_boundary.py): records (12,0) → (6,6) → (0,12) → (0,12), Ω = 1, 924, 1, 1, τ_agg = 36, 12, 0, 0 — the rest record (0,12) is stationary at Ω = 1, the table minimum, refuting the strong form exactly as stated. Constructed the other direction: four resting bodies under an L/R feature of §10.4's kind (2 L, 2 R, every junction at a fixed point) rest at (2,2), Ω = C(4,2) = 6, the n = 4 maximum — so "some populations' rest records are maximal, others' are not" is witnessed in both directions within the framework's own constructions.
- Witness / artifacts: witness_boundary.py (§8.7 trajectory and rest-at-maximum checks PASS; exit 0).
- Coverage map: (1) native domain: the conjecture's subject — all closed populations' rest records. (2) verified domain: the two factual clauses, on §8.7's population and on my constructed 4-body population. (3) map: populations represented by junction local states and a ledger-data feature, per §§8.7/10.4. (4) preserves: T_agg dynamics, Ω by (8.1), stationarity by (9.3). (5) outside: the joint itself — by the claim's own statement, unproved and unclaimed; nothing in this finding touches it.
- Category (self-classified, spec section 9.5): E
- Proposed badge: HELD
- Reason: Category E can never sustain a BROKE, and none is proposed: the paper declares this question open in terms, labels the claim LEVEL B conjecture, and its checkable clauses are true. Held means the *statement* is accurate as written, not that the joint is settled.

### FINDING 9 -- L9.4-P12: the saturation fraction is undefined for a junctionless population; the construction's arithmetic otherwise verifies
- Target claim: L9.4-P12 (§9 claim list)
- Exact target text: "The saturation census J_sat(τ), the saturation fraction, and regime change (a tick where J_sat changes) are exact counts/ratios built by summation over Paper 9 §6's local saturation behaviour, with per-junction capacity and demanded load from the junction's own entries under Paper 10 eq. (2.4) … [Construction — Paper 12; components inherited as cited]" (frozen paper L2288–L2299); definition at L2191–L2195: "the saturation fraction J_sat(τ)/J(τ) ∈ ℚ, where J(τ) is the population's junction count at τ."
- Domain and required property: The fraction is asserted to be an exact rational for the population's ticks. A declared population may have no junctions at all (junctionless bodies are admitted throughout — §2.1's degenerate single configuration; the sample's own exhibits include junctionless representatives), and at J(τ) = 0 the fraction's denominator is 0.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§9.4–9.6.
- Method and complete test space: (1) §9.5's worked example recomputed exactly (witness_boundary.py): demands 105/88/100 → demanded 293, booked 288, deferred 5, J_sat 0 → 2, fraction 2/3 — the construction's arithmetic is correct wherever J(τ) ≥ 1. (2) Boundary witness: J(τ) = 0 makes J_sat/J(τ) undefined, the same denominator class as Finding 7 (analytic second route: the ratio is a division, and no clause at §9.4 or §9.6 states J(τ) ≥ 1). J_sat itself and regime change (a change in J_sat) remain well-defined at J = 0; only the fraction fails.
- Witness / artifacts: witness_boundary.py (§9.5 check PASS; junctionless witness printed; exit 0).
- Coverage map: (1) native domain: all declared populations and ticks. (2) verified domain: J(τ) ≥ 1 — full construction verified on §9.5's exhibit. (3) map: identity. (4) preserves: per-junction demanded/booked/deferred accounting under eq. (2.4). (5) outside: the Threshold's exact point (Paper 7's construct, Paper 14's debt — cited, not claimed); unbookable relay demand, which §9.6 itself names as standing in no category of the census — a disclosed boundary of the construction, not a defect in it.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: One component of the claim (the fraction as an exact rational) lacks its domain qualification at the junctionless boundary; the census, regime change, and all exhibited arithmetic hold. Same defect class as Finding 7, filed separately because the claims and sites are distinct.

### FINDING 10 -- L11.2-P12 size-invariance: definitions contain no size branch; claim's stated domain is the enumerated range
- Target claim: L11.2-P12 (§11 claim list)
- Exact target text: "Size-invariance of the §§3–5/§7 constructions across the enumerated population range, same definitions, identities checked across population sizes 1–12, no size-triggered branch in any construction. [LEVEL A: MACHINE] (A.1, A.2, A.6)" (frozen paper L2675; body text at L2630)
- Domain and required property: For every test population in the A-series batteries (sizes 1–12), the census, aggregate-tick, flow-count, aggregate-τ, and reconcile-census constructions are computed by the same definitions, with no size-triggered branch.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§3–5, 7 (definitions read in full), §11.3 body and claim list.
- Method and complete test space: Hostile read of each construction's defining text for a case split on population size, body size, or count magnitude: §3.3 census identities (partition arithmetic), Def 4.1/T_agg (per-junction application), §5.2 flow counts, Prop 4.3 τ_agg (finite sum), §7 (7.1)–(7.3) (sums and one ratio). None contains a size condition. My independent implementations of the same constructions (witness_boundary.py) likewise contain no size branch and reproduce the identities at sizes 0, 1, 4, 6, 12 and on 300 random populations.
- Witness / artifacts: witness_boundary.py (exit 0). Script listings A.1/A.2/A.6 NOT READ (logged); the claim's machine content over its enumerated range is therefore assessed at the definitions level, and the scripts' internal behaviour is Role D's reproduction scope.
- Coverage map: (1) native domain: the constructions as defined, any size. (2) verified domain: the definitions' text (all sizes — no branch exists to trigger) and behaviour at the sizes my artifact exercises. (3) map: my implementations are independent re-implementations of the same definitions. (4) preserves: the identities each construction must satisfy. (5) outside: the A-series scripts' own code (not read by me); astronomical N, which §11.3 Edge 1 itself reserves to AUTHOR-level argument — the claim as written does not assert machine verification there.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The claim is explicitly a claim about constructions/implementations over an enumerated range, and over exactly that domain it holds: one set of definitions, no size branch, identities reproduced independently.

### FINDING 11 -- GS4-F: L11.4-P12's §12.1 agreement is not rendering-independent — ALT-3 reverses the meson/baryon step under a Σu-carried surplus rendering
- Target claim: L11.4-P12 (§11 claim list)
- Exact target text: "…on the exemplar representatives constructed at §11.3, K agrees with Paper 11 §12.1's ordering at every step, each step decided at the component §11.3 names, no paper-silent value consulted." (frozen paper L2677); §11.3 at L2666: "Under this construction, and under no other added premise, K agrees with §12.1's ordering on the six classes…"
- Domain and required property: The property I tested — that the agreement is a property of Paper 2's differentiae themselves, robust across renderings of the surplus differentia into presented/record data — is **not** asserted by the claim. The claim scopes the agreement to "the representatives constructed at §11.3" under the disclosed identification (surplus = a standing opposed pair), and §11.3 states in terms: "No rendering-independence is claimed anywhere in this section", naming the lone-leftover rival (step moves to Tau0) and the record-component rival ("would move the step to that component and could reverse it").
- Sources used: Paper_12_v4.md (fc0499af…7150), §11.3 (L2653–L2666) and Paper 2 differentiae as quoted there; paper2_section11.txt (ad4c0e3d…84e4) for the surplus wording's home.
- Method and complete test space: Alternative constructions satisfying the same stated premises (Paper 2's differentia: meson-like still carrying surplus / unresolved integers; baryon-like settled, no surplus; identical record components except where the rendering places the surplus), implemented independently in witness_alternatives.py: ALT-1 lone-leftover (paper-named): Res 1, Tau0 2 — order preserved, deciding component moves Res → Tau0 (2 < 4). ALT-2 unsettled-entry reading (paper-named): both representatives Res 0, all components tied — step decided nowhere, keys exactly equal. ALT-3 (mine): surplus carried in Σu, the record's unmatched sum — meson Σu = 4 vs baryon Σu = 3, junction presentations opposed-pair-free with Tau0 tied at 2, all components through Ss tied; Su decides, 4 > 3, so K(meson) > K(baryon): the §12.1 step is **reversed**. ALT-4 orientation swap ((−1),(+1)): no change — admissibility is orientation-blind, step still at Res. ALT-5 baryon with a lone leftover: Res still 1, step still at Res. Precondition check for each alternative: N, Σs² and the census components match §11.3's representatives except at the component the rendering itself designates; the differentiae are carried in each case by data the ledger's definitions admit (opposed pair, lone leftover, unmatched sum).
- Witness / artifacts: witness_alternatives.py (8 checks PASS, exit 0); baseline (paper's representatives) reproduced first: order and deciding components exactly as §11.3 names (also witness_boundary.py).
- Coverage map: (1) native domain: renderings of Paper 2 §§11.4–11.5's differentiae into §11.3 representative records. (2) verified domain: five renderings (baseline + ALT-1…ALT-5, with ALT-4/ALT-5 as controls). (3) map: each rendering is a declared representative in §11.3's own format (record components + presented junction data). (4) preserves: the differentiae as stated in Paper 2's vocabulary, the representatives' shared record components, K's definition. (5) outside: the unbounded space of all conceivable renderings — §11.3 itself says the rival space is not exhausted by the named rivals; my ALT-3 is one more member of the class the paper names, not a new class.
- Category (self-classified, spec section 9.5): D
- Proposed badge: OUTSIDE
- Reason: Under the strict rule this cannot be filed as a defect: requirement (ii) fails — rendering-independence is a requirement of my gatekeeper preference for representation-free results, not of the claim, which asserts the agreement only on the constructed representatives under a disclosed, AUTHOR-graded identification, and itself prints the reversal possibility. The finding is filed so the record shows exactly what the hostile search established: the agreement is identification-dependent in the strong sense (ALT-3 reverses it), and the paper's defence is its scoping, which is complete and in the open. The claim as written is separately proposed HELD in Finding 12.

### FINDING 12 -- L11.4-P12 as written: key reproduced independently; agreement on the constructed representatives exact
- Target claim: L11.4-P12 (§11 claim list)
- Exact target text: "Population ordering key K defined at §11.3 on the author's ruling (2026-10-28): a total preorder on declared populations, name-invariant, computed from ledger data alone; tick-stability exact (Ntot, Ss, Su, Btot, CenSig invariant under the aggregate tick; Res and Tau0 not — the sharpness witness is printed by A.14); on the exemplar representatives constructed at §11.3, K agrees with Paper 11 §12.1's ordering at every step, each step decided at the component §11.3 names, no paper-silent value consulted. [LEVEL A: MACHINE / AUTHOR — component split as printed]" (frozen paper L2677)
- Domain and required property: All finite declared populations at a declared tick (empty included by §11.3's statement): K total preorder, name-invariant, ledger-data only; tick-stability split as stated; agreement on the six constructed representatives and equal-size homogeneous families, at the named deciding components.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§3–4, 11.3; Paper 11 §12.1 ordering (paper_11_v69.md, its L224/L1008: photon → open tilted → meson-like → baryon-like → nuclei → atoms by (node count, tilt count, resolution status), [LEVEL B] at home).
- Method and complete test space: Independent implementation of K from §11.3's definition (witness_boundary.py), written before reading A.14. Checks: the six representatives' keys and chain order with deciding components (Ss, Ntot, Res, Ntot, Ntot — as named); meson/baryon identical count vectors separating only at Res; homogeneous families m = 1..5; empty declaration = (0, 1, 0, 0, 0, 0, ()); relabelling invariance on 200 random populations; Res/Tau0 sharpness pair (acting one-junction population (Res 0, Tau0 2) vs resting (Res 1, Tau0 0)); tick-invariance of the five named components derived from §4's stated dynamics (tick acts on junction local states alone; no body-record tick-dynamics stated — the AUTHOR component the claim's split names). Analytic route for totality/transitivity: lexicographic order on totally ordered components, the last a sorted multiset under lexicographic vector comparison with the stated prefix convention. Post-derivation consultation (logged): A.14's coverage — its declarations read the k_j multiset from the side count, exact where each side consumes one port (the regime of every population it constructs, and of the representatives); C33 is scoped to that disclosed reading. My implementation used §11.3's declared k_j values directly, so my verification does not share that restriction; populations where a side consumes more than one port (§11.2 clause (ii)) are inside my reading of the definition and outside A.14's enumeration — carried by the prose, as the claim's split states.
- Witness / artifacts: witness_boundary.py (K checks PASS, exit 0); witness_alternatives.py (baseline reproduction PASS).
- Coverage map: (1) native domain: all finite declared populations. (2) verified domain: representatives + homogeneous families m ≤ 5, empty declaration, 200 random relabelling populations, sharpness pair; totality/transitivity/stability in general by the analytic argument. (3) map: populations mapped to (body records, junction local states) exactly as §11.3's definition requires. (4) preserves: every component K reads, including CenSig as a sorted multiset of full count vectors. (5) outside: the definition itself and the representative identification (AUTHOR components, graded as such in the claim); rendering-independence (Finding 11 — not asserted); the nuclei/atoms parametric generality beyond the exhibited point is carried by §11.3's prose (M < M + S for all u ≥ 0, S ≥ 1), which I verified arithmetically — it is immediate from Ntot deciding that step.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Every machine-asserted behaviour I could test independently reproduces, the general properties follow from the definition by finite arithmetic, and the claim's AUTHOR components are disclosed in its own split. The hostile arm's strongest true statement about this claim is Finding 11, which the claim's scoping already contains.

### FINDING 13 -- Gatekeeper objection (framework disagreement, filed under the strict rule as category D): no continuum limit, convergence, or operational measurement bridge is supplied for the discrete constructions
- Target claim: L5.4-P12 (§5 claim list), with the same objection directed at L7.3-P12 and L10.1-P12
- Exact target text: "The sampling-measure postulate pre-registered in Paper 11.5 §11.6 is unnecessary… The debt is discharged by dissolution over the extended instrument family (census, flow, joint counts), with no postulate adopted." (frozen paper L1131–L1143)
- Domain and required property: As a conventional gatekeeper I require: frequencies that connect to physical prediction in the limit of large populations; a reconcile density with an operational measurement procedure and a continuum limit; periodicity results stated with convergence behaviour. Stated honestly under the strict rule: **these are requirements of my framework, not of the claim.** The claim entails only that the named frequencies are expressible without a measure over the paper's declared domain — and Finding 5 verifies that.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§1.9, 5, 7.4, 7.6, 8.4.
- Method and complete test space: The objection was pressed at its strongest: (a) dissolution yields bookkeeping over declared records, not prediction over undeclared systems — the paper concedes exactly this (§5 objection passage; L5.8-P12; §1.9: "no new empirical prediction is claimed in this paper"); (b) D carries no unit or scale — the paper states this in §7.4's bridge sentence itself ("natively, D is a pure count ratio and carries no unit and no scale constant"); (c) no limit is taken anywhere — the paper states this as a feature (§1.9(i)) and proves its finite statements exactly at each finite n.
- Witness / artifacts: None; this is a position statement, and no witness could exist for it under the paper's premises.
- Coverage map: (1) native domain: the conventional framework's requirements. (2) verified domain: not applicable — no property of the paper was tested. (3) map: none exists between the frameworks at these points; that absence is my objection, and the paper declares it rather than concealing it. (4) preserves: nothing. (5) outside: everything the paper actually claims.
- Category (self-classified, spec section 9.5): D
- Proposed badge: OUTSIDE
- Reason: Filed so the hostile arm's foundational disagreement is on the record in its correct category. Under spec §9.5's binding mapping, category D can never sustain a BROKE and is never a defect. The Stage P bridge thinness that underlies part of this objection is category C in substance; it likewise cannot break native claims that assert no bridge (L5.4, L10.1), and the one Stage P contact in the sampled set (L7.3's identification) is graded AUTHOR in the claim itself. I record the disagreement; I do not dress it as a finding against any claim as written.

### FINDING 14 -- L11.3-P12 macro-matter verdict: extension and its three edges as stated
- Target claim: L11.3-P12 (§11 claim list)
- Exact target text: "Macro-matter extension verdict, subject to Edges 1–3; census confers no ordering key on populations of itself, though census data may feed a definition (as the bodies' count vectors feed this key's CenSig). [LEVEL A: AUTHOR]" (frozen paper L2676; body verdict at L2641)
- Domain and required property: (a) The §§3–5/§7 machinery extends to macro-matter populations by its own construction; (b) the complexity ordering extends only over bodies with their own ordering records; (c) the census, as a partition, confers no rank.
- Sources used: Paper_12_v4.md (fc0499af…7150), §§3–5, 7, 11.3.
- Method and complete test space: (a) reduces to Finding 10's definitional read (no size branch, no size bound in any definition) plus the claim's own Edges: Edge 1 (enumeration horizon — machine range vs prose generality) is stated at L2635; Edge 2 (taxonomy admission of very large bodies is the export's coverage question, and §16's firewall bars this paper from extending the taxonomy) is stated at L2637; Edge 3 (packing presupposes a declared junction graph; Paper 16's territory) at L2639. Each edge names a real boundary of the extension, and the verdict claims nothing past them. (b) checked against §11.2's ordering status: §12.1's key components (tilt count, resolution status) are not defined for general records, so "only as far as bodies whose individual ordering records exist" is the correct bound. (c) the census of §3.2/§5.1 defines classes and counts, no order relation on classes; the apparent tension with L11.4 (whose CenSig is census data inside a *definition*) is resolved by the verdict's own qualification, printed in both the body and the claim.
- Witness / artifacts: None (textual/definitional examination); supporting computation in witness_boundary.py via Finding 10.
- Coverage map: (1) native domain: macro-matter populations — unbounded size. (2) verified domain: the definitions and the verdict's stated edges. (3) map: the extension is by identity of definitions, per the single-regime rule (L2.1-P12). (4) preserves: every construction's defining sentence. (5) outside: whether the received taxonomy in fact resolves every macro-matter constituent (Edge 2 — expressly reserved, not asserted); packing geometry (Edge 3 — Paper 16).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: As an AUTHOR verdict the claim is exactly as strong as its stated edges and no stronger; the hostile reading (that "extends by construction" smuggles unbounded machine verification) is answered by Edge 1 in the claim's own section, in terms.

---

# PROCESS STATUS

- Frozen paper hash: REPRODUCED (my recomputation matches the brief's freeze value fc0499af…7150).
- Packet sources (Paper_12_v4.md, paper_11_v69.md, paper_11_5_v26.md, paper9.txt, paper10.txt, paper2_section11.txt, protocol_examiner_extract.md, sample_selection.txt): READ, hashes recomputed and listed at the head of this submission — SOURCE-VERIFIED for the passages cited.
- Paper 9 / Paper 10 / Paper 2 §11 full texts: NOT READ in full; only the passages the sampled claims cite were inspected (§7.1/§7.2's Paper 9 and Paper 10 quotations were read at their Paper 12 sites; Paper 2's differentiae were read as quoted at §11.3, with paper2_section11.txt present in the packet and hash-verified). SOURCE-REPORTED for anything beyond those passages.
- Derivations (charter item 1): RUN — all twelve claims derived or, for citation/declaration claims, verified against source before any script consultation.
- Boundary search (charter item 2): RUN — witness_boundary.py, exit 0, 34/34 checks PASS as printed.
- Alternative constructions (charter items 4–5, GS4-F): RUN — witness_alternatives.py, exit 0, 8/8 checks PASS as printed.
- Script listings consulted after derivation: A.4 docstring/coverage — READ; A.14 docstring/coverage — READ. A.1, A.2, A.3, A.6 and all other listings: NOT READ. No script from the paper was RUN by me (extraction and suite execution are Role D's charter); my artifacts are independent implementations, not re-runs — REPRODUCED applies to results I recomputed (worked examples, trajectories, keys, identities), NOT REPRODUCED to the A-series scripts' internal outputs.
- FW.1 whole-paper locked-word sweep: NOT RUN (Role D scope); Finding 3 is bounded accordingly.
- Submission: UNSEALED (no sealing step is defined for this arm in my brief).
