# GS4-B REVEAL ADDENDUM — Arm N, Role C (Provenance, Badge and Change-Log Examiner)

Trial label (per spec §1): *GS-4 Gold v1.0 (house execution, two-arm
isolated-context trial).* This addendum is not external validation and
awards no badge.

**Process note.** The original Role C agent's session ended when it sealed
its submission. This reveal pass is executed by a continuation agent on the
identical charter, working from that agent's sealed record:
`BLIND_SEALED.md` (SHA-256
988fa8396c880ced8cb7388adbb0f8982a60554e70f5f811fc4d0bca6532f63b,
recomputed and matched) and §1 of `SUBMISSION.md`, reproduced there
unchanged from the sealed blind pass. Neither sealed file has been edited.
The frozen paper's SHA-256 was recomputed for this pass:
fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150 —
matches the brief's freeze hash.

**Governing standard.** Every disagreement below is resolved against the
paper's own badge definitions, §0.2 of the frozen paper:

- **[LEVEL A]** — machine-checked, *or* inherited from a cited source
  paper's Level A result with lineage cited, *or* prose-proved with no
  gaps.
- **[LEVEL A: MACHINE]** — the claim's content is the output of a named
  script; "the badge is exactly as wide as its validation artifact."
- **[LEVEL A: AUTHOR]** — the declared-axiom subtype: declaration-backed,
  not derivation-backed; it guarantees the declaration was made in the
  open, is traceable, and is carried downstream as a declaration.
- **[LEVEL A: MACHINE / AUTHOR]** — a hybrid; the components are listed
  explicitly, the halves do not cover each other, and the mark splits
  rather than averages.
- **[CITED]** — a quotation or faithful restatement of a named source;
  the claim asserts that the source says it, and its weight is the
  source's.
- **[LEVEL B]** — illustration, conditional reading, declared programme,
  or author-authorized declaration of weaker standing than
  [LEVEL A: AUTHOR].
- **[NO BADGE]** — cannot be derived and is not declared as an assumption:
  conjecture — do not cite as established.
- Bridge rule (§0.3): L_claim ≤ min(L_i) — a claim cannot outrank its
  weakest dependency. Subtype propagation (§0.4, rule 1): a source
  recorded as an author-authorized declaration is carried as
  [LEVEL A: AUTHOR], never as bare [LEVEL A].

**Tally.** 4 full matches (L0.3-P12, L7.3-P12, L11.2-P12, L11.4-P12 —
the last on label form only; its sealed reservation R-B1 survives, §3
below). 8 discrepancies resolved below: 5 recorded as examiner-miss
(L1.2-P12, L2.1-P12, L5.4-P12, L6.2-P12, L11.3-P12) and 3 recorded as
paper-defect (L8.10-P12, L9.4-P12, L10.1-P12), each at the strength the
sealed submission's own findings already assigned (LIMIT in every case;
no BROKE is proposed by this addendum).

---

## 1. Sealed blind classification beside the revealed label

| Claim | Sealed blind classification (BLIND_SEALED.md / SUBMISSION.md §1) | Revealed actual label (coordinator) | Match? |
|---|---|---|---|
| L0.3-P12 | DECLARATION [AUTHOR], no machine leg printed — stipulation fixing each Paper 11 §0.5-locked word's sole permitted route; enforcement named only as "swept by FW.1", no script coverage printed | [LEVEL A: AUTHOR] (script: —; status: FINAL) | **Match** |
| L1.2-P12 | DECLARATION / receipt [AUTHOR] — transcription claim, no derivation; "the count→weight debt is as quoted at §1.2" (Paper 11.5 §§11.5–11.6) | [CITED — L4-P12] (script: —; status: FINAL) | Discrepancy — §2.1 |
| L2.1-P12 | INHERITED declaration — no independent badge; entire content a receipt for Paper 11 §4.1's single-regime rule and licensed aggregate list | [LEVEL A] (script: —; status: FINAL) | Discrepancy — §2.2 |
| L5.4-P12 | [AUTHOR] — prose-carried dissolution, no machine leg printed; postulate "discharged by dissolution" over census/flow/joint-count instruments (Definition 5.8) | [LEVEL A — scoping result, resting on L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, and §3 — through Theorem 4.2, on §4.3 as received at §4, its bonding-mode condition standing as §0.4(b)'s declared receipt] (script: —; status: FINAL) | Partial discrepancy — §2.3 |
| L6.2-P12 | Hybrid in substance: [MACHINE over a finite control taxonomy + INHERITED general premise] — A.4's one premise class=cited-paper (Paper 11 §8.6); outcome rules arbitrary-representative; taxonomy control (e+ + e− ≤ 4) | [LEVEL A — conditional on Paper 11 §8.6 and on Paper 11 §8's role-occupancy assignment] (script: A.4; status: FINAL) | Discrepancy — §2.4 |
| L7.3-P12 | Hybrid [MACHINE / AUTHOR] — MACHINE (A.6): (7.4) identity on the exhibited window + worked-example arithmetic; AUTHOR: (7.4) in general, D's exact rationality in general, identification of the \|P\|=1 case with Paper 9 §4 | [LEVEL A: MACHINE / AUTHOR — script A.6] (script: A.6; status: FINAL) | **Match** |
| L8.10-P12 | CONJECTURE — explicitly not claimed, no Level A badge; "The joint itself is not claimed"; strong form already refuted inside the paper | [LEVEL B] (script: —; status: FINAL) | Discrepancy — §2.5 |
| L9.4-P12 | [AUTHOR] construction on inherited premises, no machine leg printed — counts summed over Paper 9 §6 behaviour, capacity/load under Paper 10 eq. (2.4), Threshold cited to Paper 7 | [Construction — Paper 12; components inherited as cited] (script: —; status: FINAL) | Discrepancy — §2.6 |
| L10.1-P12 | Hybrid [MACHINE / AUTHOR] in substance — A.3's TOY1/TOY2/TOY3 are class=control toy systems (TOY3 "not a framework rule"); the general claim must be carried by the finite-state counting argument in prose | [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)] (script: A.3; status: FINAL) | Discrepancy — §2.7 |
| L11.2-P12 | [MACHINE] over an explicitly enumerated domain — identities checked across population sizes 1–12, no size-triggered branch; scripts A.1, A.2, A.6 named; no general prose leg printed | [LEVEL A: MACHINE] (script: A.1, A.2, A.6; status: FINAL) | **Match** |
| L11.3-P12 | UNCLASSIFIABLE on the blind evidence — no badge justified; the blind packet prints an empty statement/dependency block and no named script for this claim | [LEVEL A: AUTHOR] (script: —; status: FINAL) | Non-match (abstention) — §2.8 |
| L11.4-P12 | Hybrid [MACHINE / AUTHOR] — MACHINE (A.14): key computation/behaviour over enumerated domains, W1/W4, mutants; AUTHOR: the definition (author's ruling 2026-10-28), the representative construction under §11.3's declared identification, general order properties, general tick-stability theorem (prose) | [LEVEL A: MACHINE / AUTHOR] (script: A.14; status: FINAL) | **Match** (label form; reservation R-B1 survives — §3) |

**Agreements, briefly grounded.** L0.3-P12: §0.2's [LEVEL A: AUTHOR] is
by definition the declaration-backed subtype, and the blind basis (a
stipulation, no derivation, no machine-checked domain) is exactly that;
the revealed script column (—) confirms no machine leg was claimed.
L7.3-P12: the revealed hybrid and its script (A.6) coincide with the
blind split leg for leg. L11.2-P12: the revealed [LEVEL A: MACHINE] is
sound under §0.2 only because, per the sealed submission §2, the claim
text itself self-scopes to the enumerated range (population sizes 1–12)
the scripts check — the badge is exactly as wide as its artifact, as
§0.2 requires. L11.4-P12: the revealed hybrid and its script (A.14)
coincide with the blind split in form and allocation.

---

## 2. Discrepancies resolved against §0.2

### 2.1 L1.2-P12 — examiner-miss

**Governs: the paper's [CITED — L4-P12].** The blind basis itself states
the claim is that a quotation is accurate ("the debt is as quoted at
§1.2"). §0.2's [CITED] definition covers exactly this: a quotation or
faithful restatement of a named source, asserting that the source says
it, with the source's weight. [LEVEL A: AUTHOR] covers content the
author *declares*; L1.2-P12 declares nothing — it transcribes Paper 11.5
§§11.5–11.6. The blind classification reached for the receipt's
declarative flavour and missed the dedicated [CITED] slot its own basis
described. **Recorded: examiner-miss.** No paper defect: the sealed
submission §2 already recorded this badge as correctly priced.

### 2.2 L2.1-P12 — examiner-miss

**Governs: the paper's [LEVEL A] (inherited).** The blind classification
correctly identified the substance (pure inheritance from Paper 11
§4.1, no script, no derivation) but concluded "no independent badge."
§0.2's [LEVEL A] definition has three legs, and the second is precisely
"inherited from a cited source paper's Level A result with lineage
cited." Inherited Level A is not the absence of a badge; it is one of
the badge's defined forms. The sealed submission §2 verified the
inheritance line is printed in §0.4's prescribed form (source, badge at
source [LEVEL A], validation, reliance) and that no [AUTHOR] subtype is
owed, the source not being an author-declaration. **Recorded:
examiner-miss** — the blind vocabulary treated "inherited" and "Level A"
as alternatives where §0.2 makes the first a route to the second.

### 2.3 L5.4-P12 — examiner-miss (subtype only; substance agreed)

**Governs: the paper's conditional [LEVEL A] form, for the badge slot.**
Blind and paper agree on the load-bearing facts: no machine leg (revealed
script: —), the content carried by prose over Definition 5.8 /
Proposition 5.9 / §3, resting through Theorem 4.2 on the §0.4(b) declared
receipt — and the revealed badge text names that entire chain, receipt
included, inside the badge itself. The blind error was equating
"prose-carried" with "[AUTHOR]". §0.2 separates the two: [AUTHOR] is
*declaration*-backed, whereas [LEVEL A]'s third leg is *prose-proved
with no gaps*. L5.4-P12's content is a scoping result argued in prose
(the postulate shown unnecessary), not a declaration the author made;
its declared *premise* is priced by being named in the badge text, not
by converting the result into a declaration. **Recorded: examiner-miss
on subtype.** Two boundaries are expressly not disturbed by this
resolution: (i) the §0.4(b) transitive residue — the sealed submission's
Finding 4 (category E, LIMIT) records that, priced transitively through
the receipt, the claims consuming the premise stand one grade below
their printed conditional badges until the author rules the bridge
rule's registry-keyed reading governs or the premise is registered at
its source; that is a question the paper explicitly leaves open, not a
blind-classification discrepancy, and this addendum does not re-grade
it; (ii) no machine content is claimed or found.

### 2.4 L6.2-P12 — examiner-miss (see also R-B3, §3)

**Governs: the paper's conditional [LEVEL A].** The blind classification
read A.4's provenance block (one cited-paper premise, arbitrary-
representative outcome rules, a finite control taxonomy) as a machine
leg in substance, and so predicted a hybrid. But §0.2's
[LEVEL A: MACHINE] requires that the claim's *content be the output of
the script*. Per the sealed submission §2, L6.2-P12's content is a prose
proof printed at Theorem 6.2 whose only substantive steps are the two
inherited premises — Paper 11 §8.6's factorisation and §8's
role-occupancy assignment — and the revealed badge names exactly those
two as its conditions. That is §0.2's [LEVEL A] by its inherited /
prose-proved legs, with A.4 standing in the script column as
corroboration over its finite taxonomy, not as the claim's carrier. A
script's presence in the registry column does not by itself mint a
MACHINE subtype or owe a component split. The bridge rule is satisfied
in form: the conditional badge caps the claim at its two named weakest
dependencies. **Recorded: examiner-miss** — the blind pass over-weighted
provenance classes inside a corroborating script against the printed
proof that actually carries the claim.

### 2.5 L8.10-P12 — paper-defect (taxonomy application; LIMIT)

**Governs: the blind classification's governing definition — §0.2's
[NO BADGE] — on the strict reading of §0.2 as written.** The claim
describes itself, verbatim, as a conjecture and states "The joint itself
is not claimed." §0.2 defines [NO BADGE] in one word for this case:
"conjecture — do not cite as established." Against that stands
[LEVEL B]'s inclusion of "declared programme," and L8.10-P12 is also,
in form, a declared statement of what a proof of the open joint would
need. The two definitions therefore genuinely overlap on this text, and
the paper nowhere states which governs a declared conjecture-as-target.
Where the claim's own words ("Conjecture… not claimed") sit closest to
the [NO BADGE] definition, a registry reader pricing the claim from
§0.2 alone cannot reproduce [LEVEL B] as the compelled slot. **Recorded:
paper-defect** — a taxonomy-application ambiguity in §0.2, exactly as
filed in the sealed submission's Finding 6 (category A, LIMIT). It is
not a substantive overclaim: [LEVEL B] asserts no Level A strength, the
openness of the joint is restated at every site (§§8.6/9.6), and no
reader is misled about the joint's status. The repair is a ruling on
which §0.2 definition governs declared conjectures-as-targets, reserved
to the author/adjudicator; this addendum records the discrepancy, it
does not re-badge the claim.

### 2.6 L9.4-P12 — paper-defect (undefined badge family; LIMIT)

**Governs: the blind classification on substance; neither label can
govern on form, because §0.2 does not define the revealed one.** Blind
and paper agree on every substantive fact: a construction built in this
paper (summation over Paper 9 §6's local saturation behaviour) whose
components are inherited as cited (Paper 10 eq. (2.4) for capacity/load;
Threshold cited to Paper 7, not redefined), and no machine leg (revealed
script: —). The revealed string "[Construction — Paper 12; components
inherited as cited]" describes that substance honestly. The blind pass,
working only with §0.2's vocabulary, placed it in the nearest defined
slot, [AUTHOR]. The discrepancy's cause is on the paper's side: §0.2
purports to define every badge ("Every claim in this paper carries an
epistemic badge:" followed by the definition list), yet "Construction"
appears nowhere in that list — a reader cannot price what the badge
guarantees from the defining section, even though the paper's own
registry-audit taxonomy (script H.1) recognises the class. **Recorded:
paper-defect** — a missing §0.2 definition, exactly as filed in the
sealed submission's Finding 7 (category B, LIMIT). No outranking is
asserted by the string (it claims no Level A strength) and L9.4-P12's
dependency disclosure is complete; the defect is confined to the badge's
definitional home.

### 2.7 L10.1-P12 — paper-defect (badge outruns its artifact; LIMIT)

**Governs: the blind classification.** This is the one sample claim
where the reveal confirms the blind substance over the printed badge.
§0.2 is unambiguous for [LEVEL A: MACHINE]: "the badge is exactly as
wide as its validation artifact: the script checks what the script
checks, and the prose around it claims no more." Per the sealed
submission's Finding 1, A.3's own coverage map states its verified
domain as single-junction T-systems in full and three declared toy
systems in full (TOY1/TOY2/TOY3, class=control; TOY3 "not a framework
rule"), places the well-definedness and determinism of T_agg on
many-junction populations outside its check (Theorem 4.2, A.2's remit),
and concludes that the badge the script supports is "the
decomposition/frequency arithmetic, conditional on A.2." The step from
those finite systems to the claim as badged — eventual periodicity over
*arbitrary* finite populations, with the exact (p, c) decomposition — is
carried by §5's prose proof of Proposition 5.3(iii), a prose leg the
revealed badge does not price: there is no AUTHOR leg and no component
split. The revealed condition "conditional on A.2 (well-definedness of
T_agg)" prices the dependency the blind pass also named, but it does not
supply the missing general leg. The paper's own precedent (L8.3-P12,
L11.4-P12) places exactly this kind of general content in an AUTHOR leg
under a hybrid badge — the form the blind pass predicted. **Recorded:
paper-defect** — the L8.3-class split mismatch in inverted form (general
content under a machine-only badge), filed as the sealed submission's
Finding 1 (category A, LIMIT, not BROKE: the missing leg exists in the
paper at §5 and is merely unpriced in this badge; the claim's content is
not impugned). Finding 4's §0.4(b) transitive residue also applies to
this claim at one further remove, through A.2 / Theorem 4.2, as
§0.4(b) itself names it.

### 2.8 L11.3-P12 — examiner-miss (evidential non-match; no defect on either side's reasoning)

**Governs: the paper's [LEVEL A: AUTHOR], for the claim; the blind
abstention governs only as a record of the blind evidence.** The blind
classification was not a positive prediction that failed — it was an
express abstention: the blind packet printed an empty
statement/dependency block and no named script for this claim, and the
sealed text recorded the abstention "as a blind-packet coverage fact,
not as a judgement on the claim in the paper." The reveal supplies what
the packet withheld. On the full text (sealed submission §§2–3) the
revealed badge is consistent with §0.2: L11.3-P12 is an author verdict
(macro-matter) whose declared limits (Edges 1–3: enumeration horizon,
taxonomy admission, packing deferred to Paper 16) are named in the
claim, carried over machinery whose general carry beyond enumeration is
author-level argument — declaration-backed content under the [AUTHOR]
discipline, with no machine leg claimed (revealed script: —) and none
found. For Gate 3's discrepancy ledger this non-match is **recorded as
examiner-miss in the narrow match-count sense only** — the blind pass
did not reproduce the label — with the cause stated plainly: the miss is
evidential (an empty blind block), not a reasoning error by the sealed
examiner and not a defect in the paper's badge. Collapsing it into
either plain category without this qualification would misrecord it.

---

## 3. Sealed reservations R-B1, R-B2, R-B3 in light of the revealed labels

**R-B1 (L11.4-P12 tick-stability AUTHOR leg) — SURVIVES the reveal;
paper-side, already filed as Finding 2.** The reservation was that the
blind packet's own parenthetical — §4 states no tick-dynamics for body
records' (N, Σs², Σu) — sits in tension with a general tick-stability
theorem carried by §11.3's prose proof. The revealed label
[LEVEL A: MACHINE / AUTHOR] (script: A.14) matches the blind prediction
in form, so the reveal neither creates nor cures the reservation: the
hybrid split assigns the general theorem to the AUTHOR leg, and A.14's
machine leg runs only over its enumerated domains. Per the sealed
submission's Finding 2 (category B, LIMIT), the §11.3 paragraph derives
the standing of N, the k_j multiset, and B, but for Σs² and Σu its only
step is the summarising clause "each now shown standing," while the
claim's own split discloses the §4 gap. R-B1 therefore stands as a
named premise gap in the AUTHOR leg of a correctly *formed* hybrid
badge — a paper-side gap (a §4 statement of T_agg's action on body
records would close it), not a badge-match discrepancy and not an
examiner-miss.

**R-B2 (L11.3-P12 empty blind block) — DISCHARGED as the explanation of
the §2.8 non-match; vindicated as a coverage fact.** The reservation
warned that if the paper badged this claim, the blind packet gave the
examiner no route to reproduce the badge. The paper does badge it —
[LEVEL A: AUTHOR] — and the packet indeed gave no route. The
reservation was accurate, its condition materialised, and it fully
accounts for the sole abstention in the blind sample. It casts no doubt
on the revealed badge, which the sealed submission's post-blind audit
found consistent with §0.2 (see §2.8).

**R-B3 (L6.2-P12 and L10.1-P12: mixed provenance legs, no printed split)
— DISCHARGED for L6.2-P12; VINDICATED for L10.1-P12.** The reservation
was conditional: a paper badge of plain [MACHINE] for either claim
would, on the blind evidence, overstate the machine leg.

- *L6.2-P12:* the feared badge did not occur. The revealed label is a
  conditional plain [LEVEL A] resting on the two named inherited
  premises, with A.4 corroborative (see §2.4). No machine content is
  overstated. R-B3 is discharged for this claim.
- *L10.1-P12:* the feared badge occurred exactly as specified —
  [LEVEL A: MACHINE — script A.3, conditional on A.2], with no AUTHOR
  leg and no split, over a claim whose general content is prose-carried
  (see §2.7). R-B3 is vindicated for this claim and is the blind-pass
  root of the sealed submission's Finding 1, recorded there and here as
  a paper-defect (LIMIT).

---

## 4. Net Gate 3 statement (Role C evidence only)

Of the twelve sampled claims, the blind classifications reproduce the
paper's labels in substance for nine (the four full matches, L0.3-P12,
L7.3-P12, L11.2-P12, L11.4-P12; the four examiner-misses in which the
paper's label governs, L1.2-P12, L2.1-P12, L6.2-P12, L11.3-P12; and
L5.4-P12, where the paper's conditional form governs the slot and the
sole surviving question is the paper's own disclosed §0.4(b) residue).
In three cases the blind classification governs against the printed
label, each already filed as a finding in the sealed submission and
each at LIMIT strength: L10.1-P12 (Finding 1 — machine badge wider than
its artifact), L8.10-P12 (Finding 6 — §0.2's [NO BADGE]/[LEVEL B]
overlap on a self-described conjecture), and L9.4-P12 (Finding 7 — a
badge family §0.2 never defines). No discrepancy found in this reveal
pass is new: every paper-side discrepancy above was identified, with
its witness, in the sealed submission written before the reveal.

PROCESS STATUS: READ (brief, BLIND_SEALED.md, SUBMISSION.md §1 and findings, frozen paper §0.2–§0.4; frozen-paper and sealed-file hashes recomputed and SOURCE-VERIFIED) / NOT RUN (no paper script was run in this reveal pass; no reproduction is claimed) / SEALED (BLIND_SEALED.md and SUBMISSION.md unedited; this addendum is a separate post-reveal file).
