# SUBMISSION — GS-4 Gold v1.0, Arm N, Role C (Provenance, Badge and Change-Log Examiner)

Trial label (per spec §1): *GS-4 Gold v1.0 (house execution, two-arm
isolated-context trial).* This submission is not external validation and
awards no badge; it proposes, with evidence, for the blinded adjudicator.

## 0. Identity and sources

Frozen paper: `packet/Paper_12_v4.md`, 69,425 lines. SHA-256 recomputed by
this examiner: `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150`
— matches the brief's freeze hash exactly.

Packet files used, with SHA-256 recomputed by this examiner:

| File | SHA-256 |
|---|---|
| Paper_12_v4.md | fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150 |
| protocol_examiner_extract.md | f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1 |
| sample_selection.txt | 588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766 |
| roleC_only/blind_claims.md | 4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f |
| paper_11_v69.md | f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb |
| paper_11_5_v26.md | 9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60 |
| paper9.txt | defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6 |
| paper10.txt | f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82 |
| paper2_section11.txt | ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e |
| blind_verification.txt | 97424de9a2d51d2a0e7ad043383ba5e024ed0235a328a208b70fd9c1c19e9dcb (listed in packet; not needed for Role C's charter items and not opened) |

Badge definitions applied are the paper's own, §0.2 (lines 44–58 of the
frozen paper): [LEVEL A], [LEVEL A: MACHINE] ("The badge is exactly as wide
as its validation artifact"), [LEVEL A: AUTHOR], [LEVEL A: MACHINE /
AUTHOR] ("The halves do not cover each other, and the mark splits rather
than averages"), [CITED], [LEVEL B], [Declared assumption], [LEVEL C],
[NO BADGE], Denied [Level A]; bridge rule §0.3: "L_claim ≤ min(L_i) — a
claim cannot outrank its weakest dependency."

Sample (from packet/sample_selection.txt, not re-picked): L11.4-P12,
L7.3-P12, L0.3-P12, L11.2-P12, L11.3-P12, L5.4-P12, L8.10-P12, L9.4-P12,
L6.2-P12, L1.2-P12, L10.1-P12, L2.1-P12.

---

## 1. GS4-B BLIND PASS — sealed classifications (binding order observed)

The twelve classifications below were written and sealed in
`BLIND_SEALED.md` (SHA-256
988fa8396c880ced8cb7388adbb0f8982a60554e70f5f811fc4d0bca6532f63b) **before**
this examiner opened the frozen paper's Appendix B rows or any claim-list
badge string for the sampled claims. Sources for the blind pass were only
`blind_claims.md` and the protocol extract's §9 vocabulary. They are
reproduced here unchanged; disagreements with the paper's actual labels
are NOT resolved in this submission — they are reserved for the
REVEAL_ADDENDUM.md that follows the coordinator's reveal.

| # | Claim | Blind classification (sealed) |
|---|---|---|
| 1 | L11.4-P12 | **Hybrid [MACHINE / AUTHOR]** — MACHINE (A.14): key computation/behaviour over enumerated domains, W1/W4, mutants. AUTHOR: the definition (ruling 2026-10-28), the representative construction under §11.3's declared identification over Paper 2 §§11.4–11.5, general order properties, general tick-stability theorem (prose). Reservation R-B1: the packet itself prints that §4 states no tick-dynamics for body records' (N, Σs², Σu). |
| 2 | L7.3-P12 | **Hybrid [MACHINE / AUTHOR]** — MACHINE (A.6): (7.4) identity on the exhibited window, worked-example arithmetic. AUTHOR: (7.4) in general, D's rationality in general, identification of the \|P\|=1 case with Paper 9 §4's verbal definition. |
| 3 | L0.3-P12 | **DECLARATION [AUTHOR], no machine leg printed** — stipulation fixing each locked word's sole route; enforcement named only as "swept by FW.1", no script coverage printed. |
| 4 | L11.2-P12 | **[MACHINE] over an explicitly enumerated domain** — identities checked across population sizes 1–12 (A.1, A.2, A.6); no general prose leg printed. |
| 5 | L11.3-P12 | **UNCLASSIFIABLE on the blind evidence — no badge justified** — the blind packet prints an empty statement/dependency block and no script for this claim (reservation R-B2: a blind-packet coverage fact, not a judgement on the claim in the paper). |
| 6 | L5.4-P12 | **[AUTHOR] — prose-carried dissolution, no machine leg printed** — postulate discharged by dissolution over census/flow/joint counts (Definition 5.8); load carried by prose plus the C32 firing record at §12. |
| 7 | L8.10-P12 | **CONJECTURE — explicitly not claimed, no Level A badge** — statement says "The joint itself is not claimed"; strong form already refuted inside the paper. |
| 8 | L9.4-P12 | **[AUTHOR] construction on inherited premises, no machine leg printed** — counts summed over Paper 9 §6 behaviour, capacity/load under Paper 10 eq. (2.4); Threshold cited to Paper 7, not redefined. |
| 9 | L6.2-P12 | **Hybrid in substance: [MACHINE over a finite control taxonomy + INHERITED general premise]** — A.4's one premise is class=cited-paper (Paper 11 §8.6); outcome rules arbitrary-representative; taxonomy control (e+ + e− ≤ 4). The universal statement rests on the inherited §8.6 premise (reservation R-B3). |
| 10 | L1.2-P12 | **DECLARATION / receipt [AUTHOR] — transcription claim** — "the debt is as quoted at §1.2"; no script, no derivation printed. |
| 11 | L10.1-P12 | **Hybrid [MACHINE / AUTHOR] in substance** — A.3's TOY1/TOY2/TOY3 are class=control (toy systems; TOY3 "not a framework rule"); the general claim (eventual periodicity on finite populations) must be carried by the finite-state counting argument in prose (reservation R-B3). |
| 12 | L2.1-P12 | **INHERITED declaration — no independent badge** — statement says "inherited. Dependencies: Paper 11 §4.1…". |

---

## 2. Claim → home → dependency → evidence graph (sample)

Dependency kinds: INH = inherited cited-paper fact; DEF = Paper 12
definition; DECL = author declaration/ruling; DA = declared assumption;
CTRL = arbitrary control choice; MACH = machine output (named script);
EXT = external/other-paper deferral.

| Claim | Home (claim list / registry) | Dependencies (typed) | Evidence of record |
|---|---|---|---|
| L11.4-P12 | §11.4 list, L2677 / App. B, L2884 | DECL: key definition, author's ruling 2026-10-28. DECL-ID: surplus→opposed-pair declared identification (§11.3). INH: Paper 2 §§11.4–11.5 differentia (quoted, §0.4(d) direct link); Paper 11 §12.1 ordering as agreement target ([LEVEL B] at home, per §0.3 L1-P12 fence); Paper 11 Table 5.1 sign facts [CITED]. DA: Paper 11 F.37 declared assumptions (M > 3; S ≥ 1; atoms = nuclei + incorporated simple states). DEF: §§3–5 records, §4 tick. MACH: A.14. | Split stated identically in substance at home and registry; A.14 provenance classes inputs cited-paper / paper-defined / control. Falsifier C33 (L2706). |
| L7.3-P12 | §7 claims, L1579 / App. B, L2854 | DEF: eq. (7.3) (§7, this paper's construction). INH: Paper 9 §4 verbal definition (identification leg only) — source text verified at paper9.txt L244 ("Temperature is the localized density and frequency of chaotic creation-geometry rewrite events per tick"). MACH: A.6 (exhibited window only). | Split stated at home and registry, same allocation. General legs carried by §7/§7.3 prose (exact rational arithmetic). |
| L0.3-P12 | §0.5 list, L145 / App. B, L2816 | INH: Paper 11 §0.5 lock (quoted, [CITED] via L0.4-P12). DECL: the construction list itself. MACH (paper-wide): FW.1 sweep. | Badge [LEVEL A: AUTHOR] at both sites; falsifier stated at home ("a locked word found… standing uncorrected in a final tree"). |
| L11.2-P12 | §11.4 list, L2675 / App. B, L2882 | DEF: §§3–5, §7 constructions. MACH: A.1, A.2, A.6 over population sizes 1–12. | Badge [LEVEL A: MACHINE] at both sites; claim text self-scopes to the enumerated range. (§11.3 prose form, ~L2652, also carries the looser clause "from two bodies to the largest enumerated stress populations" before restating the 1–12 check scope — the badged claim-list/registry text is the scoped one.) |
| L11.3-P12 | §11.4 list, L2676 / App. B, L2883 | DECL: macro-matter verdict (author). DEF/INH: §§3–5/§7 machinery; Paper 11 §12.2 scope permission; Edges 1–3 (declared limits: enumeration horizon; taxonomy admission; packing deferred to Paper 16, EXT). | Badge [LEVEL A: AUTHOR] at both sites; edges stated at the home section (§11.3) and named in the claim. |
| L5.4-P12 | §5 list, L1131 / App. B, L2840 | DEF: Definition 5.8 joint counts; Proposition 5.9; §3 census/flow. INH-via-chain: Theorem 4.2 → §4.3 as received at §4 → §0.4(b) declared receipt (bonding-mode premise, Paper 2 §11.1 via Paper 11 §6.1). INH: L5.3-P12 as restated. Historical witness: C32 firing against the v3 form (§12). | Badge [LEVEL A — scoping result, resting on …] at both sites, receipt named in both. See Finding 4 for the disclosed transitive residue. |
| L8.10-P12 | §8 claims, L2011 / App. B, L2867 | DEF: Proposition 5.3 orbit structure (target of the conjectured statement). INH: Paper 9 §5 asymmetry (fallback reading). Internal refutation: strong form refuted inside the paper (stated in the claim). | Badge [LEVEL B] at both sites; claim text: "Conjecture… The joint itself is not claimed." See Finding 6. |
| L9.4-P12 | §9 claims, L2288 / App. B, L2871 | INH: Paper 9 §6 local saturation behaviour (cascade step 1 verified at paper9.txt L461–463); Paper 10 eq. (2.4) capacity/load and §2.4.7 single-source isotropic partition; §2.2 relay-execution accounting (via [L3-P12]). EXT: Threshold cited to Paper 7, exact point deferred to Paper 14. DEF: the summation construction is this paper's (§0.3 [L2-P12] label states this expressly). | Badge "[Construction — Paper 12; components inherited as cited]" at both sites. See Finding 7 on this badge string. No script named; no script claimed. |
| L6.2-P12 | §6 claims, L1344 / App. B, L2849 | INH: Paper 11 §8.6 (outcome factors through M = (n+, n−)) and Paper 11 §8 role-occupancy assignment — both named in the badge at home, registry, and Theorem 6.2's badge (L1236). MACH (corroborative): A.4 (registry script column). CTRL (inside A.4): two arbitrary-representative outcome rules; finite taxonomy e+ + e− ≤ 4. | Prose proof printed at Theorem 6.2 (L1236–1268) from exactly the two named premises. Badge [LEVEL A — conditional on …] — plain Level A is the correct form here: §0.2's [LEVEL A] covers prose-proved/inherited content, and no MACHINE subtype is claimed, so no split is owed. Blind reservation R-B3 is discharged by the printed proof. |
| L1.2-P12 | §1 list, L246 / App. B, L2819 | INH/quote: Paper 11.5 v26 §§11.5–11.6 (debt text, two named items, fill rules — fill-rule debt text verified present in paper_11_5_v26.md, e.g. L2763, L2810). | Badge [CITED — L4-P12] at home, [CITED — L4-P12] in registry. A quotation-accuracy claim, correctly badged as cited, not derived. |
| L10.1-P12 | §10 list, L2510 / App. B, L2875 | MACH: A.3, conditional on A.2 (Theorem 4.2 well-definedness of T_agg) — and through Theorem 4.2 on the §0.4(b) declared receipt (§0.4(b) names L10.1 expressly as a one-further-remove consumer carrying the pointer to that theorem). INH: Paper 11 §7.5 T rule (inside A.3). CTRL (inside A.3): TOY1/TOY2/TOY3 toy systems. Prose: §5's proof of Proposition 5.3(iii) supplies the (p, c) argument (per A.3's own coverage map). | Badge [LEVEL A: MACHINE — script A.3, conditional on A.2] at both sites. See Finding 1. |
| L2.1-P12 | §2 list, L298 / App. B, L2826 | INH: Paper 11 v69 §4.1 / claim 41 / R15 (single-regime rule and licensed aggregate list; source apparatus verified present in paper_11_v69.md — R15 aggregate-reduction rule and §4.1 single-regime text). Inheritance line printed at home in §0.4's prescribed form (source, badge at source [LEVEL A], validation F.41, reliance). | Badge [LEVEL A] (inherited) at home; registry [LEVEL A]. Consistent with §0.2's inherited-Level-A route and §0.4's subtype rules (source is not an author-declaration, so no AUTHOR subtype is owed). |

## 3. Weakest-dependency badge tracing (bridge rule, §0.3)

For each sampled claim: badge vs. weakest load-bearing dependency.

- **L11.4** — Weakest dependencies: the declared identification (author
  strength) and Paper 11 §12.1 as agreement target ([LEVEL B] at home).
  The hybrid badge prices the identification in the AUTHOR leg and never
  claims the §12.1 target above its home standing (agreement *with* it is
  the construction's output, not an inheritance of its grade). No
  outranking found, subject to Findings 3 and 5.
- **L7.3** — Weakest: the Paper 9 §4 identification (author leg). Priced in
  the AUTHOR leg. No outranking.
- **L0.3** — [LEVEL A: AUTHOR] over a [CITED] lock + the author's own list.
  Declaration priced as declaration. No outranking.
- **L11.2** — [LEVEL A: MACHINE], domain expressly the enumerated range.
  No outranking within that domain.
- **L11.3** — [LEVEL A: AUTHOR] verdict over machinery whose general
  carry beyond enumeration is AUTHOR-level argument (§11.3 Edge 1 says
  so). Consistent.
- **L5.4** — Printed conditional [LEVEL A] resting through Theorem 4.2 on
  the §0.4(b) declared receipt. The paper itself records the transitive
  price ("one grade below their printed conditional badges… stands until
  the author rules"). Finding 4.
- **L8.10** — [LEVEL B] on an expressly unclaimed conjecture. Finding 6.
- **L9.4** — Construction badge (undefined in §0.2 — Finding 7); its
  inherited components are cited at their home strengths and the
  construction is claimed as this paper's own. No Level A outranking is
  asserted by the string, but a reader cannot price it from §0.2.
- **L6.2** — Conditional [LEVEL A] capped by its two named Paper 11
  premises, both consumed as inherited premises in the printed proof.
  Correctly priced.
- **L1.2** — [CITED]; weight is the source's, per §0.2's [CITED]
  definition. Correctly priced.
- **L10.1** — [LEVEL A: MACHINE] whose general content is not machine
  output (Finding 1) and which also sits one remove from the §0.4(b)
  receipt through A.2/Theorem 4.2 (Finding 4 applies to it as §0.4(b)
  itself names it).
- **L2.1** — [LEVEL A] inherited at source strength with a full
  inheritance line. Correctly priced.

## 4. MACHINE / AUTHOR split audit — ALL hybrid claims in the paper

Charter item (4) applied to the sample, extended per the tasking to every
[LEVEL A: MACHINE / AUTHOR] claim in the paper. Registry search (Appendix
B, L2806–2903) returns exactly nine hybrid claims: L3.4, L7.2, L7.3, L8.3,
L9.5, L11.1, L11.4, LD.8, LE.2 (the OR-1 row at L2901 is a resolution
record, not a claim). Allocation question for each: does the split name
the exact content each leg carries, and does neither leg claim the
other's content?

| Claim | MACHINE leg (as allocated) | AUTHOR leg (as allocated) | Allocation verdict |
|---|---|---|---|
| L3.4-P12 (§3 list, L415) | A.1: the rule's identities over the valued components (N, junction arity multiset, B) and the worked counts | The identification of the rule as the discharge of 11.5's "(1) a microstate-counting rule" under §0.5's corrected name; identity (III) over its Σs² and Σu components, "carried by §3.3's prose proof, A.1 computing no Σs² or Σu values" | **Allocated exactly.** The AUTHOR leg expressly names the components the script does not compute — the model form of the split. |
| L7.2-P12 (§7 claims, L1569) | A.6: the (7.2) arithmetic under Paper 10 eq. (2.4), including the §7.2 worked tick | §7.2's declared identification (an occasion books reconcile events exactly when it is a contact tick; the booked value is that tick's N_reconcile entry in Paper 10 §2.2's accounting form) | **Allocated exactly.** Note (provenance): round 5 of the version history records this claim "falls one grade" to the hybrid badge with its split stated — the current text carries that form. |
| L7.3-P12 (sampled) | A.6: (7.4) identity on the exhibited window; worked example's arithmetic | (7.4) in general (§7.3 prose); D's rationality in general (§7 prose); the \|P\|=1 identification with Paper 9 §4 | **Allocated exactly**, identical allocation at home and registry. Independently corroborated in §7 below (GS4-D). |
| L8.3-P12 (§8 claims, L1964; registry L2860) | A.5: assignment counts enumerated n = 1…6; closed-form shares and (8.7) checked n = 1…12 | The all-n generality of (8.7) beyond that range, carried by §8.3's printed induction "which A.5's coverage expressly leaves to the prose"; the reading of the counts as concentration (and the non-growth honesty entry) | **Allocated exactly, and verbatim-identical at home and registry** (this examiner diffed the two split strings; they match character-for-character over the split). This is the round-10 repair site — see §8 (GS4-H). |
| L9.5-P12 (§9 claims, L2302) | A.6: the §9.5 threshold arithmetic | The worked example's status as an exhibit of the §9.4 construction | **Allocated exactly.** (The claim is an exhibit claim; the AUTHOR leg carries status, not arithmetic.) |
| L11.1-P12 (§11.4 list, L2674; verdict §11.2, L2616) | A.8: (R1)–(R3), census key of the flattening, grouping-independence over enumerated groupings, the worked example incl. regrouping | The definition itself (ruling 2026-10-25); grouping-independence in general (§11.2 prose); Φ is a Bonded Aggregate (§11.2 prose proof under the definition's clauses); the narrowed ordering verdict | **Allocated exactly** at both the §11.2 verdict site and the claim list. |
| L11.4-P12 (sampled) | A.14: key computation/behaviour over A.14's enumerated domains; representatives and homogeneous families; name invariance and transitivity over the sigma family; stability invariants over those domains; W1/W4; three mutants rejected | The definition (ruling 2026-10-28); the representative construction under the declared identification; general order properties (finite-arithmetic reading); the general tick-stability theorem (§11.3 prose proof) | **Allocated in form** — each leg's content is named. Two substantive boundaries inside the allocation are filed: Finding 2 (tick-stability prose step) and Finding 3 (A.14's k_j reading). |
| LD.8-P12 (App. D list) | A.7: the printed Ω path and τ_agg series | The non-tendency reading | **Allocated exactly.** |
| LE.2-P12 (App. E list) | A.12: the recomputation (G8 witness returns 1/4 and 0 under Definition 5.7 across the full 3×3 tables) | The code-reading verdicts of the three-ways audit, "recorded in Exhibit 8" | **Allocated, in sentence form rather than a labelled split** — the home entry allocates by clause ("the recomputation is script A.12's; the code-reading verdicts are the audit's"), and the registry row carries the same content in its claim text. The weakest allocation presentation of the nine, but the allocation question is answerable from the text at both sites; no leg claims the other's content. Recorded as an observation, not a finding. |

**Split-audit conclusion:** 9/9 hybrid claims state an allocation; 8/9 in
labelled component-split form. No hybrid claim in the paper was found in
which the MACHINE leg silently carries general content or the AUTHOR leg
silently carries machine content — with the two L11.4 boundaries filed
below (Findings 2–3), which concern what the allocated legs actually
deliver, not whether they are allocated.

## 5. Declared-assumption use-site checks (sample)

Rule applied (§0.2, [Declared assumption]): each declared assumption is
"named at every load-bearing use site" and "any claim resting on one
lists it among its dependencies."

| Assumption / declared premise | Use sites in sample | Named at site? |
|---|---|---|
| Paper 11 F.37 declared assumptions (M > 3; S ≥ 1; atoms = nuclei + incorporated simple states) | §11.3 representative construction (nuclei M = 4 + u at u = 0; atoms N = M + S at S = 2), load-bearing for L11.4's nuclei/atoms step | **Named in the §11.3 prose at the construction site** ("under Paper 11 F.37's declared assumptions (M > 3; S ≥ 1; atoms are nuclei plus incorporated simple states)") and in §0.3's [L1-P12] label — but **not listed in L11.4's claim-list entry or registry row**. Finding 5. |
| §11.3 declared identification (surplus → standing opposed pair) | L11.4's meson/baryon step | Named at §11.3 in the open, with two rival renderings and their consequences, and in L11.4's AUTHOR leg at home and registry. **Pass.** |
| §0.4(b) bonding-mode declared receipt | L5.4 (via Theorem 4.2); L10.1 (via A.2/Theorem 4.2) | Named in L5.4's badge text at home and registry; for L10.1, §0.4(b) states the badge carries "the pointer to that theorem, where the receipt stands named" — L10.1's badge reads "conditional on A.2 (well-definedness of T_agg)". **Pass as the paper's own stated form** (the residue question is Finding 4, not a naming failure). |
| Paper 11 §8.6 + §8 premises (L6.2) | Theorem 6.2 proof | Both premises marked before use in the proof and named in the badge at home, theorem site, and registry. **Pass — model form.** |
| Paper 10 §2.4.7 single-source/isotropic restriction (L9.4) | §9.4 construction | Named inside the claim text itself at home and registry ("cited in its single-source, isotropic form only, and no sum of its shares over sources is formed"). **Pass.** |
| A.14's disclosed k_j reading (side count) | L11.4 machine leg | Disclosed in A.14's provenance ("class=paper-defined (disclosed reading)") and in C33's scope note; **not** disclosed in L11.4's own claim text. Finding 3. |

## 6. GS4-C dependency-break table (sample)

For each sampled claim, one load-bearing dependency at a time is removed
from the working packet; derivability is judged from the remaining
printed material.

| Claim | Dependency removed | Derivable without it? | Precise dependency / badge reflection |
|---|---|---|---|
| L11.4 | Declared identification (surplus→opposed pair) | **No** — the meson/baryon step is decided nowhere (the paper's own unsettled-entry rival shows Res ties and no component decides). | Identification is load-bearing and is priced in the AUTHOR leg. Reflected. |
| L11.4 | Paper 11 F.37 declared assumptions | **No** for the nuclei/atoms step in general (the step "holds for every u ≥ 0 and every S ≥ 1" only under M > 3 / S ≥ 1). | Priced as declared assumptions at §11.3/§0.3, but not in the claim's own dependency text. Finding 5. |
| L11.4 | A.14 (machine leg) | Partially — order properties and agreement steps are prose-reconstructible (see §7); tick-stability sharpness witness and mutant rejections are not. | Hybrid split reflects exactly this. Reflected. |
| L7.3 | Paper 9 §4 verbal definition | The construction D and identity (7.4) survive; the claim's reduction clause ("reduces to Paper 9's §4 definition") does not. | The identification is isolated in the AUTHOR leg. Reflected. |
| L7.3 | A.6 | Yes — (7.4) and rationality are one-line exact-rational arguments (§7 below). | Machine leg scoped to the exhibited window. Reflected. |
| L0.3 | Paper 11 §0.5 lock text | No — the list is a disposition *of that lock*; without the quoted lock there is nothing to fix routes for. | Carried [CITED] via L0.4-P12; L0.3 itself is the author's list. Reflected. |
| L11.2 | A.1/A.2/A.6 | No — the claim is a machine claim over sizes 1–12; prose §11.3 Edge 1 offers AUTHOR-level carry beyond enumeration but the badged claim is the enumerated one. | Badge [LEVEL A: MACHINE] with the range in the claim text. Reflected. |
| L11.3 | Edges 1–3 (declared limits) | The verdict without its edges would overclaim (enumeration horizon, taxonomy admission, packing). With them, the verdict is exactly as wide as its construction argument. | Edges named in the claim and at the home section. Reflected. |
| L5.4 | Definition 5.8 / Proposition 5.9 (joint counts) | **No** — this is the historical witness: the v3 form without joint counts was killed by C32's firing (G8 named-pair exhibit). | The v4 claim text names the extension and the firing. Reflected. |
| L5.4 | Theorem 4.2 (hence the §0.4(b) receipt) | No for the orbit-count leg (Proposition 5.3(iii) rests on Theorem 4.2's exactness, per L5.3's own conditional note). | Named in the badge text at home and registry. Reflected (residue: Finding 4). |
| L8.10 | Proposition 5.3's orbit structure | The conjecture's *statement of what a proof would need* cannot be formulated without it; nothing is derived, so nothing breaks. | Conjecture priced [LEVEL B]; see Finding 6. |
| L9.4 | Paper 9 §6 local saturation behaviour | No — J_sat is defined by summation over exactly that behaviour; remove it and the census has no per-junction criterion (§0.3 [L2-P12] states the step is Paper 9's, the population construction this paper's). | Named in the claim text. Reflected. |
| L9.4 | Paper 10 eq. (2.4) | No — capacity and demanded load are read from the junction's own entries "under Paper 10 eq. (2.4)". | Named in the claim text. Reflected. |
| L6.2 | Paper 11 §8.6 | No — the printed proof's only substantive step is §8.6's factorization. | Named in the badge (home, theorem, registry). Reflected. |
| L6.2 | Paper 11 §8 role-occupancy | No — outcome equality alone does not yield role equality; the proof marks this premise separately before use. | Named in the badge. Reflected. |
| L1.2 | Paper 11.5 §§11.5–11.6 source text | No — a [CITED] claim stands or falls with its source; the packet contains the source and the debt text is present there. | Badge [CITED — L4-P12]. Reflected. |
| L10.1 | A.2 / Theorem 4.2 | No — A.3's own coverage map places T_agg's well-definedness and determinism on many-junction populations outside its check, on Theorem 4.2. | Named in the badge ("conditional on A.2"). Reflected. |
| L10.1 | The §5 prose (p, c) argument | **No** — without it, A.3's finite systems do not yield the claim over arbitrary finite populations. | **Not reflected** in the [LEVEL A: MACHINE] badge. Finding 1. |
| L2.1 | Paper 11 §4.1 / claim 41 | No — the claim is the inheritance itself. | Inheritance line in §0.4's prescribed form. Reflected. |

## 7. GS4-D proof–code separation pairs (sampled hybrid claims: L7.3, L11.4)

For each: (a) the general proof from printed premises, written without
citing the script; (b) the independent reproduction of the finite
machine-checked range, written without citing the prose proof. Neither
deliverable cites the other as a substitute.

### 7.1 L7.3-P12

**(a) General proof from printed premises.** Premises: eq. (7.1)
R(P, W) = Σ_{b∈P} Σ_{τ∈W} r_b(τ) with r_b(τ) integers; eq. (7.3)
D(P, W) = R(P, W)/(|P|·|W|); the local density of body b over the shared
window W is d_b = (Σ_{τ∈W} r_b(τ))/|W|. Then D is a ratio of two integers,
hence an exact rational — no further premise is used. And
mean_b d_b = (1/|P|) Σ_b (Σ_τ r_b(τ))/|W| = (Σ_b Σ_τ r_b(τ))/(|P|·|W|)
= R/(|P|·|W|) = D, by commutativity of finite integer summation and exact
rational arithmetic over the shared denominator |W|. This is eq. (7.4) in
general, for every finite P and W. The remaining clause — that at |P| = 1
this D *is* Paper 9 §4's temperature definition — is not proved here or
in the paper: it is an identification of a formula with a verbal
definition, and the paper prices it in the AUTHOR leg. This examiner
verified the source wording exists (paper9.txt L244) and that the
one-body case of (7.3) has the verbal definition's form (a per-tick count
of rewrite events at one body, i.e. its localized density/frequency per
tick); the identification itself is a declaration, correctly legged.

**(b) Independent finite reproduction.** Artifact `repro_L73.py` /
`repro_L73.out` in this submission directory (examiner's own code, exact
`Fraction` arithmetic, no use of A.6): (i) the Appendix D exhibit's
printed local densities (LD.5-P12) average to exactly the printed
D = 55/36; (ii) 2,000 random instances (|P| ≤ 8, |W| ≤ 6, counts < 50)
satisfy (7.4) exactly and return rationals in every case. Result: PASS.

### 7.2 L11.4-P12

**(a) General proof from printed premises.** Premises: the §11.3
definition K(P) = (Ntot, Res, Tau0, Ss, Su, −Btot, CenSig) read
lexicographically, components as defined there; Paper 11 §7.5's T rule as
restated at §4 (admissible iff A[k] = −B[k] ≠ 0; the canonically first
admissible pair is zeroed; τ = Σ squares, falling by exactly 2 per
action); Definition 4.1's scope (multi-sided junctions carried through
unchanged). *Total preorder:* lexicographic order on tuples of totally
ordered components is total and transitive — finite arithmetic on the
definition. *Name-invariance:* every component is a population sum, a
junction-set aggregate, or a sorted multiset; none reads member order.
*Computed from ledger data alone:* each component's definition cites
§3 records, §4 junction data, or §3.2 count vectors only. *Agreement
steps:* from §11.3's printed representative table, the five steps decide
at Ss, Ntot, Res, Ntot, Ntot respectively (recomputed in (b) below from
the table alone). *Tick-stability:* the printed §11.3 argument shows
Ntot, Btot, CenSig stand because the tick acts on junction local states,
creates/destroys no junction, and changes no junction's consumed ports —
**but for Ss and Su the paragraph's step is the sentence that a count
vector's components "(N, the k_j multiset, B, Σs², Σu) [are] each now
shown standing", where Σs² and Σu have not individually been shown to
stand, and the split itself records that §4 states no tick-dynamics for
body records' (N, Σs², Σu).** The gap is filed as Finding 2; the proof
here is otherwise complete from printed premises, and Res/Tau0
non-invariance is witnessed in (b).

**(b) Independent finite reproduction.** Artifact `repro_L114.py` /
`repro_L114.out` (examiner's own implementation of K from the printed
definition; Btot/CenSig not consulted, because every step §11.3 names is
decided before −Btot — stated here as this reproduction's boundary):
(i) the six representatives' keys reproduce §12.1's order, decided at
exactly the components §11.3 names (Ss; Ntot; Res; Ntot; Ntot);
(ii) name-invariance holds over 42 two/one-member populations under all
permutations, and the induced order is a total preorder on that set;
(iii) an independent sharpness witness is found: the one-junction
population presenting ((+1,+1),(−1,+1)) precedes the one presenting
((0,),(+1,)) at declaration (Res 0 < 1) and follows it at rest
(Tau0 2 > 1, Res equal) — an order reversal of exactly the kind the
claim's tick-stability clause declares possible at Res/Tau0 and
impossible at the invariant components. Result: PASS over the stated
finite range.

## 8. GS4-H change-log integrity

**Selection, recorded before analysis (rule §6.1 applied to the frozen
paper's version history, which runs v1 → v4 corrections rounds 1–10, the
last entry dated 2026-10-31):**

- **Class (a) — most recent change that altered a claim's scope:**
  *Corrections — 2026-10-28 (round 7), item (1)* — C33's killer scoped to
  A.14's disclosed domain, "the disjunct's scope declared to be the
  claim's scope" (a scope alteration of L11.4-P12's machine content).
  (Rounds 8–10 alter registers, a script's provenance block, and badge
  allocations, but no claim's scope; round 7 is the most recent
  scope-altering entry, its items (1)–(2) both being scope/caveat
  enactments on the author's ruling.)
- **Class (b) — most recent change that altered a verification script or
  fixture:** *Corrections — 2026-10-31 (round 10), item (1)* — script
  A.15's INPUT_PROVENANCE block rewritten (compound bindings re-classed
  member by member).
- **Class (c) — most recent change that altered a badge, dependency, or
  falsification statement:** *Corrections — 2026-10-31 (round 10),
  item (2)* — L8.3-P12's claim-list component split conformed to its
  Appendix B row (a badge-allocation change). Items (1) and (2) of round
  10 are distinct changes within one entry, so no class collision arises
  under the rule's tie provision.

**Reconstruction and checks** (before/after is reconstructible only from
the version history's own text — no earlier tree is in the packet; that
boundary is recorded, and each check below is against the *current*
frozen text, which is what the log claims the changes produced):

- **Round 10 item (1) — A.15 provenance (script class).** Log's before:
  "script A.15's INPUT_PROVENANCE block assigned single class tokens to
  compound bindings". Log's after: "its entries now class each member as
  the source script's own block classes it — T cited-paper via A.12
  (Paper 11 §7.5); standings and joint counts paper-defined (Definitions
  5.7–5.8); the capability profile paper-defined via A.4 (§6's
  construction); A.4's outcome rules arbitrary-representative; assignment
  counts paper-defined via A.5 (§§8.2–8.4)". Current text (A.15 listing,
  L14004; INPUT_PROVENANCE at ~L14136): entries read exactly so — T:
  "class=cited-paper via the suite's own A.12 (Paper 11 §7.5…)";
  standings/joint counts: "class=paper-defined via the suite's own A.12
  (Paper 12 Definitions 5.7-5.8)"; capability profile:
  "class=paper-defined via A.4 (Paper 12 §6's construction…)"; outcome
  rules: "class=arbitrary-representative via A.4"; taxonomy:
  "class=control via A.4"; roles split cited-paper / paper-defined;
  assignment counts: "class=paper-defined via A.5's multinomial (Paper 12
  §§8.2-8.4)". **The log describes the actual current difference-form
  accurately.** Test correspondence: A.15 is a suite-level exhibit check
  cited by no claim (Appendix B script key, L2808); the Appendix B
  preamble records the suite at 18/18 PASS on the round-10 build
  (2026-10-31) — SOURCE-REPORTED by this examiner (Role C did not re-run
  the suite; execution is Role D's charter). No script in the packet
  evidence checks A.15's provenance block itself; the change's test is
  the suite re-run, as recorded.
- **Round 10 item (2) — L8.3 split (badge class).** Log's before: the
  claim-list split misallocated the all-n generality (the L8.3-class
  split mismatch). Log's after: "L8.3-P12's claim-list component split
  now allocates the all-n generality of (8.7) to the AUTHOR leg exactly
  as its Appendix B row already did". Current text: this examiner
  extracted the split strings from the §8 claim list (L1964) and the
  registry row (L2860) and compared them — **verbatim identical**,
  AUTHOR leg carrying "the all-n generality of (8.7) beyond that range,
  carried by §8.3's printed induction, which A.5's coverage expressly
  leaves to the prose". The log's further statement that the four seam
  sites (L3.4, L7.3, L11.1, L11.4) "were swept to the same standard" is
  consistent with §4 of this submission: all four carry labelled splits
  allocating prose-carried general content to AUTHOR legs at home (and,
  where a row states a split, at the row). **Accurate.** Test
  correspondence: H.1's registry-vs-home badge identity check (its
  docstring records the round-4 addition of exactly this check) is the
  suite mechanism over this change class; suite status SOURCE-REPORTED
  as above.
- **Round 7 item (1) — C33 scope (claim-scope class).** Log's before:
  C33's killer unscoped. Log's after: killer "scoped in its own text to
  the domain A.14's coverage discloses (its side-count reading of the
  record's k_j), the scope stated by the mechanism — a consumed-port
  count different from that side count — with the battery's k_j = 3, 4
  two-sided space named as its instance, and the disjunct's scope
  declared to be the claim's scope". Current text (C33, L2706) contains
  the scope note in exactly those terms, mechanism and k_j = 3, 4
  instance included. **Accurate.** Test correspondence: C33 "checked by
  A.14"; L11.4's registry row names A.14; suite status SOURCE-REPORTED.

**GS4-H conclusion:** all three selected changes are described by the log
in terms that match the current frozen text at the changed sites; no
change-log inaccuracy was found in the selected sample. The one systemic
observation is recorded, not filed as a defect: before/after can be
reconstructed only from the log's own prose, since no earlier tree is in
the packet — the "before" state of each change is SOURCE-REPORTED by the
log itself, and this examiner's verification covers the "after" state
and the log's fidelity in describing its form.

---

## 9. Findings

### FINDING 1 -- L10.1-P12's [LEVEL A: MACHINE] badge outruns A.3's validation artifact
- Target claim: L10.1-P12, §10 (claim list L2510; registry L2875)
- Exact target text: "[LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)] — Eventual periodicity of aggregate trajectories on finite populations; pre-period/cycle decomposition as exact counting." (L2510; registry L2875: "Eventual periodicity of aggregate trajectories on finite populations; the pre-period/cycle decomposition (p, c) is exact counting | [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)]")
- Domain and required property: Native domain = aggregate trajectories of arbitrary finite populations under T_agg. Required property (paper's own §0.2, L48): a [LEVEL A: MACHINE] badge "is exactly as wide as its validation artifact: the script checks what the script checks, and the prose around it claims no more."
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §0.2 badge definitions; A.3's embedded listing and its COVERAGE block (listing head L4423; coverage at ~L4452–4495); blind_claims.md (4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f) for A.3's provenance classes.
- Method and complete test space: Textual audit of every site that prices L10.1 (home, registry, §0.4(b)) against A.3's own printed coverage map and provenance block; no computation involved. Test space = the claim's full stated domain (all finite populations) vs. A.3's stated verified domain.
- Witness / artifacts: Textual witness pair. (i) A.3's coverage map states its verified domain as "the finite systems above (single-junction T-systems in full, three declared toy systems in full)", places "that T_agg on a many-junction population is well-defined and deterministic (that is Theorem 4.2, script A.2's remit); multi-junction state spaces are not enumerated here" *outside* the machine check, and concludes: "The badge this script supports is the decomposition/frequency arithmetic, conditional on A.2." (ii) A.3's provenance classes TOY1/TOY2 transition tables and the TOY3 re-presentation rule as class=control — "declared toy systems", TOY3 "not a framework rule". The step from those finite systems to *arbitrary* finite populations is, by A.3's own map, the (p, c) argument of §5's proof of Proposition 5.3(iii), which "consumes" determinism, totality, finiteness — a prose proof, not script output. Second route (§9.3): the paper's own allocation precedent — L8.3-P12 and L11.4-P12 both place exactly this kind of general content (all-n generality; general order/tick-stability properties) in an AUTHOR leg under a hybrid badge; L10.1 has no AUTHOR leg and no split.
- Coverage map: (1) native domain: eventual periodicity of T_agg trajectories over all finite populations. (2) verified domain: this examiner's textual check covers all pricing sites of L10.1 and A.3's full printed coverage/provenance text. (3) map between them: claim text ↔ badge text ↔ script coverage text, compared verbatim. (4) what the map preserves: the exact domains each artifact claims. (5) what stays outside: whether A.3's code matches its coverage text (Role D's execution remit; NOT RUN by this examiner), and the truth of the §5 (p, c) argument itself (reconstructible by standard finite-state reasoning — the claim's content is not impugned, only its badge allocation).
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: Under the paper's own §0.2 definition, a MACHINE badge is exactly as wide as its validation artifact; A.3's artifact supports, by its own coverage map, the decomposition/frequency arithmetic over single-junction T-systems and three toy systems, conditional on A.2. The claim as badged asserts the general statement over arbitrary finite populations, whose general leg is §5's prose argument plus Theorem 4.2. That is the L8.3-class split mismatch in its inverted form (general content under a machine-only badge). The repair the paper's own precedent prescribes is a hybrid badge with the general leg allocated to AUTHOR (prose) — the claim's content would then stand as allocated. As written, the badge overstates the machine domain: LIMIT, not BROKE, because the missing leg exists in the paper (§5) and is merely unpriced in this badge.

### FINDING 2 -- L11.4-P12 tick-stability: the §11.3 prose step for Σs² and Σu is asserted, not shown
- Target claim: L11.4-P12, §11.3/§11.4 (claim list L2677; registry L2884)
- Exact target text: Registry split (L2884): "…and the general tick-stability theorem, carried by §11.3's prose proof under §4's stated dynamics (§4 states no tick-dynamics for body records' (N, Σs², Σu)), A.14's enumeration corroborating over its enumerated domains". §11.3 proof paragraph (L2651): "…so each body's k_j multiset stands, and with N standing, B stands; and a count vector's components are exactly (N, the k_j multiset, B, Σs², Σu), each now shown standing, so CenSig stands with them".
- Domain and required property: Native domain = all declared populations under the aggregate tick. Required property: Ss and Su (the population sums of Σs² and Σu) are tick-invariant in general, as the claim's "tick-stability exact" asserts — this requires a premise about how the tick acts on, or does not act on, body records' Σs²/Σu values.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §11.3 key paragraph and proof, §4, L11.4 home and registry texts; blind_claims.md (4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f), where this examiner recorded the same reservation blind (R-B1) before opening the paper.
- Method and complete test space: Line-by-line reading of the §11.3 tick-stability paragraph against the claim's split; check of what the paragraph actually derives for each of the five asserted invariants (Ntot, Ss, Su, Btot, CenSig). Test space = the five invariants × the premises §4 states.
- Witness / artifacts: Textual witness pair. (i) The paragraph derives: the tick "acts on junction local states alone: it creates and destroys no junction and changes no junction's consumed ports, so each body's k_j multiset stands, and with N standing, B stands" — this shows N, the k_j multiset, and B standing. (ii) For Σs² and Σu no step is given: they enter only in the summarizing clause "each now shown standing", while the claim's own split discloses that "§4 states no tick-dynamics for body records' (N, Σs², Σu)". The clause "the tick acts on junction local states alone" could carry Σs²/Σu if §4 defined T_agg's action domain as junction local states with body records carried — but that is exactly the premise the split says §4 does not state for these record fields. Second route (§9.3): the registry split's parenthetical vs. the home split's parenthetical — both print the §4 gap while assigning the theorem to the prose proof; the disclosure is consistent at both sites, so the gap is in the proof's premise base, not in transcription.
- Coverage map: (1) native domain: tick-stability of K's components over all declared populations. (2) verified domain: the printed proof text and both split texts, read in full. (3) map between them: each asserted invariant traced to the sentence(s) of the proof that purport to show it. (4) what the map preserves: which invariants have a derivation step (Ntot, Btot, CenSig-via-shown-components) and which rest on the summarizing clause (Ss, Su). (5) what stays outside: A.14's enumerated-domain corroboration (not re-run by this examiner beyond §7.2(b)'s independent mini-reproduction, which does not test Σs²/Σu dynamics); whether some other §4 sentence supplies the missing premise under a different reading — the adjudicator can check §4's Definition 4.1/Theorem 4.2 statements against this finding.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: The AUTHOR leg of L11.4 asserts a *general* tick-stability theorem "carried by §11.3's prose proof", but for two of the five invariants the printed proof's only step is a summarizing assertion, and the paper itself records that the dynamics premise for those record fields is not stated in §4. A missing derivation step where the claim asserts the establishment: category B. LIMIT rather than BROKE: Ntot/Btot/CenSig stand as argued, the machine leg corroborates over its enumerated domains, and the gap is a named premise gap (a §4 statement of T_agg's action on body records would close it), not a counterexample.

### FINDING 3 -- L11.4-P12's machine leg verifies A.14's disclosed side-count reading of k_j, not the §11.3 definition's port-count reading, where the two part
- Target claim: L11.4-P12, §11.3/§11.4 (claim list L2677; registry L2884); falsification condition C33 (L2706)
- Exact target text: C33 scope note (L2706): "wherever a junction's §3 record carries a consumed-port count different from that side count (the two-sided junctions with k_j = 3 or 4 of the battery's witness space; a junction of any side count consuming more ports than its sides), the §11.3 definition, which reads k_j as Paper 11 §4.1's port count, and A.14's disclosed reading separate, first at the −Btot component — such a population stands outside this disjunct's scope, the disjunct's scope being the claim's: L11.4-P12's machine content is asserted over A.14's disclosed domains, and outside them no machine content is claimed for this condition to kill." A.14's provenance (blind packet, verified against the listing's provenance class): "The k_j multiset is read from the side count, as THE MAP states: class=paper-defined (disclosed reading, as in A.12)."
- Domain and required property: Native domain = the §11.3 key *as defined* (k_j = Paper 11 §4.1's consumed-port count) over all declared populations. Required property: the MACHINE leg of a hybrid badge checks the claim's content as defined, over the domains it states.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §11.3 definition, §0.5 terminology note (the three counts: junction arity as port count, side count, port-vector length), C33; blind_claims.md (4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f) for A.14's provenance text.
- Method and complete test space: Comparison of three printed readings of the record's k_j component — §11.3's definition (port count, via Paper 11 §4.1 and this paper's §0.5 terminology note, which states junction arity k_j "is the number of ports a junction consumes… and the only sense in which this paper uses the word"), A.14's provenance (side count), and C33's scope note (which adjudicates the parting explicitly). Test space = all junctions where side count ≠ consumed-port count, a space §11.2 clause (ii) itself constructs (a two-sided junction consuming more than one port at a configuration).
- Witness / artifacts: The C33 scope note quoted above is the paper's own witness: it names the parting domain (two-sided junctions with k_j = 3 or 4; any junction consuming more ports than its sides), the first component at which the two keys separate (−Btot), and declares the machine content unasserted there. Second route (§9.3): A.14's provenance block independently prints the side-count reading as a "disclosed reading" of class paper-defined — i.e. a reading this paper adopts, distinct from the definition's cited-paper reading.
- Coverage map: (1) native domain: K as defined at §11.3 over all declared populations. (2) verified domain: the definition text, the provenance text, and the C33 text, read in full. (3) map between them: component-wise comparison of the two k_j readings through CenSig and B = 6N − Σk_j into −Btot. (4) what the map preserves: exact agreement of the two readings wherever every junction's consumed-port count equals its side count (which includes §11.3's representatives and §7.2(b)'s reproduction range). (5) what stays outside: A.14's code itself (Role D's remit; NOT RUN by this examiner) and any population outside the parting domain.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: Over the parting domain, no machine check of the key *as defined* exists in the paper: the script checks a disclosed variant reading. The paper discloses this with unusual completeness (provenance class, C33 scope note, §0.5 terminology note), so this is not a hidden defect and cannot be BROKE — the claim, read together with C33, asserts no machine content there. But L11.4's own claim text and registry row do not carry the restriction: a reader of the claim alone receives "the key's computation and behaviour over A.14's enumerated domains" without the k_j-reading boundary, which lives in the script's provenance and the falsification condition. The verified domain is a proper subset of the defined domain, with the boundary named here and at C33: LIMIT. (Whether claim-site disclosure is required is the adjudicator's call; Role C records that the disclosure exists in the paper but not at the claim site.)

### FINDING 4 -- The §0.4(b) transitive residue: sampled claims L5.4-P12 and L10.1-P12 stand, by the paper's own record, one grade below their printed conditional badges, pending an author ruling the paper has not recorded
- Target claim: L5.4-P12 (§5 list L1131; registry L2840) and L10.1-P12 (§10 list L2510; registry L2875), via §0.4(b) (L91)
- Exact target text: §0.4(b) (L91): "Priced transitively through this receipt, the claims consuming the premise stand one grade below their printed conditional badges; that residue, recorded by the X2 diagnosis, stands until the author rules the bridge rule's registry-keyed reading governs or the premise is registered at its source." L5.4's badge (L1131/L2840): "[LEVEL A — scoping result, resting on L5.3-P12 as restated, Proposition 5.9, Theorem 4.2, and §3 — through Theorem 4.2, on §4.3 as received at §4, its bonding-mode condition standing as §0.4(b)'s declared receipt]".
- Domain and required property: The bridge rule (§0.3): "L_claim ≤ min(L_i) — a claim cannot outrank its weakest dependency." Required: a claim resting on a declared receipt (author-strength declared content, "no badge is printed for the premise anywhere in this paper", §0.4(b)) may not print above the price that dependency carries, unless the governing reading is ruled.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §0.3 bridge rule, §0.4(b) in full, L5.4/L10.1 home and registry badges, round-5 version-history entry (L69417) restating that the residue "is not discharged by this round, and stands until the author rules…".
- Method and complete test space: Dependency tracing of every sampled claim through Theorem 4.2 / A.2 to the §0.4(b) receipt (the paper's own §0.4(b) site list performs the tracing; this examiner verified L5.4's and L10.1's badges name the chain as §0.4(b) prescribes), then a search of the version history (rounds 5–10) and §0.4 for any subsequent author ruling discharging the residue. Test space = all sampled claims consuming the premise directly (L5.4) or at one remove (L10.1); both are named in §0.4(b)'s own text.
- Witness / artifacts: Textual witness pair: §0.4(b)'s residue sentence (quoted above) vs. the printed badges of L5.4 and L10.1, which stand at conditional [LEVEL A] / [LEVEL A: MACHINE] with no grade reduction printed. Second route (§9.3): the round-5 history entry independently records the residue as undischarged, and no entry in rounds 6–10 records the ruling §0.4(b) names as the discharge condition (the round-9 [L1-P12] fence and round-10 items concern other links).
- Coverage map: (1) native domain: all claims in the paper consuming the bonding-mode premise, directly or transitively. (2) verified domain: the two sampled consumers (L5.4, L10.1), their full dependency chains as printed, §0.4(b), and the complete version history. (3) map between them: printed badge ↔ bridge-rule price through the declared receipt, per §0.4(b)'s own pricing sentence. (4) what the map preserves: the disclosure itself — the residue is named in the open at §0.4(b), at the receipt's site, with its discharge conditions. (5) what stays outside: non-sampled consumers of the premise (L4.2, L4.4, L5.3(iii), L3.2 and others §0.4(b) lists) — the same residue presumably applies there, but this finding is filed only over the sampled claims Role C traced.
- Category (self-classified, spec section 9.5): E
- Proposed badge: LIMIT
- Reason: This is a question the paper explicitly leaves open: §0.4(b) states the residue, names the two events that would discharge it (an author ruling on the bridge rule's registry-keyed reading, or registration of the premise at its source), and records that neither has occurred. Under §9.5 category E it is never a defect and cannot sustain BROKE. It is filed because Gate 5 asks whether any sampled claim outranks its weakest dependency: on the paper's own transitive pricing, L5.4 and L10.1 do, by one grade, until the named ruling lands — a LIMIT on both badges' present printed strength, fully disclosed by the paper itself.

### FINDING 5 -- L11.4-P12's claim-list entry and registry row do not list the F.37 declared assumptions the claim rests on
- Target claim: L11.4-P12, §11.4 (claim list L2677; registry L2884)
- Exact target text: §0.2, [Declared assumption] (L53): "A declared assumption is never load-bearing in silence: any claim resting on one lists it among its dependencies." §11.3 (representative construction): "The nuclei representative takes the node count M = 4 + u at u = 0, and the atoms representative N = M + S at S = 2, under Paper 11 F.37's declared assumptions (M > 3; S ≥ 1; atoms are nuclei plus incorporated simple states)… their step reads M < M + S and holds for every u ≥ 0 and every S ≥ 1, not only at the exhibited point". L11.4's claim-list entry (L2677) and registry row (L2884) state the claim, its split, and script A.14; neither lists the F.37 assumptions among dependencies.
- Domain and required property: The nuclei/atoms step of L11.4's agreement content, in its general (parametric) form. Required: per §0.2, the resting claim lists the declared assumptions among its dependencies.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §0.2, §0.3 [L1-P12] label, §11.3 construction prose, L11.4 home and registry.
- Method and complete test space: Grep-and-read audit of every site that prices or states L11.4 (§11.3 prose, §11.4 claim list, Appendix B row, §0.3 labels, C33) for a dependency listing of the F.37 assumptions. Test space = all L11.4 pricing sites in the frozen paper.
- Witness / artifacts: Textual witness pair: (i) §11.3's prose names the assumptions at the construction site, and §0.3's [L1-P12] dependency label lists them ("the declared assumptions §11.3 names from Paper 11 F.37 (M > 3; S ≥ 1; atoms are nuclei plus incorporated simple states), carried as declared assumptions"); (ii) the claim's own entry and row — the sites a registry reader prices the claim from — contain no dependency list naming them. Second route (§9.3): contrast with L5.4-P12, whose entry and row both carry their full dependency chain including the §0.4(b) receipt — the paper's own standard, met there, is not met here.
- Coverage map: (1) native domain: L11.4's dependency disclosure. (2) verified domain: all L11.4 pricing sites, read in full. (3) map between them: §0.2's listing rule applied site by site. (4) what the map preserves: the assumptions ARE named at the construction site and in the §0.3 label — the gap is confined to the claim's own entry/row. (5) what stays outside: whether the §0.3 label's listing satisfies §0.2's rule as the paper intends it (a reading question for the adjudicator); the correctness of the F.37 assumptions themselves (Paper 11's content, not re-derived here).
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: The general nuclei/atoms step rests on three declared assumptions; §0.2 requires a resting claim to list its declared assumptions among its dependencies. They are listed in the paper (prose site, §0.3 label) but not in the claim's entry or registry row — a missing required dependency listing at the claim site, category B in its disclosure form. LIMIT, not BROKE: the assumptions are disclosed in the open at two other sites, the exhibited step (u = 0, S = 2) is machine-checked by A.14, and no content of the claim is false as far as this check reaches.

### FINDING 6 -- L8.10-P12: a conjecture the text says is "not claimed" carries [LEVEL B], while §0.2 assigns conjecture to [NO BADGE]
- Target claim: L8.10-P12, §8 claims (L2011; registry L2867)
- Exact target text: Home (L2011): "Conjecture, stated as a target (§8.6): a proof of the open joint would need a statement over Proposition 5.3's orbit structure… If the joint is underivable in general, the arrow stands as a boundary-condition fact inherited from Paper 9's received asymmetry, and §9's predicate as a construction with no approach content. The joint itself is not claimed. [LEVEL B]". §0.2 (L55): "**[NO BADGE]**: Cannot be derived and is not declared as an assumption. Under Paper 11's D.2 rule: conjecture — do not cite as established." §0.2 (L50): "**[LEVEL B]**: Illustration, conditional reading, declared programme, or author-authorized declaration of weaker standing than [LEVEL A: AUTHOR]."
- Domain and required property: Badge taxonomy application for expressly-unclaimed conjectures. Required: one claim, one governing badge definition.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §0.2 definitions, L8.10 home and registry, §8.6/L9.6 pointers.
- Method and complete test space: Reading of L8.10's text against both candidate definitions in §0.2; check of home/registry consistency (both print [LEVEL B] — no transcription discrepancy). Test space = the paper's conjecture-class claims in the sample (L8.10 is the only one).
- Witness / artifacts: Textual witness pair: the claim's own words ("Conjecture… The joint itself is not claimed") against §0.2's [NO BADGE] definition ("conjecture — do not cite as established"). Second route (§9.3): the counter-reading is also textual — §0.2's [LEVEL B] expressly includes "declared programme", and L8.10 is a declared statement of what a proof would need (a programme/target), with L9.6-P12 carrying the open joint as a "[Scope statement — author]" beside it. The two definitions genuinely overlap on this text; the paper does not say which governs.
- Coverage map: (1) native domain: the badge taxonomy of §0.2 as applied to unclaimed conjectures. (2) verified domain: §0.2's definitions and L8.10's two pricing sites, read in full. (3) map between them: definition-by-definition applicability check. (4) what the map preserves: home/registry badge identity (consistent), and the claim's substantive honesty (the joint is not asserted anywhere as established — §§8.6/9.6 and LD.8 all restate the openness). (5) what stays outside: all non-sampled conjecture-class rows in the registry; any author intention not printed in the paper.
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: Filed as a category-A tension *within the paper's own rules*, at the weakest strength the evidence supports: two of §0.2's badge definitions each plausibly govern L8.10, they price it differently ([NO BADGE]: "do not cite as established" vs. [LEVEL B]: an honest weaker endorsement), and the claim text's own "not claimed" language sits closer to the former. No reader is misled about the joint's status — the openness is restated at every site — so this is a taxonomy-application ambiguity, not a substantive overclaim: LIMIT, with the resolution (a ruling on which definition governs declared conjectures-as-targets) reserved to the author/adjudicator.

### FINDING 7 -- The "[Construction — Paper 12; …]" badge family (incl. sampled L9.4-P12) is enforced by H.1's taxonomy but never defined in §0.2
- Target claim: L9.4-P12, §9 claims (L2288; registry L2871), as the sampled instance of a paper-wide badge family
- Exact target text: L9.4 badge (both sites): "[Construction — Paper 12; components inherited as cited]". §0.2 (L44): "Every claim in this paper carries an epistemic badge:" followed by definitions of [LEVEL A], its three subtypes, [CITED], [LEVEL B], [Declared assumption], [LEVEL C], [NO BADGE], and Denied [Level A] — no definition of "Construction", "Definition", "Scope statement", or "AUTHOR" as badge strings. H.1's embedded TAXONOMY list (~L17049) does include "Definition", "Construction", "Scope statement", "Scope", "AUTHOR", "Worked instance", "Inherited premise", "Receipt", "Construction — Paper 12" among its recognized classes.
- Domain and required property: The paper's badge system as a whole. Required property (§0 preamble, L31): the machinery is defined "so the paper's verdicts are mechanically checkable, not rhetorically asserted" — a badge a reader cannot price from the defining section fails that stated purpose for those claims.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150) — §0.2 in full, H.1's TAXONOMY list, and a whole-paper count of the badge string "Construction — Paper 12" (12 occurrences, incl. L7.4, L8.5, L9.2, L9.4 claim texts).
- Method and complete test space: Full reading of §0.2's definition list; extraction of H.1's recognized-class list; grep census of non-§0.2 badge strings in claim lists and registry ([Construction — …], [Definition], [Scope statement — author], [AUTHOR] at L5.6). Test space = every badge string borne by a sampled claim, plus the family L9.4 belongs to.
- Witness / artifacts: Textual witness pair: §0.2's closed definition list vs. H.1's wider TAXONOMY list — the machine recognizes classes the prose never defines. Second route (§9.3): the sampled instance itself — L9.4's content (a construction over cited components) is honestly described by its string, and §0.3's [L2-P12] label explains the construction/inheritance split for its saturation component; what is missing is only the §0.2-level definition of what the badge *guarantees* (compare [LEVEL A: AUTHOR]'s three enumerated guarantees).
- Coverage map: (1) native domain: all claims carrying non-§0.2 badge strings. (2) verified domain: §0.2, H.1's taxonomy, L9.4's sites, and the grep census of the "Construction — Paper 12" string. (3) map between them: string ↔ definition lookup. (4) what the map preserves: these claims assert no Level A strength, so no Level A outranking occurs; L9.4's own dependency disclosure (Finding-free, §2 above) is complete. (5) what stays outside: the full census of every non-§0.2 badge string paper-wide (only the "Construction — Paper 12" family was counted); whether an Appendix or §13 passage defines these classes elsewhere (grep found no definition site; §0.2 is the section that purports to define the badges).
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: A missing definition required by the paper's own architecture: §0.2 purports to define every badge, H.1 enforces a wider taxonomy, and claims like L9.4 are priced in a currency §0.2 never mints. Category B (a derivation/definition the apparatus requires is absent), LIMIT (the affected claims assert no strength beyond construction-over-cited-components, which their texts disclose in full; nothing is overclaimed — a reader simply cannot price the badge from the defining section).

---

## PROCESS STATUS

- Frozen paper identity: READ; SHA-256 recomputed and matched to the brief (SOURCE-VERIFIED).
- Packet sources: protocol_examiner_extract.md READ; sample_selection.txt READ; blind_claims.md READ; Paper_12_v4.md READ (sections and sites cited; the paper was audited by targeted extraction and full reading of every cited site, not read cover-to-cover — stated plainly); paper_11_v69.md, paper_11_5_v26.md, paper9.txt, paper10.txt, paper2_section11.txt READ at the spot-check sites cited in §2/§5 (SOURCE-VERIFIED for those sites only); blind_verification.txt NOT READ (not required by Role C's charter).
- GS4-B blind pass: completed and SEALED in BLIND_SEALED.md (SHA-256 988fa8396c880ced8cb7388adbb0f8982a60554e70f5f811fc4d0bca6532f63b) before any Appendix B row or claim-list badge string for a sampled claim was opened. This submission is SEALED as of its filing; the reveal addendum is a separate later file (REVEAL_ADDENDUM.md) and will not alter §1 or BLIND_SEALED.md.
- GS4-C graph, weakest-dependency tracing, split audit (sample + all nine hybrid claims), assumption use-site checks, dependency-break table: completed from the frozen text (READ; SOURCE-VERIFIED at the cited lines).
- GS4-D: general proofs written from printed premises; independent reproductions RUN by this examiner (repro_L73.py, repro_L114.py — both PASS, outputs in repro_L73.out / repro_L114.out in this directory). The paper's own scripts (A.1–A.15, FW.1, G.1, H.1) were NOT RUN by this examiner — execution and suite status are Role D's charter; every suite figure cited here (18/18 on the round-10 build) is SOURCE-REPORTED from the Appendix B preamble and version block, never presented as this examiner's run.
- GS4-H: selection recorded in §8 before analysis; all three changes' "after" states SOURCE-VERIFIED against the frozen text; "before" states SOURCE-REPORTED from the version history (no earlier tree in the packet).
- Findings: 7 filed, each self-classified under §9.5 with a five-part coverage map and a second route where a defect is proposed. No BROKE is proposed by this examiner: every defect found is a badge-allocation, disclosure-site, or premise-gap boundary in which the paper's own text supplies the mitigating disclosure somewhere — the findings name exactly where.
