# GS4-B BLIND CLASSIFICATIONS — SEALED (Arm N, Role C)

Sealed before opening the frozen paper's Appendix B rows or any claim-list
badge string for the sampled claims. Sources used for this section ONLY:
`packet/roleC_only/blind_claims.md`
(SHA-256 4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f)
and the verdict/category vocabulary of the protocol extract §9
(SHA-256 f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1).
Frozen paper hash verified (not opened for sampled-claim labels):
fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150.

Classification vocabulary used blind: the evidence-leg structure printed in
the packet itself — MACHINE (a named script checks a stated domain),
AUTHOR (definition, ruling, declared identification, or prose proof carries
the content), INHERITED (a cited-paper premise carries the content),
DECLARATION (a stipulation/receipt with no derivation), CONJECTURE
(explicitly not claimed). A claim is "hybrid" when both MACHINE and AUTHOR
legs are printed as load-bearing.

| # | Claim | Blind classification | Basis printed in the blind packet |
|---|---|---|---|
| 1 | L11.4-P12 | **Hybrid [MACHINE / AUTHOR]** | Split printed verbatim: MACHINE (A.14) = key computation/behaviour over A.14's enumerated domains, W1/W4, mutants; AUTHOR = the definition itself (author's ruling 2026-10-28), the native representative construction under §11.3's declared identification over Paper 2 §§11.4–11.5, the general order properties (finite-arithmetic reading, A.14 corroborating), and the general tick-stability theorem (prose proof). Reservation noted blind: the packet itself prints that §4 states no tick-dynamics for body records' (N, Σs², Σu) — the tick-stability AUTHOR leg's premise base looks thinner than the split asserts. |
| 2 | L7.3-P12 | **Hybrid [MACHINE / AUTHOR]** | Split printed verbatim: MACHINE (A.6) = (7.4) identity on the exhibited window + worked-example arithmetic; AUTHOR = (7.4) in general (exact rational arithmetic over shared denominator \|W\|), D's exact rationality in general, and the identification of the \|P\|=1 case with Paper 9 §4's verbal definition. |
| 3 | L0.3-P12 | **DECLARATION [AUTHOR], no machine leg printed** | A stipulation fixing each Paper 11 §0.5-locked word's sole permitted route; enforcement named only as "swept by FW.1", with no script coverage statement printed. No derivation and no machine-checked domain is printed. |
| 4 | L11.2-P12 | **[MACHINE] over an explicitly enumerated domain** | Statement scopes itself: identities "checked across population sizes 1–12, no size-triggered branch"; scripts A.1, A.2, A.6 named; no AUTHOR split and no general (all-sizes) prose leg printed. Any badge beyond the enumerated range would outrun the printed evidence. |
| 5 | L11.3-P12 | **UNCLASSIFIABLE on the blind evidence — no badge justified** | The blind packet prints an empty statement/dependency block and no named script for this claim. On the printed evidence alone there is nothing to classify; this is recorded as a blind-packet coverage fact, not as a judgement on the claim in the paper. |
| 6 | L5.4-P12 | **[AUTHOR] — prose-carried dissolution, no machine leg printed** | The postulate is "unnecessary… discharged by dissolution" over census/flow/joint-count instruments (Definition 5.8); no script named. The load is carried by prose argument plus the C32 firing record at §12. |
| 7 | L8.10-P12 | **CONJECTURE — explicitly not claimed, no Level A badge** | Statement says verbatim: "Conjecture, stated as a target (§8.6)… The joint itself is not claimed," and notes the strong form is already refuted inside the paper. |
| 8 | L9.4-P12 | **[AUTHOR] construction on inherited premises, no machine leg printed** | Exact counts/ratios "built by summation over Paper 9 §6's local saturation behaviour", capacity/load "from the junction's own entries under Paper 10 eq. (2.4)"; Threshold cited to Paper 7, not redefined. No script named; content is definition + inherited premises. |
| 9 | L6.2-P12 | **Hybrid in substance: [MACHINE over a finite control taxonomy + INHERITED general premise]** | A.4 provenance: the one premise ("outcome factors through M = (n+, n−)") is class=cited-paper (Paper 11 §8.6, "inherited"); outcome rules are class=arbitrary-representative (two disagreeing members of the licensed class; claim checked is rule-independence within the class); test taxonomy is class=control (profiles with e+ + e− ≤ 4). The universal statement ("for every role and encounter kind") therefore rests on the inherited §8.6 premise, with A.4 corroborating on a finite taxonomy — not on A.4 alone. |
| 10 | L1.2-P12 | **DECLARATION / receipt [AUTHOR] — transcription claim, no derivation** | "The count→weight debt is as quoted at §1.2, including its two named items and the fill rules" (Paper 11.5 §§11.5–11.6). The claim is that a quotation is accurate; no script named, no derivation printed. |
| 11 | L10.1-P12 | **Hybrid [MACHINE / AUTHOR] in substance** | A.3 provenance: T's rule class=cited-paper (Paper 11 §7.5); the frequency predictions are paper-defined and "never used as inputs"; but TOY1/TOY2/TOY3 are class=control — declared toy systems, "not a framework rule" (TOY3). The machine leg therefore runs on toy controls, while the general claim (eventual periodicity on finite populations, exact (p, c)) must be carried by the finite-state counting argument in prose. |
| 12 | L2.1-P12 | **INHERITED declaration — no independent badge** | Statement says verbatim "**** — inherited. Dependencies: Paper 11 §4.1's single-regime rule and licensed aggregate list govern every aggregate quantity in this paper." No script, no derivation; the entire content is a receipt for Paper 11 §4.1. |

Blind-pass reservations (recorded before any reveal):
- R-B1: L11.4's tick-stability AUTHOR leg — the packet's own parenthetical
  (§4 states no tick-dynamics for body records' (N, Σs², Σu)) sits in
  tension with a "general tick-stability theorem… carried by §11.3's prose
  proof under §4's stated dynamics".
- R-B2: L11.3's empty blind block — if the paper badges this claim, the
  blind packet gave this examiner no route to reproduce that badge.
- R-B3: L6.2 and L10.1 print no explicit "Component split" line, yet their
  provenance blocks show mixed legs; a paper badge of plain [MACHINE] for
  either would, on the blind evidence, overstate the machine leg.

END OF SEALED BLIND SECTION.
