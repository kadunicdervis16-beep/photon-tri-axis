# SUBMISSION — GS-4 Gold v1.0 (house execution, two-arm isolated-context trial)

## Arm N, Role B — Proof and Counterexample Examiner (GS4-A support, GS4-F co-lead)

- Frozen paper: `packet/Paper_12_v4.md`, 69,425 lines. SHA-256 recomputed by this examiner:
  `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150` — matches the brief's freeze value exactly.
- Sample (from `packet/sample_selection.txt`, taken as given): L11.4-P12, L7.3-P12, L0.3-P12,
  L11.2-P12, L11.3-P12, L5.4-P12, L8.10-P12, L9.4-P12, L6.2-P12, L1.2-P12, L10.1-P12, L2.1-P12.
- Materials read: the brief; the packet files listed in the hash table below. I did **not** open
  `packet/roleC_only/blind_claims.md` (Role C material) or `packet/blind_verification.txt`
  (not in my brief's permitted list), and no file outside the packet.
- Method order (charter discipline): every home text and every definition needed for a derivation
  was read first; all derivations and all examiner computations were completed **before** any
  Appendix C verification listing was opened. The post-derivation script consultations are logged
  in §3 of this submission, with line ranges. Source papers (Papers 2, 9, 10, 11, 11.5) were
  consulted as *premise/citation sources* for the cited and inherited claims — that is source
  verification, not consultation of a claim's verification script.
- Artifacts in this directory: `witness_boundary.py` (examiner's own implementations, written
  from the paper's prose definitions; exit 0, all checks PASS), `run_log.txt` (its full output),
  `scan_locked.py` + `scan_locked_out.txt` (L0.3 spot scan).
- Standing cautions applied throughout: a failed attack is not a proof; a finite search is not a
  universal theorem. Where a verdict rests on a finite search, the analytic argument that closes
  the remainder is stated, or the badge is LIMIT with the boundary named.

### Packet hashes (independently recomputed by this examiner)

| file | SHA-256 |
|---|---|
| Paper_12_v4.md | fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150 |
| protocol_examiner_extract.md | f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1 |
| paper2_section11.txt | ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e |
| paper9.txt | defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6 |
| paper10.txt | f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82 |
| paper_11_v69.md | f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb |
| paper_11_5_v26.md | 9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60 |
| sample_selection.txt | 588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766 |

---

## 1. Independent derivation log (all entries completed BEFORE any script consultation)

**L2.1-P12 (inherited constitution).** Derivation = source verification. The §2.3 quotation was
compared character-for-character with Paper 11 v69 §4.1 (packet `paper_11_v69.md` L342): the
single-regime paragraph, the licensed list (N_nodes, N_edges, B = 6N − Σ_j k_j, Σs², Σu), the three
prohibitions (no aggregate state alphabet, no aggregate budget rule, no emergence mechanism), and
the "(Audit rule R15, Appendix H; machine check F.41)" attribution all match the source. I then
checked the reliance: every aggregate construction in §§3–9 is in fact built from exact finite
sums, counts, or rational ratios over the licensed components (census = counts; τ_agg = sum;
D = ratio of sums; Ω = count; J_sat = count; K = tuple of sums, an aggregate over the junction
set, and a sorted multiset of count vectors). No fourth operation appears.

**L1.2-P12 (cited debt).** Derivation = source verification. The three §1.2 blockquotes were
compared with Paper 11.5 v26 §11.6 (packet `paper_11_5_v26.md` L2805–2818): "Combinatorics
supplies the *counts*; the count→weight step is not certified here. It needs two things this paper
does not build: (1) a microstate-counting rule, and (2) a sampling-measure postulate. Both are
Paper 12's work."; "The fill rules — which encounter actualizes with what probability at a given
tick — are the dynamics the framework has not yet built (§11.5)."; "…the fill rules and the
sampling measure are Paper 12's work, named above, not smuggled in here." All three match
verbatim, including the two named items and the fill rules, as the claim asserts.

**L0.3-P12 (declared discipline).** The construction-list table (§0.5) was checked for
well-formedness: each of the nine locked words (temperature; entropy; ensemble;
microstate/macrostate; thermal equilibrium; probability distribution; Gibbs; Boltzmann; k_B)
receives exactly one disposition (constructed / bridged only / excluded). Compliance was then
spot-checked by my own scan (`scan_locked.py`) over lines 1–2903 (§§0–13, Appendices A–B);
classification of the hits is in Finding 1.

**Theorem 4.2 / Proposition 4.3 (substrate for L5.4, L10.1, L11.4).** Re-derived independently:
T reads/writes only its junction's port set (§4 Step 1, from Paper 11 §7.5's rule); Port-Partition
Exactness makes the port sets pairwise disjoint (Step 2); hence actions at distinct junctions
commute (Step 3 — neither action changes any entry the other reads, so the canonically first
admissible index each sees is order-independent); finitely many pairwise-commuting actions give
schedule-independence (Step 4); totality/determinism inherit (Step 5). τ accounting: Δτ_agg is a
finite sum of per-junction deltas, each −2 (acts) or 0 (fixed point, or multi-sided carry-through),
so Δτ_agg = −2·|acting|. My implementation (`witness_boundary.py` §A) confirms commutation on 300
random populations over all application orders, the τ identity, and multi-sided carry-through.

**L5.4-P12 (dissolution).** Re-derived case by case. (a) Long-run frequency: T_agg is a total
deterministic function on a finite state set (finiteness: node states from the 27-state inventory,
junction local states from finitely many port configurations over a fixed declared junction set),
so every trajectory is eventually periodic; over whole periods after the transient the visit ratio
is exactly c_X/ℓ. (b) Single tick: the population stands in one actual state; C_t(X)/|members| is
an exact rational about what stands — no measure over non-occurring states is needed to *define*
it. (c) Fill rules: what actualizes is determined by T's canonical-first rule and Paper 11's
encounter selection (§5.5); frequencies of kinds are census ratios (Prop. 5.3(ii)). Joint
extension: Prop. 5.9(i)–(ii) are one partition argument read two ways — the counted tick set is
partitioned by the last member's class (marginalization) or by the window split (additivity);
verified computationally on 400 random standing tables including k = 3 tuples, offsets, and
repeated names (§H of the artifact). The *need* for the extension was independently confirmed:
my own swap witness (§H5) exhibits two record families with identical per-tick censuses and
identical flow tables whose named joint counts differ (2 vs 0), so joint counts are not
recoverable from census/flow data — the v3 form of the discharge was indeed falsifiable and the
v4 instrument is load-bearing, not decorative.

**L6.2-P12 (capability factorization).** Given the two stated premises — (P1) encounter outcomes
factor through the presented-count profile M (Paper 11 §8.6), (P2) role occupancy attaches to
encounter sides by the encounter's outcome class (Paper 11 §8) — the theorem is a composition of
functions: profile → outcome → role, so equal profiles give equal Cap membership for every (E, R).
That derivation is sound **for the profile of the encounter**. The boundary the proof does not
cross is recorded as Finding 6: Paper 11 §8.6 defines M as a map *from a native encounter* to its
presented (n+, n−) counts (packet `paper_11_v69.md` §8.6, "Coverage theorem"), i.e. M is a property
of the presented pair, while the claim's hypothesis is phrased as a property of the two bodies
("the same presented counts to the encounters of the taxonomy"). My artifact §I exhibits the gap
mechanically: with own presented counts fixed at (1, 1), a counterpart presenting (1, 0) gives
pair profile (2, 1) and a counterpart presenting (0, 1) gives pair profile (1, 2), and any
outcome rule that §8.6's class permits can separate them (my representative rule does:
'plus-led' vs 'minus-led'). The post-derivation consultation of A.4 (§3 below) shows the machine
check models an encounter kind E by its own profile (e+, e−) and outcomes as functions of
(M(G), M(E)) — i.e. the checked content holds the kind's other side fixed by construction. The
prose claim does not state that fixing.

**L7.3-P12 (reconcile density).** Arithmetic re-derived: D(P, W) = R/(|P|·|W|) with
R = Σ_b Σ_τ r_b(τ); writing R_b = Σ_τ r_b(τ), the mean of locals over a *shared* window is
(1/|P|)·Σ_b (R_b/|W|) = R/(|P|·|W|) — exact rational arithmetic, no approximation (artifact §E:
the §7.5 worked example recomputed cell by cell — totals 12, 7, 18, 4; R = 41; D = 41/40; mean of
locals 41/40 — and 300 random ledgers). |P| = 1 reduces to (Σ_τ r_b(τ))/|W| directly. The cap
(7.2): N_reconcile = 97 − v²_contact − s² ≤ 97 because both subtracted terms are squares (≥ 0);
the worked tick 100 − 3 − 40 − 21 = 36 verified, and Paper 10 eq. (2.4) verified at source
(packet `paper10.txt` L985, with (2.2a) at L959 and (2.2c) at L963). The |P| = 1 identification
with Paper 9 §4 was source-checked: Paper 9 §4's words (packet `paper9.txt`, §4) are "Temperature
is the localized density and frequency of chaotic creation-geometry rewrite events per tick" and
§2's form is "The rate of these chaotic rewrite events per ledger tick is what the observer
macroscopically measures as temperature" — both match §7.1's quotations. The identification
itself (single body as the localized region) is the author's, graded AUTHOR in the claim's own
component split; the arithmetic does not depend on it.

**L8.10-P12 (open-joint conjecture).** This claim is a Level B target statement, not a theorem;
the examiner's work is to verify its three factual presuppositions. (i) "No result in this paper
shows that aggregate trajectories drift toward high-Ω records" — consistent with every claim
list in §§1–13 (read in full) and stated identically at §1.8, §§8.6, 9.6. (ii) "The strong form —
rest only at (E2)-maximal records — is already refuted inside this paper" — independently
recomputed from §4's T and §8.7's declared population (artifact §D): trajectory
(12, 0) → (6, 6) → (0, 12) → (0, 12), Ω = 1, 924, 1, 1, τ_agg = 36, 12, 0, 0, (p, c) = (2, 1);
the trajectory rests at (0, 12) with Ω = 1, the table minimum, while τ falls monotonically — the
strong form is refuted and the joint's openness is exhibited, not merely asserted. (iii) The
underlying counting (§§8.2–8.3) was re-derived: Σ_k C(n, k) = 2ⁿ (n ≤ 30), ratio (8.3) exact
(n ≤ 40), C(2m, m) ≥ 2^m (m ≤ 60), 1 − 2^(1−n) ≥ (n−1)/n (n ≤ 80, exact Fractions), and the
balanced record's own share over n = 1…6 is 1/2, 1/2, 3/8, 3/8, 5/16, 5/16 — it does not grow,
exactly as L8.4-P12's honesty entry states (artifact §C).

**L9.4-P12 (saturation census construction).** A construction, so the derivation is a coherence
check of its definitions plus its worked exhibit. Demanded load is defined from the junction's
own eq. (2.4) entries only (N_id, v²_contact, s² at booked values, plus demanded N_reconcile
before the cap); no cross-source sum of Paper 10 §2.4.7 shares is formed — I verified §9.4's text
forms none, and §9.6 states the boundary (unbookable many-source execution demand stands in no
category of the census) in the open. Paper 9 §6 Step 1 was verified verbatim at source (packet
`paper9.txt`, §6): "…reconciliation cycles consume the remaining budget until the standing scan
load plus the chaotic rewrite workload reaches the whole of the local processing capacity, and
the local ledger hits absolute saturation." §9.5's exhibit recomputed (artifact §F3): demands
105/88/100, booked 100/88/100 (total 288 of 293), deferred 5, J_sat: 0 → 2, fraction 2/3; the
exactly-at-capacity junction J₃ (demand 100) is saturated, consistent with the definition's
"reaches the whole of its local processing capacity" (≥ 100). §9.3's clause arithmetic also
recomputed (§F1–F2): the flowing (2, 2) example satisfies (9.3) with Ω = C(4, 2) = 6 maximal
(equilibrium), and the frozen (4, 0) census is stationary with Ω = 1 (not equilibrium).

**L10.1-P12 (eventual periodicity).** Standard functional-graph argument, re-derived: a total
deterministic function on a finite set, iterated from any start, revisits a record within
(#records + 1) steps; determinism then forces the trajectory onto the cycle through the revisited
record, giving (p, c) with c ≥ 1 and record(t + c) = record(t) for all t ≥ p; (p, c) is computable
by visited-index enumeration. The finiteness premise is the declared population's finite record
set (finite inventory × finitely many junction local states over a fixed junction set). Two
strengthenings were checked computationally (artifact §G): 200 random finite deterministic maps
all decompose as claimed; 300 random closed populations under T_agg all terminate at cycles of
length exactly 1, as §10.1's clarification requires (τ_agg strictly drops at any tick in which a
junction acts, and never rises, so no cycle of a closed trajectory can contain an acting tick).

**L11.2-P12 (size-invariance).** Derivation = definitional inspection: the constructions of
§§3–5 and §7 (census, T_agg, flow counts, τ_agg, R and D) were read in full; none contains a
case split, branch, or bound on the number of bodies or the size of a body, and the proofs of
their identities (partition arithmetic §3.3; commutation §4; bookkeeping §5.2; rational
arithmetic §7) never invoke |P|. The claim's machine domain (sizes 1–12) was confirmed
post-derivation in A.1's provenance (sizes 1–12, §3 below).

**L11.3-P12 (macro-matter verdict).** An AUTHOR verdict; checked against the machinery's own
text: the census (§3), tick (§4), flows (§5), and reconcile census (§7) are defined over "a finite
population" with no size bound, and body admission runs through §2's received taxonomy — which is
exactly Edge 2's stated limit. The "census confers no rank" clause: the census (Defs. 3.3, 5.1)
is a count function into integers; no comparison rule over populations is defined by it, so no
ordering key is acquired from the census alone — confirmed constructively in Finding 15/16 work:
the census-only key ties the meson-like/baryon-like representatives outright (identical count
vectors), so a rank requires the extra definitional components L11.4-P12 adds.

**L11.4-P12 (population ordering key K) and the GS4-F analysis.** Full treatment in §6 below.
Summary of the independent derivation: K is a lexicographic tuple of totally ordered components
(population sums; Res ∈ {0, 1}; τ_agg ∈ ℤ≥0; the census signature as a descending-sorted tuple of
count vectors under lexicographic tuple order, with the stated proper-prefix convention), hence
a total preorder; every component is a sum, an aggregate over the junction set, or a sorted
multiset, hence name-invariant. Tick-stability: under §4's stated dynamics the tick acts on
junction local states only — it creates/destroys no junction and changes no consumed-port count,
so each body's (N, k_j multiset, B) stands; §4 states no tick-dynamics for (Σs², Σu), so Ss, Su,
and CenSig stand; Res and Tau0 can move (T removes admissible pairs; τ drops by 2 per acting
junction). My implementation (artifact §J) reproduces the exemplar order with the deciders the
paper names (Ss, Ntot, Res, Ntot, Ntot), the homogeneous families at sizes 1–5, the empty
declaration's key (0, 1, 0, 0, 0, 0, ()), name invariance and transitivity on random populations,
the tick-invariants on 300 random populations (Res moved in 98, Tau0 in 112), and an examiner-built
reversal witness (Finding 16).

---

## 2. Quantifier-domain statements (charter item 3 — every universal claim in the sample)

| Claim | Exact quantifier domain (as written) | Does the proof/derivation cover it? |
|---|---|---|
| L0.3-P12 | All uses of the nine locked words in this paper's native voice, over the whole final tree | Declaration + FW.1 sweep (paper's artifact). My independent evidence covers §§0–13 + App. A–B by spot classification only → Finding 1 (LIMIT) |
| L1.2-P12 | The passages quoted at §1.2, i.e. Paper 11.5 §§11.5–11.6 as cited | Yes — verified verbatim at source |
| L2.1-P12 | Every aggregate quantity in Paper 12 (the paper's §§3–9 constructions) | Yes for the constructions as written — all are sums/counts/ratios over the licensed list (spot-verified section by section in the derivation log) |
| L5.4-P12 | Every frequency question inside the framework's own scope, where "expressed" is fixed by §5's expressibility calculus, over declared populations and declared windows | Yes within that stated scope: cases (a)–(c) plus the joint-count extension (Prop. 5.9). Outside the calculus's scope the claim asserts nothing (Finding 5) |
| L6.2-P12 | All bodies G, G′; all roles R; all encounter kinds E; at a fixed tick t | Covered only under the pair-profile reading of "present equal count profiles" (M is §8.6's map on encounters). Own-profile reading not covered → Finding 6 (LIMIT) |
| L7.3-P12 | All declared (P, W); the (7.4) identity requires one shared window W for all locals | Arithmetic covers all |P| ≥ 1, |W| ≥ 1. At |P|·|W| = 0 the quantity is undefined, and no claim site states the restriction → Finding 8 (LIMIT) |
| L8.10-P12 | Not a universal claim — a Level B conjecture/target statement about what a proof would need | Its factual presuppositions verified (Finding 10) |
| L9.4-P12 | All ticks τ and all junctions of a declared population; the fraction requires J(τ) ≥ 1 | Construction covers J(τ) ≥ 1; at J(τ) = 0 the fraction is undefined and unstated → Finding 12 (LIMIT) |
| L10.1-P12 | All finite populations, all initial records, under T_agg; the open-population case only under §10.1's clarification condition (declared re-presentation rule folded into the transition, or realized whole-period cycles) | Yes — functional-graph proof is domain-general; the open case is conditioned in the home text itself |
| L11.2-P12 | Machine form: every test population in the A-series batteries, sizes 1–12. (The §11.3 Edge-1 prose carries the analytic extension to all finite sizes at AUTHOR strength) | Yes over the stated machine domain; the definitions contain no size branch (textual verification) |
| L11.3-P12 | All macro-matter populations, subject to Edges 1–3 | Verdict checked against the definitions; the edges are part of the claim as written |
| L11.4-P12 | Definition/AUTHOR properties: all finite declared populations at a declared tick. MACHINE content: the enumerated domains A.14's coverage states | Prose properties re-derived in general (§6). Machine computation verified only over A.14's disclosed domains, whose k_j reading diverges from the §11.3 definition outside the one-port-per-side regime → Finding 17 (LIMIT) |

---

## 3. Script consultation log (all AFTER the derivations and computations above)

| Listing (Appendix C) | Lines read | Why | What I took from it |
|---|---|---|---|
| A.14 (L11.4) | 13440–13600 (docstring + coverage map) | Compare its verified domain with my independent K results | Verified domain: representatives + homogeneous families n = 1..4; F1 sigma family (3,402 populations); transitivity exhaustive over triples of the 81 one-junction populations + sampled triples. Disclosed map limit: "the k_j multiset is read from the side count" — equals §3.2's k_j only where each side consumes one port. W1/W4 witnesses and mutants M1–M3 as described |
| A.3 (L10.1) | 4422–4512 (docstring) | Compare verified domain | Single-junction T-systems (9/81/729 states) in full + three declared toy systems; the (p, c) argument's consumed properties are exactly determinism, totality, finiteness; multi-junction state spaces not enumerated — matches my analytic derivation's division of labour |
| A.4 (L6.2) | 4861–4951 (docstring) | How the machine check models encounter kinds | Test taxonomy = counterpart profiles (e+, e−), e+ + e− ≤ 4; outcomes are functions of (M(G), M(E)); two disagreeing rules; coverage (5) states §8.6 itself is outside the check (inherited) |
| A.6 (L7.3, L9.4) | 5663–5778 (docstring) | Compare checks for §§7/9 exhibits | Recomputes §7.2 worked tick, §7.5 table, §9.3 flows, §9.5 table from parsed printed inputs; all arithmetic exact |
| A.12 (L5.4 support) | 11104–11219 (docstring) | Compare joint-count machine domain | Machine domain is port-vector length 2 junctions; standings read per Def. 5.7 with no pooling across a body's junctions; G8 witness recomputed (answers 1/4 and 0) — consistent with Prop. 5.9's printed coverage statement in §5 |
| A.1 (L11.2 support) | 3240–3284 (provenance) and L3504 (located by search) | Confirm enumerated sizes | Generated populations: "seeded RNG, sizes 1–12, 8 body types" |

Not consulted: A.2, A.5, A.7, A.8, A.9, A.10, A.11, A.13, A.15, FW.1, G.1, H.1 (bodies). No
Paper 12 script was run by this examiner; all computations reported here are my own artifact's.

---

## 4. Boundary search log (charter item 2, over the sample's claims)

Complete test space: `witness_boundary.py` §§A–J (seeded, deterministic; run_log.txt). Map of the
charter's boundary list to what was run:

- **Empty populations where admitted.** Census identities hold vacuously at |P| = 0 (§B, incl.
  sizes 0 and 1 in the random family). K is defined on the empty declaration and returns exactly
  the value §11.3 states, (0, 1, 0, 0, 0, 0, ()) (§J4). D(P, W) is **not** a rational at |P| = 0
  or |W| = 0 (division by zero, demonstrated §E5) — Finding 8. Saturation fraction at J(τ) = 0
  likewise (§F4) — Finding 12.
- **Singleton populations.** Census identities at |P| = 1 (§B); D's |P| = 1 reduction (§E3);
  one-junction T-systems in the periodicity search (§G).
- **Unequal sides.** Probed by reading: §4's T is stated over a shared position index set for the
  pair (A, B); the paper's exhibits use equal-length sides. A junction whose two sides present
  tuples of different lengths is outside the σ form §4 states (admissibility indexes positions the
  two sides share). NOT RUN as a computation; recorded as a domain reading, not a defect — no
  sampled claim quantifies over such junctions.
- **Repeated members.** Census with duplicate records (§B — identities hold; duplicates count
  with multiplicity, as a family/list reading requires). Joint counts with a member named twice
  (§H4 — read literally; a (+, −) self-pair counts 0, a (+, +) self-pair equals the marginal).
- **Junctionless bodies.** Standings: neutral (§H1). Census/K: photon and tilted representatives
  are junctionless and compute as stated (§J1). Saturation fraction edge at J = 0 (§F4).
- **Multi-sided junctions.** Carried through T_agg unchanged, Δτ contribution 0 (§A2–A3, §G2 with
  three-sided junctions present in 25% of populations). Res reads them as presenting no
  admissible index *for the tick* (§11.3's clause, within Def. 4.1's scope) while Def. 5.7 reads
  opposed pairs between two of their sides for standings — two different instruments, explicitly
  distinguished at §11.3; no sampled claim conflates them.
- **Tied deciding components.** The meson-like/baryon-like representatives tie on Ntot, Tau0, Ss,
  Su, −Btot, and CenSig and separate only at Res (§J1–J2). The photon/tilted pair ties on Ntot,
  Res, Tau0 and separates at Ss.
- **Proper-prefix comparisons.** Two levels. (i) k_j-multiset tuples inside count vectors:
  lexicographic tuple order (with its standard prefix convention) decides them; where N and B
  both tie, Σ_j k_j ties, so a proper-prefix pair of multisets would need zero-arity extra
  junctions — k_j ≥ 2 in Paper 11 §4.1 — so the prefix case inside a vector is vacuous on legal
  records. (ii) Census signatures: I prove the stated proper-prefix convention can never be the
  *deciding* rule between two legal populations — if all components before CenSig tie, Ntot ties;
  if one signature were a proper prefix of the other, the longer signature's extra bodies would
  contribute N ≥ 1 each, making its Ntot strictly larger — contradiction. Computational
  corroboration: in 20,000 targeted pairs (junctionless tied family), CenSig decided 1,280
  comparisons and the prefix-related case decided 0 (§J9). The convention is a completeness
  clause of the order definition, not a live decider — Finding 18.
- **Relabellings.** K is invariant under body-order shuffles on 300 random populations (§J5);
  the joint-count swap witness (§H5) shows which instruments are *not* name-blind (joint counts
  over named members, by design).
- **Disconnected populations.** Populations whose bodies carry no inter-body junctions are inside
  every sampled construction: census/flow/K compute on them (random families in §B, §J include
  junctionless bodies and empty junction lists); T_agg is the identity on a fully junctionless
  population, which is a fixed point, not an exception.
- **Composition boundaries.** A molecule enters the sample only through L11.4 (as a body in a
  population, via its §3 record and declared junction local states, §11.3). My K model takes
  bodies exactly through that interface (record + σ list), so the composition boundary is the
  record itself; grouping-independence of the molecule key is L11.1-P12's claim, which is **not**
  in the sample and was not examined.

---

## 5. Alternative constructions (charter item 4)

Each alternative satisfies the stated premises of its target and changes the claimed result;
each ships with its precondition check in `witness_boundary.py`.

1. **K without Res (ALT-1, §J10).** Premises kept: total preorder, name-invariance, ledger data
   only. Result changed: the meson-like/baryon-like representatives **tie** — the strict step
   §12.1 requires is lost. Precondition check: both representatives' count vectors are identical
   and their Tau0 values are equal (4 = 4), so no remaining component separates them.
2. **K with Ss (or Su) promoted ahead of Ntot (ALT-2, §J11a/b).** Premises kept as in ALT-1.
   Result changed: baryon-like (Ss 9, Su 3) ranks **above** nuclei (Ss 8, Su 2), reversing the
   §12.1 step. Precondition check: the representatives' stated components are as tabled at §11.3.
3. **K with Tau0 promoted ahead of Ntot (ALT-2c, §J11c).** Result **unchanged** on the
   exemplars — showing Ntot's first position is not uniquely forced by the agreement (see §6).
4. **K with +Btot instead of −Btot (ALT-3, §J12).** Premises kept. Result changed on the
   constructed pair X (N = 2, no junctions, B = 12) vs Y (N = 2, one resting junction, B = 10):
   K orders X < Y; the variant orders Y < X. Precondition check: the pair ties on Ntot, Res,
   Tau0, Ss, Su, so −Btot is the decider; no exemplar step ever reaches Btot, so the agreement
   constrains neither its sign nor its position.
5. **Lone-leftover rendering of the differentia (§J13).** The paper's own named rival, recomputed:
   meson-like with σ = ((+1), (0)) at both junctions gives Res = 1, Tau0 = 2; the step against
   baryon-like is then decided at Tau0 (2 < 4), order preserved, decider moved — confirming
   §11.3's disclosure.
6. **Unsettled-entry rendering (§J14).** If every unsettled entry (lone entry against a zero
   side, same-sign pair) counts as surplus, both representatives carry surplus, both get Res = 0,
   and their keys tie outright (Tau0 also ties at 4): the step is decided nowhere — confirming
   §11.3's disclosure that the step's existence at Res is a property of the declared
   identification, not of Paper 2's differentia alone.
7. **Interior-dependent capability rule (mutant, §I3).** An outcome rule consulting an interior
   parity bit breaks L6.2's conclusion immediately; the rule is outside §8.6's licensed class,
   which is exactly the premise's load-bearing content — the theorem is a factorization statement
   about that class, and the mutant shows the class restriction cannot be dropped.
8. **D over unequal windows (precondition failure, not a counterexample).** (7.4) fails if the
   locals are taken over different windows — e.g. locals over W₁ ≠ W₂ do not average to D(P, W).
   The claim states the shared-window precondition in its text ("over a shared window"), so this
   alternative violates a precondition and is recorded as such, not filed as a defect.

---

## 6. GS4-F — Alternative-representative analysis for K (which components are forced, which are choices)

**Question.** Given (i) Paper 2 §§11.4–11.5's differentiae, (ii) Paper 11 §12.1's ordering and
its key (node count, tilt count, resolution status — packet `paper_11_v69.md` §12.1–12.3,
verified at source), and (iii) §11.3's declared identification (Paper 2's surplus — unresolved
integers left at the junction — rendered as a standing opposed pair; resolution rendered as no
opposed pair standing), which components of K = (Ntot, Res, Tau0, Ss, Su, −Btot, CenSig), in which
positions, are forced, and which remain the construction's choices?

**What the sources force before any construction.** Paper 2 §11 (packet `paper2_section11.txt`,
verified): "surplus" means "unresolved integers left at the junction" (preamble, extract L673–674);
the §11.4 configuration has "one integer still unresolved at the junction", "still carrying
surplus, still searching for resolution" (extract L819–821); the §11.5 configuration forms when
the chain accumulates enough bonding events "to resolve all surplus integers", "settling three
matching integers with no surplus" (extract L829–833). Paper 2 presents neither class in junction
alphabet: no port vectors, no σ, no admissibility, no τ. Paper 11 §12.1 records both classes at
three nodes with (3, 3, 0) < (3, 3, 1) — node count and tilt count tied, resolution status the
tie-break — and §12.2 states the equal-tilt-count premise is itself a declared assumption (Paper 2
states no numeric tilt count), with F.37 verifying the tie-break for any shared tilt value.
Paper 11 §12.4: resolution status ∈ {0, 1} is a class marker whose meaning is supplied only by
the finite §12 class definition — "not an independent ledger quantity".

**Forced (given the identification and the agreement requirement):**

- **F1. Some component sensitive to the opposed-pair distinction must exist, and must be the
  meson/baryon decider.** The two representatives are constructed with identical count vectors
  (the analogue, inside the construction, of Paper 11's equal-tilt declared assumption). Every
  other component of K is blind to the distinction: Ntot, Ss, Su, Btot, CenSig read the identical
  records; Tau0 is a sum of squares, hence sign-blind, and indeed ties at 4 = 4 on the
  representatives (§J2). Dropping the component ties the pair (§J10). So the *existence* of a
  Res-like component is forced — conditional on the representatives carrying identical records,
  which is the construction's chosen analogue of the source's declared assumption.
- **F2. Res's content, given the identification.** Once surplus is identified with a standing
  opposed pair, Res = 1 iff no junction presents an admissible index is the direct Boolean
  rendering of "no surplus stands / surplus stands". Its {0, 1} domain matches Paper 11 §12.4's
  registration of resolution status. (What is *not* forced by Paper 2: the identification itself.
  Paper 2's surplus is a count of integers — the §11.4 class carries exactly one — while the
  representatives present opposed pairs at *two* junctions; the construction renders the Boolean
  settled/unsettled differentia, not the surplus count. §11.3 discloses this: "the step from that
  surplus to §11.3's opposed-pair rendering is this paper's declared identification".)
- **F3. Ntot must precede Ss and Su.** Baryon-like carries Ss 9 / Su 3 against nuclei's Ss 8 /
  Su 2, yet must precede nuclei; promoting either ahead of Ntot reverses the step (§J11a/b). So
  the relative order Ntot < Ss and Ntot < Su is forced by the agreement. This mirrors Paper 11's
  own key, whose node count is first and whose nuclei/atoms steps are decided at node count alone.
- **F4. Ss must precede Su** — forced only by §11.3's *named-decider* assertion, not by the order:
  the photon/tilted representatives differ at both Ss (0 vs positive — the one component whose
  tilted value rests on a stated source fact, Paper 11 Table 5.1's sign fact) and Su (0 vs 1, a
  declared representative value). Either order gives the same ranking; only Ss-first makes the
  step "decided at Ss" as §11.3 asserts and keeps the decider on the stated fact rather than the
  declared one.

**Choices (not forced by the differentiae, the identification, or the agreement):**

- **C1. Tau0's existence and position.** No step needs it: with Tau0 deleted, every exemplar step
  is still decided (photon/tilted at Ss, meson/baryon at Res, the rest at Ntot). Promoting Tau0
  ahead of Ntot also preserves the agreement (§J11c). Tau0 is a genuine addition of the
  construction (it is what makes the tick-stability statement sharp and what decides the
  lone-leftover rival's step), not a forced component.
- **C2. Res's exact position (2nd).** The meson/baryon pair ties at Tau0, so any position of Res
  before the first component on which the pair *differs* — which is Res itself — leaves Res the
  decider; Res could sit after Tau0 without changing any exemplar verdict. Its 2nd position is
  what makes the *general* key consult settledness before tension — a construction choice with
  real consequences off the exemplars (my reversal witness, §J8, turns on Res preceding Tau0).
- **C3. −Btot: sign, position, presence.** No exemplar step reaches Btot (all steps are decided
  at or before Su). The sign flip reverses constructed pairs (§J12); the sources say nothing
  about a boundary component in a population key (Paper 11 §12.1's key has none). Pure choice.
- **C4. CenSig: presence, position, internal order.** No exemplar step reaches it (it is the
  final tie-breaker for populations with identical sums and junction aggregates). Its internal
  conventions (vectors ordered by N, then k_j multiset as ascending tuple, then B, Σs², Σu;
  signature sorted descending; proper-prefix rule) are the definition's choices — and the prefix
  convention is provably unreachable as a decider (Finding 18). A census-only key is *refuted*
  as a substitute (it ties meson/baryon), but CenSig's presence as a last component is not forced
  by the agreement: without it K would still be a total preorder agreeing on the exemplars —
  with more ties on general populations.
- **C5. The representatives' non-deciding values.** Nuclei at M = 4 + u with u = 0 and atoms at
  S = 2 are exhibited points of a parametric step (§11.3 states the step holds for all u ≥ 0,
  S ≥ 1, and A.14 checks that range); the tilted representative's Su = 1 and the nuclei/atoms
  junction data are declared values no step consults before its decider. The photon represented
  as an N = 1 body (rather than by §12.1's "zero internal nodes" record) is likewise a
  construction choice — it is what moves the photon/tilted decider from node count (Paper 11's
  records) to Ss (this construction), a decider change the paper states openly.
- **C6. Ss in place of a tilt-count component.** Paper 11's key's second component is tilt count;
  K has no tilt component at all (tilt count is undefined for general records — §11.2). Ss
  (workload sum) does the one job the agreement needs at the photon/tilted step, via a stated
  sign fact. Nothing in the sources forces this substitution; it is licensed by the fact that
  the agreement asserted is with §12.1's *ordering*, not with its key — and §11.3 says exactly
  that ("K agrees with §12.1's ordering on the six classes", each step "decided at the component
  §11.3 names").

**Bottom line.** Forced: a Res-like Boolean separator (existence + content, given the declared
identification and the identical-record representatives); Ntot ahead of Ss and Su; Ss ahead of Su
(by the named-decider assertion). Choices: Tau0 (existence and position), Res's exact position,
−Btot (sign/position/presence), CenSig (presence/position/conventions), and the representatives'
non-deciding values. The agreement with §12.1 is therefore a property of the construction *under
the disclosed identification*, exactly as L11.4-P12's AUTHOR component grades it — no
rendering-independence is claimed in the paper, and none exists (§5, alternatives 5–6).

---

## 7. Findings

### FINDING 1 -- L0.3-P12: construction-list discipline verified only over the prose region by this examiner
- Target claim: L0.3-P12 (§0.5 claim list, L145)
- Exact target text: "The construction list above fixes, for each word locked by Paper 11 §0.5, its sole permitted route into this paper; any use of a locked word outside its listed disposition is a defect against this section, swept by FW.1." [LEVEL A: AUTHOR] (L145)
- Domain and required property: Every use of the nine locked words (temperature, entropy/entropies, Gibbs, Boltzmann, k_B, ensemble, microstate/macrostate, thermal equilibrium, probability distribution) in the paper's native voice over the whole final tree must follow its tabled disposition (constructed / bridged only / excluded).
- Sources used: Paper_12_v4.md (SHA-256 fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), sample_selection.txt (588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766)
- Method and complete test space: (i) The §0.5 table was checked for well-formedness — each locked word carries exactly one disposition. (ii) Independent spot scan (scan_locked.py) over lines 1–2903 (§§0–13, Appendix A, Appendix B): every line containing the rarer tokens (ensemble 25 lines, entropy 17, microstate/macrostate 11, k_B 8, Gibbs 6, Boltzmann 6, probability distribution 3, thermal equilibrium 4) was classified by eye. All ensemble hits are exclusion discussions, Stage C/audit mentions, headings, or negations ("No ensemble is constructed at any point"); all entropy hits outside §0.5 are quotations (Paper 9 §5), the §1.7 Stage C history, the §8.4 bridge sentence, the §8.7 attributed application, or Appendix A notation rows describing the disposition; all k_B hits are the §0.5 list, the two bridge sites, or notation rows; "probability distribution" at L790 occurs inside Theorem 5.4(b)'s description of the refused frame, in scare quotes. No native-voice violation was found in the scanned region.
- Witness / artifacts: scan_locked.py, scan_locked_out.txt
- Coverage map: (1) native domain: the entire final tree's native voice, including Appendices C–J (embedded listings, planted batteries, quoted source papers, the ESP engine listing). (2) verified domain: lines 1–2903, spot-classified as above; the §0.5 table's internal well-formedness. (3) map between them: line-region restriction — the prose sections and claim registries are where native-voice use would appear as claims; the appendices are dominated by code, quotations, and audit text whose exemption classification is FW.1's rule set. (4) what the map preserves: every locked-word occurrence in the claim-bearing prose. (5) what stays outside: Appendices C–J in full, and the exemption-rule adjudication itself (FW.1's code), which this examiner did not reproduce.
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: No contradiction of the declaration was found anywhere I looked, and the declaration's falsifier is concrete. But my evidence covers a proper subset of the claim's stated domain (the whole final tree); the full sweep is FW.1's artifact, which Role B did not independently reproduce. LIMIT with the boundary named here; HELD over lines 1–2903.

### FINDING 2 -- L1.2-P12: count-to-weight debt quotations verified verbatim at source
- Target claim: L1.2-P12 (§1 claim list, L246)
- Exact target text: "The count→weight debt is as quoted at §1.2, including its two named items and the fill rules." [CITED — L4-P12] (Paper 11.5 v26 §§11.5–11.6.) (L246)
- Domain and required property: The three blockquotes at §1.2 must be faithful to Paper 11.5 §§11.5–11.6, including item (1) (microstate-counting rule), item (2) (sampling-measure postulate), and the fill rules.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper_11_5_v26.md (9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60)
- Method and complete test space: Direct textual comparison of §1.2's three blockquotes against the source file, lines 2805–2818 of the packet's Paper 11.5: "Combinatorics supplies the *counts*; the count→weight step is not certified here. It needs two things this paper does not build: (1) a microstate-counting rule, and (2) a sampling-measure postulate. Both are Paper 12's work." / "The fill rules — which encounter actualizes with what probability at a given tick — are the dynamics the framework has not yet built (§11.5)." / "…it does not pretend to stand on what it has not — the fill rules and the sampling measure are Paper 12's work, named above, not smuggled in here." Second route: the registry row (Appendix B, L2819) restates the same content and agrees.
- Witness / artifacts: textual witness pair — Paper 12 §1.2 (home text) vs paper_11_5_v26.md L2805–2818; no computation involved.
- Coverage map: (1) native domain: the debt as Paper 11.5 states it in §§11.5–11.6. (2) verified domain: the three quoted passages and their immediate source context. (3) map between them: verbatim quotation comparison. (4) what the map preserves: wording, the two named items, the fill-rules assignment. (5) what stays outside: Paper 11.5's wider §11 argument (MC.1's content is L5.6-P12's target, not this claim's; not in the sample).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Every quoted element of the claim — both named items and the fill rules — is present at the cited source in the quoted words. A [CITED] claim asserts that the source says it; the source does.

### FINDING 3 -- L2.1-P12: single-regime inheritance verified at source; reliance spot-checked construction by construction
- Target claim: L2.1-P12 (§2 claim list, L298)
- Exact target text: "The single-regime rule and the licensed aggregate list of Paper 11 §4.1 (quoted at §2.3) govern every aggregate quantity in this paper." [LEVEL A] — inherited. Inheritance: Paper 11 v69 §4.1 / claim 41 / R15 — badge at source [LEVEL A], machine check F.41. (L298)
- Domain and required property: (i) The §2.3 quotation must be Paper 11 §4.1's rule as cited; (ii) every aggregate quantity Paper 12 constructs must in fact be an exact finite sum, count, or rational ratio over the licensed list (N_nodes, N_edges, B = 6N − Σ_j k_j, Σs², Σu).
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper_11_v69.md (f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb)
- Method and complete test space: (i) Verbatim comparison: the quotation at §2.3 matches Paper 11 §4.1 (packet paper_11_v69.md L342) in full, including the licensed list and the attribution "(Audit rule R15, Appendix H; machine check F.41)". (ii) Reliance audit: each §§3–9 construction was read and classified — census (counts of records), census totals (sums), τ_agg (sum over junctions), flow counts (counts), D (ratio of two sums), Ω (count of assignments of actual bodies), J_sat (count), saturation fraction (ratio of counts), K (tuple of sums, a junction-set aggregate, and a sorted multiset of count vectors). No construction introduces an aggregate state alphabet, an aggregate budget rule, or a fourth operation.
- Witness / artifacts: textual witness pair — Paper 12 §2.3 vs Paper 11 §4.1 (packet L342); classification performed in the derivation log (§1 of this submission).
- Coverage map: (1) native domain: Paper 11 §4.1's rule and all of Paper 12's aggregate quantities. (2) verified domain: the quotation, and the named constructions of §§3–9 (each read at its definition site). (3) map between them: quotation identity for (i); operation-classification for (ii). (4) what the map preserves: the rule's text, its list, and the form of every construction that relies on it. (5) what stays outside: Paper 11's own F.41 machine check (not re-run; the claim's inheritance line cites it, and the badge at source is Paper 11's to carry); Appendix D–F exhibits' quantities, which reuse the same constructions.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The inheritance is exactly as cited, at the strength cited, and the reliance is real: the paper's aggregate quantities are, construction by construction, of the licensed forms.

### FINDING 4 -- L5.4-P12: dissolution re-derived over the extended instrument family
- Target claim: L5.4-P12 (§5 claim list, L1131)
- Exact target text: "The sampling-measure postulate pre-registered in Paper 11.5 §11.6 is unnecessary: long-run frequencies resolve to orbit counts, the single-tick "ensemble" resolves to the census, the fill rules resolve to the deterministic dynamics, and named-tuple joint frequencies resolve to joint counts over the named members' records (Definition 5.8, added in v4 after falsification condition C32 fired against this claim's v3 form — the firing record stands at §12). The debt is discharged by dissolution over the extended instrument family (census, flow, joint counts), with no postulate adopted." [LEVEL A — scoping result] (L1131)
- Domain and required property: Every frequency question inside the framework's own scope — as §5's expressibility calculus fixes "expressed" (finite arithmetic over census, flow, and joint counts over declared windows, including conditional ratios and tick-offset forms) — must be expressible without a sampling measure, over declared populations and windows.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper_11_5_v26.md (9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60)
- Method and complete test space: Independent re-derivation of Theorem 5.4's three cases plus the joint extension (derivation log §1): (a) eventual periodicity ⇒ long-run frequencies are period ratios c_X/ℓ; (b) the single-tick question is refused and replaced by the census, an exact rational about actual standings; (c) fill rules are deterministic outputs of T + the encounter taxonomy (Prop. 5.5). Proposition 5.9's identities (marginalization, window additivity, offset and repeated-name forms, conditional ratios) were verified computationally on 400 random standing tables (tuples to k = 3, offsets in {−2,−1,0,1,2}) — witness_boundary.py §H2–H4. The necessity of the joint instrument was independently witnessed (§H5): two record families with identical per-tick censuses and identical flow tables but named joint counts 2 vs 0. Attack space probed for an in-scope inexpressible frequency: conditional frequencies with zero marginal (undefined — disclosed at Prop. 5.9(iv), "defined exactly when the marginal is nonzero"); data-dependent-lag frequencies (outside the calculus's stated forms — the calculus is the claim's own scope definition, and C32's killer is stated in its terms); frequencies over undeclared populations (Finding 5).
- Witness / artifacts: witness_boundary.py §§A, G, H (run_log.txt: all PASS, including H5 (2, 0))
- Coverage map: (1) native domain: all frequency questions statable in the ledger's own terms over declared populations/windows, under the expressibility calculus §5 states. (2) verified domain: the four cases as re-derived analytically (the proof is the case analysis; it is domain-general, not enumerative), plus the Prop. 5.9 identities over the computed random tables. (3) map between them: definitions 5.1–5.2, 5.7–5.8 read as written; standings computed per Def. 5.7 in my implementation for §H1, and standing sequences treated abstractly for §H2–H5. (4) what the map preserves: the counting content of every case — numerators and denominators are counts of actual records. (5) what stays outside: any frequency notion outside the expressibility calculus (the claim asserts nothing there); A.12's machine domain (port-vector length 2) for the script's corroboration — the prose proof of Prop. 5.9(i)–(ii) is the general argument and does not rest on it.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The dissolution is a scoping result and it is proved as one: each place a measure seemed to be needed resolves to deterministic dynamics or exact counting, and the one place the v3 instruments provably did not reach (named-tuple joint frequencies — independently re-witnessed here) is reached by the v4 extension whose identities I verified. No in-scope counterexample was found; the analytic case analysis, not the finite search, is what carries the universal.

### FINDING 5 -- Attack on L5.4-P12 from predictive scope: not asserted by the claim
- Target claim: L5.4-P12 (§5 claim list, L1131)
- Exact target text: "The sampling-measure postulate pre-registered in Paper 11.5 §11.6 is unnecessary… The debt is discharged by dissolution over the extended instrument family (census, flow, joint counts), with no postulate adopted." (L1131); scope concession at L5.8-P12: "the dissolution's scope is the closed system with a declared population and a declared initial state; excluded from that scope are systems known only by a coarse description, whose fine initial state is unknown" (§5 claim list).
- Domain and required property: Attack: exhibit a use the dissolution cannot serve — prediction over an undeclared population, or inference where the fine initial state is unknown — and propose it as a failure of the discharge.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Textual: §5's "ensemble user's objection" passage concedes the territory in terms ("Where the fine initial state is unknown, this paper offers nothing that operates there… no claim in this section reaches the ensemble user's undeclared systems"), §1.9 states "no predictive calculus over undeclared populations is built here, and no new empirical prediction is claimed in this paper", and C32's killer is scoped to "a frequency question inside the framework's own scope — a declared population, a declared window, ledger data alone". The attacked property is therefore outside the claim as written, by the claim's own stated scope.
- Witness / artifacts: textual witness pair — the attack's target property vs L5.8-P12's scope statement and §5's objection passage (home text).
- Coverage map: (1) native domain: the claim's stated scope (declared populations/windows). (2) verified domain: the scope statements themselves, read at §5, §1.9, §12 (C32). (3) map between them: scope comparison. (4) what the map preserves: the exact boundary of the discharge. (5) what stays outside: whether a bridge to predictive/inferential use could be built — a Stage P question no sampled claim asserts.
- Category (self-classified, spec section 9.5): C
- Proposed badge: OUTSIDE
- Reason: The absence of a predictive bridge is real but it is not a defect of this claim: the claim's own Stage discipline asserts no bridge, and the paper concedes the undeclared-population territory explicitly (L5.8-P12). Under §9.5, category C cannot sustain a BROKE; the correct verdict for the attacked property is OUTSIDE.

### FINDING 6 -- L6.2-P12: factorization proof covers the pair-profile reading; the own-profile reading is not covered and is false
- Target claim: L6.2-P12 (§6 claim list, L1344; Theorem 6.2, L1236)
- Exact target text: "Equal presented-count profiles at a tick imply equal capabilities at that tick, for every role and encounter kind: capability factors through the presented-count profile." [LEVEL A — conditional on Paper 11 §8.6 and on Paper 11 §8's role-occupancy assignment] (L1344). Theorem 6.2: "If two bodies G and G′ present equal count profiles at tick t — the same presented counts to the encounters of the taxonomy — then for every role R and every encounter kind E, (E, t) ∈ Cap(G, R) ⟺ (E, t) ∈ Cap(G′, R)." (L1236)
- Domain and required property: For all bodies G, G′, roles R, encounter kinds E, at a fixed tick t: equality of the bodies' presented-count profiles must imply equality of capability. Required: the hypothesis must be strong enough to fix the encounter outcomes the proof routes through.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper_11_v69.md (f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb)
- Method and complete test space: (1) The proof was re-derived: it is a composition (profile → outcome → role) and is sound when "profile" is the encounter's profile. (2) Source check: Paper 11 §8.6 defines M as "the map from a native encounter to its presented (n+, n−) label counts" (packet paper_11_v69.md, §8.6 Coverage theorem) — M is a property of the encounter (the presented pair), not of one body; its selection rule's residue res(A, B) is computed from both sides' tuples. (3) Counterexample to the own-profile reading (witness_boundary.py §I2): fix both bodies' own presented counts at (n+, n−) = (1, 1); let one face a counterpart presenting (1, 0) and the other a counterpart presenting (0, 1). The pair profiles are (2, 1) and (1, 2); an outcome rule of the class §8.6 licenses (a function of the pair profile) separates them (my representative rule returns 'plus-led' vs 'minus-led'), and with roles attached by outcome class (the proof's own premise P2), the two bodies occupy different roles in their respective encounters at t despite equal own profiles. Precondition check: the construction satisfies every premise as the claim phrases it — equal presented-count profiles (own), same tick, encounter kinds of the taxonomy — and violates the conclusion under the own-profile reading. (4) Post-derivation corroboration of the boundary: A.4's disclosed map models an encounter outcome as a rule applied to (M(G), M(E)) over a test taxonomy of counterpart profiles — i.e. the machine-checked content holds the encounter kind's other side fixed by construction, which is the pair-profile reading. Second route: the analytic source-text witness (Paper 11 §8.6's definition of M) is independent of my computational witness and establishes the same boundary.
- Witness / artifacts: witness_boundary.py §I (I1: factorization holds given the premises; I2: own-profile insufficiency, outcomes 'plus-led' vs 'minus-led'; I3: interior-dependent mutant breaks the conclusion, showing P1 is load-bearing). Textual witness: Paper 11 §8.6's M definition vs Paper 12's hypothesis phrasing.
- Coverage map: (1) native domain: all bodies, roles, and encounter kinds at a tick, under either reading of "presented-count profile". (2) verified domain: the pair-profile reading in full (proof by composition, domain-general); the own-profile reading refuted by the witness above. (3) map between them: M as §8.6 defines it (encounter-level) vs the claim's body-level phrasing. (4) what the map preserves: the factorization itself — capability consults presented counts and nothing intrinsic (the interior-independence content is untouched; §I3's mutant confirms the premise is exactly what carries it). (5) what stays outside: Paper 11 §8's role taxonomy in full (the sample claim's second premise is consumed as inherited, per its badge); whether Paper 11's encounter *kinds* should be read as carrying their other side's profile (A.4's modeling choice) is a reading the adjudicator may prefer — under it, this finding's boundary collapses to a phrasing remark and the claim is HELD as modeled.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: The derivation the claim asserts exists and is correct for the pair-profile reading — which is the reading §8.6's M supports and A.4 implements — but the claim as written phrases its hypothesis at body level ("the same presented counts to the encounters"), and on that reading the step "the encounter presented to G and the encounter presented to G′ have the same profile" is a missing derivation: it does not follow, and the witness shows it can fail. Evidence therefore supports the claim over a proper subset of its phrased domain; the exact boundary is: counterpart/kind profile held fixed. Not filed as BROKE: the paper's own §6 introduction ("the pair's presented-count profile", §6 preamble) supports the pair reading, so the defect is a phrasing/proof gap between the claim's hypothesis and its proof, not a contradiction of the intended statement.

### FINDING 7 -- L7.3-P12: reconcile-density arithmetic re-derived; identification carried at its graded AUTHOR strength
- Target claim: L7.3-P12 (§7 claim list, L1577)
- Exact target text: "D(P, W) (7.3) is an exact rational; for |P| = 1 it reduces to Paper 9's §4 definition at the single body, and over a shared window it equals the mean of the local densities (7.4)." [LEVEL A: MACHINE / AUTHOR — script A.6] "Component split — MACHINE (A.6): the (7.4) mean-of-locals identity on the exhibited window and the worked example's arithmetic; AUTHOR: the (7.4) identity in general, carried by §7.3's prose (exact rational arithmetic over the shared denominator |W|); D(P, W)'s exact rationality in general, carried by §7's prose (immediate from (7.3) as a ratio of two integer counts; A.6 verifies it on the exhibited window); and the identification of D's |P| = 1 case with Paper 9 §4's verbal definition." (L1577)
- Domain and required property: For all declared (P, W) with |P| ≥ 1, |W| ≥ 1: D(P, W) = R/(|P|·|W|) ∈ ℚ; the |P| = 1 case is the single body's rewrite events per tick; over a shared window, D equals the mean of the local densities (7.4).
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper9.txt (defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6), paper10.txt (f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82)
- Method and complete test space: Analytic derivation: (1/|P|)·Σ_b (R_b/|W|) = (Σ_b R_b)/(|P|·|W|) = R/(|P|·|W|), exact in ℚ. Computational verification (witness_boundary.py §E): the §7.5 worked example recomputed from its table cells (totals 12/7/18/4, R = 41, D = 41/40, mean of locals 41/40, locals 6/5, 7/10, 9/5, 2/5); 300 random ledgers (|P| 1–8, |W| 1–9, r_b(τ) ∈ 0..97) for (7.4) and the |P| = 1 reduction, all in exact Fractions; the (7.2) cap and worked tick (36) recomputed. Source verification: Paper 10 eq. (2.4) at packet paper10.txt L985 ((2.2a) L959, (2.2c) L963); Paper 9 §4's definition and §2's rate form match §7.1's quotations verbatim (packet paper9.txt §2, §4). Alternative construction with unequal windows for the locals violates the claim's stated shared-window precondition and is recorded as a precondition failure, not a counterexample (submission §5, item 8).
- Witness / artifacts: witness_boundary.py §E (E1–E4 PASS; run_log.txt)
- Coverage map: (1) native domain: all declared populations and windows. (2) verified domain: the identity in general by the analytic derivation (the computation is corroboration over the stated random space); the worked example in full; the source texts of the identification's target. (3) map between them: r_b(τ) read as the booked N_reconcile entry under §7.2's declared identification (occasion ⇔ contact tick), whose AUTHOR grading the claim itself carries. (4) what the map preserves: exact rational values; no rounding anywhere. (5) what stays outside: the |P|·|W| = 0 boundary (Finding 8); the physical (Stage P) reading of D as measured temperature (Finding 9); whether Paper 9's "localized density" phrasing is exhausted by the body-as-region identification — that is the AUTHOR component, graded as such in the claim, and this examiner's verdict follows the claim's own split.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The arithmetic content is proved, not merely sampled: the identity is a rearrangement of a finite sum over a shared denominator, the worked example recomputes exactly, and the cap arithmetic and its Paper 10 source check out. The identification with Paper 9 §4 is carried at exactly the AUTHOR strength the claim prints for it.

### FINDING 8 -- L7.3-P12 boundary: D(P, W) is undefined at |P|·|W| = 0, and no claim site states the restriction
- Target claim: L7.3-P12 (§7 claim list, L1577); also touching L5.3-P12's ratios and §7.2's setup
- Exact target text: "D(P, W) (7.3) is an exact rational" (L1577); §7.2's setup: "Let P be a population of |P| bodies and W a window of |W| consecutive ticks." (§7.2); §11.3, for contrast: "The empty declaration stands inside the key definition's domain: a population whose membership list is empty has every sum 0…" (§11.3)
- Domain and required property: The claim asserts D is an exact rational for the (P, W) its section quantifies over. Required: either the domain excludes |P| = 0 and |W| = 0, or D is defined there.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Complete witness: P = ∅ (admitted as a declaration by §11.3's own text for the key's domain; §2.2 defines a population as "a finite family of bodies", which the empty family satisfies) and any W: R = 0, |P|·|W| = 0, so D = 0/0 — not a rational. Likewise P nonempty with the empty window: §5.2 defines a window as "a declared finite run of consecutive ticks W = [t₀, t₀ + m)" without stating m ≥ 1 (Definition 5.8 does state "at least one tick" for joint counts; §§5.3 and 7 do not). Demonstrated computationally (witness_boundary.py §E5: ZeroDivisionError in exact Fraction arithmetic for both cases). Precondition check: the witness satisfies §2.2's population definition and §5.2's window definition as written; nothing in §§2, 5, or 7 excludes it. Second route: direct textual inspection — no site in §§5–7 states |P| ≥ 1 or |W| ≥ 1 for D or for Prop. 5.3's ratios, while §11.3 shows the paper states empty-domain behaviour explicitly where it intends it.
- Witness / artifacts: witness_boundary.py §E5 (DEMONSTRATED lines in run_log.txt)
- Coverage map: (1) native domain: all (P, W) admitted by §§2.2/5.2's definitions as written. (2) verified domain: the two boundary points (empty population; empty window) in full, and all |P| ≥ 1, |W| ≥ 1 by Finding 7. (3) map between them: identity — the witness is a native declaration evaluated by the claim's own formula. (4) what the map preserves: the formula (7.3) itself. (5) what stays outside: whether the author intends "population" and "window" to carry a standing nonemptiness convention from elsewhere in the series — no such convention is stated in the packet materials I am permitted; if one exists at a source I did not read, this finding reduces to a request to cite it at §7.2.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: The claim's derivation covers exactly the nonempty domain; at the boundary the asserted property ("is an exact rational") has no truth value because the quantity is undefined, and the restriction is nowhere stated at the claim's sites. This is a missing domain statement, not a failure of the identity: over |P| ≥ 1, |W| ≥ 1 the claim is HELD (Finding 7). Proposed badge is LIMIT rather than BROKE because the defect is an unstated quantifier restriction at the extreme boundary, repairable by one clause at §7.2/§5.2, and the paper's practice elsewhere (§11.3) is to state such domains explicitly — the gap is local and named.

### FINDING 9 -- Attack on L7.3-P12 from measured temperature: not asserted by the claim
- Target claim: L7.3-P12 (§7 claim list, L1577)
- Exact target text: "D(P, W) (7.3) is an exact rational; for |P| = 1 it reduces to Paper 9's §4 definition at the single body…" (L1577); §7.6: "No numerical temperature scale is derived or asserted. The bridge sentence of §7.4 is the only contact with Stage P usage."
- Domain and required property: Attack: D carries no unit and no scale constant, so it is not a temperature in kelvin and cannot be compared with a thermometer; propose this as a failure of the "population temperature" construction.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Textual: §7.4's single bridge sentence states the Stage P contact in one sentence and §7.6 disclaims any numerical scale; the claim itself asserts (i) exact rationality, (ii) the one-body reduction to Paper 9's *verbal* definition (an event rate per tick), (iii) the mean-of-locals identity. No sampled text asserts a kelvin value, a calibration, or a thermometer comparison.
- Witness / artifacts: textual witness pair — the attacked property vs §7.4's bridge sentence and §7.6's disclaimer (home text).
- Coverage map: (1) native domain: D as a native count ratio. (2) verified domain: the claim's three asserted contents (Finding 7). (3) map between them: §7.4's declared bridge is the only Stage P contact, and it asserts representation, not a scale. (4) what the map preserves: the ratio and its one-body identification at AUTHOR strength. (5) what stays outside: any future Stage P calibration — Paper 9's observational reading is inherited, not re-derived, as §7.6 states.
- Category (self-classified, spec section 9.5): C
- Proposed badge: OUTSIDE
- Reason: An unbuilt bridge to physical measurement cannot break a claim that asserts no such bridge; under §9.5 category C sustains at most LIMIT/OUTSIDE, and the tested property (a numerical temperature scale) is one the paper explicitly does not assert — OUTSIDE.

### FINDING 10 -- L8.10-P12: the open joint is genuinely open, and its strong form is refuted inside the paper as stated
- Target claim: L8.10-P12 (§8 claim list, L2011; home text §8.6)
- Exact target text: "Conjecture, stated as a target (§8.6): a proof of the open joint would need a statement over Proposition 5.3's orbit structure, coupling the acting-junction structure of T_agg steps to the assignment counts of the records they produce — a statement about rest records, in relational form: a characterisation, for a given population, of the records its own junction structure permits it to rest at; whether a population's rest record is maximal is a property of that population, and no universal balance is claimed. (The strong form — rest only at (E2)-maximal records — is already refuted inside this paper.) If the joint is underivable in general, the arrow stands as a boundary-condition fact inherited from Paper 9's received asymmetry, and §9's predicate as a construction with no approach content. The joint itself is not claimed." [LEVEL B] (L2011)
- Domain and required property: Not a universal claim. Required for the statement to be accurate: (i) no result in the paper proves a dynamics-to-balance drift; (ii) the strong form is refuted by an in-paper exhibit; (iii) the target's description of what a proof would need is the paper's own stated position (§§8.6, 9.6).
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper9.txt (defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6)
- Method and complete test space: (i) All claim lists §§1–13 were read in full; no claim asserts Ω-monotonicity or drift, and §1.8 affirmatively forbids the phrasing ("no theorem in this paper makes Ω non-decreasing under the dynamics"). (ii) Independent recomputation of §8.7's declared population from §4's T (witness_boundary.py §D): trajectory (12, 0) → (6, 6) → (0, 12) → (0, 12); Ω = 1, 924, 1, 1; τ_agg = 36, 12, 0, 0; (p, c) = (2, 1); equilibrium verdicts — (12, 0) neither clause, (6, 6) (E2) only, (0, 12) (E1) only, no visited record an equilibrium. The rest record (0, 12) has Ω = 1 < 924, refuting the strong form; the trajectory also exhibits Ω falling 924 → 1 while τ falls, so no drift theorem of the stated kind can hold in general. Second route for (ii): the (E1)/(E2) separation is independently visible in §9.3's n = 4 examples (flowing (2, 2) equilibrium; frozen (4, 0) stationary non-equilibrium), recomputed at §F1–F2. The §8.3 counting underpinning the target was re-derived (§C: (8.3) exact to n = 40, (8.5) to m = 60, (8.7) to n = 80, balanced-share non-growth over n = 1…6). Paper 9 §5's asymmetry passage (the inherited leg) was verified verbatim at source, including the deferral sentence the claim's conditional rests on.
- Witness / artifacts: witness_boundary.py §§C, D, F (run_log.txt)
- Coverage map: (1) native domain: the paper's whole claim surface for (i); the space of closed trajectories for (ii). (2) verified domain: claim lists §§1–13 (read in full) for (i); one declared population's trajectory, recomputed exactly, for (ii) — one refuting witness is complete for a universal strong form. (3) map between them: my T implementation is §4's rule as printed (canonical-first admissible pair zeroed), applied to §8.7's declared σ₀ table. (4) what the map preserves: records, Ω values, τ values, and the (p, c) decomposition — all cell-for-cell equal to the paper's printed table. (5) what stays outside: Appendix D's and Appendix F's exhibits (cited by §8.6 as further instances; not needed — §8.7 alone refutes the strong form, and Appendix D was not read by this examiner); the relational characterisation itself, which is the open question.
- Category (self-classified, spec section 9.5): E
- Proposed badge: HELD
- Reason: The claim is an explicit open-question statement, and its factual presuppositions check out exactly: the joint is unproved everywhere in the claim surface, the strong form is refuted by a recomputed in-paper witness, and the conditional consequences are stated as conditionals. Under §9.5, category E is never a defect; the accurate verdict for the statement as written is HELD (as a Level B target statement — "held" here means the statement is correct about what is open and what is refuted, not that the joint is proved).

### FINDING 11 -- L9.4-P12: saturation census construction is coherent, per-junction, and its exhibit recomputes
- Target claim: L9.4-P12 (§9 claim list, L2288)
- Exact target text: "The saturation census J_sat(τ), the saturation fraction, and regime change (a tick where J_sat changes) are exact counts/ratios built by summation over Paper 9 §6's local saturation behaviour, with per-junction capacity and demanded load from the junction's own entries under Paper 10 eq. (2.4) — relayed work entering only as executed inside a junction's own scan allocation; Paper 10 §2.4.7's partition is cited in its single-source, isotropic form only, and no sum of its shares over sources is formed at any junction (anisotropic corrections remain Paper 23's). The Threshold is cited to Paper 7 and not redefined; its exact point is Paper 14's." [Construction — Paper 12; components inherited as cited] (L2288)
- Domain and required property: For every declared population and tick: J_sat(τ) is the exact count of junctions whose demanded load (own eq. (2.4) entries, demanded N_reconcile taken before the cap) reaches 100 CU; regime change is exactly a tick where J_sat changes; no cross-source sum of Uniform Load Partition shares is formed.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper9.txt (defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6), paper10.txt (f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82)
- Method and complete test space: (i) Definitional audit of §9.4: demanded load is built solely from the junction's own entries; relayed work enters only as executed inside the junction's own s² allocation per Paper 10's relay accounting (quoted at §9.4 from packet paper10.txt's construction); §2.4.7's partition is quoted in its single-source form and §9.6 states the census's boundary (unbookable many-source demand in no category) — I verified no summed-over-sources form appears in the definition. (ii) Paper 9 §6 Step 1 verified verbatim at source (packet paper9.txt §6). (iii) §9.5 exhibit recomputed exactly (witness_boundary.py §F3): demands 105/88/100; booked 288 of 293; deferred reconcile demand 5; J_sat 0 → 2 at τ; fraction 2/3; the exactly-at-capacity junction (demand 100) counts as saturated, matching "reaches the whole of its local processing capacity". (iv) Boundary probes: demand 99 (not saturated), 100 (saturated), 101 (saturated, deferred > 0) are all decided by the stated ≥ 100 reading consistently.
- Witness / artifacts: witness_boundary.py §F3; textual witness — §9.4's Step 1 quotation vs paper9.txt §6.
- Coverage map: (1) native domain: all declared populations and ticks. (2) verified domain: the definition's text (audited in full), its cited sources, and the one worked exhibit; the construction is a definition, so the exhibit + definitional audit is the complete check type available. (3) map between them: demanded load as §9.4 defines it, evaluated on §9.5's declared rows. (4) what the map preserves: exact integer CU accounting, including the deferred-demand count. (5) what stays outside: the fraction at J(τ) = 0 and the first-tick case (Finding 12); the Threshold's exact point (Paper 14's, disclaimed by the claim itself); queue dynamics of deferred demand (disclaimed at §9.6, no claim depends on it).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The construction does exactly what the claim says: a per-junction census over Paper 9 §6's local behaviour with Paper 10 eq. (2.4) entries, no cross-source sum, the threshold cited not redefined, and the exhibit's arithmetic exact — including the at-capacity boundary case.

### FINDING 12 -- L9.4-P12 boundary: saturation fraction undefined at J(τ) = 0; regime change undefined at a window's first tick
- Target claim: L9.4-P12 (§9 claim list, L2288)
- Exact target text: "The saturation census J_sat(τ), the saturation fraction, and regime change (a tick where J_sat changes) are exact counts/ratios…" (L2288); §9.4: "the saturation fraction J_sat(τ)/J(τ) ∈ ℚ, where J(τ) is the population's junction count at τ."
- Domain and required property: The fraction is asserted to be a rational for the populations the construction ranges over; "regime change" is defined by a change of J_sat between consecutive ticks.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Complete witnesses: (i) A junctionless population — admitted by the paper (§2.1's degenerate single configuration; §5.7's junctionless body) — has J(τ) = 0 and J_sat(τ) = 0, so the fraction is 0/0, not a rational (demonstrated, witness_boundary.py §F4). J_sat itself (the count) and regime change remain well-defined there; only the ratio fails. (ii) At the first tick of a declared window with J_sat > 0 already, "a tick at which J_sat changes value" has no predecessor inside the window; §9.5's exhibit supplies a τ − 1 row explicitly, but the definition does not state whether a window-initial saturated tick is a regime change. Precondition check: both witnesses satisfy the paper's population/junction definitions as written; no site in §9 states J(τ) ≥ 1 or a window-initial convention.
- Witness / artifacts: witness_boundary.py §F4 (DEMONSTRATED line in run_log.txt); §F3 for the interior cases.
- Coverage map: (1) native domain: all declared populations, including junctionless ones. (2) verified domain: the J(τ) = 0 point and the window-initial point, in full; all J(τ) ≥ 1 interior ticks by Finding 11. (3) map between them: identity — the witnesses are native declarations evaluated by the claim's own formulas. (4) what the map preserves: J_sat as a count (unaffected). (5) what stays outside: nothing material — the boundary is exactly these two points.
- Category (self-classified, spec section 9.5): B
- Proposed badge: LIMIT
- Reason: Same shape as Finding 8: the construction is exact on its interior domain, but the ratio's domain restriction (J(τ) ≥ 1) and the window-initial convention for "change" are unstated. LIMIT with the boundary named; the count content of the claim is unaffected.

### FINDING 13 -- L10.1-P12: eventual periodicity re-derived in general and stress-tested
- Target claim: L10.1-P12 (§10.1, L2331; claim list L2510)
- Exact target text: "Every aggregate trajectory of a finite population under T_agg is eventually periodic: there exist integers p ≥ 0 (the pre-period) and c ≥ 1 (the cycle length) such that the record at tick t + c equals the record at tick t for all t ≥ p. The pair (p, c) is an exact count, computable by enumeration of the trajectory." [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)] (L2331)
- Domain and required property: All finite populations, all initial records, under T_agg (a total deterministic function — Theorem 4.2). The open-population reading holds only under §10.1's clarification condition (declared re-presentation folded into the transition, or realized whole-period cycles), as the home text states.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: (i) Analytic derivation (domain-general): a total deterministic map on a finite set, iterated, revisits a record within (#records + 1) steps; from the first revisit, determinism forces a cycle; visited-index enumeration computes (p, c). Finiteness of the record set follows from the declared population's constitution (27-state inventory; finitely many junction local states over a fixed junction set; record components fixed by §3.1). (ii) Computational stress (witness_boundary.py §G): 200 random deterministic maps on sets of size 1–30 — every trajectory decomposed with c ≥ 1 and record(t + c) = record(t) verified beyond the pre-period; 300 random closed populations under my T_agg implementation (0–6 pairwise junctions, port-vector lengths 1–2, three-sided junctions in 25% of cases) — τ_agg monotone throughout, and every trajectory's cycle length exactly 1, confirming §10.1's clarification that closed trajectories end at fixed points. (iii) Alternative constructions: a non-deterministic tick or an infinite record set would break the conclusion, but both violate the claim's stated premises (Theorem 4.2; finite population) — recorded as precondition failures, not counterexamples.
- Witness / artifacts: witness_boundary.py §G (G1, G2 PASS; cycle set observed = {1})
- Coverage map: (1) native domain: arbitrary finite populations under T_agg. (2) verified domain: the general proof (which consumes only totality, determinism, finiteness — the same three properties A.3's coverage map names), corroborated over the computed systems. (3) map between them: population record → state of a finite transition system; T_agg → the transition function. (4) what the map preserves: exactly the three consumed properties and the (p, c) values. (5) what stays outside: open populations under arbitrary external re-presentation with no declared rule and no realized cycle — the home text itself excludes them, so they are outside the claim as written, not a gap in it.
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The claim is a finite functional-graph fact with a complete analytic proof whose premises are precisely the inherited ones the badge names (T_agg's well-definedness, via A.2/Theorem 4.2); the computational stress agrees everywhere, including the sharper closed-population consequence c = 1.

### FINDING 14 -- L11.2-P12: size-invariance verified over the stated machine domain; no size branch exists in the definitions
- Target claim: L11.2-P12 (§11.3, L2630; claim list L2675)
- Exact target text: "The census, aggregate-tick, flow-count, aggregate-τ, and reconcile-census constructions of §§3–5 and §7 are size-invariant: for every test population in the A-series batteries, from two bodies to the largest enumerated stress populations, each construction is computed by the same definitions, with the identities checked across population sizes 1–12 (A.1, A.2, A.6), with no size-triggered branch in any construction." [LEVEL A: MACHINE] (L2630)
- Domain and required property: The A-series test populations, sizes 1–12 as the claim's own second clause states (its first clause's "from two bodies" is looser; the registry short form at Appendix B L2882 reads "identities checked across population sizes 1–12", and A.1's provenance confirms generated populations at sizes 1–12).
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: (i) Textual: the definitions of §§3–5 and §7 were read in full; no construction contains a case split on population size or body size, and the identity proofs (partition arithmetic, commutation, bookkeeping, rational arithmetic) never invoke |P|. (ii) Post-derivation confirmation of the enumerated domain: A.1's INPUT_PROVENANCE states generated populations at "sizes 1–12, 8 body types" (L3504). (iii) My own computations exercise the same definitions at sizes 0–12 across §§B, E, G, J of the artifact with no size-dependent behaviour (the only size-0 failures are the ratio domains of Findings 8 and 12, which concern D's and the saturation fraction's denominators, not a branch in any construction — the sums themselves compute at size 0). (iv) The claim is explicitly a claim about the constructions and their implementations ("the honest domain of a machine badge", §11.3), not a metaphysical claim; the analytic extension beyond size 12 is carried at AUTHOR strength by Edge 1 of §11.3, as L11.3-P12 states.
- Witness / artifacts: witness_boundary.py §§B, E, G, J; A.1 provenance lines as cited.
- Coverage map: (1) native domain: the §§3–5/§7 constructions as defined. (2) verified domain: the definitions' text in full; battery sizes 1–12 as the claim states; my computations at sizes 0–12. (3) map between them: same definitions, read once, applied at every size. (4) what the map preserves: the identities themselves. (5) what stays outside: machine verification at sizes > 12 (disclaimed by Edge 1; carried by the size-free proofs at AUTHOR strength under L11.3-P12); populations containing constituents the role taxonomy does not resolve (Edge 2 — an admission boundary, not a size branch).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Over its stated domain the claim is exactly right: one set of definitions, identities checked across sizes 1–12, and — the part a machine badge cannot show — the definitions demonstrably contain no size-triggered branch for a check to miss.

### FINDING 15 -- L11.3-P12: macro-matter verdict matches the machinery's own construction and its stated edges
- Target claim: L11.3-P12 (§11.3 verdict, L2641; claim list L2676)
- Exact target text: "The §§3–5/§7 machinery extends to macro-matter populations by its own construction, size-invariantly, subject to Edges 1–3. The complexity ORDERING, as distinct from the machinery, extends to macro-matter populations only as far as the populations consist of bodies whose individual ordering records exist — atoms and admitted bodies — and no further: a population does not acquire an ordering key from its census, because the census is a partition into count-classes, not a rank." [LEVEL A: AUTHOR] (L2641, L2676)
- Domain and required property: All macro-matter populations, subject to Edge 1 (enumeration horizon), Edge 2 (admission of constituents by the received role taxonomy), Edge 3 (declared junction graph presupposed; packing is Paper 16's). Required: the machinery's definitions impose no size bound, and the census by itself defines no rank.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: (i) Definitional audit: §§3–5 and §7 quantify over "a finite population" with no bound on body count or body size; body admission is §2's receipt of the taxonomy export, which is Edge 2 stated in the claim itself. (ii) Census-no-rank: the census (Defs. 3.3/5.1) is a count function; no comparison over populations is defined by it. Constructive confirmation: a census-only key ties the meson-like/baryon-like representatives outright (identical count vectors — witness_boundary.py §J2/J10, where deleting Res from K, leaving only record-derived components, produces the tie), so any rank on populations requires a definition beyond the census — which is the verdict's exact content, and which §11.3's OR-2 resolution states in the open ("the census partition confers no rank of itself, though census data may feed a definition, as the bodies' count vectors feed this key's CenSig"). Post-derivation corroboration: A.14's mutant M2 (census-only key) is rejected on the same representatives, as its docstring records.
- Witness / artifacts: witness_boundary.py §J (J2, J10); definitional audit in the derivation log.
- Coverage map: (1) native domain: all macro-matter populations. (2) verified domain: the machinery's definitions as written (the extension is by construction, so the definitions are the domain); the census-no-rank clause over the representative pair and, in general, by the census's definition (a count function defines no order). (3) map between them: identity for the definitions; the representative pair for the constructive rank check. (4) what the map preserves: the exact scope the verdict asserts, edges included. (5) what stays outside: whether every Stage P macro-matter constituent is taxonomy-resolvable (Edge 2 — a question about Paper 11's export, which this paper is forbidden to extend; the verdict names it rather than hiding it).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: The verdict is an accurate statement about the paper's own machinery: the definitions are size-free, the three edges are real and are printed in the claim, and the census confers no rank — a point I confirmed constructively, not just by reading the definition.

### FINDING 16 -- L11.4-P12: population ordering key K re-derived; exemplar agreement, stability, and sharpness all reproduce
- Target claim: L11.4-P12 (§11.4 claim list, L2677; definition §11.3, L2645)
- Exact target text: "Population ordering key K defined at §11.3 on the author's ruling (2026-10-28): a total preorder on declared populations, name-invariant, computed from ledger data alone; tick-stability exact (Ntot, Ss, Su, Btot, CenSig invariant under the aggregate tick; Res and Tau0 not — the sharpness witness is printed by A.14); on the exemplar representatives constructed at §11.3, K agrees with Paper 11 §12.1's ordering at every step, each step decided at the component §11.3 names, no paper-silent value consulted." [LEVEL A: MACHINE / AUTHOR] (L2677)
- Domain and required property: All finite declared populations at a declared tick (definition/AUTHOR properties); the representatives and enumerated families (MACHINE content, Finding 17 for its domain). Required: totality/transitivity of the preorder, name-invariance, ledger-data-only computation, the exact tick-stability split, and agreement with §12.1's order on the six representatives at the named deciders (Ss; Ntot; Res; Ntot; Ntot).
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150), paper_11_v69.md (f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb), paper2_section11.txt (ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e)
- Method and complete test space: Independent implementation of K from §11.3's definition (witness_boundary.py §J; count vectors under the §3.2/port-count reading of k_j — deciders are insensitive to the reading, see Finding 17). Results: exemplar keys computed — photon (1,1,0,0,0,−6), tilted (1,1,0,1,1,−6), meson-like (3,0,4,9,3,−14), baryon-like (3,1,4,9,3,−14), nuclei (4,1,6,8,2,−18), atoms (6,1,6,10,3,−30) — inducing §12.1's order with deciders Ss, Ntot, Res, Ntot, Ntot exactly as §11.3 names (J1); meson/baryon count vectors identical and Tau0 tied at 4, separated only at Res (J2); homogeneous families at equal sizes 1–5 preserve the order (J3); empty declaration returns (0,1,0,0,0,0,()) as §11.3 states (J4); name invariance on 300 shuffled populations (J5); transitivity on 300 random triples (J6; the general property is the lexicographic-order argument in the derivation log — the enumeration is corroboration); tick-stability on 300 random populations — Ntot, Ss, Su, −Btot, CenSig invariant in all, Res moved in 98, Tau0 in 112 (J7). Sharpness, examiner's own witness (J8): P = one body (N 3, Ss 9, Su 3) with junctions ((+1),(−1)) and ((+1,+1),(+1,+1)) — K(P) = (3, 0, 6, …); Q = one body (N 3, Ss 9, Su 3) with junction ((+1),(+1)) — K(Q) = (3, 1, 2, …): P < Q decided at Res. After one aggregate tick P's first junction rests (Tau0 6 → 4, Res 0 → 1) while Q is unchanged: K(P′) = (3, 1, 4, …) > K(Q), decided at Tau0 — the order reverses between declaration and rest, so the stability boundary is real. Source verification of the agreement target: Paper 11 §12.1's order and key (node count, tilt count, resolution status; (3,3,0) < (3,3,1)) at packet paper_11_v69.md §§12.1–12.3; Paper 2's differentiae at paper2_section11.txt (preamble; §11.4; §11.5). The GS4-F forced/choice analysis is §6 of this submission; alternative keys are §5 items 1–6.
- Witness / artifacts: witness_boundary.py §J (J1–J14, all PASS; run_log.txt)
- Coverage map: (1) native domain: all finite declared populations at a declared tick, plus the six §12.1 classes as one-member populations and their equal-size homogeneous families. (2) verified domain: the general properties by the analytic derivation (lexicographic tuple of totally ordered components; sums/sorted multiset ⇒ name-invariance; §4-dynamics argument ⇒ stability split) — domain-general, with the enumerations above as counterexample search; the exemplar agreement in full (six representatives, five steps, families to size 5). (3) map between them: a population is its bodies' §3 records plus junction σ's, exactly §11.3's declaration data; K computed from that data alone. (4) what the map preserves: every component's value and every step's decider. (5) what stays outside: the machine corroboration's own domain (Finding 17); the representative construction's fidelity to Paper 2's classes beyond the stated differentiae and the disclosed identification (AUTHOR component, graded as such in the claim — §6 of this submission analyses exactly what the sources force and what remains choice); body-record tick-dynamics beyond §4's stated dynamics (the stability proof's condition, printed in the claim's AUTHOR split).
- Category (self-classified, spec section 9.5): A
- Proposed badge: HELD
- Reason: Every property the claim asserts was either proved in general by this examiner (preorder, name-invariance, stability split) or recomputed exactly (exemplar order and deciders, families, empty case), and the sharpness of the stability boundary was re-witnessed independently rather than taken from A.14's printed witness. The agreement is, as the claim's own split grades it, a property of the construction under the disclosed declared identification — §6 shows which parts of that construction the sources force and which are choices, and the paper claims no more than that.

### FINDING 17 -- L11.4-P12 machine domain: A.14 computes k_j from the side count; outside the one-port-per-side regime its key can differ from §11.3's definition
- Target claim: L11.4-P12 (§11.4 claim list, L2677) — its MACHINE component; and C33's first disjunct (§12)
- Exact target text: "Component split — MACHINE (script A.14): the key's computation and behaviour over the enumerated domains A.14's coverage states…" (L2677). A.14's coverage map (L13440 ff.): "The declaration carries no port-consumption data: the k_j multiset is read from the side count, which equals §3.2's k_j multiset exactly where each side consumes one port". C33 (§12): "wherever a junction's §3 record carries a consumed-port count different from that side count… the §11.3 definition, which reads k_j as Paper 11 §4.1's port count, and A.14's disclosed reading separate, first at the −Btot component — such a population stands outside this disjunct's scope".
- Domain and required property: The MACHINE content is asserted over A.14's disclosed domains. Required for a reader: the boundary between the definition's key (k_j = consumed-port count, Paper 11 §4.1) and the script's computed key (k_j from side count) must be exactly where the paper says it is.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Post-derivation reading of A.14's docstring/coverage (L13440–13600) and of §11.3's definition and C33's scope note. Analysis: the two readings coincide on every population whose junctions consume exactly one port per side (all pairwise junctions of the paper's exhibits, and both readings give k_j = 2 there). They separate exactly when a junction consumes more ports than its side count — the §11.2 clause (ii) regime (a two-sided junction with k_j = 3 or 4) or a multi-sided junction consuming extra ports — and the first component that can differ is −Btot (through B = 6N − Σ_j k_j), then CenSig. I checked the exemplar deciders are insensitive to the reading: every exemplar step is decided at or before Su, except none reaches −Btot/CenSig, and Tau0 (a sum of squares over presented entries) does not consult k_j at all — so Finding 16's agreement results hold under both readings. My own §J implementation used the port-count reading throughout, which is why it is an independent check of the *definition*, complementing A.14's check of its disclosed reading.
- Witness / artifacts: textual witness pair — §11.3's definition (k_j as §3.2's component, i.e. Paper 11 §4.1's port count) vs A.14's coverage-map map paragraph (side-count reading), both in the frozen paper; witness_boundary.py §J for the definition-side computation.
- Coverage map: (1) native domain: all declared populations (the definition). (2) verified domain: the definition in general (Finding 16, port-count reading, analytic + computed); the script's computation only over A.14's enumerated families under its side-count reading (read, not re-run, by this examiner). (3) map between them: identity where each side consumes one port; divergent exactly in the clause (ii) regime. (4) what the map preserves: all exemplar verdicts and deciders, and every component except −Btot/CenSig in the divergent regime. (5) what stays outside: a machine computation of the definition's key on clause (ii) populations — no script in the packet computes it; the definition's properties there rest on §11.3's prose (which this examiner verified) and on no machine artifact.
- Category (self-classified, spec section 9.5): A
- Proposed badge: LIMIT
- Reason: This is a disclosed, correctly scoped boundary, not a hidden defect: the claim's MACHINE component is expressly bounded to "the enumerated domains A.14's coverage states", A.14's map prints the divergence, and C33 scopes its killer to match. I file it as a finding because the boundary is exactly the kind Role B is charged to name: outside the one-port-per-side regime, "the key's computation" in the machine sense does not exist yet, and a reader who runs A.14 on a clause (ii) population will get a key that can differ from §11.3's definition at −Btot and CenSig. The claim over its stated machine domain is HELD; over the full native domain the machine content is LIMIT, with the prose-carried definition HELD as in Finding 16.

### FINDING 18 -- L11.4-P12 boundary observation: CenSig's proper-prefix convention can never decide a comparison between legal populations
- Target claim: L11.4-P12 (§11.4 claim list, L2677); definition §11.3 (L2645)
- Exact target text: "Where two census signatures differ in length, they are compared lexicographically vector by vector under the same order; if every vector of the shorter is matched in order by the longer — the shorter a proper prefix of the longer — the shorter signature is the smaller; script A.14 implements exactly this convention." (§11.3)
- Domain and required property: Attack: exhibit two declared populations whose K comparison is decided by the proper-prefix rule, or show the rule is inconsistent with the rest of the key.
- Sources used: Paper_12_v4.md (fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
- Method and complete test space: Analytic proof that the attack cannot succeed: CenSig is the last component, so the prefix rule can decide only if Ntot, Res, Tau0, Ss, Su, and −Btot all tie. Suppose the signatures are prefix-related with different lengths; the longer signature has extra bodies, each with N ≥ 1 (a body is a bonded aggregate over the inventory, §2.1 — at minimum one node), so its Ntot is strictly larger — contradicting the Ntot tie. Hence no two legal populations reach CenSig with prefix-related signatures of different lengths. Computational corroboration (witness_boundary.py §J9): over 20,000 pairs from a targeted tied family (junctionless bodies, Ss = Su = 0, N ∈ 1..3, 1–3 bodies — a family where CenSig genuinely decides), CenSig decided 1,280 comparisons and the prefix case decided 0; a hand-built pair confirms CenSig itself is a live decider (equal sums, different distributions: bodies {1, 3} vs {2, 2} at Ntot 4, Btot 24 — decided at CenSig). Precondition check: the proof uses only N ≥ 1 per body, which §2.1 guarantees.
- Witness / artifacts: witness_boundary.py §J9 (censig_decided = 1280, prefix_decided = 0)
- Coverage map: (1) native domain: all pairs of declared populations. (2) verified domain: all pairs, by the analytic argument (the computation is corroboration over the targeted family). (3) map between them: identity — the argument is about the definition itself. (4) what the map preserves: totality of the order (the convention still completes the definition of signature comparison; it is simply unreachable as a decider). (5) what stays outside: nothing — but note the observation cuts the other way as well: because the branch is unreachable, no machine check, A.14's included, can exercise it on legal populations, so its correctness rests on the convention's statement alone.
- Category (self-classified, spec section 9.5): A
- Proposed badge: OUTSIDE
- Reason: The tested property — that the prefix convention does deciding work in the key — is not asserted by the claim; §11.3 states the convention to make the order total, and totality is unaffected (indeed the proof shows the convention is a completeness clause, never a live decider). No defect: filed as a boundary observation because the charter charges Role B with the proper-prefix boundary explicitly, and the honest report is that the boundary is empty.

---

## PROCESS STATUS

Per-item status, in the vocabulary of spec §9.4 only, kept separate from the claim verdicts above.

- Frozen paper identity: READ; hash independently recomputed and matched — SOURCE-VERIFIED.
- Brief (Arm N, Role B) and protocol_examiner_extract.md: READ — SOURCE-VERIFIED (hashes in the table above).
- sample_selection.txt: READ — SOURCE-REPORTED (taken as the trial's given sample; its selection script was not in the packet and was NOT RUN by this examiner).
- Paper_12_v4.md home texts and definitions (§§0–13, Appendices A–B): READ.
- Paper_12_v4.md Appendix C listings: PARTIALLY READ, post-derivation only, as logged in §3 (A.14, A.3, A.4, A.6, A.12 docstrings/coverage; A.1 provenance excerpt). A.2, A.5, A.7–A.11, A.13, A.15, FW.1, G.1, H.1: NOT READ. No Paper 12 script was RUN by this examiner.
- Paper_12_v4.md Appendices D, E, F (exhibits and battery record): NOT READ (not needed for the sample; C32's firing was assessed from §12's record and Prop. 5.9's home text).
- paper2_section11.txt: READ (§11 preamble, §§11.1–11.8) — SOURCE-VERIFIED.
- paper9.txt: READ at the cited sites (§2 form, §3 occasion definition as cited, §4, §5, §6 Step 1) — SOURCE-VERIFIED at those sites; the whole file NOT READ.
- paper10.txt: READ at the cited sites (§2.2 eqs. (2.2a)–(2.4), L933–985) — SOURCE-VERIFIED at those sites; the whole file NOT READ.
- paper_11_v69.md: READ at the cited sites (§4.1, §8, §8.6, §§12.1–12.4) — SOURCE-VERIFIED at those sites; the whole file NOT READ.
- paper_11_5_v26.md: READ at the cited sites (§7.4 scope note location, §§11.5–11.6 at L2763–2818, roadmap line) — SOURCE-VERIFIED at those sites; the whole file NOT READ.
- packet/roleC_only/blind_claims.md: NOT READ (Role C material; outside my permitted list).
- packet/blind_verification.txt: NOT READ (not in my brief's permitted list).
- Examiner computations (witness_boundary.py): RUN — exit 0, all checks PASS; output saved as run_log.txt — REPRODUCED (the artifact is deterministic and seeded; the run log in this directory is its output).
- Examiner spot scan (scan_locked.py): RUN — output saved as scan_locked_out.txt.
- Paper's verification suite (run_all / A-series as a suite): NOT RUN by this examiner (Role D's remit; my verdicts rest on my own derivations and artifacts, plus the coverage statements I read).
- Submission sealing: UNSEALED (hashes of this directory's files are reported to the coordinator in my final reply, per the brief).
