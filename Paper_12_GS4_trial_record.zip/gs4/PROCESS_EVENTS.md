# GS-4 GOLD v1.0 — PROCESS EVENTS LOG (coordinator)

- PE-0 (pre-freeze, recorded in FREEZE_RECORD.md §5): blind-packet
  generation caught a cell-misparse of registry row L7.3-P12 (raw "|"
  in its text); parsers corrected; sample regenerated before freeze.
- PE-1 (2026-10-31, after N/C sealing): the Arm N Role C agent's
  session terminated when it sealed its main submission (platform
  behaviour: a completed subagent cannot receive follow-up messages, and
  resume of a terminal agent is refused). The GS4-B reveal pass for
  Arm N Role C is therefore executed by a fresh continuation agent on
  the identical certified brief, working from the sealed BLIND_SEALED.md
  and SUBMISSION.md (its own arm/role record) plus the coordinator's
  revealed labels. Isolation is unaffected (no cross-arm or cross-role
  material involved). The same continuation mechanics will be used for
  Arm H Role C's reveal pass and for both Role D mutation-witness
  duties, and each use is logged here.
- PE-1a (2026-10-31): PE-1 mechanics used for Arm H Role C's reveal
  pass (fresh continuation agent on the HC brief + sealed H/C record +
  revealed labels).
- PE-1b (2026-10-31): PE-1 mechanics used for both Role D mutation-
  witness duties (Arm N witness for M1-M12, Arm H witness for M13-M24),
  each a fresh continuation agent on its own arm's Role D brief, reading
  only its own predecessor's sealed submission and its own half of the
  mutation log.
- PE-2 (2026-10-31): the mutation runner recorded one convention in its
  log header: script-content mutations (M1, M17, M20, and M21's A.14
  half) were applied identically to the extracted script, its embedded
  listing, and its manifest row, so listing-identity (A.9) was not the
  control under test for those; M5 is the listing-only exception. This
  is a runner mechanics note within the pre-registered expectations
  (none of M1/M17/M20/M21 names A.9 as its control), recorded here for
  the adjudicator.
- PE-3 (2026-10-31): split-witness read restriction imperfectly
  enforced by tooling: the Arm H witness's read of RUN_LOG.md returned
  the whole file in one call despite the half-only tasking. The witness
  attests its checks and verdicts were restricted to M13-M24 (the
  countersignature covers only its half), but it cannot attest it never
  saw the other half's records. Recorded for the report; the Arm N
  witness was tasked identically and any similar exposure will be
  recorded the same way.
