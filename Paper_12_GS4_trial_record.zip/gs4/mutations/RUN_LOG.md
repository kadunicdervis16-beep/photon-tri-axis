# GS-4 Gold v1.0 — Mutation Battery Run Log (spec §8)

Trial: **GS-4 Gold v1.0 (house execution, two-arm isolated-context trial)**.
Runner: mutation runner (no badges proposed, no findings filed — verdicts
below record only whether each pre-registered expectation was met).

## Baseline

- Frozen paper: `gs4/frozen/Paper_12_v4.md`, SHA-256
  `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150`
  (verified before the run).
- Baseline working copy built under `mutations/tree/` from the frozen
  paper plus the 32 files extracted from its own Appendix C / Appendix E
  listings (extractor implementing the A.9 protocol: BEGIN marker, fence,
  content, END marker; bytes = content lines joined with `\n` plus one
  final `\n`). Every extracted file's SHA-256 matches its manifest row
  in the paper (24 Appendix C rows + 8 Appendix E exhibit rows).
- Baseline suite (fresh tree, `python3 scripts/run_all.py`): exit 0,
  closing line `run_all SUMMARY: 18/18 scripts PASS`. Full output:
  `artifacts/baseline_suite.txt`.

## Application convention (recorded once, applied throughout)

- Paper-text mutations are applied to the working-copy paper only.
- Script-content mutations (M1, M17, M20, and the A.14 half of M21) are
  applied identically to the extracted script file, to its embedded
  Appendix C listing, and to the listing's manifest row (SHA-256 and
  byte count regenerated) — i.e. the mutation is the content change a
  real edited-and-rebuilt paper would carry, so the suite's
  consistency check (A.9) is not the control under test; the semantic
  control named in §8.2 is. M5 is the deliberate exception: there the
  listing alone is replaced and A.9 is the named control.
- Input-level probes (M8, M9, M10, M12, M14, M16, M22) are run against
  the baseline extraction (`/tmp/gs4run/baseline_tree`, a byte-identical
  copy of the baseline tree) with the probe inputs constructed exactly
  as §8.2 describes; the working tree for those runs is a fresh
  baseline copy and the full suite is still run and recorded.
- Every mutation starts from a FRESH copy of the baseline tree.
- Suite command in every run: `python3 scripts/run_all.py` executed in
  `mutations/tree/` (no arguments). Per-mutation full suite outputs are
  kept in `artifacts/Mxx_suite.txt`; decisive lines are quoted in each
  record below.

## Summary

| ID | Expected control (§8.2) | Observed | Verdict |
|---|---|---|---|
| M1 | no control expected — declared scope boundary (provenance-class accuracy rests on audit) | suite 18/18 PASS; no script fires on the relabel | boundary-confirmed |
| M2 | no control expected for a pure split move — declared scope boundary | suite 18/18 PASS; H.1 check (4) does not fire (badge strings identical) | boundary-confirmed |
| M3 | H.1 (claim/registry bijection) | suite fails: H.1   FAIL (exit 1) — H.1 VERDICT: FAIL — 1 problem(s) | expectation met |
| M4 | A.15 check comparing fixture to both computation paths (incl. check (4) print-binding) | suite fails: A.15  FAIL (exit 1) — A.15 VERDICT: FAIL — ["(4) transcription anchors: the appendix's printed values stand in the paper's Appendix F span as the fixture carries them — every printed field class bound (generated anchors per class; retained anchors for the prose-dressed values)"] | expectation met |
| M5 | A.9 (listing byte-identity / manifest) | suite fails: A.9   FAIL (exit 1) — A.9 VERDICT: FAIL — 2 check(s) failed: ['(5) per-file sha256 and byte count [Appendix C]: every reconstructed file matches its manifest sha256 and byte count', '(7) sibling comparison: every canonical file present beside the paper equals its extracted bytes'] | expectation met |
| M6 | no control expected — declared scope boundary (change-log completeness is Role C's audit) | suite 18/18 PASS; no script fires on the unlogged scope edit | boundary-confirmed |
| M7 | H.1 (registry-vs-home badge reproduction) | suite fails: H.1   FAIL (exit 1) — H.1 VERDICT: FAIL — 1 problem(s) | expectation met |
| M8 | A.15's own input handling — explicit rejection or a stated empty-case result expected | A.15 crashes on the empty population: ZeroDivisionError (Fraction(0, 0)) — no explicit rejection, no stated empty-case result | expectation NOT met |
| M9 | A.14's comparison plus §11.3's stated prefix convention — the convention decides, no exception | convention decides at CenSig: K(short) < K(long), decider CenSig, no exception | expectation met |
| M10 | A.15/A.14 invariance checks — identical K components and census ratios expected | all name-free projections identical under total relabelling (census classes/totals, τ series, standings, flows, joints, R, D, Ω, equilibrium) | expectation met |
| M11 | A.12 / Proposition 5.9(ii)'s stated horizon reading — counts as the proposition's stated form requires, no double count | J_W = 4 = J_W1 + J_W2 = 2 + 2; the straddling term counted once, in W1, per the horizon reading; no double count | expectation met |
| M12 | A.14's stated domain handling — handled as outside A.14's domain per its disclosure, with C33's scoped text not firing | A.14 computes with its disclosed side-count reading (k_j = 3, B = 9, K returned, tick carries the junction unchanged, Res = 1); the case stands outside A.14's disclosed domain and outside C33's first disjunct per its scope note | expectation met |
| M13 | Role D's Gate 1 hash verification | hash-verification pass flags packet/paper9.txt MISMATCH (1 of 10); other 9 OK | expectation met |
| M14 | A.15/A.12 declaration validation — rejection or a stated duplicate rule expected; silent double-counting is the finding | no rejection and no stated duplicate rule: the duplicate is silently double-counted in the direct totals (9/44) and silently collapsed in the name-keyed grouped totals (7/34); inconsistency surfaces only as downstream internal identity FAILs | expectation NOT met |
| M15 | no control expected — declared scope boundary (dependency completeness is Role C's audit) | suite 18/18 PASS; no script fires on the removed dependency edge | boundary-confirmed |
| M16 | A.12 — the declared-horizon rule decides the count | counts follow Def 5.8 exactly: J_(0,3) = 1, J_(0,2) = 1, J_(0,4) = 1, J_(1,4) = 0 — the crossing event is excluded whole, no partial credit | expectation met |
| M17 | no script control expected; the control is the examiner (Role D item 6) | suite 18/18 PASS; A.5 output byte-identical to baseline despite the proxied check | boundary-confirmed |
| M18 | FW.1 firewall sweep | suite fails: FW.1 SUSPECT on [entropy] in Definition 5.7's neutral clause | expectation met |
| M19 | no control expected — declared scope boundary (Role C item 5 audit) | suite 18/18 PASS; no script fires on the omitted assumption name | boundary-confirmed |
| M20 | A.14's representative/order checks | suite fails: A.14  FAIL (exit 1) — A.14 VERDICT: FAIL — 4 check(s) failed: ["(1a) representatives: K induces §12.1's order, strictly, at every adjacent step", '(1b) each step decides at the component §11.3 names (photon/tilted at Ss, the 3-node step at Res, the rest at Ntot)', '(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity', '(5) stability invariants: Ntot, Ss, Su, -Btot, CenSig agree between declaration and rest on every F1 population (Res and Tau0 are the components that may move)'] | expectation met |
| M21 | A.14 / §11.3 representative checks | suite fails: A.14  FAIL (exit 1) — A.14 VERDICT: FAIL — 2 check(s) failed: ["(1a) representatives: K induces §12.1's order, strictly, at every adjacent step", '(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity'] | expectation met |
| M22 | A.12/Def 5.7 legality checks — rejection as an illegal record, or a stated precedence rule decides | pairwise instrument rejects the 3-sided record (ValueError); under Def 5.7's multi-sided clause the stated precedence decides '+' | expectation met |
| M23 | G.1 quote-integrity check | suite 18/18 PASS — G.1 verdict unchanged; truncated segment still FOUND (prefix/substring property) | expectation NOT met |
| M24 | FW.1/G.1-class wording checks if swept; else no control expected — declared scope boundary | suite 18/18 PASS; FW.1/G.1 do not sweep the receipt→citation wording shape | boundary-confirmed |

## Per-mutation records

### M1 — A.15 INPUT_PROVENANCE relabel (paper-defined → cited-paper)

- **Mutation (exact diff, applied identically to `scripts/A15_spine.py`, its Appendix C listing, and the manifest row):**
  - before: `  - Assignment counts: class=paper-defined via A.5's`
  - after: `  - Assignment counts: class=cited-paper via A.5's`
  - (the binding is Paper 12 §§8.2–8.4's own multinomial via A.5 — a paper-defined binding relabelled as cited-paper, the Y2 shape.) Manifest row regenerated: sha256 `78830a9e7ed894e663877ff0483b3dd97ffbeb63d27b9c41bde51afe0766da8b`, bytes 101118. A.9 therefore still passes — the mutation is content-only, as a rebuilt paper would carry it.
- **Controls run:** full suite (`python3 scripts/run_all.py`); no F.49-style provenance-class check exists in the suite to run additionally (the suite's scripts carry INPUT_PROVENANCE blocks as docstrings; no script parses another script's provenance classes — A.13 checks the §0.4(b) formalization, not provenance classes).
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. No script failed; A.15's own verdict line unchanged (PASS).
- **Verdict:** boundary-confirmed — no control expected/fired, per §8.2's declared scope boundary (provenance-class accuracy of A.15 rests on audit).

### M2 — Hybrid claim L8.3-P12: prose-carried general clause moved AUTHOR → MACHINE leg (Appendix B row)

- **Mutation (exact diff, working-copy paper line 2860, Appendix B registry row L8.3-P12):**
  - before: `…the inequality (8.7) checked over n = 1…12; AUTHOR: the all-n generality of (8.7) beyond that range, carried by §8.3's printed induction, which A.5's coverage expressly leaves to the prose, and the reading of those counts as concentration…`
  - after: `…the inequality (8.7) checked over n = 1…12, and the all-n generality of (8.7) beyond that range, carried by §8.3's printed induction; AUTHOR: the reading of those counts as concentration…`
  - The row's badge cell `[LEVEL A: MACHINE / AUTHOR — script A.5]` is unchanged; the claim-list (home) entry is unchanged.
- **Controls run:** full suite; specifically H.1 (registry-vs-home check 4).
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. H.1 line: `H.1   PASS (exit 0) — H.1 VERDICT: PASS — every claim carries a taxonomy badge; every MACHINE-badged claim names an existing script; every Appendix B registry badge reproduces its home-site badge in full (check 4); 0 SUSPECT scope flag(s) listed for human adjudication.` — the badge strings at home and registry are identical, so check (4) has nothing to fire on, and no other H.1 check parses the component-split text.
- **Verdict:** boundary-confirmed — pure split move with badge string unchanged: no control expected/fired, per §8.2's declared scope boundary.

### M3 — Appendix B registry row deleted (claim remains in the claim list)

- **Mutation (exact diff):** deleted working-copy paper line 2860, the entire Appendix B registry row:
  - `| L8.3-P12 | The polarized records' combined share of assignments is exactly 2^(1−n), and the non-polarized share satisfies 1 − 2^(1−n) ≥ (n − 1)/n for all n ≥ 1 (eqs. 8.6–8.7). Component split — MACHINE (A.5): the assignment counts enumerated over n = 1…6, the closed-form shares and the inequality …`
  - The claim itself remains in the claim list (§8's list, `- **L8.3-P12** — …`) and in §8's body.
- **Controls run:** full suite; specifically H.1 (claim/registry bijection).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Only H.1 fails. Decisive H.1 output lines (full output in `artifacts/M3_suite.txt`):
  - `H.1   FAIL (exit 1) — H.1 VERDICT: FAIL — 1 problem(s)`
  - `[REGISTRY-DIFF] Paper_12_v4.md:0 L8.3-P12 — registry badge None != home badge '[LEVEL A: MACHINE / AUTHOR — script A.5]'`
- **Verdict:** expectation met — H.1 fired on the missing registry row.

### M4 — One numeric value altered in the Appendix F fixture (printed text)

- **Mutation (exact diff, working-copy paper line 69341, Appendix F, E-SMALL census paragraph):**
  - before: `Census (§3): count vectors (2, (2), 10) for S1 and S2; (3, (2, 2), 14) for S3. The census is 2 and 1 over those classes; totals by (III): nodes 7, boundary 34, agreeing with the direct route 6·7 − 8 = 34.`
  - after: `Census (§3): count vectors (2, (2), 10) for S1 and S2; (3, (2, 2), 14) for S3. The census is 2 and 1 over those classes; totals by (III): nodes 7, boundary 35, agreeing with the direct route 6·7 − 8 = 34.`
  - i.e. the printed boundary total 34 → 35; every expected output in script A.15 (its FIXTURE and both computation paths) is left unchanged.
- **Controls run:** full suite; specifically A.15 (fixture vs both computation paths, and check (4) binding the fixture to the appendix's printed text). A.15 also run standalone for detail (`artifacts/M4_A15_detail.txt`).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ['A.15  FAIL (exit 1) — A.15 VERDICT: FAIL — ["(4) transcription anchors: the appendix\'s printed values stand in the paper\'s Appendix F span as the fixture carries them — every printed field class bound (generated anchors per class; retained anchors for the prose-dressed values)"]']. A.15 decisive lines: `[FAIL] (4) transcription anchors: … — 169/170 anchors present (164 generated, 6 retained); missing: ['nodes 7, boundary 34']` and `A.15 VERDICT: FAIL — ["(4) transcription anchors: …"]`; checks (2) and (3) still PASS (2128 leaves compared, mismatches: 0) — the firing control is check (4)'s binding of the fixture to the appendix's printed text, exactly the control §8.2 names.15 VERDICT: FAIL — ["(4) transcription anchors: the appendix's printed values stand in the paper's Appendix F span as the fixture carries them — every printed field class bound (generated anchors per class; retained anchors for the prose-dressed values)"].
- **Verdict:** expectation met — A.15 fired on the altered printed value.

### M5 — Embedded A.15 listing replaced with its previous round's version (stale listing)

- **Mutation (exact diff):** the content of the `scripts/A15_spine.py` listing block in the working-copy paper (block beginning at paper line 14006, `<!-- BEGIN LISTING: scripts/A15_spine.py -->`) is replaced wholesale with the coordinator-supplied fixture `mutations/stale_listing_fixture.py` (SHA-256 `15715481e6b65e858e4e25f0618a9dda93cd7cb6d85e9c0da6f143a040e04ddd`, 98,835 bytes, 1,806 lines — the previous version of A.15; the current listing is 101,120 bytes). Nothing else is changed: the extracted script file beside the paper, and the Appendix C manifest row (sha256 `4828b6b2…`, 101,120 bytes), still describe the current version. The fixture contains no backtick runs, so the block's existing ``` fence remains well-formed. First differing hunk (current → fixture): the docstring's verify-path sentence loses "the capability construction (its two outcome rules carried as copies of A.4's)" phrasing and the INPUT_PROVENANCE block is the shorter previous-round form (91 diff lines in total; full fixture is the artifact of record).
- **Controls run:** full suite; specifically A.9 (listing byte-identity / manifest), also run standalone (`artifacts/M5_A9_detail.txt`).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ["A.9   FAIL (exit 1) — A.9 VERDICT: FAIL — 2 check(s) failed: ['(5) per-file sha256 and byte count [Appendix C]: every reconstructed file matches its manifest sha256 and byte count', '(7) sibling comparison: every canonical file present beside the paper equals its extracted bytes']"]. A.9 decisive lines (standalone run): `witness: scripts/A15_spine.py: sha256 mismatch — manifest 4828b6b264a1f24f… vs extracted 15715481e6b65e858e…`, `witness: scripts/A15_spine.py: byte count mismatch — manifest 101120 vs extracted 98835`, `[FAIL] (5) per-file sha256 and byte count [Appendix C] — 2 mismatch(es) over 24 file(s)`, `[FAIL] (7) sibling comparison — 1 mismatch(es)`. A.9 decisive lines: [FAIL] (5) per-file sha256 and byte count [Appendix C]: every reconstructed file matches its manifest sha256 and byte count — 2 mismatch(es) over 24 file(s) | [FAIL] (7) sibling comparison: every canonical file present beside the paper equals its extracted bytes — 1 mismatch(es) | A.9 VERDICT: FAIL — 2 check(s) failed: ['(5) per-file sha256 and byte count [Appendix C]: every reconstructed file matches its manifest sha256 and byte count', '(7) sibling comparison: every canonical file present beside the paper equals its extracted bytes'].
- **Verdict:** expectation met — A.9 fired on the stale listing.

### M6 — Claim scope sentence edited in the body; no version-history entry

- **Mutation (exact diff, working-copy paper line 1165, the L5.8-P12 scope statement in §5's claim enumeration):**
  - before: `…objection): the dissolution's scope is the closed system with a declared population and a declared initial state;…`
  - after: `…objection): the dissolution's scope is the closed or open system with a declared population and a declared initial state;…`
  - The claim's scope is widened (closed → closed or open). No entry is added to the paper's Version block (the version history at the end of the paper is untouched), and the Appendix B registry row for L5.8-P12 is untouched.
- **Controls run:** full suite (no script control is expected; change-log completeness is Role C's GS4-H audit, not a script control).
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none.
- **Verdict:** boundary-confirmed — no control expected/fired, per §8.2's declared scope boundary.

### M7 — Claim-list badge strengthened above the registry (L1.5-P12: LEVEL B → LEVEL A: AUTHOR, claim list only)

- **Mutation (exact diff, working-copy paper line 249, claim-list entry):**
  - before: `- **L1.5-P12** — Programme: this paper discharges item (2) of L1.2-P12 by dissolution rather than by construction — no sampling-measure postulate is adopted anywhere in Paper 12. **[LEVEL B]** — declared programme at this site; …`
  - after: same entry with `**[LEVEL A: AUTHOR]**` in place of `**[LEVEL B]**`.
  - The Appendix B registry row for L1.5-P12 still carries `[LEVEL B]`, and nothing else in the paper is changed — the home badge now stands above the registry badge (and above the programme declaration's own standing).
- **Controls run:** full suite; specifically H.1 (registry-vs-home badge reproduction, check 4).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ['H.1   FAIL (exit 1) — H.1 VERDICT: FAIL — 1 problem(s)']. H.1 problem lines: PROBLEMS (MISSING / UNRECOGNIZED / REGISTRY-DIFF): | [REGISTRY-DIFF] Paper_12_v4.md:0 L1.5-P12 — registry badge '[LEVEL B]' != home badge '[LEVEL A: AUTHOR]' | [PASS] M5 registry short form flagged (REGISTRY-DIFF).
- **Verdict:** expectation met — H.1 fired on the strengthened home badge.

### M8 — Empty population declaration fed to the Spine generator

- **Mutation (input-level probe):** the exact input constructed is `{"id": "E-EMPTY", "bodies": [], "contact": {}, "joint_specs": []}` passed to `A15.run_population` (the Spine generator that normally supplies the three nonempty exhibits) from the baseline extraction.
  - Probe script: `artifacts/probe_M8.py`; full output: `artifacts/M8_probe.txt` (probe exit 0).
- **Controls run:** A.15's own input handling (the named control), via the probe; the full suite is not the control for an input probe and is recorded for uniformity. Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** the generator computes Stations 1–3 on the empty declaration (empty census, τ_agg = 0, tallies (0, 0, 0)) and then **crashes**: `ZeroDivisionError: Fraction(0, 0)` raised at `A15_spine.py`, line 605, in `run_population`, while forming a frequency ratio over the empty population (full traceback in `artifacts/M8_probe.txt`). There is no explicit rejection and no stated empty-case result — the crash shape §8.2 names as the finding.
- **Verdict:** expectation NOT met.

### M9 — Two populations whose CenSig values stand in a proper-prefix relation, compared under K

- **Mutation (input-level probe):** constructed with A.14's own classes from the baseline extraction: `B1 = Body(2, 4, 1, [((1, 0), (-1, 0))])` (vector `(2, (2,), 10, 4, 1)`) and `B0 = Body(0, 0, 0, [])` (vector `(0, (), 0, 0, 0)`); `P_short = Population([B1])`, `P_long = Population([B1, B0])`. The first six K components are identical by construction, and CenSig(P_short) = `((2, (2,), 10, 4, 1),)` is a proper prefix of CenSig(P_long) = `((2, (2,), 10, 4, 1), (0, (), 0, 0, 0))`.
  - Probe script: `artifacts/probe_M9.py`; full output: `artifacts/M9_probe.txt` (probe exit 0).
- **Controls run:** A.14's comparison (`key_KB`, `deciding_component`) plus §11.3's stated prefix convention (paper line 2649: "if every vector of the shorter is matched in order by the longer — the shorter a proper prefix of the longer — the shorter signature is the smaller"). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: `proper-prefix relation: True`; `first six components equal: True`; `K(short) < K(long): True`; `deciding component: CenSig`; `no exception raised`. The comparison is decided exactly where §11.3's convention says it must be.
- **Verdict:** expectation met.

### M10 — Every body in a Spine population relabelled (permuted names), records unchanged

- **Mutation (input-level probe):** A.15's E-SMALL declaration with body names permuted `S1→X7, S2→X3, S3→X9` (contact keys renamed to match; every record — N, junctions, σ, contact values, joint specs by index — unchanged), run through `A15.run_population` from the baseline extraction and compared with the undisturbed run on all name-free projections.
  - Probe script: `artifacts/probe_M10.py`; full output: `artifacts/M10_probe.txt` (probe exit 0).
- **Controls run:** A.15/A.14 invariance checks (the probe exercises A.15's generator directly; A.14's own name-invariance check (3) passed in the baseline suite). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: `projections identical under total relabelling: True`, with every projected field — census_classes, tot_N, tot_B, tau_agg_series, standings_records, standings_frequencies, flows, joints_J, R, D, omega, equilibrium — reported IDENTICAL, and 0 internal FAIL entries.
- **Verdict:** expectation met.

### M11 — Joint-count window shifted so an offset straddles the window split

- **Mutation (input-level probe):** constructed with A.12 from the baseline extraction: one body with σ = ((1, 0), (−1, 0)) (standing '+' at tick 0, '0' thereafter), joint spec `(("body", 0), "0", δ=+1)` — the entry's offset reads τ+1 — over W = (0, 4) split as W1 = (0, 2), W2 = (2, 4). The τ = 1 term of W1 reads tick 2, which lies in W2: the offset straddles the split.
  - Probe script: `artifacts/probe_M11.py`; full output: `artifacts/M11_probe.txt` (probe exit 0).
- **Controls run:** A.12 / Proposition 5.9(ii)'s stated horizon reading (paper §5: "Subwindow counts are taken under Definition 5.8's horizon condition (τ + δ inside the declared horizon), not under a requirement that τ + δ lie in the subwindow; additivity therefore holds also for ticks whose offset crosses the split"). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: `J_(0, 4) (X='0', delta=+1) = 4`, `J_(0, 2) = 2`, `J_(2, 4) = 2`, `additivity across the split: J_W=4, J_W1+J_W2=2+2=4, equal: True`; the δ=0 control gives J = 1 = 1 + 0. The straddling tick is counted exactly once, under the subwindow that owns τ, as the proposition's stated form requires.
- **Verdict:** expectation met.

### M12 — Multi-sided junction whose consumed-port count differs from its side count, at the C33 boundary

- **Mutation (input-level probe):** constructed with A.14 from the baseline extraction: a body `Body(2, 0, 0, [((0, 1), (0, 1), (0, 0))])` — a three-sided junction (the K7/J13 shape) — read as a record whose consumed-port count is 4 (one side consuming two ports, the §11.2 clause (ii) case), so the §11.3 definition's B = 6·2 − 4 = 8 while the side-count reading gives B = 9.
  - Probe script: `artifacts/probe_M12.py`; full output: `artifacts/M12_probe.txt` (probe exit 0).
- **Controls run:** A.14's stated domain handling (its `k_j` disclosure) and C33's scoped text (paper line 2706, which expressly places populations whose junction's §3 record carries a consumed-port count different from the side count outside the first disjunct's scope). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: `A14 k_j reading (side count): 3`; `A14 B for the body: 9` against the definition-side 8; `K(P) computed without exception: (2, 1, 2, 0, 0, -9, ((2, (3,), 9, 0, 0),))`; `tick carries the multi-sided junction unchanged: True`; `Res: 1`. No exception, no claim of coverage: A.14's `k_j` docstring states the disclosure verbatim ("A junction consuming more than one port at a side (§11.2, clause (ii)) is outside this script's domain"), and C33's scope note carves exactly this case out of its killer, so the scoped text does not fire.
- **Verdict:** expectation met.

### M13 — One source hash corrupted in the packet-manifest copy (Role D's copy)

- **Mutation (exact diff, mechanical form per the runner brief):** a copy of the freeze record's packet manifest table was made (`artifacts/M13_manifest_corrupted.md`); in the copy, exactly one hash was corrupted:
  - `packet/paper9.txt`: `defe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6` → `0efe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6` (first hex digit changed).
  - The packet files themselves and the freeze record are untouched.
- **Controls run:** Role D's Gate 1 hash verification, executed as a hash-verification pass comparing the corrupted manifest against the actual packet files (`artifacts/M13_verify.txt`); plus the full suite on a fresh baseline tree for uniformity (exit 0; `run_all SUMMARY: 18/18 scripts PASS`).
- **Observed:** the verification pass reports `MISMATCH packet/paper9.txt: manifest 0efe9cdc6ad3e29d… actual defe9cdc6ad3e29d…` and OK for the other 9 entries; result line: `RESULT: 1 mismatch(es): ['packet/paper9.txt']`. The mismatch is detected by the pass itself, before any examiner run would proceed.
- **Verdict:** expectation met — Gate 1 hash verification detects the corrupted hash.

### M14 — One population member duplicated (same name, same record, twice) in a Spine declaration

- **Mutation (input-level probe):** A.15's E-SMALL declaration with its first body duplicated — `bodies + [deepcopy of the S1 body]` (same name "S1", same record) — fed to `A15.run_population` from the baseline extraction; contact and joint specs unchanged.
  - Probe script: `artifacts/probe_M14.py`; full output: `artifacts/M14_probe.txt` (probe exit 0).
- **Controls run:** A.15/A.12 declaration validation (the named control). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: `RETURNED without exception and without any duplicate rejection`; `census totals with duplicate: tot_N = 9, tot_B = 44 (undisturbed SMALL: tot_N = 7, tot_B = 34)`; `census vectors keys: ['S1', 'S2', 'S3']` — the name-keyed census dict silently collapses the duplicate while the direct route counts it twice; `temperature R = 6, D = 1/2 (undisturbed: R = 5, D = 5/9)`. Four internal identity expects then fail downstream (`(II) census sums to |P| = 4`, `(III) nodes grouped 7 == direct 9`, `(III) boundary grouped 34 == direct 44`, `mean of locals 5/12 == D 1/2`) — a symptom registered inside the exhibit computation, not a declaration validation: the declaration itself is neither rejected nor governed by any stated duplicate rule.
- **Verdict:** expectation NOT met.

### M15 — One dependency edge removed from a sampled claim's registry row (L11.2-P12: A.2 edge)

- **Mutation (exact diff, working-copy paper line 2882, Appendix B registry row L11.2-P12 — a member of the frozen twelve-claim sample):**
  - before: `…no size-triggered branch | [LEVEL A: MACHINE] | A.1, A.2, A.6 | FINAL |`
  - after: `…no size-triggered branch | [LEVEL A: MACHINE] | A.1, A.6 | FINAL |`
  - The A.2 dependency edge is gone from the row (text edited, graph edge gone); the claim-list entry at §11 (line 2675, `(A.1, A.2, A.6)`) and the claim's own statement at line 2630 are untouched.
- **Controls run:** full suite (no script control is expected; dependency completeness is Role C's GS4-C audit). H.1 check (2) requires only that a MACHINE-badged claim name an existing script — A.1 and A.6 remain named.
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none.
- **Verdict:** boundary-confirmed — no control expected/fired, per §8.2's declared scope boundary.

### M16 — One tick window in a §5 joint-count example changed so an event crosses the window boundary mid-count

- **Mutation (input-level probe):** the §5 exhibited joint count of the Spine's E-SMALL thread — `J_W(S1 = +, S3 = −)` over W = (0, 3), computed with A.12's `joint_count_members` on the A.15 E-SMALL declaration (baseline extraction) — with the window changed to (1, 4) (and (0, 2), (0, 4) as controls). The population's only joint event stands at tick 0, so the (1, 4) shift moves it across the window boundary.
  - Probe script: `artifacts/probe_M16.py`; full output: `artifacts/M16_probe.txt` (probe exit 0).
- **Controls run:** A.12, under Definition 5.8's declared-horizon rule (count exactly the τ ∈ W, τ + δ inside the declared horizon). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output (standings by tick: tick 0 (+, 0, −), ticks 1–4 (0, 0, 0)): `J_(0, 3)(S1 = +, S3 = -) = 1`, `J_(0, 2) = 1`, `J_(0, 4) = 1`, `J_(1, 4) = 0`; the offset form behaves the same (`J_(0, 3)(S1 = + at d=0, S3 = 0 at d=+1) = 1`, `J_(1, 4) = 0`). The declared-horizon rule decides every count.
- **Verdict:** expectation met.

### M17 — One script check replaced by a proxy (string presence), output text identical

- **Mutation (exact diff, applied identically to `scripts/A5_concentration.py`, its Appendix C listing, and the manifest row; manifest regenerated: sha256 `294c539979cfdf985555750529a407352f70e86996a1a6cb902ad96e07b71f23`, bytes 17051):**
  - In A.5's Step 2 (the (8.3) ratio rule), the computed-quantity test
    - before: `            if ratio != expect:` (where `ratio = Fraction(counts[k + 1], counts[k])` and `expect = Fraction(n - k, k + 1)` are computed on the preceding two lines)
    - after: `            if "(8.3)" not in "(8.3)":` — the branch now tests a string's presence (never true) instead of the computed ratio; the failure print inside the branch is unreachable, and every printed line of the script is unchanged.
  - Mechanical form per the runner brief: output text kept identical — verified directly: A.5 standalone output on the mutated tree is byte-identical to its baseline output (`artifacts/M17_A5_baseline.txt` vs `artifacts/M17_A5_mutated.txt`, identical: True; both exit 0).
- **Controls run:** full suite. Per §8.2 the expected control is Role D's content-vs-shape determination (an examiner), and **no script control is expected**.
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none — the suite passes the proxied check, exactly as pre-registered.
- **Verdict:** boundary-confirmed — no script control expected/fired; the control is the examiner (Role D item 6).

### M18 — Stage P bridge word inserted into a native Stage N definition sentence

- **Mutation (exact diff, working-copy paper lines 931–932, Definition 5.7's neutral-standing clause — a native Stage N definition):**
  - before: `- **neutral** — the presented data contains no opposed pair of either orientation.`
  - after: `- **neutral** — the presented data contains no opposed pair of either orientation — the member's entropy class at that tick.`
  - The Stage P bridge word **entropy** is inserted into the definition sentence. (Site selection recorded: a first attempt inside §3.3's Definition (census) paragraph was classified by FW.1 as zone `construction` — that paragraph's own word "Definition" is one of FW.1's construction markers — and did not fire; the battery mutation was therefore applied at this definition site, whose segment carries no construction/bridge/scope marker. The first attempt is disclosed here, not hidden.)
- **Controls run:** full suite; specifically FW.1 (firewall sweep), also run standalone (`artifacts/M18_FW1_detail.txt`).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ['FW.1  FAIL (exit 1) — FW.1 VERDICT: FAIL — 1 SUSPECT hit(s) for human adjudication']. FW.1 decisive lines: Paper_12_v4.md:932 [entropy] SUSPECT — orientation — the member's entropy class at that tick. | Paper_12_v4.md:15900 [temperature] embedded-listing — - temperature, entropy             (controlled: SUSPECT unless the same | Paper_12_v4.md:15900 [entropy] embedded-listing — - temperature, entropy             (controlled: SUSPECT unless the same; FW.1 standalone exit 1 with SUSPECT count ≥ 1 (full output in artifact).
- **Verdict:** expectation met — FW.1 fires on the inserted bridge word at a marker-free native definition site.

### M19 — One declared assumption's name omitted at a load-bearing use site

- **Mutation (exact diff, working-copy paper line 2664, §11.3's representative construction):**
  - before: `…the atoms representative N = M + S at S = 2, under Paper 11 F.37's declared assumptions (M > 3; S ≥ 1; atoms are nuclei plus incorporated simple states).`
  - after: `…the atoms representative N = M + S at S = 2, under Paper 11 F.37's declared assumptions (M > 3; atoms are nuclei plus incorporated simple states).`
  - The name **S ≥ 1** is omitted at the very site that consumes it (the nuclei/atoms step's parametric range rests on S ≥ 1); the site's other text is unchanged.
- **Controls run:** full suite (no script control is expected; this is Role C item 5's audit). A.14 does not read the paper's §11.3 prose — its representatives are its own transcription — so no script can see the omission.
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none.
- **Verdict:** boundary-confirmed — no control expected/fired, per §8.2's declared scope boundary.

### M20 — Two deciding components of K reordered in A.14's key tuple (Ntot ↔ Res)

- **Mutation (exact diff, applied identically to `scripts/A14_ordering_key.py`, its Appendix C listing, and the manifest row; final manifest: sha256 `13e7ef52c079e1540a57f7c90c6eb611b2b95573368fdc32850606e1548a1ee4`, bytes 23540):**
  - `key_KB`: before `return (P.N_tot(), P.resolved(), P.tau_agg(), P.Ss_tot(), P.Su_tot(), -P.B_tot(), P.census_sig())`; after `return (P.resolved(), P.N_tot(), P.tau_agg(), P.Ss_tot(), P.Su_tot(), -P.B_tot(), P.census_sig())`.
  - `COMPONENTS`: before `["Ntot", "Res", "Tau0", "Ss", "Su", "-Btot", "CenSig"]`; after `["Res", "Ntot", "Tau0", "Ss", "Su", "-Btot", "CenSig"]`.
  - The mutant keys key_KA / key_KH / key_census_only / key_name_dependent are untouched.
- **Controls run:** full suite; specifically A.14 (representative/order checks), also run standalone (`artifacts/M20_A14_detail.txt`).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ['A.14  FAIL (exit 1) — A.14 VERDICT: FAIL — 4 check(s) failed: ["(1a) representatives: K induces §12.1\'s order, strictly, at every adjacent step", \'(1b) each step decides at the component §11.3 names (photon/tilted at Ss, the 3-node step at Res, the rest at Ntot)\', \'(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity\', \'(5) stability invariants: Ntot, Ss, Su, -Btot, CenSig agree between declaration and rest on every F1 population (Res and Tau0 are the components that may move)\']']. A.14 decisive lines: [FAIL] (1a) representatives: K induces §12.1's order, strictly, at every adjacent step — photon<tilted at Ss; tilted<meson at Res; meson<baryon at Res; baryon<nuclei at Ntot; nuclei<atoms at Ntot | [FAIL] (1b) each step decides at the component §11.3 names (photon/tilted at Ss, the 3-node step at Res, the rest at Ntot) | [FAIL] (2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity | [FAIL] (5) stability invariants: Ntot, Ss, Su, -Btot, CenSig agree between declaration and rest on every F1 population (Res and Tau0 are the components that may move) — violations: 2128 | A.14 VERDICT: FAIL — 4 check(s) failed: ["(1a) representatives: K induces §12.1's order, strictly, at every adjacent step", '(1b) each step decides at the component §11.3 names (photon/tilted at Ss, the 3-node step at Res, the rest at Ntot)', '(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity', '(5) stability invariants: Ntot, Ss, Su, -Btot, CenSig agree between declaration and rest on every F1 population (Res and Tau0 are the components that may move)'].
- **Verdict:** expectation met — A.14's representative comparisons failed under the reordered key.

### M21 — One sign changed in Table 5.1's received sign facts as printed in §11.3's representatives

- **Mutation (exact diff, two consistent halves):**
  - Paper, working-copy line 2664 (§11.3): before `…only its workload's positivity — a stated sign fact, Paper 11 Table 5.1: s² = 0 for the photon, s² > 0 for the tilted states — is consulted at their step…`; after `…s² = 0 for the photon, s² < 0 for the tilted states…` (the tilted sign fact flipped).
  - A.14's transcription of the same representative, applied identically to `scripts/A14_ordering_key.py`, its listing, and the manifest row (sha256 `3c32aadf2e5bbf8bccef74343f6ebd88e9846bfcd877715a7994a6de2271aaed`, bytes 23541): before `tilted = Population([Body(1, 1, 1, [])])` (Ss2 = +1); after `tilted = Population([Body(1, -1, 1, [])])` (Ss2 = −1).
- **Controls run:** full suite; specifically A.14 / §11.3 representative checks, also run standalone (`artifacts/M21_A14_detail.txt`).
- **Observed:** suite exit 1; `run_all SUMMARY: 17/18 scripts PASS — FAILURES PRESENT`. Failing scripts: ['A.14  FAIL (exit 1) — A.14 VERDICT: FAIL — 2 check(s) failed: ["(1a) representatives: K induces §12.1\'s order, strictly, at every adjacent step", \'(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity\']']. A.14 decisive lines: [FAIL] (1a) representatives: K induces §12.1's order, strictly, at every adjacent step — photon<tilted at Ss; tilted<meson at Ntot; meson<baryon at Res; baryon<nuclei at Ntot; nuclei<atoms at Ntot | [FAIL] (2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity | A.14 VERDICT: FAIL — 2 check(s) failed: ["(1a) representatives: K induces §12.1's order, strictly, at every adjacent step", '(2) homogeneous families {G x n}, n = 1..4: the class order is preserved at every multiplicity'].
- **Verdict:** expectation met — at least one representative comparison failed.

### M22 — One junction given two incompatible standings via a multi-sided record read through the pairwise rule

- **Mutation (input-level probe):** constructed exactly as a three-sided record `sides = ((1,), (−1,), (1,))` and read through the pairwise rule (A.12's `standing` on side pairs, in declaration order): sides (0,1) read '+', sides (1,2) read '−' — one junction, two incompatible standings. The whole record is then fed to A.12's pairwise `standing` directly, and to Definition 5.7's multi-sided clause as implemented by A.15's `ms_standing`.
  - Probe script: `artifacts/probe_M22.py`; full output: `artifacts/M22_probe.txt` (probe exit 0).
- **Controls run:** A.12 / Definition 5.7 legality checks (the named control). Full suite on a fresh baseline tree: exit 0; `run_all SUMMARY: 18/18 scripts PASS`.
- **Observed:** probe output: pairwise readings `sides (0,1): +`, `sides (0,2): 0`, `sides (1,2): -`; the pairwise instrument on the whole record: `REJECTED: ValueError - too many values to unpack (expected 2)` — the pairwise rule refuses a non-pair record; and Definition 5.7's own multi-sided clause (opposed pair read between two sides in declaration order, same precedence clauses) decides the standing: `A15.ms_standing: +`, corroborated by the both-orientations pair σ ((1, −1), (−1, 1)) reading '+' under A.12 (positive precedence). Both halves of §8.2's disjunction are exhibited: rejection by the pairwise instrument, and a stated precedence rule deciding where the paper's own clause applies.
- **Verdict:** expectation met.

### M23 — Verbatim quotation in §11.3 truncated mid-phrase (G.1 punctuation pattern preserved)

- **Mutation (exact diff, working-copy paper line 2653, §11.3):**
  - before: `…the resolution status's meaning "is supplied only by the finite §12 class definition," the status being "not an independent ledger quantity" (§12.4).`
  - after: `…the resolution status's meaning "is supplied only by the finite §12 class," the status being "not an independent ledger quantity" (§12.4).`
  - The Paper 11 quotation is truncated mid-phrase (the final word "definition" cut); the closing quote-and-comma punctuation pattern is exactly as before.
- **Controls run:** full suite; specifically G.1 (quote-integrity), also run standalone (`artifacts/M23_G1_detail.txt`).
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none. G.1 verdict lines: G.1 VERDICT: PASS — all 29 verbatim quotations (blockquotes + named checks) FOUND in their attributed sources; mutants behave; 26 advisory inline anomalies listed for adjudication.. G.1's lines for paper line 2653 after the mutation: [NOT FOUND] inline Paper_12_v4.md:2653 attributed=Paper 11 verified-in=- segment absent from all sources: "unresolved integers left at the junction..." | [NOT FOUND] inline Paper_12_v4.md:2653 attributed=Paper 11 verified-in=- segment absent from all sources: "one integer still unresolved at the junction..." | [NOT FOUND] inline Paper_12_v4.md:2653 attributed=Paper 11 verified-in=- segment absent from all sources: "still carrying surplus, still searching for resolution..." | [NOT FOUND] inline Paper_12_v4.md:2653 attributed=Paper 11 verified-in=- segment absent from all sources: "settling three matching integers with no surplus..." | [FOUND] inline Paper_12_v4.md:2653 attributed=Paper 11 verified-in=Paper 11. (Baseline G.1 reported at line 2653 one `[FOUND] inline … attributed=Paper 11` entry for this quotation, alongside the advisory NOT FOUND entries for the Paper 2 quotations, which lie outside G.1's four-source sweep as the paper discloses at §0.4(d).)
- **Verdict:** expectation NOT met — G.1 did not fire: its verdict remains PASS. The truncated remainder is a prefix of the true quotation, and G.1's segment test is a substring test, so the segment still verifies as FOUND in the advisory inline sweep; §11.3's quotations are inline (advisory in G.1), not blockquote/named (the hard-verdict set).

### M24 — §6.1 bonding-mode premise: receipt wording replaced with citation wording at one consumption site

- **Mutation (exact diff, working-copy paper lines 499–500, Theorem 4.2's badge — a consumption site named at §0.4(b)):**
  - before: `[LEVEL A — conditional on Paper 11 §4.3 (Port-Partition Exactness) and Paper 11 §7.5 (the properties of T), both Level A in Paper 11; §4.3's conditions include Paper 11 §6.1's bonding-mode premise, received at §0.4(b) as a declared receipt.]`
  - after: `[LEVEL A — conditional on Paper 11 §4.3 (Port-Partition Exactness) and Paper 11 §7.5 (the properties of T), both Level A in Paper 11; §4.3's conditions include the bonding-mode premise, which Paper 2 proves at §11.1.]`
  - The declared-receipt wording is replaced by a citation wording ("Paper 2 proves…") that misstates the premise's form (Paper 2 §11.1 states the matching rule without port vocabulary; the premise is carried as a declared receipt, §0.4(b)).
- **Controls run:** full suite; specifically FW.1/G.1-class wording checks.
- **Observed:** suite exit 0; `run_all SUMMARY: 18/18 scripts PASS`. Failing scripts: none — neither FW.1 (the wording carries no controlled term in an unsanctioned zone) nor G.1 (the badge text is not a verbatim quotation) sweeps this shape.
- **Verdict:** boundary-confirmed — no control expected/fired, per §8.2's declared scope boundary (Role C audit).

## Commands run (exact)

- Baseline build: extractor implementing the A.9 protocol over
  `gs4/frozen/Paper_12_v4.md` → `mutations/tree/` (32 files; every
  extracted SHA-256 checked against its manifest row), frozen paper
  copied to `mutations/tree/Paper_12_v4.md` (SHA-256 verified
  `fc0499af…` before and after the battery; the frozen copy and the
  packet copy were never mutated).
- Baseline suite: `cd mutations/tree && python3 scripts/run_all.py`
  → exit 0, `run_all SUMMARY: 18/18 scripts PASS`
  (`artifacts/baseline_suite.txt`).
- Each mutation M1–M24: fresh copy of the baseline tree →
  `mutations/tree/`; mutation applied as recorded in its section;
  `cd mutations/tree && python3 scripts/run_all.py` (full output in
  `artifacts/Mxx_suite.txt`).
- Standalone control runs: `python3 scripts/A9_listings.py` (M5),
  `python3 scripts/A15_spine.py` (M4), `python3 scripts/FW1_firewall.py`
  (M18), `python3 scripts/A14_ordering_key.py` (M20, M21),
  `python3 scripts/G1_quotes.py` (M23), `python3 scripts/A5_concentration.py`
  on baseline and mutated trees (M17) — outputs in `artifacts/`.
- Probes (M8, M9, M10, M11, M12, M14, M16, M22):
  `python3 artifacts/probe_Mxx.py /tmp/gs4run/baseline_tree/scripts`
  (baseline extraction; `/tmp/gs4run/baseline_tree` is a byte-identical
  copy of the baseline tree) — full outputs in `artifacts/Mxx_probe.txt`.
- M13: SHA-256 verification pass over the ten packet files against the
  corrupted manifest copy (`artifacts/M13_verify.txt`).
- After the battery: the working tree was restored to a fresh baseline
  copy and the suite re-run on it — `run_all SUMMARY: 18/18 scripts
  PASS` — so `mutations/tree/` stands pristine at the close.

## Verdict tally

- Expectation met: 14 (M3, M4, M5, M7, M9, M10, M11, M12, M13, M16,
  M18, M20, M21, M22)
- Boundary-confirmed (declared no-control class, no control fired):
  7 (M1, M2, M6, M15, M17, M19, M24)
- Expectation NOT met: 3 (M8 — A.15 crashes on an empty population
  declaration; M14 — duplicate member silently double-counted /
  name-collapsed with no rejection or stated duplicate rule; M23 —
  G.1 does not fire on the mid-phrase-truncated §11.3 quotation)

The runner proposes no badges and files no findings; the three
NOT-met records are stated as observed behaviour for the adjudicator.
Witness countersignatures (spec §8.3: Role D of Arm N for M1–M12,
Role D of Arm H for M13–M24) are appended by the witnesses after
their arms' submissions are sealed — those lines are not the
runner's to write.

---

## WITNESS COUNTERSIGNATURES (spec 8.3)

Appended by the coordinator after split witnessing; the two WITNESS.md files are reproduced verbatim below their headings. The runner's pre-witness log hash was 7e64801b784753a7664191fc8264b05e8a9ab8a197c5cb6c236088776fe213b8.

### Arm N Role D witness (M1-M12) -- submissions/N/D/WITNESS.md sha256 4b6be0bf9b6a89527538f7f2f7c3dfe854b5a96a5726d53d63d32c1b1aadd322

# WITNESS — GS-4 Gold v1.0 (house execution, two-arm isolated-context trial)
## Arm N, Role D — Mutation Witness (spec §8.3), Mutations M1–M12

Witness: Arm N, Role D (continuation agent, executing the mutation-witness duty of spec §8.3 on the identical charter after the original Role D session ended at sealing). Scope: M1–M12 only, per the split-witness protocol.

Method: for each mutation I compared (a) the runner's record in `mutations/RUN_LOG.md` (summary table and the M1–M12 records only) against (b) the artifact evidence under `mutations/artifacts/` (the per-mutation suite outputs `Mxx_suite.txt`, the standalone detail files for M4 and M5, and the probe outputs `M8_probe.txt`–`M12_probe.txt` with their probe scripts), and (c) the pre-registered §8.2 expectation as printed in the run log's summary table (expected control column). **CONFIRMED** below means: the observed behaviour in the artifacts matches the runner's record, and the runner's classification of that behaviour against the pre-registered expectation (expectation met / expectation NOT met / boundary-confirmed) is correct. This is witnessing only: no badges are proposed and no findings about the paper are filed.

| ID | Runner's verdict | Witness verdict |
|---|---|---|
| M1 | boundary-confirmed | **CONFIRMED** — `M1_suite.txt` shows `run_all SUMMARY: 18/18 scripts PASS` with A.15's verdict line unchanged (PASS); no script fires on the provenance relabel. This matches the pre-registered expectation: no control expected — declared scope boundary (provenance-class accuracy rests on audit). |
| M2 | boundary-confirmed | **CONFIRMED** — `M2_suite.txt` shows 18/18 PASS; H.1 PASSes with its check (4) wording intact (registry badge reproduces home badge in full), i.e. H.1 does not fire because the badge strings are identical and no H.1 check parses the component-split text. Matches the pre-registered expectation: no control expected for a pure split move — declared scope boundary. |
| M3 | expectation met | **CONFIRMED** — `M3_suite.txt` shows 17/18 PASS with only H.1 failing (exit 1, 1 problem): `[REGISTRY-DIFF] Paper_12_v4.md:0 L8.3-P12 — registry badge None != home badge '[LEVEL A: MACHINE / AUTHOR — script A.5]'`. Matches the pre-registered expectation: H.1 (claim/registry bijection) fires on the deleted registry row. |
| M4 | expectation met | **CONFIRMED** — `M4_suite.txt` and `M4_A15_detail.txt` show 17/18 PASS with only A.15 failing, on check (4) only: `169/170 anchors present (164 generated, 6 retained); missing: ['nodes 7, boundary 34']`, while checks (2) and (3) still PASS (2,128 leaves compared, mismatches: 0). The firing control is exactly the one §8.2 names: A.15's check binding the fixture to Appendix F's printed text. |
| M5 | expectation met | **CONFIRMED** — `M5_suite.txt` and `M5_A9_detail.txt` show 17/18 PASS with only A.9 failing, on checks (5) and (7): witness lines give `scripts/A15_spine.py: sha256 mismatch — manifest 4828b6b264a1f24f… vs extracted 15715481e6b65e858e…` and `byte count mismatch — manifest 101120 vs extracted 98835`, plus the sibling-comparison witness with the same two hashes/counts. Matches the pre-registered expectation: A.9 (listing byte-identity / manifest) fires on the stale listing. |
| M6 | boundary-confirmed | **CONFIRMED** — `M6_suite.txt` shows `run_all SUMMARY: 18/18 scripts PASS`, no failing script; no script fires on the unlogged scope edit. Matches the pre-registered expectation: no control expected — declared scope boundary (change-log completeness is Role C's audit). |
| M7 | expectation met | **CONFIRMED** — `M7_suite.txt` shows 17/18 PASS with only H.1 failing (exit 1, 1 problem): `[REGISTRY-DIFF] Paper_12_v4.md:0 L1.5-P12 — registry badge '[LEVEL B]' != home badge '[LEVEL A: AUTHOR]'`. Matches the pre-registered expectation: H.1 (registry-vs-home badge reproduction) fires on the strengthened claim-list badge. |
| M8 | expectation NOT met | **CONFIRMED** — the runner's NOT-met record is itself confirmed. `M8_probe.txt` shows the empty declaration computed through Stations 1–3 (empty census, τ_agg = 0, tallies (0, 0, 0)) and then crashed: `ZeroDivisionError: Fraction(0, 0)` at `A15_spine.py`, line 605, in `run_population`, while forming a frequency ratio — no explicit rejection and no stated empty-case result, which is the crash shape the pre-registered expectation (A.15's own input handling: explicit rejection or a stated empty-case result) names as the failure. `M8_suite.txt` (full suite on a fresh baseline tree, 18/18 PASS) is not the control for this input probe, as the log records. |
| M9 | expectation met | **CONFIRMED** — `M9_probe.txt` shows the constructed prefix relation holds (`proper-prefix relation: True`), the first six K components are equal, `K(short) < K(long): True`, `deciding component: CenSig`, and `no exception raised`. Matches the pre-registered expectation: A.14's comparison plus §11.3's stated prefix convention — the convention decides at CenSig, no exception. |
| M10 | expectation met | **CONFIRMED** — `M10_probe.txt` shows both runs in full and reports `projections identical under total relabelling: True`, with every projected field listed IDENTICAL (census_classes, tot_N, tot_B, tau_agg_series, standings_records, standings_frequencies, flows, joints_J, R, D, omega, equilibrium) and 0 internal FAIL entries in either run. Matches the pre-registered expectation: A.15/A.14 invariance checks — identical name-free projections under total relabelling. |
| M11 | expectation met | **CONFIRMED** — `M11_probe.txt` shows `J_(0, 4) (X='0', delta=+1) = 4`, `J_(0, 2) = 2`, `J_(2, 4) = 2`, `additivity across the split: J_W=4, J_W1+J_W2=2+2=4, equal: True`, with the τ=1 term of W1 (reading tick 2, in W2) counted once, in W1, per Proposition 5.9(ii)'s horizon reading; the δ=0 control gives J = 1 = 1 + 0. No double count. Matches the pre-registered expectation. |
| M12 | expectation met | **CONFIRMED** — `M12_probe.txt` shows `A14 k_j reading (side count): 3`, `A14 B for the body: 9` against the definition-side value 8 for consumed-port count 4, `K(P) computed without exception: (2, 1, 2, 0, 0, -9, ((2, (3,), 9, 0, 0),))`, `tick carries the multi-sided junction unchanged: True`, `Res: 1`, and quotes A.14's disclosure verbatim ("A junction consuming more than one port at a side (§11.2, clause (ii)) is outside this script's domain"). Matches the pre-registered expectation: handled as outside A.14's disclosed domain, with C33's scoped text not firing. |

Tally of this witness: 12 witnessed — 12 CONFIRMED, 0 DISPUTED. Against the pre-registered §8.2 expectations: expectation met = M3, M4, M5, M7, M9, M10, M11, M12 (8); boundary-confirmed = M1, M2, M6 (3); expectation NOT met = M8 (1).

PROCESS STATUS: Brief and sealed Arm N Role D submission READ; RUN_LOG summary table and M1–M12 records READ; M1–M12 artifacts READ and checked (suite outputs M1–M12, M4/M5 detail files, M8–M12 probe outputs and probe scripts); M13–M24 records and artifacts NOT READ / not witnessed (split-witness scope: Arm H Role D's half); mutation witnessing RUN — 12/12 CONFIRMED, 0 DISPUTED; no badges proposed, no findings filed; this witness file is the sole deliverable of this duty.

### Arm H Role D witness (M13-M24) -- submissions/H/D/WITNESS.md sha256 50580ac6936b98ee833c87b11ed31e50998f2bd4fdf7b2191a917b3b67f6ede0

# WITNESS — GS-4 Gold v1.0, ARM H, ROLE D — Mutation Witness, M13–M24 (spec §8.3)

Trial label: *GS-4 Gold v1.0 (house execution, two-arm isolated-context trial).*

Witness duty only: for each of M13–M24 I independently checked the runner's
record in `gs4/mutations/RUN_LOG.md` (summary table and the M13–M24 records)
against the artifacts under `gs4/mutations/artifacts/`, and checked whether
the observed behaviour so evidenced matches the pre-registered §8.2
expectation as recorded by the runner (expectation met / expectation NOT
met / boundary-confirmed). No badges are proposed and no findings about the
paper are filed here.

Method per mutation: read the decisive artifact(s) named in the runner's
record — the verification/probe output where one exists, the per-mutation
suite output (`Mxx_suite.txt`) in every case, and the standalone control
detail where one exists (M18 FW.1, M20/M21 A.14, M23 G.1, M17 A.5
baseline-vs-mutated outputs) — and compared the decisive lines, counts and
values character-for-character with the runner's quoted observation.

## Per-mutation witness table

| ID | Runner's verdict | Witness verdict |
|---|---|---|
| M13 | expectation met | **CONFIRMED** — `M13_manifest_corrupted.md` shows exactly one corrupted hash: `packet/paper9.txt` `0efe9cdc…` in place of `defe9cdc…` (first hex digit changed), the other nine entries uncorrupted. `M13_verify.txt` reports `MISMATCH packet/paper9.txt: manifest 0efe9cdc6ad3e29d… actual defe9cdc6ad3e29d…`, OK for the other 9 entries, and `RESULT: 1 mismatch(es): ['packet/paper9.txt']`. `M13_suite.txt`: 18/18 PASS. The behaviour matches the artifact evidence and the §8.2 expectation (Gate 1 hash verification flags the corruption). |
| M14 | expectation NOT met | **CONFIRMED** — `M14_probe.txt` shows the duplicated-S1 declaration `RETURNED without exception and without any duplicate rejection`; direct totals `tot_N = 9, tot_B = 44` against undisturbed `7 / 34`; census vector keys `['S1', 'S2', 'S3']` (name-keyed collapse, grouped route 7 / 34 in the FAIL lines); `R = 6, D = 1/2` against undisturbed `R = 5, D = 5/9`; and exactly the four downstream internal FAIL entries the log names — `(II) census sums to |P| = 4`, `(III) nodes grouped 7 == direct 9`, `(III) boundary grouped 34 == direct 44`, `mean of locals 5/12 == D 1/2`. No rejection and no stated duplicate rule appear. `M14_suite.txt` (baseline tree): 18/18 PASS. Observed behaviour and the NOT-met expectation both match the evidence. |
| M15 | boundary-confirmed | **CONFIRMED** — `M15_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); no script fires on the removed L11.2-P12 A.2 dependency edge. This matches the runner's record and the §8.2 declared scope boundary (no control expected; dependency completeness is Role C's audit). |
| M16 | expectation met | **CONFIRMED** — `M16_probe.txt` shows standings tick 0 `(+, 0, −)`, ticks 1–4 `(0, 0, 0)`, and counts `J_(0, 3) = 1`, `J_(0, 2) = 1`, `J_(0, 4) = 1`, `J_(1, 4) = 0` for `J(S1 = +, S3 = −)`, with the offset form likewise `J_(0, 3) = 1`, `J_(1, 4) = 0` — the tick-0 event excluded whole when the window shifts to (1, 4), no partial credit, exactly as the log records under Definition 5.8's declared-horizon rule. `M16_suite.txt`: 18/18 PASS. |
| M17 | boundary-confirmed | **CONFIRMED** — `M17_suite.txt`: 18/18 PASS, no script fires. The runner's decisive supporting claim is independently verified: `M17_A5_baseline.txt` and `M17_A5_mutated.txt` are byte-identical (`cmp` clean; both 3,058 bytes), so the proxied A.5 check passes with output text unchanged, exactly as pre-registered. No script control was expected; the control is the examiner (Role D item 6) — boundary-confirmed as recorded. |
| M18 | expectation met | **CONFIRMED** — `M18_suite.txt`: 17/18 PASS, `FW.1 FAIL (exit 1) — FW.1 VERDICT: FAIL — 1 SUSPECT hit(s)`. `M18_FW1_detail.txt` carries the decisive line at paper line 932: `[entropy] SUSPECT — orientation — the member's entropy class at that tick.`, repeated in the detail's verdict block; the only other entropy/temperature hits shown are in the controlled embedded-listing zone (line 15900). FW.1 fired on the inserted bridge word at the native definition site, as recorded. |
| M19 | boundary-confirmed | **CONFIRMED** — `M19_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); no script fires on the omission of the `S ≥ 1` assumption name at the §11.3 use site. Matches the runner's record and the §8.2 declared scope boundary (no control expected; Role C item 5 audit). |
| M20 | expectation met | **CONFIRMED** — `M20_suite.txt`: 17/18 PASS. `M20_A14_detail.txt` shows exactly the four failed checks the log names — (1a) representatives' order, (1b) named deciding components, (2) homogeneous families n = 1..4, (5) stability invariants with `violations: 2128` — and `A.14 VERDICT: FAIL — 4 check(s) failed` listing the same four. A.14's representative/order checks fired under the Ntot ↔ Res reordering, as recorded. |
| M21 | expectation met | **CONFIRMED** — `M21_suite.txt`: 17/18 PASS. `M21_A14_detail.txt` shows exactly the two failed checks the log names — (1a) representatives' order (with the tilted<meson step now deciding at Ntot) and (2) homogeneous families — with (1b) and (5) PASS, and `A.14 VERDICT: FAIL — 2 check(s) failed` listing the same two. At least one representative comparison failed under the flipped tilted sign fact, as recorded. |
| M22 | expectation met | **CONFIRMED** — `M22_probe.txt` shows the pairwise readings `sides (0,1): +`, `sides (0,2): 0`, `sides (1,2): -`; the pairwise instrument on the whole 3-sided record `REJECTED: ValueError - too many values to unpack (expected 2)`; Definition 5.7's multi-sided clause via `A15.ms_standing: +`; and the both-orientations pair `((1, -1), (-1, 1))` reading `+` under A.12 (positive precedence). Both halves of §8.2's disjunction are exhibited, as recorded. `M22_suite.txt`: 18/18 PASS. |
| M23 | expectation NOT met | **CONFIRMED** — `M23_suite.txt`: 18/18 PASS, G.1 verdict unchanged (`PASS — all 29 verbatim quotations … FOUND`). `M23_G1_detail.txt` shows at paper line 2653 one `[FOUND] inline … attributed=Paper 11` entry alongside the four advisory `[NOT FOUND]` entries for the out-of-sweep Paper 2 segments, and the closing `G.1 VERDICT: PASS`. G.1 did not fire on the mid-phrase-truncated §11.3 quotation — the truncated remainder still verifies as FOUND, consistent with the log's prefix/substring explanation for an advisory inline (not hard-verdict) quotation. Observed behaviour and the NOT-met expectation both match the evidence. |
| M24 | boundary-confirmed | **CONFIRMED** — `M24_suite.txt` records `run_all SUMMARY: 18/18 scripts PASS` with no failing script (file byte-identical to `baseline_suite.txt`); neither FW.1 nor G.1 fires on the receipt→citation wording replacement at the Theorem 4.2 badge site. Matches the runner's record and the §8.2 declared scope boundary (no control expected; Role C audit). |

Summary of this witness: 12 of 12 records (M13–M24) CONFIRMED, 0 DISPUTED —
in each case the observed behaviour recorded by the runner matches the
artifact evidence, and the runner's classification against the
pre-registered §8.2 expectation (6 expectation met: M13, M16, M18, M20,
M21, M22; 2 expectation NOT met: M14, M23; 4 boundary-confirmed: M15, M17,
M19, M24) is the classification the evidence supports.

## PROCESS STATUS

READ (Role D brief; predecessor SUBMISSION.md; RUN_LOG summary table and M13–M24 records; M13–M24 artifacts as cited above) / RUN (artifact comparisons, byte-identity and hash spot-checks performed by this witness; no suite or probe re-executed — witnessing rests on the runner's preserved artifacts) / REPRODUCED (decisive lines, counts and values in every M13–M24 record reproduced from the artifacts) / SOURCE-REPORTED (mutation diffs and probe constructions as recorded in the run log; decisive observed behaviour SOURCE-VERIFIED against the artifacts) — witness complete for M13–M24.
