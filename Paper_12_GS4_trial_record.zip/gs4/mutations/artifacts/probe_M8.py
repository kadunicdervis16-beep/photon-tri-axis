import sys, traceback
sys.path.insert(0, sys.argv[1])
import A15_spine as A15
empty = {"id": "E-EMPTY", "bodies": [], "contact": {}, "joint_specs": []}
print("PROBE M8: feed empty population declaration to A15.run_population (the Spine generator)")
try:
    out = A15.run_population(empty)
    print("RETURNED without exception")
    print("census:", out.get("census"))
    print("temperature:", out.get("temperature"))
    print("internal FAIL list:", A15.FAIL)
except Exception:
    print("EXCEPTION (crash):")
    traceback.print_exc()
