import sys
sys.path.insert(0, sys.argv[1])
import A12_joint_counts as A12
print("A12 HORIZON:", A12.HORIZON)
sigma0 = ((((1, 0), (-1, 0)),),)
d = A12.make_pop(["B1"], sigma0)
print("body standings by tick:", [d["stnd"][t][0] for t in range(6)])
spec = ((("body", 0), "0", 1),)   # standing '0' at tau+1
for W in [(0, 4), (0, 2), (2, 4)]:
    print(f"J_{W} (X='0', delta=+1) =", A12.joint_count_members(d, W, spec))
JW = A12.joint_count_members(d, (0, 4), spec)
J1 = A12.joint_count_members(d, (0, 2), spec)
J2 = A12.joint_count_members(d, (2, 4), spec)
print(f"additivity across the split: J_W={JW}, J_W1+J_W2={J1}+{J2}={J1+J2}, equal: {JW==J1+J2}")
print("the tau=1 term of W1 reads tick 2 (in W2): standing at tick 2 =", d["stnd"][2][0],
      "— counted once, in W1, per Prop 5.9(ii)'s horizon reading")
spec0 = ((("body", 0), "+"),)
print("delta=0 control, X='+': J_(0,4) =", A12.joint_count_members(d, (0, 4), spec0),
      " J_(0,2) =", A12.joint_count_members(d, (0, 2), spec0),
      " J_(2,4) =", A12.joint_count_members(d, (2, 4), spec0))
