import sys, copy
sys.path.insert(0, sys.argv[1])
import A15_spine as A15
base = A15.run_population(copy.deepcopy(A15.SMALL))
ren = copy.deepcopy(A15.SMALL)
mapping = {"S1": "X7", "S2": "X3", "S3": "X9"}
for b in ren["bodies"]:
    b["name"] = mapping[b["name"]]
ren["contact"] = {mapping[k]: v for k, v in ren["contact"].items()}
relabeled = A15.run_population(ren)
def proj(o):
    return {
        "census_classes": o["census"]["classes"],
        "tot_N": o["census"]["tot_N"], "tot_B": o["census"]["tot_B"],
        "tau_agg_series": [r["tau_agg"] for r in o["tau"]["rows"]],
        "standings_records": o["standings"]["records"],
        "standings_frequencies": o["standings"]["frequencies"],
        "flows": o["flows"],
        "joints_J": [j["J"] for j in o["joints"]],
        "R": o["temperature"]["R"], "D": o["temperature"]["D"],
        "omega": o["omega"]["omegas"], "equilibrium": o["equilibrium"],
    }
pb, pr = proj(base), proj(relabeled)
print("projections identical under total relabelling:", pb == pr)
for k in pb:
    print(f"  {k}: {'IDENTICAL' if pb[k]==pr[k] else 'DIFFERS: '+str((pb[k],pr[k]))}")
print("A15 internal FAIL counts (base, relabeled):", len(A15.FAIL))
