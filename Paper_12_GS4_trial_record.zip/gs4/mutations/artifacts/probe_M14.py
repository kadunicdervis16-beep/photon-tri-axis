import sys, copy
sys.path.insert(0, sys.argv[1])
import A15_spine as A15
pop = copy.deepcopy(A15.SMALL)
dup = copy.deepcopy(A15.SMALL["bodies"][0])   # S1, same name, same record
pop["bodies"] = pop["bodies"] + [dup]
pop["id"] = "E-SMALL-DUP"
print("PROBE M14: SMALL with body S1 duplicated (same name, same record, twice)")
try:
    out = A15.run_population(pop)
    print("RETURNED without exception and without any duplicate rejection")
    print("census totals with duplicate: tot_N =", out["census"]["tot_N"], " tot_B =", out["census"]["tot_B"],
          " (undisturbed SMALL: tot_N = 7, tot_B = 34)")
    print("census vectors keys:", list(out["census"]["vectors"].keys()))
    print("temperature R =", out["temperature"]["R"], " D =", out["temperature"]["D"], " (undisturbed: R = 5, D = 5/9)")
    print("internal FAIL entries:", len(A15.FAIL), A15.FAIL[:5])
except Exception as e:
    print("EXCEPTION:", type(e).__name__, e)
