import sys
sys.path.insert(0, sys.argv[1])
import A12_joint_counts as A12
import A15_spine as A15
sides = ((1,), (-1,), (1,))   # one three-sided junction's presented record
def pair_reading(a, b):
    return A12.standing((a, b))
print("pairwise readings between the sides, in declaration order:")
print("  sides (0,1):", pair_reading(sides[0], sides[1]))
print("  sides (0,2):", pair_reading(sides[0], sides[2]))
print("  sides (1,2):", pair_reading(sides[1], sides[2]), " <- two incompatible standings (+ and -) from one junction")
print("the pairwise instrument A12.standing on the whole 3-sided record:")
try:
    print("  result:", A12.standing(sides))
except Exception as e:
    print("  REJECTED:", type(e).__name__, "-", e)
print("Def 5.7's multi-sided clause via A15.ms_standing (strictest reading, positive precedence):", A15.ms_standing(sides))
both = ((1, -1), (-1, 1))
print("pair sigma presenting both orientations", both, "-> A12.standing:", A12.standing(both), "(Def 5.7 precedence: positive first)")
