import sys
sys.path.insert(0, sys.argv[1])
import A14_ordering_key as A14
ms = ((0, 1), (0, 1), (0, 0))   # three-sided junction, as declared for K7/J13 in the Spine
body = A14.Body(2, 0, 0, [ms])
P = A14.Population([body])
print("A14 k_j reading (side count):", A14.k_j(ms))
print("A14 B for the body (6N - k_j, side-count reading):", body.B())
print("§11.3 definition's B if the junction's consumed-port count is 4 (one side consuming two ports):", 6*2 - 4)
print("K(P) computed without exception:", A14.key_KB(P))
print("tick carries the multi-sided junction unchanged:", P.tick().bodies[0].sigmas == (ms,))
print("Res (multi-sided junction presents no admissible index):", P.resolved())
print("A14 k_j docstring disclosure: 'A junction consuming more than one port at a side (§11.2, clause (ii)) is outside this script's domain; no population constructed here declares one.'")
