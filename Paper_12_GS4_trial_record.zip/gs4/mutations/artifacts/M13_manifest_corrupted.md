| File | SHA-256 |
|---|---|
| `packet/Paper_12_v4.md` | `fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150` |
| `packet/protocol_examiner_extract.md` | `f6e5cfe7816244af3746e9913e264aad285d9c475a28136d0517787a7413dec1` |
| `packet/paper2_section11.txt` | `ad4c0e3d4adb9c21d6c181109a3f4836ca33a40a5535ce465c9170e147884e4e` |
| `packet/paper9.txt` | `0efe9cdc6ad3e29d824d98d091266dcfc3d98eab422cfe30ddc67d2ee25bf8f6` |
| `packet/paper10.txt` | `f4b1372f0f6e2b506dac95b7b80a65694a75fc533eab9ea304bdc92eafb6aa82` |
| `packet/paper_11_v69.md` | `f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb` |
| `packet/paper_11_5_v26.md` | `9225cd8d44bff92f785b3344fa327f18f04ab2cd0c81aca4b1df914bb9179e60` |
| `packet/sample_selection.txt` | `588b7e8766a31545c29b362ef200bb55981921c5b60dc43d395967acfe51e766` |
| `packet/blind_verification.txt` | `97424de9a2d51d2a0e7ad043383ba5e024ed0235a328a208b70fd9c1c19e9dcb` |
| `packet/roleC_only/blind_claims.md` | `4d56e0878770a5aae02b14d588d7b825fdfbc75c9ac4677081f12d5283da7f2f` |
