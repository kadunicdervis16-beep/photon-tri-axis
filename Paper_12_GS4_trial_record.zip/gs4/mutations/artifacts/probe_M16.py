import sys
sys.path.insert(0, sys.argv[1])
import A12_joint_counts as A12
import A15_spine as A15
names = [b["name"] for b in A15.SMALL["bodies"]]
sigma0 = tuple(tuple(j["sigma"] for j in b["junctions"] if j["kind"] == "pair") for b in A15.SMALL["bodies"])
d = A12.make_pop(names, sigma0)
print("standings by tick (S1,S2,S3):", [d["stnd"][t] for t in range(5)])
spec = ((("body", 0), "+"), (("body", 2), "-"))
for W in [(0, 3), (0, 2), (0, 4), (1, 4)]:
    print(f"J_{W}(S1 = +, S3 = -) =", A12.joint_count_members(d, W, spec))
spec2 = ((("body", 0), "+", 0), (("body", 2), "0", 1))
for W in [(0, 3), (1, 4)]:
    print(f"J_{W}(S1 = + at d=0, S3 = 0 at d=+1) =", A12.joint_count_members(d, W, spec2))
print("the only joint event stands at tick 0; shifting the window to (1, 4) moves it across the boundary and the count falls 1 -> 0: Def 5.8's declared-horizon rule decides, with no partial credit")
