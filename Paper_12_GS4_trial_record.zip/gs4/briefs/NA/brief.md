# EXAMINER BRIEF -- ARM N, ROLE A

GS-4 Gold v1.0 (house execution, two-arm isolated-context trial).


COORDINATOR FURNITURE -- YOUR WORKING RULES (procedural only)
- The frozen paper is ./packet/Paper_12_v4.md, SHA-256 fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150.
  Verify that hash yourself before relying on the file.
- You may read ONLY: your brief, the files in ./packet/ (the frozen
  paper, protocol_examiner_extract.md, paper2_section11.txt, paper9.txt,
  paper10.txt, paper_11_v69.md, paper_11_5_v26.md, sample_selection.txt),
  and your own submission directory. Role C additionally receives
  ./packet/roleC_only/blind_claims.md. Role D additionally uses its
  own clean work directory ./work/NA/ for extraction and runs.
- You may NOT open any other file on this machine, consult the web, or
  look for any other record of this paper or its history. The paper's own
  version history, inside the frozen paper, is part of your object.
- The twelve-claim sample is recorded in packet/sample_selection.txt.
- Write your submission only to the submission directory named in your
  tasking message.

## 1. What this trial is and is not (honesty label — read first)

**What it is.** A reconstruction and adversarial acceptance trial of Paper 12
executed in **two arms** by examiner agents whose *context* is independent
of the house audit trail:

- **Arm N (neutral):** four examiner roles (A–D, §6) working exactly as an
  ordinary independent-context audit.
- **Arm H (hostile):** the same four roles under a disclosed hostility
  overlay (§3) — a gatekeeper team chartered, in writing, to make the paper
  fail.

Both arms work from one frozen paper and one identical packet (§4, §5),
under one isolation regime (§2), and every finding from either arm is judged
by one blinded adjudicator under one evidence standard (§9, §10). The
trial's full record is a publishable package (§13).

**What it is not.**

- It is **not independent human review.** The proposal's decisive stage
  called for two independent human examiners. **The author has declined the
  human stage** (ruling, 2026-10-31: "We don't need a human. We need
  independent team"). That decision is recorded here as the author's, not
  treated as an oversight and not smoothed over: this trial's strength is
  the strength of information-isolated agent teams under evidence rules,
  and no more.
- All examiners are spawned agents of the same model family as the
  authoring and verifying environment. Context isolation removes access to
  the house's kits, verdicts, and summaries; it does not remove blind spots
  a model family may share, and it does not give any examiner epistemic
  virginity (trained familiarity with general mathematics or physics is not
  controlled and cannot be).
- It must **never be reported as external validation**, in the paper, in
  any package, or in any summary. The correct label, everywhere, is:
  *"GS-4 Gold v1.0 (house execution, two-arm isolated-context trial)."*
- **Gate 8 applies unchanged** (§14): passing Gates 1–7 establishes an
  internal-consistency and reproducibility result over the tested claims
  and domains. It is not physical validation of the framework, and no
  native or computational pass may be presented as experimental
  confirmation.
- This trial awards **no badge by itself.** Examiners propose; the blinded
  adjudicator assigns (§10); the author rules on repairs (§16).

---


## 6. Role charters and attack assignments

Attacks GS4-A…J are assigned as follows, identically in both arms. Each
examiner's charter states its required work, its prohibitions, and its
deliverable. An examiner that cannot perform a required step records the
process status (§9.4) and the reason; it never substitutes a
plausible-looking result. Arm H charters are these charters **plus the
overlay (§3)** — the overlay changes stance, never the required work, the
evidence standard, or the deliverable format.


### Role A — Native Reconstructor (GS4-A lead, GS4-G support)

Required: (1) reconstruct the aggregate tick and its declared domain;
(2) reconstruct the K ordering and its deciding components; (3) reconstruct
Res and distinguish it from the three standings and from any similarly
named predicate; (4) reconstruct the census, flow, and joint-count
definitions; (5) reconstruct at least one end-to-end Spine example from
declared records to final output; (6) for every step, classify it as
definition, finite calculation, proof, inherited premise, or author
identification.
Prohibited: importing a physical interpretation to settle a native
ambiguity; treating a script's output as proof of a general theorem;
silently replacing a declared definition with a more familiar one.
Deliverable: reconstruction workbook with per-step classification.


7.3 **Ranking within a pool (dependency centrality).** The packaging script
parses Appendix B and the claim lists and builds the stated-dependency
graph: an edge X→Y exists when claim X's registry row or claim-list entry
names claim Y, a falsification condition (C23–C33), a receipt, or a declared
premise in its dependency/pricing text. A claim's centrality score is
(inbound edges from other claims) + (inbound edges from falsification
conditions) + (outbound edges to source-paper premises). Higher score
ranks first; ties break by claim ID, ascending lexicographic order. The
script, its parsed edge list, every score, and the resulting sample are
saved to `gs4/packet/sample_selection.txt` and hashed into the freeze
record. The sample is final once the freeze record is written; a selection
dispute is a spec defect (SD-n), recorded, never silently re-picked.


## 9. Evidence standard, verdict rules, and the five categories

### 9.1 Attack record (required fields, every attack)

Attack ID and target claim; exact target text and location (section and
line in the frozen paper); claim domain and required property; source files
used with verified hashes; method and complete test space; the executable
program and inputs wherever computation is involved; output and logs; for
a proposed BROKE, the independent second route (§9.3); a five-part coverage
map — **(1) native domain, (2) verified domain, (3) the map between them,
(4) what the map preserves, (5) what stays outside the check**; the
finding's category under §9.5 (self-classified by the filing examiner,
verified by the adjudicator); proposed badge and reason. No count is
accepted without its producing artifact; no hash without independent
recomputation; no source is marked READ unless the examiner actually
inspected it; a missing source is a coverage boundary, not evidence against
a claim, unless the paper asserts the source is present.

### 9.2 Verdicts (claim status)

- **HELD** — independently reconstructed or reproduced over the stated
  domain; no counterexample found within that verified domain. Never means
  physically true.
- **BROKE** — a reproducible witness or logical contradiction against the
  claim as written, all preconditions satisfied, second route confirming.
- **LIMIT** — evidence supports only a proper subset of the stated domain,
  or the claim cannot be decided at the available scope; the exact boundary
  is named.
- **OUTSIDE** — the tested property is not asserted by the target claim.

Verdicts are never summed into a score or percentage; one broken
load-bearing claim is not cancelled by any number of held bookkeeping
checks.

### 9.3 Second-route rule

Every BROKE requires reproduction by a route independent of the first: a
different implementation, an analytic derivation, or a direct textual
witness pair (home vs registry, script block vs script block) verifiable
by inspection. The adjudicator checks the second route exists and is
genuinely independent before sustaining; a single-route BROKE is
downgraded to LIMIT with the reason recorded.

### 9.4 Process status (kept separate from claim status, always)

`READ / NOT READ`, `RUN / NOT RUN`, `REPRODUCED / NOT REPRODUCED`,
`SOURCE-VERIFIED / SOURCE-REPORTED`, `SEALED / UNSEALED`. NOT RUN is a
process status, never a badge. No report may let a process word do a
verdict's work or a verdict do a process word's work. **Neither an
examiner's confidence nor an arm's identity is evidence** (§10.1).

### 9.5 The framework-translation classification — five categories, never merged

*(Refinement from GPT-6's review of the two-arm design, adopted by the
author.)* Every finding filed by either arm — every Arm H objection and,
for symmetry, every Arm N finding — must be classified into **exactly one**
of five categories. The categories must not be merged, averaged, or
blended:

- **(A)** A genuine contradiction under MSDS's own rules.
- **(B)** A missing derivation required by a claim.
- **(C)** An unestablished bridge from the discrete mathematics to physical
  measurement.
- **(D)** A disagreement over mathematical foundations or ontology.
- **(E)** A question the paper explicitly leaves open.

**Badge mapping (binding):**

| Category | Can it sustain a BROKE against a claim as written? | Disposition |
|---|---|---|
| A | **Yes** — with witness and second route (§9.3) | Defect; author's list |
| B | **Yes** — where the claim asserts the establishment the missing derivation was required for | Defect; author's list |
| C | **No** | Bridge verdict: LIMIT or OUTSIDE, per the target claim's own Stage discipline (a native claim that asserts no bridge cannot be broken by the bridge's absence; a Stage P claim that asserts one is judged by what it asserts) |
| D | **No — never a defect** | Recorded as a framework disagreement |
| E | **No — never a defect** | Recorded as an open question the paper itself declares |

The filing examiner self-classifies; **the adjudicator verifies the
category as part of adjudication** (§10.3). A mis-categorized finding is
re-categorized **in the open**: the adjudication record prints the original
category, the corrected category, and the reason. Category verification is
not a courtesy check — most hostile-arm volume is expected to arrive as
category D in substance, and the record must show the sorting, finding by
finding.

---


## 14. Acceptance gates

Assessed by the adjudicator from the anonymized evidence where a gate
concerns findings, and completed after unblinding where a gate concerns
attribution (Gate 3's discrepancy record, the charter-integrity input to
Gate 4). A gate is marked PASS, FAIL, or NOT DECIDED (with the deciding
evidence named) — never inferred from another gate.

| Gate | Test | Evidence owned by |
|---|---|---|
| 1 — Identity | Frozen release, hashes, source versions, environment independently verified | Role D (both arms) |
| 2 — Reconstruction | Native definitions and selected load-bearing derivations reconstructed without private author knowledge | Roles A, B (both arms) |
| 3 — Badge honesty | Blind classifications match the paper's evidence, or every discrepancy is resolved and recorded | Role C (both arms) + adjudicator |
| 4 — Computational independence | Selected machine results reproduce through second implementations (including the divergent-reading K comparison, §6.2); mutation tests show the controls can fail when expected | Role D (both arms) + mutation log |
| 5 — Dependency integrity | Sampled claim graphs have no omitted load-bearing dependencies; no claim outranks its weakest dependency | Role C (GS4-C, both arms) |
| 6 — Change integrity | Sampled changes trace old text → new text, with corresponding tests and dispositions | Role C (GS4-H, both arms) |
| 7 — Falsification reach | An independent-context reader can identify a real falsifier for every selected Level A claim, or the paper explicitly names the boundary where none is available | Roles A, C (both arms) |
| 8 — Physical separation | No native or computational pass is presented as experimental confirmation without an independent physical bridge and a discriminating observation | Roles A (GS4-I/J, both arms) + adjudicator |

Per-arm readings are recorded where a gate's evidence differs by arm; the
joint assessment closes the gate table. Passing Gates 1–7 with Gate 8 open
is the expected maximum outcome of this trial and is reported as exactly
that.

---



COORDINATOR FURNITURE -- DELIVERABLE FORMAT (procedural only)
Your submission is a single Markdown file, SUBMISSION.md, in your
submission directory, plus any witness artifacts (code, outputs) in the
same directory. File every finding as a discrete block in exactly this
shape (the routing step extracts blocks mechanically; argument text is
never edited downstream):

### FINDING <n> -- <short title>
- Target claim: <claim ID and section>
- Exact target text: <quoted, with line numbers in the frozen paper>
- Domain and required property: <...>
- Sources used: <packet files, with the hashes you recomputed>
- Method and complete test space: <...>
- Witness / artifacts: <file names in your submission directory, or the textual witness pair>
- Coverage map: (1) native domain: ... (2) verified domain: ... (3) map between them: ... (4) what the map preserves: ... (5) what stays outside: ...
- Category (self-classified, spec section 9.5): <A|B|C|D|E>
- Proposed badge: <HELD|BROKE|LIMIT|OUTSIDE>
- Reason: <...>

Material that is not a finding (workbooks, derivations, graphs, run logs,
tables) goes in clearly headed sections of SUBMISSION.md outside the
FINDING blocks. Close the submission with a PROCESS STATUS section using
only the process vocabulary of spec section 9.4 (READ / NOT READ,
RUN / NOT RUN, REPRODUCED / NOT REPRODUCED, SOURCE-VERIFIED /
SOURCE-REPORTED, per item). Your last act: compute the SHA-256 of every
file you wrote in your submission directory and list them in your final
reply to the coordinator. Do not write anywhere else.

