# MUTATION RUNNER BRIEF — GS-4 Gold v1.0 (spec §8)

You are the mutation runner for the GS-4 Gold v1.0 trial. You are not an
examiner: you propose no badges and file no findings. Your complete
protocol is spec §8, printed verbatim below, plus this furniture.

FURNITURE (procedural only):
- Working area: ~/workspace/your_files/paper_12_draft/gs4/mutations/ —
  build the baseline working copy under mutations/tree/ from the frozen
  paper (~/workspace/your_files/paper_12_draft/gs4/frozen/Paper_12_v4.md,
  SHA-256 fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
  and the scripts extracted from its Appendix C listings. Never mutate
  the frozen copy or the packet copy.
- For EACH mutation M1–M24: start from a FRESH copy of the baseline,
  apply exactly the mutation §8.2 describes (record the exact diff —
  unified diff or precise before/after excerpts with line numbers), run
  the full suite (run_all.py) plus any specific check named in the
  expectation, and record: mutation ID, diff, controls run, observed
  behaviour (with the relevant output lines), expectation met / not met /
  boundary-confirmed.
- Where a mutation is an input-level probe rather than a text edit
  (M8, M9, M10, M14, M16, M22), construct the input exactly as §8.2
  describes, run it against the relevant script(s) from the baseline
  extraction, and record the observed behaviour and outputs.
- M13 mechanical form: copy the freeze record's packet manifest table,
  corrupt one file hash in the copy, then run a hash-verification pass
  comparing the corrupted manifest against the actual packet files;
  record whether the mismatch is detected before any examiner run would
  proceed.
- M5 fixture: the coordinator will supply mutations/stale_listing_fixture.py
  (a previous version of one embedded script). Replace that script's
  embedded listing block in the working-copy paper with the fixture's
  text, then run the suite's listing-identity check (A.9) against the
  mutated paper.
- M17 mechanical form: in a fresh baseline copy, edit one script so one
  of its checks tests a string's presence instead of its computed
  quantity, keeping the script's printed output text identical; run that
  script and record that the suite still passes it (the expectation is
  that no script control fires; the control is an examiner).
- Write the log to mutations/RUN_LOG.md in the §8.3 record format, with a
  summary table (ID / expectation / observed / verdict) at its head.
  Include the exact commands run. Your final reply lists the SHA-256 of
  RUN_LOG.md and of any artifact files you created.


---

## 8. Mutation battery (GS4-E) — pre-registered

### 8.1 Rules

Mutations are applied **only to a working copy** (`gs4/mutations/tree/`) of
the frozen paper and its extracted scripts; the frozen copy is never
mutated. The list below is complete and frozen with this spec: no mutation
may be added, dropped, or widened after the freeze. Each entry names its
expected catching control **in advance**; where no control is expected,
that absence is declared a scope boundary **before** execution. A mutation
whose expected control does not fire is a finding; a mutation in the
declared no-control class that no control fires on is a confirmed scope
boundary, not a finding and not a pass. The battery is run **once**; its
log is available to the adjudicator for both arms' relevant attacks (§10).

### 8.2 The mutations

| ID | Mutation (applied to the working copy) | Expected catching control |
|---|---|---|
| M1 | In A.15's INPUT_PROVENANCE, relabel one paper-defined binding as cited-paper (the Y2 shape) | F.49-style provenance check if wired in the suite; else **no control expected — declared scope boundary** (provenance-class accuracy of A.15 rests on audit, recorded before execution) |
| M2 | In a hybrid claim's Appendix B row, move one prose-carried general clause from the AUTHOR leg to the MACHINE leg (the L8.3 shape) | H.1 registry-vs-home check — expected to catch only if the home/row badge strings differ; for a pure split move with badge string unchanged: **no control expected — declared scope boundary** |
| M3 | Delete one Appendix B registry row while its claim remains in the claim list | H.1 (claim/registry bijection) |
| M4 | Alter one numeric value in the Appendix F fixture, leaving all expected outputs unchanged | A.15 check comparing fixture to both computation paths |
| M5 | Replace one embedded script listing with its previous round's version (stale listing) | A.9 (listing byte-identity / manifest) |
| M6 | Edit a claim's scope sentence in the paper body and make no version-history entry for it | **No control expected — declared scope boundary** (change-log completeness is Role C's GS4-H audit, not a script control) |
| M7 | Strengthen one claim's badge in its claim-list entry only, above its weakest dependency | H.1 (registry-vs-home badge reproduction) |
| M8 | Feed an empty population declaration to the Spine generator that normally supplies nonempty data | A.15's own input handling — expected behaviour: explicit rejection or a stated empty-case result; a crash or a silent nonempty assumption is the finding |
| M9 | Construct two populations whose CenSig values stand in a proper-prefix relation and compare them under K | A.14's comparison plus §11.3's stated prefix convention — expected: the convention decides, no exception |
| M10 | Relabel every body in a Spine population (permuted names), leaving records unchanged | A.15/A.14 invariance checks — expected: identical K components and census ratios |
| M11 | Shift one joint-count window so an offset straddles the window split | A.12 / Proposition 5.9(ii)'s stated horizon reading — expected: counts as the proposition's stated form requires, no double count |
| M12 | Introduce a multi-sided junction whose consumed-port count differs from its side count, at the C33 boundary | A.14's stated domain handling — expected: handled as outside A.14's domain per its disclosure, with C33's scoped text not firing |
| M13 | Corrupt one source hash in the packet manifest copy used by Role D | Role D's Gate 1 hash verification — expected: mismatch detected before any run |
| M14 | Duplicate one population member (same name, same record, twice) in a Spine declaration | A.15/A.12 declaration validation — expected: rejection or a stated duplicate rule; silent double-counting is the finding |
| M15 | Remove one dependency edge from a sampled claim's registry row (text edited, graph edge gone) | **No control expected — declared scope boundary** (dependency completeness is Role C's GS4-C audit) |
| M16 | Change one tick window in a §5 joint-count example so an event crosses the window boundary mid-count | A.12 — expected: the declared-horizon rule decides the count |
| M17 | In one script, make a check test a proxy (string presence) instead of its claim's computed quantity, keeping its output text identical | Role D's content-vs-shape determination (Role D item 6) — **no script control expected; the control is the examiner** |
| M18 | Insert a Stage P bridge word into a native Stage N definition sentence | FW.1 firewall sweep |
| M19 | Omit one declared assumption's name at one load-bearing use site (body text edited) | **No control expected — declared scope boundary** (Role C item 5 audit) |
| M20 | Reorder two deciding components of K in A.14's key tuple | A.14's representative/order checks — expected: failures on the representative comparisons |
| M21 | Change one sign in Table 5.1's received sign facts as printed in §11.3's representatives | A.14 / §11.3 representative checks — expected: at least one representative comparison fails |
| M22 | Give one junction two incompatible standings via a multi-sided record read through the pairwise rule | A.12/Def 5.7 legality checks — expected: rejection as an illegal record, or a stated precedence rule decides |
| M23 | Truncate one verbatim quotation in §11.3 mid-phrase, leaving its G.1 punctuation pattern plausible | G.1 quote-integrity check |
| M24 | Replace the §6.1 bonding-mode premise's receipt wording with a citation wording ("Paper 2 proves…") at one consumption site | FW.1/G.1-class wording checks if the shape is swept; else **no control expected — declared scope boundary** (Role C audit) |

### 8.3 Mutation run protocol — gold addition: split witnessing

The mutation runner applies each mutation to a fresh copy of the working
tree, runs the full suite plus any examiner-specified check named in the
expectation, and records: mutation ID, exact diff, controls run, observed
behaviour, expectation met / not met / boundary-confirmed. **Witnessing is
split across the arms** (gold addition): Role D of Arm N witnesses M1–M12
and Role D of Arm H witnesses M13–M24, each countersigning the half it
witnessed, after its own arm's submissions are sealed (witnessing is not
examination; a witness sees the mutation log for its half only, never the
other arm's submissions). Splitting the witness duty means no single arm's
examiner vouches for the whole battery, and a witness dispute is itself
recorded. The log seals to `gs4/mutations/RUN_LOG.md` (with diffs and both
countersignatures) before adjudication. The runner proposes no badges.

---

