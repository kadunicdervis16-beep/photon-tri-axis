# MUTATION RUNNER BRIEF — GS-4 Gold v1.0 (spec §8)

You are the mutation runner for the GS-4 Gold v1.0 trial. You are not an
examiner: you propose no badges and file no findings. Your complete
protocol is spec §8, printed verbatim below, plus this furniture.

FURNITURE (procedural only):
- Working area: ~/workspace/your_files/paper_12_draft/gs4/mutations/ —
  build the baseline working copy under mutations/tree/ from the frozen
  paper (~/workspace/your_files/paper_12_draft/gs4/frozen/Paper_12_v4.md,
  SHA-256 fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150)
  and the scripts extracted from its Appendix C listings. Never mutate
  the frozen copy or the packet copy.
- For EACH mutation M1–M24: start from a FRESH copy of the baseline,
  apply exactly the mutation §8.2 describes (record the exact diff —
  unified diff or precise before/after excerpts with line numbers), run
  the full suite (run_all.py) plus any specific check named in the
  expectation, and record: mutation ID, diff, controls run, observed
  behaviour (with the relevant output lines), expectation met / not met /
  boundary-confirmed.
- Where a mutation is an input-level probe rather than a text edit
  (M8, M9, M10, M14, M16, M22), construct the input exactly as §8.2
  describes, run it against the relevant script(s) from the baseline
  extraction, and record the observed behaviour and outputs.
- M13 mechanical form: copy the freeze record's packet manifest table,
  corrupt one file hash in the copy, then run a hash-verification pass
  comparing the corrupted manifest against the actual packet files;
  record whether the mismatch is detected before any examiner run would
  proceed.
- M5 fixture: the coordinator will supply mutations/stale_listing_fixture.py
  (a previous version of one embedded script). Replace that script's
  embedded listing block in the working-copy paper with the fixture's
  text, then run the suite's listing-identity check (A.9) against the
  mutated paper.
- M17 mechanical form: in a fresh baseline copy, edit one script so one
  of its checks tests a string's presence instead of its computed
  quantity, keeping the script's printed output text identical; run that
  script and record that the suite still passes it (the expectation is
  that no script control fires; the control is an examiner).
- Write the log to mutations/RUN_LOG.md in the §8.3 record format, with a
  summary table (ID / expectation / observed / verdict) at its head.
  Include the exact commands run. Your final reply lists the SHA-256 of
  RUN_LOG.md and of any artifact files you created.

