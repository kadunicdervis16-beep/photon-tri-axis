import subprocess, sys, time, pathlib, json
root = pathlib.Path.home()/"workspace/your_files/paper_12_draft/gs4/work/ND"
scripts = ["A1_counting.py","A2_parallel_tick.py","A3_orbits.py","A4_capability.py","A5_concentration.py","A6_budgets.py","A7_exhibit.py","A8_molecule.py","A9_listings.py","A10_two_level.py","A11_mode_exhibit.py","A12_joint_counts.py","A13_provenance.py","A14_ordering_key.py","A15_spine.py","FW1_firewall.py","G1_quotes.py","H1_registry.py"]
outdir = root/"individual"; outdir.mkdir(exist_ok=True)
summary=[]
for s in scripts:
    t0=time.time()
    p=subprocess.run([sys.executable, str(root/"scripts"/s)], capture_output=True, text=True, cwd=root)
    el=time.time()-t0
    (outdir/(s+".stdout.txt")).write_text(p.stdout)
    (outdir/(s+".stderr.txt")).write_text(p.stderr)
    verdict = next((ln.strip() for ln in p.stdout.splitlines() if "VERDICT:" in ln), "")
    summary.append({"script":s,"exit":p.returncode,"elapsed_s":round(el,3),"stdout_bytes":len(p.stdout.encode()),"stderr_bytes":len(p.stderr.encode()),"verdict_first120":verdict[:120]})
    print(s, p.returncode, round(el,3), "s")
(outdir/"summary.json").write_text(json.dumps(summary,indent=1))
print(json.dumps(summary,indent=1))
