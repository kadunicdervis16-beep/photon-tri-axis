#!/usr/bin/env python3
"""A.15 — The Spine exhibits (Paper 12 Appendix F).

Machine companion to Appendix F: three declared populations
(E-SMALL, E-MID, E-LARGE) carried through every station of the
paper on single numerical threads — census (§3), aggregate tick
(§4), frequencies (§5), capability (§6), population temperature
(§7), assignment counts and the entropy bridge's operands (§8),
equilibrium verdicts (§§8-9). This script recomputes every number
Appendix F prints, from the populations' declarations alone, by
two independent implementations, and compares both against the
printed fixture. It is the suite's fifteenth script in run
order. Appendix F registers no claims; this script is a
suite-level exhibit check, named at Appendix F and in Appendix
B's script key.

THE TWO IMPLEMENTATIONS. The COMPUTE path reuses the paper's
own listings for the quantities they compute — A.12 (T, the
parallel trajectory, Definition 5.7 standings, Definition 5.8
joint counts), A.4 (the presented-count profile and Cap under
its two licensed outcome rules over its declared taxonomy), A.5
(assignment counts via its multinomial) — imported from this
script's own directory, the suite layout of Appendix C; if they
are absent the script fails loudly, with no fallback. The
VERIFY path imports nothing but the declarations embedded
below: it re-implements the tick, the standings, the census,
the joint counts, the capability construction (its two
outcome rules carried as copies of A.4's), the reconcile
density and the assignment counts from the paper's
definitions, and
compares its values field by field against the compute path's.
The second path excludes a bug in either implementation. The
two paths share the declarations and the definitional readings
fixed in the declarations' header, so a misreading at that
level would pass both paths — that residue is named in the
coverage map below, not claimed away.

COVERAGE MAP (the house discipline: the check never outruns
its verified domain).
  NATIVE DOMAIN: the three populations as Appendix F declares
    them, and every number the appendix prints about them.
  VERIFIED DOMAIN: every field of the exhibits' number record
    — census vectors, classes and totals by both routes; the
    tau_agg series and tick-1 before/after states; standings
    per tick, records and frequencies; flow counts at every
    tick transition; the exhibits' joint counts with their
    marginalization and window-additivity checks; capability
    profiles and per-profile Cap cardinalities under both of
    A.4's rules, with factorization asserted at every shared
    profile; the reconcile tables, budget lines, R and D and
    the local densities; the Omega threads (visited records,
    the maximum over all records, the phi threads, the bridge
    values ln Omega rounded as printed); and the (E1)/(E2)
    verdict at every exhibited tick. Check (5) covers the
    appendix's prose numbers outside the fixture fields: the
    all-records counts (10, 28, 91) and record totals (3^n),
    recomputed by enumerating every standings record; the
    printed net flows, recomputed as consecutive tally
    differences; and the encounter-taxonomy denominator (15),
    read from A.4's declared taxonomy — each tied to the
    appendix's text by the transcription anchors of check (4).
    The compute path runs
    its internal assertion battery as it goes (the count is
    printed); the verify path re-derives and compares every
    field (the count is printed); both are compared against
    the FIXTURE below, which is the exhibits' printed number
    record — the values Appendix F's text carries, bound
    against the appendix's own span in the paper by check (4)
    when the paper file is present: check (4)'s anchor set is
    generated from the fixture and the declarations, one
    anchor per printed field rendered in the appendix's own
    print forms, so the printed text is tied to the fixture
    field by field rather than at sampled spots.
  PRINTED-FIELD BINDING MAP (check (4); field class ->
    mechanism): declarations (body N values, junction sigmas
    and presented records) — generated anchors; contact
    declarations — generated anchors in the appendix's print
    forms; census vectors, classes, totals and the
    direct-route identity — generated anchors; the tau_agg
    series, acting lists and counts, the tick delta, the
    carried multi-sided contributions and the rest-value
    decomposition — generated anchors; standings, tallies,
    frequencies, flow counts and net flows — generated
    anchors; joint counts and their frequency tail —
    generated anchors, with the E-SMALL marginalization and
    window-split values carried by retained anchors;
    capability presented tuples, profile lists, per-profile
    cardinalities and the multi-sided carrier's entry
    contributions — generated anchors; bookings, budget
    arithmetic, R, D (including its mean restatement) and
    the local densities (the E-LARGE range form) —
    generated anchors; the visited records with their Omega
    values, the maxima and argmaxima, the phi threads and
    the printed ln Omega bridge values — generated anchors;
    the all-records counts and totals — check (5)'s
    enumeration plus generated anchors; word-form counts
    (bodies, window body-ticks, contact body-ticks) —
    generated anchors rendering the computed counts as
    words; the verdict sentences — retained anchors, their
    inputs (records, Omega values, stationarity) bound by
    the generated anchors and recomputed by checks (2) and
    (3). What no anchor binds: the appendix's framing
    numerals (section and equation references, the cited
    budget form, tick indices in prose) and qualitative
    restatements (orientation, sidedness, pair-ness) of
    values bound at their primary printings, which carry no
    exhibit values of their own.
  THE MAP: declarations -> stations -> printed numbers. Each
    station reads the previous station's computed objects; no
    intermediate is hand-copied in either path.
  OUTSIDE THE CHECK, stated plainly: the declarations
    themselves (the exhibits' data — class: declared exhibit
    data, as at §3.5 and Appendix D); A.4's two outcome rules'
    standing as licensed representatives (A.4's own coverage);
    the multi-sided junctions' standing, which the
    declarations make neutral under every reading of
    Definition 5.7's multi-sided clause and which the compute
    path checks under the strictest reading; the bridge
    sentence itself (Stage P, §8.4) — this script computes its
    operand ln Omega, never the bridge; and the open joint of
    §9.6, which the exhibits end at and do not touch. Also
    outside: the definitional readings fixed in the declarations'
    header — the multi-sided standing reading, the capability
    rule copies, the declared k values — which both paths and
    the fixture's build chain share; the check is implementation-
    independent, not interpretation-independent.

INPUT_PROVENANCE:
  - The three population declarations (bodies, junctions,
    contact budget inputs, joint-count specifications):
    class=declared exhibit data (Appendix F's declarations;
    the Spine dossier's population file, embedded verbatim
    below).
  - T: class=cited-paper via the suite's own A.12 (Paper 11
    §7.5, as restated in Paper 12 §4) — imported, not
    re-derived, in the compute path; re-implemented from
    the definition in the verify path.
  - Standings and joint counts: class=paper-defined via the
    suite's own A.12 (Paper 12 Definitions 5.7-5.8) — the
    pairwise standings and the joint counts imported, not
    re-derived, in the compute path; re-implemented from
    the definitions in the verify path.
  - The multi-sided standing reading, the glue-route joint
    count over it, and the body aggregation's precedence
    implementation: class=paper-defined (Definition 5.7's
    own clauses — the multi-sided clause under its strictest
    reading, a reading fixed in the declarations' header
    and named in the coverage map above among the shared
    readings outside the check; A.12 carries no multi-sided
    member).
  - The capability profile (Cap under §6's construction):
    class=paper-defined via A.4 (Paper 12 §6's construction,
    as A.4's capability implements it: a body's presented-
    count profile read against the encounter taxonomy under
    an outcome rule) — imported, not re-derived, in the
    compute path; re-implemented from §6's definitions in
    the verify path.
  - Outcome rules 1 and 2: class=arbitrary-representative
    via A.4 (its declared controls: two disagreeing members
    of the profile-factoring class Paper 11 §8.6 licenses;
    the check does not privilege either). In the verify
    path they stand as copies of A.4's rules — the shared
    reading the coverage map above names — not as an
    independent re-derivation.
  - The encounter taxonomy (the kinds with e+ + e- <= 4,
    15 in all): class=control via A.4 (its declared finite
    test set standing in for §8's taxonomy); rebuilt
    identically in the verify path.
  - The roles {responder, initiator, spin-presenter}:
    responder and initiator class=cited-paper via A.4
    (Paper 11's relational active/passive roles read off
    the encounter); spin-presenter class=paper-defined
    via A.4 (Paper 12 §6.3's worked case).
  - Assignment counts: class=paper-defined via A.5's
    multinomial (Paper 12 §§8.2-8.4); re-implemented in
    the verify path.
  - The station definitions implemented locally in both
    paths: the aggregate tick (§4), D's form (§7.3), the
    (E1)/(E2) verdict clauses (§§9.2-9.3): class=paper-
    defined (Paper 12's own definitions at the sections
    named). The census form B = 6N - sum(k_j):
    class=cited-paper (Paper 11 §4.1, as A.1 classes it;
    restated at §3.1).
  - The FIXTURE (the printed number record): class=paper-
    defined (Appendix F's printed values, generated by the
    exhibits' build-time chain and embedded here as the
    oracle both paths are compared against). Check (5)'s
    printed all-records counts and net-flow values stand
    under the same class (Appendix F's printed values,
    carried as literals in main()).
  - The ANCHORS binding (the transcription anchors of
    check (4)): class=paper-defined (Appendix F's printed
    strings). At round 8 the set is generated: one anchor
    per printed field, rendered from the FIXTURE and the
    declarations in the appendix's own print forms by the
    generator below — superseding the round-7 hand-carried
    literals, all of which (the E-MID net-flow line, the
    twelve E-LARGE contact-declaration lines, the three
    E-LARGE capability-cardinality lines, the D values,
    the tau series, the maxima) are inside the generated
    set. Six prose-dressed values whose print form is a
    sentence rather than a field — the verdict sentences,
    the no-equilibrium sentence, the E-SMALL
    marginalization and window split — are carried as
    retained literal anchors. The values the anchors carry
    are the fixture's, verified by checks (2) and (3).
  - The reconcile budget form (100 = 3 + v2_contact + s2 +
    N_reconcile; r_b = 97 - v2_contact - s2): class=cited-
    paper (Paper 10 §2.2 eq. (2.4), via Paper 12 eq. (7.2)).
"""
import json
import math
import re
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import A12_joint_counts as A12          # noqa: E402
import A4_capability as A4              # noqa: E402
import A5_concentration as A5           # noqa: E402

FAILURES = []


def report(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(name)
    return ok


# ================================================================
# DECLARATIONS (the exhibits' data, verbatim; nothing computed)
# ================================================================
SMALL = {
    "id": "E-SMALL",
    "bodies": [
        {"name": "S1", "N": 2, "junctions": [
            {"id": "J1", "kind": "pair", "k": 2,
             "sigma": ((1, 0), (-1, 0))},
        ]},
        {"name": "S2", "N": 2, "junctions": [
            {"id": "J2", "kind": "pair", "k": 2,
             "sigma": ((0, 1), (0, 1))},
        ]},
        {"name": "S3", "N": 3, "junctions": [
            {"id": "J3", "kind": "pair", "k": 2,
             "sigma": ((-1, 0), (1, 0))},
            {"id": "J4", "kind": "pair", "k": 2,
             "sigma": ((0, 0), (0, 0))},
        ]},
    ],
    # contact budget inputs (v2_contact, s2) by tick; ticks 1..3
    "contact": {
        "S1": {1: (91, 5)},
        "S2": {1: (93, 3)},
        "S3": {2: (90, 4)},
    },
    "joint_specs": [
        # (label, specs for A.12 joint_count_members, window)
        ("J_W(S1 = +, S3 = -)", ((("body", 0), "+"), (("body", 2), "-")), (0, 3)),
        ("J_W(S1 = + at d=0, S3 = 0 at d=+1)",
         ((("body", 0), "+", 0), (("body", 2), "0", 1)), (0, 3)),
    ],
}

# ------------------------------------------------------------------ E-MID
# Six bodies, eight junctions: seven pairwise and one three-sided
# (K7, carried by M5, carried through). The middle: mixed standings,
# an orientation flip (K6), the Omega-maximal record (2,2,2) visited
# at tick 1 without rest there.
MID = {
    "id": "E-MID",
    "bodies": [
        {"name": "M1", "N": 2, "junctions": [
            {"id": "K1", "kind": "pair", "k": 2,
             "sigma": ((1, 1), (-1, -1))},
        ]},
        {"name": "M2", "N": 2, "junctions": [
            {"id": "K2", "kind": "pair", "k": 2,
             "sigma": ((1, 0), (-1, 0))},
        ]},
        {"name": "M3", "N": 3, "junctions": [
            {"id": "K3", "kind": "pair", "k": 2,
             "sigma": ((-1, -1), (1, 1))},
        ]},
        {"name": "M4", "N": 3, "junctions": [
            {"id": "K4", "kind": "pair", "k": 2,
             "sigma": ((-1, 1), (1, -1))},
            {"id": "K5", "kind": "pair", "k": 2,
             "sigma": ((0, 0), (1, 0))},
        ]},
        {"name": "M5", "N": 2, "junctions": [
            {"id": "K6", "kind": "pair", "k": 2,
             "sigma": ((1, -1), (-1, 1))},
            {"id": "K7", "kind": "ms", "k": 3,
             "sides": ((0, 1), (0, 1), (0, 0))},
        ]},
        {"name": "M6", "N": 1, "junctions": [
            {"id": "K8", "kind": "pair", "k": 2,
             "sigma": ((-1, 0), (1, 0))},
        ]},
    ],
    "contact": {
        "M1": {1: (84, 6), 2: (88, 5)},
        "M2": {1: (90, 3), 2: (86, 8), 3: (92, 4)},
        "M3": {1: (80, 9), 2: (83, 7), 3: (89, 6)},
        "M4": {1: (87, 5), 3: (90, 5)},
        "M5": {1: (85, 4), 2: (81, 10), 3: (88, 7)},
        "M6": {1: (94, 2), 2: (95, 1)},
    },
    "joint_specs": [
        ("J_W(M5 = -, M3 = -)", ((("body", 4), "-"), (("body", 2), "-")), (0, 3)),
        ("J_W(M1 = + at d=0, M5 = - at d=+1)",
         ((("body", 0), "+", 0), (("body", 4), "-", 1)), (0, 3)),
        ("J_W(junction K6 = -, M5 = -)",
         ((("junction", 4, 0), "-"), (("body", 4), "-")), (0, 3)),
    ],
}

# ---------------------------------------------------------------- E-LARGE
# Twelve bodies, thirteen junctions (twelve pairwise, one three-sided
# J13 carried by L12). The hot end: ten junctions act at tick 1,
# bookings at most body-ticks of the window.
LARGE = {
    "id": "E-LARGE",
    "bodies": [
        {"name": "L1", "N": 3, "junctions": [
            {"id": "J1", "kind": "pair", "k": 2,
             "sigma": ((1, 1), (-1, -1))}]},
        {"name": "L2", "N": 2, "junctions": [
            {"id": "J2", "kind": "pair", "k": 2,
             "sigma": ((1, 0), (-1, 0))}]},
        {"name": "L3", "N": 3, "junctions": [
            {"id": "J3", "kind": "pair", "k": 2,
             "sigma": ((-1, -1), (1, 1))}]},
        {"name": "L4", "N": 2, "junctions": [
            {"id": "J4", "kind": "pair", "k": 2,
             "sigma": ((-1, 0), (1, 0))}]},
        {"name": "L5", "N": 3, "junctions": [
            {"id": "J5", "kind": "pair", "k": 2,
             "sigma": ((1, -1), (-1, 1))}]},
        {"name": "L6", "N": 2, "junctions": [
            {"id": "J6", "kind": "pair", "k": 2,
             "sigma": ((0, 1), (0, -1))}]},
        {"name": "L7", "N": 3, "junctions": [
            {"id": "J7", "kind": "pair", "k": 2,
             "sigma": ((1, 1), (-1, 0))}]},
        {"name": "L8", "N": 2, "junctions": [
            {"id": "J8", "kind": "pair", "k": 2,
             "sigma": ((0, 0), (0, 0))}]},
        {"name": "L9", "N": 3, "junctions": [
            {"id": "J9", "kind": "pair", "k": 2,
             "sigma": ((-1, 1), (1, -1))}]},
        {"name": "L10", "N": 2, "junctions": [
            {"id": "J10", "kind": "pair", "k": 2,
             "sigma": ((1, 0), (0, 0))}]},
        {"name": "L11", "N": 3, "junctions": [
            {"id": "J11", "kind": "pair", "k": 2,
             "sigma": ((-1, -1), (1, 0))}]},
        {"name": "L12", "N": 2, "junctions": [
            {"id": "J12", "kind": "pair", "k": 2,
             "sigma": ((1, -1), (-1, -1))},
            {"id": "J13", "kind": "ms", "k": 3,
             "sides": ((0, 1), (0, 1), (0, 0))},
        ]},
    ],
    "contact": {
        "L1": {1: (38, 14), 2: (44, 18), 3: (52, 20)},
        "L2": {1: (47, 11), 2: (58, 16), 3: (63, 9)},
        "L3": {1: (35, 19), 2: (41, 22), 3: (55, 13)},
        "L4": {1: (60, 8), 2: (49, 21), 3: (67, 12)},
        "L5": {1: (33, 24), 2: (46, 15), 3: (51, 17)},
        "L6": {1: (56, 10), 2: (39, 23), 3: (62, 14)},
        "L7": {1: (43, 16), 2: (57, 19), 3: (48, 21)},
        "L8": {2: (71, 6), 3: (66, 15)},
        "L9": {1: (36, 20), 2: (45, 12), 3: (54, 18)},
        "L10": {1: (64, 13), 3: (59, 22)},
        "L11": {1: (40, 17), 2: (50, 11), 3: (61, 8)},
        "L12": {1: (42, 25), 2: (53, 9), 3: (68, 16)},
    },
    "joint_specs": [
        ("J_W(L5 = +, L9 = +)", ((("body", 4), "+"), (("body", 8), "+")), (0, 3)),
        ("J_W(L1 = + at d=0, L5 = - at d=+1)",
         ((("body", 0), "+", 0), (("body", 4), "-", 1)), (0, 3)),
        ("J_W(junction J13 = 0, L12 = +) [multi-sided member: glue route]",
         ((("msjunction", 11, 1), "0"), (("body", 11), "+")), (0, 3)),
    ],
}

POPULATIONS = [SMALL, MID, LARGE]
TRAJ_TICKS = [0, 1, 2, 3]     # states computed at these ticks
WINDOW = [1, 2, 3]            # reconcile window W (sec. 7)
JOINT_WINDOW = (0, 3)         # default window for joint counts (sec. 5)

import types as _types
P = _types.SimpleNamespace(
    SMALL=SMALL, MID=MID, LARGE=LARGE, POPULATIONS=POPULATIONS,
    TRAJ_TICKS=TRAJ_TICKS, WINDOW=WINDOW, JOINT_WINDOW=JOINT_WINDOW)

# ================================================================
# FIXTURE — the exhibits' printed number record (the oracle)
# ================================================================
FIXTURE = {'E-SMALL': {'id': 'E-SMALL', 'census': {'vectors': {'S1': [2, [2], 10], 'S2': [2, [2], 10], 'S3': [3, [2, 2], 14]}, 'classes': {'(2, (2,), 10)': 2, '(3, (2, 2), 14)': 1}, 'tot_N': 7, 'tot_B': 34}, 'tau': {'rows': [{'tick': 0, 'per_junction': {'J1': 2, 'J2': 2, 'J3': 2, 'J4': 0}, 'acting': ['J1', 'J3'], 'tau_agg': 6}, {'tick': 1, 'per_junction': {'J1': 0, 'J2': 2, 'J3': 0, 'J4': 0}, 'acting': [], 'tau_agg': 2}, {'tick': 2, 'per_junction': {'J1': 0, 'J2': 2, 'J3': 0, 'J4': 0}, 'acting': [], 'tau_agg': 2}, {'tick': 3, 'per_junction': {'J1': 0, 'J2': 2, 'J3': 0, 'J4': 0}, 'acting': [], 'tau_agg': 2}], 'tick1_before_after': {'J1': {'before': [[1, 0], [-1, 0]], 'after': [[0, 0], [0, 0]]}, 'J2': {'before': [[0, 1], [0, 1]], 'after': [[0, 1], [0, 1]]}, 'J3': {'before': [[-1, 0], [1, 0]], 'after': [[0, 0], [0, 0]]}, 'J4': {'before': [[0, 0], [0, 0]], 'after': [[0, 0], [0, 0]]}}}, 'pc': [1, 1], 'standings': {'per_tick': [['+', '0', '-'], ['0', '0', '0'], ['0', '0', '0'], ['0', '0', '0']], 'records': [[1, 1, 1], [0, 0, 3], [0, 0, 3], [0, 0, 3]], 'frequencies': {'0': {'positive': '1/3', 'negative': '1/3', 'neutral': '1/3'}, '1': {'positive': '0', 'negative': '0', 'neutral': '1'}, '2': {'positive': '0', 'negative': '0', 'neutral': '1'}, '3': {'positive': '0', 'negative': '0', 'neutral': '1'}}}, 'flows': {'0->1': {'+->0': 1, '0->0': 1, '-->0': 1}, '1->2': {'0->0': 3}, '2->3': {'0->0': 3}}, 'joints': [{'label': 'J_W(S1 = +, S3 = -)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}, {'label': 'J_W(S1 = + at d=0, S3 = 0 at d=+1)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}], 'joint_checks': {'marginalization': [1, 1], 'window_additivity': [1, 1]}, 'capability': {'profiles': {'S1': [1, 1], 'S2': [2, 0], 'S3': [1, 1]}, 'by_profile': {'(1, 1)': {'bodies': ['S1', 'S3'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}, '(2, 0)': {'bodies': ['S2'], 'sizes': {'rule1_cover': {'responder': 10, 'initiator': 10, 'spin-presenter': 4}, 'rule2_surplus': {'responder': 2, 'initiator': 11, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2], [3, 1]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2], [3, 1]], 'spin-presenter': [[0, 1], [0, 2], [0, 3], [0, 4]]}, 'rule2_surplus': {'responder': [[0, 2], [1, 3]], 'initiator': [[0, 0], [0, 1], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'spin-presenter': [[0, 2], [1, 3]]}}}}}, 'temperature': {'r_table': {'S1': {'1': 1, '2': 0, '3': 0}, 'S2': {'1': 1, '2': 0, '3': 0}, 'S3': {'1': 0, '2': 3, '3': 0}}, 'budget_lines': [{'body': 'S1', 'tick': 1, 'v2': 91, 's2': 5, 'r': 1}, {'body': 'S2', 'tick': 1, 'v2': 93, 's2': 3, 'r': 1}, {'body': 'S3', 'tick': 2, 'v2': 90, 's2': 4, 'r': 3}], 'R': 5, 'D': '5/9', 'D_float': 0.5555555555555556, 'locals': {'S1': '1/3', 'S2': '1/3', 'S3': '1'}}, 'omega': {'records': [[1, 1, 1], [0, 0, 3], [0, 0, 3], [0, 0, 3]], 'omegas': [6, 1, 1, 1], 'omega_max': 6, 'argmax': [[1, 1, 1]], 'phi_records': [[1, 2], [0, 3], [0, 3], [0, 3]], 'phi_omegas': [3, 1, 1, 1], 'ln_omegas': [1.7918, 0.0, 0.0, 0.0]}, 'equilibrium': [{'tick': 0, 'record': [1, 1, 1], 'stationary_E1': False, 'Omega': 6, 'E2_maximal': True, 'equilibrium': False}, {'tick': 1, 'record': [0, 0, 3], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}, {'tick': 2, 'record': [0, 0, 3], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}, {'tick': 3, 'record': [0, 0, 3], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}]}, 'E-MID': {'id': 'E-MID', 'census': {'vectors': {'M1': [2, [2], 10], 'M2': [2, [2], 10], 'M3': [3, [2], 16], 'M4': [3, [2, 2], 14], 'M5': [2, [2, 3], 7], 'M6': [1, [2], 4]}, 'classes': {'(2, (2,), 10)': 2, '(3, (2,), 16)': 1, '(3, (2, 2), 14)': 1, '(2, (2, 3), 7)': 1, '(1, (2,), 4)': 1}, 'tot_N': 13, 'tot_B': 61}, 'tau': {'rows': [{'tick': 0, 'per_junction': {'K1': 4, 'K2': 2, 'K3': 4, 'K4': 4, 'K5': 1, 'K6': 4, 'K8': 2, 'K7': 2}, 'acting': ['K1', 'K2', 'K3', 'K4', 'K6', 'K8'], 'tau_agg': 23}, {'tick': 1, 'per_junction': {'K1': 2, 'K2': 0, 'K3': 2, 'K4': 2, 'K5': 1, 'K6': 2, 'K8': 0, 'K7': 2}, 'acting': ['K1', 'K3', 'K4', 'K6'], 'tau_agg': 11}, {'tick': 2, 'per_junction': {'K1': 0, 'K2': 0, 'K3': 0, 'K4': 0, 'K5': 1, 'K6': 0, 'K8': 0, 'K7': 2}, 'acting': [], 'tau_agg': 3}, {'tick': 3, 'per_junction': {'K1': 0, 'K2': 0, 'K3': 0, 'K4': 0, 'K5': 1, 'K6': 0, 'K8': 0, 'K7': 2}, 'acting': [], 'tau_agg': 3}], 'tick1_before_after': {'K1': {'before': [[1, 1], [-1, -1]], 'after': [[0, 1], [0, -1]]}, 'K2': {'before': [[1, 0], [-1, 0]], 'after': [[0, 0], [0, 0]]}, 'K3': {'before': [[-1, -1], [1, 1]], 'after': [[0, -1], [0, 1]]}, 'K4': {'before': [[-1, 1], [1, -1]], 'after': [[0, 1], [0, -1]]}, 'K5': {'before': [[0, 0], [1, 0]], 'after': [[0, 0], [1, 0]]}, 'K6': {'before': [[1, -1], [-1, 1]], 'after': [[0, -1], [0, 1]]}, 'K8': {'before': [[-1, 0], [1, 0]], 'after': [[0, 0], [0, 0]]}}}, 'pc': [2, 1], 'standings': {'per_tick': [['+', '+', '-', '+', '+', '-'], ['+', '0', '-', '+', '-', '0'], ['0', '0', '0', '0', '0', '0'], ['0', '0', '0', '0', '0', '0']], 'records': [[4, 2, 0], [2, 2, 2], [0, 0, 6], [0, 0, 6]], 'frequencies': {'0': {'positive': '2/3', 'negative': '1/3', 'neutral': '0'}, '1': {'positive': '1/3', 'negative': '1/3', 'neutral': '1/3'}, '2': {'positive': '0', 'negative': '0', 'neutral': '1'}, '3': {'positive': '0', 'negative': '0', 'neutral': '1'}}}, 'flows': {'0->1': {'+->+': 2, '+->0': 1, '-->-': 1, '+->-': 1, '-->0': 1}, '1->2': {'+->0': 2, '0->0': 2, '-->0': 2}, '2->3': {'0->0': 6}}, 'joints': [{'label': 'J_W(M5 = -, M3 = -)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}, {'label': 'J_W(M1 = + at d=0, M5 = - at d=+1)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}, {'label': 'J_W(junction K6 = -, M5 = -)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}], 'joint_checks': {'marginalization': [1, 1], 'window_additivity': [1, 1]}, 'capability': {'profiles': {'M1': [2, 2], 'M2': [1, 1], 'M3': [2, 2], 'M4': [3, 2], 'M5': [4, 2], 'M6': [1, 1]}, 'by_profile': {'(1, 1)': {'bodies': ['M2', 'M6'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}, '(2, 2)': {'bodies': ['M1', 'M3'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}, '(3, 2)': {'bodies': ['M4'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 10, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 2, 'initiator': 9, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 1], [1, 2]], 'initiator': [[0, 0], [1, 0], [1, 1], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'spin-presenter': [[0, 1], [1, 2]]}}}, '(4, 2)': {'bodies': ['M5'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 12, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 2, 'initiator': 11, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 1]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 2], [1, 3]], 'initiator': [[0, 0], [0, 1], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'spin-presenter': [[0, 2], [1, 3]]}}}}}, 'temperature': {'r_table': {'M1': {'1': 7, '2': 4, '3': 0}, 'M2': {'1': 4, '2': 3, '3': 1}, 'M3': {'1': 8, '2': 7, '3': 2}, 'M4': {'1': 5, '2': 0, '3': 2}, 'M5': {'1': 8, '2': 6, '3': 2}, 'M6': {'1': 1, '2': 1, '3': 0}}, 'budget_lines': [{'body': 'M1', 'tick': 1, 'v2': 84, 's2': 6, 'r': 7}, {'body': 'M1', 'tick': 2, 'v2': 88, 's2': 5, 'r': 4}, {'body': 'M2', 'tick': 1, 'v2': 90, 's2': 3, 'r': 4}, {'body': 'M2', 'tick': 2, 'v2': 86, 's2': 8, 'r': 3}, {'body': 'M2', 'tick': 3, 'v2': 92, 's2': 4, 'r': 1}, {'body': 'M3', 'tick': 1, 'v2': 80, 's2': 9, 'r': 8}, {'body': 'M3', 'tick': 2, 'v2': 83, 's2': 7, 'r': 7}, {'body': 'M3', 'tick': 3, 'v2': 89, 's2': 6, 'r': 2}, {'body': 'M4', 'tick': 1, 'v2': 87, 's2': 5, 'r': 5}, {'body': 'M4', 'tick': 3, 'v2': 90, 's2': 5, 'r': 2}, {'body': 'M5', 'tick': 1, 'v2': 85, 's2': 4, 'r': 8}, {'body': 'M5', 'tick': 2, 'v2': 81, 's2': 10, 'r': 6}, {'body': 'M5', 'tick': 3, 'v2': 88, 's2': 7, 'r': 2}, {'body': 'M6', 'tick': 1, 'v2': 94, 's2': 2, 'r': 1}, {'body': 'M6', 'tick': 2, 'v2': 95, 's2': 1, 'r': 1}], 'R': 61, 'D': '61/18', 'D_float': 3.388888888888889, 'locals': {'M1': '11/3', 'M2': '8/3', 'M3': '17/3', 'M4': '7/3', 'M5': '16/3', 'M6': '2/3'}}, 'omega': {'records': [[4, 2, 0], [2, 2, 2], [0, 0, 6], [0, 0, 6]], 'omegas': [15, 90, 1, 1], 'omega_max': 90, 'argmax': [[2, 2, 2]], 'phi_records': [[4, 2], [2, 4], [0, 6], [0, 6]], 'phi_omegas': [15, 15, 1, 1], 'ln_omegas': [2.7081, 4.4998, 0.0, 0.0]}, 'equilibrium': [{'tick': 0, 'record': [4, 2, 0], 'stationary_E1': False, 'Omega': 15, 'E2_maximal': False, 'equilibrium': False}, {'tick': 1, 'record': [2, 2, 2], 'stationary_E1': False, 'Omega': 90, 'E2_maximal': True, 'equilibrium': False}, {'tick': 2, 'record': [0, 0, 6], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}, {'tick': 3, 'record': [0, 0, 6], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}]}, 'E-LARGE': {'id': 'E-LARGE', 'census': {'vectors': {'L1': [3, [2], 16], 'L2': [2, [2], 10], 'L3': [3, [2], 16], 'L4': [2, [2], 10], 'L5': [3, [2], 16], 'L6': [2, [2], 10], 'L7': [3, [2], 16], 'L8': [2, [2], 10], 'L9': [3, [2], 16], 'L10': [2, [2], 10], 'L11': [3, [2], 16], 'L12': [2, [2, 3], 7]}, 'classes': {'(3, (2,), 16)': 6, '(2, (2,), 10)': 5, '(2, (2, 3), 7)': 1}, 'tot_N': 30, 'tot_B': 153}, 'tau': {'rows': [{'tick': 0, 'per_junction': {'J1': 4, 'J2': 2, 'J3': 4, 'J4': 2, 'J5': 4, 'J6': 2, 'J7': 3, 'J8': 0, 'J9': 4, 'J10': 1, 'J11': 3, 'J12': 4, 'J13': 2}, 'acting': ['J1', 'J2', 'J3', 'J4', 'J5', 'J6', 'J7', 'J9', 'J11', 'J12'], 'tau_agg': 35}, {'tick': 1, 'per_junction': {'J1': 2, 'J2': 0, 'J3': 2, 'J4': 0, 'J5': 2, 'J6': 0, 'J7': 1, 'J8': 0, 'J9': 2, 'J10': 1, 'J11': 1, 'J12': 2, 'J13': 2}, 'acting': ['J1', 'J3', 'J5', 'J9'], 'tau_agg': 15}, {'tick': 2, 'per_junction': {'J1': 0, 'J2': 0, 'J3': 0, 'J4': 0, 'J5': 0, 'J6': 0, 'J7': 1, 'J8': 0, 'J9': 0, 'J10': 1, 'J11': 1, 'J12': 2, 'J13': 2}, 'acting': [], 'tau_agg': 7}, {'tick': 3, 'per_junction': {'J1': 0, 'J2': 0, 'J3': 0, 'J4': 0, 'J5': 0, 'J6': 0, 'J7': 1, 'J8': 0, 'J9': 0, 'J10': 1, 'J11': 1, 'J12': 2, 'J13': 2}, 'acting': [], 'tau_agg': 7}], 'tick1_before_after': {'J1': {'before': [[1, 1], [-1, -1]], 'after': [[0, 1], [0, -1]]}, 'J2': {'before': [[1, 0], [-1, 0]], 'after': [[0, 0], [0, 0]]}, 'J3': {'before': [[-1, -1], [1, 1]], 'after': [[0, -1], [0, 1]]}, 'J4': {'before': [[-1, 0], [1, 0]], 'after': [[0, 0], [0, 0]]}, 'J5': {'before': [[1, -1], [-1, 1]], 'after': [[0, -1], [0, 1]]}, 'J6': {'before': [[0, 1], [0, -1]], 'after': [[0, 0], [0, 0]]}, 'J7': {'before': [[1, 1], [-1, 0]], 'after': [[0, 1], [0, 0]]}, 'J8': {'before': [[0, 0], [0, 0]], 'after': [[0, 0], [0, 0]]}, 'J9': {'before': [[-1, 1], [1, -1]], 'after': [[0, 1], [0, -1]]}, 'J10': {'before': [[1, 0], [0, 0]], 'after': [[1, 0], [0, 0]]}, 'J11': {'before': [[-1, -1], [1, 0]], 'after': [[0, -1], [0, 0]]}, 'J12': {'before': [[1, -1], [-1, -1]], 'after': [[0, -1], [0, -1]]}}}, 'pc': [2, 1], 'standings': {'per_tick': [['+', '+', '-', '-', '+', '+', '+', '0', '+', '0', '-', '+'], ['+', '0', '-', '0', '-', '0', '0', '0', '+', '0', '0', '0'], ['0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'], ['0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0']], 'records': [[7, 3, 2], [2, 2, 8], [0, 0, 12], [0, 0, 12]], 'frequencies': {'0': {'positive': '7/12', 'negative': '1/4', 'neutral': '1/6'}, '1': {'positive': '1/6', 'negative': '1/6', 'neutral': '2/3'}, '2': {'positive': '0', 'negative': '0', 'neutral': '1'}, '3': {'positive': '0', 'negative': '0', 'neutral': '1'}}}, 'flows': {'0->1': {'+->+': 2, '+->0': 4, '-->-': 1, '-->0': 2, '+->-': 1, '0->0': 2}, '1->2': {'+->0': 2, '0->0': 8, '-->0': 2}, '2->3': {'0->0': 12}}, 'joints': [{'label': 'J_W(L5 = +, L9 = +)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}, {'label': 'J_W(L1 = + at d=0, L5 = - at d=+1)', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}, {'label': 'J_W(junction J13 = 0, L12 = +) [multi-sided member: glue route]', 'J': 1, 'window': [0, 3], 'frequency': '1/3'}], 'joint_checks': {'marginalization': [1, 1], 'window_additivity': [1, 1]}, 'capability': {'profiles': {'L1': [2, 2], 'L2': [1, 1], 'L3': [2, 2], 'L4': [1, 1], 'L5': [2, 2], 'L6': [1, 1], 'L7': [2, 1], 'L8': [0, 0], 'L9': [2, 2], 'L10': [1, 0], 'L11': [1, 2], 'L12': [3, 3]}, 'by_profile': {'(0, 0)': {'bodies': ['L8'], 'sizes': {'rule1_cover': {'responder': 0, 'initiator': 0, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 2, 'initiator': 0, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [], 'initiator': [], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[1, 1], [2, 2]]}}}, '(1, 0)': {'bodies': ['L10'], 'sizes': {'rule1_cover': {'responder': 10, 'initiator': 9, 'spin-presenter': 4}, 'rule2_surplus': {'responder': 2, 'initiator': 9, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2], [3, 1]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2]], 'spin-presenter': [[0, 1], [0, 2], [0, 3], [0, 4]]}, 'rule2_surplus': {'responder': [[0, 1], [1, 2]], 'initiator': [[0, 0], [1, 0], [1, 1], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'spin-presenter': [[0, 1], [1, 2]]}}}, '(1, 1)': {'bodies': ['L2', 'L4', 'L6'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}, '(1, 2)': {'bodies': ['L11'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 6, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 2, 'initiator': 0, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 2], [1, 3]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[1, 0], [2, 1]], 'initiator': [], 'spin-presenter': [[1, 0], [2, 1]]}}}, '(2, 1)': {'bodies': ['L7'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 10, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 2, 'initiator': 9, 'spin-presenter': 2}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 1], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 1], [1, 2]], 'initiator': [[0, 0], [1, 0], [1, 1], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'spin-presenter': [[0, 1], [1, 2]]}}}, '(2, 2)': {'bodies': ['L1', 'L3', 'L5', 'L9'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}, '(3, 3)': {'bodies': ['L12'], 'sizes': {'rule1_cover': {'responder': 14, 'initiator': 8, 'spin-presenter': 0}, 'rule2_surplus': {'responder': 3, 'initiator': 0, 'spin-presenter': 3}}, 'sets': {'rule1_cover': {'responder': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [3, 0], [3, 1], [4, 0]], 'initiator': [[0, 1], [0, 2], [0, 3], [0, 4], [1, 1], [1, 2], [1, 3], [2, 2]], 'spin-presenter': []}, 'rule2_surplus': {'responder': [[0, 0], [1, 1], [2, 2]], 'initiator': [], 'spin-presenter': [[0, 0], [1, 1], [2, 2]]}}}}}, 'temperature': {'r_table': {'L1': {'1': 45, '2': 35, '3': 25}, 'L2': {'1': 39, '2': 23, '3': 25}, 'L3': {'1': 43, '2': 34, '3': 29}, 'L4': {'1': 29, '2': 27, '3': 18}, 'L5': {'1': 40, '2': 36, '3': 29}, 'L6': {'1': 31, '2': 35, '3': 21}, 'L7': {'1': 38, '2': 21, '3': 28}, 'L8': {'1': 0, '2': 20, '3': 16}, 'L9': {'1': 41, '2': 40, '3': 25}, 'L10': {'1': 20, '2': 0, '3': 16}, 'L11': {'1': 40, '2': 36, '3': 28}, 'L12': {'1': 30, '2': 35, '3': 13}}, 'budget_lines': [{'body': 'L1', 'tick': 1, 'v2': 38, 's2': 14, 'r': 45}, {'body': 'L1', 'tick': 2, 'v2': 44, 's2': 18, 'r': 35}, {'body': 'L1', 'tick': 3, 'v2': 52, 's2': 20, 'r': 25}, {'body': 'L2', 'tick': 1, 'v2': 47, 's2': 11, 'r': 39}, {'body': 'L2', 'tick': 2, 'v2': 58, 's2': 16, 'r': 23}, {'body': 'L2', 'tick': 3, 'v2': 63, 's2': 9, 'r': 25}, {'body': 'L3', 'tick': 1, 'v2': 35, 's2': 19, 'r': 43}, {'body': 'L3', 'tick': 2, 'v2': 41, 's2': 22, 'r': 34}, {'body': 'L3', 'tick': 3, 'v2': 55, 's2': 13, 'r': 29}, {'body': 'L4', 'tick': 1, 'v2': 60, 's2': 8, 'r': 29}, {'body': 'L4', 'tick': 2, 'v2': 49, 's2': 21, 'r': 27}, {'body': 'L4', 'tick': 3, 'v2': 67, 's2': 12, 'r': 18}, {'body': 'L5', 'tick': 1, 'v2': 33, 's2': 24, 'r': 40}, {'body': 'L5', 'tick': 2, 'v2': 46, 's2': 15, 'r': 36}, {'body': 'L5', 'tick': 3, 'v2': 51, 's2': 17, 'r': 29}, {'body': 'L6', 'tick': 1, 'v2': 56, 's2': 10, 'r': 31}, {'body': 'L6', 'tick': 2, 'v2': 39, 's2': 23, 'r': 35}, {'body': 'L6', 'tick': 3, 'v2': 62, 's2': 14, 'r': 21}, {'body': 'L7', 'tick': 1, 'v2': 43, 's2': 16, 'r': 38}, {'body': 'L7', 'tick': 2, 'v2': 57, 's2': 19, 'r': 21}, {'body': 'L7', 'tick': 3, 'v2': 48, 's2': 21, 'r': 28}, {'body': 'L8', 'tick': 2, 'v2': 71, 's2': 6, 'r': 20}, {'body': 'L8', 'tick': 3, 'v2': 66, 's2': 15, 'r': 16}, {'body': 'L9', 'tick': 1, 'v2': 36, 's2': 20, 'r': 41}, {'body': 'L9', 'tick': 2, 'v2': 45, 's2': 12, 'r': 40}, {'body': 'L9', 'tick': 3, 'v2': 54, 's2': 18, 'r': 25}, {'body': 'L10', 'tick': 1, 'v2': 64, 's2': 13, 'r': 20}, {'body': 'L10', 'tick': 3, 'v2': 59, 's2': 22, 'r': 16}, {'body': 'L11', 'tick': 1, 'v2': 40, 's2': 17, 'r': 40}, {'body': 'L11', 'tick': 2, 'v2': 50, 's2': 11, 'r': 36}, {'body': 'L11', 'tick': 3, 'v2': 61, 's2': 8, 'r': 28}, {'body': 'L12', 'tick': 1, 'v2': 42, 's2': 25, 'r': 30}, {'body': 'L12', 'tick': 2, 'v2': 53, 's2': 9, 'r': 35}, {'body': 'L12', 'tick': 3, 'v2': 68, 's2': 16, 'r': 13}], 'R': 1011, 'D': '337/12', 'D_float': 28.083333333333332, 'locals': {'L1': '35', 'L2': '29', 'L3': '106/3', 'L4': '74/3', 'L5': '35', 'L6': '29', 'L7': '29', 'L8': '12', 'L9': '106/3', 'L10': '12', 'L11': '104/3', 'L12': '26'}}, 'omega': {'records': [[7, 3, 2], [2, 2, 8], [0, 0, 12], [0, 0, 12]], 'omegas': [7920, 2970, 1, 1], 'omega_max': 34650, 'argmax': [[4, 4, 4]], 'phi_records': [[7, 5], [2, 10], [0, 12], [0, 12]], 'phi_omegas': [792, 66, 1, 1], 'ln_omegas': [8.9771, 7.9963, 0.0, 0.0]}, 'equilibrium': [{'tick': 0, 'record': [7, 3, 2], 'stationary_E1': False, 'Omega': 7920, 'E2_maximal': False, 'equilibrium': False}, {'tick': 1, 'record': [2, 2, 8], 'stationary_E1': False, 'Omega': 2970, 'E2_maximal': False, 'equilibrium': False}, {'tick': 2, 'record': [0, 0, 12], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}, {'tick': 3, 'record': [0, 0, 12], 'stationary_E1': True, 'Omega': 1, 'E2_maximal': False, 'equilibrium': False}]}}

# ================================================================
# COMPUTE PATH (the exhibits' chain; reuses A.4/A.5/A.12)
# ================================================================
EXPECT_COUNT = [0]
FAIL = []


def expect(cond, label):
    EXPECT_COUNT[0] += 1
    if not cond:
        print(f"  [FAIL] {label}")
        FAIL.append(label)
    return cond


def tau_sigma(sigma):
    A, B = sigma
    return sum(x * x for x in A) + sum(x * x for x in B)


def tau_ms(sides):
    return sum(x * x for side in sides for x in side)


def ms_standing(sides):
    """Standing of a multi-sided junction's presented record, under
    the strictest reading of Definition 5.7's multi-sided clause:
    an opposed pair between ANY two sides, in either order across
    the pair, at any index. (The declared sides make this neutral
    under every reading; this function proves it on the data.)"""
    pos = neg = False
    n = len(sides)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            X, Y = sides[i], sides[j]
            for k in range(len(X)):
                if X[k] == 1 and Y[k] == -1:
                    pos = True
                if X[k] == -1 and Y[k] == 1:
                    neg = True
    if pos:
        return "+"
    if neg:
        return "-"
    return "0"


def body_standing_full(pair_sigmas, ms_standings):
    """Definition 5.7 body aggregation over ALL carried junctions
    (pairwise standings via A.12; multi-sided standings via glue)."""
    sts = [A12.standing(s) for s in pair_sigmas] + list(ms_standings)
    if "+" in sts:
        return "+"
    if "-" in sts:
        return "-"
    return "0"


def count_vector(body):
    arities = tuple(sorted(j["k"] for j in body["junctions"]))
    B = 6 * body["N"] - sum(arities)
    return (body["N"], arities, B)


def run_population(pop):
    pid = pop["id"]
    print(f"\n{'=' * 78}\n{pid}\n{'=' * 78}")
    out = {"id": pid}
    bodies = pop["bodies"]
    names = [b["name"] for b in bodies]
    n = len(bodies)

    # ---- population in A.12's form: per body, its carried pairwise sigmas
    sigma0 = tuple(
        tuple(j["sigma"] for j in b["junctions"] if j["kind"] == "pair")
        for b in bodies)
    d = A12.make_pop(names, sigma0)
    states = d["states"]                      # ticks 0..7 (HORIZON)
    ticks = P.TRAJ_TICKS                      # 0..3 exhibited

    # multi-sided junctions: (body_idx, junction dict) in declaration order
    ms_list = [(bi, j) for bi, b in enumerate(bodies)
               for j in b["junctions"] if j["kind"] == "ms"]
    for bi, j in ms_list:
        s = ms_standing(j["sides"])
        expect(s == "0", f"{pid}: {j['id']} standing neutral under the "
                         f"strictest reading (got {s})")

    # ------------------------------------------------ station 1: census
    print("\n-- Station 1: census (sec. 3) --")
    vectors = {b["name"]: count_vector(b) for b in bodies}
    for b in bodies:
        print(f"  {b['name']}: N={b['N']}, arities="
              f"{tuple(sorted(j['k'] for j in b['junctions']))}, "
              f"B={vectors[b['name']][2]}  vector={vectors[b['name']]}")
    cen = Counter(vectors.values())
    print(f"  census: {dict(cen)}")
    expect(sum(cen.values()) == n, f"{pid}: (II) census sums to |P| = {n}")
    # (III) grouped vs direct, componentwise (N and B; arities via consumed)
    tot_N_grp = sum(c * v[0] for v, c in cen.items())
    tot_N_dir = sum(b["N"] for b in bodies)
    tot_B_grp = sum(c * v[2] for v, c in cen.items())
    tot_B_dir = 6 * tot_N_dir - sum(j["k"] for b in bodies
                                    for j in b["junctions"])
    expect(tot_N_grp == tot_N_dir, f"{pid}: (III) nodes grouped "
                                   f"{tot_N_grp} == direct {tot_N_dir}")
    expect(tot_B_grp == tot_B_dir, f"{pid}: (III) boundary grouped "
                                   f"{tot_B_grp} == direct {tot_B_dir}")
    out["census"] = {"vectors": {k: list(v) for k, v in vectors.items()},
                     "classes": {str(k): v for k, v in cen.items()},
                     "tot_N": tot_N_dir, "tot_B": tot_B_dir}

    # --------------------------------------- station 2: aggregate tick
    print("\n-- Station 2: aggregate tick (sec. 4) --")
    # per-junction tau and action, tick by tick (pairwise from states;
    # multi-sided constant, routed, Delta-tau = 0)
    pair_junctions = [(bi, ji, j) for bi, b in enumerate(bodies)
                      for ji, j in enumerate(b["junctions"])
                      if j["kind"] == "pair"]
    tau_rows = []
    for t in ticks:
        row = {"tick": t, "per_junction": {}, "acting": []}
        tot = 0
        for bi, ji, j in pair_junctions:
            sig = states[t][bi][ji]
            tv = tau_sigma(sig)
            row["per_junction"][j["id"]] = tv
            tot += tv
            if A12.admissible_indices(sig):
                row["acting"].append(j["id"])
        for bi, j in ms_list:
            row["per_junction"][j["id"]] = tau_ms(j["sides"])
            tot += tau_ms(j["sides"])
        row["tau_agg"] = tot
        tau_rows.append(row)
    for a, b_ in zip(tau_rows, tau_rows[1:]):
        dtau = b_["tau_agg"] - a["tau_agg"]
        # acting on the tick LEAVING record a = junctions admissible at a
        expect(dtau == -2 * len(a["acting"]),
               f"{pid}: tick {a['tick']}->"
               f"{b_['tick']}: Dtau = {dtau} == -2 x {len(a['acting'])} "
               f"acting {a['acting']}")
        print(f"  tick {a['tick']}: tau_agg = {a['tau_agg']}, acting "
              f"{a['acting']} -> tick {b_['tick']}: tau_agg = "
              f"{b_['tau_agg']} (Dtau {dtau})")
    print(f"  tick {tau_rows[-1]['tick']}: tau_agg = "
          f"{tau_rows[-1]['tau_agg']} (confirming tick, acting "
          f"{tau_rows[-1]['acting']})")
    # tick-1 before/after in full
    ba = {}
    for bi, ji, j in pair_junctions:
        ba[j["id"]] = {"before": states[0][bi][ji],
                       "after": states[1][bi][ji]}
    out["tau"] = {"rows": tau_rows,
                  "tick1_before_after": {k: {"before": [list(v["before"][0]),
                                                        list(v["before"][1])],
                                             "after": [list(v["after"][0]),
                                                       list(v["after"][1])]}
                                         for k, v in ba.items()}}
    # (p, c) decomposition over the computed horizon
    seen = {}
    pc = None
    for t in range(len(states)):
        if states[t] in seen:
            pc = (seen[states[t]], t - seen[states[t]])
            break
        seen[states[t]] = t
    out["pc"] = pc
    print(f"  (p, c) decomposition: {pc}")

    # -------------------------------------- station 3: frequencies (sec. 5)
    print("\n-- Station 3: frequencies, standings, joint counts (sec. 5) --")
    stnd5 = [tuple(d["stnd"][t]) for t in ticks + [ticks[-1] + 1]]
    stnd = stnd5[:len(ticks)]
    # cross-check A.12's body standings against the full aggregation
    # (pairwise standings + multi-sided standings, Definition 5.7)
    for t in ticks:
        for bi, b in enumerate(bodies):
            pair_sigs = [j2 for j2 in
                         states[t][bi]]
            ms_sts = [ms_standing(j["sides"]) for bj, j in ms_list
                      if bj == bi]
            full = body_standing_full(pair_sigs, ms_sts)
            expect(full == stnd[t][bi],
                   f"{pid}: t{t} {b['name']} standing full-aggregation "
                   f"{full} == A.12 {stnd[t][bi]}")
    tallies = [Counter(s) for s in stnd]
    records = [tuple(c[x] for x in ("+", "-", "0")) for c in tallies]
    for t, rec in zip(ticks, records):
        print(f"  tick {t}: standings {stnd[t]}  tally (+,-,0) = {rec}")
        for x, lab in zip(rec, ("positive", "negative", "neutral")):
            pass
    freq = {t: {lab: str(Fraction(rec[i], n))
                for i, lab in enumerate(("positive", "negative", "neutral"))}
            for t, rec in zip(ticks, records)}
    out["standings"] = {"per_tick": [list(s) for s in stnd],
                        "records": records, "frequencies": freq}
    # flow counts over standing classes, per tick pair
    flows = {}
    for t in ticks[:-1]:
        # flow counts F_{i->j} (sec. 9.1), tallied in A.9's shape
        F = Counter(zip(stnd[t], stnd[t + 1]))
        flows[f"{t}->{t+1}"] = {f"{a}->{b_}": v for (a, b_), v in F.items()}
        net = {x: sum(v for (a, b_), v in F.items() if b_ == x)
               - sum(v for (a, b_), v in F.items() if a == x)
               for x in ("+", "-", "0")}
        print(f"  flow {t}->{t+1}: {flows[f'{t}->{t+1}']}  net {net}")
    out["flows"] = flows
    # joint counts (Definition 5.8) via A.12's generic route; the
    # multi-sided member goes by the glue route (its standing is the
    # constant computed above).
    joints = []
    for label, specs, window in pop["joint_specs"]:
        if any(spec[0][0] == "msjunction" for spec in specs):
            ms_spec = [s for s in specs if s[0][0] == "msjunction"][0]
            body_spec = [s for s in specs if s[0][0] == "body"][0]
            (mtag, mbi, mji), mX = ms_spec[0], ms_spec[1]
            msj = bodies[mbi]["junctions"][mji]
            ms_st = ms_standing(msj["sides"])
            (btag, bidx), bX = body_spec[0], body_spec[1]
            cnt = sum(1 for t in range(window[0], window[1])
                      if ms_st == mX and stnd[t][bidx] == bX)
            val = cnt
        else:
            val = A12.joint_count_members(d, window, specs)
        entry = {"label": label, "J": val, "window": list(window),
                 "frequency": str(Fraction(val, window[1] - window[0]))}
        joints.append(entry)
        print(f"  {label}: J = {val}, frequency = {entry['frequency']}")
    out["joints"] = joints
    # marginalization + window additivity on the first (offset-free,
    # two-body) spec of each population
    label0, specs0, win0 = pop["joint_specs"][0]
    (m1, X1), (m2, X2) = specs0[0], specs0[1]
    marg = sum(A12.joint_count_members(d, win0, ((m1, X1), (m2, X)))
               for X in A12.STANDINGS)
    single = A12.joint_count_members(d, win0, ((m1, X1),))
    expect(marg == single, f"{pid}: marginalization: sum over second "
                           f"member's standings {marg} == single count "
                           f"{single}")
    w_lo = (win0[0], win0[0] + 1)
    w_hi = (win0[0] + 1, win0[1])
    add = (A12.joint_count_members(d, w_lo, specs0)
           + A12.joint_count_members(d, w_hi, specs0))
    expect(add == joints[0]["J"], f"{pid}: window additivity: "
                                  f"{w_lo}+{w_hi} = {add} == {joints[0]['J']}")
    out["joint_checks"] = {"marginalization": [marg, single],
                           "window_additivity": [add, joints[0]["J"]]}

    # -------------------------------------- station 4: capability (sec. 6)
    print("\n-- Station 4: capability (sec. 6) --")
    caps = {}
    profiles = {}
    for bi, b in enumerate(bodies):
        presented = []
        ji = 0
        for j in b["junctions"]:
            if j["kind"] == "pair":
                # A.7's presented_tuple: A entries, then B entries
                presented.extend(states[0][bi][ji][0])
                presented.extend(states[0][bi][ji][1])
                ji += 1
            else:
                # the presented record's entries, in declaration order
                for side in j["sides"]:
                    presented.extend(side)
        M = A4.profile(tuple(presented))
        profiles[b["name"]] = M
        caps[b["name"]] = {
            rname: A4.capability({"presented": tuple(presented)}, rule)
            for rname, rule in A4.RULES.items()}
        print(f"  {b['name']}: presented {tuple(presented)}, M = {M}")
    by_profile = {}
    for nm, M in profiles.items():
        by_profile.setdefault(M, []).append(nm)
    cap_summary = {}
    for M, members in sorted(by_profile.items()):
        ref = caps[members[0]]
        for rname in A4.RULES:
            for other in members[1:]:
                expect(caps[other][rname] == ref[rname],
                       f"{pid}: factorization: {other} == {members[0]} "
                       f"at M = {M} under {rname}")
        cap_summary[str(M)] = {
            "bodies": members,
            "sizes": {rname: {role: len(ref[rname][role]) for role in ref[rname]}
                      for rname in A4.RULES},
            "sets": {rname: {role: sorted(ref[rname][role])
                             for role in ref[rname]}
                     for rname in A4.RULES}}
        print(f"  M = {M}: bodies {members}; Cap sizes "
              f"{cap_summary[str(M)]['sizes']}")
    out["capability"] = {"profiles": {k: list(v) for k, v in profiles.items()},
                         "by_profile": cap_summary}

    # -------------------------------------- station 5: temperature (sec. 7)
    print("\n-- Station 5: temperature (sec. 7) --")
    W = P.WINDOW
    r_table = {}
    budget_lines = []
    R = 0
    for b in bodies:
        r_table[b["name"]] = {}
        for t in W:
            ct = pop["contact"].get(b["name"], {}).get(t)
            if ct is None:
                r_table[b["name"]][t] = 0
            else:
                v2, s2 = ct
                r = 97 - v2 - s2
                expect(0 <= r <= 97 and 3 + v2 + s2 + r == 100,
                       f"{pid}: budget {b['name']} t{t}: 3 + {v2} + "
                       f"{s2} + {r} = 100")
                budget_lines.append({"body": b["name"], "tick": t,
                                     "v2": v2, "s2": s2, "r": r})
                r_table[b["name"]][t] = r
            R += r_table[b["name"]][t]
    D = Fraction(R, n * len(W))
    locals_ = {b["name"]: Fraction(sum(r_table[b["name"]].values()), len(W))
               for b in bodies}
    mean_locals = sum(locals_.values()) / n
    expect(mean_locals == D, f"{pid}: mean of locals {mean_locals} == "
                             f"D {D} (eq. (7.4))")
    print(f"  r_b table: {r_table}")
    print(f"  R(P, W) = {R}; |P|.|W| = {n * len(W)}; D(P, W) = {D} "
          f"= {float(D):.4f}")
    print(f"  locals: {locals_}")
    out["temperature"] = {"r_table": {k: {str(t): v for t, v in vv.items()}
                                      for k, vv in r_table.items()},
                          "budget_lines": budget_lines, "R": R,
                          "D": str(D), "D_float": float(D),
                          "locals": {k: str(v) for k, v in locals_.items()}}

    # --------------------------- station 6/7: Omega, arrow, equilibrium
    print("\n-- Stations 6-7: Omega thread, arrow, equilibrium "
          "(secs. 8-9) --")
    all_recs = [(a, b, n - a - b) for a in range(n + 1)
                for b in range(n + 1 - a)]
    omega_max = max(A5.multinomial(r) for r in all_recs)
    argmax = [r for r in all_recs if A5.multinomial(r) == omega_max]
    omegas = [A5.multinomial(r) for r in records]
    phi_records = [(rec[0], rec[1] + rec[2]) for rec in records]
    phi_omegas = [A5.multinomial(r) for r in phi_records]
    for t, rec, om, pr, po in zip(ticks, records, omegas,
                                  phi_records, phi_omegas):
        print(f"  tick {t}: record {rec}, Omega = {om}; phi record "
              f"{pr}, Omega_phi = {po}; tau_agg = "
              f"{tau_rows[t]['tau_agg']}; ln Omega = {math.log(om):.4f}")
    print(f"  Omega maximal over all {len(all_recs)} records of "
          f"{n} bodies / 3 standings: {omega_max} at {argmax}; "
          f"total assignments {sum(A5.multinomial(r) for r in all_recs)} "
          f"== 3^{n} = {3 ** n}")
    expect(sum(A5.multinomial(r) for r in all_recs) == 3 ** n,
           f"{pid}: sum of Omega over all records == 3^|P|")
    records5 = records + [tuple(Counter(s)[x] for x in ("+", "-", "0"))
                          for s in stnd5[len(ticks):]]
    verdicts = []
    for i, t in enumerate(ticks):
        # (E1), sec. 9.2/eq. (9.3): the record after one aggregate tick
        # equals the record before it, class by class.
        stationary = records5[i + 1] == records5[i]
        verdicts.append({"tick": t, "record": records[i],
                         "stationary_E1": bool(stationary),
                         "Omega": omegas[i],
                         "E2_maximal": omegas[i] == omega_max,
                         "equilibrium": bool(stationary)
                         and omegas[i] == omega_max})
        print(f"  tick {t}: (E1) {verdicts[-1]['stationary_E1']}, "
              f"(E2) {verdicts[-1]['E2_maximal']}, equilibrium: "
              f"{verdicts[-1]['equilibrium']}")
    out["omega"] = {"records": records, "omegas": omegas,
                    "omega_max": omega_max, "argmax": argmax,
                    "phi_records": phi_records, "phi_omegas": phi_omegas,
                    "ln_omegas": [round(math.log(o), 4) for o in omegas]}
    out["equilibrium"] = verdicts
    return out

# ================================================================
# VERIFY PATH (independent re-derivation; imports nothing
# but the declarations above)
# ================================================================
VCHECKS = [0]
VFAIL = []


def v_eq(got, want, label):
    VCHECKS[0] += 1
    if got != want:
        VFAIL.append(f"{label}: verify={got!r} != compute={want!r}")


# ------------------------------------------------------- own machinery
def T(sig):
    A, B = sig
    for k in range(len(A)):
        if A[k] == -B[k] != 0:
            A2, B2 = list(A), list(B)
            A2[k] = 0
            B2[k] = 0
            return (tuple(A2), tuple(B2))
    return (tuple(A), tuple(B))


def tau(sig):
    return sum(x * x for v in sig for x in v)


def standing_sig(sig):
    A, B = sig
    if any(A[k] == 1 and B[k] == -1 for k in range(len(A))):
        return "+"
    if any(A[k] == -1 and B[k] == 1 for k in range(len(A))):
        return "-"
    return "0"


def standing_ms(sides):
    pos = neg = False
    for X in sides:
        for Y in sides:
            if X is Y:
                continue
            for k in range(len(X)):
                if X[k] == 1 and Y[k] == -1:
                    pos = True
                if X[k] == -1 and Y[k] == 1:
                    neg = True
    return "+" if pos else ("-" if neg else "0")


def agg(sts):
    return "+" if "+" in sts else ("-" if "-" in sts else "0")


def multinomial(rec):
    num = math.factorial(sum(rec))
    for c in rec:
        num //= math.factorial(c)
    return num


TAXONOMY = [(ep, em) for ep in range(5) for em in range(5)
            if ep + em <= 4]
ROLES = ("responder", "initiator", "spin-presenter")


def rule1(MG, ME):
    np_, nm_ = MG
    ep, em = ME
    c = min(np_, em) + min(nm_, ep)
    s = min(np_, ep) + min(nm_, em)
    out = set()
    if c >= 1:
        out.add("responder")
        if (np_ - nm_) >= (ep - em):
            out.add("initiator")
    if c >= 1 and s == 0:
        out.add("spin-presenter")
    return out


def rule2(MG, ME):
    np_, nm_ = MG
    ep, em = ME
    net = (np_ - nm_) + (ep - em)
    total = np_ + nm_ + ep + em
    out = set()
    if net == 0 and total >= 2:
        out.update(("responder", "spin-presenter"))
    if net > 0 and np_ > nm_:
        out.add("initiator")
    return out


def cap(presented, rule):
    M = (sum(1 for v in presented if v == 1),
         sum(1 for v in presented if v == -1))
    out = {r: set() for r in ROLES}
    for E in TAXONOMY:
        for r in rule(M, E):
            out[r].add(E)
    return {r: sorted(out[r]) for r in ROLES}


def verify_pop(pop, C):
    pid = pop["id"]
    bodies = pop["bodies"]
    names = [b["name"] for b in bodies]
    n = len(bodies)

    # census
    vecs = {}
    for b in bodies:
        ar = tuple(sorted(j["k"] for j in b["junctions"]))
        vecs[b["name"]] = [b["N"], list(ar), 6 * b["N"] - sum(ar)]
    v_eq(C["census"]["vectors"], vecs, f"{pid} census vectors")
    cen = Counter(tuple([v[0], tuple(v[1]), v[2]]) for v in vecs.values())
    v_eq(C["census"]["classes"], {str(k): v for k, v in cen.items()},
       f"{pid} census classes")
    v_eq(C["census"]["tot_N"], sum(b["N"] for b in bodies), f"{pid} tot_N")
    v_eq(C["census"]["tot_B"],
       6 * sum(b["N"] for b in bodies)
       - sum(j["k"] for b in bodies for j in b["junctions"]),
       f"{pid} tot_B")

    # trajectory over pairwise part; ms junctions constant
    state = tuple(tuple(j["sigma"] for j in b["junctions"]
                        if j["kind"] == "pair") for b in bodies)
    states = [state]
    for _ in range(7):
        states.append(tuple(tuple(T(s) for s in body)
                            for body in states[-1]))
    pair_js = [(bi, ji, j) for bi, b in enumerate(bodies)
               for ji, j in enumerate(b["junctions"]) if j["kind"] == "pair"]
    ms_js = [(bi, j) for bi, b in enumerate(bodies)
             for j in b["junctions"] if j["kind"] == "ms"]
    rows = []
    for t in P.TRAJ_TICKS:
        pj = {}
        acting = []
        tot = 0
        for bi, ji, j in pair_js:
            pj[j["id"]] = tau(states[t][bi][ji])
            tot += pj[j["id"]]
            if T(states[t][bi][ji]) != states[t][bi][ji]:
                acting.append(j["id"])
        for bi, j in ms_js:
            pj[j["id"]] = sum(x * x for s in j["sides"] for x in s)
            tot += pj[j["id"]]
        rows.append({"tick": t, "per_junction": pj, "acting": acting,
                     "tau_agg": tot})
    v_eq(C["tau"]["rows"], rows, f"{pid} tau rows")
    ba = {j["id"]: {"before": [list(states[0][bi][ji][0]),
                               list(states[0][bi][ji][1])],
                    "after": [list(states[1][bi][ji][0]),
                              list(states[1][bi][ji][1])]}
          for bi, ji, j in pair_js}
    v_eq(C["tau"]["tick1_before_after"], ba, f"{pid} tick1 before/after")
    seen, pc = {}, None
    for t in range(len(states)):
        if states[t] in seen:
            pc = [seen[states[t]], t - seen[states[t]]]
            break
        seen[states[t]] = t
    v_eq(C["pc"], pc, f"{pid} (p,c)")

    # standings (full aggregation incl. ms), records, flows, joints
    def body_st(t, bi):
        sts = [standing_sig(s) for s in states[t][bi]]
        sts += [standing_ms(j["sides"]) for bj, j in ms_js if bj == bi]
        return agg(sts)

    stnd = [tuple(body_st(t, bi) for bi in range(n)) for t in range(5)]
    v_eq(C["standings"]["per_tick"], [list(s) for s in stnd[:4]],
       f"{pid} standings per tick")
    records = [tuple(Counter(s)[x] for x in ("+", "-", "0"))
               for s in stnd[:4]]
    v_eq(C["standings"]["records"], [list(r) for r in records],
       f"{pid} records")
    freq = {str(t): {lab: str(Fraction(rec[i], n))
                     for i, lab in enumerate(("positive", "negative",
                                              "neutral"))}
            for t, rec in zip(P.TRAJ_TICKS, records)}
    v_eq(C["standings"]["frequencies"], freq, f"{pid} frequencies")
    flows = {}
    for t in P.TRAJ_TICKS[:-1]:
        F = Counter(zip(stnd[t], stnd[t + 1]))
        flows[f"{t}->{t+1}"] = {f"{a}->{b}": v for (a, b), v in F.items()}
    v_eq(C["flows"], flows, f"{pid} flows")

    def member_st(t, member):
        if member[0] == "body":
            return stnd[t][member[1]]
        if member[0] == "junction":
            return standing_sig(states[t][member[1]][member[2]])
        # msjunction: (tag, body_idx, junction_idx_within_body)
        j = bodies[member[1]]["junctions"][member[2]]
        return standing_ms(j["sides"])

    joints = []
    for label, specs, window in pop["joint_specs"]:
        cnt = 0
        for t in range(window[0], window[1]):
            ok = True
            for spec in specs:
                member, X = spec[0], spec[1]
                dl = spec[2] if len(spec) > 2 else 0
                if member_st(t + dl, list(member)) != X:
                    ok = False
            cnt += ok
        joints.append({"label": label, "J": cnt, "window": list(window),
                       "frequency": str(Fraction(cnt,
                                                 window[1] - window[0]))})
    v_eq(C["joints"], joints, f"{pid} joint counts")
    # marginalization + additivity re-derived on spec 0
    (m1, X1), (m2, X2) = pop["joint_specs"][0][1][0], \
        pop["joint_specs"][0][1][1]
    w0 = pop["joint_specs"][0][2]

    def jc(specs, window):
        c = 0
        for t in range(window[0], window[1]):
            if all(member_st(t + (s[2] if len(s) > 2 else 0), list(s[0]))
                   == s[1] for s in specs):
                c += 1
        return c

    marg = sum(jc(((m1, X1), (m2, X)), w0) for X in ("+", "-", "0"))
    single = jc(((m1, X1),), w0)
    add = jc(pop["joint_specs"][0][1], (w0[0], w0[0] + 1)) \
        + jc(pop["joint_specs"][0][1], (w0[0] + 1, w0[1]))
    v_eq(C["joint_checks"], {"marginalization": [marg, single],
                           "window_additivity": [add, joints[0]["J"]]},
       f"{pid} joint checks")

    # capability
    profiles, caps = {}, {}
    for bi, b in enumerate(bodies):
        presented = []
        ji = 0
        for j in b["junctions"]:
            if j["kind"] == "pair":
                presented.extend(states[0][bi][ji][0])
                presented.extend(states[0][bi][ji][1])
                ji += 1
            else:
                for side in j["sides"]:
                    presented.extend(side)
        M = (sum(1 for v in presented if v == 1),
             sum(1 for v in presented if v == -1))
        profiles[b["name"]] = list(M)
        caps[b["name"]] = {"rule1_cover": cap(presented, rule1),
                           "rule2_surplus": cap(presented, rule2)}
    v_eq(C["capability"]["profiles"], profiles, f"{pid} profiles")
    byp = {}
    for nm_, M in profiles.items():
        byp.setdefault(tuple(M), []).append(nm_)
    summary = {}
    for M, members in sorted(byp.items()):
        ref = caps[members[0]]
        summary[str(M)] = {
            "bodies": members,
            "sizes": {rn: {role: len(ref[rn][role]) for role in ref[rn]}
                      for rn in ref},
            "sets": {rn: {role: [list(x) for x in ref[rn][role]]
                          for role in ref[rn]} for rn in ref}}
    # compute stored sets as lists of lists already; compare directly
    v_eq(C["capability"]["by_profile"], summary, f"{pid} capability by profile")

    # temperature
    r_table, R = {}, 0
    budget = []
    for b in bodies:
        r_table[b["name"]] = {}
        for t in P.WINDOW:
            ct = pop["contact"].get(b["name"], {}).get(t)
            r = 0 if ct is None else 97 - ct[0] - ct[1]
            if ct is not None:
                budget.append({"body": b["name"], "tick": t, "v2": ct[0],
                               "s2": ct[1], "r": r})
            r_table[b["name"]][t] = r
            R += r
    D = Fraction(R, n * len(P.WINDOW))
    locals_ = {b["name"]: str(Fraction(sum(r_table[b["name"]].values()),
                                       len(P.WINDOW))) for b in bodies}
    v_eq(C["temperature"]["r_table"],
       {k: {str(t): v for t, v in vv.items()} for k, vv in r_table.items()},
       f"{pid} r table")
    v_eq(C["temperature"]["budget_lines"], budget, f"{pid} budget lines")
    v_eq(C["temperature"]["R"], R, f"{pid} R")
    v_eq(C["temperature"]["D"], str(D), f"{pid} D")
    v_eq(C["temperature"]["locals"], locals_, f"{pid} locals")

    # Omega / equilibrium
    omegas = [multinomial(r) for r in records]
    allr = [(a, b, n - a - b) for a in range(n + 1)
            for b in range(n + 1 - a)]
    omax = max(multinomial(r) for r in allr)
    argmax = [list(r) for r in allr if multinomial(r) == omax]
    phi_records = [[rec[0], rec[1] + rec[2]] for rec in records]
    phi_omegas = [multinomial(r) for r in phi_records]
    v_eq(C["omega"]["omegas"], omegas, f"{pid} omegas")
    v_eq(C["omega"]["omega_max"], omax, f"{pid} omega_max")
    v_eq(C["omega"]["argmax"], argmax, f"{pid} argmax")
    v_eq(C["omega"]["phi_records"], phi_records, f"{pid} phi records")
    v_eq(C["omega"]["phi_omegas"], phi_omegas, f"{pid} phi omegas")
    v_eq(C["omega"]["ln_omegas"], [round(math.log(o), 4) for o in omegas],
       f"{pid} ln omegas")
    records5 = records + [tuple(Counter(stnd[4])[x] for x in ("+", "-", "0"))]
    verdicts = []
    for i, t in enumerate(P.TRAJ_TICKS):
        st = records5[i + 1] == records5[i]
        verdicts.append({"tick": t, "record": list(records[i]),
                         "stationary_E1": st, "Omega": omegas[i],
                         "E2_maximal": omegas[i] == omax,
                         "equilibrium": bool(st and omegas[i] == omax)})
    v_eq(C["equilibrium"],
       [{**v, "record": list(v["record"])} for v in verdicts],
       f"{pid} equilibrium verdicts")


# ================================================================
# Comparison + driver
# ================================================================
def deep_diff(a, b, path=""):
    """Yield (path, a, b) at every leaf where a and b differ;
    also yield the leaf count compared."""
    if isinstance(a, dict) and isinstance(b, dict):
        n = 0
        for k in sorted(set(a) | set(b), key=str):
            if k not in a or k not in b:
                yield (f"{path}/{k}", a.get(k, "<absent>"),
                       b.get(k, "<absent>"))
            else:
                yield from deep_diff(a[k], b[k], f"{path}/{k}")
            n += 1
        return
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            yield from deep_diff(x, y, f"{path}[{i}]")
        return
    if a != b:
        yield (path, a, b)


def leaf_count(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        return sum(leaf_count(a[k], b[k]) for k in a if k in b)
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return sum(leaf_count(x, y) for x, y in zip(a, b))
    return 1


# ================================================================
# CHECK (4) ANCHORS — generated per printed field class from the
# FIXTURE and the declarations, in the appendix's own print forms
# (round 8), plus the retained prose-dressed anchors. The print
# forms are the appendix's: unicode minus for negative entries,
# signed entries in presented tuples, word forms for counts the
# appendix prints as words.
# ================================================================
_WORDS = {0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four',
          5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine',
          10: 'ten', 11: 'eleven', 12: 'twelve', 13: 'thirteen',
          14: 'fourteen', 15: 'fifteen', 16: 'sixteen',
          17: 'seventeen', 18: 'eighteen', 19: 'nineteen',
          20: 'twenty', 30: 'thirty'}


_ORDINAL = {1: 'first', 2: 'second', 3: 'third'}


def _word(n):
    if n in _WORDS:
        return _WORDS[n]
    if 20 < n < 30:
        return 'twenty-' + _WORDS[n - 20]
    if 30 < n < 40:
        return 'thirty-' + _WORDS[n - 30]
    return str(n)


def _sgn(x):
    return '+%d' % x if x > 0 else ('−%d' % -x if x < 0 else '0')


def _fmt_sigma(s):
    return '((%s, %s), (%s, %s))' % (
        _sgn(s[0][0]), _sgn(s[0][1]), _sgn(s[1][0]), _sgn(s[1][1]))


def _fmt_sides(sides):
    return '(' + ', '.join(
        '(%s, %s)' % (_sgn(a), _sgn(b)) for a, b in sides) + ')'


def _fmt_rec(r):
    return '(' + ', '.join(str(x) for x in r) + ')'


def _fmt_vec(v):
    ars = '(' + ', '.join(str(a) for a in v[1]) + ')'
    return '(%d, %s, %d)' % (v[0], ars, v[2])


def _fmt_nets(nets):
    return '(' + ', '.join(_sgn(x) for x in nets) + ')'


def _fmt_ln(v):
    return '0' if v == 0 else ('%g' % v)


_SUP = {'0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
        '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹'}


def _sup(n):
    return ''.join(_SUP[d] for d in str(n))


def _frac(fr):
    f = Fraction(fr)
    return str(f.numerator) if f.denominator == 1 else \
        '%d/%d' % (f.numerator, f.denominator)


def _distinct_consec(rows):
    out = []
    for r in rows:
        if not out or list(out[-1]) != list(r):
            out.append(r)
    return out


def _joint_label_printed(label):
    label = label.split(' [')[0]
    wmap = {'+': 'positive', '-': 'negative', '0': 'neutral'}

    def rep(m):
        out = ' ' + wmap[m.group(1)]
        if m.group(2):
            out += ' at δ = ' + m.group(3)
        return out
    return re.sub(r" = ([+\-0])( at d=([+\-]?\d+))?", rep, label)


def _exhibit_anchors(F, DECL, kind):
    A = []
    cens = F['census']
    vectors = cens['vectors']
    names = [b['name'] for b in DECL['bodies']]
    n = len(names)
    contact = DECL['contact']
    temp = F['temperature']
    rt = temp['r_table']
    cap = F['capability']
    rows = F['tau']['rows']
    recs = F['standings']['records']

    A.append('%s bodies' % _word(n))
    # declarations — one joint anchor per body in the appendix's
    # print form, so name, N and junctions are bound together
    for b in DECL['bodies']:
        parts = []
        for j in b['junctions']:
            if j['kind'] == 'pair':
                if kind == 'LARGE':
                    parts.append('%s = %s'
                                 % (j['id'], _fmt_sigma(j['sigma'])))
                else:
                    parts.append('%s, σ = %s'
                                 % (j['id'], _fmt_sigma(j['sigma'])))
            else:
                parts.append('the three-sided %s, presented record '
                             '%s, k = %d'
                             % (j['id'], _fmt_sides(j['sides']),
                                j['k']))
        if kind == 'LARGE':
            joined = parts[0] if len(parts) == 1 else \
                ' and '.join(parts)
            A.append('%s (N = %d), %s' % (b['name'], b['N'], joined))
        else:
            joined = parts[0] if len(parts) == 1 else \
                ', '.join(parts[:-1]) + ', and ' + parts[-1]
            A.append('%s (N = %d) carrying %s'
                     % (b['name'], b['N'], joined))
    # contact declarations
    total_contacts = 0
    for name in names:
        ent = sorted(contact[name].items())
        total_contacts += len(ent)
        ticks = [t for t, _ in ent]
        pairs = ['(%d, %d)' % v for _, v in ent]
        if kind == 'SMALL':
            for t, v in ent:
                A.append('%s at tick %d, (%d, %d)'
                         % (name, t, v[0], v[1]))
        elif kind == 'MID' and ticks == list(range(1, len(ent) + 1)):
            A.append('%s: %s at ticks %s'
                     % (name, ', '.join(pairs),
                        ', '.join(str(t) for t in ticks)))
        elif kind == 'LARGE' and ticks == [1, 2, 3]:
            A.append('%s: %s' % (name, ', '.join(pairs)))
        else:
            A.append('%s: %s' % (name, ', '.join(
                '(%d, %d) at tick %d' % (v[0], v[1], t)
                for t, v in ent)))
    # census
    vec_groups = {}
    for name in names:
        v = vectors[name]
        vec_groups.setdefault((v[0], tuple(v[1]), v[2]),
                              []).append(name)
    if kind == 'SMALL':
        for v, ns in vec_groups.items():
            A.append('%s for %s' % (
                _fmt_vec([v[0], list(v[1]), v[2]]),
                ' and '.join(ns)))
        A.append('The census is %s over those classes'
                 % ' and '.join(str(len(ns))
                                for ns in vec_groups.values()))
    else:
        parts = []
        for v, ns in vec_groups.items():
            p = _fmt_vec([v[0], list(v[1]), v[2]])
            if len(ns) > 1 or kind == 'LARGE':
                p += ' ×%d' % len(ns)
            parts.append(p)
        A.append('classes ' + ', '.join(parts))
    A.append('nodes %d, boundary %d' % (cens['tot_N'], cens['tot_B']))
    A.append('6·%d − %d = %d' % (cens['tot_N'],
                                 6 * cens['tot_N'] - cens['tot_B'],
                                 cens['tot_B']))
    # aggregate tick
    A.append('τ_agg = ' + ' → '.join(str(r['tau_agg']) for r in rows))
    if kind == 'SMALL':
        A.append('At tick 1, %s act at index 0 and are zeroed'
                 % ' and '.join(rows[0]['acting']))
        d = rows[1]['tau_agg'] - rows[0]['tau_agg']
        A.append('Δτ_agg = −%d = −2 × %d'
                 % (-d, len(rows[0]['acting'])))
        A.append('at %s of its %s window body-ticks'
                 % (_word(len(temp['budget_lines'])), _word(n * 3)))
        A.append('τ_agg = %d ≠ 0' % rows[-1]['tau_agg'])
    else:
        ac = [len(r['acting']) for r in rows[:3]]

        def aw(i, capfirst=False):
            w = 'none' if ac[i] == 0 else _word(ac[i])
            return w.capitalize() if capfirst else w
        if kind == 'MID':
            A.append('%s junctions act at tick 1 (%s), %s at '
                     'tick 2 (%s, at their second indices), %s at '
                     'tick 3' % (aw(0, True),
                                 ', '.join(rows[0]['acting']),
                                 aw(1), ', '.join(rows[1]['acting']),
                                 aw(2)))
            dser = []
            for r in rows:
                if not dser or dser[-1] != r['tau_agg']:
                    dser.append(r['tau_agg'])
            A.append('τ_agg falls ' + ' → '.join(str(x) for x in dser))
            for b in DECL['bodies']:
                for j in b['junctions']:
                    if j['kind'] == 'ms':
                        A.append('%s is carried through at every '
                                 'tick with τ contribution %d, Δτ = %d'
                                 % (j['id'],
                                    rows[0]['per_junction'][j['id']],
                                    rows[-1]['per_junction'][j['id']]
                                    - rows[0]['per_junction']
                                    [j['id']]))
        else:
            A.append('%s junctions act at tick 1, %s at tick 2, '
                     '%s at tick 3' % (aw(0, True), aw(1), aw(2)))
            A.append('The rest value τ_agg = %d' % rows[-1]['tau_agg'])
            for b in DECL['bodies']:
                for j in b['junctions']:
                    if j['kind'] == 'ms':
                        A.append('%s is carried through, τ '
                                 'contribution %d throughout'
                                 % (j['id'],
                                    rows[0]['per_junction'][j['id']]))
            rest = rows[-1]['per_junction']
            singles, pairs2 = [], []
            for b in DECL['bodies']:
                for j in b['junctions']:
                    if j['kind'] == 'pair':
                        if rest[j['id']] == 1:
                            singles.append(j['id'])
                        elif rest[j['id']] == 2:
                            pairs2.append(j['id'])
            A.append('%s single entries against zero sides (%s), '
                     '%s aligned pair (%s)'
                     % (_word(len(singles)), ', '.join(singles),
                        _word(len(pairs2)), ', '.join(pairs2)))
            for b in DECL['bodies']:
                for j in b['junctions']:
                    if j['kind'] == 'ms':
                        nz = [s for s in j['sides'] if s != (0, 0)]
                        zi = [ix for ix, s in enumerate(j['sides'])
                              if s == (0, 0)]
                        if len(zi) == 1:
                            A.append("and %s's %s entries facing each "
                                     "other across its zero %s side"
                                     % (j['id'], _word(len(nz)),
                                        _ORDINAL[zi[0] + 1]))
    # frequencies
    if kind == 'SMALL':
        st0 = F['standings']['per_tick'][0]
        A.append('(%s)' % ', '.join(
            {'+': '+', '0': '0', '-': '−'}[s] for s in st0))
        st1 = F['standings']['per_tick'][1]
        A.append('(%s) from tick 1' % ', '.join(st1))
        dc = _distinct_consec(recs)
        A.append('Tallies: %s, then %s'
                 % (_fmt_rec(dc[0]), _fmt_rec(dc[1])))
        fl = F['flows']['0->1']
        assert fl == {'+->0': 1, '0->0': 1, '-->0': 1}, fl
        A.append('Flow counts at tick 0→1: +→0 once, −→0 once, '
                 '0→0 once')
    else:
        A.append('tallies ' + ' → '.join(_fmt_rec(r) for r in recs))
    if kind == 'LARGE':
        fr = F['standings']['frequencies']
        groups = []
        for t in ('0', '1', '2'):
            dd = fr[t]
            groups.append('(%s, %s, %s)'
                          % (_frac(dd['positive']),
                             _frac(dd['negative']),
                             _frac(dd['neutral'])))
        A.append('frequencies %s, then %s, then %s' % tuple(groups))
    flow_parts = [_fmt_nets(tuple(recs[i + 1][k] - recs[i][k]
                                  for k in range(3)))
                  for i in range(3)]
    if kind == 'SMALL':
        A.append('net flows %s' % flow_parts[0])
        later = [F['flows'][k] for k in ('1->2', '2->3')]
        assert all(set(d) == {'0->0'} for d in later), later
        A.append('thereafter Φ = 0')
    else:
        A.append('Net flows: ' + ', '.join(flow_parts))
    if kind == 'MID':
        assert F['flows']['0->1']['+->-'] == 1
        A.append('include one +→− transition')
        # the multi-sided carrier's pair junction loses its
        # opposed pair first (printed in the frequencies prose)
        for b in DECL['bodies']:
            if any(j['kind'] == 'ms' for j in b['junctions']):
                for j in b['junctions']:
                    if j['kind'] == 'pair' and \
                            all(x != 0 for x in j['sigma'][0]):
                        A.append('loses its (%s, %s) pair first'
                                 % (_sgn(j['sigma'][0][0]),
                                    _sgn(j['sigma'][0][1])))
    # joint counts
    joints = F['joints']
    assert len({j['frequency'] for j in joints}) == 1
    for j in joints:
        lab = _joint_label_printed(j['label'])
        if kind == 'SMALL':
            A.append('%s = %d, frequency %s'
                     % (lab, j['J'], j['frequency']))
        else:
            A.append('%s = %d' % (lab, j['J']))
    if kind == 'MID':
        A.append('each of frequency %s' % joints[0]['frequency'])
    if kind == 'LARGE':
        A.append('each frequency %s' % joints[0]['frequency'])
    # capability
    profs = {}
    for name in names:
        profs.setdefault(tuple(cap['profiles'][name]),
                         []).append(name)
    if kind == 'SMALL':
        for b in DECL['bodies']:
            entries = []
            for j in b['junctions']:
                if j['kind'] == 'pair':
                    entries += [j['sigma'][0][0], j['sigma'][0][1],
                                j['sigma'][1][0], j['sigma'][1][1]]
            A.append('%s presents %s, M = %s'
                     % (b['name'],
                        '(' + ', '.join(_sgn(x) for x in entries) + ')',
                        _fmt_rec(cap['profiles'][b['name']])))
        bp = cap['by_profile']
        s11 = bp['(1, 1)']['sizes']
        s20 = bp['(2, 0)']['sizes']
        A.append('responder at %d of the %d declared encounter '
                 'kinds, initiator at %d, spin-presenter at %d; '
                 'the surplus rule gives %d, %d, %d'
                 % (s11['rule1_cover']['responder'],
                    len(A4.TAXONOMY),
                    s11['rule1_cover']['initiator'],
                    s11['rule1_cover']['spin-presenter'],
                    s11['rule2_surplus']['responder'],
                    s11['rule2_surplus']['initiator'],
                    s11['rule2_surplus']['spin-presenter']))
        A.append('At M = (2, 0) the rules give (%d, %d, %d) and '
                 '(%d, %d, %d)'
                 % (s20['rule1_cover']['responder'],
                    s20['rule1_cover']['initiator'],
                    s20['rule1_cover']['spin-presenter'],
                    s20['rule2_surplus']['responder'],
                    s20['rule2_surplus']['initiator'],
                    s20['rule2_surplus']['spin-presenter']))
        same = profs[(1, 1)]
        jcs = {b['name']: len(b['junctions'])
               for b in DECL['bodies']}
        nmap = {b['name']: b['N'] for b in DECL['bodies']}
        A.append('(N = %d against %d, %s junction against %s)'
                 % (nmap[same[0]], nmap[same[1]],
                    _word(jcs[same[0]]), _word(jcs[same[1]])))
    else:
        A.append('profiles — ' + '; '.join(
            '%s: %s' % (_fmt_rec(p), ', '.join(ns))
            for p, ns in profs.items()))
        if kind == 'MID':
            cards = []
            for p in profs:
                s = cap['by_profile'][str(p)]['sizes']
                cards.append('(%d, %d, %d; %d, %d, %d)'
                             % (s['rule1_cover']['responder'],
                                s['rule1_cover']['initiator'],
                                s['rule1_cover']['spin-presenter'],
                                s['rule2_surplus']['responder'],
                                s['rule2_surplus']['initiator'],
                                s['rule2_surplus']['spin-presenter']))
            A.append(', '.join(cards))
            # the multi-sided carrier's entry contributions
            for b in DECL['bodies']:
                if any(j['kind'] == 'ms' for j in b['junctions']):
                    for j in b['junctions']:
                        if j['kind'] == 'pair':
                            ent = [j['sigma'][0][0], j['sigma'][0][1],
                                   j['sigma'][1][0], j['sigma'][1][1]]
                            A.append('%s contributes %s'
                                     % (j['id'], '(' + ', '.join(
                                         _sgn(x) for x in ent) + ')'))
                        else:
                            ent = [x for side in j['sides']
                                   for x in side]
                            A.append("%s contributes its presented "
                                     "record's entries %s"
                                     % (j['id'], '(' + ', '.join(
                                         _sgn(x) for x in ent) + ')'))
        else:
            for p in profs:
                s = cap['by_profile'][str(p)]['sizes']
                A.append('%s: (%d, %d, %d; %d, %d, %d)'
                         % (_fmt_rec(p),
                            s['rule1_cover']['responder'],
                            s['rule1_cover']['initiator'],
                            s['rule1_cover']['spin-presenter'],
                            s['rule2_surplus']['responder'],
                            s['rule2_surplus']['initiator'],
                            s['rule2_surplus']['spin-presenter']))
            r2 = cap['by_profile']['(0, 0)']['sets'][
                'rule2_surplus']['responder']
            if len(r2) == 2:
                A.append('at the encounter kinds %s and %s exactly'
                         % (_fmt_rec(r2[0]), _fmt_rec(r2[1])))
    # population temperature
    R = temp['R']
    if kind == 'SMALL':
        for line in temp['budget_lines']:
            A.append('%s books %d at tick %d'
                     % (line['body'], line['r'], line['tick']))
        A.append('; '.join('3 + %d + %d + %d = 100'
                           % (l['v2'], l['s2'], l['r'])
                           for l in temp['budget_lines']))
        A.append('R(P, W) = %d over %d body-ticks' % (R, n * 3))
        A.append('D(P, W) = T_ledger(P, W) = %s' % temp['D'])
        A.append('The local densities are '
                 + ', '.join(temp['locals'][b] for b in names))
    else:
        parts = []
        for name in names:
            vals = [str(rt[name][str(t)]) if t in contact[name]
                    else '—' for t in (1, 2, 3)]
            parts.append('%s: %s' % (name, ', '.join(vals)))
        A.append('; '.join(parts))
        A.append('R(P, W) = %d over %d body-ticks' % (R, n * 3))
        if kind == 'MID':
            A.append('D(P, W) = %s' % temp['D'])
            A.append('Local densities: '
                     + ', '.join(temp['locals'][b] for b in names))
        else:
            A.append('D(P, W) = %d/%d = %s' % (R, n * 3, temp['D']))
            locs = temp['locals']
            mn = min(locs.values(), key=lambda s: Fraction(s))
            mx = max(locs.values(), key=lambda s: Fraction(s))
            A.append('Local densities range from %s (%s) to %s (%s)'
                     % (mn, ', '.join(b for b in names
                                      if locs[b] == mn),
                        mx, ', '.join(b for b in names
                                      if locs[b] == mx)))
            A.append('%s contact body-ticks of %d'
                     % (_word(total_contacts).capitalize(), n * 3))
            A.append('books at %s of %s window body-ticks'
                     % (_word(total_contacts), _word(n * 3)))
            for name in names:
                tk = sorted(contact[name])
                if tk[0] != 1:
                    A.append('%s books %s'
                             % (name, ' and '.join(
                                 str(rt[name][str(t)]) for t in tk)))
                if tuple(cap['profiles'][name]) == (0, 0):
                    A.append('%s presents nothing — M = %s'
                             % (name,
                                _fmt_rec(cap['profiles'][name])))
            absent = [(nm, t) for nm in names for t in (1, 2, 3)
                      if t not in contact[nm]]
            if absent:
                A.append('%s has no occasion at tick %d' % absent[0])
                for nm, t in absent[1:]:
                    A.append('%s none at tick %d' % (nm, t))
    A.append('their mean is %s' % temp['D'])
    # Omega threads and equilibrium inputs
    om = F['omega']
    seen = []
    for r, o in zip(om['records'], om['omegas']):
        if (list(r), o) not in [(list(a), b) for a, b in seen]:
            seen.append((r, o))
    if kind == 'SMALL':
        A.append('the visited standings records are %s with Ω = %d '
                 'and %s with Ω = %d'
                 % (_fmt_rec(seen[0][0]), seen[0][1],
                    _fmt_rec(seen[1][0]), seen[1][1]))
        A.append('Ω is maximal at %s' % _fmt_rec(om['argmax'][0]))
        stat = [e['tick'] for e in F['equilibrium']
                if e['stationary_E1']]
        if stat:
            A.append('at its fixed point from tick %d' % stat[0])
    else:
        for r, o in seen:
            A.append('%s, Ω = %d' % (_fmt_rec(r), o))
        cnt = math.comb(n + 2, 2)
        A.append("the population's %d records" % cnt)
        if kind == 'MID':
            A.append('Ω along the trajectory goes '
                     + ' → '.join(str(o) for _, o in seen))
        else:
            A.append("The maximum over the population's %d records "
                     "is %d at %s"
                     % (cnt, om['omega_max'],
                        _fmt_rec(om['argmax'][0])))
            stat = [e['tick'] for e in F['equilibrium']
                    if e['stationary_E1']]
            if stat:
                A.append('no visited record is stationary before '
                         'tick %d' % stat[0])
    ln_seen = []
    for r, lv in zip(om['records'], om['ln_omegas']):
        if tuple(r) not in [tuple(a) for a, _ in ln_seen]:
            ln_seen.append((r, lv))
    if kind == 'SMALL':
        A.append('S/k_B = %s at tick 0 and 0 thereafter'
                 % _fmt_ln(ln_seen[0][1]))
    else:
        A.append('S/k_B = ' + ', '.join(_fmt_ln(lv)
                                        for _, lv in ln_seen))
    prec = _distinct_consec(om['phi_records'])
    poms = []
    prev = None
    for r, o in zip(om['phi_records'], om['phi_omegas']):
        if prev is None or list(r) != list(prev):
            poms.append(o)
        prev = r
    if kind == 'SMALL':
        A.append('The φ thread is %s, Ω_φ = %s'
                 % (' → '.join(_fmt_rec(r) for r in prec),
                    ' → '.join(str(o) for o in poms)))
    else:
        A.append('The φ thread is %s, Ω_φ = %s'
                 % (' → '.join(_fmt_rec(r) for r in prec),
                    ', '.join(str(o) for o in poms)))
    A.append('3%s = %d' % (_sup(n), 3 ** n))
    if kind == 'SMALL':
        A.append('over all %s records of the population'
                 % _word(math.comb(n + 2, 2)))
    return A


def generated_anchors():
    out = []
    for F, DECL, kind in ((FIXTURE['E-SMALL'], SMALL, 'SMALL'),
                          (FIXTURE['E-MID'], MID, 'MID'),
                          (FIXTURE['E-LARGE'], LARGE, 'LARGE')):
        out += _exhibit_anchors(F, DECL, kind)
    # conventions-paragraph bindings (appendix-wide printings)
    lens = {len(side) for D in (SMALL, MID, LARGE)
            for b in D['bodies'] for j in b['junctions']
            if j['kind'] == 'pair' for side in j['sigma']}
    assert len(lens) == 1, lens
    out.append('port vectors of length %d' % lens.pop())
    out.append('of the %d declared encounter kinds at which the '
               'body plays the role' % len(A4.TAXONOMY))
    # the cross-exhibit profile-sharing sentence (printed at
    # E-MID): each E-MID profile with the exhibits sharing it
    prof_sets = {pid: {tuple(p) for p in
                       FIXTURE[pid]['capability']['profiles']
                       .values()}
                 for pid in FIXTURE}
    shared = []
    for p in sorted(prof_sets['E-MID']):
        others = [pid for pid in ('E-SMALL', 'E-LARGE')
                  if p in prof_sets[pid]]
        if others:
            shared.append('%s with %s'
                          % (_fmt_rec(p), ' and '.join(others)))
    if shared:
        out.append(', '.join(shared))
    return out


# Retained anchors: prose-dressed values whose print form is a
# sentence rather than a field — the verdict sentences (their
# inputs are bound by the generated anchors and recomputed by
# checks (2) and (3)), the no-equilibrium sentence, and the
# E-SMALL marginalization and window split.
ANCHORS = [
    "the tick-0 record satisfies (E2) and not (E1); the rest "
    "record satisfies (E1) and not (E2)",
    "the tick-1 record satisfies (E2) and not (E1) — the "
    "trajectory visits the balanced record without resting "
    "there; the rest record satisfies (E1) and not (E2)",
    "the rest record (0, 0, 12) satisfies (E1) and fails (E2)",
    "J_W(S1 positive) = 1",
    "splits over the window as 1 + 0",
    "No visited record is an equilibrium",
]


def main():
    print("=" * 70)
    print("A.15 — THE SPINE EXHIBITS (Appendix F): every printed")
    print("number recomputed from the declarations, twice, and")
    print("compared against the printed fixture")
    print("=" * 70)

    results = {}
    for pop in P.POPULATIONS:
        results[pop["id"]] = run_population(pop)
    report("(1) compute path: the internal assertion battery "
           "holds on all three exhibits", not FAIL,
           f"{EXPECT_COUNT[0]} assertions, failures: {len(FAIL)}")

    normalized = json.loads(json.dumps(results, default=str))
    diffs = list(deep_diff(normalized, FIXTURE))
    report("(2) compute path against the printed fixture: every "
           "field agrees", not diffs,
           f"{leaf_count(normalized, FIXTURE)} leaves compared, "
           f"mismatches: {len(diffs)}"
           + (f"; first: {diffs[0]}" if diffs else ""))

    for pop in P.POPULATIONS:
        verify_pop(pop, normalized[pop["id"]])
    report("(3) verify path: every field re-derived from the "
           "declarations alone agrees with the compute path",
           not VFAIL,
           f"{VCHECKS[0]} fields compared, mismatches: {len(VFAIL)}"
           + (f"; first: {VFAIL[0]}" if VFAIL else ""))

    paper = HERE.parent / "Paper_12_v4.md"
    anchors_ran = False
    if paper.exists():
        text = paper.read_text(encoding="utf-8")
        # line-anchored on the appendix's exact heading: the bare
        # prefix also occurs inside embedded source texts (Paper
        # 11's own appendices, Appendix C), which are not this
        # appendix's span.
        start = text.find("\n## Appendix F. The Spine:")
        end = text.find("\n## ", start + 10) if start >= 0 else -1
        span = text[start:end] if start >= 0 and end > start else ""
        try:
            anchors = ANCHORS + generated_anchors()
            gen_error = None
        except Exception as exc:
            # fixture-shape drift in the generator: report it as
            # this check's failure, with the drift named — the
            # script must not die on the drift it exists to catch
            anchors, gen_error = [], exc
        missing = [a for a in anchors if a not in span]
        anchors_ran = gen_error is None
        report("(4) transcription anchors: the appendix's printed "
               "values stand in the paper's Appendix F span as the "
               "fixture carries them — every printed field class "
               "bound (generated anchors per class; retained "
               "anchors for the prose-dressed values)",
               gen_error is None and not missing,
               (f"anchor generation failed on fixture drift: "
                f"{gen_error!r}" if gen_error is not None else
                f"{len(anchors) - len(missing)}/{len(anchors)} "
                f"anchors present ({len(anchors) - len(ANCHORS)} "
                f"generated, {len(ANCHORS)} retained)")
               + (f"; missing: {missing}" if missing else ""))
    else:
        print("  [NOTE] Paper_12_v4.md not present beside the "
              "scripts folder; transcription anchors skipped "
              "(the fixture comparisons above are unaffected)")

    # (5) prose numbers outside the fixture fields
    from math import factorial
    PRINTED_RECORDS = {"E-SMALL": 10, "E-MID": 28, "E-LARGE": 91}
    PRINTED_NETS = {"E-SMALL": [(-1, -1, 2), (0, 0, 0), (0, 0, 0)],
                    "E-MID": [(-2, 0, 2), (-2, -2, 4), (0, 0, 0)],
                    "E-LARGE": [(-5, -1, 6), (-2, -2, 4), (0, 0, 0)]}
    prose_ok = True
    for pop in P.POPULATIONS:
        pid = pop["id"]
        n = len(pop["bodies"])
        tot = 0
        cnt = 0
        mx = 0
        for a in range(n + 1):
            for b in range(n + 1 - a):
                c = n - a - b
                om = factorial(n) // (factorial(a) * factorial(b)
                                      * factorial(c))
                tot += om
                cnt += 1
                mx = max(mx, om)
        prose_ok = prose_ok and cnt == PRINTED_RECORDS[pid] \
            and tot == 3 ** n \
            and mx == results[pid]["omega"]["omega_max"]
        if pid in PRINTED_NETS:
            tallies = [tuple(r) for r in results[pid]["standings"]["records"]]
            nets = [tuple(y - x for x, y in zip(tallies[i], tallies[i + 1]))
                    for i in range(len(tallies) - 1)]
            prose_ok = prose_ok and nets == PRINTED_NETS[pid]
    prose_ok = prose_ok and len(A4.TAXONOMY) == 15
    report("(5) prose numbers outside the fixture fields: the "
           "all-records counts (10, 28, 91) and totals (3^n) by full "
           "enumeration, the printed net flows as tally differences, "
           "and the encounter-taxonomy denominator (15, from A.4's "
           "declared taxonomy)", prose_ok)

    print("=" * 70)
    if FAILURES:
        print(f"A.15 VERDICT: FAIL — {FAILURES}")
        return 1
    print("A.15 VERDICT: PASS — the Spine exhibits' every printed "
          "number is recomputed from the declarations by two "
          "independent implementations, both agree with the "
          "printed fixture"
          + (", and check (4) binds the fixture to "
             "the appendix's printed text across every printed "
             "field class." if anchors_ran else
             " (check (4) was skipped: no paper file beside the "
             "scripts folder)."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
