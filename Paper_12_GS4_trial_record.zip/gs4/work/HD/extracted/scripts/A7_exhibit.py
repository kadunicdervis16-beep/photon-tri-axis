#!/usr/bin/env python3
"""A.7 — Worked exhibit: one population, carried end to end (Appendix D).

Machine companion to Paper 12 Appendix D. Computes EVERY derived number
printed in Appendix D from the exhibit's declared data, using Paper 11's
operator T exactly as Paper 12 §4 states it — the T implementation below
is copied from A2_parallel_tick.py, conventions unchanged:

  T (Paper 11 §7.5, via Paper 12 §4): a junction's local state is a pair
  of port vectors (A, B). Index k is ADMISSIBLE iff A[k] = -B[k] != 0.
  T zeroes the CANONICALLY FIRST admissible pair; if none, T is the
  identity. tau(sigma) = sum of squares of all entries; each action
  drops tau by exactly 2 (admissible entries are unit port values).

WHAT IS COMPUTED, in Appendix D's step order:
  (a) §3 census over count-classes (N, junction arities, B): identities (II)
      and (III), each checked by the grouped route and the direct
      route; (I) checked as a partition of the named bodies.
  (b) §4 trajectory, ticks 0-3: per-junction sigma and tau, tau_agg,
      acting-junction count and Delta tau_agg = -2 x acting at every
      tick; order-independence of tick 1 by pairwise commutativity
      (every unordered pair of junctions, both orders) plus a
      deterministic set of shuffled application orders (identity,
      reverse, all rotations, and seeded shuffles) — 12! orders are
      NOT enumerated, and this script does not claim they are;
      the (p, c) decomposition by visited-state enumeration.
  (c) §5/§9: the live/resting feature census of Definition 5.1
      (live = the body's junction has an admissible index) at every
      tick, flow counts F per tick, identities (9.1)/(9.2), net flows
      Phi per tick from eq. (9.3), and record-visit frequencies over
      the trajectory window ticks 0-3 as exact Fractions.
  (d) §6 capability, in A.4's formulation as far as this exhibit's
      data supports it: a body's presented tuple at a tick is the
      concatenation of its junction's two port vectors (A then B);
      its presented-count profile is M = (n+, n-) counted from that
      tuple, exactly A.4's profile map. Capability sets are computed
      under BOTH of A.4's representative outcome rules over A.4's
      declared finite test taxonomy (profiles (e+, e-) with
      e+ + e- <= 4), and the factoring check is the pairwise statement:
      at every tick, any two bodies of the exhibit with equal profiles
      have equal capability sets under both rules. What is NOT checked
      here: Paper 11 §8.6 itself (the cited premise that encounter
      outcomes factor through M) — see the coverage disclosure.
  (e) §7: R(P, W), D(P, W) as a reduced Fraction, the twelve local
      densities, and the (7.4) mean-of-locals identity, all over the
      declared window W = ticks 1-3, from the declared reconcile
      table; every booked value checked against the (7.2) cap of 97.
  (f) §8: the full assignment-count table C(12, k), k = 0..12, its
      total against 2^12, the polarized share against eq. (8.6) at
      n = 12, and the non-polarized share against eq. (8.7) at
      n = 12 — all exact Fractions.
  (g) §9: (E1) and (E2) for EACH distinct record the trajectory
      visited. (E1) is read off the computed net flows of the tick
      leaving the record's first occurrence; for the record standing
      at the final tick, a confirming tick (one further aggregate
      tick, computed, outside W and outside the frequency window) is
      also evaluated and must agree. (E2) compares the record's
      assignment count against the maximum over ALL records of the
      same census size and class structure (the full table of (f)).

TRANSCRIPTION SEAM (Step 8): if the file Paper_12_v4.md exists beside
this script's parent directory when the script runs, its Appendix D
is parsed and the declared data asserted to match this script's
embedded records exactly. The parse format, which Appendix D's
declared-data tables follow (mirroring banked/worked_miniature.md):
  - the appendix starts at a line beginning "## Appendix D" and runs
    to the next line beginning "## " or to end of file;
  - the declared-bodies table is the table whose header row's first
    cell is "body" and which has cells "sigma at tick 0: A" and
    "sigma at tick 0: B" (written with the Greek letter in the paper;
    see SIGMA_A_HEADER / SIGMA_B_HEADER below); each data row gives,
    in order: body name, nodes N, junctions (junction arities), the consumed
    total, the boundary count expression (its last integer is B),
    the junction name, and the two port vectors in "(1, 1)" style
    (minus signs may be ASCII "-" or the paper's "−", U+2212, which
    the parse normalizes);
  - the reconcile table is the table whose header row's first cell is
    "tick" and whose remaining header cells are exactly the body
    names in order; each data row is a tick number followed by the
    booked counts in body order (a trailing body-total row, whose
    first cell is not a tick number, is ignored by the parse).
  If the file or the appendix is absent, the seam leg is SKIPPED and
  a clear note is printed (it is a skip, not a pass).

PRINTED-ORACLE LEG (Step 9, added at v2 after the independent audit's
charge C-1): the seam alone leaves Appendix D's PRINTED DERIVED
values unchecked against the paper — a typo in a printed density or
assignment count would pass. Step 9 therefore parses the appendix's
printed derived values in their printed forms — the census pair and
grouped totals, the arrangement count, the tick-1 sigma-after table,
the tau_agg series and deltas, the Step-3 census table, visit
frequencies and occupancies, the Step-4 profile table and its four
counts (rule disagreements, equal-profile pairs, distinct-sigma
pairs, distinct capability assignments), the Step-4 prose
profile-class censuses, the Step 5 window declaration (the tick
range, |W|, |P|, and the body-ticks product and value), the
reconcile body-total row, the R sum, every printed D(P, W)
fraction, the local-density list, the mean-of-locals value, the
resting/acting witness counts, the Omega table, its total,
maximum, shares, and the (E1)/(E2) verdict table including the
(E1) cells' printed flow values for the (12, 0) and (6, 6) rows,
plus the LD claim lines' printed values — the LD.3 net-flow
triples, the LD.4 counts (equal-profile pairs, violations,
distinct-sigma pairs, distinct assignments) — and the closing
"What follows" paragraph's Omega path and tau_agg series — and
compares each against the recomputation of Steps 1-7. A printed
form that is ABSENT fails the leg (a missing oracle), as does any
disagreement, with the printed and computed values as witness. This
is A.6's oracle-under-test standard applied to the exhibit.
Residue left to the eyeball, disclosed: word-form numerals in
narrative sentences (e.g. the "eight resting bodies" of Step 5's
caution, whose bold-form totals ARE parsed), and per-line
arithmetic echoes in Step 2/3 narratives beyond the parsed forms.

NO DERIVED VALUE IS HARDCODED: every number this script prints after
the declared data is computed from the records below. Skeleton checks
(the trajectory's resting structure, the balanced middle record, the
burn-count split) are asserted as relations among computed quantities
and the declared parameters (|P|, |W|), never as literal tables.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: §§3-9 of Paper 12 over arbitrary finite
      populations.
  (2) Verified domain: the single declared 12-body exhibit population
      of Appendix D (one pairwise junction per body, junction arity 2,
      port-vector length 2), its ticks 0-3,
      its window W = ticks 1-3, A.4's two representative outcome
      rules and finite test taxonomy for the capability leg.
  (3) Map: native body -> its exhibit record (N, junction arities, sigma);
      native presented-count profile -> (n+, n-) counted from the
      body's presented tuple (junction A-vector then B-vector);
      native census record -> the (live, resting) feature record.
  (4) Preserved: every identity Appendix D prints — census totals,
      the Delta tau accounting, flow bookkeeping, the (7.4) mean,
      the assignment counts and shares, the (E1)/(E2) verdicts — is
      recomputed from the records by the definitions' own routes;
      and the printed forms of those values in the paper are parsed
      and compared in Step 9 (missing-or-disagreeing print fails).
  (5) Outside the machine check: Paper 11 §4.3 (disjointness, cited),
      Paper 11 §7.5 (T's properties, cited — the implementation is
      A.2's, whose own battery checks them), Paper 11 §8.6 (the
      capability premise, cited exactly as in A.4), and any claim
      about populations other than this exhibit.

INPUT_PROVENANCE:
  - The 12 bodies B1..B12, their node counts N in {2, 3}, the single
    pairwise junction per body (junction arity 2, port-vector
    length 2), and the tick-0 local states sigma:
    class=paper-defined exhibit data (declared in Appendix D; the
    only hardcoded population data in this script).
  - The reconcile table r_b(tau) for W = ticks 1-3 (12 x 3 booked
    counts): class=paper-defined exhibit data (declared in
    Appendix D, in the manner of §7.5's declared table; deliberately
    NOT a function of junction action — Step 5 computes witnesses:
    positive values at resting body-ticks and zeros at acting ones).
  - T's definition, admissibility, tau and the per-action drop of 2:
    class=cited-paper (Paper 11 §7.5, as restated in Paper 12 §4;
    implementation copied from A.2).
  - B = 6N - sum_j k_j: class=cited-paper (Paper 11 §4.1, at
    source; restated in Paper 12 §3).
  - The reconcile cap r_b(tau) <= 97 at a contact tick, eq. (7.2):
    class=cited-paper (Paper 10 eq. (2.4) accounting, via §7.2).
  - Live/resting feature classes: class=paper-defined (Definition
    5.1 feature census, as in the worked miniature).
  - Presented-count profile M = (n+, n-) and the outcome factors
    through it: class=cited-paper (Paper 11 §8.6 — the theorem's
    one premise, inherited; copied from A.4).
  - A.4's two outcome rules: class=arbitrary-representative
    (copied from A.4; two disagreeing members of the
    profile-factoring class Paper 11 §8.6 licenses).
  - A.4's test taxonomy (e+ + e- <= 4): class=control (copied
    from A.4; declared finite test set standing in for §8's
    taxonomy).
  - Roles {responder, initiator, spin-presenter}: responder and
    initiator class=cited-paper (Paper 11's relational
    active/passive roles read off the encounter; copied from
    A.4); spin-presenter class=paper-defined (Paper 12 §6.3's
    worked case).
  - Window W = ticks 1-3 and trajectory window ticks 0-3:
    class=paper-defined exhibit data (declared in Appendix D).
  - Shuffle seed for the deterministic order set: 
    class=arbitrary-representative (test design only; the identity,
    reverse and rotation orders are seed-free).
  - Appendix D declared-data tables in Paper_12_v4.md, when present:
    class=paper-defined (the transcription under test in Step 8;
    parsed at run time, never used in any computation).
  - Appendix D's printed derived values, when present:
    class=paper-defined (the oracle under test in Step 9; parsed at
    run time, never used in any computation).

V4 NOTE (2026-10-26, disclosed): default paper target is now the v4 assembly; no check logic changed.
"""
import itertools
import random
import re
import sys
from collections import Counter
from fractions import Fraction
from math import comb, factorial
from pathlib import Path

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Paper 11's operator T, exactly as Paper 12 §4 states it
# (copied from A2_parallel_tick.py).
# ---------------------------------------------------------------------------

def admissible_indices(sigma):
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def tau(sigma):
    A, B = sigma
    return sum(a * a for a in A) + sum(b * b for b in B)


def T(sigma):
    """Zero the canonically first admissible pair; identity if none."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[0]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


def parallel_tick(state):
    return tuple(T(s) for s in state)


def sequential_tick(state, order):
    st = list(state)
    for j in order:
        st[j] = T(st[j])
    return tuple(st)


def sequential_subset(state, indices_in_order):
    st = list(state)
    for j in indices_in_order:
        st[j] = T(st[j])
    return tuple(st)


def tau_agg(state):
    return sum(tau(s) for s in state)


def acting_indices(state):
    return [j for j, s in enumerate(state) if admissible_indices(s)]


# ---------------------------------------------------------------------------
# Exhibit data (DECLARED — the only hardcoded data; see INPUT_PROVENANCE)
# ---------------------------------------------------------------------------

BODIES = ["B1", "B2", "B3", "B4", "B5", "B6",
          "B7", "B8", "B9", "B10", "B11", "B12"]
NODES = {"B1": 2, "B2": 3, "B3": 2, "B4": 3, "B5": 2, "B6": 2,
         "B7": 3, "B8": 2, "B9": 3, "B10": 2, "B11": 3, "B12": 2}
JUNCTION_ARITIES = {b: (2,) for b in BODIES}   # one pairwise junction each
JUNCTIONS = {b: f"J{i + 1}" for i, b in enumerate(BODIES)}
SIGMA0 = (                            # junction local states at tick 0
    ((1, 1), (-1, -1)),     # B1
    ((1, -1), (-1, 1)),     # B2
    ((-1, -1), (1, 1)),     # B3
    ((-1, 1), (1, -1)),     # B4
    ((1, 1), (-1, -1)),     # B5
    ((1, -1), (-1, 1)),     # B6
    ((1, 0), (-1, 1)),      # B7
    ((1, 1), (-1, 0)),      # B8
    ((-1, 0), (1, -1)),     # B9
    ((-1, -1), (1, 0)),     # B10
    ((1, 0), (-1, 0)),      # B11
    ((-1, 0), (1, 0)),      # B12
)
R_BOOKED = {  # r_b(tick): declared booked reconcile counts (ledger data)
    1: {"B1": 0, "B2": 3, "B3": 1, "B4": 0, "B5": 2, "B6": 4,
        "B7": 0, "B8": 2, "B9": 1, "B10": 0, "B11": 3, "B12": 2},
    2: {"B1": 2, "B2": 0, "B3": 1, "B4": 0, "B5": 3, "B6": 0,
        "B7": 5, "B8": 0, "B9": 2, "B10": 1, "B11": 0, "B12": 4},
    3: {"B1": 1, "B2": 0, "B3": 4, "B4": 2, "B5": 0, "B6": 1,
        "B7": 2, "B8": 3, "B9": 0, "B10": 1, "B11": 0, "B12": 5},
}
WINDOW = [1, 2, 3]          # W = ticks 1-3 (§7)
TRAJ_TICKS = [0, 1, 2, 3]   # trajectory window for records/frequencies
SHUFFLE_SEED = 20261025
N_SHUFFLES = 200

SIGMA_A_HEADER = "σ at tick 0: A"
SIGMA_B_HEADER = "σ at tick 0: B"


def boundary(b):
    return 6 * NODES[b] - sum(JUNCTION_ARITIES[b])


def body_class(sigma):
    return "L" if admissible_indices(sigma) else "R"


def fmt_vec(v):
    return "(" + ", ".join(str(x) for x in v) + ")"


def fmt_sigma(s):
    return f"A={fmt_vec(s[0])}, B={fmt_vec(s[1])}"


# ---------------------------------------------------------------------------
# §6 capability, in A.4's formulation (profile map, rules, taxonomy)
# ---------------------------------------------------------------------------

ROLES = ("responder", "initiator", "spin-presenter")
TAXONOMY = [(ep, em) for ep in range(5) for em in range(5) if ep + em <= 4]


def presented_tuple(sigma):
    """The body's presented tuple at a tick: its junction's A-vector
    followed by its B-vector."""
    A, B = sigma
    return tuple(A) + tuple(B)


def profile(presented):
    """A.4's presented-count map M = (n+, n-), verbatim in effect."""
    return (sum(1 for v in presented if v == 1),
            sum(1 for v in presented if v == -1))


def outcome_rule_1(MG, ME):
    """A.4 rule 1 (complementary-cover), copied from A4_capability.py."""
    np_, nm_ = MG
    ep, em = ME
    c = min(np_, em) + min(nm_, ep)
    s = min(np_, ep) + min(nm_, em)
    roles = set()
    if c >= 1:
        roles.add("responder")
        if (np_ - nm_) >= (ep - em):
            roles.add("initiator")
    if c >= 1 and s == 0:
        roles.add("spin-presenter")
    return roles


def outcome_rule_2(MG, ME):
    """A.4 rule 2 (surplus/tension), copied from A4_capability.py."""
    np_, nm_ = MG
    ep, em = ME
    net = (np_ - nm_) + (ep - em)
    total = np_ + nm_ + ep + em
    roles = set()
    if net == 0 and total >= 2:
        roles.add("responder")
        roles.add("spin-presenter")
    if net > 0 and np_ > nm_:
        roles.add("initiator")
    return roles


RULES = {"rule1_cover": outcome_rule_1, "rule2_surplus": outcome_rule_2}


def capability(sigma, rule, taxonomy=TAXONOMY):
    """Cap at one tick as {role: frozenset of encounter kinds}, computed
    ONLY from the presented-count profile of sigma — the rest of the
    body record is never consulted, which is what Step 4 probes."""
    MG = profile(presented_tuple(sigma))
    cap = {r: set() for r in ROLES}
    for E in taxonomy:
        for r in rule(MG, E):
            cap[r].add(E)
    return {r: frozenset(s) for r, s in cap.items()}


# ---------------------------------------------------------------------------
# Appendix D transcription-seam parse (Step 8)
# ---------------------------------------------------------------------------

def strip_md(cell):
    return cell.replace("**", "").strip()


def parse_tables(lines):
    """Yield markdown tables as lists of rows (lists of stripped cells)."""
    tables, cur = [], []
    for ln in lines:
        s = ln.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [strip_md(c) for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                continue
            cur.append(cells)
        else:
            if cur:
                tables.append(cur)
                cur = []
    if cur:
        tables.append(cur)
    return tables


def appendix_lines(text):
    """Lines of Appendix D, or None if the appendix is absent."""
    lines = text.splitlines()
    start = None
    for i, ln in enumerate(lines):
        if ln.startswith("## Appendix D"):
            start = i
            break
    if start is None:
        return None
    out = []
    for ln in lines[start + 1:]:
        if ln.startswith("## "):
            break
        out.append(ln)
    return out


def parse_appendix_d(text):
    """Parse the declared-data tables of Appendix D. Returns
    (bodies_rows, reconcile) where bodies_rows maps body name ->
    (N, junction arities, sum_k, B, A, Bvec) and reconcile maps tick ->
    {body: count}. Raises ValueError on a malformed appendix."""
    lines = appendix_lines(text)
    if lines is None:
        return None
    tables = parse_tables(lines)
    bodies_rows = None
    reconcile = None
    for tbl in tables:
        if not tbl:
            continue
        header = tbl[0]
        if header[0] == "body" and SIGMA_A_HEADER in header \
                and SIGMA_B_HEADER in header:
            ia = header.index(SIGMA_A_HEADER)
            ib = header.index(SIGMA_B_HEADER)
            bodies_rows = {}
            for row in tbl[1:]:
                if not re.fullmatch(r"B\d+", row[0]):
                    continue
                ints = lambda cell: tuple(
                    int(x) for x in re.findall(
                        r"-?\d+", cell.replace("−", "-")))
                bodies_rows[row[0]] = (
                    int(row[1]),               # nodes N
                    ints(row[2]),              # junction arities
                    int(row[3]),               # sum_j k_j
                    ints(row[4])[-1],          # B (last integer)
                    ints(row[ia]),             # sigma A
                    ints(row[ib]),             # sigma B
                )
        if header[0] == "tick" and header[1:] == BODIES:
            reconcile = {}
            for row in tbl[1:]:
                if not re.fullmatch(r"\d+", row[0]):
                    continue  # e.g. the body-total row
                reconcile[int(row[0])] = {
                    b: int(row[1 + i]) for i, b in enumerate(BODIES)}
    if bodies_rows is None:
        raise ValueError("declared-bodies table not found in Appendix D")
    if reconcile is None:
        raise ValueError("reconcile table not found in Appendix D")
    return bodies_rows, reconcile


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    n = len(BODIES)
    print("=" * 72)
    print("A.7 — WORKED EXHIBIT: ONE POPULATION, CARRIED END TO END")
    print("  (Paper 12 Appendix D; every derived number computed here")
    print("   from the declared exhibit records)")
    print("=" * 72)

    # --- Declared-data validation (shape of the declared records) ------
    print("\n--- Declared data: shape checks ---")
    check(len(SIGMA0) == n and set(NODES) == set(BODIES)
          and set(JUNCTION_ARITIES) == set(BODIES),
          f"one record per body: {n} bodies, {n} tick-0 local states")
    check(all(NODES[b] in (2, 3) for b in BODIES)
          and len(set(NODES.values())) == 2,
          "node counts vary across the declared set {2, 3}",
          f"N values present: {sorted(set(NODES.values()))}")
    check(all(JUNCTION_ARITIES[b] == (2,) for b in BODIES),
          "every body carries exactly one junction, of junction arity 2")
    check(all(len(s[0]) == 2 and len(s[1]) == 2
              and all(v in (-1, 0, 1) for v in s[0] + s[1])
              for s in SIGMA0),
          "every sigma is a pair of length-2 vectors over {-1, 0, +1}")
    check(sorted(R_BOOKED) == WINDOW
          and all(set(R_BOOKED[t]) == set(BODIES) for t in WINDOW)
          and all(isinstance(R_BOOKED[t][b], int)
                  and 0 <= R_BOOKED[t][b] <= 97
                  for t in WINDOW for b in BODIES),
          "reconcile table is 12 x 3 booked counts, each within the "
          "(7.2) cap r <= 97")
    for b, s in zip(BODIES, SIGMA0):
        print(f"    {b}: N={NODES[b]}, junction_arities={JUNCTION_ARITIES[b]}, "
              f"B=6*{NODES[b]}-{sum(JUNCTION_ARITIES[b])}={boundary(b)}, "
              f"{JUNCTIONS[b]}: {fmt_sigma(s)}")

    # --- (a) §3 census ---------------------------------------------------
    print("\n--- Step 1 / (a) §3 census over (N, junction arities, B) ---")
    vectors = {b: (NODES[b], JUNCTION_ARITIES[b], boundary(b)) for b in BODIES}
    classes = {}
    for b in BODIES:
        classes.setdefault(vectors[b], []).append(b)
    for v, bs in sorted(classes.items()):
        print(f"    class {v}: bodies {bs} -> count {len(bs)}")
    flat = [b for bs in classes.values() for b in bs]
    check(sorted(flat) == sorted(BODIES) and len(flat) == len(set(flat)),
          "(I) the classes partition the population: every body in "
          "exactly one class")
    check(sum(len(bs) for bs in classes.values()) == n,
          f"(II) class counts sum to |P| = {n}")
    nodes_grouped = sum(len(bs) * v[0] for v, bs in classes.items())
    nodes_direct = sum(NODES.values())
    consumed_grouped = sum(len(bs) * sum(v[1])
                           for v, bs in classes.items())
    consumed_direct = sum(sum(JUNCTION_ARITIES[b]) for b in BODIES)
    ports_grouped = sum(len(bs) * v[2] for v, bs in classes.items())
    ports_direct = 6 * nodes_direct - consumed_direct
    print(f"    total nodes: grouped {nodes_grouped} vs direct "
          f"{nodes_direct}")
    print(f"    total consumed ports: grouped {consumed_grouped} vs "
          f"direct {consumed_direct}")
    print(f"    total boundary ports: grouped {ports_grouped} vs "
          f"direct 6*{nodes_direct} - {consumed_direct} = {ports_direct}")
    check(nodes_grouped == nodes_direct,
          "(III) node totals agree by both routes")
    check(consumed_grouped == consumed_direct,
          "(III) consumed-port totals agree by both routes")
    check(ports_grouped == ports_direct,
          "(III) boundary-port totals agree by both routes")
    denom = 1
    for bs in classes.values():
        denom *= factorial(len(bs))
    omega_census = factorial(n) // denom
    print(f"    assignments realising the §3 census record "
          f"{tuple(len(classes[v]) for v in sorted(classes))}: "
          f"{n}!/({') / ('.join(str(len(classes[v])) + '!' for v in sorted(classes))}) "
          f"= {omega_census} (an arrangement count of what could be "
          f"written — not a frequency, per §3.6)")
    check(omega_census == multinomial_of_counts(
        [len(bs) for bs in classes.values()]),
        "§3 record assignment count recomputed by the multinomial route")

    # --- (b) §4 trajectory ------------------------------------------------
    print("\n--- Step 2 / (b) §4 aggregate-tick trajectory, ticks 0-3 ---")
    states = [SIGMA0]
    for _t in WINDOW:
        states.append(parallel_tick(states[-1]))
    transitions = []   # per tick: (acting, tau_before, tau_after, delta)
    for ti, t in enumerate(WINDOW):
        start, end = states[ti], states[ti + 1]
        act = acting_indices(start)
        d = tau_agg(end) - tau_agg(start)
        transitions.append((act, tau_agg(start), tau_agg(end), d))
        print(f"  tick {t}: acting junctions "
              f"{[JUNCTIONS[BODIES[j]] for j in act]} (count {len(act)}); "
              f"tau_agg {tau_agg(start)} -> {tau_agg(end)}; "
              f"Delta tau_agg = {d}")
        check(d == -2 * len(act),
              f"tick {t}: Delta tau_agg = -2 x acting (Proposition 4.3)")
        check(tau_agg(end) <= tau_agg(start),
              f"tick {t}: tau_agg does not increase")
        for j, b in enumerate(BODIES):
            print(f"      {JUNCTIONS[b]} ({b}): {fmt_sigma(start[j])} -> "
                  f"{fmt_sigma(end[j])}; tau {tau(start[j])} -> "
                  f"{tau(end[j])}; admissible at start "
                  f"{admissible_indices(start[j])}")
    tau_series = [tau_agg(s) for s in states]
    print(f"    tau_agg series over ticks 0-3: {tau_series}")
    check(all(tau_series[i + 1] <= tau_series[i] for i in range(3)),
          "tau_agg is monotone non-increasing along the trajectory")

    # Burn counts: acting ticks per junction before it rests (computed
    # by iterating T on each junction alone until its fixed point).
    burns = []
    for s in SIGMA0:
        cur, steps = s, 0
        while admissible_indices(cur):
            cur = T(cur)
            steps += 1
        burns.append(steps)
    burn_counts = Counter(burns)
    print(f"    acting ticks before resting, per body: "
          f"{dict(zip(BODIES, burns))}")
    print(f"    burn-count census: {dict(sorted(burn_counts.items()))}")
    check(set(burn_counts) == {1, 2}
          and burn_counts[1] == burn_counts[2] == n // 2,
          "design skeleton (computed): half the junctions act on "
          "exactly one tick before resting, half on exactly two")

    # Order-independence of tick 1 (A.2's approach; 12! not enumerated).
    print("    order-independence of tick 1:")
    start, expected = states[0], states[1]
    pair_total = 0
    pair_ok = True
    for i, j in itertools.combinations(range(n), 2):
        pair_total += 1
        if sequential_subset(start, (i, j)) != sequential_subset(start, (j, i)):
            pair_ok = False
            print(f"      PAIRWISE DIVERGENCE at junctions {i}, {j}")
    check(pair_ok,
          f"pairwise commutativity on the tick-1 state: all "
          f"{pair_total} unordered junction pairs commute")
    orders = [tuple(range(n)), tuple(reversed(range(n)))]
    for shift in range(1, n):
        orders.append(tuple((shift + i) % n for i in range(n)))
    rng = random.Random(SHUFFLE_SEED)
    for _ in range(N_SHUFFLES):
        order = list(range(n))
        rng.shuffle(order)
        orders.append(tuple(order))
    orders_ok = all(sequential_tick(start, o) == expected for o in orders)
    check(orders_ok,
          f"parallel tick == sequential tick on {len(orders)} "
          f"deterministic orders of tick 1 (identity, reverse, "
          f"{n - 1} rotations, {N_SHUFFLES} seeded shuffles)")

    # (p, c) by visited-state enumeration (A.3's route).
    visited, seq, cur = {}, [], SIGMA0
    while cur not in visited:
        visited[cur] = len(seq)
        seq.append(cur)
        cur = parallel_tick(cur)
    p, c = visited[cur], len(seq) - visited[cur]
    print(f"    (p, c) decomposition: pre-period p = {p}, cycle "
          f"length c = {c} (cycle state is the trajectory's resting "
          f"state: {parallel_tick(seq[p]) == seq[p]})")
    check(c == 1 and parallel_tick(seq[p]) == seq[p]
          and all(parallel_tick(seq[i]) != seq[i] for i in range(p)),
          "(p, c): the trajectory reaches a fixed point and no "
          "earlier state is one")
    check(tuple(seq) == tuple(states[:len(seq)])
          and seq[p] == states[len(states) - 1],
          "(p, c) enumeration reproduces the tick 0-3 trajectory "
          "up to its resting state")

    # --- (c) §5/§9 feature census, flows, frequencies ---------------------
    print("\n--- Step 3 / (c) §5 feature census, §9 flows, frequencies ---")
    class_traj = [[body_class(s) for s in st] for st in states]
    records = []
    for ti, cls in enumerate(class_traj):
        rec = (cls.count("L"), cls.count("R"))
        records.append(rec)
        per = ", ".join(f"{b}:{x}" for b, x in zip(BODIES, cls))
        print(f"    at tick {ti}: record (L, R) = {rec}  ({per})")
    check(records[0] == (n, 0) and records[-1] == (0, n)
          and records[1] == (n // 2, n // 2),
          "record skeleton (computed): the trajectory opens fully "
          "live, passes through the balanced record, and rests fully "
          "resting")
    flows = []   # per tick: (F dict, Phi dict, stationary bool)
    for ti, t in enumerate(WINDOW):
        before, after = class_traj[ti], class_traj[ti + 1]
        F = {(x, y): 0 for x in "LR" for y in "LR"}
        for b in range(n):
            F[(before[b], after[b])] += 1
        n_before = {x: before.count(x) for x in "LR"}
        n_after = {x: after.count(x) for x in "LR"}
        for x in "LR":
            check(sum(F[(x, y)] for y in "LR") == n_before[x],
                  f"tick {t}: (9.1) out of {x} = n_{x} before the tick")
            check(sum(F[(y, x)] for y in "LR") == n_after[x],
                  f"tick {t}: (9.2) into {x} = n_{x} after the tick")
        phi = {x: sum(F[(y, x)] for y in "LR")
               - sum(F[(x, y)] for y in "LR") for x in "LR"}
        stat = all(v == 0 for v in phi.values())
        flows.append((F, phi, stat))
        print(f"    tick {t}: F_L->L={F[('L', 'L')]}, "
              f"F_L->R={F[('L', 'R')]}, F_R->L={F[('R', 'L')]}, "
              f"F_R->R={F[('R', 'R')]}; Phi_L={phi['L']}, "
              f"Phi_R={phi['R']}; stationary: {stat}")
    visit_counts = Counter(records)
    print("    record-visit frequencies over ticks 0-3 (counts of "
          "actual visits / ticks in the window):")
    for rec in dict.fromkeys(records):
        freq = Fraction(visit_counts[rec], len(records))
        print(f"      record {rec}: visited {visit_counts[rec]} of "
              f"{len(records)} ticks -> frequency {freq}")
    check(sum(Fraction(v, len(records)) for v in visit_counts.values()) == 1,
          "record-visit frequencies sum to 1 exactly")
    occ_L = Fraction(sum(r[0] for r in records), n * len(records))
    occ_R = Fraction(sum(r[1] for r in records), n * len(records))
    print(f"    class occupancy over the window (Proposition 5.3(i)): "
          f"L occupies {occ_L} of (body, tick) pairs; R occupies {occ_R}")
    check(occ_L + occ_R == 1, "class occupancies sum to 1 exactly")

    # --- (d) §6 capability --------------------------------------------------
    print("\n--- Step 4 / (d) §6 capability read off the population ---")
    disagreements = sum(
        1 for MG in TAXONOMY for ME in TAXONOMY
        if outcome_rule_1(MG, ME) != outcome_rule_2(MG, ME))
    print(f"    A.4's two outcome rules disagree on {disagreements} of "
          f"{len(TAXONOMY) ** 2} (profile, encounter) pairs — the "
          f"factoring check below is not one rule tested twice")
    check(disagreements > 0, "the two outcome rules genuinely disagree")
    profiles_by_tick = []
    pair_checks = 0
    violations = 0
    for ti, st in enumerate(states):
        profs = [profile(presented_tuple(s)) for s in st]
        profiles_by_tick.append(profs)
        census_p = Counter(profs)
        print(f"    tick {ti}: profiles per body: "
              f"{dict(zip(BODIES, profs))}")
        print(f"    tick {ti}: profile-class census: "
              f"{dict(sorted(census_p.items()))}")
        caps = {rn: [capability(s, r) for s in st]
                for rn, r in RULES.items()}
        for i, j in itertools.combinations(range(n), 2):
            if profs[i] == profs[j]:
                pair_checks += 1
                for rn in RULES:
                    if caps[rn][i] != caps[rn][j]:
                        violations += 1
                        print(f"      VIOLATION tick {ti}, {rn}: "
                              f"{BODIES[i]} vs {BODIES[j]} at profile "
                              f"{profs[i]}")
    print(f"    equal-profile body pairs checked (per rule, summed "
          f"over ticks 0-3): {pair_checks}; violations: {violations}")
    check(violations == 0 and pair_checks > 0,
          "factoring on the exhibit: equal presented-count profiles "
          "=> equal capability sets, at every tick, under both rules")
    distinct_pairs_t0 = [(BODIES[i], BODIES[j], profiles_by_tick[0][i])
                         for i, j in itertools.combinations(range(n), 2)
                         if profiles_by_tick[0][i] == profiles_by_tick[0][j]
                         and states[0][i] != states[0][j]]
    print(f"    tick 0: pairs of DISTINCT sigma states sharing one "
          f"profile: {len(distinct_pairs_t0)}; e.g. "
          f"{distinct_pairs_t0[:3]}")
    check(len(distinct_pairs_t0) >= 2,
          "tick 0 carries at least two pairs of distinct sigma states "
          "sharing a presented-count profile (capability witnesses)")
    distinct_caps = {rn: len({tuple(sorted(capability(s, r).items()))
                              for s in states[0]})
                     for rn, r in RULES.items()}
    print(f"    distinct capability assignments across the tick-0 "
          f"bodies: {distinct_caps} (capability varies with profile — "
          f"the check is not vacuous)")
    check(all(v >= 2 for v in distinct_caps.values()),
          "capability genuinely varies across the exhibit's profiles")
    empty_cap = capability(states[0][0], outcome_rule_1, taxonomy=[])
    check(all(len(s) == 0 for s in empty_cap.values()),
          "empty taxonomy (no encounters) => capability empty for "
          "every role, no carried residue (§6.3, on the exhibit)")

    # --- (e) §7 reconcile count and density --------------------------------
    print("\n--- Step 5 / (e) §7 reconcile count and density over W ---")
    acting_by_tick = {t: {BODIES[j] for j in transitions[ti][0]}
                      for ti, t in enumerate(WINDOW)}
    pos_resting = [(b, t) for t in WINDOW for b in BODIES
                   if b not in acting_by_tick[t] and R_BOOKED[t][b] > 0]
    zero_acting = [(b, t) for t in WINDOW for b in BODIES
                   if b in acting_by_tick[t] and R_BOOKED[t][b] == 0]
    print(f"    acting bodies by tick: "
          f"{ {t: sorted(s) for t, s in acting_by_tick.items()} }")
    print(f"    booked counts positive at RESTING body-ticks: "
          f"{pos_resting}")
    print(f"    booked counts zero at ACTING body-ticks: {zero_acting}")
    check(pos_resting and zero_acting,
          "the declared reconcile table is not a function of junction "
          "action: positives occur at resting body-ticks and zeros "
          "at acting ones")
    body_totals = {b: sum(R_BOOKED[t][b] for t in WINDOW) for b in BODIES}
    for b in BODIES:
        print(f"    body {b}: r over W = "
              f"{[R_BOOKED[t][b] for t in WINDOW]} -> total "
              f"{body_totals[b]}")
    R_total = sum(body_totals.values())
    body_ticks = n * len(WINDOW)
    D = Fraction(R_total, body_ticks)
    print(f"    R(P, W) = {R_total}; body-ticks = {n} * {len(WINDOW)} "
          f"= {body_ticks}; D(P, W) = {R_total}/{body_ticks} = {D}")
    locals_ = {b: Fraction(body_totals[b], len(WINDOW)) for b in BODIES}
    for b in BODIES:
        print(f"    local density of {b}: {body_totals[b]}/{len(WINDOW)} "
              f"= {locals_[b]}")
    mean_locals = sum(locals_.values()) / n
    print(f"    mean of the {n} local densities (7.4) = {mean_locals}")
    check(mean_locals == D, "(7.4) mean of locals == D(P, W), exactly")
    check(all(R_BOOKED[t][b] <= 97 for t in WINDOW for b in BODIES),
          "every booked r_b(tau) respects the (7.2) cap of 97")

    # --- (f) §8 assignment counts and concentration -------------------------
    print("\n--- Step 6 / (f) §8 assignment counts at n = 12 ---")
    omega_table = {}
    for k in range(n + 1):
        omega_table[(k, n - k)] = comb(n, k)
        print(f"    record (L, R) = ({k}, {n - k}): Omega = "
              f"C({n}, {k}) = {comb(n, k)}")
    total_assign = sum(omega_table.values())
    check(total_assign == 2 ** n,
          f"(8.2) the records' counts sum to 2^{n} = {2 ** n}")
    omega_max = max(omega_table.values())
    balanced_rec = (n // 2, n - n // 2)
    print(f"    maximal assignment count: {omega_max} at the balanced "
          f"record {balanced_rec}; its own share of all assignments: "
          f"{Fraction(omega_max, total_assign)}")
    check(omega_table[balanced_rec] == omega_max,
          "the maximum of the table stands at the balanced record")
    pol_share = Fraction(omega_table[(n, 0)] + omega_table[(0, n)],
                         total_assign)
    nonpol_share = 1 - pol_share
    print(f"    polarized share (8.6): {pol_share}; as 2^(1-{n}): "
          f"{Fraction(1, 2 ** (n - 1))}")
    check(pol_share == Fraction(2, 2 ** n) == Fraction(1, 2 ** (n - 1)),
          f"(8.6) polarized share = 2^(1-n) at n = {n}, exactly")
    print(f"    non-polarized share: {nonpol_share}; (n-1)/n at "
          f"n = {n}: {Fraction(n - 1, n)}")
    check(nonpol_share >= Fraction(n - 1, n),
          f"(8.7) non-polarized share >= (n-1)/n at n = {n}")
    omega_visited = {rec: omega_table[rec] for rec in dict.fromkeys(records)}
    print(f"    Omega along the trajectory's records: "
          f"{[omega_table[r] for r in records]} (per tick 0-3)")

    # --- (g) §9 equilibrium verdicts -----------------------------------------
    print("\n--- Step 7 / (g) §9 equilibrium verdicts, per visited record ---")
    # Confirming tick for the final record: one further aggregate tick,
    # computed here; it is outside W and outside the frequency window.
    conf_start = states[-1]
    conf_end = parallel_tick(conf_start)
    conf_before = class_traj[-1]
    conf_after = [body_class(s) for s in conf_end]
    conf_F = {(x, y): 0 for x in "LR" for y in "LR"}
    for b in range(n):
        conf_F[(conf_before[b], conf_after[b])] += 1
    conf_phi = {x: sum(conf_F[(y, x)] for y in "LR")
                - sum(conf_F[(x, y)] for y in "LR") for x in "LR"}
    conf_stat = all(v == 0 for v in conf_phi.values())
    print(f"    confirming tick from the final state: acting "
          f"{acting_indices(conf_start)}, state unchanged: "
          f"{conf_end == conf_start}, Phi = {conf_phi}, stationary: "
          f"{conf_stat}")
    check(conf_end == conf_start and conf_stat,
          "the confirming tick leaves the final record stationary")
    any_equilibrium = False
    for rec in dict.fromkeys(records):
        first = records.index(rec)
        if first < len(records) - 1:
            e1 = flows[first][2]
            basis = f"net flows of tick {WINDOW[first]} leaving it"
        else:
            e1 = conf_stat
            basis = "the confirming tick"
        e2 = omega_table[rec] == omega_max
        eq = e1 and e2
        any_equilibrium |= eq
        print(f"    record {rec}: Omega = {omega_table[rec]}; "
              f"(E1) stationary: {e1} (from {basis}); "
              f"(E2) maximal: {e2}; EQUILIBRIUM: {eq}")
    check(not any_equilibrium,
          "no visited record is an equilibrium: the balanced record "
          "fails (E1) while moving, the resting record satisfies "
          "(E1) and fails (E2) — the clauses separate on the exhibit")

    # --- Step 8: transcription seam -------------------------------------------
    print("\n--- Step 8: Appendix D transcription seam ---")
    paper_path = Path(__file__).resolve().parent.parent / "Paper_12_v4.md"
    if not paper_path.exists():
        print(f"    NOTE — seam leg SKIPPED: {paper_path} does not "
              f"exist at run time. The coordinator re-runs A.7 after "
              f"Appendix D is integrated, when this leg must execute.")
    else:
        text = paper_path.read_text(encoding="utf-8")
        if appendix_lines(text) is None:
            print(f"    NOTE — seam leg SKIPPED: {paper_path.name} "
                  f"exists but carries no Appendix D at run time. "
                  f"The coordinator re-runs A.7 after Appendix D is "
                  f"integrated, when this leg must execute.")
        else:
            try:
                parsed_bodies, parsed_rec = parse_appendix_d(text)
            except ValueError as exc:
                check(False, "Appendix D parse", str(exc))
            else:
                name_ok = sorted(parsed_bodies) == sorted(BODIES)
                check(name_ok,
                      "seam: Appendix D declares exactly the bodies "
                      "B1..B12")
                mism = []
                for i, b in enumerate(BODIES):
                    if b not in parsed_bodies:
                        continue
                    want = (NODES[b], JUNCTION_ARITIES[b], sum(JUNCTION_ARITIES[b]),
                            boundary(b), SIGMA0[i][0], SIGMA0[i][1])
                    if parsed_bodies[b] != want:
                        mism.append((b, parsed_bodies[b], want))
                check(not mism,
                      "seam: Appendix D body rows (N, junction arities, sum k, "
                      "B, sigma A, sigma B) match the embedded records "
                      "exactly",
                      f"mismatches: {mism}" if mism else "12 rows")
                mism_r = [(t, b) for t in WINDOW for b in BODIES
                          if parsed_rec.get(t, {}).get(b)
                          != R_BOOKED[t][b]]
                check(sorted(parsed_rec) == WINDOW and not mism_r,
                      "seam: Appendix D reconcile table matches the "
                      "embedded table exactly (12 x 3 cells)",
                      f"mismatches: {mism_r}" if mism_r else "36 cells")

    # --- Step 9: printed-oracle leg -------------------------------------
    # A.6's standard applied to the exhibit: Appendix D's PRINTED
    # DERIVED values are parsed out of the paper and compared against
    # the recomputation above. A printed form that is absent fails
    # the leg (the oracle is missing), as does any disagreement.
    print("\n--- Step 9: printed-oracle leg (Appendix D's printed "
          "derived values vs recomputation) ---")
    app_lines = None
    if paper_path.exists():
        app_lines = appendix_lines(paper_path.read_text(encoding="utf-8"))
    if app_lines is None:
        print("    NOTE — oracle leg SKIPPED with the seam (no "
              "Appendix D at run time).")
    else:
        flat = re.sub(r"\s+", " ",
                      "\n".join(app_lines)).replace("−", "-")
        tables9 = parse_tables(app_lines)

        def ints_of(s):
            return tuple(int(x) for x in
                         re.findall(r"-?\d+", s.replace("−", "-")))

        def grab(pat, label):
            m = re.search(pat, flat)
            check(m is not None, f"oracle present: {label}",
                  "printed form not found in Appendix D" if m is None
                  else "")
            return m

        def frac_eq(found, want, label):
            check(found == want, f"oracle: {label}",
                  f"printed {found}, computed {want}")

        # (i) §3: census pair, grouped totals, arrangement count.
        census_pair = tuple(len(classes[v]) for v in sorted(classes))
        m = grab(r"Census: \*\*\((\d+), (\d+)\)\*\*", "Step 1 census pair")
        if m:
            check((int(m.group(1)), int(m.group(2))) == census_pair,
                  "oracle: printed census pair == computed",
                  f"printed {m.groups()}, computed {census_pair}")
        gt = re.findall(r"grouped [\d·+ ]+= \*\*(\d+)\*\*", flat)
        check(len(gt) == 3
              and sorted(int(x) for x in gt)
              == sorted((nodes_grouped, consumed_grouped, ports_grouped)),
              "oracle: printed grouped totals (nodes, consumed, "
              "boundary) == computed totals",
              f"printed {gt}")
        m = grab(r"realise this record number .*?= \*\*(\d+)\*\*",
                 "Step 1 arrangement count")
        if m:
            check(int(m.group(1)) == omega_census,
                  "oracle: printed arrangement count == computed",
                  f"printed {m.group(1)}, computed {omega_census}")

        # (ii) §4: tick-1 table, tau series and deltas, order counts.
        jt = next((t for t in tables9 if t and t[0][0] == "junction"
                   and any("after T" in c for c in t[0])), None)
        check(jt is not None and len(jt) == n + 1,
              "oracle present: Step 2 tick-1 junction table")
        if jt is not None:
            bad = []
            for j, row in enumerate(jt[1:]):
                adm = ints_of(row[1])
                want_adm = tuple(admissible_indices(states[0][j]))
                sig = ints_of(row[3])
                want_sig = states[1][j][0] + states[1][j][1]
                want_first = want_adm[0] if want_adm else 0
                if (adm != want_adm or int(row[2]) != want_first
                        or sig != want_sig
                        or int(row[4]) != tau(states[1][j])):
                    bad.append(BODIES[j])
            check(not bad,
                  "oracle: tick-1 table (admissible, first, sigma "
                  "after T, tau after) == computed for all 12 junctions",
                  f"mismatches: {bad}" if bad else "12 rows")
        m = grab(r"τ_agg series over ticks 0.3 is ([\d, ]+):",
                 "tau_agg series")
        if m:
            check(list(ints_of(m.group(1))) == tau_series,
                  "oracle: printed tau_agg series == computed",
                  f"printed {m.group(1)}, computed {tau_series}")
        m = grab(r"τ_agg after tick 1: \*\*(\d+)\*\*", "tau after tick 1")
        if m:
            check(int(m.group(1)) == tau_series[1],
                  "oracle: printed tau_agg after tick 1 == computed")
        m = grab(r"Δτ_agg = \d+ - \d+ = \*\*(-?\d+)\*\*",
                 "tick-1 delta")
        if m:
            check(int(m.group(1)) == transitions[0][3],
                  "oracle: printed tick-1 Delta tau_agg == computed")
        m = grab(r"Δτ_agg = (-?\d+) = -2 × (\d+)", "tick-2 delta")
        if m:
            check((int(m.group(1)), int(m.group(2)))
                  == (transitions[1][3], len(transitions[1][0])),
                  "oracle: printed tick-2 Delta tau_agg and acting "
                  "count == computed")
        m = grab(r"resting τ_agg is (\d+), not 0", "resting tau_agg")
        if m:
            check(int(m.group(1)) == tau_series[-1],
                  "oracle: printed resting tau_agg == computed")
        for pat, want, lab in (
                (r"all \*\*(\d+)\*\* unordered pairs", pair_total,
                 "pairwise-commutativity pair count"),
                (r"all (\d+) junction pairs commute", pair_total,
                 "LD.2 pair count"),
                (r"\*\*(\d+)\*\* deterministic application orders", len(orders),
                 "deterministic order count"),
                (r"(\d+) deterministic orders agree", len(orders),
                 "LD.2 order count")):
            m = grab(pat, lab)
            if m:
                check(int(m.group(1)) == want,
                      f"oracle: printed {lab} == computed",
                      f"printed {m.group(1)}, computed {want}")

        # (iii) §5/§9: Step-3 census table, frequencies, occupancies.
        ct = next((t for t in tables9 if t and t[0][0] == "at tick"),
                  None)
        check(ct is not None and len(ct) == len(records) + 1,
              "oracle present: Step 3 census table")
        if ct is not None:
            bad = [r[0] for r in ct[1:]
                   if ints_of(r[3]) != records[int(r[0])]]
            check(not bad,
                  "oracle: Step 3 records per tick == computed",
                  f"mismatches at ticks: {bad}" if bad else "4 rows")
        ff = [Fraction(int(a), int(b)) for a, b in
              re.findall(r"frequency \*\*(\d+)/(\d+)\*\*", flat)]
        want_ff = sorted(Fraction(visit_counts[r], len(records))
                         for r in dict.fromkeys(records))
        check(sorted(ff) == want_ff,
              "oracle: printed record-visit frequencies == computed",
              f"printed {ff}, computed {want_ff}")
        m = grab(r"L occupies [^;]*?= \*\*(\d+)/(\d+)\*\*", "L occupancy")
        if m:
            frac_eq(Fraction(int(m.group(1)), int(m.group(2))), occ_L,
                    "printed L occupancy == computed")
        m = grab(r"R occupies \*\*(\d+)/(\d+)\*\*", "R occupancy")
        if m:
            frac_eq(Fraction(int(m.group(1)), int(m.group(2))), occ_R,
                    "printed R occupancy == computed")

        # (iv) §6: profile table and the four Step-4 counts.
        pt = next((t for t in tables9 if t and t[0][0] == "body"
                   and len(t[0]) > 1 and t[0][1] == "tick 0"), None)
        check(pt is not None and len(pt) == n + 1,
              "oracle present: Step 4 profile table")
        if pt is not None:
            bad = []
            for i, row in enumerate(pt[1:]):
                for ti in range(len(states)):
                    if ints_of(row[1 + ti]) != profiles_by_tick[ti][i]:
                        bad.append((row[0], ti))
            check(not bad,
                  "oracle: profile table (12 bodies x 4 ticks) == "
                  "computed",
                  f"mismatches: {bad}" if bad else "48 cells")
        m = grab(r"disagree on \*\*(\d+)\*\* of the (\d+)",
                 "rule disagreements")
        if m:
            check((int(m.group(1)), int(m.group(2)))
                  == (disagreements, len(TAXONOMY) ** 2),
                  "oracle: printed rule-disagreement count == computed",
                  f"printed {m.groups()}, computed "
                  f"{(disagreements, len(TAXONOMY) ** 2)}")
        m = grab(r"\*\*(\d+)\*\* equal-profile body pairs",
                 "equal-profile pairs")
        if m:
            check(int(m.group(1)) == pair_checks,
                  "oracle: printed equal-profile pair count == computed",
                  f"printed {m.group(1)}, computed {pair_checks}")
        m = grab(r"there are \*\*(\d+)\*\* pairs of \*distinct\*",
                 "distinct-sigma pairs")
        if m:
            check(int(m.group(1)) == len(distinct_pairs_t0),
                  "oracle: printed distinct-sigma pair count == "
                  "computed",
                  f"printed {m.group(1)}, computed "
                  f"{len(distinct_pairs_t0)}")
        m = grab(r"carry \*\*(\d+)\*\* distinct capability assignments",
                 "distinct capability assignments")
        if m:
            check(len(set(distinct_caps.values())) == 1
                  and int(m.group(1)) == distinct_caps["rule1_cover"],
                  "oracle: printed distinct-assignment count == "
                  "computed under both rules",
                  f"printed {m.group(1)}, computed {distinct_caps}")

        def parse_census_dict(s):
            return {(int(a), int(b)): int(c) for a, b, c in
                    re.findall(r"\((\d+), (\d+)\): (\d+)", s)}

        m = grab(r"Profile-class censuses: at tick 0, (\{[^}]*\}); "
                 r"at tick 1, (\{[^}]*\}); at ticks 2 and 3, "
                 r"(\{[^}]*\})", "Step 4 prose profile-class censuses")
        if m:
            want_census = [dict(Counter(profiles_by_tick[ti]))
                           for ti in range(len(states))]
            got_census = [parse_census_dict(m.group(i))
                          for i in (1, 2, 3)]
            check(got_census[0] == want_census[0]
                  and got_census[1] == want_census[1]
                  and got_census[2] == want_census[2] == want_census[3],
                  "oracle: printed profile-class censuses (tick 0; "
                  "tick 1; ticks 2 and 3) == computed per-tick "
                  "censuses",
                  f"printed {got_census}, computed {want_census}")

        # (v) §7: window declaration, reconcile totals row, R sum,
        # D fractions, locals, mean.
        m = grab(r"Window W = ticks (\d+)[-–—](\d+), declared: "
                 r"\|W\| = (\d+), \|P\| = (\d+), body-ticks = "
                 r"(\d+) · (\d+) = (\d+)", "Step 5 window declaration")
        if m:
            wvals = tuple(int(m.group(i)) for i in range(1, 8))
            check(wvals == (WINDOW[0], WINDOW[-1], len(WINDOW), n,
                            n, len(WINDOW), body_ticks),
                  "oracle: printed window W (ticks, |W|, |P|, "
                  "body-ticks product and value) == declared window "
                  "and computed body-ticks",
                  f"printed {wvals}, computed window {WINDOW}, "
                  f"|P| {n}, body-ticks {body_ticks}")
        rt = next((t for t in tables9 if t and t[0][0] == "tick"
                   and t[0][1:] == BODIES), None)
        check(rt is not None, "oracle present: Step 5 reconcile table")
        if rt is not None:
            trow = next((r for r in rt[1:] if "body total" in r[0]),
                        None)
            check(trow is not None
                  and [int(x) for x in trow[1:]]
                  == [body_totals[b] for b in BODIES],
                  "oracle: reconcile body-total row == computed body "
                  "totals")
        m = grab(r"R\(P, W\) = ([\d +]+) = \*\*(\d+)\*\*", "R sum")
        if m:
            check(list(ints_of(m.group(1)))
                  == [body_totals[b] for b in BODIES]
                  and int(m.group(2)) == R_total,
                  "oracle: printed R summands and total == computed")
        m = grab(r"D\(P, W\) = (\d+) / (\d+)", "D(P, W) display")
        if m:
            frac_eq(Fraction(int(m.group(1)), int(m.group(2))), D,
                    "printed D(P, W) == computed")
        dall = re.findall(r"D\(P, W\) = (\d+)/(\d+)", flat)
        check(len(dall) >= 2 and all(
            Fraction(int(a), int(b)) == D for a, b in dall),
            "oracle: every printed D(P, W) = num/den occurrence == "
            "computed D",
            f"{len(dall)} occurrence(s)")
        dens = {}
        for mm in re.finditer(
                r"B(\d+): (\d+)/(\d+)(?: = (\d+))?[;.]", flat):
            dens[int(mm.group(1))] = (
                Fraction(int(mm.group(2)), int(mm.group(3))),
                mm.group(4))
        check(sorted(dens) == list(range(1, n + 1)),
              "oracle present: the twelve printed local densities",
              f"bodies found: {sorted(dens)}")
        bad = [k for k, (fr, eq) in dens.items()
               if fr != locals_[BODIES[k - 1]]
               or (eq is not None
                   and Fraction(int(eq)) != locals_[BODIES[k - 1]])]
        check(not bad,
              "oracle: printed local densities == computed",
              f"mismatches at bodies: {bad}" if bad else "12 values")
        m = grab(r"Mean-of-locals check \(7\.4\): .*?= \*\*(\d+)/(\d+)\*\*",
                 "mean of locals")
        if m:
            frac_eq(Fraction(int(m.group(1)), int(m.group(2))),
                    mean_locals, "printed mean of locals == computed")
        m = grab(r"\*\*(\d+)\*\* resting body-ticks", "resting witnesses")
        if m:
            check(int(m.group(1)) == len(pos_resting),
                  "oracle: printed positive-at-resting count == "
                  "computed",
                  f"printed {m.group(1)}, computed {len(pos_resting)}")
        m = grab(r"\*\*(\d+)\*\* acting body-ticks", "acting witnesses")
        if m:
            check(int(m.group(1)) == len(zero_acting),
                  "oracle: printed zero-at-acting count == computed",
                  f"printed {m.group(1)}, computed {len(zero_acting)}")

        # (vi) §8: Omega table, total, maximum, shares, trajectory value.
        ot = next((t for t in tables9
                   if t and t[0][0] == "record (L, R)"), None)
        check(ot is not None, "oracle present: Step 6 Omega table")
        if ot is not None:
            orow = next((r for r in ot if r[0] == "Ω"), None)
            check(orow is not None
                  and [int(x) for x in orow[1:]]
                  == [omega_table[(k, n - k)] for k in range(n + 1)],
                  "oracle: Omega table row == computed C(12, k) table")
        m = grab(r"Total over all records: \*\*(\d+)\*\*", "Omega total")
        if m:
            check(int(m.group(1)) == total_assign,
                  "oracle: printed Omega total == computed")
        m = grab(r"class structure is \*\*(\d+)\*\*", "Omega maximum")
        if m:
            check(int(m.group(1)) == omega_max,
                  "oracle: printed maximal assignment count == computed")
        m = grab(r"own share of all assignments is (\d+)/(\d+) = "
                 r"\*\*(\d+)/(\d+)\*\*", "balanced share")
        if m:
            want_share = Fraction(omega_max, total_assign)
            check(Fraction(int(m.group(1)), int(m.group(2))) == want_share
                  and Fraction(int(m.group(3)), int(m.group(4)))
                  == want_share,
                  "oracle: printed balanced share == computed",
                  f"computed {want_share}")
        m = grab(r"combined share is exactly (\d+)/(\d+) = "
                 r"\*\*(\d+)/(\d+)\*\*", "polarized share")
        if m:
            check(Fraction(int(m.group(1)), int(m.group(2))) == pol_share
                  and Fraction(int(m.group(3)), int(m.group(4)))
                  == pol_share,
                  "oracle: printed polarized share == computed",
                  f"computed {pol_share}")
        m = grab(r"non-polarized share is \*\*(\d+)/(\d+)\*\*",
                 "non-polarized share")
        if m:
            frac_eq(Fraction(int(m.group(1)), int(m.group(2))),
                    nonpol_share,
                    "printed non-polarized share == computed")
        m = grab(r"then \*\*(\d+)\*\* \(at \(6, 6\)\)",
                 "Omega at the balanced record")
        if m:
            check(int(m.group(1)) == omega_table[balanced_rec],
                  "oracle: printed Omega at (6, 6) == computed")

        # (vii) §9: the verdict table, recomputed clause by clause.
        vt = next((t for t in tables9 if t and t[0][0] == "record"
                   and any("(E2)" in c for c in t[0])), None)
        check(vt is not None and len(vt) == len(dict.fromkeys(records)) + 1,
              "oracle present: Step 7 verdict table")
        if vt is not None:
            bad = []
            for row in vt[1:]:
                rec = ints_of(row[0])
                first = records.index(rec)
                e1 = (flows[first][2] if first < len(records) - 1
                      else conf_stat)
                e2 = omega_table[rec] == omega_max
                got = (row[1].startswith("Yes"), int(row[2]),
                       row[3].startswith("Yes"),
                       row[4].startswith("Yes"))
                if got != (e1, omega_table[rec], e2, e1 and e2):
                    bad.append(rec)
            check(not bad,
                  "oracle: verdict table ((E1), Omega, (E2), "
                  "equilibrium) == recomputed for every visited record",
                  f"mismatches: {bad}" if bad else "3 rows")
            phi_bad = []
            for rec in ((n, 0), (n // 2, n - n // 2)):
                row = next((r for r in vt[1:]
                            if ints_of(r[0]) == rec), None)
                if row is None:
                    phi_bad.append((rec, "row absent"))
                    continue
                mm = re.search(r"Φ_L = (-?\d+), Φ_R = \+?(-?\d+)",
                               row[1].replace("−", "-"))
                first = records.index(rec)
                want_phi = (flows[first][1]
                            if first < len(records) - 1 else conf_phi)
                if (mm is None
                        or (int(mm.group(1)), int(mm.group(2)))
                        != (want_phi["L"], want_phi["R"])):
                    phi_bad.append(rec)
            check(not phi_bad,
                  "oracle: verdict-table (E1) cells' printed "
                  "Phi_L/Phi_R for (12, 0) and (6, 6) == computed "
                  "flows of the tick leaving each record",
                  f"mismatches: {phi_bad}" if phi_bad else "2 cells")

        # (viii) The LD claim lines' printed values.
        ld = {}
        for ln in app_lines:
            mm = re.match(r"- \*\*(LD\.\d+)-P12", ln.strip())
            if mm:
                ld[mm.group(1)] = ln.replace("−", "-")
        check(len(ld) == 8, "oracle present: LD.1-LD.8 claim lines",
              f"found {sorted(ld)}")
        if "LD.1" in ld:
            mm = re.search(r"(\d+) nodes, (\d+) consumed ports and "
                           r"(\d+) boundary ports", ld["LD.1"])
            check(mm is not None
                  and (int(mm.group(1)), int(mm.group(2)),
                       int(mm.group(3)))
                  == (nodes_direct, consumed_direct, ports_direct),
                  "oracle: LD.1 totals == computed")
        if "LD.2" in ld:
            mm = re.search(r"series ([\d, ]+) with Δτ_agg = "
                           r"([\d, -]+) = -2 × \(([\d, ]+)\)", ld["LD.2"])
            check(mm is not None
                  and list(ints_of(mm.group(1))) == tau_series
                  and list(ints_of(mm.group(2)))
                  == [t[3] for t in transitions]
                  and list(ints_of(mm.group(3)))
                  == [len(t[0]) for t in transitions],
                  "oracle: LD.2 series, deltas, acting counts == "
                  "computed")
            mm = re.search(r"\(p, c\) decomposition is \((\d+), (\d+)\)",
                           ld["LD.2"])
            check(mm is not None
                  and (int(mm.group(1)), int(mm.group(2))) == (p, c),
                  "oracle: LD.2 (p, c) == computed")
        if "LD.3" in ld:
            fr = [Fraction(int(a), int(b)) for a, b in
                  re.findall(r"(\d+)/(\d+)", ld["LD.3"])]
            want = ([Fraction(visit_counts[r], len(records))
                     for r in dict.fromkeys(records)] + [occ_L, occ_R])
            check(fr == want,
                  "oracle: LD.3 frequencies and occupancies == "
                  "computed",
                  f"printed {fr}, computed {want}")
            mm = re.search(r"Φ = \((-?\d+), \+?(-?\d+)\), "
                           r"\((-?\d+), \+?(-?\d+)\), "
                           r"\((-?\d+), \+?(-?\d+)\)", ld["LD.3"])
            want_flows = [(flows[t][1]["L"], flows[t][1]["R"])
                          for t in range(len(flows))]
            got_flows = ([(int(mm.group(i)), int(mm.group(i + 1)))
                          for i in (1, 3, 5)] if mm else None)
            check(mm is not None and got_flows == want_flows,
                  "oracle: LD.3 net-flow triples == computed per-tick "
                  "net flows",
                  f"printed {got_flows}, computed {want_flows}")
        if "LD.4" in ld:
            mm = re.search(r"(\d+) equal-profile body pairs", ld["LD.4"])
            check(mm is not None and int(mm.group(1)) == pair_checks,
                  "oracle: LD.4 equal-profile pair count == computed",
                  f"printed {mm.group(1) if mm else None}, computed "
                  f"{pair_checks}")
            mm = re.search(r"(\d+) violations", ld["LD.4"])
            check(mm is not None and int(mm.group(1)) == violations,
                  "oracle: LD.4 violation count == computed",
                  f"printed {mm.group(1) if mm else None}, computed "
                  f"{violations}")
            mm = re.search(r"(\d+) pairs of distinct σ states",
                           ld["LD.4"])
            check(mm is not None
                  and int(mm.group(1)) == len(distinct_pairs_t0),
                  "oracle: LD.4 distinct-sigma pair count == computed",
                  f"printed {mm.group(1) if mm else None}, computed "
                  f"{len(distinct_pairs_t0)}")
            mm = re.search(r"(\d+) distinct assignments", ld["LD.4"])
            check(mm is not None
                  and len(set(distinct_caps.values())) == 1
                  and int(mm.group(1)) == distinct_caps["rule1_cover"],
                  "oracle: LD.4 distinct-assignment count == computed "
                  "under both rules",
                  f"printed {mm.group(1) if mm else None}, computed "
                  f"{distinct_caps}")
        if "LD.5" in ld:
            mm = re.search(r"local densities are ([\d/, ]+) \(in body "
                           r"order", ld["LD.5"])
            toks = ([Fraction(t.strip()) for t in mm.group(1).split(",")]
                    if mm else [])
            check(mm is not None
                  and toks == [locals_[b] for b in BODIES],
                  "oracle: LD.5 local densities == computed")
            mm = re.search(r"R\(P, W\) = (\d+) over (\d+) body-ticks",
                           ld["LD.5"])
            check(mm is not None
                  and (int(mm.group(1)), int(mm.group(2)))
                  == (R_total, body_ticks),
                  "oracle: LD.5 R and body-ticks == computed")
        if "LD.6" in ld:
            mm = re.search(r"for k = 0\.\.12 are ([\d, ]+), summing to "
                           r"(\d+)", ld["LD.6"])
            check(mm is not None
                  and list(ints_of(mm.group(1)))
                  == [omega_table[(k, n - k)] for k in range(n + 1)]
                  and int(mm.group(2)) == total_assign,
                  "oracle: LD.6 Omega table and total == computed")
            mm = re.search(r"polarized share is exactly (\d+)/(\d+)",
                           ld["LD.6"])
            check(mm is not None
                  and Fraction(int(mm.group(1)), int(mm.group(2)))
                  == pol_share,
                  "oracle: LD.6 polarized share == computed")
            mm = re.search(r"non-polarized share (\d+)/(\d+)", ld["LD.6"])
            check(mm is not None
                  and Fraction(int(mm.group(1)), int(mm.group(2)))
                  == nonpol_share,
                  "oracle: LD.6 non-polarized share == computed")
            mm = re.search(r"maximal count is (\d+) at \(6, 6\), whose "
                           r"own share is (\d+)/(\d+)", ld["LD.6"])
            check(mm is not None
                  and int(mm.group(1)) == omega_max
                  and Fraction(int(mm.group(2)), int(mm.group(3)))
                  == Fraction(omega_max, total_assign),
                  "oracle: LD.6 maximum and its share == computed")
        if "LD.7" in ld:
            mm = re.search(r"Ω = (\d+), maximal", ld["LD.7"])
            check(mm is not None and int(mm.group(1)) == omega_max,
                  "oracle: LD.7 Omega at the balanced record == "
                  "computed")
        if "LD.8" in ld:
            mm = re.search(r"goes ([\d, →-]+?) while", ld["LD.8"])
            want_path = [omega_table[r] for r in dict.fromkeys(records)]
            check(mm is not None
                  and list(ints_of(mm.group(1))) == want_path,
                  "oracle: LD.8 Omega path == computed",
                  f"computed {want_path}")

        # (ix) The closing "What follows" paragraph's printed paths.
        want_path = [omega_table[r] for r in dict.fromkeys(records)]
        m = grab(r"Ω went ([\d, →-]+?) while", "What-follows Omega path")
        if m:
            check(list(ints_of(m.group(1))) == want_path,
                  "oracle: What-follows printed Omega path == "
                  "computed visited-record Omega path",
                  f"printed {m.group(1)}, computed {want_path}")
        m = grab(r"monotonically \(([\d, →-]+?)\)",
                 "What-follows tau_agg series")
        if m:
            check(list(ints_of(m.group(1))) == tau_series,
                  "oracle: What-follows printed tau_agg series == "
                  "computed",
                  f"printed {m.group(1)}, computed {tau_series}")

    # --- Planted-mutant battery ------------------------------------------------
    print("\n--- PLANTED MUTANT BATTERY (each must be REJECTED, "
          "with witness) ---")
    # M1: a corrupted sigma entry (one entry of B1's A-vector zeroed in
    # a copy of the records). The corrupted population's computed
    # trajectory must diverge from the exhibit's — the entry is
    # load-bearing, and Step 8's seam exists to catch exactly this.
    mut_sigma = list(SIGMA0)
    a0, b0 = mut_sigma[0]
    mut_sigma[0] = ((0,) + a0[1:], b0)
    mut_state = tuple(mut_sigma)
    mut_end = parallel_tick(mut_state)
    m1_caught = (tau_agg(mut_state) != tau_agg(SIGMA0)
                 and mut_end != states[1])
    print(f"    witness: B1 sigma {fmt_sigma(SIGMA0[0])} corrupted to "
          f"{fmt_sigma(mut_sigma[0])}: tau_agg at tick 0 "
          f"{tau_agg(SIGMA0)} -> {tau_agg(mut_state)}; tick-1 end "
          f"state at B1 {fmt_sigma(states[1][0])} vs mutant "
          f"{fmt_sigma(mut_end[0])}")
    check(m1_caught,
          "M1: corrupted sigma entry is REJECTED — the corrupted "
          "records recompute to a different trajectory")
    # M2: off-by-one assignment count — the balanced record's Omega
    # read at k+1 instead of k.
    k_bal = n // 2
    mut_omega = comb(n, k_bal + 1)
    m2_caught = mut_omega != omega_table[balanced_rec]
    print(f"    witness: balanced record {balanced_rec}: computed "
          f"Omega = C({n}, {k_bal}) = {omega_table[balanced_rec]}; "
          f"off-by-one mutant C({n}, {k_bal + 1}) = {mut_omega}")
    check(m2_caught,
          "M2: off-by-one Omega is REJECTED against the computed table")
    # M3: off-by-one reconcile cell (one booked count incremented).
    mut_rec = {t: dict(R_BOOKED[t]) for t in WINDOW}
    mut_rec[WINDOW[-1]][BODIES[-1]] += 1
    mut_R = sum(mut_rec[t][b] for t in WINDOW for b in BODIES)
    mut_D = Fraction(mut_R, body_ticks)
    m3_caught = mut_D != D
    print(f"    witness: {BODIES[-1]} at tick {WINDOW[-1]} booked "
          f"{R_BOOKED[WINDOW[-1]][BODIES[-1]]} corrupted to "
          f"{mut_rec[WINDOW[-1]][BODIES[-1]]}: D(P, W) {D} -> {mut_D}")
    check(m3_caught,
          "M3: off-by-one reconcile cell is REJECTED — D(P, W) moves")

    print("\n" + "=" * 72)
    if FAILURES:
        print(f"A.7 VERDICT: FAIL — {len(FAILURES)} check(s) failed: "
              f"{FAILURES}")
        print("=" * 72)
        return 1
    print("A.7 VERDICT: PASS — the exhibit's census identities, "
          "trajectory and")
    print("  tau accounting, flow identities and frequencies, capability")
    print("  factoring, reconcile density, assignment counts and")
    print("  equilibrium verdicts all recompute from the declared")
    print("  records; Appendix D's declared tables (Step 8) and printed")
    print("  derived values (Step 9) match the recomputation; the")
    print("  planted mutants are rejected with witnesses.")
    print("=" * 72)
    return 0


def multinomial_of_counts(counts):
    out = factorial(sum(counts))
    for c_ in counts:
        out //= factorial(c_)
    return out


if __name__ == "__main__":
    sys.exit(main())
