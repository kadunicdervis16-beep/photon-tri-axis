#!/usr/bin/env python3
"""A.5 — Concentration by exact finite counting (Paper 12 §8.3).

Reproduces §8.3's counting INDEPENDENTLY and checks the draft's printed
table against the computation. The draft's table values enter this
script ONLY as the oracle under test (the prediction); every count the
verdict rests on is computed here, three separate ways, from the
combinatorics of assignments of named bodies:

  ROUTE 1 (enumeration): literally enumerate all 2^n assignments of
    n named bodies to classes {A, B} (itertools.product) and count
    how many assignments stand behind each census record (k, n-k).
  ROUTE 2 (closed form): math.comb — an independent implementation
    of (8.1), sharing no code with Route 1.
  ROUTE 3 (multinomial, r classes): enumerate all r^n assignments
    for r = 3 and count per record (n_1, n_2, n_3); each count must
    equal the multinomial n! / (n_1! n_2! n_3!) of §8.4, computed
    from factorials here. (The r = 2 case of Route 3 must reproduce
    Route 1 exactly — a cross-route consistency check.)

CHECKS (all exact; shares are Fractions, never floats):
  - record counts C(n, k) for n = 1..6 equal the draft's table,
    by Routes 1 and 2 independently;
  - total over records = 2^n (8.2);
  - ratio rule (8.3): C(n, k+1) / C(n, k) = (n - k) / (k + 1) as
    exact Fractions, n = 1..6, all k; counts strictly increase up
    to the balanced record and strictly decrease after; the n = 6
    successive-ratio sequence equals the draft's printed
    6, 5/2, 4/3, 3/4, 2/5, 1/6;
  - balanced growth (8.5): C(2m, m) >= 2^m, checked m = 1..8
    (the draft prints m = 1..3: 2 >= 2, 6 >= 4, 20 >= 8);
  - polarized share = 2 / 2^n = 2^(1-n) exactly (8.6), and the
    non-polarized share 1 - 2^(1-n) equals the draft's column;
  - finite inequality (8.7): non-polarized share >= (n-1)/n,
    checked n = 1..12 (table range and beyond), and the
    non-polarized share is STRICTLY INCREASING in n over 1..12;
  - maximal (balanced) record: its count equals the draft's
    "max record count" column, and its own share of all assignments
    equals the draft's last column EXACTLY — 1/2, 1/2, 3/8, 3/8,
    5/16, 5/16 — including that this share does NOT increase
    (the draft prints it precisely to refuse the phrasing "the
    population ends up in the maximal record"; this script verifies
    the printed values, not the refused phrasing).

ORACLE DISCIPLINE: if any printed table value disagrees with the
computed counts, this script FAILS and prints the discrepancy cell
by cell. It does not edit the draft, and it does not adjust the
computation to fit the table.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: §8.3's statements at every finite n.
  (2) Verified domain: enumeration at n = 1..6 (2^n <= 64
      assignments — the table's full range) and n = 1..12 for the
      closed-form shares/inequality; multinomial enumeration at
      r = 3, n = 1..5.
  (3) Map: census record (k, n-k) -> the set of assignments of the
      n named bodies with exactly k in class A.
  (4) Preserved: exact counts, exact shares, the inequality
      direction (8.7) — everything §8.3 claims at finite n.
  (5) Outside the machine check: the induction step of (8.7) for
      ALL n (the draft's proof is analytic; the machine checks
      n = 1..12 and the statement is exact at each), and (8.3)'s
      algebra for n > 6 (checked to n = 12 via Route 2; the
      identity is a factorial cancellation, proved in the draft).

INPUT_PROVENANCE:
  - The §8.3 table (record counts, totals, max counts, polarized /
    non-polarized / balanced shares for n = 1..6, and the n = 6
    ratio sequence): class=paper-defined (Paper 12 draft §8.3) —
    the ORACLE UNDER TEST: the prediction, transcribed below,
    never used in any computation.
  - Equations (8.1)-(8.7) and §8.4's multinomial form:
    class=paper-defined (Paper 12 draft §§8.2-8.4) — the claims
    under test; the script re-derives their values from raw
    enumeration and factorial arithmetic.
  - Body names (0..n-1) and class labels {A, B} / {A, B, C}:
    class=control (the draft's declared toy population, §8.2:
    "n distinct, named bodies, and two census classes").
"""
import sys
from fractions import Fraction
from itertools import product
from math import comb, factorial


# ------------------------------------------------------ oracle under test
# Transcribed from Paper 12 draft §8.3's table (DRAFT_C_s7-9.md).
# These literals are the PREDICTION. No computation below reads them
# except the final cell-by-cell comparisons.
ORACLE = {
    # n: (record counts k=0..n, total, max count, polarized share,
    #     non-polarized share, balanced record's own share)
    1: ((1, 1),                   2,  1,  Fraction(1),     Fraction(0),
        Fraction(1, 2)),
    2: ((1, 2, 1),                4,  2,  Fraction(1, 2),  Fraction(1, 2),
        Fraction(1, 2)),
    3: ((1, 3, 3, 1),             8,  3,  Fraction(1, 4),  Fraction(3, 4),
        Fraction(3, 8)),
    4: ((1, 4, 6, 4, 1),          16, 6,  Fraction(1, 8),  Fraction(7, 8),
        Fraction(3, 8)),
    5: ((1, 5, 10, 10, 5, 1),     32, 10, Fraction(1, 16), Fraction(15, 16),
        Fraction(5, 16)),
    6: ((1, 6, 15, 20, 15, 6, 1), 64, 20, Fraction(1, 32), Fraction(31, 32),
        Fraction(5, 16)),
}
ORACLE_RATIOS_N6 = (Fraction(6), Fraction(5, 2), Fraction(4, 3),
                    Fraction(3, 4), Fraction(2, 5), Fraction(1, 6))
ORACLE_BALANCED_GROWTH = {1: (2, 2), 2: (6, 4), 3: (20, 8)}  # m: (C(2m,m), 2^m)


# ------------------------------------------------------------------- routes

def counts_by_enumeration(n, r=2):
    """ROUTE 1/3: enumerate every assignment of n named bodies to r
    classes; count assignments per census record. Returns
    {record_tuple: count}."""
    counts = {}
    for assignment in product(range(r), repeat=n):
        record = tuple(assignment.count(cls) for cls in range(r))
        counts[record] = counts.get(record, 0) + 1
    return counts


def multinomial(record):
    """n! / (n_1! ... n_r!) from factorials — the closed form of §8.4."""
    n = sum(record)
    out = factorial(n)
    for ni in record:
        out //= factorial(ni)
    return out


# --------------------------------------------------------------------- main

def main():
    print("=" * 70)
    print("A.5 — CONCENTRATION BY EXACT FINITE COUNTING (Paper 12 §8.3)")
    print("  Independent enumeration vs the draft's printed table")
    print("  (the table is the oracle under test, never an input).")
    print("=" * 70)
    all_ok = True
    discrepancies = []

    print("\n--- Step 1: record counts, three routes, vs the oracle "
          "(n = 1..6) ---")
    computed = {}
    for n in range(1, 7):
        enum2 = counts_by_enumeration(n, r=2)
        route1 = tuple(enum2[(k, n - k)] for k in range(n + 1))
        route2 = tuple(comb(n, k) for k in range(n + 1))
        # Route 3 cross-check: multinomial at r=2 must equal comb.
        route3 = tuple(multinomial((k, n - k)) for k in range(n + 1))
        routes_agree = (route1 == route2 == route3)
        total = sum(route1)
        maxcount = max(route1)
        pol_share = Fraction(route1[0] + route1[n], total)
        nonpol_share = 1 - pol_share
        bal_share = Fraction(route1[n // 2], total)
        computed[n] = (route1, total, maxcount, pol_share,
                       nonpol_share, bal_share)
        o_counts, o_total, o_max, o_pol, o_nonpol, o_bal = ORACLE[n]
        cells = [("record counts", route1, o_counts),
                 ("total", total, o_total),
                 ("max record count", maxcount, o_max),
                 ("polarized share", pol_share, o_pol),
                 ("non-polarized share", nonpol_share, o_nonpol),
                 ("balanced share", bal_share, o_bal)]
        bad = [(label, got, want) for label, got, want in cells
               if got != want]
        if bad or not routes_agree:
            all_ok = False
            for label, got, want in bad:
                discrepancies.append((n, label, got, want))
                print(f"  n={n}: DISCREPANCY in {label}: computed "
                      f"{got} != draft's printed {want}")
            if not routes_agree:
                print(f"  n={n}: ROUTES DISAGREE: enum {route1} vs "
                      f"comb {route2} vs multinomial {route3}")
        print(f"  n={n}: counts {route1}, total {total}, max "
              f"{maxcount}, polarized {pol_share}, non-polarized "
              f"{nonpol_share}, balanced share {bal_share} "
              f"[{'OK — routes agree, table matches' if not bad and routes_agree else 'FAIL'}]")

    print("\n--- Step 2: ratio rule (8.3) and the peak at balance ---")
    step_ok = True
    for n in range(1, 7):
        counts = computed[n][0]
        for k in range(n):
            ratio = Fraction(counts[k + 1], counts[k])
            expect = Fraction(n - k, k + 1)
            if ratio != expect:
                print(f"  (8.3) FAIL at n={n}, k={k}: ratio {ratio} "
                      f"!= (n-k)/(k+1) = {expect}")
                step_ok = False
        # strict increase below the balance point, strict decrease
        # after it (central pair tied when n is odd — the draft's
        # statement, checked in that exact form)
        lo, hi = n // 2, (n + 1) // 2
        for k in range(lo):
            if not counts[k] < counts[k + 1]:
                print(f"  peak FAIL at n={n}: counts not strictly "
                      f"increasing at k={k}: {counts}")
                step_ok = False
        for k in range(hi, n):
            if not counts[k] > counts[k + 1]:
                print(f"  peak FAIL at n={n}: counts not strictly "
                      f"decreasing at k={k}: {counts}")
                step_ok = False
        if max(counts) != counts[n // 2]:
            print(f"  peak FAIL at n={n}: maximum not at the balanced "
                  f"record: {counts}")
            step_ok = False
    ratios6 = tuple(Fraction(computed[6][0][k + 1], computed[6][0][k])
                    for k in range(6))
    if ratios6 != ORACLE_RATIOS_N6:
        print(f"  n=6 ratio sequence DISCREPANCY: computed {ratios6} "
              f"!= draft's printed {ORACLE_RATIOS_N6}")
        step_ok = False
        discrepancies.append((6, "n=6 successive ratios", ratios6,
                              ORACLE_RATIOS_N6))
    print(f"  (8.3) holds as exact Fractions for n = 1..6, all k; "
          f"counts peak at the balanced record; n=6 ratios "
          f"{tuple(str(r) for r in ratios6)} match the draft "
          f"[{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 3: balanced growth (8.5), C(2m, m) >= 2^m ---")
    step_ok = True
    for m in range(1, 9):
        c = comb(2 * m, m)
        bound = 2 ** m
        if c < bound:
            print(f"  (8.5) FAIL at m={m}: C({2*m},{m}) = {c} < "
                  f"2^{m} = {bound}")
            step_ok = False
        if m in ORACLE_BALANCED_GROWTH:
            oc, ob = ORACLE_BALANCED_GROWTH[m]
            if (c, bound) != (oc, ob):
                print(f"  (8.5) DISCREPANCY at m={m}: computed "
                      f"({c}, {bound}) != draft's printed ({oc}, {ob})")
                step_ok = False
                discrepancies.append((m, "(8.5) check values",
                                      (c, bound), (oc, ob)))
    print(f"  C(2m, m) >= 2^m for m = 1..8 (draft prints m = 1..3: "
          f"2>=2, 6>=4, 20>=8) [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 4: polarized share (8.6) and inequality (8.7), "
          "n = 1..12 ---")
    step_ok = True
    prev_nonpol = None
    for n in range(1, 13):
        total = 2 ** n
        pol = Fraction(2, total)               # (8.6): 2 / 2^n
        if pol != Fraction(1, 2) ** (n - 1) and n > 1:
            print(f"  (8.6) FAIL at n={n}: 2/2^n != 2^(1-n)")
            step_ok = False
        if n == 1 and pol != 1:
            print(f"  (8.6) FAIL at n=1: polarized share {pol} != 1")
            step_ok = False
        nonpol = 1 - pol
        if nonpol < Fraction(n - 1, n):
            print(f"  (8.7) FAIL at n={n}: non-polarized share "
                  f"{nonpol} < (n-1)/n = {Fraction(n - 1, n)}")
            step_ok = False
        if prev_nonpol is not None and not nonpol > prev_nonpol:
            print(f"  MONOTONICITY FAIL at n={n}: non-polarized share "
                  f"{nonpol} not strictly greater than previous "
                  f"{prev_nonpol}")
            step_ok = False
        prev_nonpol = nonpol
        if n <= 6:
            # enumerated cross-check of the same shares (Route 1 data)
            e_total = computed[n][1]
            e_pol = Fraction(computed[n][0][0] + computed[n][0][n],
                             e_total)
            if e_pol != pol:
                print(f"  (8.6) ENUMERATION MISMATCH at n={n}: "
                      f"{e_pol} != {pol}")
                step_ok = False
    print(f"  polarized share = 2^(1-n) exactly; non-polarized share "
          f">= (n-1)/n at every n = 1..12 and strictly increasing "
          f"in n [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 5: multinomial over r = 3 classes (§8.4), "
          "n = 1..5 ---")
    step_ok = True
    cells = 0
    for n in range(1, 6):
        enum3 = counts_by_enumeration(n, r=3)
        if sum(enum3.values()) != 3 ** n:
            print(f"  r=3 TOTAL FAIL at n={n}: {sum(enum3.values())} "
                  f"!= 3^{n}")
            step_ok = False
        for record, cnt in enum3.items():
            cells += 1
            if cnt != multinomial(record):
                print(f"  MULTINOMIAL FAIL at n={n}, record {record}: "
                      f"enumerated {cnt} != n!/(n1!n2!n3!) = "
                      f"{multinomial(record)}")
                step_ok = False
    print(f"  {cells} (record, n) cells: enumerated assignment counts "
          f"equal the multinomial counts over the actual bodies; "
          f"totals are 3^n [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 6: the balanced share does NOT grow (draft's "
          "honest reading) ---")
    bal_shares = [computed[n][5] for n in range(1, 7)]
    not_increasing = all(bal_shares[i + 1] <= bal_shares[i]
                         for i in range(5))
    print(f"  balanced record's own share, n = 1..6: "
          f"{[str(s) for s in bal_shares]} — non-increasing, exactly "
          f"as printed; concentration in §8.3 is the polarized share's "
          f"collapse, not this column [{'OK' if not_increasing else 'FAIL'}]")
    all_ok &= not_increasing

    print("\n--- PLANTED MUTANT ---")
    # Swapped-class variant: read the POLARIZED record (k = 0, every
    # body in one class) as if it were the balanced/maximal one —
    # the two records' roles swapped — and form its share.
    mut_bad = []
    for n in range(1, 7):
        counts = computed[n][0]
        total = computed[n][1]
        mut_share = Fraction(counts[0], total)     # swapped classes
        if mut_share != ORACLE[n][5]:
            mut_bad.append((n, mut_share, ORACLE[n][5]))
    caught = len(mut_bad) >= 1 and all(n >= 2 for n, _, _ in mut_bad)
    if caught:
        n0, ms, os_ = mut_bad[0]
        print(f"  [CAUGHT] M1: swapped-class variant (polarized record "
              f"read as the balanced one) mismatches the oracle at "
              f"every n = 2..6 ({len(mut_bad)} cells).")
        print(f"           witness: n={n0}: variant share "
              f"C({n0},0)/2^{n0} = {ms} != draft's balanced share "
              f"{os_}. (At n=1 the two records coincide in count, so "
              f"no variant of this swap can be caught there — stated, "
              f"not hidden.)")
    else:
        print("  [NOT CAUGHT — INVESTIGATE] M1: swapped-class variant "
              "matched the oracle.")
        all_ok = False

    print("\n" + "=" * 70)
    if discrepancies:
        print("A.5 VERDICT: FAIL — the draft's printed table DISAGREES "
              "with the independent computation:")
        for n, label, got, want in discrepancies:
            print(f"  n={n} {label}: computed {got} != printed {want}")
        print("  (Reported as found; the draft was NOT edited.)")
        return 1
    if all_ok:
        print("A.5 VERDICT: PASS — §8.3's table is reproduced exactly by")
        print("  independent enumeration (Routes 1-3 agree cell by cell);")
        print("  (8.3), (8.5), (8.6) hold exactly; (8.7) holds for")
        print("  n = 1..12 with the non-polarized share strictly")
        print("  increasing; the balanced record's own share matches")
        print("  the printed 1/2, 1/2, 3/8, 3/8, 5/16, 5/16 and does not")
        print("  grow — the draft's honest reading is the computed one.")
        return 0
    print("A.5 VERDICT: FAIL — see witness lines above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
