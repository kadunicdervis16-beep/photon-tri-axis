#!/usr/bin/env python3
"""FW.1 — Paper 12 Firewall (v1).

Sweeps Paper 12's own draft prose (staging_v1/draft/DRAFT_*.md) for the
Stage-N banned/controlled vocabulary of §0.5's construction list, OUTSIDE
the declared zones. Declared zones (a hit inside one is classified, not
suspect):
  - QUOTATION: blockquote lines, and text inside double quotes
    (verbatim quotations of other papers — mention, not use).
  - CONSTRUCTION-LIST: §0.5's construction-list table and scope prose in
    DRAFT_A (the list that fixes each locked word's disposition).
    In ASSEMBLED mode (loop remediation, EA-2.2), this zone applies ONLY
    to paragraphs inside the §0.5 section span — between the §0.5
    heading and the next §1-level heading; the phrase "construction
    list" appearing anywhere else earns no zone by itself.
  - TABLE (assembled mode only): a paragraph that is a table row/block
    (starts with "|") classifies as zone "table" — tables are declared
    mention-surfaces (rows name locked words to fix their disposition,
    census values, or registry data); they no longer fall through to
    the construction-list zone merely for containing "§0.5". Draft mode
    (--drafts) zoning is unchanged.
  - BRIDGE: a paragraph carrying a declared bridge sentence
    (marked "[BRIDGE" or self-identified as the bridge sentence).
    Since the V3 ADJ-1 adjustment below, this zone is per-term: it
    admits only bridged-disposition terms, never an excluded term
    that happens to sit in a bridge paragraph.
  - SCOPE: paragraphs whose business is the exclusion itself — they
    carry an exclusion marker (excluded / refused / locked word /
    not admitted / frame this paper refuses / ban). Naming the refused
    frame to refuse it is the paper's declared method (§0.5).
Controlled terms:
  - microstate, macrostate           (excluded — permanent, §0.5)
  - ensemble                         (excluded — permanent, §0.5)
  - probability distribution         (excluded as a primitive, §0.5)
  - Gibbs, Boltzmann                 (excluded as method; citations only)
  - temperature, entropy             (controlled: SUSPECT unless the same
                                      paragraph carries a construction or
                                      bridge marker)
  - k_B                              (bridged only: the §8 bridge sentence)
  - capacity / absorption            (accounting language: SUSPECT unless
                                      inside a quotation or §9's declared
                                      saturation construction)
  - neutrino                         (banned topic: exclusion statements
                                      and Paper 15 scoping only)
  - ∂, ∫, "derivative"               (continuous-calculus markers: no
                                      Stage N claim may carry them)

v1 LIMITS, stated plainly: classification is paragraph-local and
lexical. It cannot judge whether a "construction marker" in a paragraph
genuinely constructs the term it accompanies — that is human-audit
territory, and every hit is printed so the audit can be done. The exit
code FAILs only on SUSPECT hits; all hits are listed regardless.

DISCLOSED ZONE RULES (each is a gate a determined smuggler could hide
behind; each is therefore narrow and named here):
  - "∂G" classifies as DECLARED-SYMBOL: ∂G is Paper 11's boundary-set
    notation (|∂G| = boundary count), a finite set, not a partial
    derivative. The exemption is exactly the two characters "∂G"; "∂S",
    "∂U", "∂/∂x" etc. remain SUSPECT, and the word "derivative" has
    no exemption at all.
  - "capacity" inside §9 classifies as CONSTRUCTION: §9's declared
    subject is the saturation construction built on Paper 9 §6's words
    ("local processing capacity"), and per-junction capacity is a
    defined term of §9.4. "capacity" anywhere else must earn its zone
    from its paragraph or stand SUSPECT.
  - Refusal-shaped sentences classify as SCOPE-NOTE when they carry an
    explicit refusal marker (firewall / unrealized / "at no point … of
    its own" / "No condition above appeals to" / a heading's "without").
    Residual risk, stated: a use-sentence that happens to contain one
    of these markers would be misclassified — the printed hit list is
    the audit surface for exactly that.

INPUT_PROVENANCE:
  - Controlled-term list and dispositions: class=paper-defined
    (Paper 12 §0.5 construction list, DRAFT_A).
  - Zone rules: class=paper-defined (Paper 12 §0.5: "Quotation is
    mention, and the firewall's exemptions are written for exactly
    that"; bridge discipline from Paper 11's §0.5 lock as cited).
  - Draft files swept: class=paper-defined (staging_v1/draft/DRAFT_*.md,
    read at run time; nothing about them is hardcoded except paths).

ASSEMBLY ADJUSTMENT (2026-10-24, disclosed): the sweep target is now
chosen in main() — with no argument, the assembled paper
(staging_v1/Paper_12_v1.md); with "--drafts", the four staging drafts
(the original behaviour); with any other argument, that file. The
§0.5 construction-list zone, keyed in draft mode to DRAFT_A's file
name, is keyed to the assembled file's name as well.

LOOP REMEDIATION (2026-10-24, EA-2.2, disclosed): assembled-mode zoning
tightened as described under CONSTRUCTION-LIST and TABLE above —
section-span zoning for the construction list, table paragraphs zoned
as tables. Term patterns, all other zones, draft-mode behaviour, and
the mutant battery are unchanged.

V2 ADJUSTMENT (2026-10-25, disclosed): the default sweep target is now
the v2 assembly (staging_v3/Paper_12_v2.md), and the assembled-mode
zoning branch accepts both assembled filenames (Paper_12_v1.md,
Paper_12_v2.md) so the v2 file receives the identical zoning the v1
file received. Term patterns, marker lists, zone rules, and the mutant
battery are unchanged; the v1 file remains sweepable by passing its
path explicitly.

V2 SELF-CONTAINED ADJUSTMENT (2026-10-26, disclosed): Appendix C now
embeds other files' full texts (the verification suite's listings and
the G.1 source papers) as fenced blocks wrapped in HTML-comment
markers. Lines from a BEGIN LISTING / BEGIN SOURCE marker line through
its matching END marker line classify as the declared zone
"embedded-listing": that text is present as data — another file's
words, byte-identical and hash-checked by A.9 — not as this paper's
prose, the same mention-not-use principle as the QUOTATION zone.
Heading/section state (§ numbers, the §0.5 span flag) is NOT updated
from embedded lines, so an embedded paper's own headings cannot move
this paper's zoning state. Term patterns, marker lists, all other
zone rules, and the mutant battery are unchanged, and the pre-existing
hits classify exactly as before (verified by re-run on the
pre-embedding tree).

V3 ADJ-1 ADJUSTMENT (2026-10-26, disclosed): zoning is now PER-TERM
and SEGMENT-LOCAL. (i) The BRIDGE zone admits only terms whose §0.5
disposition is bridged or bridge-carrying (entropy, k_B, temperature).
An excluded-disposition term (microstate / macrostate / ensemble /
probability distribution, the citation-only names, the accounting
terms, the calculus markers) sitting inside a bridge paragraph earns
no zone from that paragraph's bridge marker — it must earn its own
zone at its own site (a quotation, or a scope / construction marker
in its own segment) or stand SUSPECT. Previously every term in a
"[BRIDGE" paragraph classified as bridge, term-blind, so the sweep
could not see a disposition breach inside a bridge paragraph at all
(loop adjudication ADJ-1, red-team charge RT-4). (ii) Zone phrases
are evaluated against the hit's own SEGMENT — the list item or
paragraph the hit sits in — never against a sibling item's text:
the §8 claim list is one typographic block, and under paragraph-
global zoning a claim's locked word inherited its zone from a
sibling claim's phrases (L8.9's "macrostate" was zoned by L8.5's
"bridge sentence"). Quotation parity is likewise counted over the
segment, so a quotation wrapping across an item's lines classifies
at its own site. The structural zones (the §0.5 construction-list
span, table blocks) remain paragraph-level: they are properties of
the block, not phrases in it. TERM_PATTERNS and the marker lists
are byte-identical; the mutant battery is unchanged.

V4 ADJUSTMENT (2026-10-26, disclosed): (a) the assembled-mode
filename tuple in classify() gains "Paper_12_v4.md", so the v4
assembly receives the identical assembled-mode zoning the earlier
assemblies received; (b) the default sweep target in main() is
now the v4 assembly (HERE.parent / "Paper_12_v4.md"); (c) in
sweep_file, the embedded-zone trigger also fires on lines whose
stripped form starts with "<!-- BEGIN EXHIBIT:" — Appendix E
exhibit blocks are present as data, hash-checked by A.9, the same
mention-not-use principle as BEGIN LISTING / BEGIN SOURCE. Term
patterns, marker lists, and the mutant battery are unchanged.

ROUND-2 ADJUSTMENT (2026-10-27, disclosed): TERM_PATTERNS gains one
term — "arity (bare)", the fused word retired by §0.5's terminology
note (author's ruling, corrections round 2). The pattern matches
"arity"/"arities" at a word boundary NOT preceded by "junction ":
"junction arity" (Paper 11 §4.1's defined term; this paper's port
count) never matches, and mid-word occurrences (stationarity,
parity) never match. classify() admits the bare word only as a
declared mention — quotation (handled structurally), a
construction/scope/citation-marked segment such as the §0.5 note
itself, or a table — and the mutant battery gains one mutant (X8,
a bare own-voice use) and two controls (C4, the retirement mention
in quotes; C5, the defined terms in ordinary use). Every other
term, pattern, marker list, and battery entry is unchanged.

LOOP REPAIR (2026-10-27, round-2 loop pass, disclosed): the arity
branch as first built admitted the segment-wide CONSTRUCTION /
SCOPE / CITATION marker zones, and the loop showed those lists
launder this term — their trigger words occur in ordinary native
prose, so a bare use in a marked segment classified as a mention
(witnesses E4–E4e in the loop's red-team report). The branch now
admits no marker zones: a bare "arity" is legitimate only inside
the structural zones (quotation, table, construction list,
declared scope spans), and anything else is SUSPECT. Mutants X9
(a use carrying the marker word "defined") and X10 (a use in
emphasis underscores) pin the repair. The pattern's boundaries
are letter boundaries rather than word boundaries, so emphasis
underscores do not hide the word (_arity_ matches), while
stationarity / parity / charity still cannot match; the defined
term "junction arity" remains exempt via the lookbehind, which
fails closed on any other spacing.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DRAFT_DIR = HERE.parent / "draft"

TERM_PATTERNS = [
    ("microstate", re.compile(r"microstates?", re.I)),
    ("macrostate", re.compile(r"macrostates?", re.I)),
    ("ensemble", re.compile(r"ensembles?\b", re.I)),
    ("probability distribution", re.compile(r"probability distribution", re.I)),
    ("Gibbs", re.compile(r"\bGibbs\b")),
    ("Boltzmann", re.compile(r"\bBoltzmann\b")),
    ("temperature", re.compile(r"temperature", re.I)),
    ("entropy", re.compile(r"entropy|entropies", re.I)),
    ("k_B", re.compile(r"k_B")),
    ("capacity", re.compile(r"capacity", re.I)),
    ("absorption", re.compile(r"absorp\w*", re.I)),
    ("neutrino", re.compile(r"neutrino", re.I)),
    ("∂ (partial)", re.compile(r"∂")),
    ("∫ (integral)", re.compile(r"∫")),
    ("derivative", re.compile(r"derivative", re.I)),
    ("arity (bare)", re.compile(r"(?<!junction )(?<![A-Za-z])arit(?:y|ies)(?![A-Za-z])", re.I)),
]

CONSTRUCTION_MARKERS = re.compile(
    r"construct|denotes|earned|§0\.5|bridge|Paper 9|Paper 11's lock|"
    r"definition|defined|count ratio|reconcile density", re.I)
SCOPE_MARKERS = re.compile(
    r"excluded|refus|locked word|not admitted|not rehabilitat|ban\b|"
    r"frame this paper|frame the framework|two-level|does not occur|"
    r"name nothing|no native|never native|permanent|firewall|unrealized|"
    r"at no point|of its own|No condition above appeals|"
    r"appeals to a (continuum|ensemble)", re.I)
CITATION_MARKERS = re.compile(
    r"\[CITED|Paper 9\.5|audit|citation|Stage C|contrast is the exhibit", re.I)

ITEM_START = re.compile(r"^\s*(?:[-*+]\s|#{1,6}\s)")


def segment_context(plines, idx, mstart):
    """(V3 ADJ-1) Return (local_text, local_pos): the text of the
    segment containing plines[idx] — the list item the line belongs
    to, or the whole paragraph block when it has no item boundaries —
    and the offset of the match at mstart within that text. Zone
    phrases are earned segment-locally: an item's markers never zone
    a sibling item's hits."""
    start = 0
    for j in range(idx, -1, -1):
        if ITEM_START.match(plines[j][1]):
            start = j
            break
    end = len(plines)
    for j in range(idx + 1, len(plines)):
        if ITEM_START.match(plines[j][1]):
            end = j
            break
    seg = [t for _, t in plines[start:end]]
    local_text = "\n".join(seg)
    local_pos = sum(len(t) + 1 for t in seg[:idx - start]) + mstart
    return local_text, local_pos


def paragraphs(lines):
    """Yield (start_line_no, [(line_no, text), ...]) per blank-line block."""
    cur, start = [], None
    for i, ln in enumerate(lines, 1):
        if ln.strip():
            if start is None:
                start = i
            cur.append((i, ln))
        else:
            if cur:
                yield start, cur
            cur, start = [], None
    if cur:
        yield start, cur


def in_quotes(line, match_start):
    """True if the match position sits inside a double-quoted span."""
    prefix = line[:match_start]
    return prefix.count('"') % 2 == 1


def classify(fname, para_text, line, term, mstart, section="", in_s05=False,
             local_text=None, local_pos=None):
    """Return a zone classification for one hit.

    (V3 ADJ-1) Phrase-based zoning — the bridge / construction /
    scope / citation marker checks and the quotation-parity check —
    is evaluated against local_text, the hit's own segment (see
    segment_context), never against a sibling item's phrases. The
    structural zones (construction-list span, table) remain
    paragraph-level. Without a supplied segment, local_text defaults
    to the whole paragraph (the pre-ADJ-1 behaviour)."""
    if local_text is None:
        local_text = para_text
    if local_pos is None:
        local_pos = mstart
    if term == "∂ (partial)" and line[mstart:mstart + 2] == "∂G":
        return "declared-symbol"
    if line.lstrip().startswith("#") and "without" in line.lower():
        return "scope-note"
    if fname in ("Paper_12_v1.md", "Paper_12_v2.md", "Paper_12_v3.md",
                 "Paper_12_v4.md"):
        # ASSEMBLED MODE, tightened (loop remediation, EA-2.2): the
        # construction-list zone applies ONLY inside the §0.5 section
        # span (in_s05, tracked by sweep_file); table paragraphs are
        # their own declared mention-zone, "table".
        if in_s05 and (
                "| Locked word |" in para_text or
                (para_text.lstrip().startswith("|")
                 and "Disposition" not in para_text
                 and "§0.5" in para_text) or
                "construction list" in para_text.lower()):
            return "construction-list"
        if para_text.lstrip().startswith("|"):
            return "table"
    elif fname == "DRAFT_A_frontmatter_s1-3.md" and (
            "| Locked word |" in para_text or
            (para_text.lstrip().startswith("|") and "Disposition" not in para_text
             and "§0.5" in para_text) or
            "construction list" in para_text.lower()):
        return "construction-list"
    # BRIDGE is a per-term zone (V3 ADJ-1): it admits only terms
    # whose §0.5 disposition is bridged or bridge-carrying (entropy,
    # k_B, temperature). An excluded-disposition term inside a
    # bridge paragraph earns no zone from the paragraph's marker and
    # falls through to earn its own zone at its own site.
    if term in ("entropy", "k_B", "temperature") and (
            "[BRIDGE" in local_text or "bridge sentence" in local_text):
        return "bridge"
    if line.lstrip().startswith(">"):
        return "quotation"
    if local_text[:local_pos].count('"') % 2 == 1:
        return "quotation"
    if term == "temperature" or term == "entropy":
        if CONSTRUCTION_MARKERS.search(local_text):
            return "construction"
        if SCOPE_MARKERS.search(local_text):
            return "scope-note"
        return "SUSPECT"
    if term == "k_B":
        return "SUSPECT"  # bridges handled above; anywhere else is a breach
    if term in ("Gibbs", "Boltzmann"):
        if CITATION_MARKERS.search(local_text) or SCOPE_MARKERS.search(local_text):
            return "scope-note"
        return "SUSPECT"
    if term == "capacity":
        if section.startswith("9") or "§9" in local_text \
                or "saturation" in local_text.lower():
            return "construction"
        if SCOPE_MARKERS.search(local_text):
            return "scope-note"
        return "SUSPECT"
    if term == "neutrino":
        if SCOPE_MARKERS.search(local_text) or "Paper 15" in local_text:
            return "scope-note"
        return "SUSPECT"
    if term in ("∂ (partial)", "∫ (integral)", "derivative"):
        if SCOPE_MARKERS.search(local_text):
            return "scope-note"
        return "SUSPECT"
    if term == "arity (bare)":
        # Round-2 terminology separation (§0.5's terminology note):
        # the bare word is retired in the paper's own voice;
        # "junction arity" is the defined term and never matches.
        # Tightened in the round-2 loop pass: this branch admits NO
        # marker zones. The marker lists are calibrated to the
        # thermo lock's vocabulary; for this term their trigger
        # words (defined, denotes, bridge, two-level, audit) occur
        # in ordinary native prose, so a bare USE could launder
        # through them (loop witnesses E4-E4e). A bare "arity" is a
        # legitimate mention only inside the structural zones
        # already returned above (quotation, table, construction
        # list, declared scope spans); anything reaching this
        # branch is a use. Breach.
        return "SUSPECT"
    # microstate / macrostate / ensemble / probability distribution /
    # absorption: admitted inside a declared construction paragraph
    # (e.g. §7.4 constructs "ensemble temperature" by name), as the
    # named refused frame, or in quotes — nowhere else.
    if CONSTRUCTION_MARKERS.search(local_text):
        return "construction"
    if SCOPE_MARKERS.search(local_text):
        return "scope-note"
    if CITATION_MARKERS.search(local_text):
        return "scope-note"
    return "SUSPECT"


def sweep_file(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    hits = []
    in_html_comment = False
    in_embedded = False   # inside an Appendix C BEGIN…END embedded block
    section = ""
    in_s05 = False   # inside the §0.5 section span (assembled-mode zoning)
    for pstart, plines in paragraphs(lines):
        para_text = "\n".join(t for _, t in plines)
        for li, (lno, line) in enumerate(plines):
            stripped = line.strip()
            if stripped.startswith("<!-- BEGIN LISTING:") or \
                    stripped.startswith("<!-- BEGIN SOURCE:") or \
                    stripped.startswith("<!-- BEGIN EXHIBIT:"):
                in_embedded = True
            embedded_line = in_embedded
            if not embedded_line:
                hm = re.match(r"#{1,3}\s+(\d+)", line)
                if hm:
                    section = hm.group(1)
                head = re.match(r"#{1,6}\s+(\d+)(?:\.(\d+))?", line)
                if head:
                    if head.group(1) == "0" and head.group(2) == "5":
                        in_s05 = True      # §0.5 heading (or a §0.5.x one)
                    elif head.group(1) != "0":
                        in_s05 = False     # next §1-level (or later) heading
                    # other §0.x headings: span state unchanged
            if "<!--" in line:
                in_html_comment = True
            for term, pat in TERM_PATTERNS:
                for m in pat.finditer(line):
                    if embedded_line:
                        zone = "embedded-listing"
                    elif in_html_comment:
                        zone = "draft-note"
                    else:
                        local_text, local_pos = segment_context(
                            plines, li, m.start())
                        zone = classify(path.name, para_text, line, term,
                                        m.start(), section, in_s05,
                                        local_text, local_pos)
                    ctx = line.strip()
                    if len(ctx) > 110:
                        ctx = ctx[:107] + "..."
                    hits.append((path.name, lno, term, zone, ctx))
            if "-->" in line:
                in_html_comment = False
            if stripped == "<!-- END -->":
                in_embedded = False
    return hits


def scan_snippet(text):
    """Classify hits in an arbitrary snippet (mutant battery)."""
    out = []
    lines = text.splitlines()
    for pstart, plines in paragraphs(lines):
        para_text = "\n".join(t for _, t in plines)
        for li, (lno, line) in enumerate(plines):
            for term, pat in TERM_PATTERNS:
                for m in pat.finditer(line):
                    local_text, local_pos = segment_context(
                        plines, li, m.start())
                    out.append((term, classify("SNIPPET", para_text, line,
                                               term, m.start(), "", False,
                                               local_text, local_pos)))
    return out


def mutant_battery():
    """PLANTED MUTANTS: genuine discipline violations in the paper's own
    voice — each must classify SUSPECT. CONTROLS: legitimate zone uses
    that must NOT classify SUSPECT. A mutant surviving, or a control
    flagged, fails the battery."""
    print("PLANTED MUTANT BATTERY")
    mutants = [
        ("X1 bare microstate in native voice",
         "The microstate of the body at the tick fixes its class."),
        ("X2 temperature asserted with no construction",
         "The temperature of the population rises steadily across the window."),
        ("X3 k_B outside the bridge",
         "Multiplying by k_B converts the count into physical units at Stage N."),
        ("X4 neutrino content asserted",
         "The neutrino carries the missing count away from the junction."),
        ("X5 calculus marker in a native claim",
         "The rate is the derivative of the census with respect to the tick."),
        ("X6 capacity/absorption accounting",
         "The junction's capacity absorbs the excess load without record."),
        ("X7 ensemble as method",
         "Averaging over the ensemble gives the population's frequency."),
        ("X8 bare arity in native voice",
         "The arity of the shared-centre junction is 3, so the boundary count follows."),
        ("X9 bare arity laundered by a marker word",
         "The arity, as defined at §3.1, is 3 for the shared-centre junction."),
        ("X10 bare arity in emphasis underscores",
         "The junction's _arity_ is 3 at the shared centre."),
    ]
    controls = [
        ("C1 locked word inside a verbatim debt quotation",
         "> (1) a microstate-counting rule, and (2) a sampling-measure postulate."),
        ("C2 k_B inside the declared bridge sentence",
         "[BRIDGE — Stage P] The assignment count is read through S = k_B ln Ω."),
        ("C3 excluded frame named to refuse it",
         "The ensemble is excluded — permanent: it names an imagined collection."),
        ("C4 the retired word named in quotes to retire it",
         "The bare word \"arity\" is retired in this paper; the counts it fused are defined separately."),
        ("C5 the defined terms in ordinary use",
         "A junction of side count 3 is routed, whatever its junction arity."),
    ]
    ok = True
    for mid, text in mutants:
        zones = [z for _, z in scan_snippet(text)]
        caught = "SUSPECT" in zones
        ok &= caught
        print(f"  [{'CAUGHT' if caught else 'SURVIVED — FAIL'}] {mid}: zones={zones}")
    for mid, text in controls:
        zones = [z for _, z in scan_snippet(text)]
        clean = "SUSPECT" not in zones
        ok &= clean
        print(f"  [{'CLEAN' if clean else 'FALSE POSITIVE — FAIL'}] {mid}: zones={zones}")
    return ok


def main():
    print("=" * 70)
    print("FW.1 — PAPER 12 FIREWALL (v1): controlled vocabulary outside "
          "declared zones")
    print("=" * 70)
    args = sys.argv[1:]
    if args and args[0] == "--drafts":
        files = sorted(DRAFT_DIR.glob("DRAFT_*.md"))
    elif args:
        files = [Path(args[0])]
    else:
        files = [HERE.parent / "Paper_12_v4.md"]
    if not files or not all(f.exists() for f in files):
        print("FW.1 VERDICT: FAIL — sweep target(s) not found:", files)
        return 1
    all_hits = []
    for f in files:
        all_hits.extend(sweep_file(f))
    suspects = [h for h in all_hits if h[3] == "SUSPECT"]
    print(f"Files swept: {len(files)}; total hits: {len(all_hits)}; "
          f"SUSPECT: {len(suspects)}")
    print("-" * 70)
    print("ALL HITS (file:line [term] zone — context):")
    for fname, lno, term, zone, ctx in all_hits:
        print(f"  {fname}:{lno} [{term}] {zone} — {ctx}")
    print("-" * 70)
    mutants_ok = mutant_battery()
    print("=" * 70)
    if suspects or not mutants_ok:
        print(f"FW.1 VERDICT: FAIL — {len(suspects)} SUSPECT hit(s) for "
              f"human adjudication"
              + ("" if mutants_ok else "; mutant battery failed"))
        for fname, lno, term, zone, ctx in suspects:
            print(f"  SUSPECT: {fname}:{lno} [{term}] — {ctx}")
        return 1
    print("FW.1 VERDICT: PASS — no SUSPECT hits; every controlled-term "
          "occurrence sits in a declared zone (quotation / construction "
          "list / bridge / scope note / table / embedded-listing); "
          "mutants caught, controls clean.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
