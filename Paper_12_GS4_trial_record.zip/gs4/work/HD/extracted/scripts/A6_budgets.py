#!/usr/bin/env python3
"""A.6 — Reconcile-Budget Identities for Paper 12 (§§7, 9).

ORACLE-UNDER-TEST DISCIPLINE: the numbers printed in DRAFT_C (§§7–9) are
the oracle under test, never the input to their own verification. This
script extracts the PRINTED INPUTS from the draft's own tables (the §7.5
reconcile table, the §9.5 junction-demand table) and the printed claim
values stated in the prose, then RECOMPUTES every identity from those
inputs by independent arithmetic. Any disagreement between a printed
value and its recomputation is reported with a witness (printed vs
recomputed). Nothing in the recomputation path reads a printed result.

Checks:
  [1] Paper 10 eq. (2.4) worked contact tick (§7.2): printed inputs
      v²_contact = 40, s² = 21, N_id = 3, N_total = 100 CU.
      Recomputed: N_reconcile = 100 − 3 − 40 − 21; quiescent check via
      eq. (2.2a)/(2.2c): v²_quiescent = v²_contact + N_reconcile and
      N_id + v²_quiescent + s² = 100; bound (7.2): 97 − v²_contact − s².
  [2] §7.5 population example: the 4×10 reconcile table is parsed from
      the draft; body totals, R(P, W), M·|W|, D(P, W) = 41/40, the four
      local densities (6/5, 7/10, 9/5, 2/5) and the (7.4) mean-of-locals
      identity are all recomputed from the cells and compared against
      the values the draft prints.
  [3] §9.3 flowing-equilibrium example: flow counts F as printed;
      (9.1) row sums, (9.2)/(9.3) stationarity, Ω(2; 4) maximality over
      {C(4,k)}, aggregate τ drop = 2 × acting junctions; counter-
      example (4, 0): stationary, Ω = 1, not maximal.
  [4] §9.5 threshold example: the junction table is parsed from the
      draft; per-row totals, booked reconcile under the 100 CU cap,
      deferred reconcile demand, population totals (demanded / booked /
      deferred), J_sat: 0 → 2 and the fraction 2/3 are recomputed.
  [5] ULP eq. (2.7) (Paper 10 §2.4.7 / §2.2): S(d) = s²/N(d) with
      N(d) = 4d² + 2, for d = 1..6, against DIRECT shell enumeration:
      lattice points (x, y, z) ∈ ℤ³ with |x| + |y| + |z| = d are
      counted by brute force; the count must equal 4d² + 2, and the
      shell identity Σ_{shell(d)} S(d) = s² (eq. 2.6) must hold exactly
      (Fraction arithmetic, several s² values).
      DISCLOSED (loop remediation, EA-3.2): the eq. (2.6) leg is
      DEFINITIONAL given S(d) := s²/N(d) — N·S = s² by construction,
      and it is reported as such below. The computational CONTENT of
      this check is the independent shell enumeration: the brute-force
      count n must equal 4d² + 2, and S(d) is evaluated at the
      ENUMERATED n, not at the formula's.

All arithmetic is exact (int / fractions.Fraction). No floats.

INPUT_PROVENANCE:
  - §7.5 and §9.5 table cells, §7.2 worked-tick inputs, §9.3 flow
    counts: class=paper-defined (Paper 12 DRAFT_C, staging_v1 — the
    oracle under test; parsed from the draft file at run time).

ASSEMBLY ADJUSTMENT (2026-10-24, disclosed): the oracle file is now
chosen at import — with no argument, the assembled paper
(staging_v1/Paper_12_v1.md, which carries §§7/9 verbatim); with
"--drafts", the original oracle DRAFT_C_s7-9.md; with any other
argument, that file. The checks are untouched.

V2 ADJUSTMENT (2026-10-25, disclosed): the default oracle file is
now the v2 assembly (staging_v3/Paper_12_v2.md), which carries the
§§7/9 worked passages verbatim from v1. The checks are untouched.

V2 EXTRACTION REPAIR (2026-10-25, disclosed): the §7.5 and §9.5
table selections were document-global — the LAST table in the file
whose header matched the signature won. That was safe while the
§7.5/§9.5 tables were the last of their signatures; Appendix D's
same-signature tables (a "tick" reconcile table, a "junction" tick
table) silently hijacked both selections and A.6 failed on the v2
assembly. Selection is now scoped to the §7.5 and §9.5 section
spans — the tables this header always named ("the §7.5 reconcile
table, the §9.5 junction-demand table"). No check, oracle pattern,
or recomputation changed; the v1 assembly still passes under the
repair (verified at the repair), so the verified domain did not
move.
  - N_total = 100 CU, N_id = 3, C_exec = 97, eqs. (2.2a)/(2.2c)/(2.4):
    class=cited-paper (Paper 10 §2.2; paper10.txt L933–985).
  - S(d) = s²_node/N(d), N(d) = 4d²+2, eq. (2.6): class=cited-paper
    (Paper 10 §2.2 eq. 2.6, §2.4.1, §2.4.7 eq. 2.7).
  - Shell points counted by direct ℤ³ enumeration in this script:
    class=paper-defined (independent oracle; no input from the draft).

V4 NOTE (2026-10-26, disclosed): default paper target is now the v4 assembly; no check logic changed.
"""
import re
import sys
from fractions import Fraction
from math import comb
from pathlib import Path

HERE = Path(__file__).resolve().parent
if len(sys.argv) > 1 and sys.argv[1] == "--drafts":
    DRAFT_C = HERE.parent / "draft" / "DRAFT_C_s7-9.md"
elif len(sys.argv) > 1:
    DRAFT_C = Path(sys.argv[1])
else:
    DRAFT_C = HERE.parent / "Paper_12_v4.md"

FAILURES = []


def report(ok, label, detail=""):
    tag = "PASS" if ok else "FAIL"
    print(f"  [{tag}] {label}" + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(f"{label}: {detail}")


def strip_md(cell):
    return cell.replace("**", "").strip()


def parse_tables(lines):
    """Yield (start_line, table) pairs: markdown tables as lists of
    rows (lists of stripped cells), with the 1-based line number of
    the table's first row."""
    tables, cur, cur_start = [], [], None
    for i, ln in enumerate(lines, 1):
        s = ln.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [strip_md(c) for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                continue
            if not cur:
                cur_start = i
            cur.append(cells)
        else:
            if cur:
                tables.append((cur_start, cur))
                cur = []
    if cur:
        tables.append((cur_start, cur))
    return tables


def section_span(lines, sec):
    """(start, end) 1-based line span of the '### sec ...' section —
    from its heading to the next ## or ### heading. Falls back to the
    whole document when the heading is absent (drafts mode)."""
    pat = re.compile(r"^#{2,3}\s+" + re.escape(sec) + r"\b")
    start = None
    for i, ln in enumerate(lines, 1):
        if start is None:
            if pat.match(ln):
                start = i
        elif re.match(r"^#{2,3}\s+", ln):
            return (start, i)
    if start is not None:
        return (start, len(lines) + 1)
    return (0, len(lines) + 1)


def extract_oracles(text):
    """Pull every printed claim value A.6 is responsible for out of the
    draft, so the checks compare recomputation against what is printed —
    not against a second copy typed into this script."""
    o = {}
    m = re.search(r"Body-ticks: \|P\| · \|W\| = 4 · 10 = 40", text)
    o["body_ticks_printed"] = 40 if m else None
    m = re.search(r"R\(P, W\) = 12 \+ 7 \+ 18 \+ 4 = \*\*41\*\*", text)
    o["R_printed"] = 41 if m else None
    m = re.search(r"D\(P, W\) = 41/40", text)
    o["D_printed"] = Fraction(41, 40) if m else None
    m = re.search(r"T_ledger\(A, W\) = 12/10 = 6/5; T_ledger\(B, W\) = 7/10;\s*"
                  r"T_ledger\(C, W\) = 18/10 = 9/5; T_ledger\(D, W\) = 4/10 = 2/5", text)
    o["locals_printed"] = ([Fraction(6, 5), Fraction(7, 10),
                             Fraction(9, 5), Fraction(2, 5)] if m else None)
    m = re.search(r"\(41/10\)/4 = 41/40", text)
    o["mean_printed"] = Fraction(41, 40) if m else None
    m = re.search(r"N_reconcile = 100 [−-] 3 [−-] 40 [−-] 21 = \*\*36\*\*", text)
    o["nrec_printed"] = 36 if m else None
    m = re.search(r"v²_quiescent = 40 \+ 36 = 76", text)
    o["vqui_printed"] = 76 if m else None
    m = re.search(r"3 \+ 76 \+ 21 = 100", text)
    o["quiescent_check_printed"] = 100 if m else None
    m = re.search(r"demanded load = 105 \+ 88 \+ 100 = 293 CU; booked\s*"
                  r"load = 100 \+ 88 \+ 100 = 288 CU; deferred reconcile demand = 5 CU", text)
    o["pop_totals_printed"] = (293, 288, 5) if m else None
    m = re.search(r"J_sat goes 0 → 2 at τ, saturation\s*fraction 2/3", text)
    o["jsat_printed"] = (0, 2, Fraction(2, 3)) if m else None
    m = re.search(r"Aggregate τ drops by 2 × 2 = 4", text)
    o["tau_drop_printed"] = 4 if m else None
    return o


def check_worked_tick():
    print("[1] Paper 10 eq. (2.4) worked contact tick (§7.2)")
    n_id, v2c, s2 = 3, 40, 21  # printed inputs, DRAFT_C §7.2
    n_rec = 100 - n_id - v2c - s2
    report(n_rec == 36, "N_reconcile = 100 − 3 − 40 − 21",
           f"recomputed {n_rec}, draft prints 36")
    report(97 - v2c - s2 == n_rec, "(7.2) bound route: 97 − v²_contact − s²",
           f"recomputed {97 - v2c - s2}")
    v_qui = v2c + n_rec  # eq. (2.2a)
    report(v_qui == 76, "v²_quiescent = v²_contact + N_reconcile (2.2a)",
           f"recomputed {v_qui}, draft prints 76")
    total = n_id + v_qui + s2  # eq. (2.2c)
    report(total == 100, "quiescent check: 3 + 76 + 21 = 100 (2.2c)",
           f"recomputed {total}")
    report(n_rec <= 97, "N_reconcile ≤ 97", f"N_reconcile = {n_rec}")


def check_population_example(tables, o, span=(0, float("inf"))):
    print("[2] §7.5 population reconcile density example")
    lo, hi = span
    tbl = None
    for start, t in tables:
        if lo <= start < hi and t and t[0] and t[0][0].startswith("tick"):
            tbl = t
            break
    if tbl is None:
        report(False, "§7.5 table located", "table not found in DRAFT_C")
        return
    rows = [r for r in tbl[1:] if re.fullmatch(r"\d+", r[0])]
    totals_row = [r for r in tbl[1:] if "body total" in r[0]]
    report(len(rows) == 10, "window |W| = 10 ticks parsed", f"{len(rows)} rows")
    cells = [[int(x) for x in r[1:5]] for r in rows]
    body_totals = [sum(col) for col in zip(*cells)]
    printed_totals = [int(x) for x in totals_row[0][1:5]] if totals_row else None
    report(body_totals == [12, 7, 18, 4] and body_totals == printed_totals,
           "body totals A,B,C,D recomputed from cells",
           f"recomputed {body_totals}, draft prints {printed_totals}")
    R = sum(body_totals)
    report(R == 41 and o["R_printed"] == 41, "R(P, W) = Σ body totals",
           f"recomputed {R}, draft prints {o['R_printed']}")
    bt = 4 * 10
    report(bt == 40 and o["body_ticks_printed"] == 40, "body-ticks |P|·|W| = 4·10",
           f"recomputed {bt}")
    D = Fraction(R, bt)
    report(D == Fraction(41, 40) and o["D_printed"] == D,
           "D(P, W) = R/(|P|·|W|) = 41/40", f"recomputed {D}")
    locals_ = [Fraction(t, 10) for t in body_totals]
    report(locals_ == [Fraction(6, 5), Fraction(7, 10), Fraction(9, 5), Fraction(2, 5)]
           and o["locals_printed"] == locals_,
           "local densities 6/5, 7/10, 9/5, 2/5",
           f"recomputed {[str(x) for x in locals_]}")
    mean = sum(locals_) / 4  # identity (7.4)
    report(mean == D and o["mean_printed"] == mean,
           "(7.4) mean of locals = D(P, W)", f"mean {mean}, D {D}")


def check_flowing_equilibrium():
    print("[3] §9.3 stationarity / flowing-equilibrium arithmetic")
    # Printed flow counts (DRAFT_C §9.3): census (2,2); F_AA=1, F_AB=1,
    # F_BA=1, F_BB=1. Classes ordered [A, B]; F[i][j] = flow i→j.
    F = [[1, 1], [1, 1]]
    before = [2, 2]
    out_ = [sum(row) for row in F]                       # (9.1)
    in_ = [sum(F[j][i] for j in range(2)) for i in range(2)]  # (9.2)
    report(out_ == before, "(9.1) Σ_j F_{i→j} = n_i(τ)", f"out {out_}")
    after = in_
    report(after == before, "(9.2) census after tick = (2, 2)",
           f"after {after}")
    report(all(out_[i] == in_[i] for i in range(2)),
           "(9.3) net flow Φ_i = 0 for every class (stationary)",
           f"out {out_}, in {in_}")
    omegas = [comb(4, k) for k in range(5)]
    report(omegas == [1, 4, 6, 4, 1] and comb(4, 2) == 6 == max(omegas),
           "Ω(2; 4) = C(4,2) = 6, maximal among {1,4,6,4,1}",
           f"Ω table {omegas}")
    acting = 2  # printed: exactly two junctions act
    report(2 * acting == 4, "aggregate τ drop = 2 × acting junctions = 4",
           f"recomputed {2 * acting}")
    # Counter-example (4, 0): stationary but Ω minimal → not equilibrium.
    report(comb(4, 0) == 1 and comb(4, 0) != max(omegas),
           "counter-example (4,0): Ω = 1, not maximal — (E2) fails",
           f"Ω(0;4) = {comb(4, 0)}")


def check_threshold_example(tables, o, span=(0, float("inf"))):
    print("[4] §9.5 worked threshold example")
    lo, hi = span
    tbl = None
    for start, t in tables:
        if lo <= start < hi and t and t[0] and t[0][0] == "junction":
            tbl = t
            break
    if tbl is None:
        report(False, "§9.5 table located", "table not found in DRAFT_C")
        return
    cap = 100
    dem_tot = booked_tot = deferred_tot = 0
    jsat = 0
    for r in tbl[1:]:
        name = r[0]
        n_id, v2c, s2, rec_dem = (int(r[1]), int(r[2]), int(r[3]), int(r[4]))
        printed_total, printed_booked, printed_def = int(r[5]), int(r[6]), int(r[7])
        total = n_id + v2c + s2 + rec_dem
        booked = min(total, cap)
        base = n_id + v2c + s2
        booked_rec = rec_dem if total <= cap else cap - base
        deferred = rec_dem - booked_rec
        ok = (total == printed_total and booked == printed_booked
              and deferred == printed_def)
        report(ok, f"{name}: demand/booked/deferred recomputed",
               f"recomputed ({total}, {booked}, {deferred}), "
               f"draft prints ({printed_total}, {printed_booked}, {printed_def})")
        if name == "J₁":
            report(booked_rec == 27 and deferred == 5,
                   "J₁ booked reconcile = 100 − (3+55+15) = 27; deferred 5",
                   f"booked_rec {booked_rec}, deferred {deferred}")
        dem_tot += total
        booked_tot += booked
        deferred_tot += deferred
        if total >= cap:
            jsat += 1
    report((dem_tot, booked_tot, deferred_tot) == (293, 288, 5)
           and o["pop_totals_printed"] == (293, 288, 5),
           "population totals: demanded 293, booked 288, deferred 5",
           f"recomputed {(dem_tot, booked_tot, deferred_tot)}")
    report(jsat == 2 and o["jsat_printed"] == (0, 2, Fraction(2, 3)),
           "J_sat: 0 → 2; saturation fraction 2/3",
           f"J_sat(τ) recomputed {jsat}, fraction {Fraction(jsat, 3)}")


def shell_count_bruteforce(d):
    pts = 0
    for x in range(-d, d + 1):
        for y in range(-d, d + 1):
            z = d - abs(x) - abs(y)
            if z < 0:
                continue
            pts += 1 if z == 0 else 2  # z and −z
    return pts


def check_ulp():
    print("[5] ULP eq. (2.7): S(d) = s²/N(d), N(d) = 4d² + 2, d = 1..6, "
          "vs direct shell enumeration")
    print("    NOTE (EA-3.2): the eq. (2.6) leg below is definitional "
          "given S(d) := s²/N(d);")
    print("    the check's content is the independent enumeration "
          "n == 4d² + 2, with S(d) taken at the enumerated n.")
    for d in range(1, 7):
        n_formula = 4 * d * d + 2
        n_brute = shell_count_bruteforce(d)
        report(n_brute == n_formula, f"d = {d}: shell enumeration = 4d² + 2",
               f"enumerated {n_brute}, formula {n_formula}")
        for s2 in (1, 21, 97):
            S = Fraction(s2, n_brute)
            report(n_brute * S == s2,
                   f"d = {d}, s² = {s2}: eq. (2.6) Σ_shell S(d) = s²",
                   f"N(d)·S(d) = {n_brute * S}")


def mutant_battery(o):
    """PLANTED MUTANTS: corrupted oracle values of exactly the kind a
    drafting typo produces. The recomputation core must REJECT each —
    i.e. the recomputed value must differ from the mutant's printed
    value. A mutant that 'passes' means the check is vacuous."""
    print("PLANTED MUTANT BATTERY")
    mutants = [
        ("M1 off-by-one reconcile", 100 - 3 - 40 - 21, 35),
        ("M2 wrong body total (A: 12→13)", 12, 13),
        ("M3 wrong deferred demand (J₁: 5→4)", 32 - (100 - (3 + 55 + 15)), 4),
        ("M4 wrong shell count (N(3): 38→40)", shell_count_bruteforce(3), 40),
        ("M5 wrong population density (41/40→21/20)", Fraction(41, 40), Fraction(21, 20)),
    ]
    ok_all = True
    for mid, recomputed, mutant_printed in mutants:
        rejected = recomputed != mutant_printed
        ok_all &= rejected
        print(f"  [{'REJECTED' if rejected else 'SURVIVED — FAIL'}] {mid}: "
              f"recomputed {recomputed} vs mutant printed {mutant_printed}")
    return ok_all


def main():
    print("=" * 70)
    print("A.6 — RECONCILE-BUDGET IDENTITIES (Paper 12 §§7, 9; ULP eq. 2.7)")
    print("=" * 70)
    text = DRAFT_C.read_text(encoding="utf-8")
    lines = text.splitlines()
    tables = parse_tables(lines)
    o = extract_oracles(text)
    missing = [k for k, v in o.items() if v is None]
    if missing:
        report(False, "oracle extraction from DRAFT_C",
               f"printed patterns not found: {missing}")
    check_worked_tick()
    check_population_example(tables, o, section_span(lines, "7.5"))
    check_flowing_equilibrium()
    check_threshold_example(tables, o, section_span(lines, "9.5"))
    check_ulp()
    mutants_ok = mutant_battery(o)
    print("=" * 70)
    if FAILURES or not mutants_ok:
        print(f"A.6 VERDICT: FAIL — {len(FAILURES)} check failure(s)"
              + ("" if mutants_ok else "; mutant battery failed"))
        for f in FAILURES:
            print(f"  WITNESS: {f}")
        return 1
    print("A.6 VERDICT: PASS — every printed §7/§9 identity recomputes "
          "from its printed inputs; ULP shells enumerated d = 1..6; "
          "all mutants rejected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
