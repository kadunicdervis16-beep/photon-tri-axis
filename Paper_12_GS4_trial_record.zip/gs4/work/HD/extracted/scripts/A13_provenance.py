#!/usr/bin/env python3
"""A.13 — Provenance formalization consistency (Paper 12 §0.4(b)).

Machine companion to the declared receipt at Paper 12 §0.4(b): Paper
11 §6.1's bonding-mode premise — each bonding mode establishes its
junction by consuming the open status of at least one port at each
participating configuration — received from Paper 2 §11.1 as a
declared receipt, because Paper 2 predates the badge apparatus and
Paper 11 nowhere registers the premise as a claim in its own right.
This script does NOT prove the premise, and does not check Paper 2's
content. It consistency-checks the premise's port-counting
formalization — the rendering Paper 11 §4.3's bookkeeping consumes —
in the open: two independent computations of the formalization's
legality, and its bookkeeping identity verified on every legal
transition of the two-party shape. It is the suite's thirteenth
script in run order. It backs no claim's badge; it is named at
§0.4(b) and in Appendix B's script key as a suite-level check.

COVERAGE MAP (the house discipline: badge never outruns the
verified domain).
  NATIVE DOMAIN: the premise as Paper 12 consumes it — bonding-mode
    applications over bonded aggregates of inventory bodies, whose
    bookkeeping is B(G) = 6N − Σ_j k_j (Paper 11 §4.3), consumed at
    Paper 12 §4 through Theorem 4.2.
  VERIFIED DOMAIN: the port-status formalization of the premise.
    A state is one 6-bit consumed-mask per node plus a booked
    accumulator per party — one running booked count for each
    node, whose sum is the running Σ_j k_j. Two application
    shapes, and only two: DOCKING — an ordered pair of distinct
    nodes (outer, centre), a draw being a nonempty subset of each
    party's ports; CONVERGENCE — an unordered triple of distinct
    nodes, a draw being exactly one port at each party (Paper 11
    §4.3: the three-way junction consumes exactly one port per
    node). An application is legal iff every port it draws is open.
    The nonemptiness of a draw — and convergence's
    exactly-one-port shape — is carried by the construction of
    the attempted spaces: the draw generators enumerate nonempty
    subsets (resp. singletons) only, and no classifier, invariant,
    or reachability computation in this script enforces the
    condition. The empty draw at any party (draw {0} at a docking
    party, or at a convergence party) stands outside the attempted
    spaces as constructed, and no check below speaks to it.
  THE MAP: ports are labelled (node, index) pairs; the mask form
    and the labelled-set form are the two representations the two
    oracles compute in. The map preserves exactly the counting
    content: which ports are consumed, how many each junction
    books, and the boundary identity B = 6N − Σk_j.
  WHAT THE CHECK ESTABLISHES: (i) the two oracles — a bit-mask
    rule and an explicit labelled-set simulation, written
    independently — agree on legality over the full attempted
    per-party spaces (docking role 64 × 63 = 4,032 classifications;
    convergence role 64 × 6 = 384); (ii) composed two-party
    legality — the conjunction of the per-party tables — equals
    the direct fused computation on every attempted pair
    combination (16,257,024), the composed legality count equals
    the closed form on every mask pair, and the legal-transition
    total is 442,225 by both enumeration and closed form; (iii)
    on every one of those 442,225 legal docking
    transitions, the two implementations produce the same consumed
    set, the booked increment equals the number of ports drawn,
    and booked equals the consumed count with B ≥ 0 after the
    transition — and, per party, each party's booked increment
    equals the number of ports that party itself drew, checked in
    the labelled-set representation on every transition, with
    every alternative split of a transition's booked total
    across its two parties rejected on every transition (the
    split dimension is verified, not just the total); (iv) for convergence, the per-party conjunction
    law is verified for every mask triple (262,144) at a fixed
    draw and across draws on a fixed-seed sample, and the
    legal-draw count identity Σ Π(6 − popcount) =
    192³ = 7,077,888 holds over all mask triples, with transition
    invariants verified on a fixed-seed sample of legal
    convergence transitions — the per-party invariant among
    them: on every sampled convergence transition the drawn
    split (1, 1, 1) is accepted and every other split of the
    same total is rejected; (v) reachability at N = 2 is exactly
    the predicted state set — the empty state plus every mask pair
    with both masks nonzero (3,970 states) — with the invariant
    holding on every reached state in both its forms: the
    reached enriched states (mask pair with its booked vector)
    are exactly the 3,970 predicted, and the booked vector at
    every reached state is that state's own per-party consumed
    vector, on every path — the reachability and walk
    computations accumulate the booked vector by the drawn
    increments, so that accumulation is carried by their
    construction, as the nonemptiness above is carried by the
    attempted spaces' construction; what is checked is the
    reached set's exactness and the accumulated vector's
    agreement with the state's own consumed vector on every
    path and at every step, not the accumulation's freedom to
    misbook, which the transition-level checks (iii) and (iv)
    test directly; at N = 1 no application of
    either shape exists (asserted, not skipped); at N = 3,
    fixed-seed sampled paths under both shapes agree between the
    implementations with zero disagreements, the per-party
    booked vector tracking each party's own consumed count at
    every step. The lift from the
    pair/triple tables to arbitrary finite N is the locality of
    the shapes — an application touches only its parties' ports —
    stated here as prose, NOT enumerated by this script.
  OUTSIDE THE CHECK, stated plainly: the premise itself (a
    formalization's consistency is not the premise's truth);
    Paper 2's single-integer matching rule (a docking is valid
    when the receiving centre holds at least two matching
    integers and is not already resolved); the centre-saturation
    predicate (a property of a centre's three values — Paper 11
    §6.1's Triplet Saturation — not of ports); the modes'
    geometry; events of more than three parties; and whether any
    physical junction answers to a mode (Stage P).

MUTANTS (genuine violations of the formalization's rules, each
REJECTED with a printed witness): M1, a classifier variant that
admits a one-port draw naming a consumed port — the per-party
oracle agreement reports the disagreement, and the application
it licenses is shown to double-book the port; M2, a convergence
variant drawing two ports at one party while booking one per
party — the bookkeeping invariant rejects it; M3, a transition
variant booking |drawn| + 1 — the invariant rejects it at the
first transition; M4, a per-party misbooking — the KD-1 battery's
Z8 shape-(i) witness: a docking drawing two ports at one party
and one at the other, booked (1, 2) against the drawn (2, 1) —
the global invariant accepts it, because the total is preserved,
and the per-party invariant rejects it with a witness; M5, a
convergence transition booking its three drawn ports as
(2, 1, 0) across the parties — the per-party invariant rejects
it. DIAGNOSTIC (labelled, not counted among the
rejections): the premise-free classifier, under which every draw
is legal, breaks the bookkeeping identity on the second
application to the same port — printed to show the formalization's
rule is load-bearing in the model, not as a rejection.

INPUT_PROVENANCE:
  - Six ports per node: class=cited-paper (Paper 11 §4.1, §4.3 —
    B(G) = 6N − Σ_j k_j).
  - The two application shapes: class=cited-paper (Paper 2 §11.1's
    two bonding modes as rendered at Paper 11 §6.1 — at least one
    port at each participating configuration; convergence's one
    port per party from Paper 11 §4.3's proof).
  - The formalization itself (masks, draws, the booked
    accumulator, the predicted N = 2 reachable set):
    class=paper-defined (Paper 12 §0.4(b); this script's coverage
    map above).
  - The per-party booked accumulators and the per-party
    invariant: class=paper-defined (the §0.4(b) formalization,
    extended at round 8 on the author's ruling: a junction's
    booking is kept per party — the count of that junction's
    drawn ports at that party — so the split of every booked
    total across its parties is part of the checked state, not
    an unexamined consequence of the total).
  - The two oracles: class=control (independent implementations
    written for this check; their agreement is the check's
    object, so neither is derived from the other).
  - Sample seeds: class=control (fixed seeds, printed at run
    time; samples are labelled samples wherever they occur).
"""
import random
import sys
from collections import deque

PC = [bin(m).count("1") for m in range(64)]
NONEMPTY = list(range(1, 64))
SINGLETONS = [1 << i for i in range(6)]
SEED = 20261028

FAILURES = []


def report(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(name)
    return ok


def ports_of(node, bits):
    """The labelled port set of one node's bit pattern."""
    return {(node, i) for i in range(6) if (bits >> i) & 1}


def consumed_set(masks):
    out = set()
    for node, m in enumerate(masks):
        out |= ports_of(node, m)
    return out


def legal_bit(mask, draw):
    """ORACLE A — the bit rule: a draw is legal iff it names no
    consumed port of the party's mask."""
    return draw & mask == 0


def legal_set(consumed, node, draw):
    """ORACLE B — the set rule: a draw is legal iff its labelled
    port set is disjoint from the consumed set."""
    return ports_of(node, draw).isdisjoint(consumed)


def submasks(comp):
    s = comp
    while s:
        yield s
        s = (s - 1) & comp


def per_party_agreement(draws, oracle_a=legal_bit):
    """Exhaustive agreement of the two oracles over one role's
    full attempted space. Returns (count, first_disagreement)."""
    n = 0
    for mask in range(64):
        consumed = ports_of(0, mask)
        for d in draws:
            n += 1
            if oracle_a(mask, d) != legal_set(consumed, 0, d):
                return n, (mask, d)
    return n, None


def invariant_holds(masks_before, booked_before, draws, booked_increment):
    """The bookkeeping invariant across one application, computed
    in the set representation: after the application the booked
    total must equal the consumed count (the boundary identity
    B = 6N − booked then gives the open count, ≥ 0). Returns a
    witness string on violation, else None."""
    consumed = consumed_set(masks_before)
    for node, d in enumerate(draws):
        consumed |= ports_of(node, d)
    booked_after = booked_before + booked_increment
    if booked_after != len(consumed):
        return (f"booked {booked_after} != consumed {len(consumed)} "
                f"(masks {masks_before}, draws {draws})")
    if booked_after > 6 * len(masks_before):
        return f"boundary negative: booked {booked_after} > 6N"
    return None


def invariant_holds_pp(masks_before, booked_pp_before, draws,
                       booked_pp_after):
    """The per-party bookkeeping invariant across one application,
    computed in the set representation: at each party, that party's
    booked count before the application must equal its own
    consumed count before it, and its booked count after the
    application must equal its own consumed count after it (its
    own count, not a share of the total); the parties' booked
    counts must sum to the consumed total, which the boundary
    identity bounds by 6N. A call whose tuples disagree in length,
    or which names no party, is out of shape and is rejected, not
    certified. Returns a witness string on violation, else None."""
    if not draws or not (len(masks_before) == len(booked_pp_before)
                         == len(draws) == len(booked_pp_after)):
        return (f"shape: masks {masks_before}, booked-before "
                f"{booked_pp_before}, draws {draws}, booked-after "
                f"{booked_pp_after} do not agree in length")
    total = 0
    for node, d in enumerate(draws):
        consumed_before = len(ports_of(node, masks_before[node]))
        if booked_pp_before[node] != consumed_before:
            return (f"party {node} booked-before "
                    f"{booked_pp_before[node]} != its own consumed "
                    f"count before {consumed_before} "
                    f"(masks {masks_before}, draws {draws})")
        consumed_here = len(ports_of(node, masks_before[node] | d))
        total += consumed_here
        if booked_pp_after[node] != consumed_here:
            return (f"party {node} booked {booked_pp_after[node]} "
                    f"!= its own consumed count {consumed_here} "
                    f"(masks {masks_before}, draws {draws})")
    if sum(booked_pp_after) != total:
        return (f"per-party booked {booked_pp_after} sums to "
                f"{sum(booked_pp_after)} != consumed {total}")
    if sum(booked_pp_after) > 6 * len(masks_before):
        return (f"boundary negative: booked {sum(booked_pp_after)} "
                f"> 6N")
    return None


def main():
    print("=" * 70)
    print("A.13 — PROVENANCE FORMALIZATION CONSISTENCY (§0.4(b)): the")
    print("bonding-mode receipt's port-counting formalization, dually")
    print("computed over its full attempted spaces")
    print("=" * 70)

    # (1) per-party attempted spaces, both oracles, exhaustive
    n, bad = per_party_agreement(NONEMPTY)
    report("(1a) docking role: per-party legality, bit rule vs set "
           "rule, full attempted space", bad is None and n == 4032,
           f"{n} classifications, disagreement: {bad}")
    n, bad = per_party_agreement(SINGLETONS)
    report("(1b) convergence role: per-party legality, both oracles, "
           "full attempted space", bad is None and n == 384,
           f"{n} classifications, disagreement: {bad}")

    # (2a) composed two-party legality (the conjunction of the
    # per-party tables) vs the direct fused computation, on every
    # attempted pair combination
    legal_tab = [[legal_bit(m, d) for d in range(64)]
                 for m in range(64)]
    combos = 0
    comp_ok = True
    comp_witness = None
    for ma in range(64):
        ta = legal_tab[ma]
        for mb in range(64):
            tb = legal_tab[mb]
            fused_mask = ma | (mb << 6)
            for da in range(1, 64):
                la = ta[da]
                for db in range(1, 64):
                    combos += 1
                    composed = la and tb[db]
                    direct = ((da | (db << 6)) & fused_mask) == 0
                    if composed != direct:
                        comp_ok = False
                        comp_witness = (ma, mb, da, db)
                        break
                if not comp_ok:
                    break
            if not comp_ok:
                break
        if not comp_ok:
            break
    report("(2a) docking legality: composed (per-party conjunction) "
           "equals the direct fused computation on every attempted "
           "pair combination", comp_ok and combos == 16257024,
           f"{combos} combinations, witness: {comp_witness}")

    # (2b) two-party legality counts: enumeration vs closed form
    total = 0
    counts_ok = True
    for ma in range(64):
        la = sum(1 for d in NONEMPTY if legal_bit(ma, d))
        if la != (1 << (6 - PC[ma])) - 1:
            counts_ok = False
        for mb in range(64):
            lb = sum(1 for d in NONEMPTY if legal_bit(mb, d))
            total += la * lb
    report("(2b) docking legality counts: composed enumeration equals "
           "the closed form on every mask pair; legal-transition "
           "total", counts_ok and total == 442225,
           f"total legal (state, draw-pair) combinations: {total}")
    rng = random.Random(SEED)
    dis = 0
    for _ in range(50000):
        ma, mb = rng.randrange(64), rng.randrange(64)
        da, db = rng.randrange(1, 64), rng.randrange(1, 64)
        bit = legal_bit(ma, da) and legal_bit(mb, db)
        st = legal_set(consumed_set((ma, mb)), 0, da) and \
            legal_set(consumed_set((ma, mb)), 1, db)
        dis += bit != st
    report("(2s) attempted pair classifications: set rule agrees "
           "with the bit rule on a fixed-seed sample", dis == 0,
           f"50,000 attempted pairs (seed {SEED}), disagreements: {dis}")

    # (3) every legal docking transition, both implementations,
    # the per-party invariant, and every alternative split
    n = 0
    trans_ok = True
    witness = None
    pp_ok = True
    pp_witness = None
    splits = 0
    split_ok = True
    split_witness = None
    for ma in range(64):
        for mb in range(64):
            base_set = consumed_set((ma, mb))
            booked0 = PC[ma] + PC[mb]
            for da in submasks((~ma) & 63):
                for db in submasks((~mb) & 63):
                    n += 1
                    nm = (ma | da, mb | db)
                    booked1 = booked0 + PC[da] + PC[db]
                    ns = base_set | ports_of(0, da) | ports_of(1, db)
                    if not (len(ns) == booked1 == PC[nm[0]] + PC[nm[1]]
                            and consumed_set(nm) == ns
                            and 12 - booked1 >= 0):
                        trans_ok = False
                        witness = (ma, mb, da, db)
                    w = invariant_holds_pp(
                        (ma, mb), (PC[ma], PC[mb]), (da, db),
                        (PC[ma] + PC[da], PC[mb] + PC[db]))
                    if w is not None:
                        pp_ok = False
                        pp_witness = (ma, mb, da, db, w)
                    total_drawn = PC[da] + PC[db]
                    for x in range(total_drawn + 1):
                        if x == PC[da]:
                            continue
                        w = invariant_holds_pp(
                            (ma, mb), (PC[ma], PC[mb]), (da, db),
                            (PC[ma] + x, PC[mb] + total_drawn - x))
                        if w is None:
                            split_ok = False
                            split_witness = (ma, mb, da, db, x)
                        else:
                            splits += 1
                if not (trans_ok and pp_ok and split_ok):
                    break
            if not (trans_ok and pp_ok and split_ok):
                break
        if not (trans_ok and pp_ok and split_ok):
            break
    report("(3) legal docking transitions: bit and set "
           "implementations produce the same consumed set; booked "
           "increment = ports drawn; boundary identity holds; the "
           "per-party invariant holds with the drawn split",
           trans_ok and pp_ok and n == 442225,
           f"{n} transitions, witness: {witness or pp_witness}")
    report("(3b) alternative splits rejected: on every legal "
           "docking transition, every split of the booked total "
           "across the two parties other than the drawn split is "
           "rejected by the per-party invariant",
           split_ok and n == 442225,
           f"{splits} alternative splits rejected, "
           f"witness: {split_witness}")

    # (4) convergence: conjunction law, count identity, sampled
    # transition invariants
    law_ok = True
    for ma in range(64):
        for mb in range(64):
            for mc in range(64):
                composed = legal_bit(ma, 1) and legal_bit(mb, 1) \
                    and legal_bit(mc, 1)
                union = consumed_set((ma, mb, mc))
                direct = all(legal_set(union, node, 1)
                             for node in range(3))
                if composed != direct:
                    law_ok = False
    report("(4a) convergence conjunction law at a fixed draw, "
           "every mask triple", law_ok, "262,144 mask triples")
    rng = random.Random(SEED + 3)
    lawd_ok = True
    lawd_witness = None
    lawd_n = 0
    while lawd_n < 50000:
        masks = tuple(rng.randrange(64) for _ in range(3))
        opens = [[i for i in range(6) if not (m >> i) & 1]
                 for m in masks]
        if any(not o for o in opens):
            continue
        draws = tuple(1 << rng.choice(o) for o in opens)
        composed = all(legal_bit(masks[i], draws[i]) for i in range(3))
        union = consumed_set(masks)
        direct = all(legal_set(union, i, draws[i]) for i in range(3))
        if composed != direct or not composed:
            lawd_ok = False
            lawd_witness = (masks, draws)
            break
        lawd_n += 1
    report("(4d) convergence conjunction law across draws, "
           "fixed-seed sample", lawd_ok,
           f"{lawd_n} sampled mask/draw triples (seed {SEED + 3}), "
           f"witness: {lawd_witness}")
    tot = 0
    for ma in range(64):
        for mb in range(64):
            for mc in range(64):
                tot += (6 - PC[ma]) * (6 - PC[mb]) * (6 - PC[mc])
    report("(4b) convergence legal-draw count identity over all "
           "mask triples", tot == 192 ** 3 == 7077888,
           f"Σ Π(6 − popcount) = {tot}")
    rng = random.Random(SEED + 1)
    sampled = 0
    samp_ok = True
    samp_witness = None
    while sampled < 50000:
        masks = tuple(rng.randrange(64) for _ in range(3))
        opens = [[i for i in range(6) if not (m >> i) & 1]
                 for m in masks]
        if any(not o for o in opens):
            continue
        draws = tuple(1 << rng.choice(o) for o in opens)
        booked0 = sum(PC[m] for m in masks)
        w = invariant_holds(masks, booked0, draws, 3)
        nm = tuple(masks[i] | draws[i] for i in range(3))
        if w is not None or consumed_set(nm) != \
                consumed_set(masks) | set().union(
                    *(ports_of(i, draws[i]) for i in range(3))):
            samp_ok = False
            samp_witness = (masks, draws, w)
            break
        sampled += 1
    report("(4c) legal convergence transitions: bookkeeping "
           "invariant on a fixed-seed sample",
           samp_ok and sampled == 50000,
           f"{sampled} transitions (seed {SEED + 1}), "
           f"witness: {samp_witness}")
    # (4e) the per-party split check runs its own sample — the
    # same fixed-seed sequence, independently drawn, with its
    # own counter, so neither check's verdict rides on the
    # other's completion
    rng = random.Random(SEED + 1)
    pp_sampled = 0
    pp_splits = 0
    conv_pp_ok = True
    conv_pp_witness = None
    while pp_sampled < 50000:
        masks = tuple(rng.randrange(64) for _ in range(3))
        opens = [[i for i in range(6) if not (m >> i) & 1]
                 for m in masks]
        if any(not o for o in opens):
            continue
        draws = tuple(1 << rng.choice(o) for o in opens)
        before_pp = tuple(PC[m] for m in masks)
        w = invariant_holds_pp(masks, before_pp, draws,
                               tuple(b + 1 for b in before_pp))
        if w is not None:
            conv_pp_ok = False
            conv_pp_witness = (masks, draws, w)
            break
        for a in range(4):
            for b in range(4 - a):
                c = 3 - a - b
                if (a, b, c) == (1, 1, 1):
                    continue
                w = invariant_holds_pp(
                    masks, before_pp, draws,
                    (before_pp[0] + a, before_pp[1] + b,
                     before_pp[2] + c))
                if w is None:
                    conv_pp_ok = False
                    conv_pp_witness = (masks, draws, (a, b, c))
                    break
                pp_splits += 1
            if not conv_pp_ok:
                break
        if not conv_pp_ok:
            break
        pp_sampled += 1
    report("(4e) convergence per-party splits: the drawn split "
           "(1, 1, 1) is accepted and every alternative split of "
           "the same total is rejected, on its own fixed-seed "
           "sample (the (4c) sequence, independently drawn)",
           conv_pp_ok and pp_sampled == 50000,
           f"{pp_splits} alternative splits rejected over "
           f"{pp_sampled} sampled transitions (seed {SEED + 1}), "
           f"witness: {conv_pp_witness}")

    # (5) reachability — the enriched state: mask pair with its
    # per-party booked vector
    seen = {(0, 0): (0, 0)}   # state -> per-party booked vector
    queue = deque([(0, 0)])
    reach_ok = True
    while queue:
        ma, mb = queue.popleft()
        ba, bb = seen[(ma, mb)]
        if (ba, bb) != (PC[ma], PC[mb]):
            reach_ok = False   # booked vector != the state's own
                               # per-party consumed vector
        for da in submasks((~ma) & 63):
            for db in submasks((~mb) & 63):
                nm = (ma | da, mb | db)
                nb = (ba + PC[da], bb + PC[db])
                if nm in seen:
                    if seen[nm] != nb:
                        reach_ok = False   # two paths book
                                           # differently
                else:
                    seen[nm] = nb
                    queue.append(nm)
    expected = {(0, 0)} | {(a, b) for a in range(1, 64)
                           for b in range(1, 64)}
    enriched = {(a, b, v[0], v[1]) for (a, b), v in seen.items()}
    expected_enriched = {(0, 0, 0, 0)} | {
        (a, b, PC[a], PC[b]) for a in range(1, 64)
        for b in range(1, 64)}
    report("(5a) N = 2 reachability: reached state set is exactly "
           "the predicted set; the per-party booked vector at "
           "every reached state is the state's own per-party "
           "consumed vector, on every path",
           reach_ok and set(seen) == expected
           and enriched == expected_enriched,
           f"{len(seen)} states reached, {len(expected)} predicted")
    pairs1 = [(i, j) for i in range(1) for j in range(1) if i != j]
    triples1 = [(i, j, k) for i in range(1) for j in range(1)
                for k in range(1) if len({i, j, k}) == 3]
    report("(5b) N = 1: no application of either shape exists",
           pairs1 == [] and triples1 == [],
           "the degenerate case, asserted not skipped")
    rng = random.Random(SEED + 2)
    walks_ok = True
    steps = 0
    for _ in range(2000):
        masks = (0, 0, 0)
        consumed = set()
        booked_pp = [0, 0, 0]
        for _ in range(8):
            if rng.random() < 0.5:
                o, c = rng.sample(range(3), 2)
                draws = [0, 0, 0]
                for node in (o, c):
                    opens = [d for d in NONEMPTY
                             if legal_bit(masks[node], d)]
                    if not opens:
                        draws = None
                        break
                    draws[node] = rng.choice(opens)
                if draws is None:
                    break
            else:
                draws = []
                for node in range(3):
                    opens = [d for d in SINGLETONS
                             if legal_bit(masks[node], d)]
                    if not opens:
                        draws = None
                        break
                    draws.append(rng.choice(opens))
                if draws is None:
                    break
            new_masks = tuple(masks[i] | draws[i] for i in range(3))
            new_consumed = consumed | set().union(
                *(ports_of(i, draws[i]) for i in range(3)))
            steps += 1
            for i in range(3):
                booked_pp[i] += PC[draws[i]]
            if consumed_set(new_masks) != new_consumed or \
                    len(new_consumed) != sum(PC[m] for m in new_masks) \
                    or any(booked_pp[i] != PC[new_masks[i]]
                           for i in range(3)):
                walks_ok = False
                break
            masks, consumed = new_masks, new_consumed
        if not walks_ok:
            break
    report("(5c) N = 3 sampled paths under both shapes: bit and "
           "set computations agree, and the per-party booked "
           "vector tracks each party's own consumed count at "
           "every step", walks_ok,
           f"2,000 walks, {steps} applications (seed {SEED + 2})")

    # mutants
    print("  PLANTED MUTANTS")
    _, bad = per_party_agreement(
        NONEMPTY,
        oracle_a=lambda m, d: (d & m) == 0 or PC[d] == 1)
    w1 = None
    if bad is not None:
        w1 = invariant_holds((bad[0],), PC[bad[0]], (bad[1],), 1)
    report("M1 classifier admitting a one-port draw on a consumed "
           "port", bad is not None and w1 is not None,
           f"REJECTED — oracle disagreement at (mask, draw) = {bad}; "
           f"the application it licenses double-books: {w1}")
    w = invariant_holds((0, 0, 0), 0, (0b000011, 0b000001, 0b000001), 3)
    report("M2 convergence drawing two ports at one party while "
           "booking one per party", w is not None,
           f"REJECTED — {w}")
    w = invariant_holds((0, 0), 0, (0b000001, 0b000001), 3)
    report("M3 transition booking |drawn| + 1", w is not None,
           f"REJECTED — {w}")
    w_scalar = invariant_holds((0, 0), 0, (0b000011, 0b000001), 3)
    w_pp = invariant_holds_pp((0, 0), (0, 0), (0b000011, 0b000001),
                              (1, 2))
    report("M4 per-party misbooking — the KD-1 Z8 shape-(i) "
           "witness: draws (0b000011, 0b000001) booked (1, 2)",
           w_scalar is None and w_pp is not None,
           f"the global invariant accepts it (total preserved); "
           f"the per-party invariant REJECTS it — {w_pp}")
    w_pp = invariant_holds_pp((0, 0, 0), (0, 0, 0),
                              (0b000001, 0b000001, 0b000001),
                              (2, 1, 0))
    report("M5 convergence booking its drawn ports as (2, 1, 0) "
           "across the parties", w_pp is not None,
           f"REJECTED — {w_pp}")
    w = invariant_holds((0b000001,), 1, (0b000001,), 1)
    print(f"  [DIAGNOSTIC] premise-free classifier, second application "
          f"to one port: invariant witness = {w} (printed as a "
          f"diagnostic — the formalization's rule is load-bearing "
          f"in the model; not counted among the rejections)")

    print("=" * 70)
    if FAILURES:
        print(f"A.13 VERDICT: FAIL — {len(FAILURES)} check(s) failed: "
              f"{FAILURES}")
        return 1
    print("A.13 VERDICT: PASS — the §0.4(b) formalization is "
          "consistent: two independent oracles agree over the full "
          "attempted per-party spaces (4,032 + 384 classifications), "
          "composed two-party legality agrees with the direct fused "
          "computation on all 16,257,024 attempted combinations, "
          "the legal-transition total is 442,225 by enumeration and "
          "closed form, the bookkeeping identity holds on every "
          "legal docking transition in total and per party — every "
          "alternative split of every transition's booked total is "
          "rejected — and on the sampled convergence transitions, "
          "N = 2 reachability is exactly the predicted "
          "3,970 states with the accumulated per-party booked "
          "vector agreeing with the state's own consumed vector "
          "at every reached state, and the five planted mutants "
          "are rejected with witnesses. The premise itself is not "
          "proved by "
          "this script, and its coverage is as stated in the "
          "docstring.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
