#!/usr/bin/env python3
"""A.8 — Molecule reduction: two-level records collapse to the flat
record (Paper 12 §11.2).

Machine companion to Paper 12 §11.2 (the molecule reduction, new in
the v2 final build). The reduction under test: a molecule declared as
a GROUPED record — atoms, each with its own constituent nodes and
internal junctions, joined by inter-atom junctions — has exactly the
census key of its FLATTENING, the single record whose nodes are the
atoms' nodes, whose junctions are the internal and inter-atom
junctions together, and whose boundary count, Σs² and Σu are the
totals over the whole. The script verifies the reduction's finite
arithmetic from declared records, by computation:

  (R1)  VALIDATION — every case (the §11.2 worked example and every
        generated grouped molecule) is checked against the
        definition's preconditions before any identity is credited:
        the atoms' node sets are pairwise disjoint; each atom
        declares at least two nodes and at least one internal
        junction (an atom is a Paper 11 bonded aggregate); each
        atom's internal incidence graph is connected over its nodes;
        every internal junction's touches are distinct (node, port)
        incidences of its host atom, as many as its junction arity; every
        inter-atom junction's touches are (atom, node, port)
        incidences, as many as its junction arity, possibly several at one
        atom (on one node or on several), each node belonging to the
        atom it is booked under, the junction touching at least two
        distinct atoms with at least one port at each atom it
        touches, and no port consumed twice anywhere in the molecule
        (internal and inter-atom incidences together form one
        partition); per-node consumed ports (incidences across
        internal and inter-atom junctions together) never exceed 6;
        each atom's inter-atom consumed count never exceeds its own
        boundary count B(atom); and the molecule graph (atoms as
        vertices, inter-atom junctions as edges) is connected.
  (R2)  PER-ATOM BOUNDARIES RECOMPUTED — each atom's B is computed
        from its own record by B = 6N − Σ_j k_j; a stored B carried
        on a record is compared against the recomputation and never
        trusted as an input to any total.
  (R3)  THE B IDENTITY, TWO INDEPENDENT ROUTES — for every case,
        B(mol) is computed by the flat route, 6·N(mol) − Σ_all k_j
        over the flattened record, and by the two-level route,
        Σ_atoms B(atom) − Σ_inter k_j, and the two must agree.
  (R4)  GROUPING INDEPENDENCE — a merge operation joins the atoms an
        inter-atom junction touches into one atom (node union;
        internal junctions = both atoms' internals plus that
        junction re-read as internal, its touches re-read as bare
        node ids; s2 and u summed; the remaining inter-atom junctions
        re-booked under the merged atom's name — and any remaining
        junction whose touches all land inside one grouping is
        likewise re-read as internal to that grouping). For every
        case the
        census key — (N(mol), the sorted tuple of ALL junction
        junction arities, internal and inter-atom together, B(mol), Σs², Σu) —
        is recomputed after every merge along a chain that merges
        until one atom remains, and must be identical at every
        grouping, including the fully merged (flat, single-atom)
        grouping.

TRANSCRIPTION SEAM + PRINTED-ORACLE LEG (Step 4): if the file
Paper_12_v4.md exists beside this script's parent directory when the
script runs, its §11.2 span (from the line beginning "### 11.2" to
the line beginning "### 11.3") is parsed and compared against this
script's embedded worked-example records and their recomputation:
  - the atom table (header row whose first cell is "atom"; each data
    row gives, in order: name, N, internal junctions (junction arities) in
    "(2)" / "(2, 2)" / "(3)" form, Σ_j k_j over the internal
    junctions, the B cell — its last integer is B — Σs², Σu), with
    the paper's atom display names α, β, γ mapped to the embedded
    records alpha, beta, gamma;
  - the inter-atom table (header row whose first cell is
    "inter-atom junction"; each row gives: name, atoms joined in
    "α, β" form, junction arity);
  - the printed summary lines, parsed by their exact labels — the
    N(mol) sum line, the Σs²/Σu line, the flat-route and two-level
    B(mol) lines, the census-key line, and the Regrouped line's
    three bold numbers — each printed number compared against the
    value computed from the embedded records (the Regrouped numbers
    against a computed regrouping that merges alpha and beta);
  - four secondary echo prints: the feasibility sentence's per-atom
    consumed counts (α, β, γ); the feasibility totals sentence (the
    Σ_int / Σ_inter / Σ_all summands and totals); the regrouping
    prose's merged-atom line (N, internal junction arities, Σ_j k_j, the B
    arithmetic 6·N − Σ_j k_j, Σs², Σu); and the junction arity multiset
    explanation sentence (the counts of junction arity 2 and junction arity 3
    junctions and the total junction count, printed in word form
    and read through a small word→number map).
  A printed form that is ABSENT fails the leg (a missing oracle), as
  does any disagreement, with printed and computed values as witness
  — A.7's oracle standard. If the paper file is absent, the leg is
  SKIPPED and a clear note is printed (a skip, not a pass).

NO DERIVED VALUE IS HARDCODED: the embedded records below declare
nodes, junctions, s2, u — and a stored B per atom, carried only so
(R2) can check it against its recomputation. Every total, boundary
count and census key this script prints or checks is computed from
those records. The worked example's expected totals appear nowhere
as literals in a check; they are printed from the computation, and
the printed-oracle leg compares the PAPER's printed numbers against
that computation.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: Paper 12 §11.2's molecule reduction over
      arbitrary finite grouped molecules satisfying the definition's
      preconditions.
  (2) Verified domain: the single declared §11.2 worked example
      (three atoms, two inter-atom junctions), its merging chains,
      and 300 seeded-RNG generated grouped molecules (1–5 atoms per
      molecule, 2–4 nodes and at least one internal junction per
      atom, a random junction arity 2 spanning structure plus 0–2 extra
      internal junctions of junction arity 2–3 per atom, a random junction arity 2
      spanning tree of inter-atom junctions, plus, for molecules
      of at least three atoms, optionally one inter-atom junction of junction arity 3
      junction over three distinct atoms, and, in 35% of molecules
      with at least two atoms, one additional multi-port inter-atom
      junction of junction arity 3–4 touching one atom at least twice —
      attempted with bounded retries and kept only when every
      feasibility counter admits it), each carried through its
      full merging chain.
  (3) Map: a grouped record maps to its flattening by node union
      over the atoms, junction union over internal and inter-atom
      junctions (an inter-atom junction's touches re-read as bare
      node ids), and summation of s2 and u; the census key is read
      off the flattened record. The merge operation is the same map
      applied one inter-atom junction at a time.
  (4) Preserved: exactly the properties the reduction's statement
      depends on — the boundary count B under both routes (R3), the
      node total, the full junction arity multiset, Σs², Σu, and hence the
      whole census key, at every grouping (R4) — recomputed from
      the records at every step, never carried between groupings.
  Tick coherence: atom records are single-tick records (§3.1),
      and the identities are checked at one common tick by
      construction of the record model — a grouped record carries
      no per-atom tick index, so no identity in this script mixes
      records taken at two ticks.
  (5) Outside the machine check: that the flattening satisfies
      Paper 11's Bonded Aggregate definition. That is a prose proof
      at §11.2 citing the definition; this script checks only its
      arithmetic preconditions — disjointness, finiteness,
      connectedness (of each atom internally, and of the molecule
      graph), and port feasibility (the per-node cap and the
      per-atom inter-atom bound). Also outside: any claim about
      groupings other than merging chains along inter-atom
      junctions, and Paper 11 §4.3 itself (cited, not re-proved).

INPUT_PROVENANCE:
  - The molecule definition implemented in (R1)–(R4) — grouped
    records of atoms and inter-atom junctions, the flattening, the
    census key, and the merge operation:
    class=paper-defined (Paper 12 §11.2).
  - The worked example's three atoms (alpha: nodes a1, a2, one
    internal junction of junction arity 2, s2 and u as embedded; beta: nodes
    b1, b2, b3, one internal junction of junction arity 3; gamma: nodes g1, g2,
    two internal junctions of junction arity 2), their stored B values, and the
    two inter-atom junctions e1, e2 with their touches:
    class=paper-defined (Paper 12 §11.2 worked example; the only
    hardcoded molecule data in this script; node ids ASCII here,
    atom display names α, β, γ in the paper).
  - B = 6N − Σ_j k_j for an atom and for the flattened record:
    class=cited-paper (Paper 11 §4.1, at source; restated for
    bodies generally in Paper 12 §3).
  - Port-Partition Exactness — the disjointness of the port sets
    the two B routes partition, which is what makes (R3) an
    identity rather than a coincidence of the fixtures:
    class=cited-paper (Paper 11 §4.3).
  - The per-node port cap of 6 and the atoms' six ports per node
    behind B's 6N term: class=cited-paper (Paper 11 §4.1).
  - Generated-molecule fixtures (atom, node and junction counts,
    spanning structures, extra-junction ranges, the multi-port
    extra junction's 35% attempt rate, s2/u ranges, the
    B(atom) >= 2 regeneration rule, the bounded-resample rule):
    class=control (test fixtures built to the §11.2 definition's
    preconditions; no generated value is a claim of the paper).
  - RNG seed 20261025: class=arbitrary-representative (any seed
    serves; the identities are universal over finite grouped
    molecules satisfying the preconditions).
  - §11.2's atom table, inter-atom table and printed summary lines
    in Paper_12_v4.md, when present:
    class=paper-defined (the transcription and oracle under test in
    Step 4; parsed at run time, never used in any computation).

V4 NOTE (2026-10-26, disclosed): default paper target is now the v4 assembly; no check logic changed.
"""
import copy
import random
import re
import sys
from collections import Counter
from pathlib import Path

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Records (DECLARED — see INPUT_PROVENANCE). An atom is a dict
# {name, nodes, internal, s2, u, b} where "internal" is a list of
# junction dicts {junction_arity, touches} with touches a tuple of
# (node_id, port) incidences, and b is the STORED boundary count
# (checked, never trusted). An inter-atom junction is
# {name, junction_arity, touches} with touches a tuple of
# (atom_name, node_id, port) incidences. Port labels are
# bookkeeping coordinates local to a node (ports 1–6); a junction
# may touch one node at several distinct ports, and one atom at
# several ports, per §11.2 clause (ii) as generalized.
# ---------------------------------------------------------------------------

def worked_example():
    """A fresh copy of the §11.2 worked example, on every call."""
    return {
        "atoms": [
            {"name": "alpha", "nodes": ("a1", "a2"),
             "internal": [{"junction_arity": 2,
                           "touches": (("a1", 1), ("a2", 1))}],
             "s2": 4, "u": 2, "b": 10},
            {"name": "beta", "nodes": ("b1", "b2", "b3"),
             "internal": [{"junction_arity": 3,
                           "touches": (("b1", 1), ("b2", 1),
                                       ("b3", 1))}],
             "s2": 9, "u": 1, "b": 15},
            {"name": "gamma", "nodes": ("g1", "g2"),
             "internal": [{"junction_arity": 2,
                           "touches": (("g1", 1), ("g2", 1))},
                          {"junction_arity": 2,
                           "touches": (("g1", 2), ("g2", 2))}],
             "s2": 6, "u": 3, "b": 8},
        ],
        "inter": [
            {"name": "e1", "junction_arity": 2,
             "touches": (("alpha", "a1", 2), ("beta", "b1", 2))},
            {"name": "e2", "junction_arity": 2,
             "touches": (("beta", "b2", 2), ("gamma", "g1", 3))},
        ],
    }


DISPLAY_TO_RECORD = {"α": "alpha", "β": "beta", "γ": "gamma"}
GENERATED_CASES = 300
RNG_SEED = 20261025
MULTI_PORT_FRACTION = 0.35


# ---------------------------------------------------------------------------
# The reduction's computations (nothing here reads a stored total)
# ---------------------------------------------------------------------------

def boundary_of(atom):
    """B(atom) = 6·N(atom) − Σ_j k_j over its INTERNAL junctions
    (Paper 11 §4.1). Recomputed from the record on every call."""
    return 6 * len(atom["nodes"]) - sum(j["junction_arity"] for j in atom["internal"])


def per_atom_inter_consumed(mol):
    """Inter-atom consumed count per atom: the number of inter-atom
    junction touch entries booked under that atom."""
    counts = {a["name"]: 0 for a in mol["atoms"]}
    for j in mol["inter"]:
        for atom_name, _node, _port in j["touches"]:
            counts[atom_name] = counts.get(atom_name, 0) + 1
    return counts


def per_node_consumed(mol):
    """Consumed ports per node id: incidences across the internal
    junctions of its atom and the inter-atom junctions together."""
    counts = Counter()
    for a in mol["atoms"]:
        for j in a["internal"]:
            for node, _port in j["touches"]:
                counts[node] += 1
    for j in mol["inter"]:
        for _atom_name, node, _port in j["touches"]:
            counts[node] += 1
    return counts


def compute(mol):
    """Every total of the reduction, computed from the records:
    both B routes independently, and the census key off the flat
    route and the full junction arity multiset."""
    atoms = mol["atoms"]
    per_atom_b = {a["name"]: boundary_of(a) for a in atoms}
    n_mol = sum(len(a["nodes"]) for a in atoms)
    sum_int = sum(j["junction_arity"] for a in atoms for j in a["internal"])
    sum_inter = sum(j["junction_arity"] for j in mol["inter"])
    sum_all = sum_int + sum_inter
    b_flat = 6 * n_mol - sum_all
    b_two = sum(per_atom_b.values()) - sum_inter
    sum_s2 = sum(a["s2"] for a in atoms)
    sum_u = sum(a["u"] for a in atoms)
    all_junction_arities = tuple(sorted(
        [j["junction_arity"] for a in atoms for j in a["internal"]]
        + [j["junction_arity"] for j in mol["inter"]]))
    return {
        "per_atom_b": per_atom_b,
        "per_atom_inter": per_atom_inter_consumed(mol),
        "per_node": per_node_consumed(mol),
        "n": n_mol, "sum_int": sum_int, "sum_inter": sum_inter,
        "sum_all": sum_all, "b_flat": b_flat, "b_two": b_two,
        "sum_s2": sum_s2, "sum_u": sum_u,
        "key": (n_mol, all_junction_arities, b_flat, sum_s2, sum_u),
    }


def _connected(nodes, junctions):
    """BFS over nodes via junctions (a junction joins all its
    touches). A one-node graph is connected."""
    if len(nodes) <= 1:
        return True
    adjacency = {node: set() for node in nodes}
    for j in junctions:
        touched = [touch[0] if isinstance(touch, tuple) else touch
                   for touch in j["touches"]]
        for x in touched:
            for y in touched:
                if x != y and x in adjacency and y in adjacency:
                    adjacency[x].add(y)
    seen, stack = set(), [nodes[0]]
    while stack:
        cur = stack.pop()
        if cur in seen:
            continue
        seen.add(cur)
        stack.extend(adjacency.get(cur, ()))
    return seen == set(nodes)


def find_duplicate_nodes(mol):
    """node id -> list of atom names carrying it, for ids carried
    by more than one atom (the partition witness)."""
    owner = {}
    dups = {}
    for a in mol["atoms"]:
        for node in a["nodes"]:
            if node in owner and owner[node] != a["name"]:
                dups.setdefault(node, [owner[node]]).append(a["name"])
            else:
                owner.setdefault(node, a["name"])
    return dups


def validate_molecule(mol):
    """(R1)+(R2): the definition's preconditions, checked on a case.
    Returns a list of violation strings (empty iff the case is a
    grouped molecule as §11.2 defines it)."""
    errors = []
    atoms = mol.get("atoms", [])
    inter = mol.get("inter", [])
    if not atoms:
        errors.append("the molecule declares no atoms")
        return errors
    names = [a["name"] for a in atoms]
    if len(names) != len(set(names)):
        errors.append(f"atom names are not distinct: {names}")
    atom_by_name = {a["name"]: a for a in atoms}

    # Partition: the atoms' node sets are pairwise disjoint.
    for node, owners in find_duplicate_nodes(mol).items():
        errors.append(
            f"node {node} appears in two atoms: {owners[0]} and "
            f"{owners[1]} (partition violation)")

    for a in atoms:
        nodes = a["nodes"]
        if not nodes:
            errors.append(f"atom {a['name']} declares no nodes")
        if len(nodes) != len(set(nodes)):
            errors.append(f"atom {a['name']} repeats a node id: {nodes}")
        for field in ("s2", "u"):
            if not isinstance(a[field], int) or a[field] < 0:
                errors.append(
                    f"atom {a['name']}: {field} = {a[field]!r} is not "
                    f"a nonnegative integer")
        if len(nodes) < 2:
            errors.append(
                f"atom {a['name']} declares {len(nodes)} node(s); an "
                f"atom is a Paper 11 bonded aggregate — at least two "
                f"nodes")
        if not a["internal"]:
            errors.append(
                f"atom {a['name']} declares no internal junction; "
                f"an atom is a Paper 11 bonded aggregate — at least "
                f"one internal junction")
        for j in a["internal"]:
            if j["junction_arity"] != len(j["touches"]):
                errors.append(
                    f"atom {a['name']}: internal junction arity "
                    f"{j['junction_arity']} != len(touches) = {len(j['touches'])}")
            pairs_in = [x for x in j["touches"]
                        if isinstance(x, tuple) and len(x) == 2]
            if len(pairs_in) != len(j["touches"]):
                errors.append(
                    f"atom {a['name']}: an internal junction touch "
                    f"is not a (node, port) incidence: {j['touches']}")
            if len(pairs_in) != len(set(pairs_in)):
                errors.append(
                    f"atom {a['name']}: internal junction touches "
                    f"are not distinct port incidences: "
                    f"{j['touches']}")
            stray = [x for x in pairs_in if x[0] not in nodes]
            if stray:
                errors.append(
                    f"atom {a['name']}: internal junction touches "
                    f"nodes not belonging to the atom: {stray}")
            bad_ports = [x for x in pairs_in
                         if not isinstance(x[1], int)
                         or not 1 <= x[1] <= 6]
            if bad_ports:
                errors.append(
                    f"atom {a['name']}: internal junction port "
                    f"labels outside 1..6: {bad_ports}")
        if nodes and not _connected(list(nodes), a["internal"]):
            errors.append(
                f"atom {a['name']}: internal incidence graph is not "
                f"connected over nodes {nodes}")
        recomputed = boundary_of(a)
        if "b" in a and a["b"] != recomputed:
            errors.append(
                f"atom {a['name']}: stored B = {a['b']} != recomputed "
                f"B = 6*{len(nodes)} - "
                f"{sum(j['junction_arity'] for j in a['internal'])} = {recomputed}")

    for j in inter:
        label = j.get("name", "?")
        if j["junction_arity"] != len(j["touches"]):
            errors.append(
                f"inter-atom junction {label}: junction arity {j['junction_arity']} != "
                f"len(touches) = {len(j['touches'])}")
        if len(j["touches"]) != len(set(j["touches"])):
            errors.append(
                f"inter-atom junction {label}: touches are not "
                f"distinct: {j['touches']}")
        triples = [x for x in j["touches"]
                   if isinstance(x, tuple) and len(x) == 3]
        if len(triples) != len(j["touches"]):
            errors.append(
                f"inter-atom junction {label}: a touch is not an "
                f"(atom, node, port) incidence: {j['touches']}")
        touched_atoms = [atom_name for atom_name, _n, _p in triples]
        if len(set(touched_atoms)) < 2:
            errors.append(
                f"inter-atom junction {label}: touches fewer than "
                f"two distinct atoms: {touched_atoms}")
        for atom_name, node, port in triples:
            if atom_name not in atom_by_name:
                errors.append(
                    f"inter-atom junction {label}: touches unknown "
                    f"atom {atom_name}")
            elif node not in atom_by_name[atom_name]["nodes"]:
                errors.append(
                    f"inter-atom junction {label}: node {node} does "
                    f"not belong to atom {atom_name}")
            if not isinstance(port, int) or not 1 <= port <= 6:
                errors.append(
                    f"inter-atom junction {label}: port label "
                    f"{port!r} outside 1..6")

    # Port partition: every (atom, node, port) incidence in the
    # molecule — internal and inter-atom together — is distinct;
    # no port is consumed twice anywhere.
    used_ports = {}
    for a in atoms:
        for j in a["internal"]:
            for x in j["touches"]:
                if isinstance(x, tuple) and len(x) == 2:
                    key = (a["name"], x[0], x[1])
                    if key in used_ports:
                        errors.append(
                            f"port {key} consumed twice (partition "
                            f"violation): by {used_ports[key]} and "
                            f"by an internal junction of {a['name']}")
                    used_ports[key] = f"an internal junction of "                         f"{a['name']}"
    for j in inter:
        label = j.get("name", "?")
        for x in j["touches"]:
            if isinstance(x, tuple) and len(x) == 3:
                key = (x[0], x[1], x[2])
                if key in used_ports:
                    errors.append(
                        f"port {key} consumed twice (partition "
                        f"violation): by {used_ports[key]} and by "
                        f"inter-atom junction {label}")
                used_ports[key] = f"inter-atom junction {label}"

    per_node = per_node_consumed(mol)
    for node, count in sorted(per_node.items()):
        if count > 6:
            errors.append(
                f"node {node}: consumed ports {count} exceed the "
                f"per-node cap of 6")
    per_atom_inter = per_atom_inter_consumed(mol)
    for a in atoms:
        if per_atom_inter.get(a["name"], 0) > boundary_of(a):
            errors.append(
                f"atom {a['name']}: inter-atom consumed count "
                f"{per_atom_inter.get(a['name'], 0)} exceeds "
                f"B(atom) = {boundary_of(a)}")

    # The molecule graph: atoms as vertices, inter-atom junctions
    # as edges (a junction joins all the atoms it touches).
    if len(atoms) > 1:
        adjacency = {a["name"]: set() for a in atoms}
        for j in inter:
            touched = [atom_name for atom_name, _n, _p
                       in j["touches"]]
            for x in touched:
                for y in touched:
                    if x != y and x in adjacency and y in adjacency:
                        adjacency[x].add(y)
        seen, stack = set(), [atoms[0]["name"]]
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            stack.extend(adjacency.get(cur, ()))
        if seen != set(names):
            errors.append(
                f"the molecule graph is not connected: reached "
                f"{sorted(seen)} of atoms {sorted(names)}")
    return errors


# ---------------------------------------------------------------------------
# The merge operation and grouping chains (R4)
# ---------------------------------------------------------------------------

def merge_molecule(mol, inter_index=0):
    """Merge the atoms touched by mol["inter"][inter_index] into one
    atom: node union; internal = the merged atoms' internals plus
    that junction re-read as internal (touches = its node ids);
    s2/u summed; the remaining inter-atom junctions re-booked under
    the merged name. The merged atom's stored B is the two-level
    value Σ B(atom) − k_j over the merged atoms — which (R2) then
    re-checks against its recomputation from the merged record."""
    mol = copy.deepcopy(mol)
    junction = mol["inter"][inter_index]
    touched_order = []
    for atom_name, _node, _port in junction["touches"]:
        if atom_name not in touched_order:
            touched_order.append(atom_name)
    touched = set(touched_order)
    merged_name = "+".join(touched_order)
    members = [a for a in mol["atoms"] if a["name"] in touched]
    merged = {
        "name": merged_name,
        "nodes": tuple(node for a in members for node in a["nodes"]),
        "internal": [j for a in members for j in a["internal"]]
                    + [{"junction_arity": junction["junction_arity"],
                        "touches": tuple((node, port) for _a, node,
                                          port
                                          in junction["touches"])}],
        "s2": sum(a["s2"] for a in members),
        "u": sum(a["u"] for a in members),
        "b": sum(boundary_of(a) for a in members) - junction["junction_arity"],
    }
    new_atoms, placed = [], False
    for a in mol["atoms"]:
        if a["name"] in touched:
            if not placed:
                new_atoms.append(merged)
                placed = True
        else:
            new_atoms.append(a)
    atom_by_name = {a["name"]: a for a in new_atoms}
    new_inter = []
    for idx, j in enumerate(mol["inter"]):
        if idx == inter_index:
            continue
        remapped = tuple(
            (merged_name if atom_name in touched else atom_name,
             node, port)
            for atom_name, node, port in j["touches"])
        if len({atom_name for atom_name, _n, _p in remapped}) == 1:
            # Every atom this junction touched now stands inside one
            # grouping, so the junction is internal to that grouping:
            # re-read it as an internal junction of its atom (its
            # touches as bare node ids), and drop the host atom's
            # stored B by its junction arity, exactly as its recomputation
            # from the enlarged internal list will.
            host = atom_by_name[remapped[0][0]]
            host["internal"] = host["internal"] + [{
                "junction_arity": j["junction_arity"],
                "touches": tuple((node, port) for _a, node, port
                                 in remapped)}]
            host["b"] -= j["junction_arity"]
            continue
        new_inter.append({"name": j["name"], "junction_arity": j["junction_arity"],
                          "touches": remapped})
    return {"atoms": new_atoms, "inter": new_inter}


def grouping_chain(mol, inter_order=None):
    """The grouping chain of a molecule: the molecule itself, then
    the grouping after each merge along inter-atom junctions (in
    the given order of junction names, else declaration order),
    until one atom remains. Returns the list of groupings."""
    chain = [mol]
    cur = mol
    order = list(inter_order) if inter_order else None
    while len(cur["atoms"]) > 1:
        if not cur["inter"]:
            break
        idx = 0
        if order:
            want = order.pop(0)
            idx = next(i for i, j in enumerate(cur["inter"])
                       if j["name"] == want)
        cur = merge_molecule(cur, idx)
        chain.append(cur)
    return chain


# ---------------------------------------------------------------------------
# Generated grouped molecules (control fixtures; see INPUT_PROVENANCE)
# ---------------------------------------------------------------------------

def _generate_atom(rng, idx):
    """One generated atom: 2–4 nodes, at least one internal junction
    (a random junction arity 2 spanning structure over its nodes), plus 0–2
    extra internal junctions of junction arity 2–3 over distinct nodes.
    Junction touches are (node, port) incidences, ports assigned
    per node in declaration order (1, 2, ...). Regenerated while
    B(atom) < 2."""
    for _attempt in range(100):
        name = f"A{idx}"
        n_nodes = rng.randint(2, 4)
        nodes = tuple(f"{name.lower()}n{k + 1}" for k in range(n_nodes))
        port_counter = Counter()

        def junction(node_tuple):
            touches = []
            for node in node_tuple:
                port_counter[node] += 1
                touches.append((node, port_counter[node]))
            return {"junction_arity": len(node_tuple),
                    "touches": tuple(touches)}

        internal = []
        for pos in range(1, n_nodes):
            other = rng.randrange(pos)
            internal.append(junction((nodes[pos], nodes[other])))
        feasible = [k for k in (2, 3) if k <= n_nodes]
        for _extra in range(rng.randint(0, 2)):
            if not feasible:
                break
            junction_arity = rng.choice(feasible)
            internal.append(junction(tuple(rng.sample(nodes, junction_arity))))
        atom = {"name": name, "nodes": nodes, "internal": internal,
                "s2": rng.randint(0, 9), "u": rng.randint(0, 5)}
        atom["b"] = boundary_of(atom)
        if atom["b"] >= 2:
            return atom
    return None


def _generate_inter(rng, atoms):
    """Inter-atom junctions for generated atoms: a random junction arity 2
    spanning tree over the atoms, plus (for >= 3 atoms) optionally
    one junction of junction arity 3 over three distinct atoms, plus — in
    MULTI_PORT_FRACTION of molecules with at least two atoms — one
    additional multi-port junction of junction arity 3–4 touching one atom
    at least twice (bounded retries; kept only when every counter
    admits it). Touches are (atom, node, port) incidences: the port
    at a node is the next free port in declaration order, the
    node's internal incidences occupying its first ports. Every
    pick respects the per-atom inter-consumed <= B(atom) bound and
    the per-node cap of 6. Bounded resampling; None if the retry
    bound is exceeded."""
    n_atoms = len(atoms)
    if n_atoms == 1:
        return []
    base_node = {}
    for a in atoms:
        counts = Counter()
        for j in a["internal"]:
            for node, _port in j["touches"]:
                counts[node] += 1
        base_node[a["name"]] = counts

    for _attempt in range(100):
        inter = []
        per_atom = Counter()
        per_node = {name: Counter(c) for name, c in base_node.items()}

        def pick(atom, pa, pn):
            if pa[atom["name"]] + 1 > boundary_of(atom):
                return None
            candidates = [node for node in atom["nodes"]
                          if pn[atom["name"]][node] + 1 <= 6]
            if not candidates:
                return None
            node = rng.choice(candidates)
            pa[atom["name"]] += 1
            pn[atom["name"]][node] += 1
            return (atom["name"], node, pn[atom["name"]][node])

        def attempt(atom_seq):
            """Picks for one junction on cloned counters; returns
            (touches, per_atom, per_node) on success, else None —
            a failed attempt commits nothing."""
            pa = Counter(per_atom)
            pn = {k: Counter(v) for k, v in per_node.items()}
            touches = []
            for atom in atom_seq:
                touch = pick(atom, pa, pn)
                if touch is None:
                    return None
                touches.append(touch)
            return touches, pa, pn

        ok = True
        for i in range(1, n_atoms):
            j = rng.randrange(i)
            node_i, node_j = pick(atoms[i], per_atom, per_node), \
                pick(atoms[j], per_atom, per_node)
            if node_i is None or node_j is None:
                ok = False
                break
            inter.append({"name": f"e{i}", "junction_arity": 2,
                          "touches": (node_i, node_j)})
        if not ok:
            continue
        if n_atoms >= 3 and rng.random() < 0.5:
            res = attempt(rng.sample(atoms, 3))
            if res is not None:
                touches, per_atom, per_node = res
                inter.append({"name": f"e{len(inter) + 1}",
                              "junction_arity": 3, "touches": tuple(touches)})
        if rng.random() < MULTI_PORT_FRACTION:
            for _try in range(20):
                a1, a2 = rng.sample(atoms, 2)
                seq = [a1, a1, a2]
                if rng.random() < 0.5:
                    seq.append(rng.choice([a1, a2]))
                res = attempt(seq)
                if res is not None:
                    touches, per_atom, per_node = res
                    inter.append({"name": f"e{len(inter) + 1}",
                                  "junction_arity": len(touches),
                                  "touches": tuple(touches)})
                    break
        return inter
    return None


def generate_case(rng):
    """One generated grouped molecule, or None if the bounded retry
    (100 whole-case attempts) is exceeded."""
    for _attempt in range(100):
        n_atoms = rng.randint(1, 5)
        atoms = [_generate_atom(rng, i) for i in range(n_atoms)]
        if any(a is None for a in atoms):
            continue
        inter = _generate_inter(rng, atoms)
        if inter is None:
            continue
        mol = {"atoms": atoms, "inter": inter}
        if not validate_molecule(mol):
            return mol
    return None


# ---------------------------------------------------------------------------
# §11.2 transcription-seam / printed-oracle parse (Step 4)
# ---------------------------------------------------------------------------

def strip_md(cell):
    return cell.replace("**", "").strip()


def parse_tables(lines):
    """Yield markdown tables as lists of rows (lists of stripped
    cells) — A.7's parser, conventions unchanged."""
    tables, cur = [], []
    for ln in lines:
        s = ln.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [strip_md(c) for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                continue
            cur.append(cells)
        else:
            if cur:
                tables.append(cur)
                cur = []
    if cur:
        tables.append(cur)
    return tables


def section_11_2_lines(text):
    """The §11.2 span: from the line beginning "### 11.2" to the
    line beginning "### 11.3". None if either header is absent."""
    lines = text.splitlines()
    start = next((i for i, ln in enumerate(lines)
                  if ln.startswith("### 11.2")), None)
    if start is None:
        return None
    out = []
    for ln in lines[start + 1:]:
        if ln.startswith("### 11.3"):
            return out
        out.append(ln)
    return None


def ints_of(s):
    return tuple(int(x) for x in re.findall(r"-?\d+", s.replace("−", "-")))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 72)
    print("A.8 — MOLECULE REDUCTION: GROUPED RECORD == FLAT RECORD")
    print("  (Paper 12 §11.2; every total computed here from the")
    print("   declared records, by both routes)")
    print("=" * 72)

    worked = worked_example()
    wcomp = compute(worked)

    # --- Step 1: the worked example -----------------------------------
    print("\n--- Step 1: the §11.2 worked example — validation and "
          "the two routes ---")
    for a in worked["atoms"]:
        print(f"    atom {a['name']}: nodes {a['nodes']}, internal "
              f"junction arities {tuple(j['junction_arity'] for j in a['internal'])}, "
              f"Σ_int(atom) = {sum(j['junction_arity'] for j in a['internal'])}, "
              f"B recomputed = 6*{len(a['nodes'])} - "
              f"{sum(j['junction_arity'] for j in a['internal'])} = "
              f"{wcomp['per_atom_b'][a['name']]} (stored {a['b']}), "
              f"s2 = {a['s2']}, u = {a['u']}, inter-atom consumed = "
              f"{wcomp['per_atom_inter'][a['name']]}")
    for j in worked["inter"]:
        print(f"    inter-atom junction {j['name']}: junction arity "
              f"{j['junction_arity']}, touches {j['touches']}")
    print(f"    per-node consumed ports: "
          f"{dict(sorted(wcomp['per_node'].items()))}")
    errors = validate_molecule(worked)
    check(not errors,
          "(R1) the worked example satisfies every precondition of "
          "the definition",
          "; ".join(errors) if errors else
          "disjoint nodes, connected atoms, port caps, inter bounds, "
          "connected molecule graph")
    stored_ok = all(a["b"] == wcomp["per_atom_b"][a["name"]]
                    for a in worked["atoms"])
    check(stored_ok,
          "(R2) every stored per-atom B equals its recomputation "
          "from the atom's own record",
          f"recomputed {wcomp['per_atom_b']}")
    # Per-atom inter counts by a second route: junctions touched, not
    # touch entries (the two coincide iff touches have distinct atoms,
    # which (R1) has just checked).
    inter_by_junction = {
        a["name"]: sum(1 for j in worked["inter"]
                       if a["name"] in [t[0] for t in j["touches"]])
        for a in worked["atoms"]}
    check(inter_by_junction == wcomp["per_atom_inter"],
          "per-atom inter-atom consumed counts agree by the "
          "touch-entry route and the junction route",
          f"{wcomp['per_atom_inter']}")
    print(f"    N(mol) = {wcomp['n']}; Σ_int = {wcomp['sum_int']}; "
          f"Σ_inter = {wcomp['sum_inter']}; Σ_all = {wcomp['sum_all']}")
    print(f"    B(mol), flat route: 6*{wcomp['n']} - {wcomp['sum_all']} "
          f"= {wcomp['b_flat']}")
    print(f"    B(mol), two-level route: "
          f"{tuple(wcomp['per_atom_b'][a['name']] for a in worked['atoms'])} "
          f"sum {sum(wcomp['per_atom_b'].values())} - {wcomp['sum_inter']} "
          f"= {wcomp['b_two']}")
    print(f"    Σs²(mol) = {wcomp['sum_s2']}; Σu(mol) = {wcomp['sum_u']}")
    print(f"    census key v(mol) = {wcomp['key']}")
    check(wcomp["b_flat"] == wcomp["b_two"],
          "(R3) the B identity on the worked example: flat route == "
          "two-level route",
          f"{wcomp['b_flat']} == {wcomp['b_two']}")

    # --- Step 2: grouping independence on the worked example ----------
    print("\n--- Step 2: grouping independence — merging chains on "
          "the worked example ---")
    regrouped = None
    for order_label, order in (("declaration order (e1, e2)", None),
                               ("reverse order (e2, e1)", ["e2", "e1"])):
        chain = grouping_chain(worked, order)
        keys = [compute(g)["key"] for g in chain]
        for stage, g in enumerate(chain):
            print(f"    [{order_label}] grouping {stage}: atoms "
                  f"{[a['name'] for a in g['atoms']]}, inter "
                  f"{[j['name'] for j in g['inter']]}, key "
                  f"{compute(g)['key']}")
        check(all(k == keys[0] for k in keys) and keys[0] == wcomp["key"],
              f"(R4) census key identical at every grouping along the "
              f"{order_label} chain, and equal to the flat key")
        flat_errors = validate_molecule(chain[-1])
        check(len(chain[-1]["atoms"]) == 1 and not flat_errors,
              f"(R4) the fully merged grouping of the {order_label} "
              f"chain is a single atom satisfying the atom "
              f"preconditions",
              "; ".join(flat_errors) if flat_errors else
              f"single atom {chain[-1]['atoms'][0]['name']}, "
              f"B = {boundary_of(chain[-1]['atoms'][0])}")
        if order is None:
            regrouped = chain[1]   # alpha and beta merged, gamma apart
    rcomp = compute(regrouped)
    print(f"    regrouped (alpha+beta merged): atoms "
          f"{[a['name'] for a in regrouped['atoms']]}; N = {rcomp['n']}, "
          f"Σ_all = {rcomp['sum_all']}, B = {rcomp['b_flat']}, "
          f"key = {rcomp['key']}")
    check(rcomp["key"] == wcomp["key"],
          "the regrouped molecule (alpha and beta merged) carries "
          "the same census key as the original grouping")

    # --- Step 3: generated grouped molecules ---------------------------
    print(f"\n--- Step 3: enumeration — {GENERATED_CASES} seeded-RNG "
          f"generated grouped molecules ---")
    rng = random.Random(RNG_SEED)
    gen_ok = True
    atom_count_hist = Counter()
    multi_port_cases = 0
    for case_idx in range(GENERATED_CASES):
        mol = generate_case(rng)
        if mol is None:
            gen_ok = False
            print(f"    case {case_idx}: generation FAILED — bounded "
                  f"retry (100 whole-case attempts) exceeded")
            break
        atom_count_hist[len(mol["atoms"])] += 1
        if any(len({x[0] for x in j["touches"]}) < len(j["touches"])
               for j in mol["inter"]):
            multi_port_cases += 1
        errors = validate_molecule(mol)
        if errors:
            gen_ok = False
            print(f"    case {case_idx}: (R1) FAILED — {errors} "
                  f"on {mol}")
            break
        comp = compute(mol)
        if comp["b_flat"] != comp["b_two"]:
            gen_ok = False
            print(f"    case {case_idx}: (R3) FAILED — flat "
                  f"{comp['b_flat']} != two-level {comp['b_two']}")
            break
        if any(a["b"] != comp["per_atom_b"][a["name"]]
               for a in mol["atoms"]):
            gen_ok = False
            print(f"    case {case_idx}: (R2) FAILED — a stored B "
                  f"disagrees with its recomputation")
            break
        chain = grouping_chain(mol)
        keys = [compute(g)["key"] for g in chain]
        if any(k != keys[0] for k in keys) or keys[0] != comp["key"]:
            gen_ok = False
            print(f"    case {case_idx}: (R4) FAILED — chain keys "
                  f"{keys} vs original {comp['key']}")
            break
        flat_errors = validate_molecule(chain[-1])
        if len(chain[-1]["atoms"]) != 1 or flat_errors:
            gen_ok = False
            print(f"    case {case_idx}: (R4) FAILED — fully merged "
                  f"grouping invalid: {flat_errors}")
            break
    print(f"    generated molecules by atom count: "
          f"{dict(sorted(atom_count_hist.items()))}")
    print(f"    generated molecules containing a multi-port "
          f"inter-atom junction (one atom touched at least twice "
          f"by one junction): {multi_port_cases}")
    check(multi_port_cases > 0,
          "the generated domain includes multi-port inter-atom "
          "junctions (the generalized clause (ii) shapes)",
          f"{multi_port_cases} of {GENERATED_CASES} cases")
    check(gen_ok,
          f"(R1)–(R4) hold on all {GENERATED_CASES} generated grouped "
          f"molecules: validation, recomputed B, both B routes, and "
          f"the census key at every grouping of every merging chain",
          f"seed {RNG_SEED}")

    # --- Step 4: transcription seam + printed-oracle leg ---------------
    print("\n--- Step 4: §11.2 transcription seam + printed-oracle "
          "leg ---")
    paper_path = Path(__file__).resolve().parent.parent / "Paper_12_v4.md"
    if not paper_path.exists():
        print(f"    NOTE — oracle leg SKIPPED: {paper_path} does not "
              f"exist at run time. The coordinator re-runs A.8 after "
              f"the new §11.2 is integrated, when this leg must "
              f"execute.")
    else:
        text = paper_path.read_text(encoding="utf-8")
        span = section_11_2_lines(text)
        check(span is not None,
              "oracle present: §11.2 span (§§11.2–11.3 headers) in "
              "Paper_12_v4.md")
        if span is not None:
            flat = re.sub(r"\s+", " ", "\n".join(span)).replace("−", "-")
            tables = parse_tables(span)

            def grab(pat, label):
                m = re.search(pat, flat)
                check(m is not None, f"oracle present: {label}",
                      "printed form not found in §11.2" if m is None
                      else "")
                return m

            # Atom table: transcription seam against the records.
            atom_table = next(
                (t for t in tables if t and t[0][0] == "atom"), None)
            check(atom_table is not None,
                  "oracle present: §11.2 atom table")
            if atom_table is not None:
                mism = []
                seen = []
                for row in atom_table[1:]:
                    record_name = DISPLAY_TO_RECORD.get(row[0])
                    if record_name is None:
                        mism.append((row[0], "unmapped display name"))
                        continue
                    seen.append(record_name)
                    a = next(x for x in worked["atoms"]
                             if x["name"] == record_name)
                    parsed = (int(row[1]), ints_of(row[2]),
                              int(row[3]), ints_of(row[4])[-1],
                              int(row[5]), int(row[6]))
                    want = (len(a["nodes"]),
                            tuple(j["junction_arity"] for j in a["internal"]),
                            sum(j["junction_arity"] for j in a["internal"]),
                            wcomp["per_atom_b"][record_name],
                            a["s2"], a["u"])
                    if parsed != want:
                        mism.append((row[0], parsed, want))
                check(not mism and sorted(seen)
                      == sorted(a["name"] for a in worked["atoms"]),
                      "seam: §11.2 atom rows (N, internal junction arities, "
                      "Σ_j k_j, B — recomputed, Σs², Σu) match the "
                      "embedded records exactly",
                      f"mismatches: {mism}" if mism else
                      f"{len(atom_table) - 1} rows")

            # Inter-atom table: transcription seam against the records.
            inter_table = next(
                (t for t in tables if t and t[0][0]
                 == "inter-atom junction"), None)
            check(inter_table is not None,
                  "oracle present: §11.2 inter-atom table")
            if inter_table is not None:
                mism = []
                seen = []
                for row in inter_table[1:]:
                    seen.append(row[0])
                    j = next((x for x in worked["inter"]
                              if x["name"] == row[0]), None)
                    if j is None:
                        mism.append((row[0], "unknown junction"))
                        continue
                    joined = tuple(DISPLAY_TO_RECORD.get(tok.strip())
                                   for tok in row[1].split(","))
                    parsed = (joined, int(row[2]))
                    want = (tuple(t[0] for t in j["touches"]),
                            j["junction_arity"])
                    if parsed != want:
                        mism.append((row[0], parsed, want))
                check(not mism and sorted(seen)
                      == sorted(j["name"] for j in worked["inter"]),
                      "seam: §11.2 inter-atom rows (atoms joined, "
                      "junction arity) match the embedded records exactly",
                      f"mismatches: {mism}" if mism else
                      f"{len(inter_table) - 1} rows")

            # Summary lines, by their exact labels.
            m = grab(r"N\(mol\) = ([\d +]+) = \*\*(\d+)\*\*",
                     "N(mol) summary line")
            if m:
                check(list(ints_of(m.group(1)))
                      == [len(a["nodes"]) for a in worked["atoms"]]
                      and int(m.group(2)) == wcomp["n"],
                      "oracle: printed N(mol) summands and total == "
                      "computed",
                      f"printed {m.group(0)}, computed N = {wcomp['n']}")
            m = grab(r"Σs²\(mol\) = ([\d +]+) = \*\*(\d+)\*\*; "
                     r"Σu\(mol\) = ([\d +]+) = \*\*(\d+)\*\*",
                     "Σs²/Σu summary line")
            if m:
                check(list(ints_of(m.group(1)))
                      == [a["s2"] for a in worked["atoms"]]
                      and int(m.group(2)) == wcomp["sum_s2"]
                      and list(ints_of(m.group(3)))
                      == [a["u"] for a in worked["atoms"]]
                      and int(m.group(4)) == wcomp["sum_u"],
                      "oracle: printed Σs²(mol) and Σu(mol) summands "
                      "and totals == computed",
                      f"computed Σs² = {wcomp['sum_s2']}, "
                      f"Σu = {wcomp['sum_u']}")
            m = grab(r"B\(mol\), flat route: 6·N\(mol\) - Σ_all k_j = "
                     r"6·(\d+) - (\d+) = \*\*(\d+)\*\*",
                     "flat-route B(mol) line")
            if m:
                check((int(m.group(1)), int(m.group(2)),
                       int(m.group(3)))
                      == (wcomp["n"], wcomp["sum_all"], wcomp["b_flat"]),
                      "oracle: printed flat-route B(mol) (N, Σ_all, "
                      "value) == computed",
                      f"printed {m.groups()}, computed "
                      f"{(wcomp['n'], wcomp['sum_all'], wcomp['b_flat'])}")
            m = grab(r"B\(mol\), two-level route: \(([\d +]+)\) - "
                     r"(\d+) = \*\*(\d+)\*\*",
                     "two-level B(mol) line")
            if m:
                check(list(ints_of(m.group(1)))
                      == [wcomp["per_atom_b"][a["name"]]
                          for a in worked["atoms"]]
                      and int(m.group(2)) == wcomp["sum_inter"]
                      and int(m.group(3)) == wcomp["b_two"],
                      "oracle: printed two-level B(mol) (per-atom B "
                      "summands, Σ_inter, value) == computed",
                      f"printed {m.groups()}, computed B = "
                      f"{wcomp['b_two']}")
            m = grab(r"Census key: v\(mol, τ\) = \((\d+), \(([\d, ]+)\), "
                     r"(\d+), (\d+), (\d+)\)",
                     "census-key line")
            if m:
                parsed_key = (int(m.group(1)), ints_of(m.group(2)),
                              int(m.group(3)), int(m.group(4)),
                              int(m.group(5)))
                check(parsed_key == wcomp["key"],
                      "oracle: printed census key == computed census "
                      "key",
                      f"printed {parsed_key}, computed {wcomp['key']}")
            # Secondary echo prints (four).
            WORD_NUM = {"one": 1, "two": 2, "three": 3, "four": 4,
                        "five": 5, "six": 6, "seven": 7, "eight": 8,
                        "nine": 9, "ten": 10}
            m = grab(r"consume (\d+) boundary ports? of α \(at e1\), "
                     r"(\d+) boundary ports? of β \(one at e1, one at "
                     r"e2\), and (\d+) boundary ports? of γ \(at e2\)",
                     "feasibility per-atom consumed counts")
            if m:
                parsed = {rec: int(m.group(i + 1)) for i, rec in
                          enumerate(("alpha", "beta", "gamma"))}
                check(parsed == wcomp["per_atom_inter"],
                      "oracle: printed feasibility per-atom consumed "
                      "counts (α, β, γ) == computed",
                      f"printed {parsed}, computed "
                      f"{wcomp['per_atom_inter']}")
            m = grab(r"Σ_int k_j = ([\d +]+) = (\d+) over the atoms' "
                     r"internal junctions, Σ_inter k_j = ([\d +]+) = "
                     r"(\d+) over the inter-atom junctions, and "
                     r"Σ_all k_j = ([\d +]+) = (\d+) over the "
                     r"flattening",
                     "feasibility totals sentence")
            if m:
                per_atom_int = [sum(j["junction_arity"] for j in a["internal"])
                                for a in worked["atoms"]]
                totals_ok = (
                    list(ints_of(m.group(1))) == per_atom_int
                    and int(m.group(2)) == wcomp["sum_int"]
                    and list(ints_of(m.group(3)))
                    == [j["junction_arity"] for j in worked["inter"]]
                    and int(m.group(4)) == wcomp["sum_inter"]
                    and list(ints_of(m.group(5)))
                    == [wcomp["sum_int"], wcomp["sum_inter"]]
                    and int(m.group(6)) == wcomp["sum_all"])
                check(totals_ok,
                      "oracle: printed feasibility totals (Σ_int, "
                      "Σ_inter, Σ_all summands and totals) == "
                      "computed",
                      f"printed {m.groups()}, computed Σ_int = "
                      f"{wcomp['sum_int']}, Σ_inter = "
                      f"{wcomp['sum_inter']}, Σ_all = "
                      f"{wcomp['sum_all']}")
            m = grab(r"The merged atom has N = (\d+), internal "
                     r"junctions \(([\d, ]+)\), Σ_j k_j \(internal\) "
                     r"= (\d+), B = 6·(\d+) - (\d+) = (\d+), "
                     r"Σs² = (\d+), Σu = (\d+)",
                     "regrouping merged-atom line")
            if m:
                merged_atom = next(
                    a for a in regrouped["atoms"]
                    if a["name"] == "alpha+beta")
                merged_int = sum(j["junction_arity"]
                                 for j in merged_atom["internal"])
                want_merged = (len(merged_atom["nodes"]),
                               tuple(j["junction_arity"]
                                     for j in merged_atom["internal"]),
                               merged_int, len(merged_atom["nodes"]),
                               merged_int, boundary_of(merged_atom),
                               merged_atom["s2"], merged_atom["u"])
                parsed_merged = (int(m.group(1)), ints_of(m.group(2)),
                                 int(m.group(3)), int(m.group(4)),
                                 int(m.group(5)), int(m.group(6)),
                                 int(m.group(7)), int(m.group(8)))
                check(parsed_merged == want_merged,
                      "oracle: printed regrouping merged-atom line "
                      "(N, internal junction arities, Σ_j k_j, B arithmetic, "
                      "Σs², Σu) == computed merged atom",
                      f"printed {parsed_merged}, computed "
                      f"{want_merged}")
            word_alt = "|".join(WORD_NUM)
            m = grab(r"(" + word_alt + r") junctions of junction arity (\d+) "
                     r"and (" + word_alt + r") of junction arity (\d+), ("
                     + word_alt + r") junctions in all",
                     "junction arity multiset explanation sentence")
            if m:
                junction_arity_counts = Counter(wcomp["key"][1])
                parsed_counts = {int(m.group(2)): WORD_NUM[m.group(1)],
                                 int(m.group(4)): WORD_NUM[m.group(3)]}
                check(parsed_counts == dict(junction_arity_counts)
                      and WORD_NUM[m.group(5)]
                      == sum(junction_arity_counts.values()),
                      "oracle: printed junction arity multiset explanation "
                      "(word-form counts by junction arity, total junctions) "
                      "== computed junction arity multiset",
                      f"printed {parsed_counts} totalling "
                      f"{WORD_NUM[m.group(5)]}, computed "
                      f"{dict(junction_arity_counts)} totalling "
                      f"{sum(junction_arity_counts.values())}")

            regrouped_lines = [ln for ln in span if "Regrouped" in ln]
            check(len(regrouped_lines) >= 1,
                  "oracle present: Regrouped line")
            if regrouped_lines:
                bold = [int(x) for ln in regrouped_lines
                        for x in re.findall(r"\*\*(\d+)\*\*", ln)]
                want_bold = [rcomp["n"], rcomp["sum_all"],
                             rcomp["b_flat"]]
                check(bold == want_bold,
                      "oracle: the Regrouped line's bold numbers "
                      "(N, Σ_all, B of the computed regrouping "
                      "merging alpha and beta) == computed",
                      f"printed {bold}, computed {want_bold}")

    # --- Step 5: planted mutants ---------------------------------------
    print("\n--- Step 5: PLANTED MUTANT BATTERY (each must be "
          "REJECTED, with witness) ---")
    # M1 — off-by-one inter-atom junction arity in the B identity: one inter
    # junction's junction arity perturbed by +1 in a copy of the case used by
    # the two-level route only. The corrupted record is also caught
    # by (R1) as a whole (junction arity != len(touches)).
    mut1 = worked_example()
    mut1["inter"][0]["junction_arity"] += 1
    mut1_sum_inter = sum(j["junction_arity"] for j in mut1["inter"])
    mut1_b_two = (sum(wcomp["per_atom_b"].values()) - mut1_sum_inter)
    m1_errors = validate_molecule(mut1)
    m1_caught = (mut1_b_two != wcomp["b_flat"]
                 and wcomp["b_flat"] - mut1_b_two == 1)
    print(f"    witness: inter-atom junction e1 junction arity "
          f"{worked['inter'][0]['junction_arity']} corrupted to "
          f"{mut1['inter'][0]['junction_arity']} in the two-level route: "
          f"B two-level {wcomp['b_two']} -> {mut1_b_two} vs flat "
          f"{wcomp['b_flat']} (disagreement exactly 1); validation of "
          f"the corrupted record reports: {m1_errors}")
    check(m1_caught and bool(m1_errors),
          "M1: off-by-one inter-atom junction arity is REJECTED — the two B "
          "routes disagree by exactly 1, and validation catches the "
          "corrupted record (junction arity != len(touches))")

    # M2 — non-partition grouping double-counting a state: a grouping
    # of the worked example's flattening in which one node id appears
    # in two atoms. The partition validation must reject it, naming
    # the duplicated node and the two atoms.
    mut2 = worked_example()
    dup_node = mut2["atoms"][0]["nodes"][0]
    other_atom = mut2["atoms"][2]
    mut2["atoms"][2] = {**other_atom,
                        "nodes": other_atom["nodes"] + (dup_node,)}
    m2_errors = validate_molecule(mut2)
    m2_dups = find_duplicate_nodes(mut2)
    m2_caught = (dup_node in m2_dups
                 and m2_dups[dup_node] == [worked["atoms"][0]["name"],
                                           other_atom["name"]]
                 and any(dup_node in e for e in m2_errors))
    print(f"    witness: node {dup_node} booked under both "
          f"{m2_dups.get(dup_node)}; validation reports: "
          f"{[e for e in m2_errors if dup_node in e]}")
    check(m2_caught,
          "M2: non-partition grouping (one node in two atoms) is "
          "REJECTED by the partition validation, with the duplicated "
          "node and both atoms as witness")

    print("\n" + "=" * 72)
    if FAILURES:
        print(f"A.8 VERDICT: FAIL — {len(FAILURES)} check(s) failed: "
              f"{FAILURES}")
        print("=" * 72)
        return 1
    print("A.8 VERDICT: PASS — the molecule reduction's preconditions")
    print("  are validated on every case, per-atom B is recomputed (never")
    print(f"  trusted), the flat and two-level B routes agree, and the census")
    print(f"  key is identical at every grouping along every merging chain,")
    print(f"  on the §11.2 worked example and {GENERATED_CASES} generated grouped")
    print("  molecules; §11.2's printed tables, summary lines and secondary")
    print("  echo prints, when the paper is present, match the recomputation;")
    print("  both planted")
    print("  mutants are rejected with witnesses.")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
