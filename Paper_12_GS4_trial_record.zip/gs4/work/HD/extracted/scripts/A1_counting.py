#!/usr/bin/env python3
"""A.1 — Census identities and worked boundary counts, Paper 12 §3.

Machine companion to Paper 12 §3 (the counting rule) and Claim 3.1–3.3.
Checks, by COMPUTATION (never by restating the paper's numbers):

  (I)   Exhaustion/exclusivity — the count-classes partition the
        population: every body stands in exactly one class, and the
        class counts sum to |P|.  (Draft §3.3 identities (I)+(II);
        the class-sum half is the task sheet's identity (I).)
        DISCLOSED (loop remediation, EA-3.3): (I) is STRUCTURAL for a
        Counter-based census — a Counter over count vectors partitions
        by construction. The computational content of this script is
        identities (II)/(III), the worked counts (IV), and the
        dual-oracle taxicab enumeration (V); (I) is reported, not
        credited as a computation.
  (II)  Boundary additivity — the population's total boundary count is
        the sum of the per-body boundary counts, AND equals the direct
        route 6·(total nodes) − (total consumed ports).  (A component
        case of draft §3.3 identity (III); §3.5's cross-check.)
  (III) Grouped totals equal direct totals for every component of the
        count vector (draft §3.3 identity (III)): summing Q body by body
        equals summing (class count × class Q-value) over classes.
  (IV)  The worked counts of §3.4, recomputed from the constructions:
        (a) B = 6·3 − 3 = 15, (b) B = 6·2 − 2 = 10, (c) B = 6·3 − 4 = 14,
        via B = 6N − Σ_j k_j.
  (V)   The taxicab stress aggregates by a DUAL ORACLE: the closed-form
        route (shell sum with N(d) = 4d² + 2, Paper 10 §2.4.1) must agree
        with DIRECT lattice enumeration (count the integer points with
        |x|+|y|+|z| ≤ R; count adjacent pairs at taxicab distance 1).
        R = 2 → N = 25, J = 36, B = 78;  R = 3 → N = 63, J = 114, B = 150.

Identities (I)–(III) are checked on the declared exhibit P₀ of §3.5 AND
on generated populations (seeded RNG), so the checks compute the
identities rather than restate one exhibit's arithmetic.

Count-vector note: §3.1's record also carries Σs² and Σu. The §3.5
exhibit asserts NO values for them ("no values for them are asserted in
this example"), so the census checks here run on the components the
draft values — (N, junction arity multiset, B) — plus the derived
consumed-port total Σ_j k_j. (III) is componentwise; the unvalued
components enter it identically and are not silently filled in here.

INPUT_PROVENANCE:
  - B = 6N − Σ_j k_j and pairwise corollary B = 6N − 2J:
    class=cited-paper (Paper 11 v69 §4.1, licensed aggregate list).
  - Aggregates (a), (b), (c): constructions and B = 15, 10, 14:
    class=cited-paper (Paper 11 §§7–8 constructions, as restated in
    Paper 12 §3.4).
  - N(d) = 4d² + 2 for d ≥ 1: class=cited-paper (Paper 10 §2.4.1).
  - Taxicab balls R = 2, R = 3 with N = 25/63, J = 36/114, B = 78/150:
    class=paper-defined (Paper 12 §3.4 declares them controls, not
    native aggregates; J "machine-verified at source; recounted by
    direct enumeration ... for this paper" — the enumeration here IS
    that recount, an independent second oracle).
  - Exhibit population P₀ = {2×(a), 3×(b), 1×(c)}, totals 15 nodes,
    74 boundary ports: class=paper-defined (Paper 12 §3.5, declared
    bookkeeping exhibit).
  - Body-type pool and population sizes for generated populations:
    class=control (test fixtures built from the cited constructions).
  - RNG seed 20261024: class=arbitrary-representative (any seed serves;
    the identities are universal over finite populations).
"""
import random
import sys
from collections import Counter

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Bodies and the licensed boundary formula
# ---------------------------------------------------------------------------

class Body:
    """A body in the licensed alphabet: node count N and the multiset of
    its junctions' junction arities k_j. B is COMPUTED, never stored as input."""

    def __init__(self, name, n_nodes, junction_arities):
        self.name = name
        self.n = n_nodes
        self.junction_arities = tuple(sorted(junction_arities))

    @property
    def consumed(self):
        """Σ_j k_j — consumed ports, summed junction by junction."""
        return sum(self.junction_arities)

    @property
    def n_junctions(self):
        return len(self.junction_arities)

    @property
    def b(self):
        """B = 6N − Σ_j k_j (Paper 11 §4.1)."""
        return 6 * self.n - self.consumed

    def count_vector(self):
        """§3.2 count vector, valued components: (N, junction arity multiset, B)."""
        return (self.n, self.junction_arities, self.b)


def boundary_pairwise(body):
    """B = 6N − 2J — the PAIRWISE corollary. Valid only when every
    junction has junction arity 2; refuses (raises) otherwise."""
    if any(k != 2 for k in body.junction_arities):
        raise ValueError(
            f"pairwise corollary not licensed for {body.name}: "
            f"junction arities {body.junction_arities} are not all 2")
    return 6 * body.n - 2 * body.n_junctions


# Paper 11's constructions, as restated in Paper 12 §3.4.
BODY_A = Body("(a) shared-centre triple", 3, (3,))
BODY_B = Body("(b) complementary pair", 2, (2,))
BODY_C = Body("(c) chain A-B-C", 3, (2, 2))
SINGLE = Body("single configuration", 1, ())


# ---------------------------------------------------------------------------
# (IV) Worked boundary counts
# ---------------------------------------------------------------------------

def worked_counts():
    print("\n--- (IV) WORKED BOUNDARY COUNTS (§3.4), recomputed ---")
    for body, expected in ((BODY_A, 15), (BODY_B, 10), (BODY_C, 14)):
        got = body.b
        check(got == expected,
              f"{body.name}: B = 6·{body.n} − {body.consumed} = {got}",
              f"draft §3.4: {expected}")
    # Pairwise corollary, where licensed, must agree with the general form.
    for body in (BODY_B, BODY_C):
        check(boundary_pairwise(body) == body.b,
              f"pairwise corollary agrees on {body.name}",
              f"6N − 2J = {boundary_pairwise(body)} = 6N − Σk_j")
    # ... and must REFUSE the shared-centre aggregate (a) (junction arity 3).
    try:
        boundary_pairwise(BODY_A)
        check(False, "pairwise corollary refuses aggregate (a)",
              "no exception raised — guard missing")
    except ValueError as e:
        check(True, "pairwise corollary refuses aggregate (a)", str(e))


# ---------------------------------------------------------------------------
# (V) Taxicab stress aggregates — dual oracle
# ---------------------------------------------------------------------------

def shell_count(d):
    """N(d) = 4d² + 2, d ≥ 1 (Paper 10 §2.4.1)."""
    assert d >= 1
    return 4 * d * d + 2


def ball_closed_form(R):
    """Route 1: shell sum for N; B from the draft's J via B = 6N − 2J is
    NOT used here — route 1 supplies N only; J comes from enumeration,
    and the draft's (N, J, B) triple is checked for mutual consistency."""
    n = 1 + sum(shell_count(d) for d in range(1, R + 1))
    return n


def ball_enumeration(R):
    """Route 2 (independent oracle): enumerate the lattice points of the
    taxicab ball |x|+|y|+|z| ≤ R; count points and adjacent pairs
    (taxicab distance exactly 1, each pair counted once)."""
    pts = set()
    for x in range(-R, R + 1):
        for y in range(-R, R + 1):
            for z in range(-R, R + 1):
                if abs(x) + abs(y) + abs(z) <= R:
                    pts.add((x, y, z))
    edges = 0
    for (x, y, z) in pts:
        for dx, dy, dz in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
            if (x + dx, y + dy, z + dz) in pts:
                edges += 1
    return len(pts), edges


def taxicab():
    print("\n--- (V) TAXICAB STRESS AGGREGATES — DUAL ORACLE (§3.4) ---")
    expected = {2: (25, 36, 78), 3: (63, 114, 150)}
    for R, (n_exp, j_exp, b_exp) in expected.items():
        n_form = ball_closed_form(R)
        n_enum, j_enum = ball_enumeration(R)
        b_enum = 6 * n_enum - 2 * j_enum  # all junctions pairwise here
        check(n_form == n_enum,
              f"R={R}: shell-sum N = {n_form} == enumerated N = {n_enum}",
              "dual oracle agreement")
        check(n_enum == n_exp, f"R={R}: N = {n_enum}", f"draft §3.4: {n_exp}")
        check(j_enum == j_exp, f"R={R}: J = {j_enum} (enumerated adjacent pairs)",
              f"draft §3.4: {j_exp}")
        check(b_enum == b_exp, f"R={R}: B = 6·{n_enum} − 2·{j_enum} = {b_enum}",
              f"draft §3.4: {b_exp}")


# ---------------------------------------------------------------------------
# (I)–(III) Census identities
# ---------------------------------------------------------------------------

def census(population):
    """The §3.3 census: count-class (count vector) -> number of bodies."""
    return Counter(b.count_vector() for b in population)


def verify_identities(population, label):
    cen = census(population)
    ok = True
    # (I) partition: each body in exactly one class; class counts sum to |P|.
    ok &= check(sum(cen.values()) == len(population),
                f"{label}: (I) class counts sum to |P| = {len(population)}",
                f"Σ class counts = {sum(cen.values())}")
    # Class assignment must be a function of the vector alone: two bodies
    # with equal vectors never land in different classes (by construction
    # of Counter over vectors) — verified by rebuilding per body.
    per_body = {}
    partition_ok = True
    for b in population:
        v = b.count_vector()
        per_body.setdefault(v, []).append(b)
    for v, members in per_body.items():
        if cen[v] != len(members):
            partition_ok = False
    ok &= check(partition_ok,
                f"{label}: (I) every body in exactly one class (vector equality)")
    # (III) grouped totals == direct totals, componentwise; (II) is the
    # B-component together with the direct-route cross-check.
    comps = {"N": lambda b: b.n, "Σk_j": lambda b: b.consumed, "B": lambda b: b.b}
    for qname, q in comps.items():
        direct = sum(q(b) for b in population)
        grouped = 0
        for vec, count in cen.items():
            # class Q-value: recompute from the vector's own components
            n_c, ar_c, b_c = vec
            qval = {"N": n_c, "Σk_j": sum(ar_c), "B": b_c}[qname]
            grouped += count * qval
        ok &= check(grouped == direct,
                    f"{label}: (III) grouped {qname} total = {grouped} == direct = {direct}")
    # (II) boundary additivity, both routes of §3.5.
    total_b = sum(b.b for b in population)
    total_nodes = sum(b.n for b in population)
    total_consumed = sum(b.consumed for b in population)
    route = 6 * total_nodes - total_consumed
    ok &= check(total_b == route,
                f"{label}: (II) Σ per-body B = {total_b} == 6·{total_nodes} − {total_consumed} = {route}")
    return ok


def census_checks():
    print("\n--- (I)–(III) CENSUS IDENTITIES ---")
    print("    NOTE (EA-3.3): (I) is structural for a Counter-based census; "
          "the computational")
    print("    content of this script is identities (II)/(III), the worked "
          "counts, and the")
    print("    dual-oracle taxicab enumeration.")
    # The declared exhibit P₀ of §3.5.
    p0 = [BODY_A, BODY_A, BODY_B, BODY_B, BODY_B, BODY_C]
    verify_identities(p0, "P₀ (§3.5 exhibit)")
    cen = census(p0)
    check(cen[BODY_A.count_vector()] == 2 and cen[BODY_B.count_vector()] == 3
          and cen[BODY_C.count_vector()] == 1,
          "P₀: census is (2, 3, 1) over classes (a), (b), (c)")
    check(sum(b.n for b in p0) == 15, "P₀: total nodes = 15 (draft §3.5)")
    check(sum(b.b for b in p0) == 74, "P₀: total boundary ports = 74 (draft §3.5)")

    # Generated populations: the identities must COMPUTE, not restate.
    pool = [SINGLE, BODY_B, BODY_A, BODY_C,
            Body("two disjoint pairs", 4, (2, 2)),
            Body("junction arity 4 centre", 4, (4,)),
            Body("pair + single junction body", 2, (2,)),
            Body("five-chain", 5, (2, 2, 2, 2))]
    rng = random.Random(20261024)
    trials = 300
    all_ok = True
    for t in range(trials):
        size = rng.randint(1, 12)
        pop = [rng.choice(pool) for _ in range(size)]
        cen_t = census(pop)
        if sum(cen_t.values()) != len(pop):
            all_ok = False
            print(f"    trial {t}: (I) FAILED — class sum {sum(cen_t.values())} != {len(pop)}")
            break
        for q in (lambda b: b.n, lambda b: b.consumed, lambda b: b.b):
            if sum(q(b) for b in pop) != sum(c * q(Body("cls", v[0], v[1])) for v, c in cen_t.items()):
                all_ok = False
                print(f"    trial {t}: (III) FAILED on a generated population")
                break
        tb = sum(b.b for b in pop)
        if tb != 6 * sum(b.n for b in pop) - sum(b.consumed for b in pop):
            all_ok = False
            print(f"    trial {t}: (II) FAILED on a generated population")
            break
    check(all_ok, f"identities (I),(II),(III) hold on {trials} generated populations",
          "seeded RNG, sizes 1–12, 8 body types")


# ---------------------------------------------------------------------------
# Mutant battery — genuine spec violations, each must be REJECTED with a
# printed witness (mutant value vs verified value).
# ---------------------------------------------------------------------------

def boundary_double_counted(body):
    """MUTANT M2: consumed ports summed PER BODY-SIDE — each junction's
    junction arity counted once per body it touches, instead of once. This is
    §3.4's named careless count on the chain."""
    per_body = 0
    # in these aggregates a junction of junction arity k touches k bodies
    # (its ports sit at distinct bodies, one port per body); counting per
    # body-side multiplies each junction's contribution by ... the junction
    # arity itself is
    # the port count; the per-body-side error counts junction arity k once for
    # each of the body's junctions FROM EACH SIDE: emulate by summing,
    # for each body in a chain decomposition, its incident junction arities and
    # then summing over bodies — a junction between two bodies is then
    # counted twice. For the single aggregate body (c), model its three
    # constituent bodies explicitly:
    constituents = [(2,), (2, 2), (2,)]  # A, B, C incident junction arities
    for inc in constituents:
        per_body += sum(inc)
    return 6 * body.n - per_body


def mutants():
    print("\n--- MUTANT BATTERY (each must be REJECTED, with witness) ---")
    caught = 0
    total = 0

    # M1 — off-by-one in the shell counts: the raw formula 4d² + 2 applied
    # at d = 0, a shell its stated domain (d ≥ 1) excludes; N(0) = 2
    # phantom nodes. (The licensed shell_count() asserts d ≥ 1; the
    # mutant by construction bypasses that guard and evaluates raw.)
    total += 1
    m1 = 1 + sum(4 * d * d + 2 for d in range(0, 3))  # d = 0,1,2 for R = 2
    ok = (m1 != 25)
    caught += ok
    print(f"  [{'CAUGHT' if ok else 'NOT CAUGHT — INVESTIGATE'}] M1: shell sum "
          f"including d=0 gives N = {m1} ≠ 25 (witness: phantom N(0) = 2 nodes; "
          f"verified N = 25 by enumeration)")

    # M2 — a junction counted twice (per body-side) on the chain (c).
    total += 1
    m2 = boundary_double_counted(BODY_C)
    ok = (m2 != BODY_C.b)
    caught += ok
    print(f"  [{'CAUGHT' if ok else 'NOT CAUGHT — INVESTIGATE'}] M2: per-body-side "
          f"count on chain (c) gives B = {m2} ≠ 14 (witness: consumed ports "
          f"counted as 8 instead of Σ_j k_j = 4; verified B = {BODY_C.b})")

    # M3 — pairwise corollary B = 6N − 2J applied to aggregate (a), whose
    # shared junction has junction arity 3: the formula the draft forbids there.
    total += 1
    m3 = 6 * BODY_A.n - 2 * BODY_A.n_junctions
    ok = (m3 != BODY_A.b)
    caught += ok
    print(f"  [{'CAUGHT' if ok else 'NOT CAUGHT — INVESTIGATE'}] M3: pairwise "
          f"formula on shared-centre (a) gives B = {m3} ≠ 15 (witness: 2J = 2 "
          f"but Σ_j k_j = 3 at the junction of junction arity 3; verified B = {BODY_A.b}; "
          f"the licensed function boundary_pairwise refuses this input)")

    check(caught == total, f"mutants rejected: {caught}/{total}")


def main():
    print("=" * 70)
    print("A.1 — CENSUS IDENTITIES AND WORKED COUNTS (Paper 12 §3)")
    print("=" * 70)
    worked_counts()
    taxicab()
    census_checks()
    mutants()
    print("\n" + "=" * 70)
    if FAILURES:
        print(f"A.1 VERDICT: FAIL — {len(FAILURES)} check(s) failed: {FAILURES}")
        print("=" * 70)
        return 1
    print("A.1 VERDICT: PASS — identities (I)–(III) computed on the exhibit "
          "and generated populations;")
    print("  worked counts (a) 15, (b) 10, (c) 14 recomputed; taxicab "
          "R=2 (25, 36, 78) and R=3 (63, 114, 150)")
    print("  confirmed by closed form AND direct lattice enumeration; "
          "all mutants rejected with witnesses.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
