#!/usr/bin/env python3
"""G.1 — Quote Integrity for Paper 12.

Every verbatim quotation in the four staging drafts that is attributed
to Papers 9 / 10 / 11 / 11.5 is checked against the published source
texts on disk. Method:
  - Blockquotes are extracted from the drafts with their file+line.
  - Attribution is read from the quotation's neighbourhood (the lines
    immediately around the block): "Paper 9", "paper9.txt", "[CITED —
    L2-P12]", etc. The L-labels resolve per §0.3: L1→Paper 11,
    L2→Paper 9, L3→Paper 10, L4→Paper 11.5.
  - Both sides are normalized the same way: markdown emphasis stripped,
    whitespace collapsed, superscript digits folded (²→2, so Paper 9's
    flattened "v2 + s2 = c2" and the draft's "v² + s² = c²" compare
    equal — a typography fold, disclosed here), dashes unified,
    "[— page header in source —]" markers and "…" / "..." omissions
    split the quote into segments; every segment of ≥ 25 normalized
    characters must occur, in order, in the attributed source.
  - FOUND: all segments occur in the attributed source. PARTIAL: all
    segments occur in SOME source on disk but not (only) the attributed
    one — an attribution suspect. NOT FOUND: some segment occurs in no
    source.
Named checks (tasked individually, run in addition to the sweep):
  N1 Paper 9 §5 asymmetry passage (DRAFT_C §8.5 blockquote).
  N2 Paper 9 §4 temperature definition (DRAFT_C §7.1 blockquote).
  N3 Paper 10 §2.4.7 ULP theorem statement (DRAFT_C §9.4 blockquote).
  N4 Paper 10 eq. (2.7) S(d) = s²_node / N(d) — printed in paper10.txt.
  N5 Paper 10 eq. (2.4) contact budget — printed in paper10.txt and
     quoted in DRAFT_A §2.4 / DRAFT_C §7.2.
  N6 Paper 11.5 §7.4 capability debt quote (DRAFT_A §1.1 blockquote).
  N7 Paper 11.5 §11.6 count→weight debt quotes (DRAFT_A §1.2).
  N8 Paper 11 §4.1 licensed-sums passage (DRAFT_A §2.3 blockquote).
  N9 Paper 11 §16 role-taxonomy export quote (DRAFT_A §1.4).
  N10 Paper 11 §0.5 lock fragments quoted in DRAFT_A §0.5.
  N11 Paper 11.5 §1 roadmap sentence (DRAFT_A §1.5 blockquote).
  N12 Paper 9 §6 saturation Step 1 (DRAFT_C §9.4 blockquote).
Inline attributed quotations (quotation marks in prose, e.g. the
Abstract's Paper 9 phrase) are swept separately: every double-quoted
span of ≥ 40 characters in a paragraph that names a source paper is
checked against all sources and reported. SCOPING, stated: inline
fragments are woven into Paper 12's own sentences and legitimately
adapt initial case and terminal punctuation, so the inline sweep
compares case-folded with segment-edge punctuation stripped, and its
results are ADVISORY — printed in full for human adjudication, not
carrying the exit verdict. The hard verdict is carried by the
blockquote sweep and the named checks, where the drafts present text
as verbatim and verbatim is what is checked (case-sensitive). An
inline span that is Paper 12's own phrase in quotation marks (a
definition being named, not a source being quoted) will report
NOT FOUND in this sweep; the printed list is where a human confirms
that reading.

INPUT_PROVENANCE:
  - Source texts: class=cited-paper (published Papers 9/10 Zenodo
    extractions in paper_12_draft/sources/; Paper 11 v69 and
    Paper 11.5 v26 markdown in the workspace).
  - Quotations under test: class=paper-defined (staging_v1 drafts,
    read at run time).

ASSEMBLY ADJUSTMENT (2026-10-24, disclosed): the quotation source
files are now chosen in main() — with no argument, the assembled
paper (staging_v1/Paper_12_v1.md); with "--drafts", the four staging
drafts (the original behaviour); with any other argument, that file.
The named checks, the normalization, and the mutant battery are
untouched.

PACKAGE ADJUSTMENT (2026-10-24, disclosed): source resolution tries,
in order, a package-local sources/ directory (so the verification
package is self-contained), the workspace sources/ directory beside
the staging tree, and the original absolute workspace paths. Path
resolution only; no checking logic changes.

V2 ADJUSTMENT (2026-10-25, disclosed): the default quotation target
is now the v2 assembly (staging_v3/Paper_12_v2.md). The named checks,
the normalization, and the mutant battery are untouched.

V2 SELF-CONTAINED ADJUSTMENT (2026-10-26, disclosed): Appendix C now
embeds other files' full texts (the suite's listings and this
script's own four source papers) as data. The blockquote and inline
sweeps are therefore scoped to Paper 12's own prose: before sweeping
a target file, its Appendix C span (the line starting "## Appendix C."
through the line before the next "## " heading that lies OUTSIDE any
embedded marker block — the embedded source texts carry level-two
headings of their own, which are data inside the BEGIN/END blocks,
not paper structure) is masked out —
replaced line-for-line with empty strings, so every reported line
number stays true. Appendix J's treatment is deliberately unchanged:
its embedded engine listing has interacted with these sweeps since
v1, and its entries are part of the recorded baseline (29 hard-
verdict quotations, 60 inline checked, 14 advisory anomalies); the
masking changes none of those numbers — Appendix C contributed no
swept entry before, and its embedded texts contribute none now
(verified by re-run). The named checks, the normalization, and the
mutant battery are untouched.
  - V4 extension (2026-10-26, disclosed): Appendix E (the planted
    battery exhibits, v4) is masked on the exhibit-interior rule:
    BEGIN EXHIBIT blocks are tracked as embedded data and masked,
    while Appendix E's own prose is NOT masked and is swept like
    the rest of the paper — the exhibits are other files' texts,
    hash-checked by A.9, present as data, and are not this paper's
    quotations. (Loop-pass repair, 2026-10-26: the first v4 form
    masked the whole Appendix E span; narrowed to the interiors so
    the registry's "G.1 sweeps every verbatim quotation" stays true
    of Appendix E's prose. No swept number changes: Appendix E
    contributed no entry before it existed, and its prose carries
    no blockquote or named quotation.)
  - Normalization folds (superscripts, dashes, whitespace):
    class=declared-assumption — typography only; no word is folded,
    added, or removed. The mutant battery pins this: a one-word
    substitution must still fail.

V4 NOTE (2026-10-26, disclosed): default paper target is now the v4 assembly; no check logic changed.
"""
import re
import sys
from pathlib import Path

HOME = Path.home()
STAGING = HERE = Path(__file__).resolve().parent.parent
DRAFT_DIR = STAGING / "draft"


def _resolve(filename, *fallbacks):
    """First existing candidate wins: package layout (sources/ beside the
    paper), then the workspace layout (sources/ beside the staging tree),
    then the original absolute workspace paths."""
    cands = [STAGING / "sources" / filename,
             STAGING.parent / "sources" / filename,
             *fallbacks]
    for c in cands:
        if c.exists():
            return c
    return cands[0]


SOURCES = {
    "Paper 9": _resolve("paper9.txt",
                        HOME / "workspace/your_files/paper_12_draft/sources/paper9.txt"),
    "Paper 10": _resolve("paper10.txt",
                         HOME / "workspace/your_files/paper_12_draft/sources/paper10.txt"),
    "Paper 11": _resolve("paper_11_v69.md",
                         HOME / "workspace/your_files/paper_11_draft/paper_11_v69.md"),
    "Paper 11.5": _resolve("paper_11_5_v26.md",
                          HOME / "workspace/your_files/paper_11_5_draft/paper_11_5_v26.md"),
}
LABEL_SOURCE = {"L1-P12": "Paper 11", "L2-P12": "Paper 9",
                "L3-P12": "Paper 10", "L4-P12": "Paper 11.5"}

RESULTS = []


def mask_appendix_c(lines):
    """Replace the Appendix C span of a target file with empty lines
    (self-contained adjustment, disclosed in the docstring): the span
    runs from the line starting "## Appendix C." to just before the
    next level-two heading line that lies outside any embedded
    marker block — lines between a BEGIN LISTING / BEGIN SOURCE
    marker and its END marker are embedded data, and the source
    texts embedded there carry "## " headings of their own, which
    must not end the span. Line count and numbering are preserved.
    Files without such a heading (the staging drafts) pass through
    unchanged.

    V4 EXTENSION (2026-10-26, disclosed; loop-pass repair same
    date): the Appendix E span opens at the line starting
    "## Appendix E."; inside it, only the BEGIN EXHIBIT block
    interiors are masked, on the mention-not-use principle —
    Appendix E's own prose (headings, manifest, claim lines) is
    swept like the rest of the paper. The named checks, the
    normalization, and the mutant battery are untouched."""
    out, in_c, in_e, in_block = [], False, False, False
    for ln in lines:
        s = ln.strip()
        if (in_c or in_e) and not in_block and ln.startswith("## ") \
                and not ln.startswith(("## Appendix C.",
                                        "## Appendix E.")):
            in_c = False
            in_e = False
        if ln.startswith("## Appendix C."):
            in_c = True
        elif ln.startswith("## Appendix E."):
            in_e = True
        masked = in_c or (in_e and in_block)
        out.append("" if masked else ln)
        if s.startswith("<!-- BEGIN LISTING:") \
                or s.startswith("<!-- BEGIN SOURCE:") \
                or s.startswith("<!-- BEGIN EXHIBIT:"):
            in_block = True
        elif s == "<!-- END -->":
            in_block = False
    return out


def normalize(text):
    t = text
    t = t.replace("[— page header in source —]", " … ")
    t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)
    t = re.sub(r"(?<!\w)\*(.+?)\*(?!\w)", r"\1", t)
    for sup, digit in (("²", "2"), ("³", "3"), ("⁻", "-"), ("¹", "1")):
        t = t.replace(sup, digit)
    t = t.replace("Σ_j", "Σj").replace("Σ_{j}", "Σj")
    t = t.replace("−", "-").replace("–", "-").replace("—", "-")
    t = t.replace("“", '"').replace("”", '"')
    t = t.replace("‘", "'").replace("’", "'")
    t = re.sub(r"\s+", " ", t)
    return t.strip()


def segments(quote, fold_case=False):
    # Normalize FIRST: the page-header marker becomes an ellipsis under
    # normalization, and the split must see it. Edge punctuation of a
    # segment (the comma a prose sentence hangs on a woven fragment,
    # the period inside a closing quote) is stripped.
    parts = re.split(r"…|\.\.\.", normalize(quote))
    out = []
    for p in parts:
        p = p.strip().strip(".,;:").strip()
        if fold_case:
            p = p.lower()
        if len(p) >= 25:
            out.append(p)
    return out


def check_segments(segs, norm_sources):
    """Return (status, where, missing): FOUND in attributed source is
    decided by the caller; here: per-source segment coverage."""
    coverage = {}
    for name, src in norm_sources.items():
        pos, ok = -1, True
        for s in segs:
            i = src.find(s, pos + 1)
            if i < 0:
                ok = False
                break
            pos = i
        coverage[name] = ok
    return coverage


def verdict_for(segs, attributed, norm_sources):
    cov = check_segments(segs, norm_sources)
    if attributed and cov.get(attributed):
        return "FOUND", attributed, None
    found_in = [n for n, ok in cov.items() if ok]
    if found_in:
        if attributed is None:
            return "FOUND", ", ".join(found_in), \
                "no single attribution in paragraph; verified in source(s) listed"
        return "PARTIAL", ", ".join(found_in), \
            f"segments verify in {found_in} but not in attributed {attributed}"
    # find first missing segment anywhere
    allsrc = norm_sources
    for s in segs:
        if not any(s in src for src in allsrc.values()):
            return "NOT FOUND", "-", f"segment absent from all sources: \"{s[:90]}...\""
    return "NOT FOUND", "-", "segments present only out of order"


def extract_blockquotes(lines):
    quotes, cur, start = [], [], None
    for i, ln in enumerate(lines, 1):
        if ln.lstrip().startswith(">"):
            if start is None:
                start = i
            cur.append(ln.lstrip()[1:].strip())
        else:
            if cur:
                quotes.append((start, " ".join(cur)))
                cur, start = [], None
    if cur:
        quotes.append((start, " ".join(cur)))
    return quotes


def attribution(lines, start, end):
    window = "\n".join(lines[max(0, start - 4):end + 4])
    for lab, src in LABEL_SOURCE.items():
        if lab in window:
            return src
    for name in ("Paper 11.5", "Paper 11", "Paper 10", "Paper 9"):
        if name in window or name.replace(" ", "").lower() + ".txt" in \
                window.replace(" ", "").lower():
            return name
    return None


def record(kind, fname, lno, attributed, segs, norm_sources, note=""):
    status, where, missing = verdict_for(segs, attributed, norm_sources)
    RESULTS.append((status, kind, fname, lno, attributed, where, missing or note))
    return status


def main():
    print("=" * 70)
    print("G.1 — QUOTE INTEGRITY (Paper 12 vs published sources)")
    print("=" * 70)
    raw_sources = {n: p.read_text(encoding="utf-8", errors="replace")
                   for n, p in SOURCES.items()}
    norm_sources = {n: normalize(t) for n, t in raw_sources.items()}
    for n, p in SOURCES.items():
        print(f"  source {n}: {p} ({len(raw_sources[n])} chars)")

    args = sys.argv[1:]
    if args and args[0] == "--drafts":
        draft_files = sorted(DRAFT_DIR.glob("DRAFT_*.md"))
    elif args:
        draft_files = [Path(args[0])]
    else:
        draft_files = [STAGING / "Paper_12_v4.md"]
    print(f"\n--- Blockquote sweep ({len(draft_files)} file(s): "
          f"{[f.name for f in draft_files]}) ---")
    n_bq = 0
    for f in draft_files:
        lines = mask_appendix_c(f.read_text(encoding="utf-8").splitlines())
        for start, qtext in extract_blockquotes(lines):
            segs = segments(qtext)
            if not segs:
                continue
            n_bq += 1
            attr = attribution(lines, start, start + qtext.count("\n") + 3)
            record("blockquote", f.name, start, attr, segs, norm_sources)
    print(f"blockquotes checked: {n_bq}")

    print("\n--- Inline attributed quotations (≥ 40 chars, source named "
          "in paragraph) — ADVISORY, case-folded ---")
    folded_sources = {n: s.lower() for n, s in norm_sources.items()}
    INLINE = []
    n_in = 0
    for f in draft_files:
        text = mask_appendix_c(f.read_text(encoding="utf-8").splitlines())
        para, pstart = [], None
        blocks = []
        for i, ln in enumerate(text, 1):
            if ln.strip():
                if pstart is None:
                    pstart = i
                para.append(ln)
            else:
                if para:
                    blocks.append((pstart, " ".join(para)))
                para, pstart = [], None
        if para:
            blocks.append((pstart, " ".join(para)))
        for pstart, ptext in blocks:
            if ptext.lstrip().startswith(">") or ptext.lstrip().startswith("|"):
                continue
            named = [name for name in
                     ("Paper 11.5", "Paper 11", "Paper 10", "Paper 9")
                     if name in ptext]
            if not named:
                continue
            attr = named[0] if len(named) == 1 else None
            for span in re.findall(r'"([^"]{40,})"', ptext):
                segs = segments(span, fold_case=True)
                if segs:
                    n_in += 1
                    status, where, missing = verdict_for(
                        segs, attr, folded_sources)
                    INLINE.append((status, "inline", f.name, pstart,
                                   attr, where, missing or ""))
    print(f"inline quotations checked: {n_in}")
    for status, kind, fname, lno, attr, where, note in INLINE:
        print(f"  [{status}] inline {fname}:{lno} attributed={attr} "
              f"verified-in={where} {note}")

    print("\n--- Named checks ---")
    named = [
        ("N1 asymmetry of occasion (Paper 9 §5)",
         "The asymmetry of occasion - why heat flows hot to cold",
         "Paper 9"),
        ("N1b asymmetry deferral sentence",
         "The full statistical aggregation of these asymmetric occasions",
         "Paper 9"),
        ("N2 temperature definition (Paper 9 §4)",
         "Temperature is the localized density and frequency of chaotic "
         "creation-geometry rewrite events per tick", "Paper 9"),
        ("N3 ULP theorem statement (Paper 10 §2.4.7)",
         "the temporal-scan workload partitions uniformly across all "
         "admissible configurations at the same relay distance d", "Paper 10"),
        ("N4 eq. (2.7) S(d) = s2_node / N(d)",
         "S(d) = s2_node / N(d)", "Paper 10"),
        ("N5 eq. (2.4) contact budget",
         "N_total = N_id + v2_contact + s2 + N_reconcile = 100 CU", "Paper 10"),
        ("N6 capability debt (Paper 11.5 §7.4)",
         "the formal account of capability as a relation to possible "
         "encounters", "Paper 11.5"),
        ("N7 count→weight debt (Paper 11.5 §11.6)",
         "a microstate-counting rule, and (2) a sampling-measure postulate",
         "Paper 11.5"),
        ("N7b fill rules (Paper 11.5 §11.6)",
         "which encounter actualizes with what probability at a given tick",
         "Paper 11.5"),
        ("N8 licensed sums (Paper 11 §4.1)",
         "No aggregate-level quantity may be introduced unless it is "
         "defined as an exact finite sum, count, or rational ratio",
         "Paper 11"),
        ("N9 taxonomy export (Paper 11 §16)",
         "Paper 12 uses the taxonomy to determine which configurations "
         "count as resolvable bodies in the aggregated ledger", "Paper 11"),
        ("N10 lock fragment (Paper 11 §0.5)",
         "do not occur in Stage N and name nothing in the native vocabulary",
         "Paper 11"),
        ("N10b lock deferral (Paper 11 §0.5)",
         "constrained by Paper 9's asymmetry of occasion, not computed here",
         "Paper 11"),
        ("N11 roadmap sentence (Paper 11.5 §1)",
         "frequencies from combinatorics without an imported measure",
         "Paper 11.5"),
        ("N12 saturation Step 1 (Paper 9 §6)",
         "Step 1, local budget saturation: as chaotic insertions accumulate",
         "Paper 9"),
    ]
    for label, frag, src in named:
        segs = segments(frag)
        status, where, missing = verdict_for(segs, src, norm_sources)
        RESULTS.append((status, "named", label, "-", src, where, missing or ""))
        print(f"  [{status}] {label}")

    print("\n--- Mutant battery ---")
    mutants_ok = True
    good = segments("Temperature is the localized density and frequency "
                    "of chaotic creation-geometry rewrite events per tick")
    bad = segments("Temperature is the localized density and frequency "
                   "of chaotic creation-geometry rewrite events per second")
    st_good, _, _ = verdict_for(good, "Paper 9", norm_sources)
    st_bad, _, miss = verdict_for(bad, "Paper 9", norm_sources)
    print(f"  control (verbatim)      : {st_good} (expect FOUND)")
    print(f"  mutant (tick → second)  : {st_bad} (expect NOT FOUND) — {miss}")
    mutants_ok = (st_good == "FOUND" and st_bad == "NOT FOUND")
    wrong_attr, _, _ = verdict_for(good, "Paper 10", norm_sources)
    print(f"  mutant (wrong attribution: P9 quote as Paper 10): "
          f"{wrong_attr} (expect PARTIAL)")
    mutants_ok &= (wrong_attr == "PARTIAL")

    print("\n--- Full report (hard-verdict set: blockquotes + named) ---")
    n_bad = 0
    for status, kind, fname, lno, attr, where, note in RESULTS:
        mark = "" if status == "FOUND" else "  <<<"
        if status != "FOUND":
            n_bad += 1
        print(f"  [{status}] {kind} {fname}:{lno} attributed={attr} "
              f"verified-in={where} {note}{mark}")
    n_inline_bad = sum(1 for r in INLINE if r[0] != "FOUND")
    print(f"Advisory inline anomalies (printed above, for human "
          f"adjudication): {n_inline_bad} of {len(INLINE)}")
    print("=" * 70)
    if n_bad or not mutants_ok:
        print(f"G.1 VERDICT: FAIL — {n_bad} quotation(s) not FOUND as "
              f"attributed" + ("" if mutants_ok else "; mutant battery failed"))
        return 1
    print(f"G.1 VERDICT: PASS — all {len(RESULTS)} verbatim quotations "
          f"(blockquotes + named checks) FOUND in their attributed "
          f"sources; mutants behave; {n_inline_bad} advisory inline "
          f"anomalies listed for adjudication.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
