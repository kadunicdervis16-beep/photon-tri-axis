#!/usr/bin/env python3
"""A.10 — Worked application: the two-level system (Paper 12 §8.7).

Machine companion to Paper 12 §8.7. Computes EVERY derived number
printed in §8.7 from the section's declared population, using
Paper 11's operator T exactly as Paper 12 §4 states it — the T
implementation below is copied from A7_exhibit.py (itself copied
from A2_parallel_tick.py), conventions unchanged:

  T (Paper 11 §7.5, via Paper 12 §4): a junction's local state is a
  pair of port vectors (A, B). Index k is ADMISSIBLE iff
  A[k] = -B[k] != 0. T zeroes the CANONICALLY FIRST admissible pair;
  if none, T is the identity. tau(sigma) = sum of squares of all
  entries; each action drops tau by exactly 2 (admissible entries
  are unit port values).

THE DECLARED POPULATION (§8.7): n = 12 named bodies T1..T12, each
carrying exactly one pairwise junction of port-vector length 2; local state sigma = (A, B)
with A, B length-2 vectors over {-1, 0, +1}. Six bodies (T1..T6)
declare sigma_0 = ((1, 0), (-1, 0)); six bodies (T7..T12) declare
sigma_0 = ((1, 1), (-1, -1)).

THE FEATURE (§8.7, a feature of sigma in the licence of Definition
5.1 — ledger data alone): phi(sigma) is class A iff sigma presents
an opposed unit pair at some index (there exists k with
A[k] = +1 and B[k] = -1); otherwise phi(sigma) is class B. The
classes are §8.2's two census classes A and B. phi is total: every
sigma stands in exactly one class. (The class labels A and B are
§8.2's census-class labels; the port vectors of sigma are also
written (A, B) in §4's notation. The script keeps them apart:
feature() returns a class label, and port vectors are only ever
read, never returned.)

CHECKS (all exact; shares are Fractions, never floats):
  - population construction exactly as declared: 12 named bodies,
    one pairwise junction of port-vector length 2 each, the sigma table as declared, every
    entry a unit port value in {-1, 0, +1};
  - phi totality, exhaustively: phi is evaluated on all
    3^4 = 81 length-2 local states over {-1, 0, +1} and returns a
    class for every one;
  - the trajectory: T_agg recomputed step by step (parallel tick),
    ticks 0-3; tick 1 cross-checked against sequential application
    in a deterministic set of different orders (identity, reverse,
    all rotations, seeded shuffles — 12! orders are NOT enumerated,
    and this script does not claim they are), and every tick
    cross-checked against the reverse-order sequential tick;
  - the feature census at every tick; tau_agg at every tick;
    Delta tau_agg = -2 x (number of acting junctions) at every
    step (Proposition 4.3);
  - Omega of every visited record, by two independent routes:
    ROUTE 1 (literal enumeration of all 2^12 assignments of the
    12 named bodies to the two classes, counted per record) and
    ROUTE 2 (math.comb, the closed form (8.1)); the routes must
    agree on every record; the full n = 12 record table
    C(12, k), k = 0..12; the total against 2^12 = 4096 (8.2);
    C(12, 6) = 924; the balanced record's share as an exact
    Fraction, 924/4096 = 231/1024;
  - (E1) and (E2) verdicts for every distinct visited record:
    (E1) by two routes — the record after the tick leaving the
    record equals the record before it, and every class's net
    flow count Phi is zero (9.3) — with the final record's (E1)
    confirmed by one further computed tick; (E2) by comparison
    of the record's Omega against the maximum over the FULL
    n = 12 record table (§9.3's all-records comparison);
  - the (p, c) decomposition of the trajectory by visited-state
    enumeration (A.3/A.7's route);
  - the computed values against the ORACLE below — §8.7's printed
    values, transcribed as the prediction under test.

ORACLE DISCIPLINE: the printed prose values of §8.7 enter this
script ONLY as the oracle under test (the prediction, in the
ORACLE block below). Every count the verdict rests on is computed
here from the declared population by T and by the counting routes;
no computation reads the oracle except the final comparisons. If
any printed value disagrees with the computation, this script
FAILS and prints the discrepancy as a witness. It does not edit
the draft, and it does not adjust the computation to fit the
oracle.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: §§4, 8 and 9 of Paper 12 over arbitrary
      finite populations, arbitrary binary features of ledger
      data, and arbitrary declared local states.
  (2) Verified domain: the single declared 12-body population of
      §8.7 (one pairwise junction of port-vector length 2 per body, two declared sigma_0
      types), its ticks 0-3 plus one confirming tick, the single
      declared feature phi, and the n = 12 two-class assignment
      counting (full enumeration, 2^12 assignments).
  (3) Map: native body -> its declared record (name, sigma_0);
      native census record -> the (count in class A, count in
      class B) pair of the phi-census; native assignment count
      -> the number of assignments of the 12 named bodies
      realising the record.
  (4) Preserved: every value §8.7 prints — the trajectory's
      census records, Omega values, tau_agg values, acting
      counts, (E1)/(E2) verdicts, and the (p, c) decomposition —
      is recomputed from the declared records by the definitions'
      own routes (T for the dynamics, enumeration and the closed
      form for the counting, net flows and record equality for
      (E1), the full record table for (E2)).
  (5) Outside the machine check: Paper 11 §4.3 (disjointness,
      cited — the population's junctions are declared over
      disjoint port sets, as §8.7 declares them), Paper 11 §7.5
      (T's properties, cited — the implementation is A.2/A.7's,
      whose own batteries check them; on this index-symmetric
      population the canonical-first choice is
      outcome-indistinguishable, and that premise is verified by
      A.2/A.7, not by this script), the Stage P recognition
      of §8.7 (claim L8.9-P12, [LEVEL B] — a recognition under
      §8.4's bridge, not a counting claim, and no part of this
      script's verdict), and any claim about populations other
      than this declared one.

INPUT_PROVENANCE:
  - The 12 bodies T1..T12, the single pairwise junction of port-vector length 2 per body,
    and the tick-0 local states sigma_0 (six of each declared
    type): class=control (the declared population of §8.7,
    transcribed into this script; the values are transcribed
    into §8.7's text at integration and the coordinator verifies
    the transcription — this script does not read the paper, and
    §8.7 does not exist in the paper yet at the time of writing).
  - The feature phi (opposed unit pair at some index -> class A,
    otherwise class B): class=paper-defined (declared in §8.7
    under Definition 5.1's licence; stated identically in
    §8.7's prose and in feature() below).
  - T's definition, admissibility, tau and the per-action drop
    of 2: class=cited-paper (Paper 11 §7.5, as restated in
    Paper 12 §4; implementation copied from A.7/A.2).
  - Omega(k; n) = C(n, k) (8.1), the total 2^n (8.2):
    class=paper-defined (Paper 12 §8.2) — the claims under test;
    the script re-derives their values at n = 12 from raw
    enumeration and from math.comb independently.
  - (E1) stationarity as record equality / zero net flows (9.3),
    and (E2) maximality among ALL census records of the declared
    population: class=paper-defined (Paper 12 §§9.2-9.3).
  - The ORACLE block (§8.7's printed trajectory records, tau_agg
    series, acting counts, Omega table, balanced share,
    (E1)/(E2) verdicts, (p, c)): class=control (the prediction
    under test, transcribed from §8.7's draft; never used in any
    computation — see ORACLE DISCIPLINE above).
  - Shuffle seed for the deterministic order set:
    class=arbitrary-representative (test design only; the
    identity, reverse and rotation orders are seed-free).
  - The mutant battery's two planted values (the wrong Omega
    cell 793 and the fabricated tick-1 record (8, 4)):
    class=control (declared mutants; each is a genuine spec
    violation of a stated kind — a wrong assignment count, and
    a trajectory record T does not produce).

Exact arithmetic: counts are integers; the one share printed is a
fractions.Fraction. No float is used for any claimed value.
"""
import itertools
import random
import sys
from collections import Counter
from fractions import Fraction
from itertools import product
from math import comb
from pathlib import Path  # noqa: F401  (house path convention, see docstring)

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Paper 11's operator T, exactly as Paper 12 §4 states it
# (copied from A7_exhibit.py / A2_parallel_tick.py).
# ---------------------------------------------------------------------------

def admissible_indices(sigma):
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def tau(sigma):
    A, B = sigma
    return sum(a * a for a in A) + sum(b * b for b in B)


def T(sigma):
    """Zero the canonically first admissible pair; identity if none."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[0]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


def parallel_tick(state):
    return tuple(T(s) for s in state)


def sequential_tick(state, order):
    st = list(state)
    for j in order:
        st[j] = T(st[j])
    return tuple(st)


def tau_agg(state):
    return sum(tau(s) for s in state)


def acting_indices(state):
    return [j for j, s in enumerate(state) if admissible_indices(s)]


# ---------------------------------------------------------------------------
# Declared population (§8.7) — the only declared dynamics data.
# ---------------------------------------------------------------------------

BODIES = [f"T{i}" for i in range(1, 13)]          # T1..T12
SIGMA_SINGLE = ((1, 0), (-1, 0))                  # one opposed pair
SIGMA_DOUBLE = ((1, 1), (-1, -1))                 # two opposed pairs
SIGMA0 = tuple([SIGMA_SINGLE] * 6 + [SIGMA_DOUBLE] * 6)   # T1..T6, T7..T12
PORT_VECTOR_LENGTH = 2                # one pairwise junction of this length each
N = len(BODIES)
SHUFFLE_SEED = 20261026
N_SHUFFLES = 200


def feature(sigma):
    """phi(sigma), §8.7's feature, stated identically in the prose:
    class A iff sigma presents an opposed unit pair at some index
    (exists k: A[k] = +1 and B[k] = -1); otherwise class B."""
    A, B = sigma
    for k in range(len(A)):
        if A[k] == 1 and B[k] == -1:
            return "A"
    return "B"


def census(state):
    """The phi-census record (count in A, count in B) of a state."""
    classes = [feature(s) for s in state]
    return (classes.count("A"), classes.count("B"))


# ---------------------------------------------------------------------------
# ORACLE UNDER TEST — §8.7's printed values, transcribed as the
# prediction. No computation below reads these except comparisons.
# ---------------------------------------------------------------------------

ORACLE_RECORDS = [(12, 0), (6, 6), (0, 12), (0, 12)]        # ticks 0-3
ORACLE_TAU_AGG = [36, 12, 0, 0]                             # ticks 0-3
ORACLE_ACTING = [12, 6, 0]              # acting junctions, ticks 1-3
ORACLE_OMEGA_TABLE = (1, 12, 66, 220, 495, 792, 924,
                      792, 495, 220, 66, 12, 1)             # C(12, k)
ORACLE_TOTAL = 4096                                         # 2^12
ORACLE_BALANCED_SHARE = Fraction(231, 1024)                 # 924/4096
ORACLE_PC = (2, 1)                                          # (p, c)
# (E1, E2, equilibrium) per distinct visited record:
ORACLE_VERDICTS = {(12, 0): (False, False, False),
                   (6, 6): (False, True, False),
                   (0, 12): (True, False, False)}


# ---------------------------------------------------------------------------
# Counting routes (independent of each other and of the oracle)
# ---------------------------------------------------------------------------

def omega_by_enumeration(n):
    """ROUTE 1: literally enumerate all 2^n assignments of n named
    bodies to classes {A, B}; count assignments per record."""
    counts = {}
    for assignment in product(range(2), repeat=n):
        record = (assignment.count(0), assignment.count(1))
        counts[record] = counts.get(record, 0) + 1
    return counts


def omega_by_comb(n):
    """ROUTE 2: math.comb — the closed form (8.1)."""
    return {(k, n - k): comb(n, k) for k in range(n + 1)}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 72)
    print("A.10 — WORKED APPLICATION: THE TWO-LEVEL SYSTEM (Paper 12 §8.7)")
    print("  (every derived number computed here from the declared")
    print("   population; §8.7's printed values are the oracle under test)")
    print("=" * 72)

    # --- Declared population: construction exactly as declared -------
    print("\n--- Step 1: population construction, as declared ---")
    check(N == 12 and BODIES == [f"T{i}" for i in range(1, 13)],
          "12 named bodies T1..T12")
    check(len(SIGMA0) == N,
          "one declared local state per body (one junction per body)")
    check(all(len(s[0]) == PORT_VECTOR_LENGTH and len(s[1]) == PORT_VECTOR_LENGTH for s in SIGMA0),
          "every junction has port-vector length 2: both port vectors have length 2")
    check(all(v in (-1, 0, 1) for s in SIGMA0 for v in s[0] + s[1]),
          "every sigma entry is a unit port value in {-1, 0, +1}")
    check(Counter(SIGMA0) == Counter({SIGMA_SINGLE: 6, SIGMA_DOUBLE: 6}),
          "the sigma table as declared: six bodies at ((1, 0), (-1, 0)) "
          "(T1..T6), six at ((1, 1), (-1, -1)) (T7..T12)",
          f"computed census of declared states: {dict(Counter(SIGMA0))}")
    for b, s in zip(BODIES, SIGMA0):
        print(f"    {b}: sigma_0 = (A={s[0]}, B={s[1]}), tau = {tau(s)}")

    # --- Feature totality (exhaustive over all local states) ---------
    print("\n--- Step 2: the feature phi — totality, exhaustive ---")
    all_states = [((a0, a1), (b0, b1))
                  for a0 in (-1, 0, 1) for a1 in (-1, 0, 1)
                  for b0 in (-1, 0, 1) for b1 in (-1, 0, 1)]
    phi_values = {feature(s) for s in all_states}
    check(len(all_states) == 81
          and all(feature(s) in ("A", "B") for s in all_states),
          "phi is total: evaluated on all 3^4 = 81 length-2 local "
          "states, it returns a class for every one",
          f"classes returned: {sorted(phi_values)}")
    a_states = sum(1 for s in all_states if feature(s) == "A")
    print(f"    of the 81 local states, {a_states} stand in class A "
          f"and {81 - a_states} in class B under phi (a count of the "
          f"feature's domain, printed for the record; §8.7 claims "
          f"nothing from it)")

    # --- Trajectory ----------------------------------------------------
    print("\n--- Step 3: the aggregate-tick trajectory, ticks 0-3 ---")
    states = [SIGMA0]
    for _ in range(3):
        states.append(parallel_tick(states[-1]))
    records = [census(st) for st in states]
    tau_series = [tau_agg(st) for st in states]
    acting_series = []
    for ti in range(3):
        act = acting_indices(states[ti])
        acting_series.append(len(act))
        d = tau_series[ti + 1] - tau_series[ti]
        print(f"  tick {ti + 1}: acting junctions "
              f"{[BODIES[j] for j in act]} (count {len(act)}); "
              f"census {records[ti]} -> {records[ti + 1]}; "
              f"tau_agg {tau_series[ti]} -> {tau_series[ti + 1]}; "
              f"Delta tau_agg = {d}")
        check(d == -2 * len(act),
              f"tick {ti + 1}: Delta tau_agg = -2 x acting "
              f"(Proposition 4.3)")
        check(parallel_tick(states[ti])
              == sequential_tick(states[ti],
                                 tuple(reversed(range(N)))),
              f"tick {ti + 1}: parallel tick == reverse-order "
              f"sequential tick")
    for ti, st in enumerate(states):
        per = ", ".join(f"{b}:{feature(s)}"
                        for b, s in zip(BODIES, st))
        print(f"    at tick {ti}: record (A, B) = {records[ti]}; "
              f"tau_agg = {tau_series[ti]}  ({per})")
    check(records[0] == (N, 0),
          "the initial census is fully polarized (12, 0) — computed "
          "from the declared states by phi, not assumed",
          f"computed initial record: {records[0]}")
    check(records == ORACLE_RECORDS,
          "oracle: printed census trajectory == computed",
          f"printed {ORACLE_RECORDS}, computed {records}")
    check(tau_series == ORACLE_TAU_AGG,
          "oracle: printed tau_agg series == computed",
          f"printed {ORACLE_TAU_AGG}, computed {tau_series}")
    check(acting_series == ORACLE_ACTING,
          "oracle: printed acting counts == computed",
          f"printed {ORACLE_ACTING}, computed {acting_series}")

    # Order-independence of tick 1 (A.7's approach; 12! not enumerated).
    print("    order-independence of tick 1:")
    start, expected = states[0], states[1]
    pair_total = 0
    pair_ok = True
    for i, j in itertools.combinations(range(N), 2):
        pair_total += 1
        st_ij = list(start); st_ij[i] = T(st_ij[i]); st_ij[j] = T(st_ij[j])
        st_ji = list(start); st_ji[j] = T(st_ji[j]); st_ji[i] = T(st_ji[i])
        if tuple(st_ij) != tuple(st_ji):
            pair_ok = False
            print(f"      PAIRWISE DIVERGENCE at junctions {i}, {j}")
    check(pair_ok,
          f"pairwise commutativity on the tick-1 state: all "
          f"{pair_total} unordered junction pairs commute")
    orders = [tuple(range(N)), tuple(reversed(range(N)))]
    for shift in range(1, N):
        orders.append(tuple((shift + i) % N for i in range(N)))
    rng = random.Random(SHUFFLE_SEED)
    for _ in range(N_SHUFFLES):
        order = list(range(N))
        rng.shuffle(order)
        orders.append(tuple(order))
    check(all(sequential_tick(start, o) == expected for o in orders),
          f"parallel tick == sequential tick on {len(orders)} "
          f"deterministic orders of tick 1 (identity, reverse, "
          f"{N - 1} rotations, {N_SHUFFLES} seeded shuffles)")

    # --- Assignment counts: dual route ---------------------------------
    print("\n--- Step 4: assignment counts at n = 12, two routes ---")
    enum_counts = omega_by_enumeration(N)
    comb_counts = omega_by_comb(N)
    check(enum_counts == comb_counts,
          "Route 1 (literal enumeration of all 2^12 assignments) and "
          "Route 2 (math.comb, (8.1)) agree on every record")
    table = tuple(comb_counts[(k, N - k)] for k in range(N + 1))
    for k in range(N + 1):
        print(f"    record ({k}, {N - k}): Omega = C(12, {k}) = "
              f"{table[k]} (enumeration: {enum_counts[(k, N - k)]})")
    total = sum(table)
    check(table == ORACLE_OMEGA_TABLE,
          "oracle: printed record table C(12, k), k = 0..12 == computed",
          f"printed {ORACLE_OMEGA_TABLE}, computed {table}")
    check(total == ORACLE_TOTAL == 2 ** N,
          f"(8.2) the records' counts sum to 2^12 = {2 ** N}",
          f"computed total: {total}")
    omega_max = max(table)
    check(comb_counts[(6, 6)] == 924 and omega_max == 924,
          "C(12, 6) = 924, and it is the maximum of the full table",
          f"C(12, 6) = {comb_counts[(6, 6)]}, table maximum = {omega_max}")
    balanced_share = Fraction(comb_counts[(6, 6)], total)
    check(balanced_share == ORACLE_BALANCED_SHARE == Fraction(924, 4096),
          "the balanced record's share is 924/4096 = 231/1024 exactly",
          f"computed share: {balanced_share}")
    omega_visited = [comb_counts[r] for r in records]
    print(f"    Omega along the trajectory's records (ticks 0-3): "
          f"{omega_visited}")
    check(all(enum_counts[r] == comb_counts[r] for r in set(records)),
          "Omega of every visited record agrees by both routes",
          f"visited records and Omega: "
          f"{[(r, comb_counts[r]) for r in dict.fromkeys(records)]}")

    # --- (E1)/(E2) verdicts ----------------------------------------------
    print("\n--- Step 5: (E1)/(E2) verdicts, per distinct visited record ---")
    # Flow counts per tick between the phi-classes.
    flows = []
    for ti in range(3):
        before = [feature(s) for s in states[ti]]
        after = [feature(s) for s in states[ti + 1]]
        F = {(x, y): 0 for x in "AB" for y in "AB"}
        for b in range(N):
            F[(before[b], after[b])] += 1
        phi_net = {x: sum(F[(y, x)] for y in "AB")
                   - sum(F[(x, y)] for y in "AB") for x in "AB"}
        flows.append((F, phi_net))
        print(f"    tick {ti + 1}: F_A->A={F[('A', 'A')]}, "
              f"F_A->B={F[('A', 'B')]}, F_B->A={F[('B', 'A')]}, "
              f"F_B->B={F[('B', 'B')]}; Phi_A={phi_net['A']}, "
              f"Phi_B={phi_net['B']}")
    # Confirming tick for the final record (computed; outside the
    # trajectory window, used for no count in §8.7).
    conf_state = parallel_tick(states[-1])
    conf_record = census(conf_state)
    check(conf_state == states[-1] and conf_record == records[-1],
          "the confirming tick leaves the final state and its record "
          "(0, 12) unchanged",
          f"confirming record: {conf_record}")
    # The confirming tick's flow counts, computed explicitly — the
    # final record's (E1)-by-flows route below reads THESE counts,
    # not the record-equality result.
    conf_before = [feature(s) for s in states[-1]]
    conf_after = [feature(s) for s in conf_state]
    conf_F = {(x, y): 0 for x in "AB" for y in "AB"}
    for b in range(N):
        conf_F[(conf_before[b], conf_after[b])] += 1
    conf_net = {x: sum(conf_F[(y, x)] for y in "AB")
                - sum(conf_F[(x, y)] for y in "AB") for x in "AB"}
    print(f"    confirming tick: F_A->A={conf_F[('A', 'A')]}, "
          f"F_A->B={conf_F[('A', 'B')]}, F_B->A={conf_F[('B', 'A')]}, "
          f"F_B->B={conf_F[('B', 'B')]}; Phi_A={conf_net['A']}, "
          f"Phi_B={conf_net['B']}")
    any_equilibrium = False
    for rec in dict.fromkeys(records):
        first = records.index(rec)
        if first < len(records) - 1:
            e1_by_record = records[first + 1] == rec
            e1_by_flows = all(v == 0 for v in flows[first][1].values())
            basis = f"tick {first + 1} leaving it"
        else:
            e1_by_record = conf_record == rec
            e1_by_flows = all(v == 0 for v in conf_net.values())
            basis = "the confirming tick"
        check(e1_by_record == e1_by_flows,
              f"record {rec}: (E1) by record equality == (E1) by "
              f"zero net flows (9.3)")
        e1 = e1_by_record
        e2 = comb_counts[rec] == omega_max
        eq = e1 and e2
        any_equilibrium |= eq
        print(f"    record {rec}: Omega = {comb_counts[rec]}; "
              f"(E1) stationary: {e1} (from {basis}); "
              f"(E2) maximal: {e2}; EQUILIBRIUM: {eq}")
        check((e1, e2, eq) == ORACLE_VERDICTS[rec],
              f"oracle: printed (E1)/(E2)/equilibrium verdicts for "
              f"{rec} == computed",
              f"printed {ORACLE_VERDICTS[rec]}, computed {(e1, e2, eq)}")
    check(not any_equilibrium,
          "no visited record is an equilibrium: the balanced record "
          "(6, 6) satisfies (E2) only, the resting record (0, 12) "
          "satisfies (E1) only, the opening record (12, 0) neither")

    # --- (p, c) decomposition ---------------------------------------------
    print("\n--- Step 6: (p, c) decomposition, by visited-state enumeration ---")
    visited, seq, cur = {}, [], SIGMA0
    while cur not in visited:
        visited[cur] = len(seq)
        seq.append(cur)
        cur = parallel_tick(cur)
    p, c = visited[cur], len(seq) - visited[cur]
    print(f"    (p, c): pre-period p = {p}, cycle length c = {c} "
          f"(cycle state is a fixed point: "
          f"{parallel_tick(seq[p]) == seq[p]})")
    check((p, c) == ORACLE_PC,
          "oracle: printed (p, c) == computed",
          f"printed {ORACLE_PC}, computed {(p, c)}")
    check(c == 1 and parallel_tick(seq[p]) == seq[p]
          and all(parallel_tick(seq[i]) != seq[i] for i in range(p)),
          "(p, c): the trajectory reaches a fixed point and no "
          "earlier state is one")
    check(tuple(seq) == tuple(states[:len(seq)])
          and seq[p] == states[-1],
          "(p, c) enumeration reproduces the tick 0-3 trajectory "
          "up to its resting state")

    # --- Mutant battery -----------------------------------------------------
    print("\n--- Step 7: planted mutants — each must be REJECTED ---")
    # M1: one wrong Omega cell — the oracle cell C(12, 5) = 792
    # replaced by 793, compared against both counting routes.
    mutant_table = list(ORACLE_OMEGA_TABLE)
    mutant_table[5] = 793
    m1_witness = [(k, mutant_table[k], table[k]) for k in range(N + 1)
                  if mutant_table[k] != table[k]]
    check(m1_witness == [(5, 793, 792)],
          "M1 REJECTED: mutant Omega table (C(12, 5) replaced by 793) "
          "disagrees with the computed table",
          f"witness: k=5: mutant 793 != computed C(12, 5) = 792 "
          f"(enumeration {enum_counts[(5, 7)]}, comb "
          f"{comb_counts[(5, 7)]}); the mutant table also sums to "
          f"{sum(mutant_table)} != 4096")
    # M2: one fabricated trajectory step — claiming tick 1's census
    # is (8, 4), a legal record (Omega = 495) that T does not
    # produce from the declared initial state.
    mutant_records = [(12, 0), (8, 4), (0, 12), (0, 12)]
    m2_bad = [(ti, mutant_records[ti], records[ti]) for ti in range(4)
              if mutant_records[ti] != records[ti]]
    check(m2_bad == [(1, (8, 4), (6, 6))],
          "M2 REJECTED: fabricated trajectory (tick 1 claimed as "
          "(8, 4)) disagrees with the recomputed trajectory",
          f"witness: tick 1: claimed (8, 4) != computed "
          f"{records[1]}; T_agg applied to the declared initial "
          f"state, whose census is (12, 0), produces census "
          f"{census(parallel_tick(SIGMA0))}, not (8, 4) — (8, 4) "
          f"is a legal record (Omega = {comb_counts[(8, 4)]}) that "
          f"this trajectory does not visit")

    # --- Verdict --------------------------------------------------------------
    print("\n" + "=" * 72)
    if FAILURES:
        print("A.10 VERDICT: FAIL — witnesses:")
        for f in FAILURES:
            print(f"  - {f}")
        return 1
    print("A.10 VERDICT: PASS — §8.7's two-level exhibit is computed "
          "from its declared")
    print("  population: trajectory (12, 0) -> (6, 6) -> (0, 12) -> "
          "(0, 12), tau_agg")
    print("  36 -> 12 -> 0 -> 0 with Delta tau_agg = -2 x acting "
          "(12, 6, 0); Omega by")
    print("  enumeration and by (8.1) agree on the full table "
          "(total 4096, maximum")
    print("  924 at (6, 6), share 231/1024); no visited record is an "
          "equilibrium —")
    print("  (6, 6) satisfies (E2) only, (0, 12) (E1) only, (12, 0) "
          "neither; (p, c) =")
    print("  (2, 1); both planted mutants rejected with witnesses.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
