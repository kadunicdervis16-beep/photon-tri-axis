#!/usr/bin/env python3
"""A.11 — Mode exhibit: the full-swing re-presentation cycle (Paper 12 §10.4).

WHAT THIS SCRIPT VERIFIES. Section 10.4 exhibits one positive instance
of a collective mode in this paper's native sense: a population-level
periodic feature of an aggregate trajectory with an exact period, an
amplitude, and an exact rational visit frequency. The exhibit is an
ENLARGED TRANSITION in the sense of §10.1's clarification — a declared
re-presentation rule folded into the transition, an A.3-style control
result — and NOT a trajectory under T_agg alone. This script checks
the exhibit's arithmetic and, as a control, the contrasting frozen
behaviour under T_agg alone, so the two transitions are never
confused.

THE DECLARED EXHIBIT (control data, declared here and in §10.4):
  - Population: m = 4 named bodies (b0, b1, b2, b3). The state of the
    exhibit is the per-body feature assignment itself: a tuple of
    L/R standings, one per body, in body order. A standing is ledger
    data — a census-side record in the licence of Definition 5.1,
    which admits any class of population members defined by ledger
    data alone (for a body, a feature of its junction local state).
  - Junctions and the feature: each body carries exactly one
    pairwise junction of port-vector length 2, a local state sigma = (A, B) as in §8.7.
    Two junction states are declared, the exhibit's REST STATES:
    SIGMA_L = ((+1, 0), (0, 0)) and SIGMA_R = ((-1, 0), (0, 0)).
    The feature is psi(sigma) = L iff A presents a +1 at some
    index, R otherwise — total, as §8.7's phi is total;
    psi(SIGMA_L) = L and psi(SIGMA_R) = R. In neither rest state
    is any index admissible (admissibility at k needs
    A[k] = -B[k] != 0, and B is the zero vector in both), so each
    is a fixed point of T — a fact this script COMPUTES by
    applying T (below, copied from A.2), not one it takes from
    the declaration.
  - Declared re-presentation rule rho (the enlarged transition): at
    each tick, every body's feature standing is re-presented flipped,
    L <-> R. Rho is a DECLARED RULE. It is not T and it is not T_agg,
    and nothing in this script writes it as either.
  - Declared start: the fully L assignment (L, L, L, L).
  - Census of an assignment: (number of bodies standing in L,
    number standing in R).

WHAT IS COMPUTED (never restated as its own input):
  - The orbit of the declared start under rho, by iteration.
  - The (pre-period p, cycle length c) decomposition of that orbit
    by TWO independent routes, in A.3's idiom, which must agree:
      ROUTE 1 (brute force): per-start trajectory iteration with a
        visited-index map; the first repeated state gives (p, c).
      ROUTE 2 (functional-graph decomposition): global indegree
        peeling isolates the cycle nodes, cycles are walked and
        measured, transient depths come from a reverse-adjacency
        breadth-first search. No per-start iteration is used.
  - The same dual-route decomposition for EVERY one of the
    2^4 = 16 assignments (the global check).
  - The census sequence along the start orbit; the amplitude,
    DEFINED here as the census swing of the L-class count over the
    cycle: (maximal L-count over the cycle) - (minimal L-count over
    the cycle).
  - Visit frequencies as exact Fractions over windows of whole
    periods taken after the pre-period: per cycle record, and per
    body for the L standing (the Proposition 5.3(ii)/(iii) form —
    a ratio of actual counts over an actual window).
  - The frozen control: under T_agg alone (no re-presentation),
    A.2's operator T is applied to each body's declared junction
    state and the standing is re-read by psi; both rest states
    are fixed points of T, so the induced transition on standings
    is the identity — computed from T here, not stipulated — and
    the same start is frozen at census (4, 0) with decomposition
    (0, 1), over the same 16 assignments.

CHECKS (all exact; frequencies are Fractions, never floats):
  - rho is implemented exactly as declared: for every one of the 16
    assignments, rho flips every body's standing; rho is an
    involution (rho(rho(s)) = s) and has no fixed point;
  - the orbit from the declared start is
    (L,L,L,L) -> (R,R,R,R) -> (L,L,L,L), with census sequence
    (4, 0) -> (0, 4) -> (4, 0);
  - the decomposition of the start orbit is (p, c) = (0, 2) by
    Route 1 and by Route 2 independently;
  - the census values alternate (4, 0), (0, 4) over the cycle;
  - amplitude = 4 by the stated definition (4 - 0);
  - each cycle record's visit frequency over windows of whole
    periods is Fraction(1, 2) = 1/c with c = 2; each body stands
    in L with frequency Fraction(1, 2) over the same windows;
    records off the cycle have frequency 0 (there are none on this
    orbit beyond the cycle, since p = 0 — checked, not assumed);
  - GLOBAL: every one of the 16 assignments has decomposition
    (0, 2) under rho, by both routes;
  - CONTROL: T(SIGMA_L) = SIGMA_L and T(SIGMA_R) = SIGMA_R,
    computed by T itself; psi is total on all 81 local states
    at port-vector length 2 and takes the declared values on the two rest states;
    under T_agg alone (T applied to each body's declared junction
    state, standings re-read by psi) every assignment has
    decomposition (0, 1), and the declared start's census is
    constantly (4, 0) — the population is frozen, c = 1, exactly
    as §10.1's clarification requires of a closed trajectory
    under T_agg alone.

ORACLE DISCIPLINE: the declared exhibit's printed values (the orbit,
(0, 2), the alternating census values, amplitude 4, frequency 1/2)
enter this script ONLY as the oracle under test, in the ORACLE block
below. Every value the verdict rests on is computed here from the
declared population and the declared rule. If a printed value
disagrees with the computation, this script FAILS and prints the
discrepancy; it does not adjust the computation to fit the print.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: §10.4's exhibit — one declared population of
      4 bodies under one declared re-presentation rule — together
      with §10.1's clarification (enlarged transitions with c > 1;
      closed trajectories under T_agg alone with c = 1) and the
      frequency form of L10.2-P12 / Proposition 5.3(ii)-(iii).
  (2) Verified domain: the exhibit's full state set — all
      2^4 = 16 feature assignments — under rho and under the
      identity (T_agg-alone) transition, in full, by two
      independent decomposition routes.
  (3) Map: per-body feature assignment (a tuple of L/R standings)
      -> state of the finite transition system; one enlarged tick
      -> rho (flip every standing); one T_agg-alone tick -> A.2's
      operator T applied to each body's declared junction state,
      the standing re-read by psi (both rest states are fixed
      points of T, so the induced transition on standings is the
      identity — computed, not assumed).
  (4) Preserved: determinism, totality, finiteness — the only
      properties the (p, c) decomposition and the 1/c frequency
      argument consume — plus the exact census counts, the exact
      amplitude under its stated definition, and the exact
      rational frequencies over windows of whole periods.
  (5) Outside the machine check: L10.3-P12's completeness scope is
      NOT extended by this exhibit — the exhibit is an enlarged
      transition (a declared re-presentation), a control result in
      §10.1's sense, standing outside that claim exactly as §10.1
      provides; what "mode" means natively (the LEVEL B reading of
      L10.6-P12) is a definition, not a computation, and is outside
      the machine check; Port-Partition Exactness (the junctions'
      disjoint port sets) is cited from Paper 11 §4.3, as in A.2,
      and Theorem 4.2's well-definedness of the parallel tick is
      A.2's verified domain — this script applies A.2's operator
      to the declared junction states and checks the consequence
      for this exhibit's standings, which is the level the
      exhibit's state lives at.

INPUT_PROVENANCE:
  - The declared population (m = 4 named bodies b0..b3), the binary
    L/R feature standings, the declared start (L, L, L, L), and the
    re-presentation rule rho (flip every standing at each tick):
    class=control (the §10.4 exhibit's declared data — a declared
    toy population and a declared rule, in A.3's control idiom;
    rho is not a framework rule and is never presented as T or
    T_agg). Transcribed into §10.4's text at integration; the
    coordinator verifies the transcription.
  - The printed exhibit values (orbit, (p, c) = (0, 2), census
    values (4, 0) and (0, 4), amplitude 4, frequency 1/2):
    class=control (the ORACLE UNDER TEST — the prediction printed
    in §10.4, transcribed below; never used in any computation).
    Transcribed into §10.4's text at integration; the coordinator
    verifies the transcription.
  - The amplitude definition (maximal minus minimal L-class count
    over the cycle): class=declared-assumption (the exhibit's own
    stated definition of its amplitude, declared in §10.4 and
    here; the computation applies exactly this definition).
  - The (p, c) decomposition and the 1/c per-record frequency form,
    and Proposition 5.3(ii)-(iii)'s census-ratio form c_X / ell:
    class=paper-defined (Paper 12 §10.1-§10.2, §5) — the claims
    under test, computed against below, never used as inputs.
  - The two rest states SIGMA_L = ((+1, 0), (0, 0)) and
    SIGMA_R = ((-1, 0), (0, 0)) and the feature psi (L iff A
    presents a +1 at some index): class=control (the §10.4
    exhibit's declared junction data and declared feature,
    stated in §10.4 and here; that the rest states are fixed
    points of T is COMPUTED below, not declared).
  - T's definition (admissibility A[k] = -B[k] != 0; zero the
    canonically first admissible pair; fixed point if none):
    class=cited-paper (Paper 11 §7.5, as restated in Paper 12
    §4; the implementation below is copied from
    A2_parallel_tick.py, conventions unchanged).
  - The frozen-under-T_agg-alone fact (closed trajectories under
    T_agg have c = 1, by tau-monotonicity): class=paper-defined
    (Paper 12 §10.1 clarification, Proposition 4.3) — its
    instance here is computed from T on the declared junction
    states, as above.
"""
import sys
from collections import Counter, deque
from fractions import Fraction
from itertools import product


# ------------------------------------------------------ declared exhibit
# CONTROL DATA (see INPUT_PROVENANCE): the declared population, the
# declared rule's data, and the declared start. The rule itself is
# implemented in rho() below, from the declaration, not from the
# oracle.
BODIES = ("b0", "b1", "b2", "b3")
M = len(BODIES)
CLASSES = ("L", "R")
START = ("L", "L", "L", "L")

# Each body carries exactly one pairwise junction of port-vector length 2; its local state is
# one of the two declared REST STATES (sigma = (A, B), §8.7's form).
# A body's standing is the feature psi of its junction state.
SIGMA_L = ((1, 0), (0, 0))
SIGMA_R = ((-1, 0), (0, 0))
REST_STATES = {"L": SIGMA_L, "R": SIGMA_R}

# ------------------------------------------------------ oracle under test
# Transcribed printed values of the §10.4 exhibit (see
# INPUT_PROVENANCE). These literals are the PREDICTION. No
# computation below reads them except the comparisons.
ORACLE_ORBIT = (("L", "L", "L", "L"), ("R", "R", "R", "R"),
                ("L", "L", "L", "L"))
ORACLE_PC = (0, 2)
ORACLE_CENSUS_CYCLE = ((4, 0), (0, 4))
ORACLE_AMPLITUDE = 4
ORACLE_FREQUENCY = Fraction(1, 2)
ORACLE_GLOBAL_PC = (0, 2)          # every assignment, under rho
ORACLE_CONTROL_PC = (0, 1)         # every assignment, T_agg alone
ORACLE_CONTROL_CENSUS = (4, 0)     # the start's constant census


# ------------------------------------------------------------------- rules

def admissible_indices(sigma):
    """Paper 11 §7.5, via Paper 12 §4 (copied from
    A2_parallel_tick.py): index k is admissible iff
    A[k] = -B[k] != 0."""
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def T(sigma):
    """Paper 11's junction operator, copied from A2_parallel_tick.py,
    conventions unchanged: zero the canonically first admissible
    pair; the identity if none is admissible (a fixed point)."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[0]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


def psi(sigma):
    """The declared feature (§10.4): L iff A presents a +1 at some
    index, R otherwise. Total: at every sigma the condition either
    holds or it does not."""
    A, _B = sigma
    return "L" if any(a == 1 for a in A) else "R"


def rho(state):
    """The DECLARED re-presentation rule (the enlarged transition):
    flip every body's standing, L <-> R. A declared rule — not T,
    not T_agg."""
    return tuple("R" if s == "L" else "L" for s in state)


def t_agg_alone(state):
    """CONTROL transition: T_agg alone, COMPUTED — A.2's operator T
    applied to each body's declared junction state, the standing
    re-read by psi. Both rest states are fixed points of T
    (checked in Step 0), so the induced transition on standings
    is the identity — as a computation, not a stipulation."""
    return tuple(psi(T(REST_STATES[s])) for s in state)


def census(state):
    """Census of an assignment: (count standing in L, count in R)."""
    return (state.count("L"), state.count("R"))


def all_assignments():
    return list(product(CLASSES, repeat=M))


def transition_table(fn):
    return {s: fn(s) for s in all_assignments()}


# ------------------------------------------------------- decomposition routes
# A.3's idiom, verbatim in structure: two independent routes.

def decompose_bruteforce(trans, start):
    """ROUTE 1: iterate from start; first repeated state gives
    (p, c) and the cycle as an ordered list."""
    seen = {}
    path = []
    s = start
    while s not in seen:
        seen[s] = len(path)
        path.append(s)
        s = trans[s]
    p = seen[s]
    cycle = path[p:]
    return p, len(cycle), cycle


def decompose_global(trans):
    """ROUTE 2: functional-graph decomposition without per-start
    iteration. Indegree peeling isolates cycle nodes; cycles are
    walked and measured; depths come from a reverse-adjacency BFS.
    Returns {state: (p, c)}."""
    indeg = {s: 0 for s in trans}
    radj = {s: [] for s in trans}
    for s, nxt in trans.items():
        indeg[nxt] += 1
        radj[nxt].append(s)
    queue = deque([s for s in trans if indeg[s] == 0])
    on_cycle = {s: True for s in trans}
    while queue:
        s = queue.popleft()
        on_cycle[s] = False
        nxt = trans[s]
        indeg[nxt] -= 1
        if indeg[nxt] == 0:
            queue.append(nxt)
    cycle_len = {}
    seen_cycle = set()
    for s in trans:
        if on_cycle[s] and s not in seen_cycle:
            cur, members = s, []
            while cur not in seen_cycle:
                seen_cycle.add(cur)
                members.append(cur)
                cur = trans[cur]
            for m_ in members:
                cycle_len[m_] = len(members)
    depth = {s: 0 for s in trans if on_cycle[s]}
    queue = deque(depth.keys())
    while queue:
        s = queue.popleft()
        for pre in radj[s]:
            if pre not in depth:
                depth[pre] = depth[s] + 1
                queue.append(pre)
    result = {}
    for s in trans:
        cur = s
        while not on_cycle[cur]:
            cur = trans[cur]
        result[s] = (depth[s], cycle_len[cur])
    return result


# --------------------------------------------------------------------- main

def main():
    print("=" * 70)
    print("A.11 — MODE EXHIBIT: THE FULL-SWING RE-PRESENTATION CYCLE")
    print("  (Paper 12 §10.4 — an enlarged transition, §10.1's sense;")
    print("   a control result, NOT a trajectory under T_agg alone)")
    print("=" * 70)
    all_ok = True

    rho_tab = transition_table(rho)
    id_tab = transition_table(t_agg_alone)
    states = all_assignments()

    print(f"\n--- Step 0: the declared rest states, against T "
          f"itself ---")
    step_ok = True
    for name, sig in (("SIGMA_L", SIGMA_L), ("SIGMA_R", SIGMA_R)):
        if admissible_indices(sig):
            print(f"  REST FAIL: {name} = {sig} presents admissible "
                  f"indices {admissible_indices(sig)} — not a rest "
                  f"state")
            step_ok = False
        if T(sig) != sig:
            print(f"  REST FAIL: T({name}) = {T(sig)} != {name} = "
                  f"{sig} — the declared rest state is not a fixed "
                  f"point of T")
            step_ok = False
    if psi(SIGMA_L) != "L" or psi(SIGMA_R) != "R":
        print(f"  FEATURE FAIL: psi(SIGMA_L) = {psi(SIGMA_L)}, "
              f"psi(SIGMA_R) = {psi(SIGMA_R)} — the declared "
              f"feature does not take its declared values on the "
              f"rest states")
        step_ok = False
    n_psi = 0
    for flat in product((-1, 0, 1), repeat=4):
        sig = (flat[:2], flat[2:])
        if psi(sig) not in CLASSES:
            print(f"  FEATURE TOTALITY FAIL at {sig}: psi = "
                  f"{psi(sig)}")
            step_ok = False
        n_psi += 1
    print(f"  T fixes both declared rest states (neither presents "
          f"an admissible index); psi(SIGMA_L) = L, "
          f"psi(SIGMA_R) = R; psi total on all {n_psi} local "
          f"states at port-vector length 2 [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print(f"\n--- Step 1: the declared rule, implemented exactly ---")
    step_ok = True
    for s in states:
        expect = tuple("R" if x == "L" else "L" for x in s)
        if rho(s) != expect:
            print(f"  RULE FAIL at {s}: rho gives {rho(s)}, "
                  f"declared flip gives {expect}")
            step_ok = False
        if rho(rho(s)) != s:
            print(f"  INVOLUTION FAIL at {s}: rho(rho(s)) = "
                  f"{rho(rho(s))} != {s}")
            step_ok = False
        if rho(s) == s:
            print(f"  FIXED POINT FAIL: rho fixes {s}; the declared "
                  f"flip of a binary standing has no fixed assignment")
            step_ok = False
    print(f"  rho flips every standing on all {len(states)} "
          f"assignments; rho is an involution with no fixed point "
          f"[{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 2: the orbit from the declared start ---")
    orbit = [START]
    for _ in range(2):
        orbit.append(rho(orbit[-1]))
    orbit_t = tuple(orbit)
    cens = tuple(census(s) for s in orbit)
    step_ok = (orbit_t == ORACLE_ORBIT
               and cens[:2] == ORACLE_CENSUS_CYCLE
               and cens[2] == ORACLE_CENSUS_CYCLE[0])
    if orbit_t != ORACLE_ORBIT:
        print(f"  ORBIT DISCREPANCY: computed {orbit_t} != printed "
              f"{ORACLE_ORBIT}")
    print(f"  start {START} -> rho -> {orbit[1]} -> rho -> "
          f"{orbit[2]}; census {cens[0]} -> {cens[1]} -> {cens[2]} "
          f"[{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 3: (p, c) of the start orbit, two routes ---")
    p1, c1, cycle = decompose_bruteforce(rho_tab, START)
    glob_rho = decompose_global(rho_tab)
    p2, c2 = glob_rho[START]
    step_ok = ((p1, c1) == (p2, c2) == ORACLE_PC)
    if (p1, c1) != (p2, c2):
        print(f"  ROUTE DISAGREEMENT: brute force ({p1}, {c1}) vs "
              f"global ({p2}, {c2})")
    if (p1, c1) != ORACLE_PC:
        print(f"  DECOMPOSITION DISCREPANCY: computed ({p1}, {c1}) "
              f"!= printed {ORACLE_PC}")
    print(f"  Route 1 (brute force): (p, c) = ({p1}, {c1}); "
          f"Route 2 (functional graph): (p, c) = ({p2}, {c2}); "
          f"cycle = {cycle} [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 4: alternating census and amplitude ---")
    cycle_census = [census(s) for s in cycle]
    alternating = (len(cycle_census) == 2
                   and cycle_census[0] != cycle_census[1]
                   and tuple(cycle_census) == ORACLE_CENSUS_CYCLE)
    l_counts = [cc[0] for cc in cycle_census]
    amplitude = max(l_counts) - min(l_counts)   # the stated definition
    step_ok = alternating and amplitude == ORACLE_AMPLITUDE
    if not alternating:
        print(f"  ALTERNATION FAIL: cycle census {cycle_census} != "
              f"printed {ORACLE_CENSUS_CYCLE}")
    if amplitude != ORACLE_AMPLITUDE:
        print(f"  AMPLITUDE DISCREPANCY: computed max-min = "
              f"{max(l_counts)} - {min(l_counts)} = {amplitude} "
              f"!= printed {ORACLE_AMPLITUDE}")
    print(f"  cycle census values {cycle_census} alternate; "
          f"L-counts over the cycle {l_counts}; amplitude = "
          f"max - min = {max(l_counts)} - {min(l_counts)} = "
          f"{amplitude} [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 5: visit frequencies over whole periods "
          "(exact Fractions) ---")
    step_ok = True
    K = 5  # whole periods after the pre-period
    traj = [START]
    for _ in range(p1 + K * c1):
        traj.append(rho(traj[-1]))
    window = traj[p1:p1 + K * c1]
    counts = Counter(window)
    cycset = set(cycle)
    for x in states:
        observed = Fraction(counts.get(x, 0), len(window))
        predicted = Fraction(1, c1) if x in cycset else Fraction(0)
        if observed != predicted:
            print(f"  FREQUENCY MISMATCH: record {x}: window census "
                  f"ratio {observed} != predicted {predicted}")
            step_ok = False
    # Per-body L-standing frequency over the same window, and the
    # Proposition 5.3 class form for the L class as a whole.
    for i, b in enumerate(BODIES):
        f = Fraction(sum(1 for s in window if s[i] == "L"),
                     len(window))
        if f != ORACLE_FREQUENCY:
            print(f"  BODY FREQUENCY MISMATCH: {b} stands in L with "
                  f"frequency {f} != printed {ORACLE_FREQUENCY}")
            step_ok = False
    rec_freq = Fraction(counts.get(cycle[0], 0), len(window))
    if rec_freq != ORACLE_FREQUENCY or Fraction(1, c1) != ORACLE_FREQUENCY:
        print(f"  1/c FORM FAIL: 1/c = {Fraction(1, c1)}, window "
              f"ratio = {rec_freq}, printed = {ORACLE_FREQUENCY}")
        step_ok = False
    print(f"  window of K = {K} whole periods ({len(window)} ticks) "
          f"after p = {p1}: each cycle record visited with frequency "
          f"{rec_freq} = 1/c (c = {c1}); each body stands in L with "
          f"frequency {ORACLE_FREQUENCY}; off-cycle records: "
          f"frequency 0 (none occur — p = 0, checked over all "
          f"{len(states)} records) [{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 6: GLOBAL check — all 16 assignments under "
          "rho ---")
    step_ok = True
    for s in states:
        pa, ca, _ = decompose_bruteforce(rho_tab, s)
        pb, cb = glob_rho[s]
        if (pa, ca) != (pb, cb):
            print(f"  ROUTE DISAGREEMENT at {s}: brute force "
                  f"({pa}, {ca}) vs global ({pb}, {cb})")
            step_ok = False
        if (pa, ca) != ORACLE_GLOBAL_PC:
            print(f"  GLOBAL DISCREPANCY at {s}: computed "
                  f"({pa}, {ca}) != printed {ORACLE_GLOBAL_PC}")
            step_ok = False
    print(f"  all {len(states)} assignments: decomposition "
          f"{ORACLE_GLOBAL_PC} under rho, by both routes "
          f"[{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- Step 7: CONTROL — the same standings under T_agg "
          "alone ---")
    step_ok = True
    glob_id = decompose_global(id_tab)
    for s in states:
        pa, ca, _ = decompose_bruteforce(id_tab, s)
        pb, cb = glob_id[s]
        if (pa, ca) != (pb, cb) or (pa, ca) != ORACLE_CONTROL_PC:
            print(f"  CONTROL FAIL at {s}: brute force ({pa}, {ca}), "
                  f"global ({pb}, {cb}), expected "
                  f"{ORACLE_CONTROL_PC}")
            step_ok = False
    frozen = [START]
    for _ in range(4):
        frozen.append(t_agg_alone(frozen[-1]))
    frozen_census = [census(s) for s in frozen]
    if any(cc != ORACLE_CONTROL_CENSUS for cc in frozen_census):
        print(f"  CONTROL CENSUS FAIL: {frozen_census} — the start "
              f"is not frozen at {ORACLE_CONTROL_CENSUS}")
        step_ok = False
    print(f"  under T_agg alone (computed: T on the declared "
          f"junction states, standings re-read by psi): all "
          f"{len(states)} assignments have decomposition "
          f"{ORACLE_CONTROL_PC}; the declared start's census is "
          f"constantly {frozen_census[0]} over 5 ticks — frozen, "
          f"c = 1. The oscillation above is the declared "
          f"re-presentation's, not T_agg's "
          f"[{'OK' if step_ok else 'FAIL'}]")
    all_ok &= step_ok

    print("\n--- PLANTED MUTANTS ---")
    mutants_ok = True
    # M1: period mis-stated as 3. A genuine spec violation: the
    # exhibit's period is the computed cycle length; restating it
    # as 3 must be REJECTED against the computation.
    mutant_period = 3
    if mutant_period != c1:
        print(f"  [REJECTED] M1: period mis-stated as "
              f"{mutant_period}. witness: computed cycle length "
              f"c = {c1} (both routes, all {len(states)} "
              f"assignments); {mutant_period} != {c1}, and rho^"
              f"{mutant_period}(start) = "
              f"{rho(rho(rho(START)))} != start {START}, so no "
              f"period-{mutant_period} return occurs.")
    else:
        print("  [NOT REJECTED — INVESTIGATE] M1: mis-stated period "
              "3 matched the computed cycle length.")
        mutants_ok = False
    # M2: amplitude halved (2 in place of 4). A genuine spec
    # violation of the stated amplitude definition.
    mutant_amplitude = ORACLE_AMPLITUDE // 2
    if mutant_amplitude != amplitude:
        print(f"  [REJECTED] M2: amplitude halved to "
              f"{mutant_amplitude}. witness: computed amplitude = "
              f"max L-count - min L-count over the cycle = "
              f"{max(l_counts)} - {min(l_counts)} = {amplitude}; "
              f"{mutant_amplitude} != {amplitude} — the halved "
              f"value is the swing of a 2-body population, not of "
              f"this declared 4-body exhibit.")
    else:
        print("  [NOT REJECTED — INVESTIGATE] M2: halved amplitude "
              "matched the computed amplitude.")
        mutants_ok = False

    print("\n" + "=" * 70)
    if all_ok and mutants_ok:
        print("A.11 VERDICT: PASS — the §10.4 exhibit computes exactly")
        print("  as printed: rho flips every standing on all 16")
        print("  assignments; the start orbit is (4, 0) -> (0, 4) ->")
        print("  (4, 0) with (p, c) = (0, 2) by two independent routes;")
        print("  amplitude 4 by its stated definition; per-record and")
        print("  per-body visit frequency Fraction(1, 2) = 1/c over")
        print("  whole periods; every assignment has (0, 2) under rho;")
        print("  and the T_agg-alone control is frozen at (0, 1) — the")
        print("  oscillation is the declared re-presentation's, an")
        print("  enlarged-transition control result in §10.1's sense.")
        return 0
    print("A.11 VERDICT: FAIL — see witness lines above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
