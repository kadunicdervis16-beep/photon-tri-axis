#!/usr/bin/env python3
"""A.12 — Joint counts: identity-resolved frequencies (Paper 12 §5,
v4 extension).

Machine companion to the v4 extension of Paper 12 §5. GS-1's attack
G8 (GS1_BATTERY_REPORT.md §G8, badge GS-BROKE) exhibited a frequency
question inside the framework's own scope that no census or flow
count of Definitions 5.1-5.2 expresses: the named-pair joint
frequency Q7b. Its witness is a pair of populations — Appendix D's
population and the same declaration with the sigma_0 assignments of
named bodies B1 and B2 exchanged — whose finest census sequences
and finest flow tables are identical, while Q7b's answer differs
(1/4 against 0). The v4 repair extends §5's instruments with the
joint count built here. The v4 loop pass (devil's advocate and
red team) then found that the first form of this script covered
only bodies, one junction each, while Definition 5.8 as
generalized in the same pass runs over named members of either
kind, bodies with any number of junctions, and entries carrying
tick offsets; its red-team witness Q_J' (a junction swap inside
one body, below) separates junction-member joint counts from
every body-tuple joint count. This script verifies the
generalized instrument: its definitions, its bookkeeping
identities, the recomputed G8 witness, the Q_J' witness, and the
failure of the planted mutants M1, M2, M3 and M5, together with
the (C, F)-only meta-check (not a planted mutant). It is the
suite's twelfth script in run order.

THE INSTRUMENT (v4 §5, Definitions 5.7-5.8 generalized). A
member is a named body or a named junction. A body is a LIST of
junction local states sigma = (A, B), with A, B length-2 vectors
over {-1, 0, +1} (junctions of port-vector length 2 throughout
this script's machine domain). The STANDING of a junction member at a tick is
the standing of its own sigma, read from that sigma alone:

  positive iff there exists k with A[k] = +1 and B[k] = -1;
  negative iff no such k exists, but there exists k with
    A[k] = -1 and B[k] = +1;
  neutral  iff no opposed pair of either orientation exists
    (for every k, neither of the two patterns above occurs).

The STANDING of a body member at a tick aggregates over its
junctions with the same precedence (Definition 5.7's body case):
positive iff any of its junctions presents a (+1, -1) opposed
pair within its own sigma; else negative iff any presents the
mirror pair (-1, +1) and none presents (+1, -1); else neutral.
An opposed pair is always read inside one junction's sigma —
pairs are NEVER pooled across a body's junctions. A body with
no junctions is neutral. The three standings are written +, -, 0
in this script's tables. Standing is total: every member stands
in exactly one class at every tick, and where both orientations
occur (necessarily at distinct indices, possibly in distinct
junctions of one body) the positive clause takes precedence, by
the definition's own order. In code a member is written
('body', i) for the i-th body of a population or
('junction', i, j) for the j-th junction of the i-th body, and
a joint-count spec is a (member, class) pair, optionally with a
tick offset: (member, class, delta). The JOINT COUNT of a tuple
of such specs over a declared window W is

  J_W((m_1, X_1, d_1), ..., (m_k, X_k, d_k)) =
    |{ tau in W : named member m_r stands in class X_r at
        tau + d_r, for all r }|,

written without the offsets when every d_r is 0, and the joint
frequency is J_W / |W|, an exact rational. A member may be named
more than once in a tuple (the same-body lagged case of check
(10) is one such). The dynamics are Paper 11's operator T
exactly as Paper 12 §4 states it, applied per junction — the T
implementation below is copied from A7_exhibit.py (itself copied
from A2_parallel_tick.py), conventions unchanged:

  T: index k is ADMISSIBLE iff A[k] = -B[k] != 0; T zeroes the
  CANONICALLY FIRST admissible pair; if none, T is the identity.

THE FEATURE phi (§8.7, a feature of sigma in the licence of
Definition 5.1): phi(sigma) is class A iff sigma presents an
opposed unit pair A[k] = +1, B[k] = -1 at some index; otherwise
class B. Check (2) verifies that phi is exactly the merging of
the standings that forgets the negative/neutral distinction —
which is what makes the standing-derived and phi-derived routes
to Q7b two computations of one answer in check (4).

DATA (self-contained). This script runs in a bare layout with
only the paper, scripts/ and sources/ beside it; it reads NO
file at run time — in particular it does not read the battery/
tree. Its declared dynamics data are embedded below: the two
G8 witness populations (Appendix D's population, bodies B1..B12
with one pairwise junction of port-vector length 2 each, sigma_0 as in A.7's SIGMA0, and
its B1<->B2 name-swap, constructed by exchanging the first two
entries of the same table); the two Q_J' witness populations of
check (9) (body P with two named junctions J_a, J_b and body Q
with one named junction J_c, in the junction assignments alpha
and beta stated there); and the pooled-reading counterexample
body of check (8). BUILD-TIME CROSS-CHECK (2026-10-26, stated
here, not re-run at run time): the embedded sigma_0 table was
compared entry by entry against the planted G8 witness file,
Appendix E's Exhibit 7, battery/G8_witnesses.json (the staging
copy lives at staging_v7/battery/G8_witnesses.json) — its entry
Q7b.population_1 (id "AppendixD") carries a sigma0 equal to
A.7's SIGMA0 exactly (all 12 bodies, both port vectors), and
its entry Q7b.population_2 (id "AppendixD_swap_names_0_1")
equals the same table with entries #0 and #1 exchanged, under
the same names B1..B12. The table below is that verified table.

CHECKS (each printed PASS/FAIL with witnesses on failure; exit 0
iff all pass; shares and frequencies are Fractions, never floats):
  (1) Standing totality: over all 81 sigma states, exactly one
      standing each; the three standings' counts over the 81
      states are printed; states presenting both orientations
      are positive (the definition's precedence), computed.
  (2) phi refinement: over all 81 states, phi(sigma) = A iff
      standing is positive; phi(sigma) = B iff standing is
      negative or neutral.
  (3) The break's premise, recomputed: the two G8 witness
      populations' finest census sequences (t = 0..4, over all
      81 sigma classes, junctions counted) and finest flow
      tables (t = 0..3) are identical.
  (4) The repair: the full 3x3 joint standing tables J_W for
      (B1, B2), W = [0, 4), for both populations (printed);
      Q7b's answers (J[+][-] + J[+][0]) / 4 equal 1/4
      (population 1) and 0 (population 2); direct phi-class
      joint counts, tallied from sigma without standing, agree
      with the standing-derived answers; the tables also agree
      cell by cell with the generic member joint-count route.
  (5) Marginalization: on both witness populations and on the
      seeded generated populations (uniform and structured
      families; seeds printed; n in 2..6, windows of lengths
      1-6): for every ordered pair of distinct named bodies and
      every class X of the first body, the sum over the second
      body's three standings of J equals the first body's own
      per-window count in X (the k = 1 joint count); the sum
      over both bodies' classes equals |W|; and the pair counts
      marginalize to the k = 1 joint counts of both bodies.
  (6) Window additivity: for every split of every tested window
      into two consecutive parts, J over the union equals the
      sum of J over the parts, componentwise (all 9 cells), on
      witness and generated populations.
  (7) Tuple case k = 3: on generated populations, the 3x3x3
      joint table marginalizes over the third body to the pair
      table, and over two bodies to the single counts.
  (8) Multi-junction bodies: the body standing (aggregate over
      a body's junctions, Definition 5.7's body case) agrees,
      on every 1-junction body (all 81), every 2-junction body
      (all 81 x 81 ordered pairs, exhaustively) and a seeded
      sample of 3-junction bodies, across three routes — the
      direct opposed-pair scan, the aggregation of the
      junctions' own standings, and the orientation-set read;
      the empty body is neutral; and the pooled-reading
      counterexample: the body with J_a sigma = ((1, 0),
      (0, 0)) and J_b sigma = ((0, 0), (-1, 0)) is NEUTRAL (no
      junction of it presents an opposed pair, and T acts
      nowhere on it), while the pooled reading — one sigma
      formed by summing the two junctions' sides — stands
      positive, and is rejected.
  (9) Junction-member joints, and the Q_J' witness: joint
      counts over tuples mixing named bodies and named
      junctions, by the generic member route. The witness:
      body P carrying two named junctions J_a, J_b and body Q
      carrying one named junction J_c, W = [0, 1); alpha:
      J_a = s+, J_b = s-, J_c = s+; beta: J_a = s-, J_b = s+,
      J_c = s+, where s+ = ((1, 0), (-1, 0)) and
      s- = ((0, -1), (0, 1)). Computed and verified: the
      finest junction census sequences and junction flow
      tables of alpha and beta agree; every body class of P
      and of Q agrees (node count, junction arity multiset, B, the
      Sigma-s-squared total, the presented-count profile, the
      junction-sigma multiset — P's class at t = 0 carries
      B = 14 and presented profile (2, 2)); P's and Q's body
      standings agree at every tick (positive at t = 0); and
      every body-tuple joint count (tuples of length 1-3 over
      W, and pairs over [0, 4)) agrees across alpha/beta —
      while Q_J', the fraction of W at which J_a stands
      positive while body Q stands positive, computed by the
      member joint-count route (and by a direct raw tally),
      is 1 on alpha and 0 on beta.
  (10) Tick offsets: joint counts whose entries carry an
      offset delta. On the generated family, the lagged pair
      tables with delta = (0, 1) — the second member read at
      tau + 1 — agree cell by cell with a brute-force recount
      from the raw trajectories; they marginalize over the
      second member's standings to the first member's own
      (offset-0) count, and over the first member's standings
      to the second member's count over the shifted window;
      and they add over window splits with the offsets held
      fixed. The same-body lagged case (i, i) with
      delta = (0, 1) is included and its instance count is
      printed.
  (11) Conditional ratios (Proposition 5.9(iv)): on the G8
      witness populations, P(B1 = + | B2 = +) =
      J((+, +)) / marginal(B2 = +) over W = [0, 4) equals
      1/1 = 1 (population 1) and 1/2 (population 2), computed
      from the joint tables; and on the generated family, for
      every ordered pair, window and class pair whose
      marginal is nonzero, the conditional ratio computed
      from the pair table and the k = 1 counts equals the
      ratio computed by a direct raw-trajectory tally
      (instances counted and printed).
  (12) PLANTED MUTANTS, each REJECTED with a printed witness,
      and one META-CHECK: M1, the identity-blind product
      estimator; M2, the honest unordered-pair count (for the
      unordered pair {+, -} it returns J(+,-) + J(-,+) as the
      answer to BOTH oriented questions); M3, binarized
      standings {positive, not-positive}; M5, the window-shift
      tally (the joint count taken over (t0 + 1, t1 + 1] in
      place of [t0, t1)). The META-CHECK (the former M4 label;
      not a planted mutant): any purported joint frequency computed as a
      function of the (C, F) data alone — G8's argument,
      computed in checks (3) and (4): one (C, F) input, two
      true answers.

ORACLE DISCIPLINE: the answers under test enter this script
ONLY as oracles (the ORACLE block below): Q7b's answers 1/4 and
0, transcribed from GS-1's G8 witness; the conditional answers
1 and 1/2 of check (11), stated in the v4 loop pass's charge;
and Q_J's answers 1 (alpha) and 0 (beta), stated in the same
charge. Every count the verdicts rest on is computed here from
the embedded declarations by T and by the tally routes; no
computation reads the oracles except the final comparisons in
checks (4), (9) and (11). If a computed answer disagrees with
an oracle, this script FAILS and prints the discrepancy.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: arbitrary finite populations of named
      members — bodies with any number of established pairwise
      junctions of port-vector length 2, the junctions named in the declaration —
      joint counts for tuples of every length k >= 1 of named
      (member, class) entries with per-entry tick offsets, over
      arbitrary declared windows; the classes are Definition
      5.1 classes — in these checks, the standings of
      Definition 5.7.
  (2) Verified domain: standing and phi over all 81 sigma
      states, exhaustively; body standing over all 81
      1-junction bodies, all 81 x 81 2-junction bodies
      (exhaustively) and a seeded sample of 2000 3-junction
      bodies; the two G8 witness populations in full
      (trajectories t = 0..7; finest census t = 0..4 and finest
      flows t = 0..3; the headline window W = [0, 4)); the
      Q_J' witness populations in full (bodies of 2 and 1
      junctions; census/flow agreement t = 0..4 / t = 0..3;
      body-tuple joint agreement over W = [0, 1) for k = 1..3
      and over [0, 4) for k = 2); the pooled-reading body (2
      junctions); and the seeded generated family — a uniform
      family (n in 2..6, twelve populations per n, bodies
      carrying 1-3 junctions each, every junction's sigma_0
      uniform over the 81 states) and a structured family
      (n in 2..6, six populations per n whose bodies carry one
      junction each with sigma_0 drawn from a pool of 4 states,
      duplicates expected, plus, for the first three
      populations per n, their first-two-bodies name-swap
      twins) — over every window of lengths 1-6 inside
      t = 0..7 for k = 1, 2, marginalization and window
      additivity, over windows [0, L), L = 1..6, for k = 3,
      over every window with end + 1 <= 8 for the lagged
      (offset) tables of check (10), and over every tested
      window for the conditional ratios of check (11).
  (3) Map: native named member -> its declared record — a body
      member to (name, its list of junction sigma_0), a
      junction member to (its body's index, its index in that
      body's junction list); native tick tau -> the trajectory
      state T_agg^tau(sigma_0), computed by the A.2-form T
      applied per junction; native standing -> the standing of
      the member's presented data by Definition 5.7 (a
      junction's own sigma; a body aggregated over its
      junctions, pairs never pooled); native joint count ->
      the tally of window ticks at which every named member
      stands in its named class at its named offset.
  (4) Preserved: every property the §5 extension's claims rest
      on — standing's totality and precedence at junction and
      at body level, the phi merging identity, the identity of
      the finest (C, F) data across the B1<->B2 name-swap
      together with the difference of the joint answers (G8's
      witness, recomputed), the identity of the finest
      junction (C, F) data, of every body class and of every
      body-tuple joint count across the Q_J' junction swap
      together with the difference of the junction-member
      answers (the loop pass's witness, recomputed), Q7b's two
      values by two independent routes (standing tables and
      direct phi tallies, with the generic member route
      agreeing cell by cell), and the marginalization,
      window-additivity, offset and conditional identities,
      verified as agreements between separately tallied counts
      (generic member route, pair tally, triple tally, raw
      recount) over every tested instance. Checks (5)-(7) are
      partition/bookkeeping identities: their machine content
      is exactly this agreement between independently coded
      tally routes — no population choice could falsify the
      identities themselves, and none is claimed to.
  (5) Outside the machine check: Paper 11 §7.5 (T's properties,
      cited — the implementation is A.2/A.7/A.10's, whose own
      batteries check them); §2.2's doctrine that a member's
      name is ledger data (cited — the reason identity-resolved
      questions are inside the framework's scope; GS-1's G8
      adjudication of C32's antecedent is the battery
      adjudicator's, cited from GS1_BATTERY_REPORT.md §G8 —
      this script recomputes the witness arithmetic, not the
      adjudication); tuples of length k >= 4; junctions of
      side count other than 2 (the paper's standing for multi-side
      junctions is stated in prose in Definition 5.7) and pairwise
      junctions of port-vector length other than 2 (this script's
      machine domain is the pairwise form at port-vector length 2,
      and no multi-side junction is generated or checked here) and
      pairwise junctions whose sides consume more than one port at
      a configuration (junction arity above the side count; the
      script carries no consumption data, and body_class reads the
      k_j multiset from the side count); junctions per body beyond
      the verified domain stated in
      (2) — the generated uniform family carries 1-3 junctions
      per body, the structured and G8 witness bodies 1
      junction each, the Q_J' bodies 2 (P) and 1 (Q) junctions,
      the pooled-reading body 2 junctions; populations and
      windows beyond the verified domain; and that v4 §5's
      prose states the instrument exactly as implemented here
      (the script does not read the paper; transcription is
      the coordinator's check at integration).

INPUT_PROVENANCE:
  - The standing definitions (Definition 5.7: a junction
    member's standing from its own sigma; a body member's
    standing aggregated over its junctions with the positive
    clause's precedence, opposed pairs never pooled across
    junctions) and the joint count J_W over named (member,
    class) entries with per-entry tick offsets, and joint
    frequency J_W / |W| (Definition 5.8): class=paper-defined
    (Paper 12 §5, v4 extension as generalized in the v4 loop
    pass — the claims under test; stated identically in §5's
    prose and in standing() / standing_body() / the tally
    routes below).
  - The G8 witness populations' sigma_0 table (12 bodies
    B1..B12, one pairwise junction of port-vector length 2 each): class=paper-defined
    (Appendix D via A.7's SIGMA0; embedded here as data;
    build-time cross-checked against the planted file
    battery/G8_witnesses.json (Appendix E's Exhibit 7; staging
    copy at staging_v7/battery/G8_witnesses.json), entries
    Q7b.population_1 and Q7b.population_2 — see DATA above;
    the file is not read at run time).
  - The second G8 witness population (the B1<->B2 name-swap):
    class=control (GS-1 G8's witness construction, declared in
    GS1_BATTERY_REPORT.md §G8; constructed below by exchanging
    the embedded table's first two entries — the names are
    unchanged, the assignments move).
  - The Q_J' witness populations alpha and beta (body P with
    named junctions J_a, J_b; body Q with named junction J_c;
    s+ and s- as stated in check (9); the bodies' declared
    node counts N(P) = 3, N(Q) = 2, which enter only the B
    component of the body-class check, B(P) = 6*3 - 4 = 14,
    B(Q) = 6*2 - 2 = 10): class=control (the v4 loop pass
    red team's witness construction, declared in the charge
    this script answers; embedded below as data).
  - The pooled-reading counterexample body of check (8) (two
    junctions, each presenting one side of an opposed pair and
    no opposed pair of its own): class=control (declared
    counterexample to the pooled reading of Definition 5.7,
    from the same charge).
  - The feature phi (opposed unit pair -> class A, otherwise
    class B): class=paper-defined (Paper 12 §8.7, under
    Definition 5.1's licence; stated identically in §8.7's
    prose and in phi() below).
  - T's definition, admissibility, and the canonical-first
    rule: class=cited-paper (Paper 11 §7.5, as restated in
    Paper 12 §4; implementation copied from A.7/A.2).
  - The ORACLE block (Q7b's answers 1/4 for population 1 and
    0 for population 2; the conditional answers 1 and 1/2;
    Q_J's answers 1 for alpha and 0 for beta): class=control
    (the predictions under test — Q7b's transcribed from GS-1's
    G8 witness, the others stated in the v4 loop pass's
    charges; never used in any computation — see ORACLE
    DISCIPLINE above).
  - The generation seeds GEN_SEED and STR_SEED, the twelve
    uniform and six structured generated populations per n in
    2..6 (plus the structured name-swap twins), the horizon of
    8 ticks, and the tested window family (lengths 1-6):
    class=arbitrary-representative (test design only; the
    witness checks (3)-(4), (8) and (9) are seed-free).
  - The generated populations' sigma_0 values (uniform family:
    drawn uniformly over the 81 states from GEN_SEED, bodies
    carrying 1-3 junctions; structured family: drawn from the
    declared 4-state pool from STR_SEED): class=control
    (seeded test fixtures; no generated value is a claim of
    the paper).
  - The planted mutants M1, M2, M3 and M5 (the product
    estimator, the honest unordered-pair count, the binarized
    standings, the window-shift tally): class=control
    (declared mutants; each is a genuine spec violation of a
    stated kind — an identity-blind estimator, an
    orientation-blind count, a class-merging, and a
    window-misreading tally).
  - The (C, F)-only meta-check of check (12) (the former M4
    label): class=control
    (NOT a planted mutant — G8's argument, computed from
    checks (3) and (4): a purported instrument restricted to
    data those checks prove identical across the witness
    pair, against two true answers those checks compute).
  - External data: none. This script reads no file, fetches
    nothing, and takes no value from the environment.

Exact arithmetic: counts are integers; every frequency, share
and mutant value printed is a fractions.Fraction. No float is
used for any claimed value.
"""
import random
import sys
from collections import Counter
from fractions import Fraction
from itertools import product

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Paper 11's operator T, exactly as Paper 12 §4 states it
# (copied from A7_exhibit.py / A2_parallel_tick.py). T acts on ONE
# junction's sigma; a body's tick applies T per junction.
# ---------------------------------------------------------------------------

def admissible_indices(sigma):
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def T(sigma):
    """Zero the canonically first admissible pair; identity if none."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[0]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


def parallel_tick(state):
    """One aggregate tick: T applied per junction, body by body.
    A state is a tuple of bodies; a body is a tuple of sigmas."""
    return tuple(tuple(T(s) for s in body) for body in state)


# ---------------------------------------------------------------------------
# The instrument (v4 §5, Definitions 5.7-5.8): standings of
# junctions and of bodies, phi, joint counts over named members.
# ---------------------------------------------------------------------------

STANDINGS = ("+", "-", "0")   # positive, negative, neutral
STANDING_NAMES = {"+": "positive", "-": "negative", "0": "neutral"}


def presents_pos(sigma):
    """True iff sigma presents an opposed pair (+1, -1) at some k."""
    A, B = sigma
    return any(A[k] == 1 and B[k] == -1 for k in range(len(A)))


def presents_neg(sigma):
    """True iff sigma presents an opposed pair (-1, +1) at some k."""
    A, B = sigma
    return any(A[k] == -1 and B[k] == 1 for k in range(len(A)))


def standing(sigma):
    """The v4 §5 standing of ONE junction from its presented
    sigma: positive iff some k has A[k] = +1 and B[k] = -1; else
    negative iff some k has A[k] = -1 and B[k] = +1; else
    neutral. This is also a junction member's standing."""
    if presents_pos(sigma):
        return "+"
    if presents_neg(sigma):
        return "-"
    return "0"


def standing_body(body):
    """A body member's standing (Definition 5.7's body case),
    direct route: positive iff ANY of the body's junctions
    presents a (+1, -1) opposed pair within its own sigma; else
    negative iff any presents the mirror pair and none presents
    (+1, -1); else neutral. Pairs are read inside one junction
    only — never pooled across junctions. The empty body is
    neutral."""
    if any(presents_pos(s) for s in body):
        return "+"
    if any(presents_neg(s) for s in body):
        return "-"
    return "0"


def standing_body_via_junctions(body):
    """A body member's standing, second route: aggregate the
    junctions' own standings with the same precedence —
    positive iff any junction stands positive, else negative
    iff any stands negative, else neutral."""
    sts = [standing(s) for s in body]
    if "+" in sts:
        return "+"
    if "-" in sts:
        return "-"
    return "0"


def standing_body_orientations(body):
    """A body member's standing, third route: form the set of
    oriented pairs (A[k], B[k]) presented inside the body's
    junctions (each pair from one junction, one index); the
    body is positive iff (1, -1) is in the set, else negative
    iff (-1, 1) is, else neutral."""
    pairs = {(s[0][k], s[1][k]) for s in body
             for k in range(len(s[0]))}
    if (1, -1) in pairs:
        return "+"
    if (-1, 1) in pairs:
        return "-"
    return "0"


def phi(sigma):
    """phi(sigma), §8.7's feature: class A iff sigma presents an
    opposed unit pair (some k with A[k] = +1 and B[k] = -1);
    otherwise class B."""
    A, B = sigma
    for k in range(len(A)):
        if A[k] == 1 and B[k] == -1:
            return "A"
    return "B"


def all_sigma_states():
    """All 3^4 = 81 local states at port-vector length 2, in
    A.10's enumeration order."""
    return [((a0, a1), (b0, b1))
            for a0 in (-1, 0, 1) for a1 in (-1, 0, 1)
            for b0 in (-1, 0, 1) for b1 in (-1, 0, 1)]


def trajectory(sigma0, horizon):
    """The aggregate-tick trajectory: states at t = 0..horizon-1.
    sigma0 is a tuple of bodies; each body a tuple of sigmas."""
    states = [tuple(tuple(body) for body in sigma0)]
    for _ in range(horizon - 1):
        states.append(parallel_tick(states[-1]))
    return states


def standing_traj(states):
    """Per tick, the tuple of BODY standings in body order."""
    return [tuple(standing_body(body) for body in state)
            for state in states]


def junction_standing_traj(states):
    """Per tick, per body, the tuple of its junctions' standings."""
    return [tuple(tuple(standing(s) for s in body) for body in state)
            for state in states]


def make_pop(names, sigma0):
    """Computed per-population data: trajectory, body standings,
    junction standings. sigma0: tuple of bodies (tuples of
    sigmas)."""
    states = trajectory(sigma0, HORIZON)
    return {"names": names, "sigma0": sigma0, "states": states,
            "stnd": standing_traj(states),
            "jstnd": junction_standing_traj(states)}


def member_standing(d, t, member):
    """The standing of a named member at tick t, from the
    precomputed standings: member is ('body', i) or
    ('junction', i, j)."""
    if member[0] == "body":
        return d["stnd"][t][member[1]]
    return d["jstnd"][t][member[1]][member[2]]


def joint_count_members(d, window, specs):
    """The generic member joint-count route, any k, any mix of
    body and junction members, with per-entry tick offsets:
    J_W(specs) tallied directly from Definition 5.8 — the
    number of ticks tau in window = (start, end) at which, for
    every spec (member, X) or (member, X, delta), the named
    member stands in class X at tau + delta."""
    start, end = window
    norm = [(spec[0], spec[1], spec[2] if len(spec) > 2 else 0)
            for spec in specs]
    return sum(1 for t in range(start, end)
               if all(member_standing(d, t + delta, member) == X
                      for member, X, delta in norm))


def single_counts(d, window, i):
    """The k = 1 joint counts of body i over window, by the
    generic member route: {X: J_W((('body', i), X))}."""
    return {X: joint_count_members(d, window, ((("body", i), X),))
            for X in STANDINGS}


def pair_table(stnd, window, i, j):
    """The 3x3 joint standing table for the ordered pair of
    bodies (i, j) over window, by its own tally (independent
    of the generic route): {(X, Y): J_W((i, X), (j, Y))}."""
    start, end = window
    table = {(X, Y): 0 for X in STANDINGS for Y in STANDINGS}
    for t in range(start, end):
        table[(stnd[t][i], stnd[t][j])] += 1
    return table


def triple_table(stnd, window, i, j, k):
    """The 3x3x3 joint standing table for the ordered triple
    (i, j, k) over window, by its own tally."""
    start, end = window
    table = {(X, Y, Z): 0 for X in STANDINGS for Y in STANDINGS
             for Z in STANDINGS}
    for t in range(start, end):
        table[(stnd[t][i], stnd[t][j], stnd[t][k])] += 1
    return table


def flat_junctions(state):
    """All junction sigmas of a population state, in declaration
    order (body order, then junction order within the body)."""
    return [s for body in state for s in body]


def finest_census(states, ticks):
    """The finest census sequence: at each tick in ticks, the
    Counter of sigma values over all junctions of all bodies
    (all 81 classes). For the G8 witness populations (one
    junction per body) this is the bodies' finest census."""
    return [Counter(flat_junctions(states[t])) for t in ticks]


def finest_flows(states, ticks):
    """The finest flow tables: at each tick t in ticks, the
    Counter of (sigma_t, sigma_{t+1}) pairs over all junctions,
    junctions matched across ticks by declaration order."""
    return [Counter(zip(flat_junctions(states[t]),
                         flat_junctions(states[t + 1])))
            for t in ticks]


def body_class(body, n_nodes):
    """A body's Definition 5.1 / §3 body class, on the data this
    script carries: (node count, junction arity multiset,
    B = 6N - sum of junction arities, Sigma-s-squared total = sum over all presented
    components of the component squared, presented-count profile
    (n+, n-) over all presented components, the multiset of the
    body's junction sigmas).

    Disclosure (round-2 loop repair): this script carries no
    port-consumption data. The junction arity multiset is read from
    the side count (the length of each sigma), which equals the
    k_j multiset exactly where each side consumes one port -- the
    verified domain stated in the coverage map. A junction whose
    side consumes more than one port (section 11.2, clause (ii))
    is outside this script's domain, and its section 3.2 key is
    not computed here."""
    junction_arities = tuple(sorted(len(s) for s in body))
    sum_k = sum(junction_arities)
    sum_s2 = sum(v * v for s in body for side in s for v in side)
    profile = (sum(1 for s in body for side in s for v in side
                   if v == 1),
               sum(1 for s in body for side in s for v in side
                   if v == -1))
    return (n_nodes, junction_arities, 6 * n_nodes - sum_k, sum_s2,
            profile, tuple(sorted(body)))


# ---------------------------------------------------------------------------
# Witness data (DECLARED — see INPUT_PROVENANCE and the build-time
# cross-check stated in the docstring's DATA paragraph).
# ---------------------------------------------------------------------------

BODIES = [f"B{i}" for i in range(1, 13)]          # B1..B12
SIGMA0_FLAT = (                            # Appendix D, via A.7
    ((1, 1), (-1, -1)),     # B1
    ((1, -1), (-1, 1)),     # B2
    ((-1, -1), (1, 1)),     # B3
    ((-1, 1), (1, -1)),     # B4
    ((1, 1), (-1, -1)),     # B5
    ((1, -1), (-1, 1)),     # B6
    ((1, 0), (-1, 1)),      # B7
    ((1, 1), (-1, 0)),      # B8
    ((-1, 0), (1, -1)),     # B9
    ((-1, -1), (1, 0)),     # B10
    ((1, 0), (-1, 0)),      # B11
    ((-1, 0), (1, 0)),      # B12
)
# The G8 witness populations in the generalized representation:
# each body is a tuple of its junctions' sigmas (one each here).
SIGMA0_POP1 = tuple((s,) for s in SIGMA0_FLAT)
# Population 2: the identical declaration with the sigma_0
# assignments of named bodies B1 and B2 exchanged (names unmoved).
SIGMA0_POP2 = (SIGMA0_POP1[1], SIGMA0_POP1[0]) + SIGMA0_POP1[2:]

# The Q_J' witness (check (9)): body P (index 0) carries named
# junctions J_a (index 0) and J_b (index 1); body Q (index 1)
# carries named junction J_c (index 0).
S_PLUS = ((1, 0), (-1, 0))
S_MINUS = ((0, -1), (0, 1))
QJ_NAMES = ["P", "Q"]
QJ_NODES = (3, 2)          # declared node counts (B check only)
QJ_ALPHA = ((S_PLUS, S_MINUS), (S_PLUS,))    # J_a=s+, J_b=s-, J_c=s+
QJ_BETA = ((S_MINUS, S_PLUS), (S_PLUS,))     # J_a=s-, J_b=s+, J_c=s+
QJ_WINDOW = (0, 1)                            # W = [0, 1)

# The pooled-reading counterexample body (check (8)): J_a
# presents the +1 side of an opposed pair, J_b the -1 side;
# neither junction presents an opposed pair of its own.
POOLED_BODY = (((1, 0), (0, 0)), ((0, 0), (-1, 0)))

HORIZON = 8                                # trajectories t = 0..7
WINDOWS = [(s, s + L) for L in range(1, 7)
           for s in range(0, HORIZON - L + 1)]
OFFSET_WINDOWS = [w for w in WINDOWS if w[1] + 1 <= HORIZON]
HEADLINE_WINDOW = (0, 4)                   # W = [0, 4), Q7b's window

GEN_SEED = 20261026
GEN_REPS = 12                              # uniform pops per n
STR_SEED = 20261027
STR_REPS = 6                               # structured pops per n
STR_TWIN_REPS = 3                          # of those, with twins
POOL4 = (S_PLUS, S_MINUS,
         ((1, 1), (-1, -1)),
         ((0, 0), (0, 0)))                 # the 4-state pool

# ---------------------------------------------------------------------------
# ORACLES UNDER TEST — Q7b's answers, transcribed from GS-1's G8
# witness; the conditional answers of check (11) and Q_J's
# answers, stated in the v4 loop pass's charges (see ORACLE
# DISCIPLINE in the docstring). No computation reads these
# except the comparisons in Steps 4, 9 and 11.
# ---------------------------------------------------------------------------

ORACLE_Q7B = (Fraction(1, 4), Fraction(0, 1))   # (pop 1, pop 2)
ORACLE_COND = (Fraction(1, 1), Fraction(1, 2))  # (pop 1, pop 2)
ORACLE_QJ = (Fraction(1, 1), Fraction(0, 1))     # (alpha, beta)


def fmt_sigma(s):
    return f"A={s[0]}, B={s[1]}"


def print_pair_table(table, label):
    print(f"    {label}")
    print("             " + "".join(f"B2={Y:<7}" for Y in STANDINGS))
    for X in STANDINGS:
        row = "".join(f"{table[(X, Y)]:<9}" for Y in STANDINGS)
        print(f"      B1={X}   {row}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 72)
    print("A.12 — JOINT COUNTS: IDENTITY-RESOLVED FREQUENCIES")
    print("  (Paper 12 §5, v4 extension, generalized to named")
    print("   members of either kind; the G8 and Q_J' witnesses")
    print("   recomputed, the joint-count instrument verified)")
    print("=" * 72)

    witness_pops = [("AppendixD", BODIES, SIGMA0_POP1),
                    ("AppendixD_swap_names_0_1", BODIES, SIGMA0_POP2)]

    # --- Step 0: declared witness data, shape checks -----------------
    print("\n--- Step 0: the declared witness populations ---")
    check(len(SIGMA0_POP1) == 12 and len(SIGMA0_POP2) == 12,
          "12 named bodies B1..B12 in each witness population")
    check(all(len(body) == 1 for body in SIGMA0_POP1)
          and all(len(s[0]) == 2 and len(s[1]) == 2
                  and all(v in (-1, 0, 1) for v in s[0] + s[1])
                  for body in SIGMA0_POP1 for s in body),
          "every witness body carries one pairwise junction of port-vector length 2; "
          "every sigma_0 is a pair of length-2 vectors over "
          "{-1, 0, +1}")
    check(SIGMA0_POP2[0] == SIGMA0_POP1[1]
          and SIGMA0_POP2[1] == SIGMA0_POP1[0]
          and SIGMA0_POP2[2:] == SIGMA0_POP1[2:]
          and SIGMA0_POP1[0] != SIGMA0_POP1[1],
          "population 2 is population 1 with exactly the B1/B2 "
          "sigma_0 assignments exchanged (a nontrivial swap)")
    check(Counter(SIGMA0_FLAT)
          == Counter(body[0] for body in SIGMA0_POP2),
          "the two declarations carry the same multiset of "
          "sigma_0 values (the swap moves assignments, not data)")
    for b, body in zip(BODIES, SIGMA0_POP1):
        print(f"    {b}: sigma_0 = ({fmt_sigma(body[0])})")
    print(f"    Q_J' witness: body P = (J_a, J_b), body Q = (J_c); "
          f"alpha J_a/J_b/J_c = s+/s-/s+, beta = s-/s+/s+, "
          f"s+ = ({fmt_sigma(S_PLUS)}), s- = ({fmt_sigma(S_MINUS)})")
    print(f"    pooled-reading body: J_a = ({fmt_sigma(POOLED_BODY[0])}), "
          f"J_b = ({fmt_sigma(POOLED_BODY[1])})")

    # Generated families (seeded fixtures; see INPUT_PROVENANCE).
    all_states = all_sigma_states()
    rng = random.Random(GEN_SEED)
    uniform_pops = []
    for n in range(2, 7):
        for rep in range(GEN_REPS):
            names = [f"G{n}_{rep}_B{i + 1}" for i in range(n)]
            sigma0 = tuple(
                tuple(rng.choice(all_states)
                      for _ in range(rng.randint(1, 3)))
                for _ in range(n))
            uniform_pops.append((f"Gen_n{n}_{rep:02d}", names, sigma0))
    rng_s = random.Random(STR_SEED)
    structured_pops = []
    for n in range(2, 7):
        for rep in range(STR_REPS):
            names = [f"S{n}_{rep}_B{i + 1}" for i in range(n)]
            sigma0 = tuple((rng_s.choice(POOL4),) for _ in range(n))
            structured_pops.append(
                (f"Struct_n{n}_{rep:02d}", names, sigma0))
            if rep < STR_TWIN_REPS:
                twin = (sigma0[1], sigma0[0]) + sigma0[2:]
                structured_pops.append(
                    (f"Struct_n{n}_{rep:02d}_swap01", names, twin))
    gen_pops = uniform_pops + structured_pops
    nj_dist = Counter(len(body) for _l, _n, s0 in uniform_pops
                      for body in s0)
    print(f"    generated family (uniform): seed {GEN_SEED}; "
          f"n in 2..6, {GEN_REPS} populations per n "
          f"({len(uniform_pops)} total); bodies carry 1-3 "
          f"junctions (distribution over bodies: "
          f"{dict(sorted(nj_dist.items()))}); every junction's "
          f"sigma_0 uniform over the 81 states")
    print(f"    generated family (structured): seed {STR_SEED}; "
          f"n in 2..6, {STR_REPS} populations per n plus "
          f"{STR_TWIN_REPS} first-two-bodies name-swap twins per "
          f"n ({len(structured_pops)} total); bodies carry one "
          f"junction each, sigma_0 drawn from a pool of "
          f"{len(POOL4)} states (duplicates expected); horizon "
          f"t = 0..{HORIZON - 1}; {len(WINDOWS)} tested windows "
          f"(lengths 1-6)")

    # Per-population computed data, shared by the steps below.
    pop_data = {}
    for label, names, sigma0 in witness_pops + gen_pops:
        d = make_pop(names, sigma0)
        singles = {}
        pairs = {}
        for w in WINDOWS:
            for i in range(len(names)):
                singles[(w, i)] = single_counts(d, w, i)
            for i in range(len(names)):
                for j in range(len(names)):
                    if i != j:
                        pairs[(w, i, j)] = pair_table(d["stnd"], w, i, j)
        d["singles"] = singles
        d["pairs"] = pairs
        pop_data[label] = d

    # --- Step 1 / check (1): standing totality ------------------------
    print("\n--- Step 1 / (1): standing totality over all 81 states ---")
    counts81 = Counter(standing(s) for s in all_states)
    check(len(all_states) == 81
          and all(standing(s) in STANDINGS for s in all_states)
          and sum(counts81.values()) == 81,
          "(1) standing is total: every one of the 81 sigma states "
          "stands in exactly one of the three classes",
          f"counts over the 81 states: positive (+) = "
          f"{counts81['+']}, negative (-) = {counts81['-']}, "
          f"neutral (0) = {counts81['0']}")
    both = [s for s in all_states
            if any(s[0][k] == 1 and s[1][k] == -1 for k in range(2))
            and any(s[0][k] == -1 and s[1][k] == 1
                    for k in range(2))]
    check(len(both) > 0 and all(standing(s) == "+" for s in both),
          "(1) precedence: states presenting BOTH orientations "
          "stand positive, by the definition's clause order",
          f"{len(both)} such states among the 81, all positive")

    # --- Step 2 / check (2): phi refinement ---------------------------
    print("\n--- Step 2 / (2): phi is the standings, merged (§8.7) ---")
    bad2 = [s for s in all_states
            if (phi(s) == "A") != (standing(s) == "+")
            or (phi(s) == "B") != (standing(s) in ("-", "0"))]
    check(not bad2,
          "(2) over all 81 states: phi(sigma) = A iff standing is "
          "positive; phi(sigma) = B iff standing is negative or "
          "neutral",
          f"mismatches: {bad2[:3]}" if bad2 else
          "phi forgets exactly the negative/neutral distinction")

    # --- Step 3 / check (3): the break's premise, recomputed ----------
    print("\n--- Step 3 / (3): finest (C, F) identical across the swap ---")
    d1 = pop_data["AppendixD"]
    d2 = pop_data["AppendixD_swap_names_0_1"]
    cens1 = finest_census(d1["states"], range(5))
    cens2 = finest_census(d2["states"], range(5))
    flows1 = finest_flows(d1["states"], range(4))
    flows2 = finest_flows(d2["states"], range(4))
    for t in range(5):
        print(f"    t = {t}: distinct sigma classes occupied: "
              f"pop 1: {len(cens1[t])}, pop 2: {len(cens2[t])}; "
              f"class counts sum to {sum(cens1[t].values())} "
              f"junctions (one per body here)")
    for t in range(4):
        print(f"    flow t = {t} -> {t + 1}: distinct (sigma, "
              f"sigma') pairs: pop 1: {len(flows1[t])}, pop 2: "
              f"{len(flows2[t])}; transitions sum to "
              f"{sum(flows1[t].values())}")
    check(cens1 == cens2,
          "(3) the finest census sequences (t = 0..4, over all 81 "
          "sigma classes) of the two witness populations are "
          "identical")
    check(flows1 == flows2,
          "(3) the finest flow tables (t = 0..3) of the two "
          "witness populations are identical")
    print("    every Definition 5.1 census or flow count of either "
          "population is a marginalization of this finest data, so "
          "all of them agree across the pair as well")

    # --- Step 4 / check (4): the repair — joint tables and Q7b --------
    print("\n--- Step 4 / (4): joint tables for (B1, B2), W = [0, 4), "
          "and Q7b ---")
    q7b_answers = []
    for pi, (label, _names, _s0) in enumerate(witness_pops):
        d = pop_data[label]
        table = d["pairs"][(HEADLINE_WINDOW, 0, 1)]
        print(f"    population {pi + 1} ({label}): standings of "
              f"(B1, B2) at t = 0..3: "
              + ", ".join(f"t{t}=({d['stnd'][t][0]},"
                          f"{d['stnd'][t][1]})" for t in range(4)))
        print_pair_table(table, f"J_W for (B1, B2), W = [0, 4), "
                                f"population {pi + 1} ({label}):")
        check(sum(table.values()) == 4,
              f"(4) population {pi + 1}: the 3x3 table sums to "
              f"|W| = 4")
        generic = {(X, Y): joint_count_members(
            d, HEADLINE_WINDOW, ((("body", 0), X), (("body", 1), Y)))
                   for X in STANDINGS for Y in STANDINGS}
        check(generic == table,
              f"(4) population {pi + 1}: the pair tally and the "
              f"generic member joint-count route agree on all "
              f"9 cells")
        ans = Fraction(table[("+", "-")] + table[("+", "0")], 4)
        q7b_answers.append(ans)
        check(ans == ORACLE_Q7B[pi],
              f"(4) oracle: Q7b answer for population {pi + 1} "
              f"== printed {ORACLE_Q7B[pi]}",
              f"computed (J[+][-] + J[+][0]) / 4 = "
              f"({table[('+', '-')] } + {table[('+', '0')]}) / 4 "
              f"= {ans}")
        direct = sum(1 for t in range(4)
                     if phi(d["states"][t][0][0]) == "A"
                     and phi(d["states"][t][1][0]) == "B")
        check(Fraction(direct, 4) == ans,
              f"(4) population {pi + 1}: the direct phi-class "
              f"joint count (B1 in A, B2 in B, tallied from sigma "
              f"without standing) agrees with the standing-derived "
              f"answer",
              f"direct count {direct}/4 = {Fraction(direct, 4)}, "
              f"standing-derived {ans}")
    check(q7b_answers[0] != q7b_answers[1],
          "(4) the joint instrument separates the witness pair: "
          "the two Q7b answers differ",
          f"population 1: {q7b_answers[0]}, population 2: "
          f"{q7b_answers[1]}")

    # --- Step 5 / check (5): marginalization ---------------------------
    print("\n--- Step 5 / (5): marginalization, witness + generated ---")
    row_fail, col_fail, tot_fail = [], [], []
    n_instances = 0
    for label, names, _s0 in witness_pops + gen_pops:
        d = pop_data[label]
        for w in WINDOWS:
            for i in range(len(names)):
                for j in range(len(names)):
                    if i == j:
                        continue
                    n_instances += 1
                    table = d["pairs"][(w, i, j)]
                    si = d["singles"][(w, i)]
                    sj = d["singles"][(w, j)]
                    for X in STANDINGS:
                        if sum(table[(X, Y)] for Y in STANDINGS) \
                                != si[X] and len(row_fail) < 5:
                            row_fail.append((label, w, names[i],
                                             names[j], X))
                    for Y in STANDINGS:
                        if sum(table[(X, Y)] for X in STANDINGS) \
                                != sj[Y] and len(col_fail) < 5:
                            col_fail.append((label, w, names[i],
                                             names[j], Y))
                    if sum(table.values()) != w[1] - w[0] \
                            and len(tot_fail) < 5:
                        tot_fail.append((label, w, names[i],
                                         names[j]))
    print(f"    ordered-pair instances verified: {n_instances} "
          f"(populations x windows x ordered pairs)")
    for wit in row_fail + col_fail + tot_fail:
        print(f"    witness: {wit}")
    check(not row_fail,
          "(5) for every ordered pair and every class X of the "
          "first body: sum over the second body's standings of J "
          "== the first body's k = 1 count in X",
          f"{n_instances} instances" if not row_fail else
          f"first witnesses: {row_fail}")
    check(not col_fail,
          "(5) pair counts marginalize to the k = 1 joint counts "
          "of the second body as well",
          f"{n_instances} instances" if not col_fail else
          f"first witnesses: {col_fail}")
    check(not tot_fail,
          "(5) for every ordered pair and window: sum over both "
          "bodies' classes of J == |W|",
          f"{n_instances} instances" if not tot_fail else
          f"first witnesses: {tot_fail}")

    # --- Step 6 / check (6): window additivity -------------------------
    print("\n--- Step 6 / (6): window additivity, all splits ---")
    add_fail = []
    n_splits = 0
    for label, names, _s0 in witness_pops + gen_pops:
        d = pop_data[label]
        for (s, e) in WINDOWS:
            for m in range(s + 1, e):
                for i in range(len(names)):
                    for j in range(len(names)):
                        if i == j:
                            continue
                        n_splits += 1
                        whole = d["pairs"][((s, e), i, j)]
                        left = d["pairs"][((s, m), i, j)]
                        right = d["pairs"][((m, e), i, j)]
                        if any(whole[c] != left[c] + right[c]
                               for c in whole) \
                                and len(add_fail) < 5:
                            add_fail.append((label, (s, e), m,
                                             names[i], names[j]))
    print(f"    (window, split, ordered pair) instances "
          f"verified: {n_splits}")
    for wit in add_fail:
        print(f"    witness: {wit}")
    check(not add_fail,
          "(6) for every split of every tested window into two "
          "consecutive parts: J over the union == sum of J over "
          "the parts, componentwise (all 9 cells)",
          f"{n_splits} instances" if not add_fail else
          f"first witnesses: {add_fail}")

    # --- Step 7 / check (7): tuple case k = 3 --------------------------
    print("\n--- Step 7 / (7): tuple case k = 3 (generated) ---")
    tri_fail = []
    n_triples = 0
    for label, names, _s0 in gen_pops:
        if len(names) < 3:
            continue
        d = pop_data[label]
        for L in range(1, 7):
            w = (0, L)
            for i in range(len(names)):
                for j in range(len(names)):
                    for k in range(len(names)):
                        if len({i, j, k}) < 3:
                            continue
                        n_triples += 1
                        tt = triple_table(d["stnd"], w, i, j, k)
                        pair = d["pairs"][(w, i, j)]
                        marg_pair = {(X, Y): sum(
                            tt[(X, Y, Z)] for Z in STANDINGS)
                            for X in STANDINGS for Y in STANDINGS}
                        si = d["singles"][(w, i)]
                        sj = d["singles"][(w, j)]
                        sk = d["singles"][(w, k)]
                        ok = marg_pair == pair and all(
                            sum(tt[(X, Y, Z)]
                                for Y in STANDINGS
                                for Z in STANDINGS) == si[X]
                            for X in STANDINGS) and all(
                            sum(tt[(X, Y, Z)]
                                for X in STANDINGS
                                for Z in STANDINGS) == sj[Y]
                            for Y in STANDINGS) and all(
                            sum(tt[(X, Y, Z)]
                                for X in STANDINGS
                                for Y in STANDINGS) == sk[Z]
                            for Z in STANDINGS)
                        if not ok and len(tri_fail) < 5:
                            tri_fail.append((label, w, names[i],
                                             names[j], names[k]))
    print(f"    (population, window, ordered triple) instances "
          f"verified: {n_triples}")
    for wit in tri_fail:
        print(f"    witness: {wit}")
    check(not tri_fail,
          "(7) the 3x3x3 joint table marginalizes over the third "
          "body to the pair table, and over two bodies to the "
          "single (k = 1) counts, on every tested instance",
          f"{n_triples} instances" if not tri_fail else
          f"first witnesses: {tri_fail}")

    # --- Step 8 / check (8): multi-junction bodies ---------------------
    print("\n--- Step 8 / (8): multi-junction bodies — body standing "
          "aggregates over junctions, pairs never pooled ---")
    route_fail = []
    n_route = 0
    for s in all_states:
        n_route += 1
        if not (standing_body((s,)) == standing(s)
                == standing_body_via_junctions((s,))
                == standing_body_orientations((s,))) \
                and len(route_fail) < 5:
            route_fail.append((s,))
    for s1 in all_states:
        for s2 in all_states:
            n_route += 1
            body = (s1, s2)
            if not (standing_body(body)
                    == standing_body_via_junctions(body)
                    == standing_body_orientations(body)) \
                    and len(route_fail) < 5:
                route_fail.append(body)
    rng_t = random.Random(777)
    for _ in range(2000):
        body = tuple(rng_t.choice(all_states) for _ in range(3))
        n_route += 1
        if not (standing_body(body)
                == standing_body_via_junctions(body)
                == standing_body_orientations(body)) \
                and len(route_fail) < 5:
            route_fail.append(body)
    print(f"    body-standing route agreements verified: {n_route} "
          f"(81 one-junction, 6561 two-junction exhaustive, "
          f"2000 three-junction sampled, seed 777)")
    for wit in route_fail:
        print(f"    witness: {wit}")
    check(not route_fail,
          "(8) body standing: the direct opposed-pair scan, the "
          "aggregation of the junctions' own standings, and the "
          "orientation-set read agree on every tested body "
          "(positive iff some junction presents (+1, -1); else "
          "negative iff some presents (-1, +1); else neutral)",
          f"{n_route} bodies" if not route_fail else
          f"first witnesses: {route_fail}")
    check(standing_body(()) == "0"
          and standing_body_via_junctions(()) == "0",
          "(8) a body with no established junctions is neutral")
    ja, jb = POOLED_BODY
    pooled_sigma = (tuple(ja[0][k] + jb[0][k] for k in range(2)),
                    tuple(ja[1][k] + jb[1][k] for k in range(2)))
    pooled_traj = [POOLED_BODY]
    for _ in range(HORIZON - 1):
        pooled_traj.append(tuple(T(s) for s in pooled_traj[-1]))
    print(f"    pooled counterexample: J_a stands "
          f"{STANDING_NAMES[standing(ja)]}, J_b stands "
          f"{STANDING_NAMES[standing(jb)]}; body standing = "
          f"{STANDING_NAMES[standing_body(POOLED_BODY)]}; the "
          f"pooled reading (sides summed across junctions: "
          f"sigma = ({fmt_sigma(pooled_sigma)})) stands "
          f"{STANDING_NAMES[standing(pooled_sigma)]}")
    check(standing(ja) == "0" and standing(jb) == "0"
          and standing_body(POOLED_BODY) == "0",
          "(8) pooled-reading counterexample: the body with "
          "J_a sigma = ((1, 0), (0, 0)) and J_b sigma = "
          "((0, 0), (-1, 0)) is NEUTRAL — no junction of it "
          "presents an opposed pair")
    check(T(ja) == ja and T(jb) == jb
          and all(b == POOLED_BODY for b in pooled_traj)
          and all(standing_body(b) == "0" for b in pooled_traj),
          "(8) T acts nowhere on the pooled-reading body: each "
          "junction's T is the identity, its trajectory is "
          "constant, and it stands neutral at every tick")
    check(standing(pooled_sigma) == "+"
          and standing(pooled_sigma) != standing_body(POOLED_BODY),
          "(8) the pooled reading is rejected: summing the two "
          "junctions' sides into one sigma manufactures an "
          "opposed pair ((1, -1) at k = 0) that no junction "
          "presents, and misstands the body as positive")

    # --- Step 9 / check (9): junction-member joints, Q_J' --------------
    print("\n--- Step 9 / (9): junction-member joint counts — the "
          "Q_J' witness ---")
    qj = {}
    for tag, sigma0 in (("alpha", QJ_ALPHA), ("beta", QJ_BETA)):
        qj[tag] = make_pop(QJ_NAMES, sigma0)
    qa, qb = qj["alpha"], qj["beta"]
    qj_cens_a = finest_census(qa["states"], range(5))
    qj_cens_b = finest_census(qb["states"], range(5))
    qj_flow_a = finest_flows(qa["states"], range(4))
    qj_flow_b = finest_flows(qb["states"], range(4))
    check(qj_cens_a == qj_cens_b,
          "(9) Q_J': the finest junction census sequences "
          "(t = 0..4, over all 81 sigma classes, all 3 junctions) "
          "of alpha and beta are identical",
          f"at t = 0 the junction multiset is "
          f"{dict(qj_cens_a[0])} on both")
    check(qj_flow_a == qj_flow_b,
          "(9) Q_J': the finest junction flow tables (t = 0..3) "
          "of alpha and beta are identical")
    class_fail = []
    for t in range(5):
        for bi in range(2):
            ca = body_class(qa["states"][t][bi], QJ_NODES[bi])
            cb = body_class(qb["states"][t][bi], QJ_NODES[bi])
            if ca != cb and len(class_fail) < 5:
                class_fail.append((t, QJ_NAMES[bi], ca, cb))
    print(f"    body P class at t = 0 (both alpha and beta): "
          f"(N, junction arities, B, Sigma-s-squared total, presented "
          f"profile, junction multiset) = "
          f"{body_class(QJ_ALPHA[0], QJ_NODES[0])}")
    print(f"    body Q class at t = 0 (both alpha and beta): "
          f"{body_class(QJ_ALPHA[1], QJ_NODES[1])}")
    for wit in class_fail:
        print(f"    witness: {wit}")
    check(not class_fail,
          "(9) Q_J': every body class of P and of Q agrees across "
          "alpha/beta at every tick t = 0..4 — node count, "
          "junction arity multiset, B (P: 14, Q: 10), Sigma-s-squared total "
          "(P: 4 at t = 0), presented-count profile (P: (2, 2) "
          "at t = 0), junction-sigma multiset",
          "P at t = 0: B = 14, profile (2, 2)" if not class_fail
          else f"first witnesses: {class_fail}")
    check(qa["stnd"] == qb["stnd"]
          and qa["stnd"][0] == ("+", "+"),
          "(9) Q_J': the body standings of P and Q agree across "
          "alpha/beta at every tick t = 0..7, and both bodies "
          "stand positive at t = 0",
          f"P standing at t = 0: {qa['stnd'][0][0]} on both; "
          f"Q standing at t = 0: {qa['stnd'][0][1]} on both")
    tuple_fail = []
    n_tuple_cmp = 0
    for k in (1, 2, 3):
        for bodies in product(range(2), repeat=k):
            for classes in product(STANDINGS, repeat=k):
                n_tuple_cmp += 1
                specs = tuple((("body", bi), X)
                              for bi, X in zip(bodies, classes))
                if joint_count_members(qa, QJ_WINDOW, specs) \
                        != joint_count_members(qb, QJ_WINDOW, specs) \
                        and len(tuple_fail) < 5:
                    tuple_fail.append((specs,))
    for bodies in product(range(2), repeat=2):
        for classes in product(STANDINGS, repeat=2):
            n_tuple_cmp += 1
            specs = tuple((("body", bi), X)
                          for bi, X in zip(bodies, classes))
            if joint_count_members(qa, HEADLINE_WINDOW, specs) \
                    != joint_count_members(qb, HEADLINE_WINDOW,
                                           specs) \
                    and len(tuple_fail) < 5:
                tuple_fail.append((specs,))
    print(f"    body-tuple joint counts compared across "
          f"alpha/beta: {n_tuple_cmp} (tuples of length 1-3 over "
          f"W = [0, 1), pairs over [0, 4), all class entries)")
    for wit in tuple_fail:
        print(f"    witness: {wit}")
    check(not tuple_fail,
          "(9) Q_J': every body-tuple joint count agrees across "
          "alpha/beta on every compared tuple",
          f"{n_tuple_cmp} comparisons" if not tuple_fail else
          f"first witnesses: {tuple_fail}")
    qj_answers = []
    for tag, d in (("alpha", qa), ("beta", qb)):
        cnt = joint_count_members(
            d, QJ_WINDOW,
            ((("junction", 0, 0), "+"), (("body", 1), "+")))
        direct = sum(
            1 for t in range(QJ_WINDOW[0], QJ_WINDOW[1])
            if standing(d["states"][t][0][0]) == "+"
            and standing_body(d["states"][t][1]) == "+")
        ans = Fraction(cnt, QJ_WINDOW[1] - QJ_WINDOW[0])
        qj_answers.append(ans)
        print(f"    Q_J' on {tag}: J_a (junction (0, 0)) stands "
              f"{STANDING_NAMES[member_standing(d, 0, ('junction', 0, 0))]} "
              f"at t = 0, body Q stands "
              f"{STANDING_NAMES[member_standing(d, 0, ('body', 1))]}; "
              f"member joint count = {cnt}, direct raw tally = "
              f"{direct}, Q_J' = {ans}")
        check(cnt == direct,
              f"(9) Q_J' on {tag}: the member joint-count route "
              f"and the direct raw tally agree")
        check(ans == ORACLE_QJ[0 if tag == "alpha" else 1],
              f"(9) oracle: Q_J' answer for {tag} == printed "
              f"{ORACLE_QJ[0 if tag == 'alpha' else 1]}",
              f"computed {ans}")
    check(qj_answers[0] != qj_answers[1],
          "(9) the junction-member instrument separates the "
          "Q_J' pair: the two answers differ, while every "
          "body-level instrument above agrees",
          f"alpha: {qj_answers[0]}, beta: {qj_answers[1]}")

    # --- Step 10 / check (10): tick offsets -----------------------------
    print("\n--- Step 10 / (10): tick offsets — lagged pair counts, "
          "delta = (0, 1) ---")
    lag_fail, lag_marg_fail, lag_split_fail = [], [], []
    n_lagged = 0
    n_lagged_same = 0
    n_lag_splits = 0
    for label, names, _s0 in gen_pops:
        d = pop_data[label]
        lagged = {}
        for w in OFFSET_WINDOWS:
            for i in range(len(names)):
                for j in range(len(names)):
                    n_lagged += 1
                    if i == j:
                        n_lagged_same += 1
                    table = {(X, Y): 0 for X in STANDINGS
                             for Y in STANDINGS}
                    brute = {(X, Y): 0 for X in STANDINGS
                             for Y in STANDINGS}
                    for t in range(w[0], w[1]):
                        table[(d["stnd"][t][i],
                               d["stnd"][t + 1][j])] += 1
                        brute[(standing_body(d["states"][t][i]),
                               standing_body(
                                   d["states"][t + 1][j]))] += 1
                    lagged[(w, i, j)] = table
                    if table != brute and len(lag_fail) < 5:
                        lag_fail.append((label, w, names[i],
                                         names[j]))
                    si = d["singles"][(w, i)]
                    sj_shift = d["singles"][((w[0] + 1, w[1] + 1), j)]
                    marg_ok = all(
                        sum(table[(X, Y)] for Y in STANDINGS) == si[X]
                        for X in STANDINGS) and all(
                        sum(table[(X, Y)] for X in STANDINGS)
                        == sj_shift[Y] for Y in STANDINGS)
                    if not marg_ok and len(lag_marg_fail) < 5:
                        lag_marg_fail.append((label, w, names[i],
                                              names[j]))
        for (s, e) in OFFSET_WINDOWS:
            for m in range(s + 1, e):
                for i in range(len(names)):
                    for j in range(len(names)):
                        n_lag_splits += 1
                        whole = lagged[((s, e), i, j)]
                        left = lagged[((s, m), i, j)]
                        right = lagged[((m, e), i, j)]
                        if any(whole[c] != left[c] + right[c]
                               for c in whole) \
                                and len(lag_split_fail) < 5:
                            lag_split_fail.append(
                                (label, (s, e), m, names[i],
                                 names[j]))
    print(f"    lagged pair tables verified: {n_lagged} "
          f"(generated populations x offset windows x ordered "
          f"pairs, the second member read at tau + 1); of these, "
          f"same-body (i, i) lagged tables: {n_lagged_same}")
    print(f"    (offset window, split, ordered pair) instances "
          f"verified: {n_lag_splits}")
    for wit in lag_fail + lag_marg_fail + lag_split_fail:
        print(f"    witness: {wit}")
    check(not lag_fail,
          "(10) lagged pair counts (delta = (0, 1)) agree cell "
          "by cell with a brute-force recount from the raw "
          "trajectories, on every generated instance",
          f"{n_lagged} tables, including {n_lagged_same} "
          f"same-body (i, i) tables" if not lag_fail else
          f"first witnesses: {lag_fail}")
    check(not lag_marg_fail,
          "(10) lagged pair counts marginalize over the second "
          "member's standings (a partition) to the first "
          "member's own offset-0 count, and over the first "
          "member's standings to the second member's count over "
          "the shifted window",
          f"{n_lagged} tables" if not lag_marg_fail else
          f"first witnesses: {lag_marg_fail}")
    check(not lag_split_fail,
          "(10) lagged pair counts add over window splits, with "
          "the offsets held fixed",
          f"{n_lag_splits} instances" if not lag_split_fail else
          f"first witnesses: {lag_split_fail}")

    # --- Step 11 / check (11): conditional ratios -----------------------
    print("\n--- Step 11 / (11): conditional ratios "
          "(Proposition 5.9(iv)) ---")
    cond_answers = []
    for pi, (label, _names, _s0) in enumerate(witness_pops):
        d = pop_data[label]
        table = d["pairs"][(HEADLINE_WINDOW, 0, 1)]
        marg = d["singles"][(HEADLINE_WINDOW, 1)]["+"]
        joint = table[("+", "+")]
        cond = Fraction(joint, marg) if marg else None
        cond_answers.append(cond)
        direct_both = sum(1 for t in range(4)
                          if d["stnd"][t][0] == "+"
                          and d["stnd"][t][1] == "+")
        direct_marg = sum(1 for t in range(4)
                          if d["stnd"][t][1] == "+")
        print(f"    population {pi + 1} ({label}): J((B1, +), "
              f"(B2, +)) = {joint}, marginal(B2 = +) = {marg}, "
              f"P(B1 = + | B2 = +) = {joint}/{marg} = {cond} "
              f"(direct tally {direct_both}/{direct_marg})")
        check(cond == ORACLE_COND[pi] and direct_both == joint
              and direct_marg == marg,
              f"(11) oracle: P(B1 = + | B2 = +) for population "
              f"{pi + 1} == printed {ORACLE_COND[pi]}",
              f"computed {cond}")
    cond_fail = []
    n_cond = 0
    for label, names, _s0 in gen_pops:
        d = pop_data[label]
        for w in WINDOWS:
            for i in range(len(names)):
                for j in range(len(names)):
                    if i == j:
                        continue
                    table = d["pairs"][(w, i, j)]
                    raw = {(X, Y): 0 for X in STANDINGS
                           for Y in STANDINGS}
                    raw_marg = Counter()
                    for t in range(w[0], w[1]):
                        X = standing_body(d["states"][t][i])
                        Y = standing_body(d["states"][t][j])
                        raw[(X, Y)] += 1
                        raw_marg[Y] += 1
                    for X in STANDINGS:
                        for Y in STANDINGS:
                            marg = d["singles"][(w, j)][Y]
                            if marg == 0:
                                continue
                            n_cond += 1
                            cond = Fraction(table[(X, Y)], marg)
                            direct = Fraction(raw[(X, Y)],
                                              raw_marg[Y])
                            if cond != direct \
                                    and len(cond_fail) < 5:
                                cond_fail.append(
                                    (label, w, names[i], names[j],
                                     X, Y))
    print(f"    conditional-ratio instances verified on the "
          f"generated family (marginal nonzero): {n_cond}")
    for wit in cond_fail:
        print(f"    witness: {wit}")
    check(not cond_fail,
          "(11) on the generated family, wherever the marginal "
          "is nonzero, the conditional ratio joint / marginal "
          "computed from the pair table and the k = 1 counts "
          "equals the ratio computed by a direct raw-trajectory "
          "tally",
          f"{n_cond} instances" if not cond_fail else
          f"first witnesses: {cond_fail}")

    # --- Step 12 / check (12): planted mutants + meta-check -------------
    print("\n--- Step 12 / (12): PLANTED MUTANTS M1, M2, M3, M5 "
          "(each must be REJECTED, with witness) and the "
          "(C, F)-ONLY META-CHECK (former M4; not a mutant) ---")
    d1w = pop_data["AppendixD"]
    table1 = d1w["pairs"][(HEADLINE_WINDOW, 0, 1)]
    s_b1 = d1w["singles"][(HEADLINE_WINDOW, 0)]
    s_b2 = d1w["singles"][(HEADLINE_WINDOW, 1)]

    # M1: identity-blind estimator — Q7b's frequency estimated as
    # the product of the two bodies' separate class frequencies.
    est1 = Fraction(s_b1["+"], 4) * Fraction(s_b2["-"] + s_b2["0"], 4)
    d2w = pop_data["AppendixD_swap_names_0_1"]
    s2_b1 = d2w["singles"][(HEADLINE_WINDOW, 0)]
    s2_b2 = d2w["singles"][(HEADLINE_WINDOW, 1)]
    est2 = Fraction(s2_b1["+"], 4) * Fraction(s2_b2["-"] + s2_b2["0"], 4)
    print(f"    M1 witness: on population 1, freq(B1 positive) = "
          f"{s_b1['+']}/4 and freq(B2 not positive) = "
          f"{s_b2['-'] + s_b2['0']}/4, product = {est1}; the true "
          f"Q7b answer is {q7b_answers[0]}. (On population 2 the "
          f"product gives {est2} against a true {q7b_answers[1]}.)")
    check(est1 != q7b_answers[0],
          "M1 REJECTED: the identity-blind product estimator "
          "(pair frequency from the product of the two bodies' "
          "separate class frequencies) misanswers Q7b on "
          "witness population 1",
          f"estimator {est1} != true {q7b_answers[0]}")

    # M2: the honest unordered-pair count — for the unordered
    # pair {+, -} it returns J(+,-) + J(-,+) as the answer to
    # BOTH oriented questions. It is orientation-blind: on each
    # witness population it answers 1 to an oriented question
    # whose true answer is 0.
    table2 = d2w["pairs"][(HEADLINE_WINDOW, 0, 1)]
    u1 = table1[("+", "-")] + table1[("-", "+")]
    u2 = table2[("+", "-")] + table2[("-", "+")]
    print(f"    M2 witness (population 1): J(B1 = +, B2 = -) = "
          f"{table1[('+', '-')]}, J(B1 = -, B2 = +) = "
          f"{table1[('-', '+')]}; the unordered-pair count returns "
          f"{u1} for BOTH orientations — for the (-, +) question "
          f"whose true answer is {table1[('-', '+')]}")
    print(f"    M2 witness (population 2): J(B1 = +, B2 = -) = "
          f"{table2[('+', '-')]}, J(B1 = -, B2 = +) = "
          f"{table2[('-', '+')]}; the unordered-pair count returns "
          f"{u2} for BOTH orientations — for the (+, -) question "
          f"whose true answer is {table2[('+', '-')]}")
    check(u1 == 1 and u1 != table1[("-", "+")]
          and u2 == 1 and u2 != table2[("+", "-")],
          "M2 REJECTED: the unordered-pair count "
          "(J(+,-) + J(-,+) returned as the answer to both "
          "oriented questions) misanswers an oriented question "
          "on each witness population — it returns 1 for "
          "population 1's (-, +) question (true 0) and for "
          "population 2's (+, -) question (true 0)",
          f"pop 1: unordered {u1} != true (-, +) "
          f"{table1[('-', '+')]}; pop 2: unordered {u2} != "
          f"true (+, -) {table2[('+', '-')]}")

    # M3: binarized standings {positive, not-positive} — the
    # three-valued question J(B7 = -, B1 = +) on population 1.
    table_b7_b1 = d1w["pairs"][(HEADLINE_WINDOW, 6, 0)]
    true_m3 = table_b7_b1[("-", "+")]
    merged_m3 = table_b7_b1[("-", "+")] + table_b7_b1[("0", "+")]
    bin_table = {(r, c): sum(table_b7_b1[(X, Y)]
                             for X in (("+",) if r == "+"
                                       else ("-", "0"))
                             for Y in (("+",) if c == "+"
                                       else ("-", "0")))
                 for r in ("+", "not+") for c in ("+", "not+")}
    print(f"    M3 witness: on population 1, W = [0, 4), the "
          f"question J(B7 = -, B1 = +) has true count {true_m3}; "
          f"the binarized table's merged (not-positive, positive) "
          f"cell is {merged_m3} (= J(-, +) + J(0, +) = {true_m3} "
          f"+ {table_b7_b1[('0', '+')]}); binarized table: "
          f"{bin_table}")
    check(sum(bin_table.values()) == 4 and merged_m3 != true_m3,
          "M3 REJECTED: binarized standings {positive, "
          "not-positive} cannot return the three-valued answer "
          "J(B7 = -, B1 = +) — its merged cell differs from the "
          "true cell count",
          f"true {true_m3}, merged {merged_m3}")

    # M5: the window-shift tally — the joint count taken over
    # (t0 + 1, t1 + 1] in place of [t0, t1): the counted ticks
    # are t0 + 2 .. t1 + 1, not t0 .. t1 - 1.
    t0, t1 = HEADLINE_WINDOW
    shift_ticks = list(range(t0 + 2, t1 + 2))
    m5_table = {(X, Y): sum(1 for t in shift_ticks
                            if d1w["stnd"][t][0] == X
                            and d1w["stnd"][t][1] == Y)
                for X in STANDINGS for Y in STANDINGS}
    diff_cells = [(c, table1[c], m5_table[c]) for c in table1
                  if table1[c] != m5_table[c]]
    print(f"    M5 witness: on population 1 the true window is "
          f"[{t0}, {t1}) (ticks {list(range(t0, t1))}); the "
          f"window-shift tally counts over ({t0 + 1}, {t1 + 1}] "
          f"(ticks {shift_ticks}); differing cells "
          f"(cell, true, shifted): {diff_cells}; in particular "
          f"cell (+, -): true {table1[('+', '-')]}, shifted "
          f"{m5_table[('+', '-')]}")
    check(diff_cells and m5_table[("+", "-")] != table1[("+", "-")],
          "M5 REJECTED: the window-shift tally (joint count over "
          "(t0 + 1, t1 + 1] in place of [t0, t1)) misanswers the "
          "joint count on witness population 1 — its (+, -) cell "
          "differs from the true cell",
          f"true (+, -) {table1[('+', '-')]}, shifted "
          f"{m5_table[('+', '-')]}; {len(diff_cells)} cells differ")

    # META-CHECK (the former M4 label; not a planted mutant):
    # any purported joint frequency computed as a function of
    # the (C, F) data alone — G8's argument, computed.
    print(f"    META-CHECK witness: by check (3) the finest "
          f"(C, F) data of the two witness populations are "
          f"identical (census t = 0..4, flows t = 0..3), so any "
          f"function of (C, F) alone returns ONE value on both; "
          f"by check (4) the true Q7b answers are "
          f"{q7b_answers[0]} and {q7b_answers[1]} — two values")
    check(cens1 == cens2 and flows1 == flows2
          and q7b_answers[0] != q7b_answers[1],
          "(12) META-CHECK (former M4; not a planted mutant): "
          "no function of the census/flow data (C, F) alone computes the "
          "named-pair joint frequency — one input, two true "
          "answers (G8's argument, computed)")

    # --- Verdict -------------------------------------------------------
    print("\n" + "=" * 72)
    if FAILURES:
        print("A.12 VERDICT: FAIL — witnesses:")
        for f in FAILURES:
            print(f"  - {f}")
        return 1
    print(f"A.12 VERDICT: PASS — the §5 joint-count instrument, "
          f"generalized to named")
    print(f"  members of either kind, verifies: standing is total "
          f"over all 81 sigma")
    print(f"  states (positive {counts81['+']}, negative "
          f"{counts81['-']}, neutral {counts81['0']}), at body "
          f"level over {n_route} tested bodies,")
    print(f"  with phi (§8.7) the standings, merged; the G8 "
          f"witness recomputes —")
    print(f"  finest (C, F) identical across the B1<->B2 name-swap")
    print(f"  (census t = 0..4, flows t = 0..3) while Q7b's joint "
          f"answers differ,")
    print(f"  {q7b_answers[0]} (population 1) against "
          f"{q7b_answers[1]} (population 2), by standing tables")
    print(f"  and by direct phi tallies; the Q_J' witness "
          f"recomputes — every body class,")
    print(f"  every body standing and every body-tuple joint count "
          f"identical across")
    print(f"  the junction swap, while Q_J' differs, "
          f"{qj_answers[0]} (alpha) against")
    print(f"  {qj_answers[1]} (beta), by the member joint-count "
          f"route; marginalization")
    print(f"  holds on {n_instances} ordered-pair instances, "
          f"window additivity on")
    print(f"  {n_splits} split instances, k = 3 marginalization "
          f"on {n_triples} triple")
    print(f"  instances; lagged (offset) tables agree with raw "
          f"recounts on {n_lagged}")
    print(f"  instances (including {n_lagged_same} same-body "
          f"lagged), marginalize and add")
    print(f"  over splits ({n_lag_splits} split instances); "
          f"conditional ratios verify on")
    print(f"  the witness pair ({cond_answers[0]} and "
          f"{cond_answers[1]}) and on {n_cond} generated")
    print(f"  instances; the planted mutants M1, M2, M3 and M5 "
          f"(product estimator,")
    print("  unordered-pair count, binarized standings, "
          "window-shift tally) are")
    print("  rejected with witnesses, and the (C, F)-only "
          "meta-check (not a planted")
    print("  mutant) is computed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
