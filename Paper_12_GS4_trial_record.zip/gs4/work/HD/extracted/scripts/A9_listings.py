#!/usr/bin/env python3
"""A.9 — Embedded listings: the paper agrees with its own manifest
and unpacks to the runnable layout (Paper 12 Appendix C).

Machine companion to Paper 12 Appendix C. At build time the whole
verification suite (scripts A.1–A.15, FW.1, G.1, H.1 and the runner),
the four G.1 source texts, and the ESP v2.3 initiation text are
embedded INTO the paper itself, each as a fenced block wrapped in
HTML-comment markers, beside a manifest table that records, for
each embedded file, its path, its sha256, and its byte count. This
script is the checking side of that embedding protocol: it reads
one paper file, parses its manifest, extracts every embedded block,
reconstructs each embedded file's bytes from the block's lines,
and verifies that the paper agrees with itself and can be unpacked
to the layout the suite runs in. It is the suite's ninth script
in run order.

THE EMBEDDING PROTOCOL, as this script implements the checking
side. Each embedded file occupies one block: a header line, a blank
line, a BEGIN marker line, a fence line consisting only of backtick
characters, the file's own lines, a closing fence line identical to
the opening fence line, and an END marker line. A marker line is a
line whose stripped content is exactly an HTML comment opening with
the word BEGIN, then the word LISTING or the word SOURCE or the
word EXHIBIT, then a
colon, then the file's path, then the comment closer; the END
marker line's stripped content is exactly an HTML comment whose
whole content is the word END. The paths are of four families:
script files under the scripts directory (the nineteen files: the
fifteen A-series scripts, A1_counting.py through
A15_spine.py, FW1_firewall.py,
G1_quotes.py, H1_registry.py and run_all.py), source texts under
the sources directory (paper9.txt, paper10.txt, paper_11_v69.md
and paper_11_5_v26.md), the ESP text under the esp directory
(the ESP_v2.3_START_HERE.txt initiation text) — twenty-four
embedded files in Appendix C in total — plus the Appendix E
exhibit files under the battery directory, embedded in the
Appendix E span under EXHIBIT markers and manifested by that
appendix's own exhibit manifest. Every embedded file's text ends with exactly one
newline and contains no carriage return. Reconstruction is fixed:
the embedded bytes are the lines between the two fence lines,
joined with newline characters, with one final newline appended,
encoded as UTF-8. The fence rule is fixed: the fence length equals
the larger of three and one more than the longest run of backtick
characters occurring anywhere inside the embedded content. The
manifest table lives inside the Appendix C span — from the line
starting with the Appendix C heading to the next line starting
with a level-two heading, or to the end of the file (a
heading-shaped line inside an embedded block or another fenced
region is embedded content, not a paper heading, and does not
end the span; the manifest parse likewise reads only lines
outside blocks and fences) — and its
header row names the three columns Embedded file, sha256, Bytes;
a table row counts as a manifest row exactly when its first cell,
stripped, starts with one of that span's path families. The
exhibit manifest table lives likewise inside the Appendix E
span (from the line starting with the Appendix E heading), under
the same three column names, and a row of it counts as an exhibit
manifest row exactly when its first cell, stripped, starts with
the battery path family.

CHECKS (each printed PASS or FAIL, with witnesses on failure):
  (1) The paper is located: by default the Paper_12_v4.md file in
      the parent directory of this script's directory; a
      command-line argument overrides that path (the sibling
      scripts' convention).
  (2) The manifests are parsed from the Appendix C span and the
      Appendix E span, each against its own path families: at
      least
      one manifest row is present in each span present, every
      manifest row is well
      formed (a 64-hex-digit sha256 and an integer byte count),
      and no path appears twice.
  (3) Every marker block in the whole paper is extracted: every
      BEGIN marker is followed by its fence line, its closing
      fence line, and its END marker line; no block is
      unterminated (a failure names the block's path); no path
      is extracted twice; and every block lies inside one of the
      two spans, carrying a path of that span's families (a
      marker outside both spans, or a block whose path family
      disagrees with its span, is a failure naming the block).
  (4) Set equality: the extracted paths equal the manifest paths
      exactly (paths missing from the blocks and paths extra to
      the manifest are both named).
  (5) Per file: the sha256 of the reconstructed bytes equals the
      manifest sha256, and the reconstructed byte length equals
      the manifest byte count (a mismatch is named, with both
      values printed).
  (6) Fence-rule compliance per block: the fence length is
      recomputed from the block's content by the fixed fence
      rule, and a block whose fence disagrees is named.
  (7) Sibling comparison: for each embedded path, when the
      canonical file exists beside the paper (the paper's own
      directory joined with the embedded path), its bytes must
      equal the extracted bytes, and a mismatch fails. Absent
      siblings are printed as notes — the paper-alone mode — and
      are not failures.
  (8) Planted mutants, run in memory against this script's own
      functions, each of which must be REJECTED with a printed
      witness: M1, one character changed in one extracted block's
      content, after which the verification of that mutated copy
      reports that file's hash mismatch; and M2, an END marker
      line deleted from a copy of a paper's lines, after which
      extraction reports the unterminated block, naming the file.

INPUT_PROVENANCE:
  - The manifest tables and the embedded blocks:
    class=paper-defined (Paper 12 Appendix C and Appendix E;
    parsed at run time
    from the paper file under test; nothing about their contents
    is hardcoded in this script — no path list, hash, or byte
    count appears here as data).
  - The embedding protocol itself — the block layout, the marker
    forms, the reconstruction rule, and the fence rule:
    class=paper-defined (Paper 12 Appendix C, the protocol this
    script is the checking side of).
  - Sibling canonical files, when present beside the paper (the
    script files, the ESP text, and the source texts):
    class=paper-defined for the script files and the ESP text
    (Paper 12's own verification suite and initiation text);
    class=cited-paper for the source texts (the published Papers
    9, 10, 11 and 11.5 texts the suite quotes against).
  - The synthetic in-memory fixture of the mutant battery (one
    small synthetic block, its manifest row computed from its own
    declared content lines at run time):
    class=control (a test fixture built to the protocol; no
    synthetic value is a claim of the paper).
  - External data: none. This script reads only the paper file
    named on its command line (or its default) and, for check
    (7), the sibling files beside that paper. Nothing is fetched,
    and no value is taken from the environment.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: the paper artifact as a whole — the
      published Paper 12 document, whose Appendix C purports to
      carry byte-exact copies of the twenty-two files of the
      suite, the sources, and the ESP text, and whose Appendix E
      purports to carry byte-exact copies of the exhibit files
      under battery/.
  (2) Verified domain: the internal consistency of THIS paper
      file — its embedded bytes against its own manifest table —
      plus extractability: every embedded block in the file is
      well formed under the protocol and reconstructs, by the
      fixed reconstruction rule, to bytes that can be laid out
      at the embedded relative paths (the runnable layout).
  (3) Map: a paper file maps to the set of its reconstructed
      embedded files by span location (the Appendix C span and
      the Appendix E span),
      marker extraction, and the fixed reconstruction rule. The
      map preserves byte identity only: the sha256 and the byte
      count of each reconstructed file are compared against the
      paper's own recorded values for that file, and against a
      sibling file's bytes when a sibling is present; nothing
      else about a file — its meaning, its correctness, its
      provenance — is carried by the map.
  (4) Preserved: exactly the properties the Appendix C claim
      depends on — the presence of every manifested file as a
      well-formed block inside the span, the absence of any
      unmanifested block, the byte identity of each
      reconstruction with its manifest sha256 and byte count,
      the fence rule that makes each block parse unambiguously,
      and (when siblings are present) byte identity with the
      sibling files. Each is recomputed from the paper file at
      run time, never carried from any other run.
  (5) Outside the machine check: that the embedded bytes are
      the author's canonical files. This script proves the paper
      agrees with itself and can be unpacked; it does not prove
      the canonical identity of what was embedded. That identity
      is anchored, when the canonical tree is present beside the
      paper, by check (7)'s sibling comparison, and otherwise by
      the verification package (Paper_12_v4_verification_package.zip,
      which carries its own MANIFEST.sha256 listing the sha256 of
      every file it contains, this paper included — a copy is the
      package of this build when its enclosed files match that
      manifest) and by the published record. Also outside the
      check: that the suite's own checks are sound — that is each
      script's own docstring
      and coverage statement, not this script's — and that the
      manifest was honestly computed at build time, which no
      self-consistency check inside the artifact can establish;
      the package and the record anchor that.

SELF-REFERENCE DISCIPLINE: this script's own source is itself one
of the embedded files, so its text must never break the protocol
it checks. No line of this file, stripped, is a BEGIN marker or
an END marker, and no line of this file consists solely of
backtick characters; the docstring describes the markers in words
inside sentences, never as a bare marker on its own line, and the
code builds every marker string from pieces, so the full marker
form never stands alone on a line of the source. Ordinary code is
otherwise safe: the embedder computes each block's fence from the
longest backtick run in the content, so the single backtick
characters this script manipulates need only the minimum fence.

V4 ADJUSTMENT (2026-10-26, disclosed): the exhibit extension.
The default paper is now Paper_12_v4.md. A third marker kind,
EXHIBIT, is admitted beside LISTING and SOURCE, and the path
families gain the battery family. The paper is now read through
two manifested spans — the Appendix C span with its manifest
(rows whose first cell starts with the scripts, sources, or esp
family) and the Appendix E span with its own exhibit manifest
(rows whose first cell starts with the battery family); the span
finder takes the heading prefix, and the manifest parser takes
the span and the family tuple. Every block must lie inside one
of the two spans and carry a path of that span's families —
family/span agreement is enforced, with a violation named as an
error — and set equality, hash and byte verification, and the
fence checks run per span against that span's manifest, with the
printed output naming the span for each file. The sibling
comparison (7) is unchanged, and the planted mutants (8) are
unchanged (the synthetic fixture remains an Appendix C fixture).
The checks keep their (1)–(8) structure, and the SELF-REFERENCE
DISCIPLINE above is unchanged and still holds of this source.

ROUND-5 ADJUSTMENT (2026-10-28, disclosed): script A.13
(provenance formalization consistency, §0.4) joined the suite
with corrections round 5: the embedded set is now twenty-two
files — seventeen suite files (the thirteen A-series scripts,
FW.1, G.1, H.1 and the runner), the four source texts and the
ESP text. The protocol, the checks, and the mutant battery are
unchanged.

ROUND-6 ADJUSTMENT (2026-10-28, disclosed): scripts A.14
(population ordering key, §11.3) and A.15 (the Spine exhibits,
Appendix F) joined the suite with corrections round 6: the
embedded set is now twenty-four files — nineteen suite files
(the fifteen A-series scripts, FW.1, G.1, H.1 and the runner),
the four source texts and the ESP text. The protocol, the
checks, and the mutant battery are unchanged.
"""
import hashlib
import re
import sys
from pathlib import Path

FAILURES = []


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}"
          + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# The protocol constants. Every marker string is built from pieces,
# so no full marker ever stands alone on a line of this source (see
# SELF-REFERENCE DISCIPLINE in the docstring).
# ---------------------------------------------------------------------------

_BEGIN_HEAD = "<!-- BEGIN" + " "
_MARKER_TAIL = " " + "-->"
END_MARKER = "<!-- END" + _MARKER_TAIL
_BEGIN_PREFIXES = (
    ("LISTING", _BEGIN_HEAD + "LISTING: "),
    ("SOURCE", _BEGIN_HEAD + "SOURCE: "),
    ("EXHIBIT", _BEGIN_HEAD + "EXHIBIT: "),
)
_APPENDIX_C_FAMILIES = ("scripts/", "sources/", "esp/")
_APPENDIX_E_FAMILIES = ("battery/",)
_PATH_FAMILIES = _APPENDIX_C_FAMILIES + _APPENDIX_E_FAMILIES
_SHA256_RE = re.compile(r"[0-9a-fA-F]{64}")


def begin_line_for(kind, path):
    """The BEGIN marker line for one embedded file, assembled from
    pieces (kind is the word LISTING, the word SOURCE, or the
    word EXHIBIT)."""
    prefix = _BEGIN_HEAD + kind + ": "
    return prefix + path + _MARKER_TAIL


def parse_begin_marker(stripped):
    """(kind, path) if a stripped line is a BEGIN marker line, else
    None. The three admitted kinds are the LISTING form, the
    SOURCE form, and the EXHIBIT form described in the docstring."""
    for kind, prefix in _BEGIN_PREFIXES:
        if stripped.startswith(prefix) and stripped.endswith(_MARKER_TAIL):
            path = stripped[len(prefix):len(stripped) - len(_MARKER_TAIL)]
            path = path.strip()
            if path:
                return kind, path
            return None
    return None


def is_fence_text(stripped):
    """True iff a stripped line consists only of backtick
    characters and is at least three of them long."""
    return len(stripped) >= 3 and set(stripped) == {"`"}


def max_backtick_run(text):
    """The longest run of consecutive backtick characters in a
    text (zero when the text holds no backtick)."""
    best = 0
    run = 0
    for ch in text:
        if ch == "`":
            run += 1
            if run > best:
                best = run
        else:
            run = 0
    return best


def reconstruct_bytes(content_lines):
    """The fixed reconstruction: the lines between the fence
    lines, joined with newlines, one final newline appended,
    encoded as UTF-8."""
    return ("\n".join(content_lines) + "\n").encode("utf-8")


def expected_fence_length(content_lines):
    """The fixed fence rule: the larger of three and one more than
    the longest backtick run inside the content."""
    text = "\n".join(content_lines) + "\n"
    return max(3, max_backtick_run(text) + 1)


# ---------------------------------------------------------------------------
# The manifested spans (Appendix C and Appendix E) and the manifests
# ---------------------------------------------------------------------------

def find_appendix_span(lines, heading_prefix="## Appendix C."):
    """(start, end) line indices of the span opened by the given
    heading prefix (the Appendix C heading by default; the
    Appendix E heading for the exhibit span): from the
    line starting with that heading to the next line
    starting with a level-two heading, or to the end of the file.
    The span is start-inclusive and end-exclusive. None when no
    such heading exists. Heading-shaped lines inside a
    marker block or another fenced region are embedded content,
    not paper headings, and neither open nor close the span; the
    scan therefore tracks block and fence state, exactly as the
    extraction scan skips block interiors."""
    start = None
    in_block = False
    fence = None
    for i, ln in enumerate(lines):
        stripped = ln.strip()
        if in_block:
            if stripped == END_MARKER:
                in_block = False
            continue
        if fence is not None:
            if stripped == fence:
                fence = None
            continue
        if parse_begin_marker(stripped) is not None:
            in_block = True
            continue
        if is_fence_text(stripped):
            fence = stripped
            continue
        if ln.startswith(heading_prefix):
            start = i
            break
    if start is None:
        return None
    end = len(lines)
    in_block = False
    fence = None
    for j in range(start + 1, len(lines)):
        stripped = lines[j].strip()
        if in_block:
            if stripped == END_MARKER:
                in_block = False
            continue
        if fence is not None:
            if stripped == fence:
                fence = None
            continue
        if parse_begin_marker(stripped) is not None:
            in_block = True
            continue
        if is_fence_text(stripped):
            fence = stripped
            continue
        if lines[j].startswith("## "):
            end = j
            break
    return start, end


def parse_manifest(lines, span, families=_APPENDIX_C_FAMILIES):
    """Parse the manifest table inside the given span, admitting
    the given path families (the Appendix C families by default;
    the battery family for the Appendix E exhibit manifest).

    Returns (manifest, duplicates, malformed, row_count), where
    manifest maps a path to its (sha256, byte_count) pair,
    duplicates lists each path named by more than one manifest
    row, and malformed lists one witness string per manifest row
    whose sha256 or byte count is not of the required form. A
    table row counts as a manifest row exactly when its first
    cell, stripped, starts with one of the given path families.
    """
    manifest = {}
    duplicates = []
    malformed = []
    row_count = 0
    if span is None:
        return manifest, duplicates, malformed, row_count
    start, end = span
    in_block = False
    fence = None
    for idx in range(start, end):
        stripped = lines[idx].strip()
        if in_block:
            if stripped == END_MARKER:
                in_block = False
            continue
        if fence is not None:
            if stripped == fence:
                fence = None
            continue
        if parse_begin_marker(stripped) is not None:
            in_block = True
            continue
        if is_fence_text(stripped):
            fence = stripped
            continue
        if not stripped.startswith("|"):
            continue
        core = stripped[1:]
        if core.endswith("|"):
            core = core[:-1]
        cells = [c.strip() for c in core.split("|")]
        if not cells:
            continue
        first = cells[0]
        if not first.startswith(families):
            continue
        row_count += 1
        if first in manifest and first not in duplicates:
            duplicates.append(first)
        if len(cells) < 3:
            malformed.append(
                f"line {idx + 1}: manifest row for {first} has "
                f"{len(cells)} cell(s), three required")
            continue
        sha = cells[1].strip("`").strip()
        if not _SHA256_RE.fullmatch(sha):
            malformed.append(
                f"line {idx + 1}: manifest row for {first} carries "
                f"sha256 {cells[1]!r}, not 64 hex digits")
            continue
        count_text = cells[2].replace(",", "").strip("`").strip()
        try:
            byte_count = int(count_text)
        except ValueError:
            malformed.append(
                f"line {idx + 1}: manifest row for {first} carries "
                f"byte count {cells[2]!r}, not an integer")
            continue
        if byte_count < 0:
            malformed.append(
                f"line {idx + 1}: manifest row for {first} carries "
                f"a negative byte count {byte_count}")
            continue
        if first not in manifest:
            manifest[first] = (sha.lower(), byte_count)
    return manifest, duplicates, malformed, row_count


# ---------------------------------------------------------------------------
# Extraction of the marker blocks
# ---------------------------------------------------------------------------

def extract_blocks(lines, span=None, spans=None):
    """Extract every marker block from the whole paper.

    The manifested spans are given either as a single span (the
    span argument: one (start, end) pair, read as the Appendix C
    span with the Appendix C families — the form the mutant
    battery's Appendix C fixture uses) or as the spans argument:
    a list of (span label, (start, end) pair or None, families)
    triples, one per manifested span.

    Returns (blocks, errors, duplicates), where blocks maps a path
    to its record (kind, begin_line, fence, content_lines,
    end_line, span — line numbers 1-based; span is the label of
    the manifested span the block lies in, or None), errors lists
    one witness
    string per structural failure (an unterminated or malformed
    block, a block outside both manifested spans, or a block
    whose path family disagrees with its span; every witness
    names the block's path), and duplicates lists each path
    extracted more than once. A block whose BEGIN marker is not
    followed, in order, by a fence line, a closing fence line
    identical to the opening fence, and an END marker line on the
    very next line is unterminated and is not entered in blocks.
    Content lines are never scanned for markers: the scan resumes
    after a block's END marker line.
    """
    if spans is None:
        spans = [("Appendix C", span, _APPENDIX_C_FAMILIES)]
    blocks = {}
    errors = []
    duplicates = []
    i = 0
    while i < len(lines):
        parsed = parse_begin_marker(lines[i].strip())
        if parsed is None:
            i += 1
            continue
        kind, path = parsed
        begin_idx = i
        span_label = None
        span_families = None
        for label, one_span, families in spans:
            if one_span is not None and one_span[0] <= begin_idx < one_span[1]:
                span_label = label
                span_families = families
                break
        if span_label is None:
            errors.append(
                f"block for {path} at line {begin_idx + 1} lies "
                f"outside the Appendix C and Appendix E spans")
        elif not path.startswith(span_families):
            errors.append(
                f"block for {path} at line {begin_idx + 1} lies "
                f"inside the {span_label} span but its path "
                f"belongs to none of that span's families "
                f"{span_families} — family/span agreement "
                f"violation")
        if path in blocks and path not in duplicates:
            duplicates.append(path)
        if i + 1 >= len(lines) or not is_fence_text(lines[i + 1].strip()):
            found = ("end of file" if i + 1 >= len(lines)
                     else repr(lines[i + 1].strip()[:60]))
            errors.append(
                f"unterminated block for {path}: the BEGIN marker "
                f"at line {begin_idx + 1} is not followed by a "
                f"fence line (found {found})")
            i += 1
            continue
        fence = lines[i + 1].strip()
        close_idx = None
        for j in range(i + 2, len(lines)):
            if lines[j].strip() == fence:
                close_idx = j
                break
        if close_idx is None:
            errors.append(
                f"unterminated block for {path}: no closing fence "
                f"line follows the BEGIN marker at line "
                f"{begin_idx + 1}")
            i += 1
            continue
        if close_idx + 1 >= len(lines) \
                or lines[close_idx + 1].strip() != END_MARKER:
            found = ("end of file" if close_idx + 1 >= len(lines)
                     else repr(lines[close_idx + 1].strip()[:60]))
            errors.append(
                f"unterminated block for {path}: the closing "
                f"fence at line {close_idx + 1} is not followed "
                f"by an END marker line (found {found})")
            i = close_idx + 1
            continue
        if path not in blocks:
            blocks[path] = {
                "kind": kind,
                "begin_line": begin_idx + 1,
                "fence": fence,
                "content_lines": lines[i + 2:close_idx],
                "end_line": close_idx + 2,
                "span": span_label,
            }
        i = close_idx + 2
    return blocks, errors, duplicates


# ---------------------------------------------------------------------------
# Verification of extracted blocks against a manifest
# ---------------------------------------------------------------------------

def verify_against_manifest(blocks, manifest):
    """One witness string per (path, sha256) or (path, byte count)
    disagreement between the reconstructed bytes and the manifest,
    over the paths present on both sides. Set differences between
    the two sides are check (4)'s business, not this function's."""
    errors = []
    for path in sorted(set(blocks) & set(manifest)):
        want_sha, want_count = manifest[path]
        data = reconstruct_bytes(blocks[path]["content_lines"])
        got_sha = hashlib.sha256(data).hexdigest()
        if got_sha != want_sha:
            errors.append(
                f"{path}: sha256 mismatch — manifest {want_sha} "
                f"vs extracted {got_sha}")
        if len(data) != want_count:
            errors.append(
                f"{path}: byte count mismatch — manifest "
                f"{want_count} vs extracted {len(data)}")
    return errors


def verify_fences(blocks):
    """One witness string per block whose fence length disagrees
    with the fixed fence rule recomputed from its content."""
    errors = []
    for path in sorted(blocks):
        block = blocks[path]
        want = expected_fence_length(block["content_lines"])
        got = len(block["fence"])
        if got != want:
            errors.append(
                f"{path}: fence length {got} at line "
                f"{block['begin_line'] + 1} violates the fence "
                f"rule — the content's longest backtick run "
                f"requires a fence of length {want}")
    return errors


# ---------------------------------------------------------------------------
# Planted mutants (in memory, against this script's own functions)
# ---------------------------------------------------------------------------

_SYNTHETIC_PATH = "scripts/A1_counting.py"
_SYNTHETIC_CONTENT = [
    "sample alpha line",
    "sample beta line",
    "sample gamma line",
]


def synthetic_paper_lines():
    """A fresh synthetic paper, in memory: an Appendix C span
    holding a one-row manifest and one well-formed block for the
    synthetic path, the row's hash and count computed from the
    synthetic content by this script's own reconstruction."""
    data = reconstruct_bytes(_SYNTHETIC_CONTENT)
    sha = hashlib.sha256(data).hexdigest()
    fence = "`" * expected_fence_length(_SYNTHETIC_CONTENT)
    lines = [
        "## Appendix C. Embedded listings (synthetic fixture)",
        "",
        "| Embedded file | sha256 | Bytes |",
        "|---|---|---|",
        f"| {_SYNTHETIC_PATH} | {sha} | {len(data)} |",
        "",
        f"### Listing: {_SYNTHETIC_PATH}",
        "",
        begin_line_for("LISTING", _SYNTHETIC_PATH),
        fence,
        *_SYNTHETIC_CONTENT,
        fence,
        END_MARKER,
        "",
        "## Appendix D. Following matter (synthetic fixture)",
        "",
    ]
    return lines


def mutant_battery():
    """M1 and M2, each run against this script's own parsing,
    extraction, and verification functions on in-memory copies.
    Each mutant must be REJECTED — M1 by a reported hash mismatch
    naming the file, M2 by a reported unterminated block naming
    the file — with the witness printed."""
    print("\n--- Step 8: PLANTED MUTANT BATTERY (each must be "
          "REJECTED, with witness) ---")

    # Control: the unmutated synthetic paper must extract and
    # verify cleanly, or the battery's rejections mean nothing.
    base_lines = synthetic_paper_lines()
    base_span = find_appendix_span(base_lines)
    base_manifest, _, _, _ = parse_manifest(base_lines, base_span)
    base_blocks, base_errors, _ = extract_blocks(base_lines, base_span)
    control_ok = (
        not base_errors
        and _SYNTHETIC_PATH in base_blocks
        and _SYNTHETIC_PATH in base_manifest
        and not verify_against_manifest(base_blocks, base_manifest)
        and not verify_fences(base_blocks))
    check(control_ok,
          "mutant-battery control: the unmutated synthetic paper "
          "extracts and verifies cleanly",
          f"extraction errors: {base_errors}" if base_errors else
          "the battery's rejections below are credited against "
          "this control")

    # M1 — one character changed in the extracted block's content.
    mutated_lines = list(_SYNTHETIC_CONTENT)
    first = mutated_lines[0]
    replacement = "X" if not first.startswith("X") else "Y"
    mutated_lines[0] = replacement + first[1:]
    mutated_blocks = {path: dict(block) for path, block
                      in base_blocks.items()}
    mutated_blocks[_SYNTHETIC_PATH]["content_lines"] = mutated_lines
    m1_report = verify_against_manifest(mutated_blocks, base_manifest)
    m1_witness = [e for e in m1_report
                  if e.startswith(_SYNTHETIC_PATH)
                  and "sha256 mismatch" in e]
    print(f"    witness: the first character of "
          f"{_SYNTHETIC_PATH}'s content, {first[0]!r}, is changed "
          f"to {replacement!r} in a copy of the extracted block; "
          f"verification of the mutated copy reports: {m1_report}")
    check(bool(m1_witness),
          "M1: one character changed in an extracted block's "
          "content is REJECTED — verification reports that file's "
          "sha256 mismatch, naming the file")

    # M2 — the END marker line deleted from a copy of the lines.
    m2_lines = synthetic_paper_lines()
    end_idx = next(i for i, ln in enumerate(m2_lines)
                   if ln.strip() == END_MARKER)
    del m2_lines[end_idx]
    m2_span = find_appendix_span(m2_lines)
    _m2_blocks, m2_errors, _m2_dups = extract_blocks(m2_lines, m2_span)
    m2_witness = [e for e in m2_errors
                  if _SYNTHETIC_PATH in e and "unterminated" in e]
    print(f"    witness: the END marker line (line {end_idx + 1} "
          f"of the synthetic copy) is deleted; extraction of the "
          f"mutated copy reports: {m2_errors}")
    check(bool(m2_witness),
          "M2: a deleted END marker line is REJECTED — extraction "
          "reports the unterminated block, naming the file")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def resolve_paper_path(argv):
    """Check (1)'s path rule: a command-line argument overrides
    the default — the Paper_12_v4.md file in the parent directory
    of this script's directory."""
    if argv:
        return Path(argv[0])
    return Path(__file__).resolve().parent.parent / "Paper_12_v4.md"


def main():
    print("=" * 72)
    print("A.9 — EMBEDDED LISTINGS: MANIFEST, EXTRACTION AND BYTE")
    print("  IDENTITY (Paper 12 Appendices C and E; the paper agrees")
    print("   with its own manifests and unpacks to the runnable layout)")
    print("=" * 72)

    paper_path = resolve_paper_path(sys.argv[1:])

    # --- Step 1: the paper is located --------------------------------
    print("\n--- Step 1: paper location ---")
    located = paper_path.is_file()
    check(located, "(1) paper located", str(paper_path))
    if not located:
        print("\n" + "=" * 72)
        print(f"A.9 VERDICT: FAIL — paper not found: {paper_path}")
        print("=" * 72)
        return 1
    try:
        paper_text = paper_path.read_bytes().decode("utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        check(False, "(1) paper read as UTF-8", f"{type(exc).__name__}: {exc}")
        print("\n" + "=" * 72)
        print("A.9 VERDICT: FAIL — the paper could not be read as "
              "UTF-8 text")
        print("=" * 72)
        return 1
    lines = paper_text.splitlines()
    print(f"    paper: {paper_path} ({len(lines)} lines)")

    span_specs = [
        ("Appendix C", find_appendix_span(lines, "## Appendix C."),
         _APPENDIX_C_FAMILIES),
        ("Appendix E", find_appendix_span(lines, "## Appendix E."),
         _APPENDIX_E_FAMILIES),
    ]
    span_c = span_specs[0][1]
    for label, one_span, _families in span_specs:
        if one_span is not None:
            print(f"    {label} span: lines {one_span[0] + 1}–"
                  f"{one_span[1]} of the paper")
        else:
            print(f"    {label} span: no line starting with the "
                  f"{label} heading was found")

    # --- Step 2: the manifests ---------------------------------------
    print("\n--- Step 2: manifest tables (Appendix C and "
          "Appendix E spans) ---")
    check(span_c is not None,
          "(2) Appendix C span found (the line starting with the "
          "Appendix C heading, to the next level-two heading)")
    if span_specs[1][1] is None:
        print("    NOTE — Appendix E span absent: no exhibit "
              "manifest is parsed in this run (a paper carrying "
              "no Appendix E, as the pre-v4 assemblies do); the "
              "Appendix E legs below are skipped, not passed, and "
              "the Appendix C checks are unaffected.")
    manifests = {}
    for label, one_span, families in span_specs:
        if one_span is None:
            manifests[label] = {}
            continue
        manifest, manifest_dups, manifest_malformed, row_count = \
            parse_manifest(lines, one_span, families)
        manifests[label] = manifest
        check(row_count >= 1,
              f"(2) manifest parsed [{label}]: at least one "
              f"manifest row in the {label} span",
              f"{row_count} manifest row(s) found")
        for path in manifest_dups:
            print(f"    witness: duplicate manifest path {path} "
                  f"[{label}]")
        for witness in manifest_malformed:
            print(f"    witness: malformed manifest row [{label}] "
                  f"— {witness}")
        check(not manifest_dups and not manifest_malformed,
              f"(2) manifest [{label}] has no duplicate paths and "
              f"no malformed rows",
              f"duplicates: {manifest_dups}; malformed: "
              f"{len(manifest_malformed)}" if manifest_dups
              or manifest_malformed else
              f"{len(manifest)} distinct path(s)")
        for path in sorted(manifest):
            sha, count = manifest[path]
            print(f"    manifest [{label}]: {path} — sha256 "
                  f"{sha[:16]}…, {count} bytes")

    # --- Step 3: extraction ------------------------------------------
    print("\n--- Step 3: extraction of the marker blocks ---")
    blocks, extract_errors, extract_dups = extract_blocks(
        lines, spans=span_specs)
    for witness in extract_errors:
        print(f"    witness: {witness}")
    for path in extract_dups:
        print(f"    witness: duplicate extracted path {path}")
    check(not extract_errors,
          "(3) every BEGIN marker has its fence line, closing "
          "fence line and END marker line; no unterminated block; "
          "every block lies inside one of the two spans and "
          "carries a path of that span's families",
          f"{len(extract_errors)} structural failure(s)" if
          extract_errors else f"{len(blocks)} block(s) extracted")
    check(not extract_dups,
          "(3) no path is extracted twice",
          f"duplicates: {extract_dups}" if extract_dups else
          "all extracted paths distinct")
    for path in sorted(blocks):
        block = blocks[path]
        print(f"    extracted [{block['span']}]: {path} — BEGIN "
              f"at line {block['begin_line']}, "
              f"{len(block['content_lines'])} content line(s), "
              f"END at line {block['end_line']}")

    # --- Step 4: set equality, per span ------------------------------
    print("\n--- Step 4: extracted paths vs manifest paths "
          "(per span) ---")
    for label, one_span, _families in span_specs:
        if one_span is None:
            print(f"    NOTE — {label} span absent: set equality "
                  f"for that span is not evaluated in this run.")
            continue
        span_paths = {p for p, b in blocks.items()
                      if b["span"] == label}
        manifest = manifests[label]
        missing = sorted(set(manifest) - span_paths)
        extra = sorted(span_paths - set(manifest))
        check(not missing and not extra,
              f"(4) set equality [{label}]: extracted paths == "
              f"manifest paths",
              (f"missing from the blocks: {missing}; extra to "
               f"the manifest: {extra}") if missing or extra else
              f"{len(span_paths)} path(s) on both sides")

    # --- Step 5: hashes and byte counts, per span --------------------
    print("\n--- Step 5: per-file sha256 and byte count (per span) ---")
    for label, one_span, _families in span_specs:
        if one_span is None:
            print(f"    NOTE — {label} span absent: hash and byte "
                  f"verification for that span is not evaluated "
                  f"in this run.")
            continue
        manifest = manifests[label]
        span_blocks = {p: b for p, b in blocks.items()
                       if b["span"] == label}
        hash_errors = verify_against_manifest(span_blocks, manifest)
        for witness in hash_errors:
            print(f"    witness: {witness}")
        common = set(span_blocks) & set(manifest)
        if not common:
            check(False,
                  f"(5) per-file sha256 and byte count verified "
                  f"[{label}]",
                  "no file is present on both sides — nothing to "
                  "verify (see Steps 2–4)")
        else:
            check(not hash_errors,
                  f"(5) per-file sha256 and byte count [{label}]: "
                  f"every reconstructed file matches its manifest "
                  f"sha256 and byte count",
                  f"{len(hash_errors)} mismatch(es) over "
                  f"{len(common)} file(s)" if hash_errors else
                  f"{len(common)} file(s) verified byte for byte")

    # --- Step 6: fence rule, per span --------------------------------
    print("\n--- Step 6: fence-rule compliance (per span) ---")
    for label, one_span, _families in span_specs:
        if one_span is None:
            print(f"    NOTE — {label} span absent: fence checks "
                  f"for that span are not evaluated in this run.")
            continue
        span_blocks = {p: b for p, b in blocks.items()
                       if b["span"] == label}
        fence_errors = verify_fences(span_blocks)
        for witness in fence_errors:
            print(f"    witness: {witness}")
        if not span_blocks:
            check(False,
                  f"(6) fence-rule compliance per block [{label}]",
                  "no block was extracted — nothing to verify")
        else:
            check(not fence_errors,
                  f"(6) fence-rule compliance [{label}]: every "
                  f"block's fence length equals the larger of "
                  f"three and one more than the longest backtick "
                  f"run in its content",
                  f"{len(fence_errors)} violation(s)" if fence_errors
                  else f"{len(span_blocks)} block(s) compliant")

    # --- Step 7: sibling comparison ----------------------------------
    print("\n--- Step 7: sibling comparison (canonical files beside "
          "the paper) ---")
    sibling_errors = []
    compared = 0
    for path in sorted(blocks):
        sibling = paper_path.parent / path
        if not sibling.is_file():
            print(f"    NOTE — paper-alone mode: no sibling file "
                  f"at {sibling}; {path} is anchored by the "
                  f"manifest alone in this run")
            continue
        compared += 1
        data = reconstruct_bytes(blocks[path]["content_lines"])
        sibling_bytes = sibling.read_bytes()
        if sibling_bytes != data:
            sibling_errors.append(
                f"{path}: sibling bytes ({len(sibling_bytes)} "
                f"bytes, sha256 "
                f"{hashlib.sha256(sibling_bytes).hexdigest()}) "
                f"differ from the extracted bytes ({len(data)} "
                f"bytes, sha256 "
                f"{hashlib.sha256(data).hexdigest()})")
    for witness in sibling_errors:
        print(f"    witness: {witness}")
    check(not sibling_errors,
          "(7) sibling comparison: every canonical file present "
          "beside the paper equals its extracted bytes",
          f"{len(sibling_errors)} mismatch(es)" if sibling_errors
          else f"{compared} sibling(s) compared, "
               f"{len(blocks) - compared} absent (notes above)")

    # --- Step 8: planted mutants -------------------------------------
    mutant_battery()

    print("\n" + "=" * 72)
    if FAILURES:
        print(f"A.9 VERDICT: FAIL — {len(FAILURES)} check(s) "
              f"failed: {FAILURES}")
        print("=" * 72)
        return 1
    print("A.9 VERDICT: PASS — the manifests and the embedded blocks")
    print(f"  of {paper_path.name} agree exactly: {len(blocks)} "
          f"embedded file(s) extracted")
    print("  from the manifested spans (Appendix C, and Appendix E "
          "where present), each byte-identical to its manifest sha256")
    print("  and byte count, each fence compliant with the fence "
          "rule, every")
    print("  sibling file present beside the paper byte-identical "
          "to its block;")
    print("  both planted mutants rejected with witnesses.")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
