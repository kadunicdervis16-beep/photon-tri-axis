#!/usr/bin/env python3
"""A.2 — The aggregate tick is well-defined, Paper 12 §4.

Machine companion to Paper 12 §4 (Definition 4.1, Theorem 4.2,
Proposition 4.3). Implements Paper 11's junction operator T exactly as
Paper 12 §4 states it, and COMPUTES the theorem's steps:

  T (Paper 11 §7.5, via Paper 12 §4): a junction's local state is a pair
  of port vectors (A, B) over the junction's port set. Index k is
  ADMISSIBLE iff A[k] = −B[k] ≠ 0. T zeroes the CANONICALLY FIRST
  admissible pair (A[k*], B[k*]); if none is admissible, T is the
  identity (fixed point). τ(σ) = Σ_k (A[k]² + B[k]²) drops by exactly 2
  per action (admissible entries are unit port values, a² = 1).

Checks:
  (1) WELL-DEFINEDNESS (Theorem 4.2): parallel application — T applied
      at every junction from the tick-start state — equals EVERY
      sequential order of the same junctions: all permutations for
      populations of ≤ 5 junctions, random orders beyond.
      Locality (proof Step 1) is also computed, not assumed — and the
      check is DISCRIMINATING (loop remediation, RT-2a): an operator Op
      on populations passes the locality check iff output block j is
      invariant under arbitrary replacement of all other blocks. The
      battery asserts BOTH directions: the canonical parallel tick
      PASSES, and a deliberately NON-LOCAL operator (block j's output
      reads block j+1's entries) FAILS, with a printed witness. The
      earlier form of this check — call the per-block function on block
      j alone and observe it cannot see the other blocks — passed for
      ANY pure per-block function, including nonsense ones; it is
      replaced, not merely supplemented.
  (2) τ ACCOUNTING (Proposition 4.3): Δτ_agg = −2 × (number of acting
      junctions), exactly, on every tested population; τ_agg never
      increases.
  (3) TOTALITY + DETERMINISM: T is defined on EVERY local state of
      port-vector length 1, 2, 3 (exhaustive: 9 + 81 + 729 states over unit port
      values {−1, 0, +1}), is a pure function (same input → same
      output), satisfies the per-action τ rule on every state, and
      fixes exactly the states with no admissible index.
  (4) SCOPE CONTROL (Definition 4.1's scope paragraph; correction,
      2026-10-27, re-keyed by the corrections loop pass): a declared
      population containing a junction of THREE OR MORE SIDES must be
      ROUTED by the declared rule — T is never called on it, and its
      presented data are carried through the tick unchanged (T_agg's
      value at such a junction) — never silently processed. The
      routing variable is the SIDE COUNT, derived from the presented
      data themselves (the length of the junction's presented tuple);
      no caller-supplied label is trusted. The control below runs a
      mixed population (pairwise junctions plus one three-sided
      junction) through declared_tick, asserts the three-sided
      junction is routed with its presented data untouched and that
      T's call count equals the number of pairwise junctions, and
      asserts rejection — each by a NAMED conjunct, with witnesses
      printed — of three cheats: a silent mutant (processes the
      junction and reports nothing routed), a route-and-process
      mutant (reports the routing honestly but rewrites the data —
      rejected by the guard's data-identity conjunct alone), and a
      fixed-bait processing cheat (calls T where T changes nothing:
      the guard cannot see it — that limit is PRINTED — and the
      call-count check rejects it).

TERMINOLOGY (correction, 2026-10-27; re-keyed by the corrections
loop pass): three different counts must not be fused. (i)
"Port-vector length" (σ-length) in this script is the number of
canonical positions in ONE SIDE of a junction's local state
σ = (A, B) — Paper 11 §7.5's number of canonical positions of a
pairwise junction. (ii) The SIDE COUNT of a junction is the number
of configurations converged at it — two for a pairwise junction,
three or more for a multi-sided one; THIS is Definition 4.1's
scope variable (Paper 11 §7.5 scopes T to pairwise junctions and
glosses the excluded case as three configurations converging at
one meeting point). (iii) Junction arity k_j (Paper 11 §4.1) is
the number of PORTS a junction consumes — a third count, equal to
the side count only when each side consumes exactly one port, as
at Paper 12 §3.4's aggregate (a) (three sides, k_j = 3) and
§11.2's atom β (internal junction of junction arity 3, one port per
participating atom); §11.2 clause (ii) allows a two-sided junction
to consume more than one port at a configuration, where the
counts part. Every local state in this script's main path is the
state of a single PAIRWISE junction, whatever its port-vector
length; no state there is, or models, a multi-sided junction, and
T is never applied to one (check (4)).

SCOPE COVERAGE (corrections loop pass, EA-2): the scope control's
declared_tick is the DECLARED-POPULATION entry point — the one
place a population may present junctions of more than two sides.
The main checking path's populations (checks (1)–(3)) are tuples
of pairwise local states σ = (A, B) by construction: a junction
of more than two sides is INEXPRESSIBLE there, not merely
unguarded. parallel_tick is unchanged by the correction.

Population model: a population state is a tuple of junction local
states; by Port-Partition Exactness (Paper 11 §4.3) the junctions' port
sets are pairwise disjoint, so each junction owns its block.

COVERAGE DISCLOSURE (loop remediation, RT-2a — exactly what is computed
here): disjointness itself remains the CITED Paper 11 §4.3 premise; this
script does NOT prove it. What the script computes is (a) the
CONSEQUENCES of disjointness — order-independence of the parallel tick
and the exact Δτ accounting — on generated populations, and (b) the
GUARD: every generated population in the main checking path is asserted
through validate_disjoint (each junction assigned its consecutive port
block), and a main-path NEGATIVE CONTROL runs a shared-port population
(J1 = {0}, J2 = {0, 1}) through the global-port-table tick, where it
must exhibit order-dependence AND be rejected by validate_disjoint.
(Mutant M2 repeats that witness inside the battery.)

INPUT_PROVENANCE:
  - T's definition (admissibility A[k] = −B[k] ≠ 0; zero the canonically
    first admissible pair; fixed point if none): class=cited-paper
    (Paper 11 §7.5, as restated in Paper 12 §4).
  - τ(σ) = Σx² and the per-action drop of exactly 2: class=cited-paper
    (Paper 11 §7.5).
  - Port values restricted to unit values {−1, 0, +1}: class=cited-paper
    (Paper 12 §4: "a ≠ 0 a unit port value, so a² = 1" — the drop of
    exactly 2 is stated for this domain; no other values are tested,
    and none are claimed).
  - Pairwise-disjoint port sets across a population's junctions:
    class=cited-paper (Paper 11 §4.3, Port-Partition Exactness).
  - Aggregate tick = T at every established pairwise junction
    (Definition 4.1's scope); a junction of more than two sides is
    carried through the tick unchanged; τ_agg = Σ_j τ(σ_j):
    class=paper-defined (Paper 12 §4, Definition 4.1 and its scope
    paragraph).
  - Exhaustive port-vector-length bound (≤ 3), permutation bound
    (≤ 5 junctions), random-order counts, generated state
    distributions: class=control (test design; the theorem itself
    is port-vector-length- and size-free).
  - The scope control's routing rule (two-sided junctions under T;
    a junction of three or more sides routed — T never called on
    it, its presented data carried through unchanged — with the
    side count derived from the presented tuple's length):
    class=paper-defined (Paper 12 §4, Definition 4.1's scope
    paragraph; the routed junction's own dynamics are Paper 11
    §7.6's routing, outside T_agg and not computed here). The
    exhibited populations (mixed pairwise/three-sided, fixed-bait,
    only-multi-sided): class=control (test design).
  - The loud refusal of a presented tuple of fewer than two sides
    (not a junction): class=control (the entry point's own input
    hygiene; no paper text defines a sub-2-side junction, and the
    refusal asserts nothing about one).
  - RNG seed 20261024: class=arbitrary-representative.
"""
import itertools
import random
import sys

FAILURES = []
VALUES = (-1, 0, 1)


def check(ok, label, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)
    return ok


# ---------------------------------------------------------------------------
# Paper 11's operator T, exactly as Paper 12 §4 states it
# ---------------------------------------------------------------------------

def admissible_indices(sigma):
    A, B = sigma
    return [k for k in range(len(A)) if A[k] == -B[k] != 0]


def tau(sigma):
    A, B = sigma
    return sum(a * a for a in A) + sum(b * b for b in B)


def T(sigma):
    """Zero the canonically first admissible pair; identity if none."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[0]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


def T_last(sigma):
    """MUTANT M1: zero the LAST admissible pair instead of the first —
    a violation of §4's canonical-first rule."""
    A, B = sigma
    idx = admissible_indices(sigma)
    if not idx:
        return (tuple(A), tuple(B))
    k = idx[-1]
    A2 = list(A); B2 = list(B)
    A2[k] = 0; B2[k] = 0
    return (tuple(A2), tuple(B2))


# ---------------------------------------------------------------------------
# Populations over disjoint port blocks
# ---------------------------------------------------------------------------

def parallel_tick(state, op=T):
    """T_agg: every junction's action computed from the tick-start state."""
    return tuple(op(s) for s in state)


def sequential_tick(state, order, op=T):
    """Apply op junction by junction in the given order."""
    st = list(state)
    for j in order:
        st[j] = op(st[j])
    return tuple(st)


def acting_count(state):
    return sum(1 for s in state if admissible_indices(s))


def tau_agg(state):
    return sum(tau(s) for s in state)


def random_sigma(rng, plen):
    return (tuple(rng.choice(VALUES) for _ in range(plen)),
            tuple(rng.choice(VALUES) for _ in range(plen)))


def random_population(rng, n_junctions):
    return tuple(random_sigma(rng, rng.randint(1, 3)) for _ in range(n_junctions))


# ---------------------------------------------------------------------------
# Port-block assignment + the disjointness guard, wired into the main path
# (validate_disjoint itself is defined below, with the port-sharing model;
# Python resolves it at call time.)
# ---------------------------------------------------------------------------

DISJOINT_ASSERTIONS = [0]  # populations passed through the guard, main path


def population_port_sets(state):
    """Assign each junction its consecutive block of global port ids:
    junction j owns ports [base, base + plen_j), plen_j the
    junction's port-vector length. Pairwise disjoint by
    construction — the guard below VERIFIES that on every population
    the main path generates, rather than trusting the construction."""
    sets, base = [], 0
    for A, _B in state:
        sets.append(list(range(base, base + len(A))))
        base += len(A)
    return sets


def assert_disjoint(state):
    """Main-path guard: every generated population passes through
    validate_disjoint; a failure here is a hard error, not a soft check."""
    assert validate_disjoint(population_port_sets(state)), \
        f"generated population failed the disjointness guard: {state}"
    DISJOINT_ASSERTIONS[0] += 1


# ---------------------------------------------------------------------------
# DISCRIMINATING locality check (RT-2a): an operator Op on populations is
# LOCAL iff output block j is invariant under arbitrary replacement of all
# other blocks. Asserted in BOTH directions below: the canonical parallel
# tick passes; a deliberately non-local operator fails, with witness.
# ---------------------------------------------------------------------------

def canonical_global(state):
    """The aggregate tick of Definition 4.1, as an operator on populations."""
    return parallel_tick(state, T)


def nonlocal_global(state):
    """DELIBERATELY NON-LOCAL operator (battery control): junction j's
    output READS junction j+1's block — if the next junction has an
    admissible index, j's own action is suppressed (its block returned
    unchanged); otherwise j acts as T. Output block j therefore depends
    on block j+1's entries, and the locality check must catch it."""
    n = len(state)
    out = []
    for j in range(n):
        if admissible_indices(state[(j + 1) % n]):
            out.append(state[j])            # suppressed by the neighbour
        else:
            out.append(T(state[j]))
    return tuple(out)


def block_invariant(global_op, state, j, perturbed):
    """True iff global_op's output block j is the same on state and on
    perturbed (which may differ from state only outside block j)."""
    return global_op(state)[j] == global_op(perturbed)[j]


def locality_check(global_op, rng, trials=500):
    """Returns (ok, witness, n_validated). witness is None iff ok.
    Every population generated here also passes the disjointness guard."""
    for _ in range(trials):
        state = random_population(rng, rng.randint(2, 4))
        assert_disjoint(state)
        j = rng.randrange(len(state))
        perturbed = list(state)
        for j2 in range(len(state)):
            if j2 != j:
                perturbed[j2] = random_sigma(rng, len(state[j2][0]))
        perturbed = tuple(perturbed)
        if not block_invariant(global_op, state, j, perturbed):
            return False, (state, perturbed, j,
                           global_op(state)[j], global_op(perturbed)[j]), \
                DISJOINT_ASSERTIONS[0]
    # Constructed witness pair, so the verdict never rests on the RNG
    # happening to flip the relevant bit: both blocks admissible; the
    # perturbation disarms block 1 only.
    state = (((1,), (-1,)), ((1,), (-1,)))
    perturbed = (((1,), (-1,)), ((0,), (0,)))
    assert_disjoint(state)
    if not block_invariant(global_op, state, 0, perturbed):
        return False, (state, perturbed, 0,
                       global_op(state)[0], global_op(perturbed)[0]), \
            DISJOINT_ASSERTIONS[0]
    return True, None, DISJOINT_ASSERTIONS[0]


# ---------------------------------------------------------------------------
# (3) Totality, determinism, per-action τ rule — exhaustive small states
# ---------------------------------------------------------------------------

def exhaustive_local():
    print("\n--- (3) T: TOTALITY / DETERMINISM / τ RULE (exhaustive) ---")
    total_states = 0
    for plen in (1, 2, 3):
        n_checked = 0
        for flat in itertools.product(VALUES, repeat=2 * plen):
            sigma = (flat[:plen], flat[plen:])
            out1 = T(sigma)          # totality: must not raise
            out2 = T(sigma)          # determinism: pure function
            assert out1 == out2, f"T not deterministic on {sigma}"
            assert len(out1[0]) == plen and len(out1[1]) == plen
            assert all(v in VALUES for v in out1[0] + out1[1])
            idx = admissible_indices(sigma)
            if idx:
                assert tau(out1) == tau(sigma) - 2, \
                    f"τ rule violated on {sigma}: {tau(sigma)} -> {tau(out1)}"
                # exactly the first admissible pair zeroed, nothing else moved
                expA, expB = list(sigma[0]), list(sigma[1])
                expA[idx[0]] = 0; expB[idx[0]] = 0
                assert out1 == (tuple(expA), tuple(expB)), \
                    f"T moved the wrong entries on {sigma}"
            else:
                assert out1 == sigma, f"T moved a fixed point {sigma}"
            n_checked += 1
        total_states += n_checked
        print(f"    port-vector length {plen}: {n_checked} local states exhausted")
    check(True, f"T total, deterministic, τ-exact on all {total_states} "
                f"local states of port-vector length 1–3",
          "9 + 81 + 729 states; fixed points are exactly the states with "
          "no admissible index")


# ---------------------------------------------------------------------------
# (1) + (2) Parallel == sequential; Δτ_agg accounting
# ---------------------------------------------------------------------------

def well_definedness():
    print("\n--- (1) PARALLEL == EVERY SEQUENTIAL ORDER (Theorem 4.2) ---")
    rng = random.Random(20261024)

    # Step 1 of the proof, computed — DISCRIMINATING form (RT-2a): the
    # locality property is a property of an operator on populations
    # (output block j invariant under arbitrary replacement of all other
    # blocks), and the battery asserts both directions.
    loc_ok, _w, _n = locality_check(canonical_global, rng, trials=500)
    check(loc_ok, "locality: canonical parallel tick — output block j "
                  "invariant under arbitrary replacement of all other "
                  "blocks (500 perturbation trials + constructed pair)")
    nl_ok, nl_witness, _n2 = locality_check(nonlocal_global, rng, trials=500)
    if nl_witness is not None:
        st, pt, jj, out_a, out_b = nl_witness
        print(f"    non-local witness: state {st}, block {jj}; perturbed "
              f"state {pt}")
        print(f"    output block {jj}: {out_a} on state vs {out_b} on "
              f"perturbed — INVARIANCE VIOLATED, as required")
    check(not nl_ok, "locality check has teeth: a deliberately NON-LOCAL "
                     "operator (block j reads block j+1) FAILS the same "
                     "check, with the witness printed above")

    # All permutations, ≤ 5 junctions.
    trials_small = 60
    perms_tested = 0
    all_ok = True
    tau_ok = True
    for _ in range(trials_small):
        nj = rng.randint(1, 5)
        state = random_population(rng, nj)
        assert_disjoint(state)
        par = parallel_tick(state)
        for order in itertools.permutations(range(nj)):
            perms_tested += 1
            if sequential_tick(state, order) != par:
                all_ok = False
                print(f"    DIVERGENCE at order {order} on state {state}")
                break
        if tau_agg(par) - tau_agg(state) != -2 * acting_count(state):
            tau_ok = False
    check(all_ok, f"parallel == sequential for every order "
                  f"({trials_small} populations, {perms_tested} permutations, ≤5 junctions)")

    # Random orders beyond 5 junctions.
    trials_big = 40
    orders_tested = 0
    big_ok = True
    for _ in range(trials_big):
        nj = rng.randint(6, 8)
        state = random_population(rng, nj)
        assert_disjoint(state)
        par = parallel_tick(state)
        for _ in range(200):
            order = list(range(nj))
            rng.shuffle(order)
            orders_tested += 1
            if sequential_tick(state, tuple(order)) != par:
                big_ok = False
                print(f"    DIVERGENCE at order {order} on state {state}")
                break
        if tau_agg(par) - tau_agg(state) != -2 * acting_count(state):
            tau_ok = False
    check(big_ok, f"parallel == sequential on random orders "
                  f"({trials_big} populations of 6–8 junctions, {orders_tested} orders)")

    print("\n--- (2) Δτ_agg = −2 × ACTING JUNCTIONS (Proposition 4.3) ---")
    check(tau_ok, "Δτ_agg = −2·|acting| exactly on every population above; "
                  "τ_agg never increases")
    check(True, f"disjointness guard wired into the main path: "
                f"validate_disjoint asserted on all "
                f"{DISJOINT_ASSERTIONS[0]} populations generated above "
                f"(locality trials + permutation trials)")


# ---------------------------------------------------------------------------
# Disjointness validator (the premise guard) and port-sharing model
# ---------------------------------------------------------------------------

def validate_disjoint(junction_port_sets):
    """Port-Partition premise guard: port sets must be pairwise disjoint.
    Returns True/False; the tick machinery requires True."""
    seen = set()
    for ps in junction_port_sets:
        if seen & set(ps):
            return False
        seen |= set(ps)
    return True


def global_tick(state_pairs, junction_ports_in_order):
    """Apply T junction by junction over a GLOBAL port table, where
    state_pairs[p] = (x_p, y_p) is the pair of side-values at port p and
    each junction scans ITS OWN port list in canonical order, zeroing
    its first admissible port. Used only for mutant M2, whose junctions
    share a port — the situation Port-Partition Exactness forbids."""
    st = dict(state_pairs)
    for ports in junction_ports_in_order:
        for p in ports:
            x, y = st[p]
            if x == -y != 0:
                st[p] = (0, 0)
                break
    return st


def negative_control():
    """MAIN-PATH NEGATIVE CONTROL (RT-2a): a shared-port population run
    through the parallel-tick machinery (global port table) must exhibit
    order-dependence AND be rejected by validate_disjoint — here in the
    main check sequence, not only inside the mutant battery."""
    print("\n--- NEGATIVE CONTROL (main path): SHARED PORT ---")
    j1 = [0]          # junction 1 owns port 0
    j2 = [0, 1]       # junction 2 owns ports 0 and 1 — SHARES port 0
    shared_state = {0: (1, -1), 1: (1, -1)}   # both ports admissible
    end_12 = global_tick(shared_state, [j1, j2])   # J1 first, then J2
    end_21 = global_tick(shared_state, [j2, j1])   # J2 first, then J1
    print(f"    shared-port state {shared_state}: order J1,J2 -> {end_12}; "
          f"order J2,J1 -> {end_21}")
    check(end_12 != end_21,
          "shared-port population IS order-dependent under the tick "
          "machinery (the parallel tick is not well-defined there)",
          "p1 is zeroed in one order and survives in the other")
    check(validate_disjoint([j1, j2]) is False,
          "validate_disjoint REJECTS the shared-port population in the "
          "main path", "J1 = {0}, J2 = {0, 1} share port 0")
    check(validate_disjoint([[0], [1, 2]]) is True,
          "validate_disjoint still ACCEPTS a genuinely disjoint "
          "population (guard not trivially rejecting)")


# ---------------------------------------------------------------------------
# (4) SCOPE CONTROL (Definition 4.1's scope paragraph): a junction of
# three or more SIDES in a declared population is ROUTED — T is never
# called on it, and its presented data are carried through the tick
# unchanged (T_agg's value at it) — never silently processed. The side
# count is DERIVED from the presented data (the length of the
# junction's presented tuple); no caller-supplied label is trusted.
# ---------------------------------------------------------------------------

def declared_tick(junctions, op=None):
    """The aggregate tick of Definition 4.1 WITH its scope paragraph.
    A declared population is a list of presented junctions; each
    junction is the tuple of its sides' port vectors. Two sides —
    presented = σ = (A, B): T applies. Three or more sides: T does
    not apply (Paper 11 §7.5 scopes T to pairwise junctions); the
    junction is ROUTED — its presented data are carried through the
    tick unchanged, which is T_agg's value at it — and its own
    dynamics are Paper 11 §7.6's routing, outside T_agg and NOT
    computed here (the carried data are not a computed next state).
    Returns (new_junctions, routed_indices). op, if given, is called
    as op(sigma) at each pairwise junction (the control uses it to
    count T's calls); the default is T itself. A presented tuple of
    fewer than two sides is not a junction and is refused loudly."""
    apply_op = T if op is None else op
    out, routed = [], []
    for idx, presented in enumerate(junctions):
        sides = len(presented)
        if sides == 2:
            out.append(tuple(apply_op(tuple(presented))))
        elif sides >= 3:
            routed.append(idx)
            out.append(tuple(presented))
        else:
            raise ValueError(f"a presented tuple of {sides} side(s) "
                             f"is not a junction")
    return out, routed


def scope_guard(before, after, routed):
    """The declared rule as a checkable guard: the record has the
    same length as the population; every junction of three or more
    sides in `before` appears in `routed`, and its presented data in
    `after` are identical to `before` (T_agg's carry-through value).
    Pairwise junctions are unconstrained here — their tick is checks
    (1)–(3)'s business. KNOWN LIMIT, printed by the battery: the
    guard inspects data and the routing report only; a processing
    call that changes nothing (fixed bait) is invisible to it and is
    caught by the battery's call-count check instead."""
    if len(before) != len(after):
        return False
    routed = set(routed)
    for idx, presented in enumerate(before):
        if len(presented) >= 3:
            if idx not in routed:
                return False
            if tuple(after[idx]) != tuple(presented):
                return False
    return True


def silent_tick(junctions):
    """MUTANT (scope battery): process a multi-sided junction
    SILENTLY — flatten its first two sides into a pairwise σ and
    apply T, as if Definition 4.1 had no scope paragraph. Returns
    the junctions with the multi-sided junction's data rewritten
    and NOTHING routed."""
    out = []
    for presented in junctions:
        if len(presented) == 2:
            out.append(tuple(T(tuple(presented))))
        else:
            A, B = presented[0], presented[1]
            nA, nB = T((tuple(A), tuple(B)))
            out.append((nA, nB) + tuple(presented[2:]))
    return out


def processing_tick(junctions, op=None):
    """CHEAT (scope battery): report the routing HONESTLY but process
    the multi-sided junction anyway — apply the operator to its
    first two sides. On acting bait this rewrites the routed
    junction's data (the guard's data conjunct must reject it ALONE);
    on fixed bait it changes nothing (the guard cannot see it; the
    call count must reject it)."""
    apply_op = T if op is None else op
    out, routed = [], []
    for idx, presented in enumerate(junctions):
        if len(presented) == 2:
            out.append(tuple(apply_op(tuple(presented))))
        else:
            routed.append(idx)
            A, B = presented[0], presented[1]
            nA, nB = apply_op((tuple(A), tuple(B)))
            out.append((nA, nB) + tuple(presented[2:]))
    return out, routed


def scope_control():
    print("\n--- (4) SCOPE CONTROL: MULTI-SIDED JUNCTION ROUTED, "
          "NEVER SILENTLY PROCESSED ---")
    # Declared population: two pairwise junctions (one acting, one at
    # a fixed point) and one THREE-SIDED junction whose first two
    # sides present an admissible pair — the bait for silent
    # processing: a scope-blind tick would zero that pair.
    acting = ((1,), (-1,))
    fixed = ((0,), (0,))
    triple = ((1,), (-1,), (1,))     # three sides, one port each
    population = [acting, triple, fixed]

    calls = [0]

    def counting_T(sigma):
        calls[0] += 1
        return T(sigma)

    after, routed = declared_tick(population, op=counting_T)
    print(f"    declared population: [{acting}, {triple}, {fixed}] "
          f"(side counts derived from the presented data: 2, 3, 2)")
    print(f"    declared_tick -> pairwise end states {after[0]}, "
          f"{after[2]}; routed indices {routed}; T called "
          f"{calls[0]} time(s)")
    print("    disclosure: the routed junction's after-data are its "
          "presented data carried through — T_agg's value there — "
          "not a computed next state; its §7.6 dynamics are not "
          "computed by this script or claimed by the paper.")
    check(routed == [1],
          "the three-sided junction is ROUTED by the declared rule "
          "(index 1; its dynamics are Paper 11 §7.6's routing, "
          "outside T_agg)", "Definition 4.1's scope paragraph")
    check(calls[0] == 2,
          "T was called exactly once per pairwise junction and never "
          "on the three-sided junction", f"calls = {calls[0]}")
    check(after[1] == triple and after[0] == ((0,), (0,))
          and after[2] == fixed,
          "routed junction's presented data carried through "
          "unchanged; pairwise junctions ticked (acting junction's "
          "pair zeroed, fixed point carried)")
    check(scope_guard(population, after, routed),
          "scope guard ACCEPTS the declared tick's record")

    # Two-tick persistence: routing holds at every tick, and the
    # pairwise evolution is the ordinary one.
    after2, routed2 = declared_tick(after, op=counting_T)
    check(routed2 == [1] and after2[1] == triple
          and after2[0] == ((0,), (0,)) and calls[0] == 4,
          "second tick: the three-sided junction is routed again "
          "with its data still unchanged; the pairwise junctions "
          "rest", f"routed = {routed2}, calls = {calls[0]}")

    # A population of only multi-sided junctions: everything routes,
    # T is never called, and the record is the presented data.
    solo_after, solo_routed = declared_tick([triple],
                                            op=counting_T)
    check(solo_routed == [0] and solo_after == [triple]
          and calls[0] == 4,
          "only-multi-sided population: routed wholesale, T never "
          "called, after-data identical to the presented data "
          "(carried, not computed)")

    # A presented tuple of fewer than two sides is refused loudly.
    try:
        declared_tick([((1,),)])
        refused = False
    except ValueError:
        refused = True
    check(refused, "a presented tuple of one side is REFUSED loudly "
                   "(ValueError), not processed")

    # The guard returns False — does not raise — on a short record.
    check(not scope_guard(population, after[:2], routed),
          "scope guard REJECTS a truncated record (length mismatch) "
          "without raising")

    # Cheat 1 — the silent mutant must be rejected by the guard.
    mut_after = silent_tick(population)
    print(f"    silent mutant -> three-sided junction's data "
          f"rewritten to {mut_after[1]}, routed = []")
    check(mut_after[1] != triple,
          "the silent mutant really does process the three-sided "
          "junction (its first admissible pair is zeroed) — the "
          "witness bites")
    check(not scope_guard(population, mut_after, []),
          "scope guard REJECTS the silent mutant's record: a "
          "multi-sided junction processed without routing fails "
          "the declared rule")

    # Cheat 2 — route-and-process on ACTING bait: the routing report
    # is honest, so the guard's DATA conjunct alone must reject it
    # (the conjuncts are isolated: routed == [1] holds here).
    cheat_after, cheat_routed = processing_tick(population)
    print(f"    route-and-process cheat -> routed report "
          f"{cheat_routed} (honest), three-sided data rewritten to "
          f"{cheat_after[1]}")
    check(cheat_routed == [1]
          and not scope_guard(population, cheat_after, cheat_routed),
          "scope guard REJECTS the route-and-process record on the "
          "data-identity conjunct ALONE (routing report was honest)")

    # Cheat 3 — fixed bait: the cheat calls T on a three-sided
    # junction whose first two sides are at a fixed point, so the
    # data do not move and the guard ACCEPTS the record. That is the
    # guard's known limit, printed here, not hidden: the battery's
    # call-count check is the conjunct that rejects this cheat.
    fixed_triple = ((0,), (0,), (1,))
    fb_population = [acting, fixed_triple, fixed]
    fb_calls = [0]

    def fb_counting(sigma):
        fb_calls[0] += 1
        return T(sigma)

    fb_after, fb_routed = processing_tick(fb_population,
                                          op=fb_counting)
    print(f"    fixed-bait cheat -> guard verdict on its record: "
          f"{scope_guard(fb_population, fb_after, fb_routed)}; "
          f"operator calls: {fb_calls[0]} (pairwise junctions: 2)")
    check(scope_guard(fb_population, fb_after, fb_routed)
          and fb_calls[0] == 3,
          "fixed-bait cheat: the guard accepts its record (DISCLOSED "
          "limit — data and routing cannot see a call that changes "
          "nothing) and the CALL-COUNT check rejects it: 3 calls "
          "for 2 pairwise junctions")


def mutants():
    print("\n--- MUTANT BATTERY (each must be REJECTED, with witness) ---")
    caught = 0
    total = 0

    # M1 — last-pair variant (violates canonical-first).
    total += 1
    witness = ((1, 1), (-1, -1))  # two admissible indices: 0 and 1
    can = T(witness)
    mut = T_last(witness)
    diverges = (can != mut)
    print(f"    witness state σ = {witness}: canonical T -> {can}; "
          f"last-pair T' -> {mut}")
    # Honest sub-check: is T' itself order-dependent ACROSS junctions?
    # Under disjoint blocks, any purely local deterministic rule commutes,
    # so T' is expected to remain order-independent across junctions —
    # its violation is against the canonical-first SPEC, not against
    # commutation. Verified computationally:
    rng = random.Random(20261024)
    tlast_order_ok = True
    for _ in range(30):
        state = random_population(rng, rng.randint(2, 5))
        par = parallel_tick(state, op=T_last)
        for order in itertools.permutations(range(len(state))):
            if sequential_tick(state, order, op=T_last) != par:
                tlast_order_ok = False
    print(f"    sub-check: T' across disjoint junctions is "
          f"{'still order-independent' if tlast_order_ok else 'ORDER-DEPENDENT'} "
          f"(disjointness forces commutation for any local rule; T' is "
          f"caught as a spec violation — wrong end states — not as an "
          f"order-dependence). The genuine order-dependence witness is M2.")
    ok = diverges
    caught += ok
    print(f"  [{'CAUGHT' if ok else 'NOT CAUGHT — INVESTIGATE'}] M1: last-pair "
          f"variant diverges from canonical T on the witness state "
          f"(end states differ in which pair survives)")

    # M2 — port sharing: two junctions sharing port p0 breaks
    # well-definedness; the disjointness validator must catch it.
    total += 1
    j1 = [0]          # junction 1 owns port 0
    j2 = [0, 1]       # junction 2 owns ports 0 and 1 — SHARES port 0
    guard_ok = (validate_disjoint([j1, j2]) is False)
    guard_ok_disjoint = (validate_disjoint([[0], [1, 2]]) is True)
    # Divergence witness: p0 = (1, −1), p1 = (1, −1), both admissible.
    shared_state = {0: (1, -1), 1: (1, -1)}
    end_12 = global_tick(shared_state, [j1, j2])   # J1 first, then J2
    end_21 = global_tick(shared_state, [j2, j1])   # J2 first, then J1
    # J1->J2: J1 zeroes p0; J2's first admissible is now p1 -> zeroes p1.
    # J2->J1: J2 zeroes p0 (its first); J1 then has nothing admissible.
    div = (end_12 != end_21)
    print(f"    shared-port state {shared_state}: order J1,J2 -> {end_12}; "
          f"order J2,J1 -> {end_21}")
    print(f"    disjointness validator on [{{0}}, {{0,1}}]: "
          f"{'REJECTED' if guard_ok else 'ACCEPTED — GUARD FAILED'}; "
          f"on genuinely disjoint [{{0}}, {{1,2}}]: "
          f"{'accepted' if guard_ok_disjoint else 'REJECTED — GUARD BROKEN'}")
    ok = div and guard_ok and guard_ok_disjoint
    caught += ok
    print(f"  [{'CAUGHT' if ok else 'NOT CAUGHT — INVESTIGATE'}] M2: port-sharing "
          f"junctions break well-definedness (end state depends on order: "
          f"p1 survives in one order, is zeroed in the other; Δτ differs "
          f"by 2) and are caught by the disjointness check")

    check(caught == total, f"mutants rejected: {caught}/{total}")


def main():
    print("=" * 70)
    print("A.2 — AGGREGATE TICK WELL-DEFINEDNESS (Paper 12 §4)")
    print("=" * 70)
    exhaustive_local()
    well_definedness()
    negative_control()
    scope_control()
    mutants()
    print("\n" + "=" * 70)
    if FAILURES:
        print(f"A.2 VERDICT: FAIL — {len(FAILURES)} check(s) failed: {FAILURES}")
        print("=" * 70)
        return 1
    print("A.2 VERDICT: PASS — parallel tick equals every sequential order;")
    print("  Δτ_agg = −2 × acting junctions exactly; T total and deterministic")
    print("  on the exhaustive local state space; a junction of three or")
    print("  more sides is routed, never silently processed; mutants rejected")
    print("  with witnesses.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
