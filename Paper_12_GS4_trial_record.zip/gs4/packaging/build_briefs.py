#!/usr/bin/env python3
"""GS-4 Gold v1.0 -- examiner brief builder (spec sections 5.2, 2.2).

Each brief = coordinator furniture (procedural only) + verbatim spec
slices in the section 5.2 order: section 1, the examiner's own charter
(section 6 intro + role block), section 3 (Arm H only), section 7.3,
section 9, section 14. Also writes the common packet extract
(section 1 + 7.3 + 9 + 14). Certifies each brief: sha256 + a grep over
the section 2.2 exclusion tripwires, reported for the freeze record.
"""
import hashlib, re, sys
from pathlib import Path

GS4 = Path(sys.argv[1])
spec = (GS4 / "GS4_GOLD_SPEC.md").read_text().split("\n")
def sl(a, b):  # 1-based inclusive slice of spec lines
    return "\n".join(spec[a - 1:b])

S1 = sl(23, 67); S3 = sl(142, 220); S73 = sl(489, 501)
S9 = sl(573, 658); S14 = sl(865, 890); S6INTRO = sl(331, 340)
CHARTER = {"A": sl(341, 355), "B": sl(356, 375), "C": sl(376, 414), "D": sl(415, 450)}
PAPER_HASH = "fc0499af5d32bd9a6adf3ab77aca598e8647adffb92f5e1c5e780d8c1f473150"
BASE = str(GS4)

(GS4 / "packet" / "protocol_examiner_extract.md").write_text(
    "# PROTOCOL EXTRACT (common part: spec sections 1, 7.3, 9, 14)\n\n" + S1 + "\n\n" + S73 + "\n\n" + S9 + "\n\n" + S14 + "\n")

FINDING_FORMAT = """
COORDINATOR FURNITURE -- DELIVERABLE FORMAT (procedural only)
Your submission is a single Markdown file, SUBMISSION.md, in your
submission directory, plus any witness artifacts (code, outputs) in the
same directory. File every finding as a discrete block in exactly this
shape (the routing step extracts blocks mechanically; argument text is
never edited downstream):

### FINDING <n> -- <short title>
- Target claim: <claim ID and section>
- Exact target text: <quoted, with line numbers in the frozen paper>
- Domain and required property: <...>
- Sources used: <packet files, with the hashes you recomputed>
- Method and complete test space: <...>
- Witness / artifacts: <file names in your submission directory, or the textual witness pair>
- Coverage map: (1) native domain: ... (2) verified domain: ... (3) map between them: ... (4) what the map preserves: ... (5) what stays outside: ...
- Category (self-classified, spec section 9.5): <A|B|C|D|E>
- Proposed badge: <HELD|BROKE|LIMIT|OUTSIDE>
- Reason: <...>

Material that is not a finding (workbooks, derivations, graphs, run logs,
tables) goes in clearly headed sections of SUBMISSION.md outside the
FINDING blocks. Close the submission with a PROCESS STATUS section using
only the process vocabulary of spec section 9.4 (READ / NOT READ,
RUN / NOT RUN, REPRODUCED / NOT REPRODUCED, SOURCE-VERIFIED /
SOURCE-REPORTED, per item). Your last act: compute the SHA-256 of every
file you wrote in your submission directory and list them in your final
reply to the coordinator. Do not write anywhere else.
"""

RULES = f"""
COORDINATOR FURNITURE -- YOUR WORKING RULES (procedural only)
- The frozen paper is {BASE}/packet/Paper_12_v4.md, SHA-256 {PAPER_HASH}.
  Verify that hash yourself before relying on the file.
- You may read ONLY: your brief, the files in {BASE}/packet/ (the frozen
  paper, protocol_examiner_extract.md, paper2_section11.txt, paper9.txt,
  paper10.txt, paper_11_v69.md, paper_11_5_v26.md, sample_selection.txt),
  and your own submission directory. Role C additionally receives
  {BASE}/packet/roleC_only/blind_claims.md. Role D additionally uses its
  own clean work directory {BASE}/work/<ARM><ROLE>/ for extraction and runs.
- You may NOT open any other file on this machine, consult the web, or
  look for any other record of this paper or its history. The paper's own
  version history, inside the frozen paper, is part of your object.
- The twelve-claim sample is recorded in packet/sample_selection.txt.
- Write your submission only to the submission directory named in your
  tasking message.
"""

certs = {}
for arm in ("N", "H"):
    for role in ("A", "B", "C", "D"):
        parts = [f"# EXAMINER BRIEF -- ARM {arm}, ROLE {role}\n",
                 "GS-4 Gold v1.0 (house execution, two-arm isolated-context trial).\n",
                 RULES.replace("<ARM>", arm).replace("<ROLE>", role),
                 S1, "", S6INTRO, "", CHARTER[role]]
        if arm == "H":
            parts += ["", S3]
        parts += ["", S73, "", S9, "", S14, "", FINDING_FORMAT]
        text = "\n".join(parts) + "\n"
        d = GS4 / "briefs" / f"{arm}{role}"
        d.mkdir(parents=True, exist_ok=True)
        (d / "brief.md").write_text(text)
        certs[f"{arm}{role}"] = hashlib.sha256(text.encode()).hexdigest()

TRIPWIRES = ["GS-1", "GS-2", "GS-3", "KD-1", "GROK", "DS-12", "LOOP_ADJUDICATION",
             "dossier", "paste kit", "send kit", "author's list"]
print("brief hashes:")
for k, v in certs.items():
    print(f"  {k}: {v}")
print("tripwire scan over briefs (must be all zero except spec-inherent text):")
for arm in ("N", "H"):
    for role in ("A", "B", "C", "D"):
        t = (GS4 / "briefs" / f"{arm}{role}" / "brief.md").read_text()
        hits = {w: t.count(w) for w in TRIPWIRES if t.count(w)}
        print(f"  {arm}{role}: {hits if hits else 'clean'}")
