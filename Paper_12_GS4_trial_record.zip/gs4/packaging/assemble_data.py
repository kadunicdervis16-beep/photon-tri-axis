#!/usr/bin/env python3
"""GS-4 Gold v1.0 -- report data assembly (coordinator mechanics, post-unblinding).

Parses KEY_SEALED.md + GS4_ADJUDICATION_BLIND.md and emits attributed
tables for GS4_REPORT.md: per-card attributed record, per-arm proposed
and adjudicated arithmetic, per-claim side-by-side groupings. No
judgments are made here; every value is copied from the sealed records.
"""
import re, json
from pathlib import Path

GS4 = Path(__file__).resolve().parent.parent
key = {}
for line in (GS4 / "adjudication" / "KEY_SEALED.md").read_text().split("\n"):
    m = re.match(r"\| (GS4-F-\d+) \| ([NH]) \| ([A-D]) \| (.*?) \| ([0-9a-f]{64}) \|", line)
    if m:
        key[m.group(1)] = {"arm": m.group(2), "role": m.group(3), "header": m.group(4)}

adj_text = (GS4 / "adjudication" / "GS4_ADJUDICATION_BLIND.md").read_text()
cards = {}
for m in re.finditer(r"### (GS4-F-\d+)\n(.*?)(?=\n### GS4-F-|\n## Tally)", adj_text, re.S):
    body = m.group(2)
    def field(name):
        mm = re.search(rf"- \*\*{name}:\*\* (.*)", body)
        return mm.group(1).strip().strip("*").strip() if mm else ""
    cards[m.group(1)] = {
        "target": field("Target claim"),
        "selfcat": field("Self-classified category")[:1],
        "vercat": field("Verified category")[:1],
        "proposed": field("Proposed badge"),
        "adjudicated": field("Adjudicated badge"),
        "evidence": field("Evidence summary"),
    }

assert set(cards) == set(key), (len(cards), len(key))

def tally(rows, k):
    out = {}
    for r in rows:
        out[r[k]] = out.get(r[k], 0) + 1
    return out

rows = []
for cid in sorted(cards):
    r = dict(cards[cid]); r.update(key[cid]); r["card"] = cid
    rows.append(r)

print("== PER-ARM PROPOSED ==")
for arm in ("N", "H"):
    sub = [r for r in rows if r["arm"] == arm]
    print(arm, "cards:", len(sub), "proposed:", tally(sub, "proposed"), "adjudicated:", tally(sub, "adjudicated"))
print("== PER-ROLE (arm) PROPOSED BROKE counts ==")
for arm in ("N", "H"):
    for role in ("A", "B", "C", "D"):
        sub = [r for r in rows if r["arm"] == arm and r["role"] == role]
        print(f"{arm}/{role}: {len(sub)} cards, proposed {tally(sub, 'proposed')}")
print("== OVERALL ADJUDICATED ==", tally(rows, "adjudicated"))
print("== ADJUDICATED BY VERIFIED CATEGORY ==")
for cat in "ABCDE":
    sub = [r for r in rows if r["vercat"] == cat]
    print(cat, len(sub), tally(sub, "adjudicated"))
print("== RE-CATEGORIZED ==")
for r in rows:
    if r["selfcat"] != r["vercat"]:
        print(r["card"], r["arm"] + "/" + r["role"], r["selfcat"], "->", r["vercat"], "|", r["target"][:80])
print("== BROKE (proposed or adjudicated) ==")
for r in rows:
    if r["proposed"] == "BROKE" or r["adjudicated"] == "BROKE":
        print(r["card"], r["arm"] + "/" + r["role"], "prop", r["proposed"], "-> adj", r["adjudicated"],
              "cat", r["selfcat"], "->", r["vercat"], "|", r["target"][:100])
print("== ADJUDICATED LIMIT, category A or B (defect-class) ==")
for r in rows:
    if r["adjudicated"] == "LIMIT" and r["vercat"] in "AB":
        print(r["card"], r["arm"] + "/" + r["role"], "cat", r["vercat"], "|", r["target"][:110])
print("== JSON dump written ==")
(GS4 / "adjudication" / "assembly_data.json").write_text(json.dumps(rows, indent=1))
print(len(rows), "rows")
