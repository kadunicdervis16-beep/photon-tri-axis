#!/usr/bin/env python3
"""GS-4 Gold v1.0 -- deterministic sample selection (spec section 7).

Implements section 7.2 category assignment and section 7.3 dependency
centrality mechanically over the frozen paper's Appendix B registry and
claim lists. Operationalizations (recorded here, in the open):
- A claim's "home section" is read from its claim ID (L<section>.<n>-P12);
  LD./LC./LE. claims are appendix claims with no body home section.
- Dependency/pricing text for a claim = its Appendix B row short form plus
  its claim-list entry text (where one exists).
- An edge X->Y exists when X's dependency text names claim Y (Y != X).
  Outbound edges to conditions (C23-C33), receipts ("Receipt n"), and
  source-paper premises ("Paper N ..." references and [Depends: ...]
  flags) are recorded in the edge list; the centrality score uses exactly
  the three components section 7.3 names: inbound edges from other claims
  + inbound edges from falsification conditions (a condition whose text
  names the claim) + outbound edges to source-paper premises (counted as
  distinct (Paper, section) targets plus Depends flags).
- Category rules (section 7.2, first match wins): (i) hybrid badge string
  in the registry row -> hybrid pool; (ii) home section 11 -> ordering /
  composition pool; (iii) home section in {5,7,8,9} -> counting /
  statistical pool; (iv) author-declaration pool if the registry badge is
  exactly [LEVEL A: AUTHOR], or the claim text carries a "declared
  identification" or opens as a programme/declaration statement;
  (v) otherwise native definition/theorem pool.
- Quotas filled in the order: hybrid (2), author-declaration (1),
  ordering/composition (2), counting/statistical (3), native (4).
  Ranking inside a pool: centrality desc, ties by claim ID ascending.
"""
import re, sys, json
from pathlib import Path

PAPER = Path(sys.argv[1])
OUT = Path(sys.argv[2])

lines = PAPER.read_text(errors="replace").split("\n")
CLAIM_RE = re.compile(r"^(L\d+\.\d+|LD\.\d+|LC\.\d+|LE\.\d+)-P12$")
ID_IN_TEXT = re.compile(r"\b(L\d+\.\d+|LD\.\d+|LC\.\d+|LE\.\d+)-P12\b")
COND_RE = re.compile(r"\bC(2[3-9]|3[0-3])\b")

# --- Appendix B region
b_start = next(i for i, l in enumerate(lines) if l.startswith("## Appendix B"))
b_end = next(i for i, l in enumerate(lines) if i > b_start and l.startswith("## Appendix C"))

rows = {}   # claim_id -> dict(badge, script, text)
for l in lines[b_start:b_end]:
    if l.startswith("| L"):
        cells = [c.strip() for c in l.strip().strip("|").split("|")]
        if len(cells) >= 5 and CLAIM_RE.match(cells[0]):
            # short-form text may contain raw "|" (cardinality notation);
            # the badge cell is the first bracketed cell after the ID.
            bi = next((k for k in range(1, len(cells)) if cells[k].startswith("[")), 2)
            rows[cells[0]] = {"text": " | ".join(cells[1:bi]), "badge": cells[bi],
                              "script": cells[bi + 1] if bi + 1 < len(cells) else "-",
                              "status": cells[bi + 2] if bi + 2 < len(cells) else ""}

# --- claim-list entries (whole paper)
entries = {}
i = 0
while i < len(lines):
    m = re.match(r"^- \*\*(L\d+\.\d+|LD\.\d+|LC\.\d+|LE\.\d+)-P12\*\*", lines[i])
    if m:
        cid = m.group(1) + "-P12"
        buf = [lines[i]]
        j = i + 1
        while j < len(lines) and (lines[j].startswith(" ") or lines[j] == ""):
            if lines[j] == "" and (j + 1 >= len(lines) or not lines[j + 1].startswith(" ")):
                break
            buf.append(lines[j]); j += 1
        entries.setdefault(cid, "\n".join(buf))
        i = j
    else:
        i += 1

# --- falsification conditions: blocks beginning with a C-number entry
cond_names = {}  # condition -> set of claim ids it names
i = 0
while i < len(lines):
    m = re.search(r"\*\*C(2[3-9]|3[0-3])\b", lines[i])
    if m and ("--" in lines[i] or "—" in lines[i] or lines[i].lstrip().startswith("-")):
        cond = "C" + m.group(1)
        buf = [lines[i]]; j = i + 1
        while j < len(lines) and (lines[j].startswith(" ") or lines[j] == ""):
            if lines[j] == "" and (j + 1 >= len(lines) or not lines[j + 1].startswith(" ")):
                break
            buf.append(lines[j]); j += 1
        named = set(ID_IN_TEXT.findall("\n".join(buf)))
        cond_names.setdefault(cond, set()).update(x + "-P12" for x in named)
        i = j
    else:
        i += 1

claims = sorted(rows.keys())
dep_text = {c: rows[c]["text"] + "\n" + entries.get(c, "") for c in claims}

edges = []          # (src, dst, kind)
inbound_claims = {c: 0 for c in claims}
inbound_conds = {c: 0 for c in claims}
outbound_premises = {c: 0 for c in claims}
for c in claims:
    t = dep_text[c]
    for y in set(ID_IN_TEXT.findall(t)):
        yid = y + "-P12"
        if yid != c and yid in rows:
            edges.append((c, yid, "claim")); inbound_claims[yid] += 1
    for cn in set(COND_RE.findall(t)):
        edges.append((c, "C" + cn, "condition"))
    for rn in set(re.findall(r"Receipt (\d+)", t)):
        edges.append((c, "Receipt " + rn, "receipt"))
    papers = set(re.findall(r"Paper (\d+(?:\.\d+)?)\s*(?:§|section|Sec\.)", t))
    deps = len(re.findall(r"\[Depends:", t))
    outbound_premises[c] = len(papers) + deps
    for p in papers:
        edges.append((c, "Paper " + p, "premise"))
    for _ in range(deps):
        edges.append((c, "Depends-flag", "premise"))
for cond, named in cond_names.items():
    for c in named:
        if c in inbound_conds:
            inbound_conds[c] += 1
            edges.append((cond, c, "condition-names-claim"))

score = {c: inbound_claims[c] + inbound_conds[c] + outbound_premises[c] for c in claims}

def home_section(c):
    m = re.match(r"^L(\d+)\.\d+-P12$", c)
    return int(m.group(1)) if m else None

def category(c):
    badge = rows[c]["badge"]; text = dep_text[c]; hs = home_section(c)
    if "MACHINE / AUTHOR" in badge or "MACHINE/AUTHOR" in badge:
        return "hybrid"
    if hs == 11:
        return "ordering"
    if hs in (5, 7, 8, 9):
        return "counting"
    if badge.strip() == "[LEVEL A: AUTHOR]" or "declared identification" in text \
       or text.lstrip().startswith("Programme:") or "author declaration" in text.lower():
        return "declaration"
    return "native"

pools = {}
for c in claims:
    pools.setdefault(category(c), []).append(c)
for k in pools:
    pools[k].sort(key=lambda c: (-score[c], c))

QUOTA = [("hybrid", 2), ("declaration", 1), ("ordering", 2), ("counting", 3), ("native", 4)]
sample, used = [], set()
for k, q in QUOTA:
    for c in pools.get(k, []):
        if len([s for s in sample if category(s) == k]) >= q:
            break
        if c not in used:
            sample.append(c); used.add(c)

with OUT.open("w") as f:
    f.write("GS-4 GOLD v1.0 -- SAMPLE SELECTION RECORD (spec section 7)\n")
    f.write("Selection script: select_sample.py (packaging step, deterministic).\n")
    f.write(f"Registry claims parsed: {len(claims)}; claim-list entries found: {len(entries)}; "
            f"conditions parsed: {len(cond_names)}; edges: {len(edges)}.\n\n")
    f.write("EDGE LIST (src -> dst [kind]):\n")
    for s, d, k in sorted(edges):
        f.write(f"  {s} -> {d} [{k}]\n")
    f.write("\nSCORES (claim: inbound_claims + inbound_conditions + outbound_premises = centrality):\n")
    for c in sorted(claims, key=lambda c: (-score[c], c)):
        f.write(f"  {c}: {inbound_claims[c]} + {inbound_conds[c]} + {outbound_premises[c]} = {score[c]}"
                f"  [pool: {category(c)}; home section: {home_section(c)}]\n")
    f.write("\nPOOLS (ranked):\n")
    for k, _ in QUOTA:
        f.write(f"  {k}: {pools.get(k, [])}\n")
    f.write("\nTHE TWELVE-CLAIM SAMPLE (fill order: hybrid, declaration, ordering, counting, native):\n")
    for c in sample:
        f.write(f"  {c}  [pool: {category(c)}; score: {score[c]}; script: {rows[c]['script']}]\n")
    f.write("\nSample JSON: " + json.dumps(sample) + "\n")
print(json.dumps({"n_claims": len(claims), "n_edges": len(edges), "sample": sample}))
