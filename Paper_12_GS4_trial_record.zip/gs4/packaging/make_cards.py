#!/usr/bin/env python3
"""GS-4 Gold v1.0 -- anonymization step (spec section 10.2).

Run ONLY after all eight submissions and the mutation log are sealed.

1. Extracts every FINDING block from the eight SUBMISSION.md files.
   A block runs from its "### FINDING" header line to the next
   "### FINDING" header or the next level-1/2 heading. The card keeps
   the block body BYTE-IDENTICAL after the header line; the header line
   is replaced by the card key (headers/labels are metadata; argument
   text is never edited). Cards are ordered by the SHA-256 of their
   bodies and keyed GS4-F-001... so the order encodes neither arm, role,
   nor filing order.
2. Writes adjudication/KEY_SEALED.md (card -> arm, role, local finding
   header, source file, block-body hash).
3. Produces anonymized full-text evidence copies of every submission
   document (SUBMISSION.md, blind files, reveal addenda) for the gate
   assessments: arm/role label strings and submission paths replaced by
   neutral tokens. Finding blocks are adjudicated from the cards, never
   from these copies.
4. Copies every submission artifact into adjudication/artifacts/ under
   neutral names and writes an artifact index.
"""
import hashlib, re, shutil, sys
from pathlib import Path

GS4 = Path(sys.argv[1])
SUB = GS4 / "submissions"
ADJ = GS4 / "adjudication"
(ADJ / "cards").mkdir(parents=True, exist_ok=True)
(ADJ / "evidence").mkdir(parents=True, exist_ok=True)
(ADJ / "artifacts").mkdir(parents=True, exist_ok=True)

ROLES = [("N", "A"), ("N", "B"), ("N", "C"), ("N", "D"),
         ("H", "A"), ("H", "B"), ("H", "C"), ("H", "D")]

blocks = []  # (arm, role, header, body)
for arm, role in ROLES:
    text = (SUB / arm / role / "SUBMISSION.md").read_text(errors="replace")
    lines = text.split("\n")
    i = 0
    while i < len(lines):
        if lines[i].startswith("### FINDING"):
            header = lines[i]
            j = i + 1
            while j < len(lines) and not (lines[j].startswith("### FINDING")
                                          or lines[j].startswith("## ")
                                          or lines[j].startswith("# ")):
                j += 1
            body = "\n".join(lines[i + 1:j])
            blocks.append((arm, role, header, body))
            i = j
        else:
            i += 1

blocks.sort(key=lambda b: hashlib.sha256(b[3].encode()).hexdigest())
key_rows = []
for n, (arm, role, header, body) in enumerate(blocks, 1):
    key = f"GS4-F-{n:03d}"
    card = f"### CARD {key}\n{body}"
    (ADJ / "cards" / f"{key}.md").write_text(card if card.endswith("\n") else card + "\n")
    key_rows.append((key, arm, role, header, hashlib.sha256(body.encode()).hexdigest()))

with (ADJ / "KEY_SEALED.md").open("w") as f:
    f.write("# GS-4 ADJUDICATION KEY -- SEALED until badges are frozen (spec 10.2.3)\n\n")
    f.write("| Card | Arm | Role | Original header | Block-body SHA-256 |\n|---|---|---|---|---|\n")
    for key, arm, role, header, h in key_rows:
        f.write(f"| {key} | {arm} | {role} | {header} | {h} |\n")
key_hash = hashlib.sha256((ADJ / "KEY_SEALED.md").read_bytes()).hexdigest()

def anonymize(text):
    text = re.sub(r"Arm [NH]\b", "Arm X", text)
    text = re.sub(r"\bArm [NH], Role [A-D]\b", "Arm X, Role X", text)
    text = re.sub(r"\(hostile arm\)|\(neutral arm\)", "(arm)", text, flags=re.I)
    text = re.sub(r"submissions/[NH]/[A-D]/", "submissions/X/X/", text)
    text = re.sub(r"briefs/[NH][A-D]/", "briefs/XX/", text)
    return text

ev_n = 0
for arm, role in ROLES:
    for doc in sorted((SUB / arm / role).glob("*.md")):
        ev_n += 1
        out = anonymize(doc.read_text(errors="replace"))
        (ADJ / "evidence" / f"EV-{ev_n:02d}.md").write_text(out)

art_rows = []
art_n = 0
for arm, role in ROLES:
    for art in sorted((SUB / arm / role).iterdir()):
        if art.suffix in (".py", ".txt", ".json", ".out") and art.is_file():
            art_n += 1
            neutral = f"ART-{art_n:02d}_" + re.sub(r"[^A-Za-z0-9._-]", "_", art.name).replace("hostile", "X")
            shutil.copy(art, ADJ / "artifacts" / neutral)
            art_rows.append((neutral, arm, role, art.name,
                             hashlib.sha256(art.read_bytes()).hexdigest()))
with (ADJ / "ARTIFACT_INDEX_SEALED.md").open("w") as f:
    f.write("# Artifact index -- sealed with the key (neutral name -> origin)\n\n")
    for neutral, arm, role, name, h in art_rows:
        f.write(f"- {neutral} <- {arm}/{role}/{name} sha256 {h}\n")

print(f"cards: {len(blocks)}; evidence docs: {ev_n}; artifacts: {art_n}; KEY sha256: {key_hash}")
