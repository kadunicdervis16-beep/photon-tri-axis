#!/usr/bin/env python3
"""GS-4 Gold v1.0 -- blind packet generation (spec section 5.3).

Generates blind_claims.md from the twelve sampled claims: claim statement
text, dependency statements, and the named script's printed coverage
statement (its INPUT_PROVENANCE block), with ALL badge material removed:
bracketed spans (badges live in brackets in this paper), sentences
containing status/verdict vocabulary, and sentences containing the word
'badge' in any case. Every removal is counted and logged. The recorded
grep pattern set must return ZERO matches before release; this script
refuses to write a non-compliant packet.
"""
import re, subprocess, sys, json
from pathlib import Path

PAPER = Path(sys.argv[1]); SAMPLE_FILE = Path(sys.argv[2])
SCRIPTS = Path(sys.argv[3]); OUT = Path(sys.argv[4]); LOG = Path(sys.argv[5])

lines = PAPER.read_text(errors="replace").split("\n")
sample = json.loads([l for l in SAMPLE_FILE.read_text().split("\n")
                     if l.startswith("Sample JSON:")][0].split(":", 1)[1].strip())

b_start = next(i for i, l in enumerate(lines) if l.startswith("## Appendix B"))
b_end = next(i for i, l in enumerate(lines) if i > b_start and l.startswith("## Appendix C"))
rows = {}
for l in lines[b_start:b_end]:
    if l.startswith("| L"):
        cells = [c.strip() for c in l.strip().strip("|").split("|")]
        if len(cells) >= 5 and re.match(r"^(L\d+\.\d+|LD\.\d+|LC\.\d+|LE\.\d+)-P12$", cells[0]):
            bi = next((k for k in range(1, len(cells)) if cells[k].startswith("[")), 2)
            rows[cells[0]] = {"text": " | ".join(cells[1:bi]), "badge": cells[bi],
                              "script": cells[bi + 1] if bi + 1 < len(cells) else "-"}

entries = {}
i = 0
while i < len(lines):
    m = re.match(r"^- \*\*(L\d+\.\d+|LD\.\d+|LC\.\d+|LE\.\d+)-P12\*\*", lines[i])
    if m:
        cid = m.group(1) + "-P12"; buf = [lines[i]]; j = i + 1
        while j < len(lines) and (lines[j].startswith(" ") or lines[j] == ""):
            if lines[j] == "" and (j + 1 >= len(lines) or not lines[j + 1].startswith(" ")):
                break
            buf.append(lines[j]); j += 1
        entries.setdefault(cid, "\n".join(buf)); i = j
    else:
        i += 1

SCRIPT_FILES = {"A.1": "A1_counting.py", "A.2": "A2_parallel_tick.py", "A.3": "A3_orbits.py",
                "A.4": "A4_capability.py", "A.5": "A5_concentration.py", "A.6": "A6_budgets.py",
                "A.7": "A7_exhibit.py", "A.8": "A8_molecule.py", "A.9": "A9_listings.py",
                "A.10": "A10_two_level.py", "A.11": "A11_mode_exhibit.py",
                "A.12": "A12_joint_counts.py", "A.13": "A13_provenance.py",
                "A.14": "A14_ordering_key.py", "A.15": "A15_spine.py",
                "FW.1": "FW1_firewall.py", "G.1": "G1_quotes.py", "H.1": "H1_registry.py"}

def coverage_statement(script_id):
    fn = SCRIPT_FILES.get(script_id.strip())
    if not fn:
        return None
    p = SCRIPTS / fn
    if not p.exists():
        return None
    t = p.read_text(errors="replace")
    m = re.search(r"INPUT_PROVENANCE:(.*?)(?:\"\"\"|\nimport |\ndef )", t, re.S)
    return m.group(0)[:3000] if m else None

stats = {}
def strip_material(text, cid):
    n_brackets = len(re.findall(r"\[[^\]]*\]", text))
    text = re.sub(r"\[[^\]]*\]", "", text)
    sents = re.split(r"(?<=[.!?])\s+", text.replace("\n", " "))
    kept, dropped = [], 0
    for s in sents:
        sl = s.lower()
        if ("badge" in sl or "resolved" in sl or "final" in sl
                or re.search(r"level [abc]\b", sl) or "machine / author" in sl
                or "machine/author" in sl):
            dropped += 1
        else:
            kept.append(s)
    stats[cid] = (n_brackets, dropped)
    return " ".join(kept).strip()

out = ["GS4-B CLASSIFICATION PACKET",
       "Twelve claims are reproduced below with their statements, dependency",
       "statements, and the coverage statements of the scripts they name.",
       "Classify each claim under the paper's own epistemic-status definitions",
       "(protocol extract, sections 1 and 9), using only what is printed here.",
       ""]
for cid in sample:
    home = entries.get(cid, rows[cid]["text"])
    home = re.sub(r"^- \*\*" + re.escape(cid) + r"\*\*\s*--?\s*", "", home)
    out.append("=" * 70)
    out.append(f"CLAIM {cid}")
    out.append("")
    out.append("Statement and dependency text:")
    out.append(strip_material(home + " " + rows[cid]["text"], cid))
    out.append("")
    out.append(f"Named script: {rows[cid]['script']}")
    cov = coverage_statement(rows[cid]["script"])
    if cov:
        out.append("Named script's printed coverage statement (provenance block):")
        out.append(strip_material(cov, cid + "/cov"))
    out.append("")
text = "\n".join(out) + "\n"

PATTERNS = ["LEVEL A", "LEVEL B", "LEVEL C", "MACHINE / AUTHOR", "MACHINE/AUTHOR",
            "[LEVEL", "badge", "FINAL |", "RESOLVED"]
badges = [rows[c]["badge"] for c in sample]
tmp = OUT.with_suffix(".tmp")
tmp.write_text(text)
failures = []
for pat in PATTERNS + badges:
    r = subprocess.run(["grep", "-F", "-c", pat, str(tmp)], capture_output=True, text=True)
    cnt = int(r.stdout.strip() or 0)
    if cnt:
        failures.append((pat, cnt))
log = ["GS4-B BLIND PACKET -- GENERATION AND VERIFICATION RECORD (spec 5.3)",
       f"Sample: {sample}",
       "Stripping counts per claim (bracket spans removed / sentences dropped):"]
for cid in sample:
    log.append(f"  {cid}: {stats.get(cid)} ; coverage block: {stats.get(cid + '/cov')}")
log.append("Grep pattern set (fixed strings), required result ZERO:")
for pat in PATTERNS:
    r = subprocess.run(["grep", "-F", "-c", pat, str(tmp)], capture_output=True, text=True)
    log.append(f"  pattern {pat!r}: {r.stdout.strip()} matches")
for c in sample:
    r = subprocess.run(["grep", "-F", "-c", rows[c]["badge"], str(tmp)], capture_output=True, text=True)
    log.append(f"  exact registry string of {c} ({rows[c]['badge']!r}): {r.stdout.strip()} matches")
log.append(f"RESULT: {'ZERO MATCHES -- packet released' if not failures else 'FAIL ' + str(failures)}")
LOG.write_text("\n".join(log) + "\n")
if failures:
    print("BLIND PACKET NON-COMPLIANT:", failures); sys.exit(1)
tmp.rename(OUT)
print("blind packet written:", OUT, len(text), "bytes; zero matches confirmed")
