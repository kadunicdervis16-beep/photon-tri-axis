# GS-4 — Independent Acceptance and Epistemic Stress Trial: House Specification

Paper 12, *The Aggregated Ledger*. Design authority: GPT-6's GS-4 proposal
(2026-10-31), adopted by the author's ruling of 2026-10-31 for in-house
execution with spawned agents, as the pre-publication cleanup gate.
Status of this document: **SPECIFICATION ONLY.** Nothing in it has been run.
Execution begins only after the freeze step of §3 completes.

---

## 1. What this trial is and is not (honesty label — read first)

**What it is.** A reconstruction and adversarial acceptance trial of Paper 12
executed by examiner agents whose *context* is independent of the house audit
trail: each examiner works only from this protocol, the frozen paper, the
source texts the paper itself declares, and its own role charter (§2, §4).
Information isolation is real, mechanical, and verified (§2.4, §4.3).

**What it is not.**

- It is **not independent human review.** All examiners are spawned agents of
  the same model family as the authoring and verifying environment. Context
  isolation removes access to the house's kits, verdicts, and summaries; it
  does not remove blind spots a model family may share, and it does not give
  any examiner epistemic virginity (an examiner's trained familiarity with
  general mathematics or physics is not controlled and cannot be).
- It must **never be reported as external validation**, in the paper, in any
  package, or in any summary. The correct label, everywhere, is:
  *"GS-4 (house execution, isolated-context agents)."*
- **Gate 8 applies unchanged** (§10): passing Gates 1–7 establishes an
  independent-context internal-consistency and reproducibility result over
  the tested claims and domains. It is not physical validation of the
  framework, and no native or computational pass may be presented as
  experimental confirmation.
- This trial awards **no badge by itself.** Examiners propose; the
  adjudicator (§2.5) assigns; the author rules on repairs.

---

## 2. Isolation architecture

### 2.1 Parties

| Party | Who | May see | May not do |
|---|---|---|---|
| Coordinator | The house agent who knows the full history | Everything house-side | Examine, hint, suggest targets, adjudicate, or edit any submission |
| Packaging step | A deterministic script plus one packaging agent running only §2.4/§6 mechanics | The frozen paper, the registry (Appendix B), the sources | Read submissions; exercise any judgment about claim importance beyond the recorded selection rule |
| Examiners A–D | Four spawned agents, one per role charter (§5) | Only the examiner packet (§4) and their own charter | See each other's work before sealing; consult any house material |
| Mutation runner | One spawned agent, distinct from A–D | The frozen paper **copy** (§7.1), the pre-registered mutation list (§7.2) | Invent mutations; read role submissions |
| Adjudicator | One spawned agent that runs no attack and executes no script check of its own design | Sealed submissions, the frozen paper (full, unblinded), the mutation run log | Run new attacks; contact examiners; alter submissions |

### 2.2 Information barrier

Each examiner receives **exactly**:

1. this protocol (the examiner-facing extract defined in §4.2),
2. the frozen paper (`Paper_12_v4.md` at the freeze hash, §3),
3. the declared source texts listed in §4.1,
4. its own role charter (§5).

Each examiner is spawned with a brief that contains **only** those items and
the instruction to work from them. Examiner briefs must not contain: any kit
(the GS-3 paste kit, any send kit), any prior battery report or outcome
(GS-1, GS-2, GS-3 in any execution, KD-1, GROK batteries, DS-12), any loop
adjudication (any round, including round 10's), any house summary or memory
extract, the Spine dossier, the OR-2 research report, or the words of any
prior verdict about any claim. The coordinator certifies each brief against
this exclusion list before spawning; the certification (brief hash + exclusion
checklist) is recorded in the freeze record (§3.3).

### 2.3 Sealing

- Each examiner writes its submission only to `gs4/submissions/<role>/`
  (`A/`, `B/`, `C/`, `D/`), as a single Markdown file plus any witness
  artifacts in the same directory.
- On completion the examiner's last act is to emit the SHA-256 of every file
  it wrote. The coordinator records those hashes in `gs4/submissions/SEALED.md`
  with the completion timestamp. A submission whose hash later differs from
  the sealed value is void and the role is re-run by a fresh agent.
- **No cross-reading before all four seals exist.** Neither examiners, nor the
  mutation runner, nor the adjudicator may open another role's directory
  before `SEALED.md` lists all four roles (mutation results seal separately,
  §7.3). The coordinator does not read submission content at all before the
  seals are complete; after sealing, the coordinator routes files to the
  adjudicator without summarizing them.

### 2.4 The blind packet (GS4-B) — mechanically enforced

The badge blind test fails if stripping is a matter of trust, so it is a
matter of grep:

1. The packaging step generates `gs4/packet/blind_claims.md` from the twelve
   sampled claims (§6): for each, the claim statement text and its evidence
   excerpts (home statement, dependency statements, the named script's printed
   coverage statement, source passages relied on), with **all badge material
   removed**: every badge string, every badge token in brackets, registry
   verdicts, claim-status words ("FINAL", "RESOLVED" as a status), and the
   Appendix B row for the claim.
2. Stripping is verified by running the recorded grep pattern set over the
   blind packet; the run must return **zero** matches before release:
   `LEVEL A`, `LEVEL B`, `LEVEL C`, `MACHINE / AUTHOR`, `MACHINE/AUTHOR`,
   `[LEVEL`, `badge`, `FINAL |`, `RESOLVED` (as a status token in a table
   cell), and each sampled claim's exact Appendix B badge string.
3. The grep command, pattern set, and zero-match output are saved to
   `gs4/packet/blind_verification.txt` and hashed into the freeze record.
   If any match is found, the packet is regenerated; it is never hand-edited
   into compliance.
4. Role C receives the blind packet **in place of** the corresponding
   Appendix B rows for its GS4-B work, and records its classifications
   (sealed) before the adjudicator reveals the paper's actual labels to it
   for the disagreement-resolution pass. That second pass is a separate,
   later-sealed addendum; the original blind classifications are never edited.

### 2.5 Adjudication

The adjudicator assigns final badges attack-by-attack from the sealed
submissions and the mutation log, under §8's verdict rules. A proposed
**BROKE may be sustained only if its witness was reproduced by a second,
independent route** (§8.3). The adjudicator writes `gs4/GS4_ADJUDICATION.md`;
it does not edit the paper, the submissions, or the mutation log.

### 2.6 Coordinator's permitted acts (exhaustive)

Spawn examiners with certified briefs; run the packaging and selection
mechanics; record hashes and seals; route sealed files; report status in
process vocabulary only (§8.4). Anything else — interpreting a finding,
suggesting where to look, characterizing an outcome before adjudication —
is a breach of this protocol and voids the affected role's run.

---

## 3. Freeze protocol

3.1 **Freeze target.** The round-10 final tree of Paper 12 v4 (corrections
round 10: Y2 + D6 repairs) after its own loop pass and final-tree suite run.
This spec is written tree-agnostically: no hash, line count, or claim count
is written into it in advance. If round 10 has not closed when execution is
called for, execution waits; GS-4 never runs against a tree that is still
being repaired.

3.2 **Freeze acts, in order:**

1. Copy the final paper to `gs4/frozen/Paper_12_v4.md`; compute its SHA-256.
2. Record the verification-suite result on that exact tree (the round-10
   final run's output, verbatim) and the suite's script count.
3. Assemble the examiner packet (§4) and hash every file in it.
4. Run the sample selection (§6) and the blind-packet generation and
   verification (§2.4).
5. Write `gs4/FREEZE_RECORD.md` containing: paper hash; suite result;
   packet manifest with per-file hashes; the selection rule's output (the
   twelve claim IDs and the rule inputs); blind-verification result; the
   four certified examiner briefs' hashes. Execution (spawning examiners)
   may begin only after this record exists.

3.3 **Immutability.** After the freeze record is written, the frozen copy is
never edited. Any paper change after freeze (including a repair round)
invalidates the freeze; a new freeze on the new tree is required, and both
freeze records are kept.

---

## 4. Examiner packet manifest

### 4.1 Contents (exhaustive)

| # | File | Source of the file |
|---|---|---|
| 1 | `Paper_12_v4.md` (frozen) | The round-10 final tree, per §3 |
| 2 | `protocol_examiner_extract.md` | §4.2 extract of this spec |
| 3 | `paper2_section11.txt` | Paper 2 §11 extract (the paper's declared §11 reliance), newline line-numbered |
| 4 | `paper9.txt` | As carried in the paper's own verification package sources |
| 5 | `paper10.txt` | As carried in the paper's own verification package sources |
| 6 | `paper_11_v69.md` | As carried in the paper's own verification package sources |
| 7 | `paper_11_5_v26.md` | As carried in the paper's own verification package sources |
| 8 | The examiner's own role charter | §5, one file per role |
| 9 | Role C only: `blind_claims.md` | Generated and verified per §2.4 |

### 4.2 Examiner-facing extract

The extract given to examiners contains: §1 (honesty label), the examiner's
charter, §6.3 (sample, once selected), §7.2's mutation list **only for the
mutation runner**, §8 (evidence standard and verdict rules), and §10 (gates,
for reference). It does **not** contain: §2.6, §9, §11, the freeze record,
any hash of anything except the frozen paper's (given so Role D can verify
identity, Gate 1), or any mention of prior batteries' existence beyond the
change-log and version history that are part of the frozen paper itself.

### 4.3 Deliberately excluded — and how exclusion is verified

Excluded: all verification-package zips (any round), all battery reports and
kits of every prior battery and every circuit member, all loop adjudications,
KD-1/GS-3 reports, the Spine dossier, the OR-2 research report, all house
summaries. Verification: the packet directory is built empty and populated
only by the §4.1 list; the freeze record's manifest is a complete recursive
listing of the packet directory with hashes; any file present that is not on
the §4.1 list voids the freeze. Examiners work in the packet directory and
their own submission directory only.

### 4.4 A note on the paper's own memory

The frozen paper legitimately contains its version history and change log,
which mention prior batteries and repairs. That is **inside** the object
under examination (and GS4-H examines it); it is not a breach of isolation.
What isolation forbids is giving examiners the house's *verdicts and working
records* about that history.

---

## 5. Role charters and attack assignments

Attacks GS4-A…J are assigned as follows. Each examiner's charter states its
required work, its prohibitions, and its deliverable. An examiner that cannot
perform a required step records the process status (§8.4) and the reason; it
never substitutes a plausible-looking result.

### Role A — Native Reconstructor (GS4-A lead, GS4-G support)

Required: (1) reconstruct the aggregate tick and its declared domain;
(2) reconstruct the K ordering and its deciding components; (3) reconstruct
Res and distinguish it from the three standings and from any similarly named
predicate; (4) reconstruct the census, flow, and joint-count definitions;
(5) reconstruct at least one end-to-end Spine example from declared records
to final output; (6) for every step, classify it as definition, finite
calculation, proof, inherited premise, or author identification.
Prohibited: importing a physical interpretation to settle a native ambiguity;
treating a script's output as proof of a general theorem; silently replacing
a declared definition with a more familiar one.
Deliverable: reconstruction workbook with per-step classification.

### Role B — Proof and Counterexample Examiner (GS4-A support, GS4-F co-lead)

Required: (1) derive each selected theorem independently, without reading
its verification script first (script consultation, if any, happens after the
derivation attempt and is logged); (2) search the boundary space: empty and
singleton populations where admitted, unequal sides, repeated members,
junctionless bodies, multi-sided junctions, tied deciding components,
proper-prefix comparisons, relabellings, disconnected populations,
composition boundaries; (3) for every universal statement, state the exact
quantifier domain and whether the proof covers it; (4) attempt alternative
constructions satisfying the same premises but changing the claimed result;
(5) every proposed counterexample ships the complete witness and a check that
it satisfies every precondition.
Standing cautions (stated in the charter verbatim): a failed attack is not a
proof; a successful finite search is not a universal theorem unless the
domain is finite and exhaustively covered or an analytic argument closes the
remainder.
Deliverable: derivation/counterexample log with witnesses as runnable
artifacts where computation is involved.

### Role C — Provenance, Badge and Change-Log Examiner (GS4-B, GS4-C, GS4-D, GS4-H)

Required: (1) build an independent claim→home→dependency→evidence graph for
the sample; (2) trace every sampled claim's badge through its dependencies
applying the paper's weakest-dependency rule; (3) separate inherited facts,
Paper 12 definitions, author declarations, arbitrary control choices, machine
outputs, external observations; (4) audit all MACHINE/AUTHOR splits in the
sample — name the exact sentence or content each leg carries; (5) check that
every declared assumption is named at every load-bearing use site in the
sample; (6) GS4-H: select three historical changes by the recorded rule
(§5.1) and reconstruct before/after from the paper's version history,
checking that the change log describes the actual difference and that the
current suite tests the changed claim; (7) GS4-B blind classification from
the blind packet (§2.4), sealed before any label is revealed; (8) GS4-C
dependency-break: for each sampled claim, remove one dependency at a time
from the working packet and determine derivability — if derivable, show the
alternative derivation; if not, name the precise dependency and whether the
badge reflects it; (9) GS4-D proof–code separation: for every hybrid claim in
the sample, two separate deliverables — the general proof from printed
premises, and the independent reproduction of the finite machine-checked
range — neither citing the other as a substitute.
**This role expressly reopens the two known provenance/pricing defect
classes (an A.15-class provenance mislabel; an L8.3-class split mismatch)
as open questions over the whole sample; it must not assume the round-10
repairs, or their absence, make any other part of the system sound or
unsound.** The charter does not tell Role C what round 10 changed.
Deliverable: graph, split audit, blind classifications (sealed first),
dependency-break table, proof–code pairs, change-log findings.

### 5.1 Change-log selection rule (for GS4-H)

From the frozen paper's version history, take: the most recent change that
altered a claim's scope; the most recent change that altered a verification
script or fixture; the most recent change that altered a badge, dependency,
or falsification statement. If one change fills two classes, take the next
most recent for the second class. The selection (change IDs and classes) is
recorded in Role C's submission before its analysis.

### Role D — Implementation and Reproducibility Examiner (GS4-A support, mutation witness)

Required: (1) verify the frozen paper's hash before any execution (Gate 1);
(2) extract the embedded scripts from the frozen paper itself (never from a
package zip) and run the suite in a clean working directory, recording
interpreter version, dependencies, OS, command, exit codes, stdout, stderr,
elapsed time; (3) reimplement at least three load-bearing computations from
the paper's definitions without importing the paper's functions or copying
its algorithm line-for-line — the three are: the K ordering key and its
comparison, the population-temperature/census ratios for one Spine
population, and one A.5-class assignment-count computation; (4) independently
regenerate one Spine thread's outputs from the declarations, not from the
printed fixture; (5) witness the mutation runs (§7) and confirm each
mutation's observed behaviour against its pre-registered expectation;
(6) state, per sampled machine-checked claim, whether the named script checks
the claim's mathematical content or only the presence/shape of a registry
entry.
Deliverable: environment record, run log, three reimplementations with
outputs, Spine regeneration record, mutation witness table.

### Attack assignment summary

| Attack | Lead | Support | Notes |
|---|---|---|---|
| GS4-A Claim reconstruction (12-claim sample) | A | B, D | Reconstructions from home text + dependencies only |
| GS4-B Badge blind test | C | — | Blind packet §2.4; sealed before reveal |
| GS4-C Dependency break | C | B | One dependency removed at a time |
| GS4-D Proof–code separation | C | B | Two deliverables per hybrid claim, mutually non-citing |
| GS4-E Mutation battery | Mutation runner | D (witness) | §7; pre-registered, no additions |
| GS4-F Alternative representatives | B | A | Same Paper 2 differentiae + declared identification; which K components are forced vs chosen |
| GS4-G Reader-only reconstruction | A | — | Paper + declared sources only; no scripts, no outputs; log every point needing hidden knowledge |
| GS4-H Change-log integrity | C | — | Selection rule §5.1 |
| GS4-I Physical bridge firewall | A | C | Every Stage P item in the sample: calibration, bridge sentence, empirical input, uncertainty — and whether any Stage N result is presented as if the bridge were measured |
| GS4-J Competing explanations | A | — | Per physical-facing sampled claim: an alternative model producing the same observation, the discriminating measurement, its precision, and what counts against the framework. If none can be supplied, the claim gets no empirical acceptance verdict — recorded as such, not as a defect of the native claim |

---

## 6. The twelve-claim sample — deterministic selection

The sample is chosen by rule, not by hand. The coordinator does not pick,
swap, or veto claims.

6.1 **Composition (fixed quotas, per the proposal):** 4 native definitions
or theorems; 3 counting/statistical claims; 2 ordering or composition
claims; 2 hybrid [LEVEL A: MACHINE / AUTHOR] claims; 1 author declaration.

6.2 **Category assignment.** Each registry claim is assigned to exactly one
category by the first matching rule, applied in this order: (i) badge is the
hybrid mark → *hybrid pool*; (ii) home section is §11 or the claim concerns
the K ordering, representatives, or the molecule reduction → *ordering/
composition pool*; (iii) home section is §§5, 7, 8, or 9, or the claim
concerns census, joint counts, temperature, or assignment counts →
*counting/statistical pool*; (iv) the claim is a stated author declaration or
declared identification → *author-declaration pool*; (v) otherwise →
*native definition/theorem pool*. A claim consumed by an earlier quota is
removed from later pools; quotas are filled in the order hybrid,
author-declaration, ordering/composition, counting/statistical, native.

6.3 **Ranking within a pool (dependency centrality).** The packaging script
parses Appendix B and the claim lists and builds the stated-dependency
graph: an edge X→Y exists when claim X's registry row or claim-list entry
names claim Y, a falsification condition (C23–C33), a receipt, or a declared
premise in its dependency/pricing text. A claim's centrality score is
(inbound edges from other claims) + (inbound edges from falsification
conditions) + (outbound edges to source-paper premises). Higher score ranks
first; ties break by claim ID, ascending lexicographic order. The script,
its parsed edge list, every score, and the resulting sample are saved to
`gs4/packet/sample_selection.txt` and hashed into the freeze record. The
sample is final once the freeze record is written; a selection dispute is a
spec defect (SD-n), recorded, never silently re-picked.

6.4 **Mandatory additions (outside the twelve).** Independently of the
sample, the examiners also cover: every hybrid-split Level A claim (Role C's
split audit is over all of them, not only the sampled two, for GS4-D's
allocation question only); every declared assumption consumed by a sampled
claim; every direct external dependency of a sampled claim. Unexamined
claims remain unexamined; no global verdict may be inferred from the sample.

---

## 7. Mutation battery (GS4-E) — pre-registered

### 7.1 Rules

Mutations are applied **only to a working copy** (`gs4/mutations/tree/`) of
the frozen paper and its extracted scripts; the frozen copy is never
mutated. The list below is complete and frozen with this spec: no mutation
may be added, dropped, or widened after the freeze. Each entry names its
expected catching control **in advance**; where no control is expected, that
absence is declared a scope boundary **before** execution. A mutation whose
expected control does not fire is a finding; a mutation in the declared
no-control class that no control fires on is a confirmed scope boundary,
not a finding and not a pass.

### 7.2 The mutations

| ID | Mutation (applied to the working copy) | Expected catching control |
|---|---|---|
| M1 | In A.15's INPUT_PROVENANCE, relabel one paper-defined binding as cited-paper (the Y2 shape) | F.49-style provenance check if wired in the suite; else **no control expected — declared scope boundary** (provenance-class accuracy of A.15 rests on audit, recorded before execution) |
| M2 | In a hybrid claim's Appendix B row, move one prose-carried general clause from the AUTHOR leg to the MACHINE leg (the L8.3 shape) | H.1 registry-vs-home check — expected to catch only if the home/row badge strings differ; for a pure split move with badge string unchanged: **no control expected — declared scope boundary** |
| M3 | Delete one Appendix B registry row while its claim remains in the claim list | H.1 (claim/registry bijection) |
| M4 | Alter one numeric value in the Appendix F fixture, leaving all expected outputs unchanged | A.15 check comparing fixture to both computation paths |
| M5 | Replace one embedded script listing with its previous round's version (stale listing) | A.9 (listing byte-identity / manifest) |
| M6 | Edit a claim's scope sentence in the paper body and make no version-history entry for it | **No control expected — declared scope boundary** (change-log completeness is Role C's GS4-H audit, not a script control) |
| M7 | Strengthen one claim's badge in its claim-list entry only, above its weakest dependency | H.1 (registry-vs-home badge reproduction) |
| M8 | Feed an empty population declaration to the Spine generator that normally supplies nonempty data | A.15's own input handling — expected behaviour: explicit rejection or a stated empty-case result; a crash or a silent nonempty assumption is the finding |
| M9 | Construct two populations whose CenSig values stand in a proper-prefix relation and compare them under K | A.14's comparison plus §11.3's stated prefix convention — expected: the convention decides, no exception |
| M10 | Relabel every body in a Spine population (permuted names), leaving records unchanged | A.15/A.14 invariance checks — expected: identical K components and census ratios |
| M11 | Shift one joint-count window so an offset straddles the window split | A.12 / Proposition 5.9(ii)'s stated horizon reading — expected: counts as the proposition's stated form requires, no double count |
| M12 | Introduce a multi-sided junction whose consumed-port count differs from its side count, at the C33 boundary | A.14's stated domain handling — expected: handled as outside A.14's domain per its disclosure, with C33's scoped text not firing |
| M13 | Corrupt one source hash in the packet manifest copy used by Role D | Role D's Gate 1 hash verification — expected: mismatch detected before any run |
| M14 | Duplicate one population member (same name, same record, twice) in a Spine declaration | A.15/A.12 declaration validation — expected: rejection or a stated duplicate rule; silent double-counting is the finding |
| M15 | Remove one dependency edge from a sampled claim's registry row (text edited, graph edge gone) | **No control expected — declared scope boundary** (dependency completeness is Role C's GS4-C audit) |
| M16 | Change one tick window in a §5 joint-count example so an event crosses the window boundary mid-count | A.12 — expected: the declared-horizon rule decides the count |
| M17 | In one script, make a check test a proxy (string presence) instead of its claim's computed quantity, keeping its output text identical | Role D's content-vs-shape determination (GS4/D item 6) — **no script control expected; the control is the examiner** |
| M18 | Insert a Stage P bridge word into a native Stage N definition sentence | FW.1 firewall sweep |
| M19 | Omit one declared assumption's name at one load-bearing use site (body text edited) | **No control expected — declared scope boundary** (Role C item 5 audit) |
| M20 | Reorder two deciding components of K in A.14's key tuple | A.14's representative/order checks — expected: failures on the representative comparisons |
| M21 | Change one sign in Table 5.1's received sign facts as printed in §11.3's representatives | A.14 / §11.3 representative checks — expected: at least one representative comparison fails |
| M22 | Give one junction two incompatible standings via a multi-sided record read through the pairwise rule | A.12/Def 5.7 legality checks — expected: rejection as an illegal record, or a stated precedence rule decides |
| M23 | Truncate one verbatim quotation in §11.3 mid-phrase, leaving its G.1 punctuation pattern plausible | G.1 quote-integrity check |
| M24 | Replace the §6.1 bonding-mode premise's receipt wording with a citation wording ("Paper 2 proves…") at one consumption site | FW.1/G.1-class wording checks if the shape is swept; else **no control expected — declared scope boundary** (Role C audit) |

### 7.3 Mutation run protocol

The mutation runner applies each mutation to a fresh copy of the working
tree, runs the full suite plus any examiner-specified check named in the
expectation, and records: mutation ID, exact diff, controls run, observed
behaviour, expectation met / not met / boundary-confirmed. Role D witnesses
the runs and countersigns the log. The log seals to `gs4/mutations/RUN_LOG.md`
(with diffs) before adjudication. The runner proposes no badges.

---

## 8. Evidence standard and verdict rules

### 8.1 Attack record (required fields, every attack)

Attack ID and target claim; exact target text and location (section and
line in the frozen paper); claim domain and required property; source files
used with verified hashes; method and complete test space; the executable
program and inputs wherever computation is involved; output and logs; for a
proposed BROKE, the independent second route (§8.3); a five-part coverage
map — **(1) native domain, (2) verified domain, (3) the map between them,
(4) what the map preserves, (5) what stays outside the check**; proposed
badge and reason. No count is accepted without its producing artifact; no
hash without independent recomputation; no source is marked READ unless the
examiner actually inspected it; a missing source is a coverage boundary,
not evidence against a claim, unless the paper asserts the source is present.

### 8.2 Verdicts (claim status)

- **HELD** — independently reconstructed or reproduced over the stated
  domain; no counterexample found within that verified domain. Never means
  physically true.
- **BROKE** — a reproducible witness or logical contradiction against the
  claim as written, all preconditions satisfied, second route confirming.
- **LIMIT** — evidence supports only a proper subset of the stated domain,
  or the claim cannot be decided at the available scope; the exact boundary
  is named.
- **OUTSIDE** — the tested property is not asserted by the target claim.

Verdicts are never summed into a score or percentage; one broken
load-bearing claim is not cancelled by any number of held bookkeeping checks.

### 8.3 Second-route rule

Every BROKE requires reproduction by a route independent of the first:
a different implementation, an analytic derivation, or a direct textual
witness pair (home vs registry, script block vs script block) verifiable by
inspection. The adjudicator checks the second route exists and is genuinely
independent before sustaining; a single-route BROKE is downgraded to LIMIT
with the reason recorded.

### 8.4 Process status (kept separate from claim status, always)

`READ / NOT READ`, `RUN / NOT RUN`, `REPRODUCED / NOT REPRODUCED`,
`SOURCE-VERIFIED / SOURCE-REPORTED`, `SEALED / UNSEALED`. NOT RUN is a
process status, never a badge. No report may let a process word do a
verdict's work or a verdict do a process word's work.

---

## 9. Execution order and deliverables

1. **Packaging** — packet built per §4; blind packet generated and verified
   per §2.4; sample selected per §6. (Coordinator + packaging step.)
2. **Freeze record** — §3.2 completed and written. Nothing runs before this.
3. **Role submissions** — examiners A–D spawned in parallel with certified
   briefs (§2.2); each seals per §2.3. Role C's blind classifications seal
   before its reveal pass; the reveal addendum seals separately.
4. **Mutation runs** — §7.3, on copies, witnessed by Role D after its own
   submission is sealed (witnessing is not examination; the runner's log and
   Role D's countersignature seal together).
5. **Adjudication** — §2.5; `gs4/GS4_ADJUDICATION.md` with per-attack
   badges, coverage maps as submitted, second-route confirmations, and the
   gate table (§10) filled gate by gate.
6. **Report** — `gs4/GS4_REPORT.md`: the adjudication's results in plain
   language, the author's list (findings only, no repairs), the retained
   LIMIT/OUTSIDE boundaries, the process-status table, and the §1 honesty
   label repeated verbatim at the head of the report.

Deliverables live in `~/workspace/your_files/paper_12_draft/gs4/`. The frozen
paper, submissions, and mutation log are retained permanently as the trial's
evidence; none is overwritten by any later round (a re-run gets a new
directory suffix with its own freeze record).

---

## 10. Acceptance gates

| Gate | Test | Owner of the evidence |
|---|---|---|
| 1 — Identity | Frozen release, hashes, source versions, environment independently verified | Role D |
| 2 — Reconstruction | Native definitions and selected load-bearing derivations reconstructed without private author knowledge | Roles A, B |
| 3 — Badge honesty | Blind classifications match the paper's evidence, or every discrepancy is resolved and recorded | Role C + adjudicator |
| 4 — Computational independence | Selected machine results reproduce through second implementations; mutation tests show the controls can fail when expected | Role D + mutation log |
| 5 — Dependency integrity | Sampled claim graphs have no omitted load-bearing dependencies; no claim outranks its weakest dependency | Role C (GS4-C) |
| 6 — Change integrity | Sampled changes trace old text → new text, with corresponding tests and dispositions | Role C (GS4-H) |
| 7 — Falsification reach | An independent-context reader can identify a real falsifier for every selected Level A claim, or the paper explicitly names the boundary where none is available | Roles A, C |
| 8 — Physical separation | No native or computational pass is presented as experimental confirmation without an independent physical bridge and a discriminating observation | Roles A (GS4-I/J) + adjudicator |

A gate is marked PASS, FAIL, or NOT DECIDED (with the deciding evidence
named) — never inferred from another gate. Passing Gates 1–7 with Gate 8
open is the expected maximum outcome of this trial and is reported as
exactly that.

---

## 11. What the house does with the results

- The GS-4 report and author's list go to the author. **No repair is
  enacted on the basis of GS-4 alone**; repairs require the author's ruling,
  item by item, as with every prior battery.
- GS-4 is the **pre-publication cleanup gate** per the author's ruling of
  2026-10-31: its author's list is disposed of (repaired on ruling, or
  explicitly accepted as a retained boundary) before publication.
- Proposed badges from GS-4 are recorded as GS-4's own record, disclosed
  alongside prior batteries with the §1 label attached; they do not replace
  or silently merge with GS-3/KD-1 outcomes.
- Spec defects discovered during execution are logged as SD-n in the
  report, named, never silently repaired mid-run; a defect that voids a
  role's isolation (§2.6 breach, unsealed cross-reading, packet
  contamination) voids that role's run and is reported as such.

---

## 12. What this spec could not operationalize from the proposal

Named honestly, so the gap is on the record rather than smoothed over:

1. **Independent human examiners.** The proposal's decisive stage calls for
   two independent humans (discrete mathematics/computation; physics/
   statistical mechanics) working independently. Spawned agents cannot
   supply this. The house execution is a first pass at reduced strength;
   the human stage remains available to the author at any time and is not
   replaced by this trial.
2. **Empirical content of Gates 8 / GS4-J.** No experiment can be run
   in-house. GS4-I/J as specified audit the bridge text, name the
   discriminating observations and their required precision, and police the
   presentation boundary — they do not and cannot produce the observations.
3. **Model-family independence.** Examiners share the house model family
   (§1). Isolation here is informational (context, kits, verdicts, cross-
   reading), which is enforceable and verified; architectural independence
   (a different model family, let alone humans) is not achievable with
   spawned house agents.
4. **A truly clean environment for Role D.** Role D runs in a fresh working
   directory on the house machine with the house interpreter; the
   environment record (§5, Role D) states exactly what the environment was,
   and no claim of platform diversity is made.
