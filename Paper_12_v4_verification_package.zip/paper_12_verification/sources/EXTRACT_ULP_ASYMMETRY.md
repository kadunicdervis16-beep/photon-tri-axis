# EXTRACT — ULP, Asymmetry of Occasion, Paper 9 Definitions (verbatim grounding for Paper 12)

Sources (on disk, published texts):
- `~/workspace/your_files/paper_12_draft/sources/paper9.txt` (885 lines)
- `~/workspace/your_files/paper_12_draft/sources/paper10.txt` (5448 lines)

Transcription convention: the .txt files are PDF extractions with hard line wraps; wraps are joined into flowing sentences inside quote blocks, but every word and punctuation mark is copied byte-faithfully from the file. Where a running page header interrupts a sentence inside a quote, the interruption is marked `[— page header in source —]`. Line anchors (L###) refer to the .txt files above. Superscripts appear flattened in the extraction exactly as shown (Paper 9 prints "v2 + s2 = c2"; Paper 10 prints "v² + s²" in most places).

**Headline findings (read first):**
1. ULP is Paper 10 §2.4.7 — full theorem + 5-step proof, FOUND verbatim.
2. Asymmetry of occasion is Paper 9 §5 (unnumbered bold-lead passage, PDF pp. 10–11) — FOUND verbatim.
3. **The contact-budget equation `N_total = N_id + v²_contact + s² + N_reconcile = 100 CU` is NOT printed in Paper 9.** Paper 9's own budget rule is the orthogonal sum rule `v2 + s2 = c2` over the Circa budget (from Paper 8), with no "100", no "CU", and no `N_reconcile` symbol anywhere in the file. The 100 CU equation is printed verbatim in **Paper 10 §2.2, eq. (2.4)** (with its build-up in eqs. 2.2a–2.2c), citing Paper 9 §8.1 for `N_reconcile`. Quoted below under correct attribution.
4. **The symbol `T_ledger` appears in NEITHER paper.** Paper 9 defines temperature verbally (§4, §2). Paper 9 carries **no Stage P / Stage C scope labels** (the strings "stage"/"scope" do not occur in paper9.txt).
5. **Paper 9 does not define the Junction Saturation Threshold** — it is Paper 7's, cited by Paper 9 in three passages (quoted below). No definition of it as an "aggregate-load ceiling" appears in Paper 9 or Paper 10.
6. **The 3^N per-tick sub-region scaling passage is NOT FOUND in Paper 9** (no "3^N", no "sub-region" anywhere in paper9.txt; "sub-region" also absent from paper10.txt). The only "3^N" in either file is Paper 10 Appendix E, Axiom E.2 — a state-space cardinality bound, not a per-tick sub-region scaling. Quoted below with the mismatch flagged.

---

## 1. Paper 10 — Uniform Load Partition

### 1.1 The theorem, exact statement (Paper 10, §2.4.7; paper10.txt L1381–1386)

Section header and theorem statement, verbatim:

> 2.4.7 THEOREM: UNIFORM LOAD PARTITION FROM MANDATORY COMPLETE SWEEP
>
> Theorem (Uniform Load Partition — Exact Architectural Form) [LEVEL A][L1·L2·L3·L4]. For an isolated source configuration, the temporal-scan workload partitions uniformly across all admissible configurations at the same relay distance d that share the same operational state category and local Circa budget.

### 1.2 Derivation as printed — the five proof steps (paper10.txt L1387–1422)

> Proof.
> Step 1 — The Temporal Scan is a complete sweep by definition. Every configuration whose Identity Scan returns "I am not a photon" must execute the Temporal Scan: an outer 360° search for geometric resolution (Paper 2, §1.1; Paper 10, §2.1). The scan's operational mandate is "How do I get back to the photon baseline?" To answer this, the configuration must interrogate all available relational channels. A partial sweep would leave potential resolution partners on unqueried axes undiscovered, violating the scan's mandatory search function. Therefore, once triggered, the Temporal Scan covers all three relational axes without directional omission.
> Step 2 — The 27-state inventory is S₃-symmetric. The Classification Theorem of Paper 2 partitions the 27 states under the action of the axis permutation group S₃. The Per-Triangle Rule (Paper 3) requires exactly one X, one Y, and one O per triangle — a condition invariant under any permutation of the three axes. The Closure Principle (Paper 5) locks a junction when its center triplet is uniform, regardless of which axis carries which value. Consequently, no relational axis is structurally privileged over another.
> Step 3 — Equal emission weight per axis. Because the Temporal Scan is complete (Step 1) and the state rules are S₃-symmetric (Step 2), the source configuration emits scan-query workload with equal weight along each of the three relational axes. There is no mechanism in the 27-state inventory that permits Axis 1 to emit a stronger scan query than Axis 2 or Axis 3.
> Step 4 — The relational medium has no void positions. By HTA (§2.4.1, Layer 2), every position in the array is a configuration with six relay ports. By the Unboundedness Axiom (Layer 4), there are no boundary terminations. The default non-source state is the photon baseline (State 9, s² = 0), which executes its identity scan and relays queries deterministically. There are no "forbidden" positions in the array; the Per-Triangle Rule is a hardware law governing state transitions, not a filter that excludes nodes from the shell count.
> Step 5 — Uniform partition across the complete shell. Because every position at relay distance d is occupied by an admissible configuration (Step 4), and all non-source configurations are in the same baseline state category with identical local Circa budgets, the workload s²_node divides equally among all N(d) configurations on the shell. The per-configuration strain is exact:
> S(d) = s²_node / N(d). (2.7)
> There is no N_forbidden(d) term because the relational medium contains no voids and no excluded positions. ∎

The printed gloss immediately following the proof (paper10.txt L1422–1428):

> Architectural Distinction from Continuous Metric Theory. General Relativity postulates isotropy via the cosmological principle: the metric tensor is assumed spatially homogeneous and isotropic at large scales, and no structural mechanism exists within the theory to violate this assumption. The ledger does not postulate isotropy. It derives the uniform partition as the exact output of S₃-symmetric state emission (Layer 1) across isotropic six-port hardware (Layer 2) in a medium that has no void positions (Layer 4). The "quiescent regime" is not a special assumption in the ledger; it is the default operating state of the relational array. Standard physics needs a cosmological principle because its vacuum is empty. The ledger needs none because its space is full.

### 1.3 The definition the theorem discharges (Paper 10, §2.2; paper10.txt L964–971)

> Definition (Uniform Partition). The per-configuration strain at relay distance d is defined by the exact partition:
> S(d) ≡ s²_node / N(d) (in CU).
> Consequently, for any isolated source and any complete relay shell at distance d:
> Σ_{shell(d)} S(d) = s²_node. (2.6)
> This algebraic identity is definitional, not dynamical. It states that the workload is divided equally across the shell; the physical content lies in the shell-count theorem N(d) = 4d² + 2 and the uniformity theorem (§2.4.7), not in the algebraic closure of the partition.

Restated in the Three-Category Closure Rule (§2.2; paper10.txt L992–996):

> By the Uniform Partition Definition (2.6), the total temporal-scan workload s²_node is partitioned across all configurations at relay distance d, with each configuration processing the share:
> S(d) = s²_node / N(d).
> The sum over any complete shell is exact:
> Σ_shell(d) S(d) = s²_node.

### 1.4 Load-bearing equations — shell count N(d) = 4d² + 2

Corollary statement (Paper 10, §2.4.1; paper10.txt L1160–1167):

> Corollary (Shell Count — Conditional Topological Theorem) [L1·L2·L3·L4]. The exact shell count is N(d) = 4d² + 2.
> Status of the shell count. The coefficient 4 in N(d) = 4d² + 2 is the canonical Taxicab Shell Cardinality coefficient (§5.3.2). Its appearance in the 3-axis point-shell count depends on the 3-axis count (Layer 1), the bidirectional port structure (Layer 2), the group composition ℤ³ (Layer 3), and the absence of boundary corrections (Layer 4). The theorem is therefore a consequence of the full four-layer architecture, not of the 27-state inventory alone.

Definition form (§2.4.1; paper10.txt L1194–1199):

> Definition (Conditional Topological Theorem — Shell Count). The exact shell cardinality N(d) = 4d² + 2 is a Conditional Topological Theorem requiring the full four-layer architecture [L1·L2·L3·L4]. It is exact and rigorously proved within this framework, but it is not an output of Layer 1 (the 27-state inventory) alone, nor of any single layer in isolation. Evaluators must verify the full dependency chain before treating the shell count as established.

§2.4.3 restatement (paper10.txt L1231–1234):

> Exact finite shell-count output: For a locally isotropic relational medium with 3-axis topology, the number of configurations at exactly d relay steps from any given origin is exact: N(d) = 4d² + 2. The coefficient 4 is the canonical Taxicab Shell Cardinality coefficient fixed by the Taxicab Shell Cardinality Theorem (§5.3.2); it is not a fitting parameter. The 3-axis point-shell count inherits this coefficient as the leading coefficient of N(d) = 4d² + 2 (Constant Lineage Register, §0.5.w).

Constant Lineage Register derivation sketches as printed (§0.5; paper10.txt L408, L418):

> DERIVATION: Planar shell count N_planar(ρ) = 4ρ; inherited leading coefficient of N(d) = 4d² + 2.
>
> DERIVATION: Integer enumeration of the ℤ³ taxicab shell gives N(d) = 4d² + 2; the constant term 2 is the exact finite-shell offset.

Related suppression sequence (used with N(d); Paper 10 §2.4.10 / abstract; paper10.txt L40):

> quantized finite-shell suppression sequence δ(d) = −2/(4d²+2)

### 1.5 The theorem at work — §2.4.6 (paper10.txt L1370–1379)

> By the Uniform Partition Definition (§2.2), the total query rate s²_node must be distributed across the available processing configurations.
> By the Uniform Load Partition Theorem (§2.4.7), the workload distributes evenly across all configurations at the same relay distance d. The per-configuration strain is:
> S(d) = s²_node / N(d)
> For large finite d, N(d) approaches the leading term 4d², yielding the large-d shadow behavior:
> S(d) ≈ s²_node / (4d²) for d sufficiently large that the +2 offset is below operational resolution.
> This is the inverse-square attenuation. It emerges from the 3-dimensional branching of scan-relay propagation, not from a background coordinate system.

### 1.6 Scope note on the S₃ assumption (§2.4.4 module; paper10.txt L1326–1332)

> The isotropic shell average S(d) = s²_node/N(d) holds under the S₃ symmetry assumption of the Uniform Load Partition Theorem (§2.4.7), which averages over axis permutations. Anisotropic source corrections—accounting for the fact that an isolated State 7 configuration emits scan workload preferentially along its tilted axis—are deferred to Paper 23.

---

## 2. Paper 9 — The Asymmetry of Occasion

### 2.1 The passage (Paper 9, §5 "The Structural Budget Shift: Divergence vs. Alignment"; paper9.txt L409–428; PDF pp. 10–11)

The passage is an unnumbered bold-lead paragraph inside §5. Verbatim, complete:

> The asymmetry of occasion — why heat flows hot to cold. The underlying mechanisms of heating and cooling are perfectly symmetric under the budget rule, but their structural occasions are not, and this asymmetry is the mechanical root of the thermodynamic arrow. Chaotic, mismatched insertions arise from any generic, unaligned [— page header in source —] intersection of manifold scans anywhere in the medium — they require no preparation. Forced structural cooling, by contrast, requires a highly specific, phase-aligned standing structure already in place to compel the surrounding registers into order. Chaotic disorder is the default writing of random intersection; coherent alignment is the highly specialized one. Heat therefore flows spontaneously from hot to cold not because of an abstract statistical probability imposed from outside, but because disordered creation geometry is the mechanical default of an unguided collision, while ordered resolution is the rare, prepared exception. This thermodynamic asymmetry of occasion is not a mere statistical probability of macroscopic states, but a structural necessity driven directly by the mechanics established in Paper 2: because open background states (States 2 through 8) are inherently unstable and un-anchored, their temporal scans must continuously cycle through local coordinates searching for geometric resolution. This active, open-state search behavior inherently drives the directional, chaotic progression of the manifold, providing the explicit geometric anchor for the thermodynamic arrow before any statistical averaging takes place. The full statistical aggregation of these asymmetric occasions — alongside the mechanical derivation of entropy and the thermodynamic arrow — is deferred as a locked coordinate and a declared boundary condition to Paper 12, constrained by this asymmetry of occasion.

Note the final sentence: Paper 12 is named in Paper 9 itself as the venue for "the full statistical aggregation of these asymmetric occasions," "constrained by this asymmetry of occasion."

### 2.2 The definition of "occasion" (Paper 9, §3; paper9.txt L180–181)

> The intersection of two scans of the kind established in Paper 7.5 is the occasion; the chaotic character of the geometry forced into the registers is what makes the occasion thermal.

### 2.3 Companion statement — Second Law reading (§5, following the asymmetry passage; paper9.txt L435–438)

> The Second Law (entropy always increases; heat flows hot to cold) is the natural dispersal of localized rewrite cycles into neighbouring coordinates, because the medium automatically distributes forced geometric backpressure toward regions with a higher remaining processing budget.

---

## 3. Paper 9 — Definitions

### 3.1 Contact budget — NOT FOUND in Paper 9 in the 100 CU form; here is what each paper actually prints

**Paper 9's own budget rule** is the orthogonal sum rule over the Circa budget, inherited from Paper 8. Verbatim, dependency summary (§1; paper9.txt L90–95):

> From Paper 8: the fixed Circa budget, the three-percent identity skim, the ninety-seven percent translation ceiling c, and the orthogonal sum rule v2 + s2 = c2 — the budget constraint every thermal transaction in this paper obeys.

§5 statement (paper9.txt L310–315):

> The congestion draw — heating. Under the orthogonal sum rule established in Paper 8, a configuration's fixed budget splits between spatial translation (v) and the manifold scan that holds and reconciles its geometry (s), with the two as orthogonal draws on the one conserved ceiling: v2 + s2 = c2. When a mismatched geometric insertion forces an increase in chaotic reconciliation work, the configuration's scan cycles (s) must rise sharply to maintain the ledger. Because the total is fixed at c, those cycles are pulled directly away from translation: v falls as s rises.

§8 restatement (paper9.txt L647–652):

> Energy conservation is not an imposed law but a theorem of the architecture: because the medium cannot write a fractional vector or manufacture free capacity from nothing, the geometry forced by an impact must transfer whole and balance exactly, and because the processing budget is fixed at c under v2 + s2 = c2, every cycle the scan gains is a cycle translation loses, and every cycle the scan sheds is a cycle translation regains.

Exhaustive check: the strings "100", "CU", "N_total", "N_id", "N_reconcile", and "v²_contact" do **not** occur in paper9.txt (the only "100" hit is inside a DOI in the references).

**The 100 CU contact-budget equation is printed in Paper 10, §2.2** ("The Budget Accounting: v² + s² = C_exec and Single-Ledger Tick Conservation"). Verbatim build-up (paper10.txt L933–985):

> Hardware Invariance Axiom. The execution substrate allocates exactly N_total = 100 indivisible operation units (CU) per configuration per tick. This is partitioned into an invariant identity overhead and an invariant post-identity execution capacity:
> N_total = N_id + C_exec = 3 + 97 = 100 CU.
> (Axiom: N_id and C_exec are never penetrated by external events.)
>
> Contact Reallocation Axiom. During a contact event, the configuration does not expand its total hardware budget. Instead, it reallocates a portion of its quiescent spatial budget to external event processing:
> v²_quiescent = v²_contact + N_reconcile. (2.2a)
> The post-identity budget during contact is therefore:
> C_exec = v²_contact + s² + N_reconcile. (2.2b)
> Total Budget Check. Substituting (2.2a) into the contact partition:
> N_total = N_id + v²_contact + s² + N_reconcile = N_id + v²_quiescent + s² = 100 CU. (2.2c)

And the Layer II statement carrying the target equation as eq. (2.4) (paper10.txt L978–985):

> Layer II — External Event Reconciliation (Contact-Bound). A contact event delivers creation geometry ΔG_event from the incoming configuration. This geometry is external to the struck configuration's pre-existing budget. Processing it requires N_reconcile CU of chaotic rewrite work (Paper 9, §8.1). The total hardware load during the contact tick is the exact integer sum:
> N_total = N_id + v²_contact + s² + N_reconcile = 100 CU. (2.4)

Layer I, for completeness (paper10.txt L973–976):

> Layer I — Internal Execution Budget (Invariant). Every configuration maintains a fixed post-identity execution budget for its own state operations:
> C_exec = v² + s² (in CU). (2.3)

⚠ Attribution note for drafting: citing the 100 CU contact budget to "Paper 9" would be an address error. Paper 9 supplies the *physics* (reconcile work at contact; its §8.1 as cited by Paper 10); the *arithmetic form* (N_total = 100 CU partition) is Paper 10 §2.2's, built on Paper 8's Circa budget.

### 3.2 Temperature — no `T_ledger` symbol in either paper; Paper 9's definition is verbal

The symbol `T_ledger` does **not** occur in paper9.txt or paper10.txt. Paper 9's definition, verbatim (§4 "Temperature as the Density of Rewrite Events"; paper9.txt L241–250):

> 4. Temperature as the Density of Rewrite Events
> If heat is the work of resolving chaotic creation geometry, temperature is the rate at which that reconciliation work is demanded.
> Temperature is the localized density and frequency of chaotic creation-geometry rewrite events per tick. A region of the medium in which incompatible insertions are frequent and densely packed is running many reconciliation cycles per tick — its registers are being written with mismatched geometry and recomputed at a high rate. A region in which such events are sparse, or in which the geometry being written is coherent rather than chaotic, runs few such cycles. Temperature is the measure of that congestion: how many chaotic rewrites the local medium must execute per tick to keep its registers resolved.

The §2 form (paper9.txt L106–108):

> The rate of these chaotic rewrite events per ledger tick is what the observer macroscopically measures as temperature.

Abstract form (paper9.txt L27):

> Temperature follows as the localized density and frequency of chaotic rewrite events per tick, and thermal transfer [continues]

Absolute-zero scope statement (§4; paper9.txt L265–266):

> Absolute zero is the condition of a region in which no incompatible geometry is being written, so there is no reconciliation work to do.

Scope labels: **none.** Paper 9 uses no Stage P / Stage C (or any stage) labels for temperature — the words "stage" and "scope" do not occur in paper9.txt. Any Stage-P/C scoping of T_ledger in Paper 12 is Paper 12's own construction, not an inherited label; the inherited content is: *temperature = localized density/frequency of chaotic rewrite (reconcile) events per tick — a count ratio over ticks.*

Per-tick counting anchor, Appendix A (paper9.txt L684–694) — the closest Paper 9 comes to a scaling statement for per-tick counts (see §3.4):

> The manifold scan must therefore execute a series of discrete reconciliation sub-routines per tick to carve that mismatch into permitted whole-step vectors. The total processing cost drawn into the scan (s) is a direct function of the geometric divergence between the standing registers and the incoming insertion: the more sharply the insertion conflicts with what is already seated, the more sub-routines per tick the reconciliation demands. When the divergence is chaotic — when the incoming vectors are mutually non-aligned and disagree with the standing geometry along multiple axes at once — the per-tick rewrite count rises steeply, and that steep rise is the physical manifestation of high temperature. … The appendix thus grounds temperature in a single quantity: the per-tick reconciliation count forced by the structural divergence of the insertion.

### 3.3 Junction Saturation Threshold — defined in NEITHER Paper 9 nor Paper 10; Paper 9 cites Paper 7

Paper 9 names the JST as a Paper 7 primitive in its dependency summary (§1; paper9.txt L90):

> From Paper 7: the Junction Saturation Threshold and processing-rate mechanics governing loaded junctions.

Its two substantive uses in Paper 9, verbatim:

(§2; paper9.txt L127–131)

> The ledger resolves directional updates exclusively at whole steps of the resolution floor, because any fractional displacement falls below the Junction Saturation Threshold (Paper 7) — a fractional write cannot form a standing gradient and is structurally rejected by the medium's primitive conservation laws.

(§2, creation geometry; paper9.txt L149–150)

> …the raw coordinate updates generated when intersecting manifold scans force localized axis-tilt shifts that exceed the local Junction Saturation Threshold (Paper 7, Section 5.1.1). It is the mandatory cost of balancing the ledger under load on the single tick it appears…

Paper 9's saturation *behavior* (not a JST definition) is §6's ejection cascade, Step 1 (paper9.txt L461–463):

> Step 1, local budget saturation: as chaotic insertions accumulate, reconciliation cycles consume the remaining budget until the standing scan load plus the chaotic rewrite workload reaches the whole of the local processing capacity, and the local ledger hits absolute saturation.

And §5's Stefan–Boltzmann reading (paper9.txt L441–443):

> And the Stefan-Boltzmann law (radiated power scaling with the fourth power of temperature) is the geometric saturation threshold: as localized rewrite density forces the ledger toward absolute saturation, the rate of mandatory structural ejections — State 9 releases — climbs steeply as the medium struggles to clear its capacity.

⚠ For drafting: "Junction Saturation Threshold = aggregate-load ceiling" is **not** a quotation from Paper 9 or Paper 10; in both papers the JST is Paper 7's local/register-level threshold. Any aggregate-load reading in Paper 12 must be built (and badged) as Paper 12's construction on top of §6's saturation cascade, not cited as Paper 9's definition.

### 3.4 The 3^N scaling — NOT FOUND as a per-tick sub-region passage in Paper 9

Exhaustive search of paper9.txt for "3^N", "3N", "sub-region", "subregion", exponential/combinatorial scaling of per-tick counts: **no match.** Paper 9 contains no 3^N statement of any kind.

The only "3^N" in either source file is Paper 10, Appendix E ("The Algebraic Impossibility of Static Negative Tilt"), E.1 (paper10.txt L3230–3233), verbatim:

> E.1 Axiomatic Foundation
> Axiom E.1: v² ≥ 0, s² ≥ 0, v² + s² = C_exec.
> Axiom E.2: Ω_max = 3^N configurations. No state encodes negative persistent tilt.
> Axiom E.3: Incoming scan work + local scan work ≤ local capacity.

This is a **state-space cardinality bound** (each of N configurations ranges over the 3-value axis alphabet in the Appendix E argument), stated as an axiom for the negative-tilt impossibility proof — it is not a per-tick sub-region count and not a Paper 9 passage. If Paper 12 needs a 3^N-style growth count for aggregated records, it must derive it (e.g., from the 27 = 3³ inventory per body, Paper 10 §2.4.3 / Axiom E.2's form) and badge it as its own derivation — it cannot be quoted from Paper 9.
