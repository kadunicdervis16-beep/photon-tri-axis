# COMPARATIVE BATTERY REPORT — DS-12 and GS-1 against Paper 12 v3

*Clerical assembly.* This document places the two battery reports side by side. It merges nothing and re-adjudicates nothing: every badge, witness, and ground below is carried from `DS12_BATTERY_REPORT.md` or `GS1_BATTERY_REPORT.md`, and each entry names the report section to cite for it. Where the two reports use different words for the same thing, both wordings are quoted.

**Targets, as each report states them.** DS-12 ran against `staging_v6/Paper_12_v3.md`, sha256 `168ff55a61c2f30a59de1861ac0d4de8e4e6126189d07e37c8670893ce299e0b`. GS-1 ran against `Paper_12_v3.md`, sha256 `010cc32717c6845ced429b3e46415ec1c99e91aef95160320d2e65c732a83462` — the typo-repaired file; the hash difference between the two targets is recorded in the GS-1 report's target-hash note and logged there as its self-defect SD-1.

---

## 1. Closing badge lines, verbatim

**DS-12** (DS12 report, "Closing badge"):

**[DS-12-COMPLETE: 2/8 DS-HELD, 0/8 DS-BROKE, 6/8 DS-LIMIT, 0/8 DS-OUTSIDE]**

**GS-1** (GS-1 report, "Badge line"):

```
[GS-1-COMPLETE: G1 GS-LIMIT, G2 GS-HELD, G3 GS-HELD, G4 GS-HELD, G5 GS-LIMIT, G6 GS-HELD, G7 GS-HELD, G8 GS-BROKE | battery GS-1.0 | paper Paper_12_v3.md sha256 010cc32717c6845ced429b3e46415ec1c99e91aef95160320d2e65c732a83462 | witnesses reproduced 2/2 per badged attack | adjudicator ran nothing]
```

---

## 2. Per-theme contrast

| Theme | DS-12 — badge and ground (one line) | GS-1 — badge and ground (one line) |
|---|---|---|
| **Factorization / Cap** | **T2 — DS-LIMIT.** At the premise-instantiating layer, 0 violations in 946,428 Cap comparisons; Layer 1's 21,800 violating triples (of 47,034) exploit the free-encounter index pairing the premise discards — "Theorem 6.2 is a single-tick statement and cannot be iterated through T." Cite: DS12 report §T2. | **G1 — GS-LIMIT.** The T-shadow properties are false in bulk (590,243 counterexamples per face; permutation equivariance fails at every port count), but "T is not consumed by the proof" of Theorem 6.2 (premise list, Pr-6), so the failure is a scope determination, not a counterexample to L6.2-P12. Cite: GS-1 report §G1. |
| **The joint hunt** | **T5 — DS-LIMIT** (exploratory). 81 trajectories: drift-high 0/81, drift-low 63/81, stationary 18/81; every trajectory rests at (0, n), Ω = 1; the maximal record is visited 24/81 and rested at 0/81; mechanism — under φ, no φ=A state is a fixed point and T can never create one, so k cannot rise under this feature. Cite: DS12 report §T5. | **G3 — GS-HELD** (sweep; characterisations graded inside, CH-1/CH-2/CH-3 all GS-HELD). 1,067,744 populations; "every population in the family rests at the single record (0, n), Ω = 1"; CH-1 survives on φ (§8.7's feature), the other two family features failing at the junction-member census reading. Cite: GS-1 report §G3. |
| **The molecule reduction** | **T4 — DS-HELD.** Atom-route and flattening trajectories agree at tick 0 and all 10 ticks for both floor-corrected configurations; no divergence witness. Cite: DS12 report §T4. | **G2 — GS-HELD.** All 119 connected groupings of 11 molecules over 10 ticks: 1,190 key comparisons and 1,190 σ-reconstruction comparisons, all equal; 0 mismatches; the §11.2 worked example re-derived (B(mol) = 29 by both routes). Cite: GS-1 report §G2. |
| **C32 / the discharge** | **T6 — DS-LIMIT** (inside-scope probe (g) DS-HELD). Probes (d) initial conditions, (e) junction formations, (f) parameter values each fail native-statability; "C25's killer is not exhibited on any probe. C32's antecedent is instantiated by no probe." Cite: DS12 report §T6. Companion: **T7 — DS-LIMIT** — "discharged by dissolution" is exact within the declared domain and overstates as an unqualified label. Cite: DS12 report §T7. | **G8 — GS-BROKE.** Q7b, the named-pair joint frequency, is inexpressible by any census or flow count: two populations whose finest census sequences and finest flow tables are identical give Q7b answers 1/4 and 0; "C32's first disjunct is instantiated"; the casualty is L5.4-P12's scoping claim as C32 states it. Cite: GS-1 report §G8. |
| **Reconcile accounting** | **T8 — DS-LIMIT**; C28 not instantiated. All three temperature properties are not definable in the paper's constructions (no contact construction); where defined, D verifies exactly — R(P, W) = 41, D(P, W) = 41/40, the (7.4) mean identity holds. Cite: DS12 report §T8. | **G4 — GS-HELD.** 79 checks, 0 failures: window additivity holds on every split and tiling — §7.5 (R = 41, D = 41/40) and Appendix D (R = 55, D = 55/36), all D arithmetic in exact rationals. Cite: GS-1 report §G4. |
| **Self-containment** | No DS-12 attack targets this theme (no badge). The battery's T1–T8 do not test Appendix C / A.9; the theme is absent from the DS12 report's attack sections (§§T1–T8). | **G7 — GS-HELD.** Ten tamper cells plus two controls, all reproduced: "Every cell's observed outcome is the outcome the disclosures predict for that cell"; the T-b′ paper-alone escape (two scripts passing under each other's names) sits exactly on the disclosed §C.1(d) line. Cite: GS-1 report §G7. |

**Same fact, two wordings** (quoted, per assembly rule). On arrangement sensitivity, DS-12: "T's post-state presented profile **is** arrangement-sensitive"; GS-1: "the M-shadow of one tick genuinely carries arrangement information." Both batteries record the cross-check that the counts coincide: GS-1 — "G1's A-face ordered counts at p = 2, 3, 4 (28; 856; 20,916) coincide with DS-12 T2 Layer 1's — two batteries, one fact."

---

## 3. The T6–G8 contrast, in the GS-1 report's own terms

From the GS-1 report's closing section, "Disclosure beside DS-12," verbatim:

> "DS-12's T6 probes (d)–(f) asked after C32 and found no instance — GS-1's G8, hunting *inside* the antecedent with identity-resolved questions, found one. That difference is the batteries' designs, not a contradiction: T6 probed outward (initial conditions, junction formations, parameters — all at or beyond the paper's scope boundary), G8 probed at the boundary the antecedent itself draws."

Neither report withdraws anything on account of the other: DS-12's T6 verdict stands over the probes it ran ("C32's antecedent is instantiated by no probe"), and GS-1's G8 verdict stands on its exhibited instance ("C32's first disjunct is instantiated"). The contrast is one of attack design — outward probing versus identity-resolved probing inside the antecedent — and is recorded here without reconciliation, because the two reports, read at their stated scopes, do not conflict.

---

## 4. Design rating summary

**DS-12 as a design: rated 7/10.** Its contributions, as the two reports record them: the four-badge taxonomy (HELD / BROKE / LIMIT / OUTSIDE), kept by GS-1 in its own naming; the joint-hunt framing (T5), which GS-1's G3 rest-record census extends; and T2's population-level Step 5, the premise-instantiating layer on which T2's adjudication turned. Its logged defects are the battery-defect register BD-1–BD-4 (DS12 report, opening register): T1's Paper-11 encounter idiom (BD-1), T1 Step 10's "reconcile declared" (BD-2), T4 configuration (i)'s sub-floor atom (BD-3), and T2 Step 3's conflation of a free encounter with an established junction's fixed port pairing (BD-4).

**GS-1's principles**, as executed in its report: badges assigned by an adjudicator who ran nothing ("adjudicator ran nothing," badge line); witnesses as reproduced artifacts — two independent reproducers, artifacts-only, as a precondition of any badge (GS-F2: "No badge below rests on an unreproduced witness"); the closing badge line arithmetic-matched against the per-attack badges (GS-F3); a coverage map executed per attack, with the verified domain and what lies outside it stated at each attack; and a self-defect register for the battery itself (Rule 6 — GS-F1), in which GS-1 logs five defects of its own:

- **SD-1 (target hash).** GS-1.0's header, §2.1 template, and §6 name the target at sha256 `168ff55a…`; the run was commissioned and executed against the typo-repaired file at `010cc327…`. A stale-hash defect in the specification's own paperwork.
- **SD-2 (G1 framing).** G1 §1 presupposes §8.6's factorization rests on T's M-shadow; G1's own premise audit disproves the presupposition (the proof consumes §8.6 + §8, not T). DS-12's BD-4 conflation recurring inside GS-1's own text.
- **SD-3 (G3 palette labels).** Two provenance labels in G3's palette are wrong against the paper (σ_R's state; palette index 1's source). The executed states are the states as listed, so the sweep stands; the labels are defective.
- **SD-4 (G4 upstream clause).** G4 field 5 instructs a recomputation "by A.7's route" from contact data that neither Appendix D nor A.7 declares. The route does not exist; the attack executed the route that does exist, openly.
- **SD-5 (G5 clause (ii) under-specification).** G5 field 4 sends the attack to "profiles with totals above the taxonomy's maximum"; §8 states no maximum. The attack recorded its choice (totals 5–6).

---

## 5. The author's list — everything both batteries carry forward

1. **The G8 repair fork** (GS-1 report §G8). C32's first disjunct is instantiated by Q7b; by C32's own terms, item (2) of the §1.6 discharge plan reopens. The repair is the author's choice between the two forms the report names — "narrow the discharge's scope wording to member-class frequencies, or extend §5's instruments" — the battery reports the break and does not choose.
2. **The G5 gloss wording at three sites** (GS-1 report §G5). Paper 12's §6 introduction (lines 839–841), its §1 receipt (line 146), and L6.1-P12's registry text assert that encounter kinds are "specified (completely) by [their] presented-count profile M = (n+, n−)" — inaccurate as a description of Paper 11 §8, where each kind is a condition on an ordered pair of presented tuples and no single profile individuates any kind. (Def 6.1's membership phrase "E's presented-count profile M(E)" inherits the compression.) Graded GS-LIMIT: no operative claim assigns or omits a Cap pair wrongly; the defect is in the one-line description of the imported taxonomy. The same finding carries a datum for L12.1-P12's completeness — a defect class (a false description of an imported taxonomy) that no §12 condition names — recorded without upgrading any badge.
3. **The §6 no-iteration note candidate** (DS12 report §T2 and closing suggestions (i); GS-1 report §G1). DS-12: "any future corollary of Thm 6.2 must not claim profile-invariance under the tick (T2, Layer 1 refutes it in advance)"; GS-1 confirms the boundary exhaustively to p = 4 and by sweep to p = 6. Candidate for the author's list: an explicit §6 note that Theorem 6.2 is a single-tick statement and cannot be iterated through T.
4. **The §1.2 cross-reference slip** (DS12 report §T7, bycatch; closing suggestions (iii)). §1.2 cited the MC.1 re-scoping as "§5.4"; in v3 the re-scoping sits at §5.6. **CLOSED 2026-10-26** — corrected on the author's order before the GS-1 run; the delivered v3 is the repaired tree (sha256 010cc327…), with a repair note in its version block.
5. **The §8.6 characterisation split, as a suggestion** (DS12 report §T5 and closing suggestions (ii)). "§8.6's relational characterisation may profitably split into a feature-level part (which records can be rest records — fixed-point content of the feature's positive class) and a population-level part (which records are visited)" — labelled in its report as suggestion, not finding; GS-1's G3 characterisation verdicts (CH-1 held on φ; the junction-member census failures of the other two family features) are the second battery's evidence at the same site.

*End of comparative assembly. The two battery reports remain the documents of record; this file only sets them side by side.*
