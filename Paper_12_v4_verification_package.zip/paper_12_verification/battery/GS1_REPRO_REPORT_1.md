# GS-1.0 Battery — Stage 2 Reproduction Report (REPRODUCER 1)

**Role:** Reproducer 1, Stage 2 of the process in
`GOLD_STANDARD_BATTERY_GS1.md` (§2). Every attack G1–G8 was re-run
**from the shipped artifacts alone**, in a scratch copy. **No badges
are assigned and nothing is graded in this report** — it records
reproduction facts and discrepancies only.

**Target paper (read-only):** `staging_v6/Paper_12_v3.md`,
sha256 `010cc32717c6845ced429b3e46415ec1c99e91aef95160320d2e65c732a83462`
— verified **before** the work and **after** the work; unchanged.
(The GS-1.0 specification's header names a different hash,
`168ff55a…`; that discrepancy is in the shipped attack reports
themselves and is not a reproduction finding of mine.)

**Scratch:** `~/workspace/gs1_repro1_scratch/paper_12_draft/ds12/gs1/`
(mirrored layout, with `staging_v6` symlinked read-only, because
several programs locate the staging tree relative to their own
path; `/tmp` is a 512 MB tmpfs and could not hold the artifact set).
Nothing was written into the shipped attack directories or the
staging tree: after all runs, all 128 shipped files under
`ds12/gs1/g1…g8` were re-hashed against the baseline taken before
the runs — **all 128 unchanged**.

**Summary:** G1 REPRODUCED (one environmental byte-difference in
`results.json`, detailed below — all counts identical) · G2
REPRODUCED · G3 REPRODUCED · G4 REPRODUCED · G5 REPRODUCED · G6
REPRODUCED · G7 REPRODUCED (A.9 per-cell outputs differ only in
workdir path strings; the observation table is byte-identical) ·
G8 REPRODUCED. **No discrepancies in any count, witness, or
verdict were found. No attack was COULD-NOT-RUN.**

---

## G1 — Factorization, generalized — REPRODUCED

Commands (in scratch `g1/`):

```
python3 generate_generating_sets.py   # exit 0
python3 g1_runner.py                  # exit 0, wall 48.23 s (shipped: 89.11 s)
python3 verify_witnesses.py           # exit 0
```

- Generating-set files regenerated **byte-identical**:
  `g5_vectors.txt` sha256 `89983cdc636fbb92…`, `g6_vectors.txt`
  `8d1a32e8589df062…` (|G₅| = 96, |G₆| = 198, construction_match
  re-validated by the runner).
- Counterexample files **byte-identical** to shipped:
  `counterexamples_a_face.txt` sha256
  `b2e6bb0a3c49a9f42f97966a8e08ed82dfcabd1e53d0579143970a34481aa1af`
  (590,243 lines); `counterexamples_b_face.txt` sha256
  `5b9711e647ee945fb5bc738dfe67f6f79661c7d7b9211b62ac4997a3d1dfdc48`
  (590,243 lines). `equivariance_witnesses.txt` byte-identical
  (sha256 `1f9944d31b6c8593…`); `run.log` byte-identical.
- `results.json` counts — **all identical** to shipped, both faces,
  all domains: A-face and B-face counterexample counts
  14 / 428 / 10,458 (exhaustive p = 2, 3, 4) and 38,444 / 540,899
  (sweep p = 5, 6); totals 590,243 unordered / 1,180,486 ordered per
  face; checks 1,084,407 unordered per face; implementation
  agreement 7,371 exhaustive states, 0 disagreements; equivariance
  failures 4 / 284 / 17,984 / 130,800 / 4,487,520 at p = 2…6.
  The one byte-level difference in `results.json` is environmental,
  not numerical: its `input_hashes` keys are absolute paths (the
  shipped run's keys point at
  `~/workspace/goals/paper-12-the-aggregated-ledger/files/paper_12_draft/…`,
  mine at the scratch tree; the hash **values** are identical), and
  `wall_time_seconds` differs (89.11 shipped vs 48.23 mine). A
  field-by-field comparison confirms every other field — all
  counts, agreement and equivariance sections — is identical.
  My `results.json` sha256:
  `f69fafb3660bfdf686e95ab9b1797bd176979e9a40e5be1ba1eb1aee4467019e`
  (shipped: `7fed102a0fb6b0e1f…`).
- `verify_witnesses.py` (which uses `t_impl_b`, the *other*
  implementation than the runner's primary): exit 0 — all
  1,180,486 shipped face-counterexample lines re-verified, 0 failed,
  per-(p, domain, face) line counts match `results.json`;
  `verify_witnesses.log` byte-identical to shipped.
- **Hand-computation of 3 sampled triples** with my own from-scratch
  T (a third implementation, written from §4's text; the shipped
  counterexamples were produced via `t_impl_a` and shipped-verified
  via `t_impl_b`): (1) A-face line 1, p = 2: σ = ((−1,+1),(−1,0)),
  σ′ = ((+1,−1),(−1,0)) — M(A) = M(A′) = (1,1); M(T(σ)) = ((1,1),(0,1)),
  M(T(σ′)) = ((0,1),(0,0)) — matches file, differ. (2) B-face line
  300,000, p = 6: σ = ((0,0,0,−1,0,0),(−1,+1,+1,+1,+1,−1)),
  σ′ = ((0,0,0,−1,0,0),(+1,−1,+1,−1,+1,+1)) — M(B) = M(B′) = (4,2);
  M(T(σ)) = ((0,0),(3,2)), M(T(σ′)) = ((0,1),(4,2)) — matches file,
  differ. (3) A-face last line, p = 6: σ = ((1,0,0,0,1,0),(1,1,1,1,−1,−1)),
  σ′ = ((1,1,0,0,0,0),(1,1,1,1,−1,−1)) — M(A) = M(A′) = (2,0);
  M(T(σ)) = ((1,0),(4,1)), M(T(σ′)) = ((2,0),(4,2)) — matches file,
  differ. All 3 hand-verified.

## G2 — Molecule grouping independence — REPRODUCED

Command: `python3 g2_program.py` (exit 0) in scratch `g2/`.

- `output.txt` **byte-identical** (sha256 `d38ca2bb9cb44c83…`);
  `results.json` **byte-identical** (sha256 `ee035c371a88c006…`);
  `molecules.json` unchanged (sha256 `214b87c71e18dc33…`).
- Grouping counts from **both enumerators** agree per molecule and
  with shipped: 4/4 (worked example), 4/4 path_3, 8/8 path_4, 16/16
  path_5, 4/4 star_3, 8/8 star_4, 16/16 star_5, 12/12 cycle_4,
  27/27 cycle_5, 5/5 complete_3, 15/15 complete_4 — total 119
  groupings by each enumerator. Path counts 4, 8, 16 as specified.
- Totals line reproduced exactly: key comparisons **1,190 run /
  1,190 equal**, σ-reconstruction comparisons **1,190 / 1,190**,
  A.8-route checks 119 / 119, mismatches 0. Worked example
  B(mol) = 29 by both routes, key (7, (2,2,2,2,2,3), 29, 19, 6).

## G3 — Rest-record census — REPRODUCED

Commands (in scratch `g3/`):

```
python3 gen_j8_input.py   # exit 0; inputs/j8_subfamily.json byte-identical
python3 g3_program.py     # exit 0, ~62 s
python3 verify_g3.py      # exit 0 (shipped self-check, run as a leg)
```

- `outputs/summary.json`, `outputs/witnesses.json`,
  `outputs/run.log`, `outputs/console.log` all **byte-identical**
  to shipped. The 207 MB tabulation was **hash-compared in full**:
  `outputs/tabulation.jsonl` sha256
  `c418d61e7b86a957cbfe3838d4f9449a4876531acea00e2d9c2a0302ab1d95d1`
  — identical to shipped.
- Family size reproduced: **1,067,744** populations (J = 4: 16,384;
  J = 6: 1,048,576; J = 8 structured: 2,784; 696 assignments × 4
  assemblies). Per-characterisation pooled violation counts
  identical to shipped: CH-1 ψ=φ: 0 violating pairs (30 groups);
  CH-1 admissible-count, junction census: 68/68 groups violating,
  **28,143,226,010** pairs; CH-1 admissible-count, body census: 0;
  CH-1 all-zero, junction census: 21/21 groups, **152,170,736,738**
  pairs; CH-1 all-zero, body census: 0; CH-3: 0 (394 groups);
  CH-2: **0** violations in every stratum. Stratified violating
  pairs: 0 for every test (as shipped).
- **All 89 witness groups independently validated by
  re-simulation** with my own from-scratch T (not the shipped
  program's machinery): for each of the 178 witness populations I
  re-checked the initial σ against the declared assignment,
  stepped every tick by T_agg, recomputed the body-level φ record
  path, Ω = C(n, k) per tick, and the τ_agg path, and confirmed
  the final tick is a fixed point, the rest record matches, and
  the pair's rest records differ. **0 mismatches.** The shipped
  `verify_g3.py` also passes all three of its legs on my
  regenerated outputs (tabulation recount agrees; 18-population
  resimulation agrees; 89 witnesses validated).

## G4 — Window additivity — REPRODUCED

Command: `python3 g4_program.py` (exit 0) in scratch `g4/`. The
program re-parses the target paper (read-only) and rewrites
`inputs/` and `outputs/` in the scratch copy.

- All regenerated inputs **byte-identical** to shipped (all 4 JSON
  inputs and all 3 excerpt files; hashes match the RUN_REPORT
  table). All outputs **byte-identical**: `outputs/output.txt`
  (sha256 `1aa97d02b9ec8085…`), `outputs/output.json`
  (`ee2a48be1d2f70ab…`), `outputs/detail_tables.md`
  (`1b3d1813ec1058c0…`), `g4_run.log`.
- **79 checks passed / 0 failed**, as shipped. Printed values
  confirmed: §7.5 full window R = 41, D = 41/40; Appendix D
  R = 55, D = 55/36; §8.7 acting (12, 6, 0), Δτ_agg (−24, −12, 0).
- **Two split identities spot-verified by hand** from the parsed
  tables (my own summation over the shipped `r` tables):
  (§7.5) split 1–4 | 5–10: R₁ = 19, R₂ = 22, sum 41 = R;
  D₁ = 19/16, D₂ = 11/12, weighted mean (4·D₁ + 6·D₂)/10 = 41/40 —
  both identities hold and match the shipped table.
  (Appendix D) split 1 | 2–3: R₁ = 18, R₂ = 37, sum 55 = R;
  D₁ = 3/2, D₂ = 37/24, weighted mean (1·D₁ + 2·D₂)/3 = 55/36 —
  both identities hold and match the shipped table.

## G5 — Capability at the taxonomy's edge — REPRODUCED

Commands (in scratch `g5/`): `python3 extraction_program.py`,
`python3 shared_profile_witness.py`,
`python3 A4_capability_pristine_copy.py`,
`python3 A4_capability_unextended.py`,
`python3 A4_capability_extended.py`, `python3 diff_pairs.py` —
all exit 0.

- **Independent extraction repeated:** I extracted the embedded
  `paper_11_v69` from the target's §C.4 myself (BEGIN SOURCE marker
  at target line 17781; content lines 17783–44061; 1,842,415 bytes,
  sha256 `f77c473ecffc773b35d2aa2fd216494d2b1ee8a9438fd98866633fffdd24adbb`
  — matches the target's own §C.2 manifest entry). The extracted
  file is **byte-identical** to the shipped extraction.
- **§8 kind list re-derived from my extraction:** §8.1 (extracted
  lines 698–700) lists exactly three kinds — **Attraction,
  Repulsion, Forced Decay** — plus the refused/outside-domain
  branch for an all-zero incoming side (domain guard, §8.6). No
  kind is assigned a single presented-count profile M(E) in §8;
  the selection rule (§8.6, extracted line 768) is a function of
  the directional residue res(A, B) over the ordered pair of
  presented tuples, the threshold interval 0 < TH < k, and the
  guard. **Branch determination independently reproduced:
  Branch B** (kinds carry individuating data beyond a single M).
  `shared_profile_witness.py` re-run: log byte-identical —
  incoming (2, 0) selects Attraction / Repulsion / Forced Decay
  against neighbours (0, 2) / (0, 1) / (0, 0); neighbour (0, 1)
  likewise shared; (0, 0) refused against every neighbour.
- All three A.4 runs' outputs **byte-identical** to shipped
  (`output_pristine.txt`, `output_unextended.txt`,
  `output_extended.txt`), as are `pairs_unextended.json` (788
  pairs) and `pairs_extended.json` (1,476 projected pairs).
  `diff_pairs.py` re-run reproduces `pairs_diff.txt`
  **byte-identically**: **688 projected pairs added**, every one
  for one of the 13 added unrealised profiles (totals 5–6), 0
  removed, 0 cells changed on the original 15 profiles, 0 pairs
  for profiles in neither taxonomy; duplicate-kind cells:
  `K(0, 1)#A` and `#B` each in exactly **59** cells, `K(2, 0)#A`
  and `#B` each in exactly **49** cells, no cell containing one
  without the other.

## G6 — (E1) two-route agreement — REPRODUCED

Command: `python3 g6_two_route.py` (exit 0) from the shipped
`g6_input.json` in scratch `g6/`.

- `g6_output.json` **byte-identical** (sha256
  `e4c2857bfe40a254…`), `g6_tick_table.csv` **byte-identical**
  (sha256 `81c6bf59af53ec…`), `g6_run.log` **byte-identical**
  (sha256 `ecaa602fecf179…`).
- **6,283 tick checks / 0 disagreements** reproduced (2,083
  populations; agreements 6,283; bits true 4,668 / 4,668; named
  members 8/8, generated 4,337/4,337, mirror 1,938/1,938).
- **Flowing-stationary census reproduced:** mirror sub-family
  **13 tick instances in 13 populations** (records (1,1) ×2,
  (1,3) ×4, (1,5) ×5, (2,4) ×1, (1,7) ×1); generated family 489
  instances in 462 populations; named members 0 — all as shipped.

## G7 — Self-containment under adversarial extraction — REPRODUCED

Commands (in scratch `g7/`): `python3 build_tampers.py` (exit 0),
then `python3 run_g7.py --workdir <scratch>/g7_work` (exit 0;
all 12 cells). The tampered copies were **rebuilt** from the
genuine target via the shipped construction program (the shipped
copies were not reused as inputs to the protocol).

- All five rebuilt tampered copies **byte-identical** to the
  shipped copies: T-a sha256 `ad26c894b228ba88…`, T-b
  `24895e6b310a953f…`, T-b′ `e2f4f4c7179bbf73…`, T-c
  `a0c646a25ce36a92…`, T-d `4d28f7725b3b8e70…`.
- `observation_table.json` and `observation_table.md`
  **byte-identical** to shipped; every cell's `cell.json`
  **byte-identical**; every `run_all_output.txt`
  **byte-identical**. The full 10-cell observation table (plus 2
  CONTROL cells) is confirmed exactly as shipped:

  | Cell | A.9 | Failed check(s) | Suite |
  |---|---|---|---|
  | CONTROL__L-paper | PASS | — | 14/14 PASS |
  | CONTROL__L-package | PASS | — | 14/14 PASS |
  | T-a__L-paper | PASS | — | 14/14 PASS |
  | T-a__L-package | FAIL | (7) | not run |
  | T-b__L-paper | FAIL | (5) | not run |
  | T-b__L-package | FAIL | (5), (7) | not run |
  | T-bprime__L-paper | PASS | — | 14/14 PASS |
  | T-bprime__L-package | FAIL | (7) | not run |
  | T-c__L-paper | PASS | — | 14/14 PASS |
  | T-c__L-package | FAIL | (7) | not run |
  | T-d__L-paper | FAIL | (4) | not run |
  | T-d__L-package | FAIL | (4) | not run |

- Environmental note (not a discrepancy in any verdict): the
  per-cell `a9_output.txt` files are not byte-identical to shipped
  because A.9 prints the cell's absolute paper path — the shipped
  run used workdir `/tmp/g7_work`, mine used the scratch workdir.
  After normalising only those path strings, all 12
  `a9_output.txt` files are **identical** to shipped, line for
  line (same checks, same witnesses, same verdicts).

## G8 — Discharge under C32's antecedent — REPRODUCED

Command: `python3 g8_program.py` (exit 0) in scratch `g8/`
(regenerates `populations.json` from the fixed seed 20261026,
then all outputs).

- All four regenerated artifacts **byte-identical** to shipped:
  `populations.json` sha256 `60b5d5d3267d81aa…`, `results.json`
  `5d8ee83bcca68d0d…`, `witnesses.json` `4c25d28c6d772ba3…`,
  `run.log` `7b6e11969ddfdbda…`.
- Per-question expressibility results reproduced: Q1, Q2, Q3
  (controls), Q5a (inside and shifted), Q6, Q7a expressible with
  expressing functions verified on all 1,402 populations each
  (0 mismatches); Q4 verified on 949 defined populations; Q8 and
  Q8w on 948 (the shipped report's "verified 948/948" for Q8);
  Q5b presented ungraded, as shipped. Leg-1 grouping: 1,393
  distinct (C, F) groups, 9 multi-population groups, no answer
  disagreement on any question.
- **Q7b witness pair reproduced:** Appendix D vs
  `AppendixD_swap_names_0_1` — identical finest census sequences
  (C_t, t = 0..4) and identical finest flow tables (F_t, t = 0..3),
  answers **1/4 vs 0**; the program's independent cross-check line
  reproduces: "census sequences identical: True | flow tables
  identical: True | cross-check PASSED".
- **Swap statistics reproduced:** permutation leg — Q7b answers
  changed in **467 / 1,385** nontrivial swaps; every other
  question 0 / 1,385.

---

## Method notes

- Byte-identity was tested with `cmp` / sha256 against a baseline
  hash list of all 128 shipped files taken before any run.
- Where an output embeds environment data (G1 `results.json`
  absolute input paths + wall time; G7 `a9_output.txt` workdir
  paths), the difference is reported above with the exact fields
  involved; in both cases every count, witness and verdict is
  identical.
- Scratch hand-verification scripts (my own T implementation, the
  G1 triple check, the G3 witness re-simulation, the G4 hand
  summations) live in `~/workspace/gs1_repro1_scratch/` alongside
  the mirrored run trees.
- Discrepancies: **none found.** Nothing was repaired; no shipped
  file was modified.

**No badge is assigned, suggested, or pre-graded by this report.**
