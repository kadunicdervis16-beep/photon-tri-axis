# GOLD STANDARD BATTERY GS-1 — SPECIFICATION

**Version:** GS-1.0 (2026-10-26)
**Status:** Specification. No attack in this document has been run. This
document designs the battery; execution is a separate, later act, and
nothing in it is a verdict on the target paper.
**Target paper (GS-1.0):** Paper 12 v3 — "The Aggregated Ledger —
Many-Body Statistical Mechanics and the Emergence of Bulk
Thermodynamics", `Paper_12_v3.md`,
sha256 `168ff55a61c2f30a59de1861ac0d4de8e4e6126189d07e37c8670893ce299e0b`.
Claim labels (L-labels) below are Paper 12 v3's Appendix B labels;
falsification-condition numbers (C23–C32) are its §12 conditions.
**Custodian:** the house (Valkyrie, for Dervis Kadunic).

---

## 0. Provenance and standing process

GS-1 exists because of a standing ruling by the author (2026-10-26),
recorded here because the battery's authority is exactly that ruling
and nothing else:

1. The auditor always designs and runs **their own battery first**.
2. The house **rates** that battery against this standard and
   incorporates its unique elements, with credit.
3. The **house gold-standard battery** then runs.
4. **Both batteries are disclosed**, side by side. Neither verdict set
   is merged into, averaged with, or silently replaced by the other.

The auditor battery for the target paper is DeepSeek's **DS-12**
(specification adjudicated in `DS12_ADJUDICATION.md`, same folder;
its run follows its own adjudication). GS-1 is the house battery. It
is versioned the way the series' ESP protocol is versioned: revisions
increment, are never silent, and are logged in §6 of this document.

GS-1.0 is written against Paper 12 v3. Later papers adopt the
then-current GS version by name.

---

## 1. Design principles — the standard's own rules

These six rules are GS-1's discipline. An attack, a run, or a report
that breaks one is defective *as GS-1 work*, whatever it finds about
the paper.

**Rule 1 — No self-graded witnesses.** An attack states: the target
claim, the property asserted, the test space, and the witness format.
An attack may **not** pre-write its survival witness and may **not**
pre-grade its expected badge. (DS-12 did both; §5 rates that.) Badges
are assigned by an adjudicator who ran nothing (§2). Where DS-12's
format has a "survival witness" field, GS-1 replaces it with **held
evidence**: the exact checks that ran and their outputs, recorded
after execution, in the run report — never prose acquittal written in
advance.

**Rule 2 — Coverage map per attack.** Every attack carries a coverage
map in the series' verification-rigor form: (1) the native domain,
(2) the verified domain, (3) the map between them, (4) what the map
preserves, (5) what stays outside the check. An attack without a
coverage map is malformed (see GS-F1).

**Rule 3 — Exhaustive-where-finite, paired with the analytic
argument.** Where a property is universal over a finite-but-large
space, the attack pairs exhaustive enumeration on a stated subdomain
with the paper's own general argument, re-checked as a machine
property where a machine property exists (e.g. invariance under
structure the argument abstracts away), and says exactly which part
is enumeration and which part is argument. A sweep is never badged
as exhaustiveness.

**Rule 4 — Witnesses are artifacts.** Every computable attack ships:
input file, program, output, log. Inputs are hashed (sha256) in the
run report. Reproduction of every witness by **two independent
auditors**, from the shipped artifacts alone, is a **precondition**
of any badge — not a postscript.

**Rule 5 — The taxonomy is DS-12's, kept with credit.** Outcome
badges: **GS-HELD** (the attacked property held over the verified
domain), **GS-BROKE** (a witness against the target claim was
produced and reproduced), **GS-LIMIT** (the attack reached the edge
of what the paper claims — the paper's own stated scope boundary,
not a defect), **GS-OUTSIDE** (the attack's construction is not one
the paper's framework admits). The taxonomy's source is DeepSeek's
DS-12 battery, which named the four outcomes first. The differences
from DS-12 are Rules 1–4 and the process rules of §2; the taxonomy
itself is unchanged.

**Rule 6 — GS-1 is itself falsifiable.** In the spirit of DS-12's
C1–C3, tightened:

- **GS-F1.** A malformed attack specification — an undefined test
  space, a missing witness format, no coverage map, a construction
  that violates the target paper's own floors — is a defect of
  **GS-1**, counted against the battery, not the paper. The run
  report names it. (DS-12's adjudication treated its T1 and T4
  exactly so; GS-1 adopts the practice as a rule about itself.)
- **GS-F2.** A badge resting on a witness that either reproducer
  cannot reproduce from the shipped artifacts is **void**. The badge
  line is reissued without it.
- **GS-F3.** The published badge line must arithmetic-match the
  per-attack badges: same attacks, same badges, same count. A
  mismatch voids the line, not the attacks.

---

## 2. Process — coordinator, attack agents, reproducers, adjudicator

**Stage 0 — Freeze.** This specification is frozen before any attack
runs. Its sha256 is recorded in the run report. Any change after the
freeze is a GS revision (§6), never an edit.

**Stage 1 — Attack agents.** One agent per attack (or per pair, at
the coordinator's discretion) implements and runs the attack exactly
as specified. An agent that finds its attack unimplementable as
written stops and reports the spec defect (GS-F1) rather than
improvising a different attack. Each attack ships the Rule-4 artifact
set: input file(s) with sha256, program, output, log.

**Stage 2 — Reproducers.** Two auditors, independent of the attack
agent and of each other, re-run each attack **from the shipped
artifacts alone**. Reproduction means: same inputs, same program,
outputs byte-identical (for seeded random generation: same seed,
same output). A reproduction disagreement blocks badging for that
attack until resolved; an unresolvable disagreement voids the
witness (GS-F2).

**Stage 3 — Adjudicator.** One adjudicator, who has run nothing,
reads the specification, the target paper, and the reproduced
artifacts, and assigns one badge per attack, each with a short
grounds paragraph quoting the outputs it rests on. The adjudicator
may return an attack as **MALFORMED** (a GS-F1 spec defect) instead
of badging it. The adjudicator does not repair attacks, does not
re-run anything, and does not grade characterisations in exploratory
attacks beyond what the attack's own section states (see G3).

**Disclosure.** The run report publishes: the badge line (§2.1), the
per-attack badges with grounds, the coverage maps as executed, and
the artifact hashes. DS-12's report for the same paper is disclosed
beside it, under DS-12's own verdicts (§0, rule 4).

### 2.1 The badge line

```
[GS-1-COMPLETE: G1 <badge>, G2 <badge>, G3 <badge>, G4 <badge>, G5 <badge>, G6 <badge>, G7 <badge>, G8 <badge> | battery GS-1.0 | paper Paper_12_v3.md sha256 168ff55a61c2f30a59de1861ac0d4de8e4e6126189d07e37c8670893ce299e0b | witnesses reproduced 2/2 per badged attack | adjudicator ran nothing]
```

The slot is empty until a run completes. It is **not** pre-filled in
this specification, in whole or in part (Rule 1).

### 2.2 The attack format

Each attack in §3 is stated in eight fields, DS-12's format with
field 7 replaced, plus a coverage map and a falsification link:

1. **Target** — the exact claim (L-label) and construction attacked.
2. **Steelman** — the strongest honest version of the target.
3. **Hypothesis** — the property asserted, stated as a killable
   universal over the test space. Not a verdict.
4. **Test case** — the concrete test space.
5. **Computation** — what is computed, and how.
6. **Failure witness** — the format of a witness against the target.
7. **Held evidence** — the exact checks and outputs that will be
   recorded if the property holds. (Specified here as *what will be
   recorded*; the outputs themselves exist only after the run.)
8. **Deliverables** — the artifact set.

---

## 3. The attacks

### G1 — Factorization, generalized (extends DS-12 T2)

**1. Target.** **L6.2-P12** (Theorem 6.2, §6.2): bodies presenting
equal count profiles carry equal capability. The theorem is
conditional, and the attack is aimed at its load-bearing premise:
Paper 11 §8.6's factorization — encounter outcomes factor through the
presented-count profile M = (n+, n−) — as consumed by §6.2, together
with the M-shadow of Paper 11's operator T (§7.5, via Paper 12 §4)
on which that factorization rests. Script A.4 checks the mechanism
on worked aggregates under two representative outcome rules, over a
declared test taxonomy of profiles with e+ + e− ≤ 4; G1 attacks the
premise at the level of T itself, exhaustively where finite.

**2. Steelman.** The premise is inherited Level A, machine-checked
at its source over 710,090 encounters in Paper 11; Theorem 6.2's own
proof adds only definitions and Paper 11 §8's role-occupancy premise.
The strongest honest version: factorization is a proved fact about
how T consumes profiles, and no enumeration can do more than
re-confirm it. G1 accepts that burden: it is a premise audit, not a
search for a likely failure.

**3. Hypothesis.** Two faces of one premise, reported separately:
(A-face) for all junction states σ = (A, B), σ′ = (A′, B) with
M(A) = M(A′): M(T(σ)) = M(T(σ′)). (B-face) for all σ = (A, B),
σ″ = (A, B′) with M(B) = M(B′): M(T(σ)) = M(T(σ″)). And the
invariance property: T is permutation-equivariant — T(πσ) = πT(σ)
for every index permutation π — so the M-shadow of T's action
carries no port-identity information.

**4. Test case.** Exhaustive: every (A, B) pair at port counts
p = 2, 3, 4 — 81, 729, and 6,561 pairs respectively (A, B ∈
{−1, 0, +1}^p; M-classes per p: 6, 10, 15). Sweep: at p = 5 and
p = 6, the generating sets G₅ (96 vectors) and G₆ (198 vectors),
defined as: all vectors with ≤ 2 nonzero entries (51 at p = 5; 73
at p = 6) **plus** all distinct permutations of the dense seed
multisets — at p = 5: {+1,+1,−1,−1,0} (30), {+1,+1,+1,−1,−1} (10),
{+1,+1,+1,+1,−1} (5); at p = 6: {+1,+1,+1,−1,−1,−1} (20),
{+1,+1,+1,+1,−1,−1} (15), {+1,+1,−1,−1,0,0} (90). The sweep pairs
equal-M members of the generating set against every B in the set
(worst case 96³ ≈ 0.88M triples at p = 5; 198³ ≈ 7.76M at p = 6).
Equivariance: exhaustive over all states and all π ∈ S_p at p ≤ 4;
at p = 5, 6, over the generating sets under all π (images computed
in the full state space; equivariance is a property of T, not of
the set).

**5. Computation.** T is implemented from §4's text verbatim
(admissible index: A[k] = −B[k] ≠ 0; zero the canonically first;
τ drops by exactly 2 per action) by **two independent
implementations**, which must agree on the whole exhaustive domain
before the sweep runs — the agreement is part of the held evidence,
not a courtesy. For each face: group the A-vectors (resp. B-vectors)
by M; for every equal-M pair and every partner in the domain,
compare M(T(·)). Every counterexample is logged with the full
states. Argument leg (Rule 3): the attack lists every premise
Theorem 6.2's proof consumes and marks each as *machine-covered
here*, *covered by A.4*, *inherited-cited* (with the citation), or
*uncovered*. An uncovered premise is reported as a finding about the
proof's support, not converted into a badge by hand.

**6. Failure witness.** A triple (σ, σ′, face) with M equal on the
varied side and M(T(σ)) ≠ M(T(σ′)), shipped as an artifact (input
file, program, output, log; input hashed).

**7. Held evidence.** Per port count: pair counts checked per face,
counterexample count (the outputs, not a summary); the two
implementations' agreement log over the exhaustive domain;
equivariance check counts; the premise-consumption list.

**8. Deliverables.** Both T implementations, the generating-set
input files (hashed), outputs, logs, the premise list.

**Coverage map.** (1) *Native domain:* all junction states of all
arities, and through Theorem 6.2 all aggregates and encounters.
(2) *Verified domain:* exhaustive at p ≤ 4; the stated generating
sets at p = 5, 6; equivariance as stated. (3) *Map:* restriction of
the universal claim to the enumerated and swept subsets; at p ≤ 4
the map is the identity on its subdomain. (4) *Preserves:* exactly
the quantity the premise asserts factors — the M-shadow of T's
action, on both faces, plus port-identity invariance. (5) *Outside
the check:* p ≥ 7 entirely; at p = 5, 6, every vector with ≥ 3
nonzero entries whose multiset is not a seed multiset (the sweep is
a sweep, and the report must call it one); Paper 11 §8's
role-occupancy premise (inherited prose, not a property of T);
encounter outcomes beyond their M-shadow (A.4's domain).

**Falsification link.** **C26** (Paper 12 §12): the condition's
killer is a capability-level pair, and a G1 failure is the
premise-level witness feeding it. The badge's grounds must state
which level the witness sits at: a T-level failure lands on the
inherited premise (Paper 11 §8.6's machine claim) and enters Paper
12 through L6.2-P12's stated condition — the conditional badge then
does exactly what it says, and the report must not blur that.

---

### G2 — Molecule grouping independence

**1. Target.** **L11.1-P12**, its MACHINE split: the census key
v(mol, τ) of §11.2 is grouping-independent — over enumerated
groupings of declared flattenings, script A.8. And the prose claim
the split rests on: "the flattening is a function of the inventory
graph and its junction set alone", so no grouping of one molecule
can carry a different key. A.8 verifies grouping-independence along
declared **merge chains**; G2 enumerates **all** groupings.

**2. Steelman.** (R1)–(R3) are sums over the flattening's atoms and
junctions; regrouping re-partitions the same sums, and finite
addition is associative. A.8 checks the §11.2 worked example by both
routes (B(mol) = 29) and merge chains to depth 4 over 12 bases. The
strongest honest version: grouping-independence can fail only if a
two-level **re-reading** of one grouping changes the inventory
itself — what counts as internal versus inter, or which junctions an
atom owns — and that is exactly what an all-groupings enumeration
probes and a chain sample might miss.

**3. Hypothesis.** For every molecule in the test family, every
connected grouping (below), and every tick τ ∈ {0, …, 9} of the
flattening's T_agg trajectory: the key computed from that grouping's
two-level reading at τ equals the key computed from the flattening
at τ, component by component.

**4. Test case.** Molecules of **3, 4, and 5 atoms**. Atoms respect
the paper's floor (≥ 2 nodes, ≥ 1 internal junction, internally
connected — validated by A.8's R1 checks, reused). Inter-atom
junction graphs: path, star, cycle (4 and 5 atoms), complete (3 and
4 atoms); inter-atom junction arities ≤ 3; every junction carries a
declared σ state (drawn from a stated set including acting and
resting states; the declarations are input files). A *grouping* is
a partition of the atom set into blocks each inducing a connected
sub-molecule — the set of all two-level readings coarser than the
finest. It is enumerated by generation, and the count is printed
per molecule and cross-checked by an independent enumerator (for a
path graph the counts are 4, 8, 16 at 3, 4, 5 atoms). Trajectories:
10 ticks of T_agg on the flattening.

**5. Computation.** Per tick, per grouping: re-read the molecule at
two levels — each block as an atom, its internal junctions being
the atoms' own junctions plus the inter-atom junctions inside the
block, the inter-atom junctions being those crossing blocks —
recompute each block's record from the flattening's state at τ
(record components per §3.1; where a component's tick-evolution is
bookkeeping the paper carries rather than derives — the (Σs², Σu)
components — the implementer states the bookkeeping rule in the
program header and it is classed control), apply the flattening Φ,
compute v, and compare against the flattening route at the same τ.
A mismatch prints the molecule, grouping, tick, both keys, and the
first differing component.

**6. Failure witness.** (Molecule declaration, grouping, tick, the
two keys) as an artifact. This is verbatim **C31**'s third killer
clause: "two groupings of one flattening carrying different census
keys".

**7. Held evidence.** Per molecule: grouping count (both
enumerators), ticks × groupings comparisons run, all-equal output
lines; the worked example of §11.2 re-derived inside the family as
a base case.

**8. Deliverables.** Program, molecule declaration files (hashed),
outputs, logs.

**Coverage map.** (1) *Native domain:* all molecules — any atom
count, any inter-atom graph, any tick. (2) *Verified domain:*
3–5 atoms, the four graph shapes, arities ≤ 3, 10 ticks, σ from the
declared set. (3) *Map:* restriction. (4) *Preserves:* the exact
operation under dispute — two-level re-reading, Φ, the key — at
every tick, not only at rest. (5) *Outside the check:* molecules of
≥ 6 atoms; inter-atom junctions of arity ≥ 4; the (Σs², Σu)
tick-bookkeeping (control-class, flagged here rather than hidden);
populations of molecules (the census key is per molecule; the
population-level ordering key is OR-2, open, and not G2's business).

**Falsification link.** **C31** directly — its third clause is the
witness format above.

---

### G3 — Rest-record census (the relational conjecture's evidence base)

**1. Target.** No claim of the paper is badged by G3. G3 is an
exploratory sweep — DS-12's T5 pattern, kept — aimed at **L8.10-P12**
(the §8.6 conjecture, in the author's restated relational form: a
characterisation, *for a given population*, of the records its own
junction structure permits it to rest at; maximality of a rest
record is a property of that population; no universal balance is
claimed) and its §9.6 link (**L9.6-P12**). Its product is the
evidence base for the announced first-principles derivation phase
(open joint, §§8.6/9.6). **Badges attach to the candidate
characterisations CH-1–CH-3, not to the paper**; §3's closing note
fixes the two verdict levels.

**2. Steelman.** Of the conjecture's research programme, in its
strongest form: the paper's two rest exhibits (§8.7 and Appendix D)
both rest at Ω = 1, and Appendix D rests at τ_agg = 4 ≠ 0 — so rest
is neither τ-exhaustion nor, by the paper's own counter-exhibits, a
universal peak (both exhibits also refute the conjecture's strong
form, which rested only at (E2)-maximal records). What the
derivation phase lacks is not a guess but a census: over a declared
family, which records are rested at, at what Ω-rank, and which
census-visible characterisations survive. A characterisation that
survives a broad family is a candidate premise; one that dies,
dies by a printed witness.

**3. Hypotheses — the characterisations, each a killable universal
over the family.**
- **CH-1 (feature-decidability of rest).** There is a feature ψ in
  the stated feature family Ψ = {φ (§8.7's opposed-pair feature);
  the admissible-index-count feature; the all-zero feature} such
  that, for every population in the family, populations with equal
  initial ψ-census reach equal rest records.
- **CH-2 (rest-Ω minimality).** For every population in the family,
  Ω(rest record) = min{Ω(r) : r visited on its trajectory}.
- **CH-3 (initial-record determinacy).** For every pair of
  populations in the family with equal initial census record and
  equal initial τ_agg, the rest records are equal.

**4. Test case.** The declared family. Junctions: arity 2, total
count J ∈ {4, 6, 8}. Initial σ per junction from the palette Π of
eight stated states — §8.7's two acting types ((+1,+1),(−1,−1))
and ((+1,−1),(−1,+1)), Appendix D's resting types ((+1,0),(−1,+1))
and ((−1,0),(1,0)), A.11's σ_L ((+1,0),(0,0)) and σ_R
((0,0),(0,−1)), the all-zero state, and ((+1,+1),(−1,0)) — written
out in full in the input file. Assemblies (partitions of the
junction set into bodies): all-in-one, one-per-body, path-pairs,
star. The census feature is φ at body level: a body stands in class
A iff at least one of its junctions presents an opposed pair, else
class B (for one-junction bodies this is §8.7 verbatim). Enumeration:
J = 4 — all 8⁴ = 4,096 palette assignments × 4 assemblies; J = 6 —
all 8⁶ = 262,144 × 4 assemblies (trajectories are short: τ ≤ 4 per
junction, so ≤ 2 acting ticks plus the confirming tick); J = 8 — a
structured subfamily only: all junctions equal; two-palette-type
mixtures in all ratios and both spatial arrangements; palette
cycling — the subfamily's exact membership and size printed in the
input file. Initial census classes vary by construction across the
family; the family's realised initial-class list is printed.

**5. Computation.** Per population: run T_agg to the fixed point
plus one confirming tick. Record: assembly, initial record, the
full record path, the rest record, Ω at each visited record
((8.1)/(8.2), deterministic-record convention), the Ω-rank of the
rest record among visited records and among all records of that
population size, the τ_agg path. Then test CH-1–CH-3 over the whole
table; every violation is printed with the witnessing population(s)
and their full trajectories.

**6. Failure witness (per characterisation).** For CH-1/CH-3: a
pair of populations agreeing on the characterisation's input and
disagreeing on the rest record, with trajectories. For CH-2: one
population resting above its visited minimum, with its trajectory.
Artifacts, per Rule 4.

**7. Held evidence.** The full tabulation as a machine-readable
file; per characterisation, the violation count over the family
(the output, zero or otherwise); the family size printout and the
enumeration/structured split.

**8. Deliverables.** The tabulation (the derivation phase's data),
program, input files (palette, assemblies, structured subfamily;
hashed), outputs, logs.

**Coverage map.** (1) *Native domain:* all closed populations.
(2) *Verified domain:* the declared family — J ≤ 8, arity 2,
palette Π, four assemblies. (3) *Map:* restriction, and **no further
map is claimed**: a surviving characterisation is a survivor *of
this family*, and its report line carries the family as its scope.
(4) *Preserves:* T_agg dynamics exactly (T verbatim from §4); Ω by
(8.1)/(8.2). (5) *Outside the check:* arity ≥ 3 junctions; J > 8;
features outside Ψ (for CH-1); bodies assembled by rules outside
the four; the open joint itself — G3 gathers its evidence, it does
not close it.

**Falsification link.** None, by design. The paper asserts none of
CH-1–CH-3; a characterisation's death is data, not a defect. The
run report must say this in G3's grounds paragraph, so no reader
upgrades the sweep into a verdict on L8.10-P12 in either direction.

**Verdict levels.** G3 carries two: the sweep itself is badged like
any attack (on execution to spec and reproducibility — its claim is
the tabulation's correctness), and inside its report each
characterisation receives GS-HELD (survived the family) or GS-BROKE
(killed by a reproduced witness), printed with the family as scope.
The battery badge line carries the sweep's badge.

---

### G4 — Window additivity of reconcile accounting

**1. Target.** **L7.1-P12** (the reconcile count R(P, W) and the
population temperature D(P, W) of (7.1)–(7.3) are well-defined) and
**L7.3-P12** (the §7.5 exhibit's identities), attacked through a
property §7 *implies* but nowhere separately claims: for adjacent
windows W₁, W₂ with W = W₁ ∪ W₂,

  R(P, W) = R(P, W₁) + R(P, W₂), and
  D(P, W) = (|W₁|·D(P, W₁) + |W₂|·D(P, W₂)) / (|W₁| + |W₂|).

**2. Steelman.** (7.1) defines R as a double sum over a fixed
population and a window; additivity over a partition of the window
is finite-sum associativity, and (7.4) already exhibits the
mean-of-locals form of D. The strongest honest version: the algebra
cannot fail. What *can* fail is the **booking** — the paper's
printed exhibits might disobey the definition they illustrate — and
that, not the algebra, is what G4 audits, on every split the
exhibits support.

**3. Hypothesis.** On every test population, for every split of its
booked window into two adjacent non-empty windows (and every tiling
by three, where stated), both identities hold on the booked
per-body per-tick reconcile data r_b(τ), with R recomputed
independently of the paper's printed sums.

**4. Test case.** (i) **§7.5's population:** the declared table,
4 bodies × ticks 1–10, full window W = {1, …, 10} (printed R = 41,
D = 41/40): all 9 two-window splits and all C(9, 2) = 36
three-window tilings. (ii) **Appendix D's population:** the declared
reconcile table over W = ticks 1–3 (A.7's check (e)): splits
1 | 2–3 and 1–2 | 3, and the full-window identities re-derived
(R = 55, D = 55/36). (iii) **§8.7's population — reduced leg, with
the reason stated.** §8.7 declares no reconcile inputs (no
v²_contact, no s² per body-tick), so no r_b(τ) table exists there
and GS-1 does not invent one. The §8.7 leg runs the additivity
§8.7 *does* declare: per-tick acting counts (12, 6, 0) and Δτ_agg
(−24, −12, 0) sum over window splits by Proposition 4.3's per-tick
form. The coverage map carries this reduction openly.

**5. Computation.** The declared tables are parsed from the paper's
text as inputs (oracle-under-test discipline: the tables are data,
additivity is the check, and additivity is nowhere in the input —
this is not an input-equals-output check). R is recomputed per
sub-window by direct summation over the parsed r_b(τ). For
Appendix D, r_b(τ) is additionally recomputed upstream by A.7's
route — contact-tick N_reconcile rewrites counted from the declared
ledger — and the per-tick cap (7.2), r_b(τ) ≤ 97, is checked as a
side condition on every booked entry. D's identity is checked in
exact rationals throughout.

**6. Failure witness.** (Population, split, left side, right side,
the r_b table) as an artifact: a booked split that does not add.

**7. Held evidence.** Per population: the split count, the
all-equal outputs, the recomputed R and D lines for every
sub-window, the cap-check output.

**8. Deliverables.** Program, the parsed tables as input files
(hashed), outputs, logs.

**Coverage map.** (1) *Native domain:* all populations, windows,
and splits. (2) *Verified domain:* the named exhibits and every
split of their booked windows — exhaustive over splits, restricted
over populations. (3) *Map:* restriction to the exhibits; the
algebra is general, the booking is exhibit-level, and the attack
verifies that everywhere the paper books numbers, the booking obeys
the algebra. (4) *Preserves:* the exact quantities (7.1)–(7.3)
define, recomputed from booked data. (5) *Outside the check:*
windows and populations the paper never books; the §8.7 R-leg
(named, with its reason); |W| = 0 (excluded by §2.2, not tested).

**Falsification link.** No §12 condition names window additivity;
the nearest is **C28** (an enlarged transition whose construction
disagrees with its own dynamics). A G4 failure would therefore also
be a datum against **L12.1-P12**'s completeness — a defect with no
condition of its own. GS-1 states this in advance, here, so that
the grading of such a failure cannot be improvised after the fact.

---

### G5 — Capability at the taxonomy's edge

**1. Target.** **L6.1-P12** (Definition 6.1): Cap(G, R) is the set
of pairs (E, t) where E is an encounter **kind of Paper 11's
taxonomy** whose presented-count profile M(E) the body presents,
with the performing tick t in role R. The attacked property is the
definition's quantifier domain: Cap ranges over *kinds*, and §6's
text supplies no rule by which a profile realised by **no** kind
could acquire pairs, nor by which two kinds sharing one profile
could collapse into one pair-source. Behaviour text: §6.2 (L6.2),
§6.3's emptiness discipline (L6.3: remove the encounters and Cap is
empty).

**2. Steelman.** The paper already discloses the pressure point:
A.4's coverage states its test taxonomy (profiles with e+ + e− ≤ 4)
is a declared control *standing in for* §8's taxonomy, not the
taxonomy itself. The strongest honest version: the text never
confuses the proxy with the taxonomy, Def 6.1 quantifies over kinds
throughout, and §6.3 exhibits the emptiness discipline in the
paper's own worked case. G5 tests whether that discipline survives
at the taxonomy's edge — profiles outside it, and profiles (if any)
inside it twice.

**3. Hypothesis.** (a) No text or script of the paper assigns a Cap
pair to a profile realised by no kind of Paper 11's taxonomy.
(b) If the extraction (below) finds two kinds sharing one profile,
§6's machinery treats them as distinct pair-sources: membership of
(E, t) is decided per kind — by its M and Paper 11 §8's
role-occupancy premise — and the shared profile's pairs are the
union over the kinds, with no silent identification. (c) A.4's
implementation, re-run with its test taxonomy extended by an
unrealised profile, mints no pair for that profile beyond what the
kinds present in the run supply: the proxy's extra profile is inert.

**4. Test case.** *Step 1 — extraction.* From the paper's own
embedded canonical copy of Paper 11 v69 (Appendix C, §C.4), extract
§8's encounter taxonomy: the kind list, with each kind's specifying
data exactly as printed. The extraction is printed in full and is
itself a deliverable; the two reproducers repeat it independently,
because the attack stands or falls on reading §8 correctly.
*Branch A:* kinds are specified by profile alone — then leg (b) is
vacuous **by extraction**, and the report says so; no badge may rest
on it. *Branch B:* kinds carry individuating data beyond M — the
shared-profile kinds found are leg (b)'s test cases. *Unrealised
profiles:* (i) every (n+, n−) with n+ + n− ≤ 4 absent from the
extracted kind profiles; (ii) profiles with totals above the
taxonomy's maximum; (iii) the null profile (0, 0), if no kind
presents nothing.

**5. Computation.** *Textual leg:* a premise audit of Def 6.1, §6.2,
§6.3, and A.4's source for any rule assigning pairs by profile
rather than by kind; the evidence (passages, with locations) is
printed for the adjudicator to read — it is not pattern-matched
into a verdict by script. *Machine leg:* A.4 re-run with the
extended taxonomy of the test case (branch-dependent), its outputs
diffed against the unextended run, pair by pair.

**6. Failure witness.** The passage or output line assigning a pair
to a non-kind profile, quoted with its location; or, for leg (b),
an output in which two same-profile kinds' pairs are identified.
Shipped as an artifact quoting the untampered sources.

**7. Held evidence.** The extraction table (kind list as extracted,
both reproducers' copies agreeing); the premise-audit evidence;
both A.4 runs' outputs and their diff.

**8. Deliverables.** Extraction table, audit note, the extended-run
program and outputs, logs.

**Coverage map.** (1) *Native domain:* Paper 11's full taxonomy and
every presentable profile. (2) *Verified domain:* the taxonomy as
extracted from the embedded v69 text; the unrealised profiles of
the test case; A.4's machinery. (3) *Map:* the embedded source *is*
the taxonomy's carrier for this paper (Appendix C, §C.4) — the map
is identity, with the extraction step as its one human reading,
doubled by the reproducers. (4) *Preserves:* kind individuation
exactly as §8 states it. (5) *Outside the check:* Paper 11 editions
other than v69; §8's role-occupancy facts (inherited); Cap's
behaviour under outcome rules outside §8.6's class (A.4's disclosed
limit, inherited here).

**Falsification link.** The nearest condition is **C26** (carried
capability), but an extension defect — capability minted for a
non-kind — is not C26's killer as written. GS-1 states the gap in
advance: if G5 is graded GS-BROKE, its grounds must name the defect
against L6.1-P12 directly and record the L12.1-P12 completeness
consequence (a second such datum, with G4's), rather than filing
the witness silently under C26.

---

### G6 — The (E1) two-route agreement, generalized

**1. Target.** **L9.1-P12** (§9.3: a record is stationary at a tick
iff the net class flows Φᵢ of (9.3) vanish for every class i) as
used by **L9.2-P12**'s (E1) equilibrium criterion (§9.2). A.7's
check (g) and A.10 both already compute (E1) by the two routes —
record equality over the confirming tick, and net flows — on their
exhibits, and agree. G6 makes that agreement a property over a
generated family.

**2. Steelman.** (9.3) is integer bookkeeping: the record changes
at a tick iff some class count changes iff some net flow is
nonzero. The two routes must agree **if** both read the same class
partition and the same tick. The strongest honest version concedes
exactly where the risk sits: A.7's route reads the tick *leaving a
record's first occurrence*, with the confirming tick for the final
record — conventions that can drift from §9.2's per-tick statement
without any arithmetic being wrong anywhere. G6 pins the per-tick
reading and tests it everywhere in the family.

**3. Hypothesis.** For every population in the family, every tick τ
of its trajectory including the confirming tick past the fixed
point, and the record r_τ at τ:

  [r_{τ+1} = r_τ] ⟺ [Φᵢ(τ) = 0 for every class i],

both sides computed on the same declared feature and the same tick.

**4. Test case.** (i) *Named members:* Appendix D's population
(live/resting feature, ticks 0–3) and §8.7's population (feature φ,
ticks 0–3) — the exhibits where the two routes are already printed.
(ii) *Generated family:* closed populations of n ∈ {2, …, 8}
bodies, one arity-2 junction each, σ₀ drawn from all 81 arity-2
states by seeded RNG (seed printed in the input file), 200
populations per n, feature φ. (iii) *Flowing-stationary search:* a
targeted sub-family engineered to seek records stationary **with**
acting junctions — bodies paired with mirror states under φ, so
class changes can cancel — because the (E1)-with-action species of
§9.3 is the case where a route disagreement would hide. The count
of flowing-stationary records found is reported whatever it is;
zero is a reportable result, not an attack failure.

**5. Computation.** Per population: trajectory to the fixed point
plus confirming tick. Per tick: the record-equality bit; the flow
table F_τ built from the per-body class transitions on that tick;
Φ per (9.3); the bits compared. Every disagreement is logged with
the population, tick, both records, and the full flow table.

**6. Failure witness.** (Population, tick, records, flow table) as
an artifact: one tick where the routes disagree.

**7. Held evidence.** Population and tick counts; agreement counts
per route-pair; the flowing-stationary census (found or zero);
the named members' per-tick outputs matched against the paper's
printed routes.

**8. Deliverables.** Program, seed/input file (hashed), outputs,
logs.

**Coverage map.** (1) *Native domain:* all closed populations, all
features §5.1 licences. (2) *Verified domain:* the named exhibits
plus the generated family (n ≤ 8, one-junction bodies, features φ
and live/resting). (3) *Map:* restriction. (4) *Preserves:* the
exact two routes §9.2, A.7(g), and A.10 use, read per-tick as §9.2
states them. (5) *Outside the check:* bodies with ≥ 2 junctions
(the named exhibits have one-junction bodies too — the family does
not extend past them, and says so); features defined over
sub-populations; the (E2) half of equilibrium (A.5's, A.7(h)'s,
A.10's domain, not G6's).

**Falsification link.** No §12 condition names the two-route
agreement; the nearest is **C30** (a closed trajectory resting
somewhere else — a different statement). A disagreement would be a
defect in §9.2's criterion as stated and a third L12.1-P12
completeness datum (with G4's and G5's notes). Stated in advance,
as there, so the grading cannot be improvised.

---

### G7 — Self-containment under adversarial extraction

**1. Target.** **LC.1-P12** (Appendix C embedding: the embedded
listings, sources, and ESP v2.3 initiation block are byte-identical
to the files named in the Appendix C manifest; the listings and
sources extract to the runnable layout of §C.1) — attacked not on
the untampered artifact, where A.9 already passes, but through the
**exactness of the paper's disclosures about its own detection
boundary**: §C.1(b) (layout and run protocol), §C.1(c) (what a
no-execution audit may conclude), §C.1(d) (package identity via
MANIFEST.sha256, with its printed caveat that the match "does not
establish that the manifest was honestly computed at build time"),
and A.9's coverage item (5) (canonical identity anchored by sibling
comparison when the tree is present, otherwise by the package and
the published record). The attacked property: **the observed
detection boundary equals the disclosed boundary — no more, no
less.**

**2. Steelman.** The paper discloses its weak points in words, in
advance: §C.1(d) prints the internal-consistency caveat; A.9's
coverage (5) states that no check inside the artifact can establish
honest computation of the manifest. The strongest honest version:
every tamper below is either caught by a mechanism the paper names,
or escapes by exactly a route the paper names as outside. G7's work
is to make "exactly" earn its place — by tampering.

**3. Hypothesis.** For each tamper × layout cell of the test case:
the observed outcome (which numbered A.9 check fires, or PASS; the
suite verdict where run) matches the outcome the disclosures
predict for that cell — in particular, paper-alone, a consistently
re-manifested content change is *not* detected internally
(predicted escape, disclosed as outside), while in the package
layout A.9's check (7), sibling comparison, *does* detect it
(predicted catch, disclosed). No cell is caught by less than
disclosed, and the paper's text nowhere claims more detection than
is observed.

**4. Test case.** Tampers, applied to copies — never to the
delivered artifact:
- **T-a (consistent re-manifest).** Change one character in one
  embedded script listing (scripts/A5_concentration.py) **and**
  recompute that file's manifest row (sha256 and byte count) in the
  paper copy.
- **T-b (listing swap).** Exchange the full contents of two embedded
  listings of similar size (the pair is fixed by byte counts at
  implementation and named in the input file), manifest untouched.
  Variant **T-b′**: the same swap with the two manifest rows swapped
  along with the contents.
- **T-c (ESP downgrade).** Replace the embedded ESP v2.3 initiation
  block with the ESP v2.2 initiation text (taken from the published
  Paper 11.5 verification package; the source is cited by its
  published record in the attack's input file) and recompute its
  manifest row.
- **T-d (manifest deletion — control).** Delete one file's manifest
  row; contents untouched.
Layouts: **L-paper** (the tampered paper alone in a clean
directory) and **L-package** (the tampered paper with the canonical
sibling tree beside it). In each layout the protocol follows the
paper's own §C.1(b): A.9 is extracted from the copy under test (in
L-paper, that bootstrap is itself part of what is being examined,
and the report says so), and where A.9 passes, the full suite is
extracted and run, recording the run_all verdict.

**5. Computation.** The observation table: for every (tamper,
layout) cell — A.9's verdict and the numbered check that fired (or
PASS), the suite verdict where run, and the external anchors
available in that layout (the published sha256 of the genuine paper
file for L-paper; sibling bytes for L-package). Then the disclosure
comparison: each cell set beside the §C.1 / A.9 text it tests,
quoted. The comparison is the adjudicator's reading of printed
evidence (Rule 1), not a script's pattern match.

**6. Failure witness.** A cell where observation ≠ disclosure, in
either direction — an escape the disclosures do not name, or a
disclosed catch that fails to fire — with the tampered artifact
preserved and hashed as the witness.

**7. Held evidence.** The complete observation table (no cell
omitted); A.9 and run_all outputs per cell; the disclosure
comparison table with quotations.

**8. Deliverables.** The tamper-construction program, the tampered
copies (or their hashes plus a reconstruction recipe exact enough
for the reproducers to rebuild them byte-for-byte), outputs, logs.

**Coverage map.** (1) *Native domain:* all tamperings of the
artifact. (2) *Verified domain:* four tampers × two layouts — one
representative per tamper class (content change, permutation,
version substitution, deletion). (3) *Map:* restriction to the
classes the disclosures themselves distinguish — internal
consistency, sibling anchoring, external record. (4) *Preserves:*
the exact mechanisms §C.1 and A.9 name, exercised as a reader would
exercise them. (5) *Outside the check:* consistent tampering with
paper **and** sibling tree together (the package anchor itself —
§C.1(d) assigns that to the build record and the published record,
outside any artifact-internal check; named here, not tested,
because no artifact-internal test could test it); distribution
attacks (the wrong file published), where the published hash is the
anchor and comparing a copy against it is a reader act — represented
in L-paper's external-anchor column, not badged as a mechanism.

**Falsification link.** **LC.1-P12** itself, read precisely: its
MACHINE badge rests on A.9 passing on the untampered artifact, and
G7 does not re-litigate that. What G7 can break is the *disclosure*
— §C.1's and A.9's statements about where detection ends. A failure
witness is therefore graded against those texts, and the grounds
must name the sentence the observation contradicts.

---

### G8 — The discharge under C32's antecedent

**1. Target.** **L5.4-P12** (Theorem 5.4, §5.4: the sampling-measure
postulate is discharged — every frequency question inside the
framework's own scope is answered by a census count or a flow count
of actual events), as scoped by **L5.3-P12** (Proposition 5.3's
instruments) and bounded by **L5.8-P12** (the §5 steelman's
concession: unknown initial states are outside the dissolution).
G8 is a direct attempt to instantiate **C32**: construct one
frequency question inside the antecedent — a declared population, a
declared window, ledger data alone — that no census or flow count
expresses.

**2. Steelman.** The discharge is a scoping theorem with its scope
printed, and its instruments are wide: the census of Def 5.1 ranges
over members of *both* kinds (bodies and junctions), junctions
classed by σ "or any feature of it"; flows count transitions between
any classes; Prop 5.3's ratios run over (member, tick) pairs, over
windows, and over period counts. The strongest honest version: in
this framework a frequency just *is* a ratio of counts of actual
events over a declared window, so the candidate space for a
counterexample is the boundary itself — sub-populations, offsets,
pairs, cohorts — which is where G8 aims every probe.

**3. Hypothesis (the construction target).** There exists a
frequency question Q in the declared family (field 4) such that Q
satisfies C32's antecedent clause by clause, and Q's answer is
**not expressible** by §5's instruments — where expressibility is
tested mechanically, not argued: Q's answer, computed from the full
trajectory records, is not a function of the census sequence (C_t)
and the flow tables (F_t). Two populations (or two windows on one
population) with identical (C, F) data and different Q-answers are
the proof of inexpressibility.

**4. Test-case (the declared family of questions).** Asked over
declared populations drawn from the paper's exhibits (Appendix D,
§8.7) and G6's generated family (the sharing is stated; populations
are re-declared as G8 inputs, hashed):
- **Q1–Q3 (controls).** Occupancy ratios (Prop 5.3(i)); event rates
  (5.3(ii)); long-run frequencies (5.3(iii)). These must come out
  expressible, with the expressing function exhibited. A control
  failing voids G8's own machinery, not the paper — stated in
  advance.
- **Q4 (feature sub-populations).** Frequencies over the
  sub-population of junctions whose σ carries a stated feature
  (e.g. an admissible index at position 0) — membership tick-indexed;
  the answer is a ratio over (member, tick) incidences. Def 5.1
  licences junction classes by any feature of σ; the probe tests
  whether the *frequency over the moving sub-population* is a
  (C, F)-function.
- **Q5 (offset windows).** Frequencies over windows shifted from,
  or strictly inside, the declared window W; and over windows
  extending past the computed trajectory. The last sub-case is
  presented with the scope texts (Prop 5.3's quantification over
  declared windows; L5.8's boundary) for the adjudicator — G8 does
  not pre-grade it (Rule 1).
- **Q6 (conditional frequencies).** The frequency of class X at
  t + 1 among members standing in Y at t. Flow ratios; control-
  adjacent, included so the family's easy members are on record.
- **Q7 (pair frequencies).** Frequencies over body *pairs*: (a)
  class-level pair counts (how many pairs stand in the same class
  at a tick) — the attack computes the census-polynomial expressing
  them if one exists, and reports it; (b) **named-pair joint
  frequencies** (the frequency with which named B_i stands in X
  while named B_j stands in Y) — not obviously (C, F)-functions;
  the inexpressibility test decides. Pairs are not members under
  Def 5.1, and whether a pair-question sits inside C32's antecedent
  is part of what the adjudicator grades — G8 constructs the
  strongest candidate and presents the antecedent checklist; it
  does not decide the scope question by fiat in either direction.
- **Q8 (cross-tick cohorts).** The frequency, over W, of a class at
  t + k among the cohort standing in class X at a *fixed earlier
  tick* t₀ — membership fixed by history, not by current class.
  Flows are one-step and class-level; whether multi-step cohort
  answers are (C, F)-functions is decided by the same test.

**5. Computation.** Per question Q: (1) compute Q's answer directly
from the full records on every population in the test set;
(2) the expressibility test — search the test set for two
populations (or windows) with identical census sequences *and*
identical flow tables but different Q-answers; if found, Q is
inexpressible by (C, F) and the pair is the witness; if none, and
Q is a control or an easy member, exhibit the expressing function
and verify it on the whole set; (3) for an inexpressible Q, the
scope checklist — C32's antecedent clauses (declared population?
declared window? ledger data alone?) checked one by one against
§2.2's and §5's texts, quoted, and presented for adjudication.

**6. Failure witness (against the paper).** An inexpressible Q, its
witness pair, and its antecedent checklist, as artifacts. If the
adjudicator grades the checklist inside-scope, the discharge is
void at that point: GS-BROKE against L5.4-P12's scoping claim. If
the adjudicator grades the candidate outside the antecedent (e.g.
pair-membership outside Def 5.1's member concept), the outcome is
GS-LIMIT — the attack found the scope boundary where the paper
draws it. Both gradings are the adjudicator's; the attack's job is
that the candidate and the checklist be strong enough to force the
decision onto the paper's actual texts.

**7. Held evidence.** Per question: the expressibility result —
witness pair or exhibiting function, with verification outputs; the
antecedent checklists for every inexpressible Q; the controls'
expressing functions. If no Q in the family is inexpressible, the
held evidence *is* the family plus the functions: GS-HELD with the
family as the coverage limit, per field 8's map.

**8. Deliverables.** Program, population set (hashed), per-question
outputs, logs, checklists.

**Coverage map.** (1) *Native domain:* all ledger-statable
frequency questions — an **open** class, over which the paper's
claim is universal. (2) *Verified domain:* the declared family
Q1–Q8 over the stated population set. (3) *Map:* **there is no
completeness map from the family to the class, and the attack says
so.** A GS-HELD here is a held-over-this-family verdict, printed
that way wherever the badge travels. (4) *Preserves:* the
antecedent's exact clauses — the family is built to sit on the
antecedent's boundary (sub-populations, offsets, pairs, cohorts),
which is the only place a universal scoping claim can be broken.
(5) *Outside the check:* questions needing undeclared data (unknown
initial states — L5.8's conceded residue; estimation), populations
or windows never declared, and any frequency over continuous
parameters (the ledger has none).

**Falsification link.** **C32** (primary — G8 is its antecedent,
instantiated), **C25** (the same gap stated at §5's level: a
ledger-stated frequency no census or flow count expresses).

---

## 4. DS-12 rated against GS-1's principles

GS-1's second duty under the standing process (§0) is to rate the
auditor's battery. The rating below is against GS-1's six rules; it
incorporates the per-attack adjudication already recorded in
`DS12_ADJUDICATION.md`, which stands as its own document.

**What GS-1 keeps from DS-12.**
- The four-outcome taxonomy (Rule 5 — credited, unchanged).
- The eight-field attack format (with field 7 replaced, §2.2).
- Pre-registration with a publication commitment: the spec is fixed
  before execution and published whatever comes out. DS-12 held
  this discipline; GS-1 keeps it (Stage 0).
- Falsification conditions on the battery itself (DS-12's C1–C3 →
  GS-F1–GS-F3, tightened).
- Spec-defect honesty: DS-12's adjudication named its own defects
  (T1's encounter idiom and its "no reconcile declared" slip, where
  reconciliation is computed, not declared; T4's sub-floor atom).
  GS-F1 adopts the practice as a rule about GS-1 itself.
- T5's exploratory framing — badges on characterisations, not on
  the paper — inherited by G3 entire.
- Specific attacks: T2 (factorization) is extended by G1; T6's
  direct C32-instantiation attempt is given disciplined form by
  G8; T5's joint-hunt is G3's ancestor.

**What GS-1 tightens.**
1. *Self-grading.* DS-12 pre-wrote survival witnesses and expected
   badges per attack; T3's spec even supplies its own acquittal
   (the mapping it tests "does not exist") as its survival witness.
   Rule 1 forbids both: held evidence replaces the survival
   witness, and the adjudicator runs nothing.
2. *Coverage.* DS-12 stated test spaces but no coverage maps; a
   reader could not always tell a sweep from an exhaustiveness.
   Rule 2 makes the five-part map mandatory, and G1's map shows
   the standard applied to GS-1's own strongest attack.
3. *Witnesses.* DS-12's witnesses are prose descriptions. Rule 4
   makes them hashed artifacts, with two-auditor reproduction as a
   badge precondition.
4. *Roles.* DS-12 was adjudicated by its recipient. §2 separates
   attack agents, reproducers, and a non-running adjudicator.
5. *Artifact integrity.* DS-12's envelope failed its own protocol's
   timestamp gate — a transport defect, judged non-fatal to its
   content, but a defect. GS-1 moves integrity from transport into
   the deliverable: hashes, logs, and reproduction are part of
   every attack's output.

**What DS-12 has that GS-1 lacks — stated honestly.**
1. *Priority of framing.* DS-12's T5 framed the joint-hunt — the
   rest-record sweep feeding the §8.6 conjecture — before GS-1
   existed. G3 is its disciplined descendant; the idea's credit
   stays with DS-12.
2. *Breadth of appetite.* DS-12 ranged beyond the paper's claims —
   T3's statistical-mechanics mapping, T8's contact construction —
   and several of its probes land at LIMIT or OUTSIDE for exactly
   that reason. But the ranging probes the paper's boundary claims
   in a way GS-1's claim-anchored list mostly does not: GS-1's only
   true boundary attacks are G7 (disclosure-exactness) and G8
   (antecedent pressure). A future GS revision should consider
   whether the house battery needs a ranging slot of its own; GS-1.0
   records the gap rather than papering over it.
3. *The trivial-case floor.* DS-12's T1, whatever its idiom defect,
   aimed at the simplest possible population carried end to end — a
   sanity floor. GS-1's list has no counterpart; it relies on
   Appendix D and A.7 for the base case. The reliance is stated
   here, not hidden.
4. *External authorship.* DS-12 was designed outside the house.
   That independence is a property GS-1, as the house battery,
   cannot claim for itself — which is precisely why the standing
   process runs the auditor's battery first and discloses both.

**Bottom line.** DS-12 is a strong auditor battery with two
structural defects GS-1 exists to remove — self-graded witnesses
and unartifacted prose witnesses — and one virtue GS-1 cannot
manufacture: it was not written by the house. It stands as the
first stage of the standing process. Its verdicts, when its run
completes, will be DS-12's own, disclosed beside GS-1's, neither
merged into the other.

---

## 5. Versioning

GS is versioned like the series' ESP protocol. **GS-1.0** is this
document. Minor revisions (GS-1.1, GS-1.2, …) clarify wording, add
attacks — appended under new numbers, never renumbering existing
ones — or extend a test space, and say which they did. A change to
the taxonomy, the six rules, or the process of §2 is a major
revision (GS-2.0). No revision is silent: every revision appends a
changelog entry (§6) and re-records the specification's sha256 in
the next run report. A battery run always names the exact GS
version it executed, in its badge line.

## 6. Changelog

- **GS-1.0 — 2026-10-26.** First issue. Eight attacks (G1–G8)
  against Paper 12 v3 (sha256
  `168ff55a61c2f30a59de1861ac0d4de8e4e6126189d07e37c8670893ce299e0b`).
  Taxonomy and attack format adopted from DeepSeek's DS-12 with
  credit (§1 Rule 5, §4); Rules 1–4 and the §2 process are the
  house's tightening. Status at issue: specification only — no
  attack run, no badge assigned, badge-line slot empty (§2.1).

---

*End of GS-1.0 specification.*
