# Three-ways audit addendum — GS-1/DS-12 computations under the three standings (Paper 12 v4, Appendix E)

## 0. What this addendum is

The GS-1 and DS-12 batteries ran against Paper 12 v3, whose §8.7 feature φ is two-valued. Paper 12 v4 §5 (Definition 5.7) repairs the standing instrument to three standings. This addendum audits three battery computations — GS-1 attacks G8 and G3, and DS-12 attack T5 — against the repaired instrument. Two questions are put to each program: (a) at the exact-σ grain, did its data structures keep all three component values {−1, 0, +1} apart (exact local states σ, full state tuples), or did any computation merge −1 with 0 (or +1 with 0) before the point where its conclusion was drawn; (b) where a two-valued feature was used, was that feature the question's own stated feature — the paper's §8.2/§8.7 construction — rather than a silent merging of the exact data the conclusion needed. The G8 witness is then recomputed in full under the three standings.

## 1. The three standings (v4 §5, Definition 5.7)

Every port component of every local state σ = (A, B) is in {−1, 0, +1}. A member's standing at a tick is:

- **positive** iff its presented data contains an opposed pair in the (+1, −1) orientation: there exists k with A[k] = +1 and B[k] = −1;
- **negative** iff it contains no (+1, −1) pair, but a mirror pair exists: there exists k with A[k] = −1 and B[k] = +1;
- **neutral** iff it contains no opposed pair of either orientation.

The §8.7 feature φ is two-valued: φ(σ) = A iff a (+1, −1) pair exists. In standing terms, φ class A is exactly the positive standing, and φ class B is the negative standing and the neutral standing taken together. Every use of φ below is graded against that identity: a φ count is a three-standing count with its negative and neutral cells summed, and it is exact for any question that is itself stated in φ terms.

## 2. Audit method

Two legs, both executed for this addendum.

*Code read.* Each program was read at the lines cited: `ds12/gs1/g8/g8_program.py`, `ds12/gs1/g3/g3_program.py`, `ds12/t5/t5_program.py`, together with the machinery T5 and G3 import read-only (the feature at `staging_v6/scripts/A10_two_level.py`, lines 233–241, and the operator T in `staging_v6/scripts/A2_parallel_tick.py`). A verdict rests on the cited lines, not on a run report's summary of them.

*Independent recomputation.* The G8 witness was recomputed by a program written for this addendum from Definition 5.7 and §4's statement of T alone, reading only `ds12/gs1/g8/populations.json`. It imports no battery program. Section 4 below is its output, stated as exact counts and exact fractions throughout.

## 3. Per-attack verdicts

### 3.1 G8 — the discharge under C32's antecedent (GS-1; badge GS-BROKE)

**Grain: exact-σ throughout; no merge of −1 with 0 anywhere before a conclusion. The two-valued step is φ, and φ is each question's own stated feature.**

Evidence from `g8_program.py`:

- The state space is exact: lines 100–103 build `ALL_STATES` as `itertools.product((-1, 0, 1), repeat=4)` — all 81 arity-2 states as full tuples — with `IDX` mapping each exact tuple to its class index.
- The dynamics are exact: `T_sigma` (lines 80–87) tests each index by the exact equality `A[k] == -B[k] != 0` on the integer entries and zeroes that pair; −1, 0 and +1 are never identified with one another.
- The (C, F) data on which the inexpressibility test turns are the finest data: `census_flow` (lines 138–148) counts bodies per exact σ class at each tick (`Counter(IDX[s] ...)`) and counts flows per exact ordered pair of σ classes. The grouping key for the witness search is `(n, finest C sequence, finest F tables)` — an exact-σ key.
- φ enters only where a question states it: `phi` (lines 89–91) is the orientation-specific test `A[k] == 1 and B[k] == -1`, exactly §8.7's feature; the question list (header, lines 36–59) states Q1, Q3, Q4, Q6, Q7a, Q7b and Q8 in φ terms, and Q7b by name (lines 53–55; computed at lines 189–190 from the per-body φ classes of the full trajectory records). The expressing functions marginalise the finest (C, F) by φ (`marg_class`, lines 202–203) — a summation performed on the finest data after that data is fixed, which is the test's design: a question not expressible from the finest data is expressible from no census or flow count formed by summing it either.

Verdict: the finest structures distinguish all three component values; no computation in G8 merges −1 with 0, or +1 with 0, before any conclusion. φ's summing of the negative and neutral standings is the stated form of the questions G8 was set, not a silent merging of data a conclusion needed in finer form.

### 3.2 G3 — rest-record census (GS-1; badge GS-HELD)

**Grain: exact-σ orbits and exact assignments throughout; the two-valued and three-valued steps are the characterisations' own stated features. One sign-summing quantity, τ, is the paper's own §4 quantity, used only as itself.**

Evidence from `g3_program.py`:

- The orbit machinery is exact: lines 172–175 build `ALL_STATES` by nested loops over (−1, 0, +1) — all 81 states as full tuples — and the program precomputes the T-orbit of every one of the 81 states before any population runs. `T` (lines 147–159) and `admissible_indices` (lines 137–139) use the exact test `A[k] == -B[k] != 0`; the direct T is cross-checked against A.2's T on all 81 states (lines 248–249 of the run path).
- The shipped tabulation retains the exact assignment: each row (written at lines 365–379) carries field `s`, the assignment as palette-index digits, from which every junction's exact σ at tick 0 is recovered by the palette, and every later tick by the orbit tables; the witness file carries full σ trajectories for its pairs.
- φ is applied as a census output, after exact stepping: `phi_class` (lines 162–169) is the orientation-specific test `A[k] == 1 and B[k] == -1`, §8.7's feature verbatim, and the per-state φ values along the exact orbits are stored as 0/1 marks (lines 272–278) solely to form the φ-census records the characterisations CH-1 to CH-3 are stated over.
- The two auxiliary features are stated features, each tabulated at both of its readings: the admissible-index count uses `adm0` (line 280), the count of indices passing the exact admissibility test — a count of indices, by its stated definition indifferent between the two opposed orientations, both of which §4 counts as admissible; the all-zero feature uses `zero0` (line 281), the exact test `s == ZERO` against the full tuple ((0, 0), (0, 0)) — it separates the all-zero state exactly and groups the remaining states together, which is that feature's stated definition, at both the junction-member and body readings.
- τ (lines 141–143) is the sum of squares of the entries: it takes −1 and +1 to the same contribution. That is §4's definition of τ, and τ enters G3 only as itself — in the τ_agg paths and as one half of CH-3's stated key, alongside the initial φ-record. No standing, record or count in G3 is derived from τ.

Verdict: the finest structures distinguish all three component values; no computation in G3 merges −1 with 0, or +1 with 0, before any conclusion. Every summed key in the program is a characterisation's own stated key.

### 3.3 T5 — dynamics-to-balance joint hunt (DS-12; exploratory classification)

**Grain: exact σ types and full states retained through every trajectory; the mirror types are distinguished in the construction and tracked in the τ and acting series. The two-valued step is φ, the hunt's own stated feature.**

Evidence from `t5_program.py` and its imported machinery:

- The five σ types are exact tuples (lines 170–174), and the mirror pair is kept apart in the construction itself: `ALPHA = ((1, 0), (-1, 0))` against `GAMMA = ((-1, 0), (1, 0))`, and `BETA = ((1, 1), (-1, -1))` against `DELTA = ((-1, -1), (1, 1))`. A body's type name is recorded per trajectory, so the orientation of every initial state survives into the outputs.
- The dynamics are imported exact-tuple machinery: T, `parallel_tick`, `tau_agg` and `acting_count` from A.2, applied to full state tuples; `run_trajectory` (lines 258–281) stores the full state at every tick alongside its record.
- φ enters through the imported feature (A.10 `feature`, lines 233–241 of the imported file: class A iff some k has A[k] = +1 and B[k] = −1), which is what the hunt's specification directs — the program header (lines 15–20) records the instruction to use the §8.7/A.10 idiom, and the census record (k, n − k) is formed from that feature alone (line 266).
- What φ does not separate, the program still counts: the header (lines 46–56) states that the mirror types burn τ without changing the census, and each trajectory's classification carries its full τ_agg series and acting series (computed in `classify` from the exact states), so the mirror states' action is present in the tabulated data as exact counts, not discarded.

Verdict: the finest structures distinguish all three component values; no computation in T5 merges −1 with 0, or +1 with 0, before any conclusion. φ is the feature the hunt was specified to use, and the quantities the classification reports — census records, Ω values, drift classes — are φ quantities by the hunt's own statement.

## 4. The G8 witness recomputed under the three standings

Populations: `AppendixD` and `AppendixD_swap_names_0_1`, as declared in `ds12/gs1/g8/populations.json` (the second is the first with the σ₀ assignments of named bodies #0 (B1) and #1 (B2) exchanged; the remaining ten bodies are unchanged). Window W = [0, 4): ticks t = 0, 1, 2, 3. Each body's trajectory is computed under T as §4 states it: an index k is admissible iff A[k] = −B[k] ≠ 0; T zeroes the canonically first admissible pair; if no index is admissible, the state is unchanged.

Named bodies, tick by tick:

| Population | t | B1 σ | B1 standing | B2 σ | B2 standing |
|---|---|---|---|---|---|
| AppendixD | 0 | ((1, 1), (−1, −1)) | positive | ((1, −1), (−1, 1)) | positive |
| AppendixD | 1 | ((0, 1), (0, −1)) | positive | ((0, −1), (0, 1)) | negative |
| AppendixD | 2 | ((0, 0), (0, 0)) | neutral | ((0, 0), (0, 0)) | neutral |
| AppendixD | 3 | ((0, 0), (0, 0)) | neutral | ((0, 0), (0, 0)) | neutral |
| AppendixD_swap_names_0_1 | 0 | ((1, −1), (−1, 1)) | positive | ((1, 1), (−1, −1)) | positive |
| AppendixD_swap_names_0_1 | 1 | ((0, −1), (0, 1)) | negative | ((0, 1), (0, −1)) | positive |
| AppendixD_swap_names_0_1 | 2 | ((0, 0), (0, 0)) | neutral | ((0, 0), (0, 0)) | neutral |
| AppendixD_swap_names_0_1 | 3 | ((0, 0), (0, 0)) | neutral | ((0, 0), (0, 0)) | neutral |

The joint standing count J_W(B1, B2) over W — entry (r, c) is the count of ticks at which B1's standing is r and B2's standing is c; rows and columns are ordered (+, −, 0); each table sums to 4, the count of ticks in W:

**AppendixD:**

| B1 \ B2 | + | − | 0 |
|---|---|---|---|
| + | 1 | 1 | 0 |
| − | 0 | 0 | 0 |
| 0 | 0 | 0 | 2 |

**AppendixD_swap_names_0_1:**

| B1 \ B2 | + | − | 0 |
|---|---|---|---|
| + | 1 | 0 | 0 |
| − | 1 | 0 | 0 |
| 0 | 0 | 0 | 2 |

Q7b's answer under the repaired instrument is the count of ticks at which B1 is positive and B2 is not positive, over the 4 ticks of W: (J[+][−] + J[+][0]) / 4.

- AppendixD: (1 + 0) / 4 = **1/4**. The single contributing tick is t = 1, in the (+, −) cell: B1 positive, B2 negative.
- AppendixD_swap_names_0_1: (0 + 0) / 4 = **0**. No tick contributes; the t = 1 pair stands in the (−, +) cell, which Q7b does not count.

Cross-check against the direct φ-class joint count (B1 in φ class A and B2 in φ class B, per tick, over W): AppendixD gives 1 tick of 4, hence 1/4; the swapped population gives 0 ticks of 4, hence 0. The two routes agree on both populations, as they must: B2 not positive is B2 negative or B2 neutral, which is φ class B stated in standing terms.

Finest-data identity, re-verified in the same recomputation: the finest census sequences of the two populations — the count of bodies in each of the 81 exact σ classes, at each of t = 0, 1, 2, 3, 4 — are identical at all 5 ticks, and the finest flow tables — the count of bodies passing from each exact σ class to each exact σ class, at each of t = 0, 1, 2, 3 — are identical at all 4 transitions. The recomputation agrees with the battery's recorded witness (answers 1/4 and 0) at every point.

## 5. Whether any battery conclusion changes

**G8 — no conclusion changes.** The break stands exactly as badged. The inexpressibility rests on the finest (C, F) data, which are exact-σ counts; a census or flow count formed from the three standings is a sum of finest census entries (a standing is a feature of σ), so it takes the same value on both witness populations for the same reason the finest data do, while Q7b's answer differs — recomputed here as 1/4 against 0 under the repaired instrument itself. The three standings refine the witness rather than dissolve it: they locate the whole difference in one tick, t = 1, standing in the (+, −) cell in `AppendixD` and in the (−, +) cell in the swapped population.

**G3 — no conclusion changes.** CH-1, CH-2 and CH-3 are statements about the stated features — φ, the admissible-index count, the all-zero test, and τ_agg — and every count G3 reports is a count over exact assignments and exact orbits, so no count is recomputed by this audit and none moves: CH-1 for φ, 0 violating pairs; CH-2, 0 violations; CH-3, 0 violating pairs; the two auxiliary features at the junction-member reading, 28,143,226,010 and 152,170,736,738 violating pairs, and 0 at the body reading, in each case as reported. The standings add one consistency observation, not a correction: a fixed point of T has no admissible index, hence no opposed pair of either orientation, so every junction at rest is neutral — the rest end of every G3 trajectory is all-neutral under the three standings, in agreement with the rest record (0, n) that φ reports for every population in the family.

**T5 — no conclusion changes.** T5 reports a classification, and every classified quantity — the census record at each tick, its Ω, the drift class of a trajectory, whether the maximal record was visited, whether the terminal record is maximal — is a φ quantity by the hunt's own specification, computed from exact states that the program retains in full, with the mirror types distinguished by name in the construction and their action carried in the τ_agg and acting counts. No classified count was produced by merging −1 with 0, so no classified count moves under the three standings; and at rest every junction of every trajectory is neutral (no admissible index, hence no opposed pair of either orientation), which is the standing-level statement of the resting records the classification already reports.

## 6. The G3 tabulation: location and hash

- Location: `ds12/gs1/g3/outputs/tabulation.jsonl` (full path: `~/workspace/your_files/paper_12_draft/ds12/gs1/g3/outputs/tabulation.jsonl`), one JSON object per population, 1,067,744 rows, 207,091,856 bytes.
- sha256: `c418d61e7b86a957cbfe3838d4f9449a4876531acea00e2d9c2a0302ab1d95d1`.

Source of the hash: computed directly in this audit over the file at the location above. The computed value agrees with the hash recorded in G3's `RUN_REPORT.md` §9 and with both Stage-2 reproduction reports, each of which compared the tabulation by full hash.
