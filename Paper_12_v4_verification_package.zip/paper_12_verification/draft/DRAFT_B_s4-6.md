# Paper 12 — Draft B: §§4–6 (staging v1)

<!-- DRAFT — not a build. Written under the corrected relational frame
(CORRECTION section, ARCHITECTURE_AND_OUTLINE.md, Dervis 2026-10-24):
no micro/macro two-level picture, no possibility-space, no probability
postulate. Frequencies are census ratios of actual counts over declared
windows and populations. Claim labels are section-numbered (L§.n-P12)
pending merge with Draft A (§§0–3). -->

---

## §4. The aggregate tick

Paper 11 supplies dynamics at exactly one scale: the single pairwise
junction. Its transition operator T (Paper 11 §7.5) acts on the local
state σ of one junction — the pair of port vectors (A, B) presented to
that junction by its two sides — and does exactly one thing: it finds
the canonically first index k* at which the pair is *admissible*,

    admissible(k)  ⟺  A[k] = −B[k] ≠ 0,

and sets A[k*] := 0, B[k*] := 0. If no index is admissible, T leaves σ
unchanged: σ is a fixed point. Paper 11 proves of T, at Level A, that
it is total (defined on every local state), deterministic (the
canonical-first rule leaves no choice), and that each action lowers
the local sum of squares τ(σ) = Σ_k (A[k]² + B[k]²) by exactly 2: the
admissible pair contributes A[k*]² + B[k*]² = a² + (−a)² = 2a² with
a ≠ 0 a unit port value, so a² = 1 and the contribution removed is
exactly 2. Paper 11 has **no** global evolution law: nothing in it says
what a population of junctions does at one tick. That is the gap this
section fills — by definition first, then by theorem.

**Definition 4.1 (aggregate tick).** Let a population be a finite
family of bodies and established junctions, as constituted in §§2–3:
each junction j carries its local state σ_j, and by Port-Partition
Exactness (Paper 11 §4.3, Level A) the boundary ports of the whole
population are partitioned among the junctions and the open boundary —
every port is consumed by exactly one junction or is open, and the
junctions' port sets are pairwise disjoint, with the global accounting

    |∂G| = 6N − Σ_j k_j,

where N is the node count and k_j the number of ports junction j
consumes. One **aggregate tick** is the operation T_agg: apply T once
at every established junction of the population. A junction with no
admissible index does not act; it is carried through the tick
unchanged. [Definition]

The definition is a sentence, but it is not yet a dynamics: "apply T
at every junction" names many operations, and until we know they do
not interfere, T_agg is a schedule, not a function. The theorem below
removes the schedule.

**Theorem 4.2 (the aggregate tick is well-defined).**
T_agg is a single well-defined function on population states: the end
state of an aggregate tick does not depend on the order in which the
per-junction applications of T are carried out.
[LEVEL A — conditional on Paper 11 §4.3 (Port-Partition Exactness) and
Paper 11 §7.5 (the properties of T), both Level A in Paper 11.]

*Proof, step by step.*

*Step 1 — each junction's action is local to its own port set.* By
Paper 11 §7.5, T at junction j reads only the vectors (A_j, B_j) over
j's consumed ports and writes only those same ports: it changes at
most the two entries A_j[k*], B_j[k*] and reads nothing outside j's
port set. So each per-junction operation touches exactly the port set
P_j of its junction, for both reading and writing.

*Step 2 — the port sets are pairwise disjoint.* By Port-Partition
Exactness (Paper 11 §4.3), the P_j partition the consumed boundary:
P_j ∩ P_j′ = ∅ for j ≠ j′. Hence the write set of junction j's action
is disjoint from the read set and the write set of every other
junction's action.

*Step 3 — actions at distinct junctions commute.* Take j ≠ j′ and any
population state. Apply T at j, then at j′; compare with the reverse
order. By Step 2, j's action does not change any entry that j′'s
action reads, so the admissibility pattern j′ sees — and therefore
its canonically first admissible index, and the pair it zeroes — is
the same in both orders. Symmetrically for j. Neither action writes
an entry the other writes. Therefore the composite end state is the
same in both orders: T_j ∘ T_j′ = T_j′ ∘ T_j on every population
state.

*Step 4 — all schedules agree.* The per-junction actions are finitely
many (the population is finite) pairwise commuting operations (Step
3). Any two orders of applying them are connected by a sequence of
adjacent transpositions, each of which leaves the composite unchanged
by Step 3. Hence every schedule yields one and the same end state.

*Step 5 — totality and determinism are inherited.* T is total and
deterministic at each junction (Paper 11 §7.5), so each schedule is
defined on every population state and yields a unique result; by Step
4 that result is schedule-independent. T_agg is therefore a total,
deterministic function on population states. ∎

This is what licenses the word "simultaneous" in this paper, and the
license is a theorem, not a convention: within one aggregate tick
there is no fact of the matter about which junction "went first,"
because the end state provably does not depend on it.

**Proposition 4.3 (aggregate τ accounting).** Define the aggregate
τ of a population state as the exact finite sum over its junctions,

    τ_agg = Σ_j τ(σ_j).

Under one aggregate tick, τ_agg never increases, and it drops by
exactly twice the number of acting junctions:

    Δτ_agg = −2 · |{ j : junction j acts this tick }|.

[LEVEL A — conditional on Paper 11 §7.5, where the per-action drop of
exactly 2 is proved.]

*Proof (the arithmetic, shown).* Δτ_agg = Σ_j Δτ(σ_j), since τ_agg is
a finite sum and the tick changes each term independently (Theorem
4.2). For each junction j, Paper 11 §7.5 gives exactly two cases: j
acts, and Δτ(σ_j) = −2; or j is at a fixed point, T does not act, and
Δτ(σ_j) = 0. Summing,

    Δτ_agg = (−2)·(number of acting junctions) + 0·(the rest)
           = −2 · |{ j : j acts }|  ≤  0.  ∎

No term can be positive, so τ_agg is monotone non-increasing along
every aggregate trajectory — the many-body shadow of Paper 11's
single-junction fact, obtained by addition only, in accordance with
the single-regime rule: an aggregate quantity here is an exact finite
sum over constituent data, nothing else.

**Corollary 4.4 (the aggregate trajectory is one ledger sequence).**
Starting from any population state S₀, the iterates
S₀, T_agg(S₀), T_agg²(S₀), … form a single deterministic sequence.
Each step is a finite set of junction completions, and it serializes
as ledger entries in tick order: entries within one tick may be listed
in any fixed canonical junction order, because by Theorem 4.2 the
state the tick arrives at does not depend on that listing order.
Precisely: what is unique is the tick-end state sequence. The
within-tick entry listing is a fixed canonical order, conventional as
a listing; what serializes uniquely is the state sequence — the
population-level continuation of Paper 11's a_k-ordered junction
completions. [LEVEL A — conditional as in Theorem 4.2.]

*What is definition and what is derivation in this section.*
Definition 4.1 (the aggregate tick itself, and τ_agg as a sum) is
this paper's stipulation. Everything else — well-definedness,
commutation, the τ arithmetic, serializability — is derived, and the
derivation consumes exactly two imported results, both Level A in
Paper 11: Port-Partition Exactness (§4.3) and the properties of T
(§7.5). No new dynamics has been introduced; §4 is Paper 11's
junction law, applied everywhere at once, with the proof that
"everywhere at once" means something.

### Claim list — §4

- **L4.1-P12** — *Definition:* one aggregate tick is T applied once at
  every established junction of the population; τ_agg = Σ_j τ(σ_j).
  [Definition]
- **L4.2-P12** — The aggregate tick is well-defined: per-junction
  actions pairwise commute on their disjoint port sets, so the end
  state is independent of application order. [LEVEL A — conditional on
  Paper 11 §4.3 and §7.5]
- **L4.3-P12** — Δτ_agg = −2 × (number of acting junctions) per
  aggregate tick; τ_agg never increases. [LEVEL A — conditional on
  Paper 11 §7.5]
- **L4.4-P12** — The aggregate trajectory from any initial population
  state is a single deterministic sequence whose tick-end state
  sequence is unique; the within-tick entry listing is a fixed
  canonical order, conventional as a listing — what serializes
  uniquely is the state sequence. [LEVEL A — conditional as
  L4.2-P12]

---

## §5. Census and flow: the dissolution of the sampling measure

Paper 11.5 §11.6 registered a debt against this paper in these words:
the count→weight step "needs two things this paper does not build:
(1) a microstate-counting rule, and (2) a sampling-measure postulate.
Both are Paper 12's work." Item (1) is discharged in §3, re-founded
under the corrected frame as a counting rule over actual ledger
records. This section discharges item (2) — by showing it does not
exist. The expected postulate was an artifact of a frame this series
has already refused: a two-level picture in which an observer's coarse
description stands over a space of finer states that might have been,
and a measure must then be laid over the might-have-beens. The ledger
has no might-have-beens. It has a population, standing in actual
states, changing by actual ticks. Everything a measure was wanted for
is a ratio of counts of those. We build the two counting instruments —
census and flow — and then prove, by cases over the three places a
measure seemed to be needed, that nothing else is required.

**Definition 5.1 (census).** Let the population be declared (a finite
family of bodies and junctions, §§2–3) and let a **count-class** be
any class of population members defined by ledger data alone — for a
junction, its local state σ or any feature of it; for a body, its
count data as fixed in §3 (boundary B, Σs², Σu, presented-count
profile). The classes of any census partition the actual population:
every member stands in exactly one class of the partition at a given
tick. The **census** at tick t is the exact integer count function

    C_t(X) = |{ members of the population standing in class X at tick t }|.

The census counts what is there. It is not an estimate of an
underlying distribution, and there is no underlying distribution for
it to estimate. One widening from §3.3 is flagged here: §3.3's census
classes bodies by their count vectors, while this census takes
population members of either kind — bodies classed by their §3 count
data, and junctions classed by local state σ. It is the same
construction — an exact count of members standing in a class — over a
wider member set. [Definition; the counts themselves are exact finite
counts over constituent data, per the single-regime rule.]

**Definition 5.2 (flow counts).** Under the aggregate tick of §4,
members move between classes. The **flow count** from class X to
class Y at tick t is the exact integer

    F_t(X→Y) = |{ members in class X at tick t and in class Y at t+1 }|,

where "at t+1" means after one aggregate tick. The flows at a tick
form a finite table, computable from T_agg by applying §4 to the
declared population and counting. Two accounting identities hold by
construction — every member counted in C_t(X) lands in exactly one
class at t+1, and every member counted in C_{t+1}(Y) came from exactly
one class at t:

    Σ_Y F_t(X→Y) = C_t(X),        Σ_X F_t(X→Y) = C_{t+1}(Y).

[Definition; the identities are bookkeeping consequences of the
definitions — every member is counted once on each side.]

A **window** is a declared finite run of consecutive ticks
W = [t₀, t₀ + m). Every frequency this paper uses is formed the way
Paper 9 forms its temperature verbally — a count of actual reconcile
events over a count of actual ticks; the population form of that
ratio is constructed at §7 as D(P, W). No formula of the shape
T_ledger = N_reconcile/N_ticks is written at §7 or attributed to
Paper 9: Paper 9's definition is verbal — it prints no symbol for it,
and none is attributed to it here (§0.5).

**Proposition 5.3 (every frequency is a census or flow ratio).**
Let a population and a window W be declared. Then each of the
following is an exact rational ratio of census or flow counts over W:

(i) the frequency with which class X is occupied — the number of
(member, tick) pairs in W standing in X, divided by the number of
(member, tick) pairs in W;
(ii) the rate of any event kind defined by ledger data (e.g. junction
completions, reconcile events) — the count of such events in W
divided by |W|, the number of ticks;
(iii) the long-run frequency of a class along an aggregate trajectory —
see the proof: it is a ratio of counts over one period of the
trajectory.

[LEVEL A — (i) and (ii) by construction from Definitions 5.1–5.2;
(iii) by the finiteness argument in the proof, using Theorem 4.2.]

*Proof.* (i) and (ii) are Definitions 5.1–5.2 read aloud: the
numerator is a count of actual (member, tick) pairs or actual events
in a declared finite window; the denominator is a count of ticks or
pairs; the ratio is an exact rational. For (iii): a population state
is a finite tuple of finite data — node states drawn from the finite
27-state inventory, junction local states drawn from finitely many
port configurations — so the set of population states is finite.
T_agg is a deterministic function on this finite set (Theorem 4.2),
so the trajectory from any S₀ is eventually periodic: a finite
transient followed by a cycle of some length ℓ ≥ 1. On the cycle, the
number of ticks per period in which the population (or a chosen
member) stands in class X is an exact integer c_X, and the long-run
frequency is the rational c_X/ℓ — attained exactly, not approached:
for any window consisting of whole periods taken after the transient,
the ratio of counts is precisely c_X/ℓ. Transient ticks precede the
cycle and contribute nothing to periods; no limit is taken and no
continuum is invoked anywhere in the argument. ∎

**Theorem 5.4 (dissolution: no sampling measure is needed).**
Every place in the Paper 11.5 §11.6 debt where a sampling measure
seemed to be required resolves, under §§3–4 and Definitions 5.1–5.2,
to deterministic dynamics or to exact counting — in the three cases:

(a) *Long-run frequency.* Seemed to need: weights over states, giving
how often each is visited. Resolved by: orbit counts. Proposition
5.3(iii) — the trajectory is eventually periodic and the frequency is
c_X/ℓ, a ratio of integers read off the actual orbit. The dynamics
itself supplies the visits (for windows of whole periods after the
transient — Proposition 5.3(iii)); nothing weighs them.

(b) *The single-tick ensemble.* Seemed to need: at one tick, a
probability distribution over the states the population "could" be
in, given only aggregate data. Resolved by: refusal of the question's
frame, replaced by the census. At one tick the population is not
"in" a distribution over possible states; it stands in one actual
state, and the aggregated ledger records C_t(X) for every class X —
the exact fraction of the actual population standing in X at t is
C_t(X) / |population|, an exact rational about what is there, not a
probability about what might be. The measure was needed only to speak
about states that did not occur; the ledger speaks only about states
that did.

(c) *The fill rules.* §11.6 also assigned to this paper "which
encounter actualizes with what probability at a given tick." Resolved
by: dynamics, stated exactly in §5.5 below. What actualizes at a tick
is determined — by T's canonical-first rule at each junction and by
Paper 11's encounter selection — not drawn. The frequency with which
an encounter kind actualizes over a window is the count of its
actualizations divided by the window's tick count: a census ratio
under Proposition 5.3(ii).

Therefore the "sampling-measure postulate" pre-registered in §11.6 is
**unnecessary**: it is not adopted, not replaced by a weaker postulate,
and not smuggled in under another name. The debt's item (2) is
discharged by dissolution. [LEVEL A — as a scoping result: the proof
is the case analysis (a)–(c) above, resting on Proposition 5.3,
Theorem 4.2, and §3's counting rule.]

**The estimation residue (closing note to Theorem 5.4).** One use
of sampling survives the dissolution, and it is a use about
arithmetic, not about nature. Where a declared population's records
are too many to enumerate in full, sampling returns as a *method of
estimation* of census quantities: a count over a sample estimates the
census ratio of Proposition 5.3 — it does not define it. The quantity
estimated remains the exact rational of §5.3, formed over the full
declared population and window whether or not anyone enumerates it;
and the estimate's error is itself a counting fact about the sample —
how many sampled records stood in the class, set against the census
count — not a probability over states that did not occur. Sampling,
so used, introduces no measure, no distribution, and no postulate:
the quantity it approximates was fully defined before the
approximation began. [LEVEL A: AUTHOR — scope statement: this note
fixes what sampling may mean in this paper's uses; it asserts no
frequency and estimates none.]

**Proposition 5.5 (fill rules, discharged).** Which encounter
actualizes at a given tick is a determinate output of the framework,
not a probabilistic event: at each established junction, the
encounter presented at that tick is the one constituted by the port
vectors actually presented (Paper 11's encounter taxonomy, by
presented-count profile), and its resolution is T's action — the
canonically first admissible pair is zeroed, or none is and the
junction rests (Paper 11 §7.5, applied population-wide by §4). There
is no residual slot in this account for a probability: the
deterministic rules consume the whole question. Frequencies of
encounter kinds over declared windows are census ratios (Proposition
5.3(ii)). [LEVEL A — conditional on Paper 11 §7.5 and the encounter
taxonomy of Paper 11 §8.]

**Re-scoping 5.6 (what MC.1's uniform sampling was).** Paper 11.5's
script MC.1 sampled uniformly over a finite set of presented-count
profiles. Under this section's accounting, that uniformity is a
property of the *test*, not of nature: MC.1 is a stress test, and a
stress test enumerates its test set — each profile in the finite set
counted once — in order to check a claim over the whole set. Read
honestly, MC.1's conclusions are counting statements over its declared
test set (a census of the test set), and no sentence of Paper 11.5 or
of this paper licenses reading them as frequencies in a physical
population. Where a physical frequency is wanted, this paper supplies
it as in Proposition 5.3, from an actual population and window. This
re-scoping narrows nothing MC.1 proved as a test; it refuses an
interpretation MC.1 never earned. [AUTHOR — an interpretive honesty
statement about Paper 11.5's script, made by the author of both.]

### Claim list — §5

- **L5.1-P12** — *Definition:* the census C_t(X) is the exact integer
  count of actual population members standing in count-class X at
  tick t; classes are defined by ledger data and partition the
  population. [Definition]
- **L5.2-P12** — *Definition:* flow counts F_t(X→Y) are the exact
  numbers of members moving class X→Y over one aggregate tick,
  satisfying Σ_Y F_t(X→Y) = C_t(X) and Σ_X F_t(X→Y) = C_{t+1}(Y).
  [Definition]
- **L5.3-P12** — Every frequency used in this paper — class occupancy,
  event rates, long-run trajectory frequencies — is an exact rational
  ratio of census or flow counts over a declared window; long-run
  frequencies are period counts c_X/ℓ of the eventually periodic
  aggregate trajectory. [LEVEL A — conditional on Theorem 4.2]
- **L5.4-P12** — The sampling-measure postulate pre-registered in
  Paper 11.5 §11.6 is unnecessary: long-run frequencies resolve to
  orbit counts, the single-tick "ensemble" resolves to the census,
  and the fill rules resolve to the deterministic dynamics. The debt
  is discharged by dissolution, with no postulate adopted. [LEVEL A —
  scoping result, resting on L5.3-P12, Theorem 4.2, and §3]
- **L5.5-P12** — Which encounter actualizes at a given tick is
  determined by the presented port vectors and T's canonical-first
  rule; encounter-kind frequencies over windows are census ratios.
  [LEVEL A — conditional on Paper 11 §7.5 and §8]
- **L5.6-P12** — MC.1's uniform sampling is re-scoped as enumeration
  of a finite test set (a property of the stress test), not a physical
  sampling measure. [AUTHOR]

---

## §6. Capability as a relation

Paper 11.5 §7.4 used a distinction it declined to certify: "the formal
account of capability as a relation to possible encounters — what
makes a capability structural rather than carried — is Paper 12's
work. Nothing here certifies it; the distinction is used, not derived."
This section derives it. Under the corrected frame, "possible
encounters" is tightened to what the framework actually contains:
Paper 11's **finite taxonomy of encounter kinds**, each kind specified
by its presented-count profile M = (n+, n−) — the counts of positive
and negative presentations the encounter puts forward (Paper 11 §8).
A body's capability in a role is then nothing but its standing
relation to that taxonomy, tick by tick.

**Definition 6.1 (capability).** Let G be a body (a bonded aggregate
admitted to the aggregated ledger per §§2–3) and R a role in the role
taxonomy Paper 11 exports to this paper. The **capability of G for
role R** is the set

    Cap(G, R) = { (E, t) : E is an encounter kind in Paper 11's
                  taxonomy, t is a tick, and in encounter E at tick t,
                  G stands in role R }.

Cap(G, R) is a set of pairs — a relation between G, the encounter
taxonomy, and the tick — not a quantity stored in G. Whether (E, t)
belongs to Cap(G, R) is decided by the encounter: by E's presented-count
profile M(E) = (n+, n−), by what G presents to E at tick t, and by
Paper 11's rules for role occupancy in an encounter. [Definition]

**Theorem 6.2 (capability factors through presented-count profiles).**
If two bodies G and G′ present equal count profiles at tick t — the
same presented counts to the encounters of the taxonomy — then for
every role R and every encounter kind E,

    (E, t) ∈ Cap(G, R)  ⟺  (E, t) ∈ Cap(G′, R).

That is: at a fixed tick, capability is a function of the presented-count
profile, and of nothing else about the body.
[LEVEL A — conditional on Paper 11 §8.6 (where it is proved at Level A
that encounter outcomes factor through the presented-count map
M = (n+, n−): over 710,090 machine-checked encounters, the outcome
depended only on the presented counts, with zero divergences) AND on
Paper 11 §8's role-occupancy assignment — roles attach to encounter
sides by the encounter's outcome class — consumed as an inherited
premise.]

*Proof.* One premise is marked before it is used: role occupancy in
an encounter is a feature of the encounter's outcome — G stands in
role R in encounter E at tick t according to what the encounter does.
That premise is [Inherited premise — Paper 11 §8], where roles attach
to encounter sides by the encounter's outcome class; the proof
consumes it as an inherited premise, not as a consequence of §8.6.
Paper 11 §8 determines outcomes from presented data. By Paper 11 §8.6, the outcome of an
encounter depends only on its presented-count profile M = (n+, n−) —
not on the interior constitution of the presenting bodies, not on
their histories, not on anything else they might be said to carry.
Hence if G and G′ present equal profiles at tick t, then for each
encounter kind E the encounter presented to G and the encounter
presented to G′ have the same profile, the same outcome, and
therefore the same role occupancy: (E, t) ∈ Cap(G, R) iff
(E, t) ∈ Cap(G′, R). Since E and R were arbitrary, Cap(G, ·) at tick
t is determined by the presented-count profile alone. ∎

The content of the theorem is the denial of the alternative. If
capability were *carried* — a possession of the body, stored in its
interior — then two bodies with equal presented profiles but different
interiors could differ in capability, and Theorem 6.2 would fail. It
does not fail, because Paper 11's outcomes never consult the interior.
Capability is structural in the exact sense that it supervenes on
presented relational data — counts at a boundary, against a finite
taxonomy of encounter kinds — and on nothing intrinsic.

**Worked case 6.3 (§7.4's spin-presentation capability, restated
relationally).** Paper 11.5 §7.4 treated the case of a body that
*presents spin* in an encounter: standard ontology carries spin as an
intrinsic possession of the particle, a property it has alone, before
any encounter and between encounters. In the present formalism the
entry is a relation and nothing else. Fix the encounter kinds of
Paper 11's taxonomy whose profiles constitute spin-presentation
encounters — those E whose presented-count profile M(E), against the
profile G presents at tick t, yields the spin-presentation outcome
class of §8. Then

    Cap(G, spin-presenter) = { (E, t) : E a spin-presentation kind,
                               and G's presented profile at t completes
                               the spin-presentation outcome }.

Every clause of the definition is relational: the encounter kind, the
tick, the two presented profiles. Remove the encounters — consider G
with no encounter at any tick — and the set is empty: there is no
remainder, no stored spin left over in the body, nothing for G to
"have" in isolation. The emptiness just stated is true by
construction — a set of (encounter, tick) pairs ranging over no
encounters is empty by Definition 6.1 — and it is not where the
substantive content sits. The content is Theorem 6.2's contrapositive:
were a capability carried, it would appear as profile-independent
residue in the taxonomy — capability differences between bodies
presenting equal profiles — and the theorem shows there are none.
What §7.4 called the axis-relativity of the
presentation is, in this restatement, the dependence of membership
(E, t) ∈ Cap(G, spin-presenter) on E's profile: change the encounter
kind and the same body at the same tick may stand outside the set.
That is the whole phenomenon, and it needed no carried quantity at
any point. [Worked instance of Definition 6.1 and Theorem 6.2 —
LEVEL A conditional as in Theorem 6.2.]

**Discharge receipt 6.4 (against §7.4, sentence by sentence).** The
debt sentence, discharged clause by clause:

1. *"the formal account of capability as a relation to possible
   encounters"* — given in Definition 6.1: Cap(G, R) is a set of
   (encounter-kind, tick) pairs. "Possible encounters" is corrected
   to Paper 11's finite taxonomy of encounter kinds: the relation
   ranges over kinds the framework defines, not over a space of
   possibilities.
2. *"what makes a capability structural rather than carried"* —
   answered by Theorem 6.2: a capability is structural because its
   membership is decided entirely by presented-count profiles against
   the taxonomy — equal profiles, equal capability, whatever the
   interiors — and carried by nothing: §6.3 shows the capability set
   is empty when the encounters are removed, leaving no residue in
   the body.
3. *"Nothing here certifies it; the distinction is used, not derived"*
   — the distinction is now derived, from Paper 11 §8.6's
   count-factorization, with the conditional badge stated on Theorem
   6.2 rather than hidden. What Paper 11.5 used, this section proves —
   at exactly the strength of its one cited premise, and no further.

### Claim list — §6

- **L6.1-P12** — *Definition:* Cap(G, R) is the set of (encounter-kind,
  tick) pairs — encounter kinds from Paper 11's finite taxonomy,
  specified by presented-count profiles M = (n+, n−) — under which
  body G stands in role R. [Definition]
- **L6.2-P12** — Equal presented-count profiles at a tick imply equal
  capabilities at that tick, for every role and encounter kind:
  capability factors through the presented-count profile.
  [LEVEL A — conditional on Paper 11 §8.6]
- **L6.3-P12** — The spin-presentation capability of Paper 11.5 §7.4
  is exactly a Cap-set of the form in L6.1-P12: relational in every
  clause, empty in the absence of encounters, with no carried residue.
  [LEVEL A — conditional as L6.2-P12]
- **L6.4-P12** — The §7.4 debt is discharged: capability is structural
  rather than carried because it is a relation to the encounter
  taxonomy decided by presented-count data — per the receipt in §6.4.
  [LEVEL A — conditional as L6.2-P12]
