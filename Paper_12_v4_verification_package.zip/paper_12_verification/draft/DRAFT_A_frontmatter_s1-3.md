# DEPARTURE FROM THE PHOTON BASELINE SERIES

## Paper 12: The Aggregated Ledger — Many-Body Statistical Mechanics and the Emergence of Bulk Thermodynamics

**By Dervis Kadunic**

2026 — v1 DRAFT (2026-10-24)

*Umbrella series title: Departure From the Photon Baseline: A Universal Ruler for Mass, Gravity, and Time. Paper 12 of the series; Tier 1 (foundational). The companion critique convention does not apply — Paper 12 is a foundational paper, not a critique. A note on the subtitle's word "Emergence": it is the series' battle-plan title, kept verbatim. In this paper's native vocabulary there is no emergence mechanism — Paper 11's rule R15 forbids one (§2) — and nothing in what follows posits one. What the title word points at is built in §§7–9 as exact census quantities of the same ledger that describes a single configuration. The title is the series' name for the territory; the paper's constructions are the paper's own.*

---

## ABSTRACT

Paper 11 described configurations and their encounters: one rule set for a lone configuration and for any finite bonded aggregate, every aggregate quantity an exact finite sum, count, or rational ratio over constituent data. What Paper 11 deliberately did not build — it walled the territory off and named the wall — is the statistics of many bodies at once: how a population of configurations, each standing in its own junctions and carrying its own ledger record, is counted, how its counts move tick by tick, and what bulk quantities those counts support. That territory is this paper.

Two debts were left on the record by the companion critique, Paper 11.5, and this paper pays both. The first is a definition: capability, used throughout 11.5 as a structural relation rather than a carried possession, was never formally constructed — "the formal account of capability as a relation to possible encounters … is Paper 12's work" (§7.4). The second is a rule: the count→weight step, by which combinatorial counts become frequencies, was "not certified" in 11.5, which named two missing pieces — "(1) a microstate-counting rule, and (2) a sampling-measure postulate. Both are Paper 12's work" (§11.6).

This paper discharges the first debt in §6 (capability constructed as a relation over Paper 11's finite encounter taxonomy) and the first half of the second in §3 (a counting rule). The second half of the second debt is discharged differently, and the difference is one of this paper's results: **the sampling-measure postulate is never needed, and none is adopted.** The need for it was an artifact of a frame this framework refuses — two levels of description, a counted level underneath and a summarized level on top, with a measure spread over the states the summary discards. Under the single-regime rule there is one level: the ledger. A population's bodies stand in actual count-classes; the census counts them; the deterministic dynamics moves them between classes in exact flow counts; a frequency is a ratio of actual counts over a declared tick window — the shape of Paper 9's own definition of temperature, "the localized density and frequency of chaotic creation-geometry rewrite events per tick" (§4). Nothing is weighed over possibilities, because nothing in the ledger is merely possible: every record counted here is a record of something that stands, or stood, at a tick. Paper 11.5's own roadmap sentence stated the programme exactly — "frequencies from combinatorics without an imported measure" — and §5 proves the programme is sufficient.

**Method.** Every construction is native: finite sets, exact integer counts, rational ratios, and Paper 11's transition operator applied at every established junction (§4). No continuum calculus appears in any Stage N passage. Each thermodynamic word locked by Paper 11's §0.5 is admitted in this paper only through a stated native construction, admitted only as an excluded frame with the reason given, or confined to a single declared bridge sentence at Stage P (§0.5 below gives the full construction list; §8 discharges the hardest case, entropy). Bulk temperature is constructed in §7 as an aggregate reconcile density — an exact rational, census over window. The thermodynamic arrow is stated in §8 from three ingredients only: the monotonicity of the aggregate τ under the dynamics, the census counting of §8, and Paper 9's asymmetry of occasion, received as a cited boundary condition, not re-derived.

**Scope discipline.** This paper does not re-derive Paper 11's role taxonomy; it receives it, as Paper 11's export specifies, "to determine which configurations count as resolvable bodies in the aggregated ledger." It does not treat time (Paper 13), the exact saturation point (Paper 14), or high-density packing (Paper 16). It introduces no new primitive. Where a derivation bottoms out, the paper says so at the site, in the claim list, rather than papering over the floor.

---

## 0 &nbsp; PREAMBLE AND EPISTEMIC ARCHITECTURE

This paper extends Paper 11's verified ledger to populations. It applies the same verification discipline Papers 11 and 11.5 applied: every claim carries an epistemic badge, every inherited claim carries an inheritance line, and the paper's own prose is swept by a firewall script (FW.1) for the vocabulary it forbids itself. This section defines the machinery so the paper's verdicts are mechanically checkable, not rhetorically asserted.

### 0.1 The three stages

The series distinguishes three stages of description, and every claim in this paper belongs to exactly one.

- **Stage N (native).** The ledger's own vocabulary: configurations, ports, junctions, ticks, counts, ratios of counts. Stage N statements are finite and exact. No continuum calculus, no dimensional scale, and no thermodynamic primitive appears at Stage N.
- **Stage P (physical reconstruction).** The stage at which native quantities are connected to measured physical quantities — seconds, joules, kelvin — through declared bridge sentences and measured calibrations. A bridge sentence is stated once, at its site, and flagged as a bridge; it is never used inside a Stage N derivation.
- **Stage C (commentary).** Discussion of other formalisms — standard statistical mechanics, textbook thermodynamics — on their own terms, for audit and comparison. Stage C passages exhibit the standard formalism; they do not ground any native claim.

Temperature, entropy, and their kin live at Stage P or Stage C in this paper, each through the construction listed in §0.5 — never at Stage N.

### 0.2 Badge definitions

Every claim in this paper carries an epistemic badge:

- **[LEVEL A]**: Machine-checked (script exits 0), or inherited from a cited source paper's Level A result with lineage cited (inheritance line, §0.4), or prose-proved with no gaps. The strongest claim this paper makes.
- **[LEVEL A: MACHINE]**: The claim's content is the output of a named verification script, run on the paper's final tree, exit 0. The badge is exactly as wide as its validation artifact: the script checks what the script checks, and the prose around it claims no more.
- **[LEVEL A: AUTHOR]**: The declared-axiom subtype of Level A (Paper 11.5 §0.5.1's [LEVEL A, author-authorized], carried here in this paper's short form). Declaration-backed, not derivation-backed. It guarantees exactly three things: (1) the declaration was made, by the author, in the open — its content, date, and location are recorded; (2) the declaration is *traceable* — the inheritance or declaration line names its source; (3) the declaration is *stable* — downstream claims carry the subtype with it, so the declared character cannot be laundered into "proved" by distance. It does NOT guarantee independent derivation or a machine check. Every [LEVEL A: AUTHOR] claim states its falsifiers — concrete, checkable conditions under which the declaration fails — or states explicitly that no genuine falsifier exists and names the limit instead. A declaration with neither is an assertion, not a badged claim.
- **[LEVEL A: MACHINE / AUTHOR]**: A hybrid claim, partly machine-checked, partly declared. The components are listed explicitly at the claim site. [LEVEL A] covers exactly the machine-checked content; the declared identification is carried under the [LEVEL A: AUTHOR] discipline and never extends the machine content. The halves do not cover each other, and the mark splits rather than averages.
- **[CITED]**: The claim is a quotation or a faithful restatement of a named source — a paper of this series or a verified external source — with the address given (paper, section, and line or registry row where applicable). A [CITED] claim asserts that the source says it; the claim's own epistemic weight is whatever the source's badge is, traced through the inheritance line.
- **[LEVEL B]**: Illustration, conditional reading, declared programme, or author-authorized declaration of weaker standing than [LEVEL A: AUTHOR]. Honest but weaker — the dependence is stated at the site.
- **[Declared assumption]**: A premise this paper adopts openly because derivation bottoms out at that point. Each declared assumption is isolated, named, badged at every use site, and accompanied by the reason derivation stopped and by what would falsify or discharge it. A declared assumption is never load-bearing in silence: any claim resting on one lists it among its dependencies.
- **[LEVEL C]**: Deferred to a later paper. Not claimed here.
- **[NO BADGE]**: Cannot be derived and is not declared as an assumption. Under Paper 11's D.2 rule: conjecture — do not cite as established.
- **Denied [Level A]**: A verdict, not a grade of endorsement (Paper 11.5 §0.5.1, author-authorized 2026-10-18, framework-wide). It marks a claim put through Level A treatment — machine check, inherited Level A result, or gapless prose proof attempted — whose examination returned a negative verdict. The bracketed [Level A] names the rigor of the examination; **Denied** is the verdict. It is not Level B or C: a denial is not an endorsement at any strength, and rebadging it would misrepresent denial as a dimmer endorsement.

**Approximation rule (author-authorized 2026-10-18 — framework-wide).** Wherever this paper presents an approximation, a rounding, or a translator *as its number* for a badged claim, it is [LEVEL B] — honestly labeled with why it was made — and the real number is specifically badged right beside it. Nothing this paper badges is rounded silently. Incidental "≈" in expository prose is notation, not the paper's badged number, and is out of scope. Badged numbers print at fixed decimals; the machine's full computed value is stated wherever a rounding is load-bearing.

**Precision convention for this paper.** The native arithmetic of Paper 12 is exact — integers and rational ratios — so most badged numbers need no rounding at all. Where a Stage P bridge produces a decimal (it happens only in §8's bridge context), the approximation rule above governs it in full.

### 0.3 Dependency labels

Each Level A claim lists its dependencies as bracketed labels. The labels L#-P12 are this paper's; they name the lineage a claim stands on, and the bridge rule caps the claim at its weakest dependency.

- **[L1-P12]**: Paper 11 v69 Level A results, inherited with lineage: the single-regime rule (claim 41; §4.1; audit rule R15), the licensed aggregate sums (§4.1), Port-Partition Exactness (§4.3), the transition operator T (§7.5), the encounter outcome map through presented counts (§8.6), and the role taxonomy export (§16).
- **[L2-P12]**: Paper 9's natives: heat as interaction event; the orthogonal budget rule v² + s² = c² over Paper 8's Circa budget, as Paper 9 states it (§§1, 5, 8); temperature as the localized density and frequency of chaotic rewrite events per tick (§4 — a verbal definition; Paper 9 prints no symbol for it, and none is inherited); reconcile work at contact (Paper 9 §8.1, as cited by Paper 10); the asymmetry of occasion (§5), received as a boundary condition.
- **[L3-P12]**: Paper 10's results: the shell count N(d) = 4d² + 2 (§2.4.1); the Uniform Load Partition (§2.4.7, with the partition definition S(d) = s²_node/N(d) at §2.2); the contact-budget partition N_total = N_id + v²_contact + s² + N_reconcile = 100 CU (§2.2, eq. 2.4).
- **[L4-P12]**: Paper 11.5 v26 — the commissioning text: the two debts (§7.4, §11.6) and the roadmap sentence (§1).
- **[L5-P12]**: Paper 9.5's audit standard: a thermal variable counts as derived only if obtained from the discrete process without temperature, equilibrium assumptions, or ensemble distributions as primitives.
- **[L6-P12]**: This paper's own definitions (§§2–4) and declared assumptions, each named at its site.

**Bridge rule** (from Paper 10.5, carried through 11.5): L_claim ≤ min(L_i) — a claim cannot outrank its weakest dependency.

### 0.4 The badge inheritance rule — no silent Level A by distance

An inherited claim may not outrank its source. Every claim this paper inherits at Level A carries an **inheritance line** at its first use site:

**Inheritance:** Source: Paper 11 v69 §X.Y — badge carried at source: [LEVEL A] or [LEVEL A: AUTHOR] — validation: the source's registry row (script id, or prose section, or author-authorized definition with date, as recorded there) — Paper 12 reliance: what this paper uses it for.

Three hard rules govern the line, carried verbatim in substance from Paper 11.5 §0.5.6:

1. **The subtype propagates.** If the source records the claim as an author-authorized declaration, the claim is carried here as [LEVEL A: AUTHOR] with its stated falsifiers, never as bare [LEVEL A]. Distance does not convert a declared axiom into a proved fact.
2. **Hybrids are split, not averaged.** Where a claim's content is partly machine-checked and partly declared, [LEVEL A] covers exactly the machine-checked content, and the declared part is disclosed in the line under the [LEVEL A: AUTHOR] discipline.
3. **Inline cites point to the line.** An inline citation in the prose is a pointer; the inheritance line at the claim's home site carries the traced validation path. Nothing inherits Level A from an inline cite alone.

### Claim list — §0

- **Claim 0.1** — The epistemic architecture of this section (badges, dependency labels, inheritance rule, approximation rule) is adopted for Paper 12 in the form stated. **[LEVEL A: AUTHOR]** — declared architecture; falsifier: any claim in this paper found carrying a badge its stated backing does not support is a defect against this declaration, correctable by rebadging, and FW.1/H.1 exist to catch it.
- **Claim 0.2** — No claim in this paper outranks its weakest dependency (bridge rule, §0.3). **[LEVEL A: AUTHOR]** — procedural declaration; its enforcement artifact is the registry audit (script H.1), and a registry row violating the rule fails that script.

---

## 0.5 &nbsp; SCOPE AND THE THERMO-WORD CONSTRUCTION LIST

### What this paper does

Paper 12 constructs the statistics of populations inside Paper 11's single regime: the counting rule (§3), the aggregate tick (§4), frequencies as census ratios and the dissolution of the sampling-measure postulate (§5), capability as a relation (§6), bulk temperature (§7), the entropy bridge (§8), the arrow (§8) and the constructed equilibrium predicate (§9), collective modes scoped to their native substrate (§10), the complexity-ordering extension graded by derivation permission (§11), falsification conditions continuing the series numbering at C23 (§12), and the bridge ledger of imports and exports (§13).

### What this paper does not do

- It does not re-derive the role taxonomy. Paper 11's §16 export is received, not re-opened (§1.4).
- It does not treat time as a formalism. Ticks are counted; the 720° manifold scan and the origin of time are Paper 13's. Paper 12 cites ticks only.
- It does not fix the Junction Saturation Threshold's exact point. The threshold is Paper 7's construct, cited — not defined — by Paper 9; its exact point is Paper 14's locked debt, and cosmic expansion is Paper 14's. Where this paper needs aggregate load behaviour (§9), it builds it from Paper 9 §6's saturation cascade and badges it as this paper's construction: neither Paper 9 nor Paper 10 states an "aggregate-load ceiling" definition, so none is inherited.
- It does not do packing. High-density aggregate packing and the baryon/meson structural mapping are Paper 16's. Paper 12 is the statistics of populations, not their packing geometry.
- It does not treat beta decay or any travelling-particle neutrino content. That topic is Paper 15's, and the ban on the neutrino as a travelling particle is absolute in this series.
- It does not import the complexity-difference selection rule from unpublished lab notes. That rule is quarantined: it conflicts with Paper 10's mass-agnostic shell count N(d) = 4d² + 2, and it appears in this paper only as a named exclusion.

### The construction list

Paper 11's §0.5 terminology lock ruled that the words "temperature", "entropy"/"entropies", "Gibbs", "Boltzmann", "k_B", "ensemble", "microstate"/"macrostate", "thermal equilibrium", and "probability distribution" "do not occur in Stage N and name nothing in the native vocabulary," and that statistical aggregation "is Paper 12's declared territory (§14.2), constrained by Paper 9's asymmetry of occasion, not computed here" [CITED — Paper 11 v69 §0.5]. This paper is that declared territory. Its method for each locked word is fixed here, in advance, so no word drifts in later wearing a construction it did not earn: each word is either **constructed** (a native definition earns the word, at a named section, with its stage marked), **bridged** (the word enters only inside one declared Stage P bridge sentence), or **excluded** (the word names a frame this paper refuses; it survives only inside quotations and Stage C audit passages, and the exclusion is permanent for this paper's native voice). The firewall script FW.1 sweeps this paper's prose for exactly these dispositions.

| Locked word | Disposition | Construction / reason | Site |
|---|---|---|---|
| temperature | Constructed (Stage P shadow) | Paper 9 §4 defines temperature verbally: "the localized density and frequency of chaotic creation-geometry rewrite events per tick." (Paper 9 prints no symbol for it; the shorthand T_ledger seen in series working notes is later shorthand, not a Paper 9 term, and this paper does not cite it as one.) §7's construction carries that definition to populations unchanged in kind: total reconcile events counted over a declared population and tick window, divided by the window's tick count — an exact rational ratio of actual counts. Never a native primitive; never 1/T = ∂S/∂U (that identity is named in Paper 11's lock as never native, and this paper does not rehabilitate it). The Stage P marking is this paper's architecture (following Paper 11's lock, which calls temperature a Stage P/C reconstruction shadow); Paper 9 itself carries no stage labels, and none are attributed to it. | §7 |
| entropy | Bridged only | The native quantity is an exact count of actual ledger records (§8). The word "entropy" enters solely inside one declared Stage P bridge sentence, S = k_B ln Ω, stated once at its site and never used in any Stage N derivation. | §8 |
| ensemble | **Excluded** — permanent | The word names an imagined collection of unrealized copies of a system, assembled so that averages can be taken over what did not happen. Paper 9.5's verdict stands: the ensemble is an averaging procedure over an imagined collection, adopted because the continuum theory cannot track the actual event-by-event history — and a physical count has no ensemble to construct. This paper's replacement word is **population**: the actual finite family of bodies under count, every member of which stands at a tick with its own ledger record. | — |
| microstate / macrostate | **Excluded** — permanent | The pair presupposes two levels of description: a fine level that is real and a coarse level that summarizes it, with information lost between them. The single-regime rule (Paper 11 claim 41; §2 below) admits one level — the ledger — and an aggregate quantity is an exact sum or count over the same records a single body has, so nothing is summarized and nothing is lost. This paper's replacement words are **ledger record** (a body's actual per-tick data) and **count-class** (§3). Paper 11.5's debt text (§1.2) uses the locked word "microstate-counting rule"; the debt is paid in full under the replacement name — a counting rule — and §1.2 says so at the receipt. | — |
| thermal equilibrium | Constructed (native predicate) | A population whose census (§3) is unchanged by the aggregate tick (§4) over a declared window: every established junction at a fixed point of Paper 11's operator, so every flow count (§5) is zero. Constructed as a predicate on actual records; no appeal to any standard equilibrium postulate. | §9 |
| probability distribution | **Excluded** as a primitive | No distribution is ever posited in this paper. A frequency is a census ratio: a count of actual events or actual class-members divided by a count of actual ticks or actual population members (§5). Where standard theory writes a distribution over outcomes, this paper writes the flow counts that the deterministic dynamics produces, enumerated over a declared population. The phrase survives only in quotations and Stage C audit. | — |
| Gibbs | Excluded as method | The Gibbs construction is the excluded ensemble frame's machinery (Paper 9.5's audit exhibit). The name appears in this paper only in citations and Stage C discussion of that audit. | — |
| Boltzmann | Excluded as method | As Gibbs: the name appears only in citations and Stage C audit contexts (Paper 9.5's Gibbs–Boltzmann contrast is the exhibit). No Boltzmann weight, factor, or constant is used natively; the constant enters only through the §8 bridge, below. | — |
| k_B | Bridged only | The token appears solely inside the §8 bridge sentence, in the role Paper 9.5 assigned it: an assigned Stage P conversion token. It appears in no Stage N line of this paper — the native chain never touches it, exactly as it never touches the logarithm in the bridge. | §8 |

Two consequences of the list are worth stating plainly, because they shape everything after §2. **First**, the excluded words are excluded as *frames*, not as sounds: §1 quotes Paper 11.5's debt text verbatim, locked words included, because a receipt must show what was written. Quotation is mention, and the firewall's exemptions are written for exactly that — as Paper 11's F.42 admitted the lock paragraph itself. **Second**, the exclusions are not a gap in this paper's coverage. Everything the excluded frames were invented to do — supply frequencies, define an arrow, fix an equilibrium — is done here by census counts, flow counts, and the constructed predicate, and §5 and §9 prove the replacements carry the load. A frame is not missed once its work is done without it.

### Claim list — §0.5

- **Claim 0.3** — The construction list above fixes, for each word locked by Paper 11 §0.5, its sole permitted route into this paper; any use of a locked word outside its listed disposition is a defect against this section, swept by FW.1. **[LEVEL A: AUTHOR]** — declared discipline; falsifier: a locked word found in this paper's native voice outside its disposition and outside a firewall exemption, standing uncorrected in a final tree.
- **Claim 0.4** — Paper 11's lock text, quoted in this section, is as cited. **[CITED — L1-P12]** (Paper 11 v69 §0.5; quote integrity is machine-checked by script G.1 against the source on disk.)

---

## 1 &nbsp; WHAT WAS OWED

This paper was commissioned three times: twice by the companion critique that left its debts on the record, and once — earlier, and in stronger terms — by the foundational paper whose territory this is. The receipts are stated here verbatim, because a debt discharged against a paraphrase is not discharged.

### 1.1 The first debt: capability, used but not constructed

Paper 11.5's §7.4 answered the dispositional reading of "intrinsic" by distinguishing capability from actuality — a configuration's capability is structural, indexed to encounters, not a possession it carries. The section closed with a scope note that names the unpaid bill exactly (Paper 11.5 v26, §7.4):

> **Scope note.** This reply uses the working capability/actuality distinction without constructing it. 11.5 is a companion critique, not a foundational paper: the formal account of capability as a relation to possible encounters — what makes a capability structural rather than carried — is Paper 12's work. Nothing here certifies it; the distinction is used, not derived.

[CITED — L4-P12]

One word in that receipt is read in this paper under the correction of §0.5. "Possible encounters" cannot mean a space of unrealized worlds spread out for a measure to range over — that frame is excluded, permanently. It means the encounters of Paper 11's finite taxonomy: the encounter kinds the ledger admits, each specified completely by its presented-count profile — the count map M = (n+, n−) through which, Paper 11 §8.6 machine-proved, every encounter outcome factors. A capability is then a classification over that finite taxonomy: for which encounter kinds, at which ticks, does this body play this role. §6 constructs it in that form, and the construction is a relation in the strict sense — a set of (encounter, tick) pairs falling out of boundary and count data — not a property of the body alone. What made the capability "structural rather than carried" in 11.5's prose is proved there as a theorem about profiles: bodies with equal presented-count profiles have equal capabilities at a tick, whatever their interiors.

### 1.2 The second debt: the count→weight step

Paper 11.5's capstone (§11) showed the standard predictive pipeline running on discrete counts, and then stopped, deliberately, at the step it could not certify. The stop is recorded at §11.6:

> Combinatorics supplies the *counts*; the count→weight step is not certified here. It needs two things this paper does not build: (1) a microstate-counting rule, and (2) a sampling-measure postulate. Both are Paper 12's work.

> The fill rules — which encounter actualizes with what probability at a given tick — are the dynamics the framework has not yet built (§11.5).

> … it does not pretend to stand on what it has not — the fill rules and the sampling measure are Paper 12's work, named above, not smuggled in here.

[CITED — L4-P12]

The two named items are discharged in two different ways, and §0.5 has already forced the difference into the open.

**Item (1), the counting rule — constructed, under a corrected name.** The word "microstate" in the debt text is one of Paper 11's locked words, excluded as a frame in §0.5: it names the lower level of a two-level picture this framework does not have. The debt's substance, however, is untouched by the renaming: what was owed is a *rule that counts* — a stated, checkable procedure by which the records of many bodies are counted, class by class, with the arithmetic shown. §3 supplies it under the name this paper uses throughout: the **counting rule**, and its output is the **census**. Nothing in the debt is reduced by the name change; the rule counts everything the locked word gestured at, and it counts only what stands.

**Item (2), the sampling-measure postulate — discharged by dissolution.** This paper adopts no sampling-measure postulate, anywhere, and §5 proves none is needed. The preview of the proof belongs here, because it changes what the reader should watch for. A sampling measure is a device for spreading weight over states that did not occur, in proportion the theory cannot extract from the states that did. It is needed exactly when the theory's basic records are summaries — when the fine detail has been discarded and must be averaged back in. The ledger discards nothing. Its dynamics (Paper 11's operator T) is deterministic and total; applied at every established junction (§4), it moves each body from the count-class it stands in to the count-class it stands in next, and the number of bodies making each move in a tick is an exact count over the actual population — a **flow count**. A frequency, in this paper, is a ratio of such counts over a declared window: counts of things that happened, divided by counts of ticks or of bodies. There is no remainder for a postulate to cover, because there is no discarded level for the postulate to reconstruct. What 11.5's MC.1 did with uniform sampling is re-scoped at §5.4 and stated plainly there: a sampling device over a finite set, inside a stress-test script — a method of an audit, never a premise about the world. It is not retroactively promoted to a postulate, and it is not retroactively needed as one.

The fill rules fall with the same argument. "Which encounter actualizes at a given tick" is, in the ledger, not a draw from a distribution but a fact of the dynamics: the encounters a body enters are the ones its junctions and its presented counts determine, tick by tick, under T. What a population-level account owes is therefore not a probability for the draw but the flow counts of §5 — how many bodies enter each encounter kind per tick — and those are counted, not postulated.

### 1.3 The third anchor: Paper 9 commissioned this paper first

The debts of §1.1–1.2 were recorded in 2026, against a critique. The commission itself is older. Paper 9 — *Heat as Interaction Event* — built the mechanical root of the thermodynamic arrow and then stopped at exactly the border this paper occupies. Its §5 passage on the asymmetry of occasion states why heat flows from hot to cold:

> Heat therefore flows spontaneously from hot to cold not because of an abstract statistical probability imposed from outside, but because disordered creation geometry is the mechanical default of an unguided collision, while ordered resolution is the rare, prepared exception.

and closes by naming the venue for everything past that border:

> The full statistical aggregation of these asymmetric occasions — alongside the mechanical derivation of entropy and the thermodynamic arrow — is deferred as a locked coordinate and a declared boundary condition to Paper 12, constrained by this asymmetry of occasion.

[CITED — L2-P12] (Paper 9, §5; paper9.txt L409–428.)

Two things in this receipt govern the whole paper. **First**, the refusal is already there, in the commissioning text: "not because of an abstract statistical probability imposed from outside." §5's dissolution of the sampling-measure postulate is not this paper's innovation imposed on the series; it is obedience to the paper that commissioned it. A Paper 12 that postulated a measure would violate its own commission. **Second**, the asymmetry of occasion arrives as "a locked coordinate and a declared boundary condition" — Paper 9's words. This paper therefore receives it as a boundary condition [L2-P12]: cited, load-bearing where §9 says it is, and not re-derived here. Paper 11's lock says the same in one clause — statistical aggregation is Paper 12's territory "constrained by Paper 9's asymmetry of occasion" (§0.5) — and the constraint is accepted, not argued.

### 1.4 The export receipt: the role taxonomy is received, not re-derived

Paper 11's firewall (§16) is symmetric: Paper 11 built no ensembles, no temperature, no entropy — and Paper 12 builds no role taxonomy. What crosses the wall is one export, specified by Paper 11 itself:

> No many-body statistics — the role taxonomy is applied to individual configurations and their aspects. Paper 12 uses the taxonomy to determine which configurations count as resolvable bodies in the aggregated ledger.

[CITED — L1-P12] (Paper 11 v69, §16 firewall list.)

Receipt is acknowledged in the form the export specifies: in §2, a body is admitted to the aggregated ledger when the received taxonomy counts it as a resolvable body. The taxonomy's own proofs stay in Paper 11; nothing in this paper re-opens them, and nothing in this paper needs to — the census counts bodies once admitted, and admission is the export's whole content.

### 1.5 The roadmap sentence

Finally, the programme in one line. Paper 11.5's §1 roadmap, describing what its own capstone deliberately did not claim:

> The positive native-prediction program — the count→weight step, frequencies from combinatorics without an imported measure — awaits Paper 12; §11 does not claim to have built it.

[CITED — L4-P12]

"Without an imported measure" was the tell, present from the first statement of the programme. This paper executes the programme as written: §3 counts, §4 moves, §5 divides — and at no point imports the measure the sentence already refused.

### 1.6 The discharge plan

| Debt / commission | Source | Discharge | Shape |
|---|---|---|---|
| Capability as a relation | 11.5 §7.4 | §6 | Construction over Paper 11's encounter taxonomy |
| Counting rule (debt item 1) | 11.5 §11.6 | §3 | Construction — the census |
| Sampling-measure postulate (debt item 2) | 11.5 §11.6 | §5 | **Dissolution** — no postulate adopted; frequencies as census ratios; flow counts |
| Fill rules | 11.5 §§11.5–11.6 | §§4–5 | Dynamics + flow counts, not draws |
| Statistical aggregation of asymmetric occasions; entropy; the arrow | Paper 9 §5 | §§5, 8, 9 | Construction under a received boundary condition |
| Role taxonomy export | Paper 11 §16 | §2 | Receipt — received, not re-derived |

### Claim list — §1

- **Claim 1.1** — The capability debt is as quoted at §1.1; Paper 11.5 used the capability/actuality distinction without constructing it. **[CITED — L4-P12]** (Paper 11.5 v26 §7.4, scope note.)
- **Claim 1.2** — The count→weight debt is as quoted at §1.2, including its two named items and the fill rules. **[CITED — L4-P12]** (Paper 11.5 v26 §§11.5–11.6.)
- **Claim 1.3** — Paper 9 commissioned the statistical aggregation, the entropy derivation, and the arrow to Paper 12, constrained by the asymmetry of occasion as a declared boundary condition, and refused "an abstract statistical probability imposed from outside" as the arrow's mechanism. **[CITED — L2-P12]** (Paper 9 §5.)
- **Claim 1.4** — Paper 11's sole export to this paper is the role taxonomy, for determining which configurations count as resolvable bodies in the aggregated ledger. **[CITED — L1-P12]** (Paper 11 v69 §16.)
- **Claim 1.5** — Programme: this paper discharges item (2) of Claim 1.2 by dissolution rather than by construction — no sampling-measure postulate is adopted anywhere in Paper 12. **[LEVEL B]** — declared programme at this site; the result itself is stated and badged where it is proved (§5), and this claim is superseded by that badge there.

---

## 2 &nbsp; THE AGGREGATED LEDGER

### 2.1 Bodies: what is counted

A **body**, in this paper, is what Paper 11's bonded-aggregate definition already built and what Paper 11's export admits: a finite connected aggregate G = (V, E) over configurations of the 27-state inventory, its junctions completed bonding-mode junctions in Paper 11's sense — with a single configuration as the degenerate case (one node, no junctions). The role taxonomy, received under §1.4, determines which configurations count as resolvable bodies in the aggregated ledger; this paper applies that determination and does not re-derive it. A body's description at any tick is entirely in Paper 11's licensed terms (§2.3): how many nodes it has, which junctions are established and at what arity, how many boundary ports stand open, what workload and unmatched counts its records carry.

Nothing in that paragraph is a new definition of a body. It is a receipt: Paper 12 counts what Paper 11 admitted, in the data Paper 11 licensed. The new definitions of this paper begin with the grouping, not the member.

### 2.2 Population: a grouping of relations, not a container

**Definition (population).** A **population** is a finite family of bodies, together with (i) the established junctions among them — junctions of exactly the kind Paper 11 defines, each a relation between the bodies it joins, consuming the ports it consumes — and (ii) a declared tick window: a finite, stated set of consecutive ticks over which the population is counted. A population is written as its membership list, its junction list, and its window. [Definition — this paper's; badge at Claim 2.2.]

Three properties of the definition matter, because each refuses a picture the standard theory takes for granted.

**A population is not a container.** There is no box, no boundary-as-object, no inside that bodies are *in*. Membership is a list, not a location. A body belongs to a population because the population's declaration names it — the same body may be named by two populations counted for different purposes, exactly as the same junction may be read from either of its bodies. The relations are the physics; the grouping is bookkeeping for counting, and the paper never confuses the two.

**A population is not a system-plus-environment.** No member is designated the observed part and no remainder is designated the bath. Inter-body junctions relate members symmetrically, and the census of §3 counts every member by the same rule. Where a later section needs a distinguished sub-family (a region, in Paper 9's sense), it declares the sub-family as a sub-population and counts it by the same rule — the distinction is a declaration, not an ontology.

**A population carries its window.** Counts are always *at a tick* or *over a window*, and the window is part of the population's declaration, stated wherever the population is stated. A frequency quoted without its window is not a claim of this paper; §5's ratios are meaningless without the denominator's ticks, and the paper prints them together.

### 2.3 The licensed data: Paper 11's list, whole and closed

What may be computed about a body — and therefore about a population, member by member — is fixed by Paper 11, and Paper 12 adds nothing to the list at Stage N. Paper 11 §4.1, verbatim:

> **The distinction between simple and complex is a distinction of enumeration depth, not a distinction of law.** The same 27-state inventory, six-port topology, Per-Triangle Rule, and Circa budget apply to one configuration and to any finite bonded aggregate. No aggregate-level quantity may be introduced unless it is defined as an exact finite sum, count, or rational ratio over constituent configuration states and completed junctions — N_nodes(G), N_edges(G), the boundary count B = 6N − Σ_j k_j (pairwise corollary B = 6N − 2J), the workload Σs², the unmatched count Σu. No aggregate state alphabet. No aggregate budget rule. No emergence mechanism. (Audit rule R15, Appendix H; machine check F.41.)

[CITED — L1-P12]

**Inheritance:** Source: Paper 11 v69 §4.1 (rule R15, Appendix H) — badge carried at source: [LEVEL A] — validation: the source's registry row for the single-regime claim (claim 41; machine check F.41) — Paper 12 reliance: the licensed list above is the complete input alphabet of the census (§3) and of every aggregate quantity in this paper.

Read the list as a closed alphabet. A body's ledger record may carry: its node count N, its edge/junction data (the junctions and their arities k_j, whence Σ_j k_j), its boundary count B, its workload sum Σs², its unmatched sum Σu. Every quantity in §§3–9 is built from these by exact finite sums, counts, and rational ratios over a population — the three operations R15 licenses — and the claim lists mark any construction that reaches for a fourth operation. There is no aggregate state alphabet: a population has no state of its own over and above its members' records. There is no aggregate budget rule: budgets bind per configuration (Paper 8's Circa budget; Paper 9's orthogonal sum rule v² + s² = c² over it; Paper 10 §2.2's contact partition, eq. 2.4 — received per member, §2.4), and a population's budget figures are sums over members or they are nothing. There is no emergence mechanism: §7's temperature and §8's count are sums and counts, and if a bulk quantity in this paper ever cannot be exhibited as one, its claim list entry will say so instead of naming a mechanism.

### 2.4 SINGLE_REGIME as this paper's constitution

The rule just quoted is Paper 11's claim 41, the single-regime rule, and it is this paper's constitution in the literal sense: the document every later section is checked against. Its content for Paper 12 is one sentence: **aggregation changes the size of the count, never the kind of the quantity.** The census of a population of six bodies and the record of a single configuration are the same kind of object — exact data in the licensed alphabet — differing in how many members were counted. There is no level at which the description changes character, no threshold of body-count at which sums become statistics in the standard sense, no point where the ledger hands over to an averaging procedure. Standard statistical mechanics is built at exactly that hand-over point; this paper's claim, executed section by section, is that the hand-over is unnecessary — the sums go all the way up.

The budgets make the same point concretely, and their attributions matter, so they are stated with care. Per configuration, the budget rule is Paper 8's Circa budget under the orthogonal sum rule Paper 9 states: v² + s² = c² — translation and scan as orthogonal draws on one conserved ceiling [CITED — L2-P12] (Paper 9 §§1, 5, 8). At a contact tick, the partition of the fixed hardware budget is Paper 10 §2.2's arithmetic: N_total = N_id + v²_contact + s² + N_reconcile = 100 CU (eq. 2.4), with N_reconcile the reconcile work of Paper 9 §8.1 [CITED — L3-P12]. Both rules bind members. A population's totals — total workload, total reconcile count over a window — are finite sums of member values under R15, and §7's temperature is a ratio of two such sums. At no point does a population acquire a budget of its own, a capacity of its own, or a temperature of its own in any sense stronger than the counted ratio. That restraint is not a limitation of the paper; it is the paper.

### Claim list — §2

- **Claim 2.1** — The single-regime rule and the licensed aggregate list of Paper 11 §4.1 (quoted at §2.3) govern every aggregate quantity in this paper. **[LEVEL A]** — inherited. **Inheritance:** Paper 11 v69 §4.1 / claim 41 / R15 — badge at source [LEVEL A], machine check F.41 — reliance: constitution of §§3–9. Dependencies: [L1-P12].
- **Claim 2.2** — "Population" is defined as at §2.2: a finite family of bodies, their established inter-body junctions, and a declared tick window; membership is a declaration, not a containment. **[LEVEL A: AUTHOR]** — this paper's declared definition. Falsifier: a use of "population" in this paper that requires containment, an environment split, or an undeclared window is a defect against this definition. Limit stated: the definition governs counting; it asserts nothing about which groupings are physically natural, and §7's regions are declared sub-populations under it, not consequences of it.
- **Claim 2.3** — Per-member budgets are received as cited at §2.4 (v² + s² = c², Paper 9; the 100 CU contact partition, Paper 10 §2.2 eq. 2.4); this paper introduces no aggregate budget rule, per R15. **[CITED — L2-P12, L3-P12]** for the budget rules; the "no aggregate budget rule" clause is **[LEVEL A]** by inheritance from Claim 2.1.

---

## 3 &nbsp; THE COUNTING RULE

This section pays debt item (1) of §1.2. What was owed was a rule that counts — stated exactly enough to be checked, counting only what stands. The rule has three parts: what a record is (§3.1), how records are classed (§3.2), and the census identities that make the counting auditable (§3.3). Worked counts follow (§§3.4–3.5), on the same aggregates Paper 11 used, so every number can be compared against its source.

### 3.1 The ledger record

At a tick τ, each body G in a population carries a **ledger record**: its data in the licensed alphabet of §2.3 —

- N(G): its node count;
- its junction data: the list of its established junctions with their arities k_j, and the consumed-port total Σ_j k_j;
- B(G) = 6N(G) − Σ_j k_j: its open boundary ports;
- Σs²(G): its workload sum at τ;
- Σu(G): its unmatched sum at τ.

The record is not a summary of the body. It is the body's data, in the only alphabet the framework licenses, at the tick named. A single configuration is its own record with N = 1. Nothing is averaged in a record, nothing is discarded from it, and no record is a sample of anything: it is the whole of what the ledger says about that body at that tick.

### 3.2 Count-classes

**Definition (count vector, count-class).** The **count vector** of a body G at tick τ is the tuple

v(G, τ) = ( N(G), (k_j multiset of G), B(G), Σs²(G, τ), Σu(G, τ) ),

with every component taken from the record of §3.1. Two bodies are in the same **count-class** at τ if and only if their count vectors agree in every component. A count-class is named by its vector.

The classes are relations among records, not kinds of bodies. A body changes class when the dynamics changes its record (a junction completes, a workload sum moves) — class membership is tick-indexed, like every role in this framework, and §4–§5 count exactly those changes. A class asserts nothing about a body's interior beyond what the vector's components say: two bodies in one class may differ in every datum the vector does not carry, and §6's capability theorem is careful to claim equality only where the vector is the whole of what an encounter can present.

### 3.3 The census and its three identities

**Definition (census).** The **census** of a population P at tick τ is the assignment, to each count-class represented in P at τ, of the number of bodies of P standing in that class at τ. The census over a window is the list of per-tick censuses, one per tick of the window.

The census is the counting rule's output, and it is auditable because of three identities. Each is finite arithmetic over the population's records; each is proved here, in line, because each is short enough that a proof sketch would be longer than the proof.

**(I) Exhaustion and exclusivity.** Every body of P stands in exactly one class at τ. *Proof.* Class membership is equality of count vectors (§3.2). Equality is reflexive, symmetric, and transitive, so "same vector" partitions any finite family of records into disjoint classes covering the family. ∎

**(II) The census sums to the population.** The class counts sum to |P|, the number of bodies in the population. *Proof.* By (I), the classes partition P; a finite partition's block sizes sum to the size of the partitioned set. ∎

**(III) Grouped totals equal direct totals.** For every component Q of the count vector, the population total of Q equals the sum over classes of (class count × the class's Q-value). *Proof.* The population total of Q is the finite sum of Q over bodies. Group the summands by class: within a class, every body has the same Q-value (that is what the class is), so the class contributes (number of its bodies) × (that value). Finite addition is insensitive to grouping. ∎

Identity (III) is the working tool of the paper. It says the census loses nothing: every licensed total of the population is recoverable from the census alone, exactly, by multiplication and addition. This is the precise sense in which §0.5's exclusion of the two-level frame costs nothing — there is no fine detail beneath the census that the census has thrown away, because the census is a partition of the records themselves, and (III) recovers every total the records support. Frequencies in §5 are ratios of census counts and flow counts; totals in §7 are (III)-sums. The counting rule is the whole foundation, and it is three lines of arithmetic.

### 3.4 Worked boundary counts: Paper 11's aggregates

The counting rule is first run on the bodies Paper 11 already built, so that the arithmetic can be checked against a published source at every step. In each case B is computed from the licensed formula B = 6N − Σ_j k_j (pairwise corollary B = 6N − 2J), with every input shown.

**Aggregate (a)** — three configurations converged centre-to-centre on one shared junction (Paper 11's documented construction; k_j = 3 at the shared junction):

N = 3, so 6N = 18. Junctions: one, of arity 3, so Σ_j k_j = 3.
B = 18 − 3 = **15**.

**Aggregate (b)** — two configurations (Paper 11's State-5/State-6 complementary pair) at one pairwise junction:

N = 2, so 6N = 12. Junctions: one, of arity 2, so Σ_j k_j = 2.
B = 12 − 2 = **10**.

**Aggregate (c)** — three configurations in a chain A—B—C, two pairwise junctions (the middle body in both):

N = 3, so 6N = 18. Junctions: two, each of arity 2, so Σ_j k_j = 2 + 2 = 4.
B = 18 − 4 = **14**.

The chain is the instructive case: the middle body's ports are consumed by two junctions, and a careless count double-counts them. The formula does not, because Σ_j k_j counts consumed ports junction by junction and Port-Partition Exactness (Paper 11 §4.3 [L1-P12]) guarantees each port is consumed at most once — the books close because the partition is exact, and 18 − 4 = 14 is the count Paper 11 records.

**Stress aggregate, R = 2** — the taxicab ball of radius 2 (a declared control at source, not a native aggregate — Paper 11's label, kept). Nodes counted by shells outward from the centre node: the centre contributes 1; the shell at relay distance d ≥ 1 contributes N(d) = 4d² + 2 nodes (Paper 10 §2.4.1 [L3-P12]):

N = 1 + N(1) + N(2) = 1 + 6 + 18 = **25**.

Junctions: one 2-port junction per taxicab-adjacent node pair; the adjacent pairs number J = 36 (machine-verified at source; recounted by direct enumeration of the 25 lattice points and their adjacent pairs for this paper). All junctions are pairwise, so Σ_j k_j = 2J = 72, and:

B = 6·25 − 72 = 150 − 72 = **78**.

**Stress aggregate, R = 3** — the same control at radius 3:

N = 1 + N(1) + N(2) + N(3) = 1 + 6 + 18 + 38 = **63**.
J = 114 (same provenance as R = 2), so Σ_j k_j = 2J = 228, and:
B = 6·63 − 228 = 378 − 228 = **150**.

| Body | N | Junctions (arities) | Σ_j k_j | 6N | B = 6N − Σ_j k_j |
|---|---|---|---|---|---|
| (a) | 3 | one (3) | 3 | 18 | 15 |
| (b) | 2 | one (2) | 2 | 12 | 10 |
| (c) | 3 | two (2, 2) | 4 | 18 | 14 |
| R = 2 ball | 25 | 36 × (2) | 72 | 150 | 78 |
| R = 3 ball | 63 | 114 × (2) | 228 | 378 | 150 |

Every entry is checkable by hand from the two inputs in its row. The machine companion (script A.1) recomputes the table from the constructions and checks the census identities of §3.3 on these bodies and on generated populations; the badges below say exactly which part is whose.

### 3.5 A worked census

Let P₀ be a declared test population — six bodies: two of aggregate (a)'s class, three of class (b), one of class (c), counted at a tick at which each body stands as Paper 11 constructed it (records as in §3.4, on the components (N, junction arities, B); the (Σs², Σu) components are carried by the records and enter every identity componentwise, identically — no values for them are asserted in this example). P₀ is a bookkeeping exhibit: it shows the census arithmetic on bodies the reader can already check, and it claims nothing about any physical arrangement.

Census at the tick: class (a): 2 bodies; class (b): 3 bodies; class (c): 1 body.

Check of identity (II): 2 + 3 + 1 = 6 = |P₀|. ✓

Population totals by identity (III), grouping by class:

- Total nodes: 2·3 + 3·2 + 1·3 = 6 + 6 + 3 = **15**.
- Total boundary ports: 2·15 + 3·10 + 1·14 = 30 + 30 + 14 = **74**.

Cross-check by the direct route, no classes used: total ports over the population = 6 per node × 15 nodes = 90. Total consumed ports = Σ over bodies of Σ_j k_j = 2·3 + 3·2 + 1·4 = 6 + 6 + 4 = 16. Boundary ports = 90 − 16 = **74**. The two routes agree — as (III) requires, and as the reader can verify with nothing but the table of §3.4 and the multiplication above. That agreement, on every component, for every population, is the counting rule's entire guarantee: *the census is the records, organized; nothing added, nothing lost.*

### 3.6 What the counting rule is not

It is not a count of arrangements that did not occur. Every number in this section counts bodies standing in a population, junctions established among them, ports open on them. The number of distinct record-assignments *consistent with* a census is a different number, with a different job — it appears once, at §8, inside the Stage P bridge's native operand, and it is never used in this paper as a frequency, a weight, or a likelihood. One qualification to "appears once" is owed, and it is stated here rather than left for a later section to surprise the reader with: the assignment count Ω appears a second time, at §9 — as a definitional comparison only, in the (E2) maximality clause of the equilibrium construction, where candidate records are ranked by Ω inside the definition of the equilibrium predicate. A ranking inside a definition; still never a frequency, a weight, or a likelihood over occurrences. Confusing the census (what stands) with an arrangement count (what could be written) is the exact confusion the excluded frame runs on; §3 exists so that Paper 12 never has to.

### Claim list — §3

- **Claim 3.1** — The census of a population at a tick satisfies identities (I), (II), and (III) of §3.3 for every finite population and every tick. **[LEVEL A]** — prose-proved in line at §3.3 (finite partition arithmetic, no gaps); machine companion: script A.1. Dependencies: [L6-P12] (definitions §§3.1–3.3), [L1-P12] (licensed alphabet).
- **Claim 3.2** — The boundary counts of §3.4 are B = 15, 10, 14 for aggregates (a), (b), (c) and B = 78, 150 for the R = 2, R = 3 taxicab controls, by the arithmetic shown. **[LEVEL A]** — inputs **[CITED — L1-P12]** (constructions and B-values at source, Paper 11 §§7–8; shell counts **[CITED — L3-P12]**, Paper 10 §2.4.1); arithmetic shown in line; machine companion: script A.1.
- **Claim 3.3** — For the declared test population P₀ of §3.5, the census is (2, 3, 1) over classes (a), (b), (c), with population totals 15 nodes and 74 boundary ports by both the grouped and direct routes. **[LEVEL A]** — finite arithmetic shown in line; P₀ is a declared exhibit, and the claim covers the arithmetic, not any physical arrangement.
- **Claim 3.4** — Debt item (1) of §1.2 is discharged: the counting rule of §§3.1–3.3 is a stated, checkable procedure counting actual ledger records class by class. **[LEVEL A: MACHINE / AUTHOR]** — MACHINE: the rule's identities and worked counts (script A.1). AUTHOR: the identification of this rule as the discharge of 11.5's "(1) a microstate-counting rule," under the corrected name of §0.5 — the debt's substance is the counting; the locked word in its phrasing is not carried into the construction.
