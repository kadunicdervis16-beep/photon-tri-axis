# Paper 12 — DRAFT D: §§10–13 and Appendices skeleton
## Staging v1 · sections drafted under the CORRECTED frame (architecture, CORRECTION section, 2026-10-24)

Frame discipline observed throughout this draft: no micro/macro two-level picture; no ensemble, no possibility-space, no probability measure or postulate anywhere; every frequency is a census ratio of actual counts over a declared window; every forward claim is the deterministic dynamics enumerated over a declared population. Thermo vocabulary appears only inside a native construction or inside a section's single declared bridge sentence. Labels are L\<section\>.\<n\>-P12; harmonisation with the §§1–9 drafts' label sequence is a v1 assembly task.

Symbols used below are as established in §§2–9 of this paper (population census, count-classes, the aggregate tick, flow counts, the reconcile census) and in the home papers listed in Appendix A.

---

## 10. Collective modes: the periodic substrate, honestly scoped

Paper 11's §16 firewall assigns collective modes to this paper and forbids them to Paper 11. This section discharges the substrate of that assignment and states, in the paper's own text, exactly how much of the standard collective-mode programme it does **not** yet discharge. The scoping is part of the result, not an apology appended to it.

### 10.1 What the aggregate tick gives for free

§4 defines the aggregate tick: the transition operator T of Paper 11 §7.5 applied once at every established junction of the aggregated ledger, well-defined because junction port-sets are disjoint (Port-Partition Exactness, Paper 11 §4.3) and T's fixed point is order-independent. Write the aggregate tick as **T_agg**, a function from ledger records to ledger records.

The record set of a finite population is finite. A ledger record of a population of N bodies is a finite tuple of finite data — node states over the 27-state inventory, per-junction local states σ, census data — so the number of distinct records a declared finite population can stand in is a finite integer, computable from the population's constitution (§3's counting rule counts actual records; the finiteness used here is the finiteness of that same enumeration, not a space of unrealised possibilities).

**Claim L10.1-P12 [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)].** *Every aggregate trajectory of a finite population under T_agg is eventually periodic: there exist integers p ≥ 0 (the pre-period) and c ≥ 1 (the cycle length) such that the record at tick t + c equals the record at tick t for all t ≥ p. The pair (p, c) is an exact count, computable by enumeration of the trajectory.*
Ground: T_agg is a total deterministic function on a finite set; iterating a function on a finite set revisits a record within (number of records + 1) steps, and determinism then forces the trajectory onto the cycle through that record forever. The decomposition of a trajectory into a pre-period (the transient segment) and a cycle is therefore not a model or an approximation; it is arithmetic on the trajectory the dynamics actually produces. Verified by A.3 (orbit/census counts: enumeration of trajectories on test populations, exact pre-period and cycle lengths against independent re-enumeration).

**Claim L10.2-P12 [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)].** *The eventual-periodicity decomposition is a census statement: for a declared population and a declared window, the number of records standing on cycles, the number standing on pre-periods, and the distribution of cycle lengths are exact integer counts, and the frequency with which a cycling trajectory visits each record of its cycle is the exact rational 1/c per record per cycle. For closed populations the eventual cycle is a fixed point, c = 1, per §10.1's clarification; c > 1 frequencies concern open populations under re-presentation.*
Ground: §5's dissolution applies verbatim. No weight is assigned to any record; a cycling trajectory *actually visits* each record of its cycle once per c ticks, so the visit frequency is a ratio of actual counts over an actual window — counted, not postulated. Verified by A.3 (cycle-visit frequencies as exact Fractions, checked against brute-force trajectory iteration by an independent functional-graph decomposition).

### 10.2 The native name for population-level recurrence

A population whose aggregate trajectory has entered a cycle exhibits **population-level recurrence**: the whole census — every count-class population, every boundary total — returns exactly, tick for tick, with period c. This recurrence is the native substrate on which any collective-mode talk in this framework must be built, for a structural reason: a collective mode, in any theory, is a pattern that belongs to the population as a whole and persists in time. In the ledger there is no population-level object other than the census and its trajectory; a persisting population-level pattern is therefore, natively, a periodic aggregate trajectory or a periodic feature of one (a count-class population, a boundary total, or a flow count that is periodic in t with a period dividing c).

**Claim L10.3-P12 [LEVEL A: AUTHOR].** *Every population-level periodic phenomenon statable in the aggregated ledger is a periodic feature of an aggregate trajectory under T_agg in the sense of L10.1-P12: there are no population-level periodic phenomena in the ledger that are not features of trajectories, because the ledger contains no population-level data other than records and their tick-successors.*
This is a completeness claim about the ledger's own contents, of the same species as Paper 11's single-regime claim: it follows from the definition of the aggregated ledger (§2) plus L10.1-P12, and it is falsifiable in the ledger's own terms (C27, §12).

### 10.3 What is NOT claimed — the deferral, with its reasons

Three pieces of the standard collective-mode programme are **not** delivered in this paper, and the paper says so here rather than letting the section title imply them.

**(a) No mode spectrum.** Standard theory decomposes a population's motion into modes indexed by a wavevector, each with a frequency. The ledger delivers periods of whole trajectories (L10.1-P12) and periodic features of them (§10.2); it does not deliver a decomposition of a trajectory into independently superposable modes, and no such decomposition is asserted. A spectrum is a basis; the ledger has trajectories, not bases. Whether a native analogue of modal decomposition exists — for instance, a factorisation of T_agg over weakly coupled sub-populations whose cycles combine — is an open question, recorded here as unproved in either direction.

**(b) No dispersion relation.** A dispersion relation ties a mode's frequency to a spatial period. Both of its ingredients are outside this paper's licence: frequency in physical time requires assigning durations to ticks, which is Stage P work via Paper 2's t₀ and is formalised in Paper 13's time formalism, which this paper cites but does not build; and spatial period requires a metric embedding of the population, which the L3 relay structure of Paper 10 supplies only at the encounter level, not as a population geometry. A dispersion relation stated here would be a bridge with no native pier on either side.

**(c) "Phonon" is not reconstructed here.** In standard theory the phonon is the quantum of a collective mode — a carried, countable excitation. Nothing in §§10.1–10.2 is a carried object: a cycle is a property of a trajectory, not a thing a body holds, exactly as capability in §6 is a relation and not a possession. The word "phonon" therefore names, at this point in the series, a standard-theory counterpart that this section does **not** reconstruct; it appears in this paper only in this scope note and in the construction list of §0.5, marked *not admitted natively; Stage P counterpart not yet built*. If a later paper builds the Stage P reconstruction of mode quanta, it will build it on L10.1-P12's substrate and say so; this paper neither promises nor pre-builds it.

**Claim L10.4-P12 [LEVEL A: AUTHOR — scope claim].** *The claims of §10 are exactly L10.1-P12, L10.2-P12, and L10.3-P12. No claim in this paper asserts a mode spectrum, a dispersion relation, modal superposition, or a native or reconstructed phonon.*

### 10.4 Claim list — §10

- **L10.1-P12 [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)]** — Eventual periodicity of aggregate trajectories on finite populations; pre-period/cycle decomposition as exact counting. (A.3)
- **L10.2-P12 [LEVEL A: MACHINE — script A.3, conditional on A.2 (well-definedness of T_agg)]** — Cycle/pre-period census counts are exact integers; per-cycle visit frequencies are exact rationals 1/c; the open-population case is conditioned at §10.1's clarification. (A.3)
- **L10.3-P12 [LEVEL A: AUTHOR]** — Completeness: every ledger-statable population-level periodic phenomenon is a periodic feature of an aggregate trajectory. (§2 + L10.1-P12)
- **L10.4-P12 [LEVEL A: AUTHOR — scope]** — §10 asserts no spectrum, no dispersion relation, no superposition, no phonon.

---

## 11. The ordering extension: molecules and macro-matter, graded

Paper 11 §12.2 assigns this paper the extension of the complexity ordering beyond atoms — to molecules and to macro-matter. Paper 11's own ordering (§12.1) is a theorem over its domain: simple states and bonded atomic configurations, ordered by records the paper itself supplies. An assignment is **scope permission**: Paper 11 names molecules and macro-matter as inside Paper 12's territory. Scope permission is not **derivation permission**: a derivation needs native sentences that supply, for the new domain, the records the ordering is computed from. This section grades the two permissions separately for each target, per the standing discipline, and enacts nothing that the grading does not license.

### 11.1 The obstacle, stated once

Paper 11's Bonded Aggregate is defined over the 27-state inventory: an aggregate is a finite connected graph G = (V, E) whose vertex set V is drawn from the inventory of simple states, joined by completed Paper 2 bonding-mode junctions. Atoms — the ordering's current top domain — are themselves complex configurations: bonded aggregates, not inventory members. A **molecule**, in the usage Paper 11 §12.2 gestures at, is a bonded aggregate *of atoms*. But atoms are not members of the 27-state inventory, so a graph whose vertices are atoms does not satisfy the Bonded Aggregate definition as written: its vertex set is pinned to the inventory, and the definition does not quantify over configurations. The §12.2 gesture and the §4 definition do not, as they stand, compose. This is the known conflict recorded in the V19 analysis of Paper 11, and it is a defect of fit between two of Paper 11's own sentences — Paper 12 cannot repair it by silence, because any molecule-ordering it published would silently presuppose one side of the conflict.

### 11.2 Target (i): molecules as bonded aggregates of atoms

**Scope permission: PRESENT.** Paper 11 §12.2 names molecules as Paper 12's assignment; the battle plan's boundary (Paper 12 = many-body statistics) covers them.

**Derivation permission: ABSENT, on two independent grounds.**

*Ground 1 — the vertex-domain conflict (§11.1).* The ordering key for bonded aggregates in Paper 11 is computed from records — node counts, Σs², boundary B = 6N − Σk_j — whose definitions quantify over inventory vertices. For a graph of atoms, N, Σs², and B are not defined by any native sentence: is an atom one "node" for the molecule's B, or does the molecule's boundary count run over the atoms' constituent inventory nodes through the inter-atom junctions? Both readings are constructible; they give different keys; no native sentence chooses between them. Choosing one would be a definition, and definitions are the author's.

*Ground 2 — no composition record.* Paper 11's ordering between adjacent complexity classes rests, at each step, on a native sentence of composition form (the higher record is the lower record plus a stated increment). No native sentence anywhere in Papers 1–11 states what a molecule is composed of in ledger terms — "atoms, plus X" with X a ledger quantity — because the molecule concept enters the corpus only in §12.2's assignment gesture. An ordering derived without a composition record would have its increments supplied by this paper, i.e. invented, however honestly labelled.

**Verdict L11.1-P12 [LEVEL A: AUTHOR].** *The complexity ordering does not extend to molecules in this paper. The extension is blocked by the vertex-domain conflict in Paper 11's Bonded Aggregate definition and by the absence of any native composition record for molecules. Both blocks are stated here as findings about the corpus, not as limitations of effort.*

**OPEN RULING OR-1 (author's word required).** A native definition of *molecule* that resolves the vertex-domain conflict — e.g. a two-level graph definition in which a molecule's vertices are atoms and its boundary and census keys are defined by an explicit reduction to the atoms' constituent inventory records, or an amendment of the Bonded Aggregate definition's vertex domain. Either form is a definitional act in Paper 11's ontology. **Not enacted in this paper.** Until the author rules, every occurrence of "molecule" in Paper 12 is confined to this section and to §12's falsification conditions, as the name of an unbuilt extension.

### 11.3 Target (ii): macro-matter populations

Macro-matter — populations of bodies large enough that the paper's subject is the population rather than any body — grades differently, because the census and flow machinery of §§3–5 was built over *populations of bodies* from the start, and a body's admission (§2) runs through the received role-taxonomy export, not through any size bound.

**Scope permission: PRESENT.** Paper 11 §12.2; §16 firewall (Paper 12's territory is the aggregated ledger).

**Derivation permission: PRESENT where the machinery's own inputs exist; ABSENT at three named edges.**

*Where it extends by construction.* The census (§3) partitions an actual population into count-classes; nothing in its construction bounds N, the number of bodies, or the size of a body — a body enters the census through its presented count data and its boundary, whatever its internal constitution. The aggregate tick (§4) applies T at every established junction; Port-Partition disjointness is a per-junction fact and does not degrade with population size. Flow counts (§5) are per-tick integer counts over the population. Aggregate τ (§4) is a sum over junctions. The reconcile census and the population temperature of §7 are ratios of these counts. Every one of these quantities is therefore defined for a macro-matter population by the same sentences that define it for a three-body population — SINGLE_REGIME operating exactly as designed: the lone node, the aggregate, and the population under one rule set, differing in counts, not in kind.

**Claim L11.2-P12 [LEVEL A: MACHINE].** *The census, aggregate-tick, flow-count, aggregate-τ, and reconcile-census constructions of §§3–5 and §7 are size-invariant: for every test population in the A-series batteries, from two bodies to the largest enumerated stress populations, each construction is computed by the same definitions, with the identities checked across population sizes 1–12 (A.1, A.2, A.6), with no size-triggered branch in any construction.*
This is the machine form of the single-regime claim at population scale, and it is stated as a claim about the constructions and their implementations — the honest domain of a machine badge — not as a metaphysical claim about matter.

*Where it bottoms out — three edges, stated plainly.*

**Edge 1 — enumeration horizon.** The machine checks are enumerations, and enumeration is finite: A-series batteries verify the constructions on populations up to stated sizes, and the analytic content (the identities are sums and ratios whose proofs do not case on N) carries them beyond the enumerated range as AUTHOR-level argument. Paper 12 does not claim machine verification at astronomical N; it claims machine verification on the enumerated range plus proofs whose steps never invoke N's size. A reader who wants the boundary has it exactly here.

**Edge 2 — the admission of very large bodies.** §2 admits a body via the role-taxonomy export: a configuration counts as a resolvable body if the taxonomy resolves it as one. The taxonomy was built at configuration scale. Whether every macro-matter constituent a Stage P physicist would point at is resolvable as a body by the received taxonomy is a question about the export's coverage, not about §§3–5 — and the §16 firewall forbids this paper to extend the taxonomy. Populations containing unresolvable constituents are outside the aggregated ledger until the taxonomy speaks; the ledger does not silently absorb them.

**Edge 3 — packing is not statistics.** At high density, which junctions exist at all becomes a geometric question. That question is Paper 16's (high-density aggregate packing), and this paper's census presupposes a declared junction graph: it counts the population it is given. Population claims in §§7–9 are therefore conditional on the declared graph in the same way §10's trajectories are conditional on the declared population. (See §13, export to Paper 16.)

**Verdict L11.3-P12 [LEVEL A: AUTHOR].** *The §§3–5/§7 machinery extends to macro-matter populations by its own construction, size-invariantly, subject to Edges 1–3. The complexity ORDERING, as distinct from the machinery, extends to macro-matter populations only as far as the populations consist of bodies whose individual ordering records exist — atoms and admitted bodies — and no further: a population does not acquire an ordering key from its census, because the census is a partition into count-classes, not a rank.*

**OPEN RULING OR-2 (author's word required).** Whether a *population-level* ordering key (an ordering of populations themselves, as distinct from orderings of their members) is wanted at all. This paper defines none; the census deliberately does not rank. If the author wants one, its definition is a ruling, not a derivation. **Not enacted.**

### 11.4 Claim list — §11

- **L11.1-P12 [LEVEL A: AUTHOR]** — Molecules: scope permission present, derivation permission absent (vertex-domain conflict + no composition record). Extension not enacted. (OR-1)
- **L11.2-P12 [LEVEL A: MACHINE]** — Size-invariance of the §§3–5/§7 constructions across the enumerated population range, same definitions, identities checked across population sizes 1–12, no size branch. (A.1, A.2, A.6)
- **L11.3-P12 [LEVEL A: AUTHOR]** — Macro-matter extension verdict, subject to Edges 1–3; census confers no ordering key on populations. (OR-2)

---

## 12. Falsification conditions

The series' falsification numbering is continuous across papers (Paper 11's registry). Paper 11 closed at conditions C19–C22. Paper 12's conditions therefore open at **C23**. Each condition names the claim at risk, the observation or computation that would kill it, and the label it hangs on. A condition is stated so that it can, in principle, be met; a condition nothing could meet would be decoration.

**C23 — The aggregate tick is not well-defined.** *Claim at risk:* §4's aggregate tick (parallel application of T at all established junctions) and every construction downstream of it (§§5, 7, 10). *Killer:* an exhibited aggregate — finite bodies, established junctions, all data native — in which two junctions' port-sets are not disjoint, or in which applying T at the junctions in two different orders yields different successor records. Either exhibit breaks Port-Partition Exactness's use here or T's order-independence, and the aggregate tick falls. *Hangs on:* §4's well-definedness theorem; checked by A.2.

**C24 — The census miscounts.** *Claim at risk:* §3's counting rule — the census partitions an actual population into count-classes with exact integer counts. *Killer:* a population, small enough for hand enumeration, whose census output under A.1 disagrees with the hand count of its actual records — a body counted twice, a body uncounted, or a count-class boundary that two of the paper's own definitions draw differently. *Hangs on:* §3's counting rule; checked by A.1 (dual oracle: closed form against brute enumeration).

**C25 — Frequencies that no census or flow count can express (the §5 dissolution condition).** *Claim at risk:* §5's central result — that the count→weight debt of Paper 11.5 §11.6 is discharged by dissolution: every frequency statable about the aggregated ledger is a census ratio of actual counts over a declared window, or a flow count of the deterministic dynamics over a declared population, and no sampling measure or probability postulate is needed or used. *Killer:* a demonstrated frequency in the aggregated ledger — arising from the ledger's own dynamics and records, stated in native terms — that provably cannot be expressed as any such census ratio or flow count: for instance, a long-run visit frequency along aggregate trajectories that disagrees with the exact rational the trajectory enumeration yields (L10.2-P12's 1/c structure), or a per-tick transition share that no integer flow count over any declared window reproduces. One such exhibit reopens the debt and shows the postulate 11.5 expected was necessary after all. *Hangs on:* §5 entire; supported by A.3. *This is the condition the paper most invites: §5 is its centre, and §5 is where it can die.*

**C26 — Capability is carried after all.** *Claim at risk:* §6's account of capability as a relation over Paper 11's encounter taxonomy — two bodies with equal presented-count profiles have equal capabilities at a tick; capability is structural, never a possession. *Killer:* two bodies presenting equal count profiles (identical M = (n+, n−)) in an encounter kind, at the same tick, that nevertheless occupy different roles in that encounter kind — one standing in a role the other cannot stand in — with the difference traceable to no encounter-side or tick-side data. Such a pair exhibits a capability component that travels with the body beyond its presented counts: carried, not structural. *Hangs on:* §6's profile theorem (L6-series); checked by A.4, including its interior-independence probes on Paper 11's aggregates (a) B = 15, (b) B = 10, (c) B = 14.

**C27 — A population-level periodic phenomenon outside the trajectories.** *Claim at risk:* L10.3-P12's completeness claim. *Killer:* a population-level periodic phenomenon, statable in the aggregated ledger's own data, that is not a periodic feature of any aggregate trajectory under T_agg — periodic behaviour in some population-level quantity that the trajectory decomposition (pre-period + cycle, L10.1-P12) cannot account for. *Hangs on:* L10.1-P12, L10.3-P12; supported by A.3.

**C28 — The population temperature is not Paper 9's temperature.** *Claim at risk:* §7's construction — population temperature as aggregate reconcile density, bridging to Paper 9's T_ledger = N_reconcile/N_ticks. *Killer:* an exhibited population and window in which the §7 construction and Paper 9's own accounting of the same events disagree — the same reconcile events counted by Paper 9's contact budget yielding a different density than §7's census of the same window — or a population in which §7's quantity depends on a choice (window placement, class boundary) that Paper 9's accounting does not make, so that the "same" temperature takes two values for one physical situation. *Hangs on:* §7's construction and its bridge sentence; checked by A.6 and G.1.

**C29 — The arrow runs backwards.** *Claim at risk:* §8's actual claims — the finite counting facts of §§8.2–8.3 (the assignment counts (8.1)–(8.2), the ratio (8.3), the bounds (8.4)–(8.7)) and the assembled arrow exactly as scoped in §8.6: assembled from τ-monotonicity (§4), the exact counting, and Paper 9 §5's asymmetry of occasion as an inherited boundary condition. Assignment counts are not frequencies, and §8 claims no trajectory-concentration: no result in this paper shows aggregate trajectories drifting toward high-Ω records (the open joint named in §§8.6 and 9.6). *Killer:* an exhibited error in the counting — a census record whose assignment count disagrees with hand enumeration of the actual bodies, or one of (8.3)–(8.7) failing at some finite n; or a ledger frequency, arising from the ledger's own records over a declared window, that the counting of §8 cannot express. *Hangs on:* §8's counting and §4's τ-accounting; checked by A.5 and A.2.

**C30 — A regime change with no saturation-census change.** *Claim at risk:* §9's regime-change construction in its own terms: under §9.4's construction, a regime change occurs exactly at ticks where the saturation census J_sat changes value, with per-junction capacity taken as input from Paper 10 eq. (2.4). §9 does NOT identify that capacity with Paper 7's Junction Saturation Threshold point, whose exact location remains Paper 14's locked debt and is not tested here. *Killer:* an exhibited population trajectory in which J_sat changes at a tick that §9.4's construction does not mark as a regime change, or a tick §9.4 marks as a regime change at which J_sat does not change. Either direction severs the construction from its own census. *Hangs on:* §9's construction; checked by A.6. (A dispute over the exact location of Paper 7's JST point is not a killer of this condition; see §13.)

### 12.1 Claim list — §12

- **L12.1-P12 [LEVEL A: AUTHOR]** — Conditions C23–C30 are the complete falsification surface of Paper 12's Level A claims: each construction of §§3–10 is the named target of at least one condition, as named in each condition's own text. (H.1)
- **L12.2-P12 [LEVEL A: AUTHOR]** — No condition above appeals to a continuum quantity, an ensemble, or a probability: each killer is an exhibit (a finite aggregate, a trajectory segment, a count disagreement) producible inside the ledger's own terms.

---

## 13. Bridge ledger

This section is the paper's customs house. Everything Paper 12 takes from another paper is declared as received, with its home label; everything Paper 12 hands forward is declared as an export, with its scope; and the two debts this paper exists to pay are receipted here, at the point of discharge. Bridge sentences elsewhere in the paper (one per admitted thermo word, §0.5 construction list) are governed by the same discipline: one sentence, declared, at Stage P — never a native premise.

### 13.1 Exports forward

**To Paper 13 (time formalism).** Paper 12 exports the **aggregate trajectory as an a_k-serialisable sequence**: an aggregate trajectory (L10.1-P12) is a sequence of ledger records indexed by tick count, and tick indices are a_k-ordered ledger entries in Paper 2's sense, so the trajectory is already a serialisable sequence of the kind Paper 13's time formalism (the 720° ledger) receives and formalises. What is exported is the sequence and its exact period data (p, c). What is **not** exported and **not** built here: any assignment of duration to a tick, any physical-time frequency, any part of the 720° formalism. Paper 12 cites ticks; Paper 13 owns time. The export is deliberately thin: a sequence, handed over.

**To Paper 14 (threshold and expansion).** Paper 12 exports **population flow data at saturation-census changes (§9.4)**: for declared populations, the per-tick flow counts and aggregate load values in windows bracketing a saturation-census change (§9.4), as exact integer and rational data. Paper 14 receives population-scale load behaviour around such changes. What is **not** touched: the threshold's exact point. Paper 11's lock stands unamended — for a junction of degree k, the exact point in 0 < TH < k is **Paper 14's locked debt**, and nothing in Paper 12 computes, bounds, approximates, or conjectures it; §9's constructions take saturation-census changes (§9.4) as events in a trajectory, computed from the capacity input of Paper 10 eq. (2.4), not from any threshold point of Paper 7's. Cosmic expansion is likewise Paper 14's and is not addressed.

**To Paper 16 (packing).** Paper 12 exports **census class data for aggregate types**: the count-class partitions (§3) of declared populations, and the class-level flow counts (§5), as data about what kinds of aggregates a population contains and how their numbers move. Paper 16 receives population composition data for its packing constructions. What is **not** touched: packing itself — which junctions form at high density, the geometry of dense aggregates, and the baryon/meson structural mapping are Paper 16's, and Paper 12's census presupposes a declared junction graph (§11, Edge 3) precisely so as not to trespass.

### 13.2 Discharge receipts backward

**Receipt 1 — Paper 11.5 §7.4 (capability).** Debt, verbatim in substance: "the formal account of capability as a relation to possible encounters — what makes a capability structural rather than carried — is Paper 12's work. Nothing here certifies it; the distinction is used, not derived." **Discharged at §6 of this paper**, under the corrected frame: encounters are the finite encounter taxonomy of Paper 11 (actual encounter kinds, specified by presented-count profiles), and capability is defined as a relation over that taxonomy and the tick — Cap(G, role) as the set of taxonomy encounters and ticks at which G plays the role — with the profile theorem (equal presented-count profiles ⇒ equal capabilities) machine-checked by A.4 on Paper 11's own aggregates. The word "possible" in the debt's phrasing is receipted as the taxonomy's kinds, not a possibility-space; §6 states this reading explicitly, so the receipt does not quietly change the debt's terms. Mechanism caveat: A.4 verifies the factorization mechanism at the strength of its cited premise (Paper 11 §8.6, cited not re-proved): capability computed from presented data alone cannot consult interiors, and the carried-capability mutant is caught with a witness.

**Receipt 2 — Paper 11.5 §11.6 (count→weight).** Debt, verbatim in substance: the count→weight step "needs two things this paper does not build: (1) a microstate-counting rule, and (2) a sampling-measure postulate. Both are Paper 12's work," together with the fill rules ("which encounter actualizes with what probability at a given tick"). **Discharged at §§3 and 5, by construction and by dissolution.** Item (1) is discharged at §3 as re-founded by the author's 2026-10-24 correction: a counting rule over actual ledger records — the census — not a count of unrealised states. Item (2) is discharged **by dissolution** at §5: the sampling-measure postulate is shown to be an artifact of the micro/macro frame the framework refuses; frequencies are census ratios of actual counts and flow counts of the deterministic dynamics (R3′: no probability postulate anywhere in this paper). The fill rules are receipted in the same place: which encounter actualises at a tick is read off the dynamics and the taxonomy (§§4–6); the frequency with which an encounter kind actualises over a window is a flow count. MC.1 of Paper 11.5 is retro-scoped by §5: its uniform sampling is a sampling device over a finite set inside a stress-test script, and §5 states this without upgrading it retroactively into a physical claim. The dissolution itself is falsifiable — that is C25, §12, and the paper flags C25 as the condition it most invites.

**Receipt 3 — Paper 11 §16 (role-taxonomy export).** Received at §2, **not re-derived**: the role taxonomy, exported by Paper 11 "to determine which configurations count as resolvable bodies in the aggregated ledger," is used in this paper exactly under that description and no other. Paper 12 derives no role, reclassifies no configuration, and extends no taxonomy (§11, Edge 2, records the cost of this discipline). The firewall is symmetric and this paper keeps its side.

**Receipt 4 — Paper 9's constructs (heat, reconcile accounting, T_ledger, asymmetry of occasion).** Received from Paper 9 (with Paper 10's budget identities where Paper 9's accounting cites them), and extended at population scale **only as licensed**: §7 aggregates the reconcile census over populations and windows — the same events, the same budget identities (checked by A.6, quoted-checked by G.1), counted over more bodies — and §8 takes the asymmetry of occasion as a stated boundary condition, named as received, not derived here. Nothing of Paper 9's is redefined; where §7's construction and Paper 9's text could be read to diverge, G.1's quote-integrity check governs and §7 follows Paper 9.

### 13.3 What this ledger does not contain

No export to Paper 15 is made and none is needed: this paper contains no beta-decay content and no neutrino content, under the standing absolute ban. No export to Paper 12's own later versions is implied: OPEN RULING items OR-1 and OR-2 (§11) are not exports but referrals to the author, and they travel with the paper until he rules.

### 13.4 Claim list — §13

- **L13.1-P12 [LEVEL A: AUTHOR]** — The exports of §13.1 are exactly: trajectory sequences with period data (to Paper 13), flow/load data at saturation-census changes (§9.4) (to Paper 14), census class data (to Paper 16). No export assigns a tick duration, fixes or bounds the threshold point 0 < TH < k, or constructs a packing.
- **L13.2-P12 [LEVEL A: AUTHOR]** — Receipts 1–4 of §13.2 accurately state the debts discharged and received, at the sections named; quote integrity of the debt statements against the published Papers 11/11.5 is checked by G.1.
- **L13.3-P12 [LEVEL A: AUTHOR]** — Nothing in §§1–13 re-derives the role taxonomy, redefines a Paper 9 construct, or asserts content owned by Papers 13, 14, 15, or 16 under their standing boundaries.

---

## Appendix A. Notation

Every symbol used in §§1–13, with its home. Symbols home to this paper are defined at the section cited; all others are received unchanged from their home paper (changes of meaning across papers would be bridge items for §13 and there are none).

| Symbol | Meaning | Home |
|---|---|---|
| a_k | The tick: native event identifier / serialisation of the scan (ordinal, not a duration) | Paper 2 |
| t₀ | Stage P tick-duration parameter (seconds per tick); cited, never used natively in Paper 12 | Paper 2 (Stage P) |
| N(d) = 4d² + 2 | Scan-shell population at relay distance d | Paper 10 |
| S(d) = s²/(4d² + 2); e·S(d) | Engagement-weighted scan allocation and its per-encounter form | Papers 10/11 (§8.5–8.6 lineage) |
| d | Taxicab (L3) relay-hop distance | Paper 10 |
| CU | Contact unit (Paper 9 contact-budget unit) | Paper 9 |
| N_total = N_id + v²_contact + s² + N_reconcile = 100 | Paper 9 contact budget (contact ticks only) | Paper 9 |
| N_reconcile | Reconcile work: count of chaotic rewrite/reconciliation events | Paper 9 |
| N_ticks | Tick count of a declared window | Paper 9 |
| T_ledger = N_reconcile/N_ticks | Paper 9 temperature: localised density of reconcile events per tick (reconstruction shadow) | Paper 9 |
| JST | Junction Saturation Threshold; exact point in 0 < TH < k is Paper 14's locked debt | Papers 9/11 (behaviour); point: Paper 14 |
| TH, k | Threshold value; junction degree in the JST bound | Papers 11/14 |
| G = (V, E) | Bonded aggregate graph; V pinned to the 27-state inventory (§11.1 of this paper) | Paper 11 §4 |
| N (N_nodes) | Node count of an aggregate or population, per §2's declaration | Paper 11 §4.1 / Paper 12 §2 |
| J | Junction count of an aggregate/population | Paper 11 §4.1 lineage |
| k_j | Degree (completed bonding-mode count) of junction j | Paper 11 §4.1 |
| B(G) = 6N − Σ_j k_j (pairwise: 6N − 2J) | Boundary / open-port count of an aggregate | Paper 11 §4.1, §4.3 |
| σ | Per-junction local state (Paper 11's junction state data) | Paper 11 §7 |
| T | Transition operator at a pairwise junction (zeroes the canonically-first admissible pair) | Paper 11 §7.5 |
| τ(σ) = Σx² | Junction quadratic tally; drops by exactly 2 per T-action | Paper 11 §7.5 |
| M = (n+, n−) | Presented count map of an encounter | Paper 11 §8.6 |
| T_agg | Aggregate tick: T applied once at every established junction (§4) | Paper 12 §4 |
| τ_agg | Aggregate τ: sum of τ over all junctions of the population | Paper 12 §4 |
| Census / count-class | Partition of an actual population by presented count data at a tick (§3) | Paper 12 §3 |
| Flow count | Per-tick exact count of bodies/records moving between two count-classes under T_agg (§5) | Paper 12 §5 |
| Ω | Native multiplicity/arrangement count of a population's records, re-founded as an actual-record count under the corrected frame; enters "entropy" only via the §0.5 bridge sentence S = k_B ln Ω (Stage P) | Paper 12 §§7–9 (definition finalised in drafting) |
| k_B | Boltzmann constant as Stage P assigned token; appears in Paper 12 only inside the entropy bridge sentence | Paper 9.5 (audit) / Stage P |
| Cap(G, role) | Capability: set of (encounter, tick) pairs, encounters from Paper 11's taxonomy, at which G plays `role` (§6) | Paper 12 §6 |
| (p, c) | Pre-period length and cycle length of an aggregate trajectory (§10) | Paper 12 §10 |
| C23–C30 | Paper 12's falsification conditions (series numbering continues from Paper 11's C19–C22) | Paper 12 §12 |
| L\<n\>-P12 | Claim labels of this paper | Paper 12 §0.5 |

*Skeleton note:* symbols introduced by §§1–9 drafts not yet assembled into this appendix (ensemble-temperature symbol for §7's construction, §8's concentration quantities, §9's load symbol) are to be entered here at v1 assembly from those drafts verbatim; no symbol may appear in §§1–13 that is not entered in this table (H.1 checks the registry side; the notation sweep is a v1 assembly check).

## Appendix B. Claim registry (skeleton)

One row per claim label. Badge column is final only when the named script has run green on the final tree (final-tree re-run rule). Script key: **A.1** counting rule (enumeration vs closed form) · **A.2** parallel-T well-definedness · **A.3** orbit/census counts · **A.4** capability profiles · **A.5** concentration counts · **A.6** reconcile-budget identities · **FW.1** firewall · **G.1** quote integrity · **H.1** registry honesty.

| Label | Claim (short form) | Badge | Verifying script |
|---|---|---|---|
| L3.\*-P12 | Census counting rule exact over actual records (§3) | LEVEL A: MACHINE (target) | A.1 |
| L4.\*-P12 | Aggregate tick well-defined; τ_agg accounting (§4) | LEVEL A: MACHINE (target) | A.2 |
| L5.\*-P12 | Frequencies as census ratios / flow counts; dissolution of the sampling-measure postulate (§5) | LEVEL A: MACHINE/AUTHOR (target) | A.3 (+ C25) |
| L6.\*-P12 | Capability profile theorem; structural, not carried (§6) | LEVEL A: MACHINE (target) | A.4 |
| L7.\*-P12 | Population temperature = aggregate reconcile density (§7) | LEVEL A: MACHINE (target) | A.6, G.1 |
| L8.\*-P12 | Arrow: τ-monotonicity + concentration under asymmetry of occasion (§8) | LEVEL A: MACHINE/AUTHOR (target) | A.5, A.2 |
| L9.\*-P12 | Regime change identified with JST crossings (§9) | LEVEL A: MACHINE (target) | A.6 |
| L10.1-P12 | Eventual periodicity; (p, c) decomposition as exact counting | LEVEL A: MACHINE | A.3 |
| L10.2-P12 | Cycle census counts exact; visit frequencies 1/c | LEVEL A: MACHINE | A.3 |
| L10.3-P12 | Completeness of trajectory features for population periodicity | LEVEL A: AUTHOR | — (argument; §2 + L10.1) |
| L10.4-P12 | §10 scope: no spectrum / dispersion / superposition / phonon | LEVEL A: AUTHOR (scope) | FW.1 (prose sweep) |
| L11.1-P12 | Molecules: derivation permission absent; extension not enacted | LEVEL A: AUTHOR | G.1 (Paper 11 §4/§12.2 quotes) |
| L11.2-P12 | Size-invariance of §§3–5/§7 constructions | LEVEL A: MACHINE | A.1, A.2, A.6 |
| L11.3-P12 | Macro-matter verdict under Edges 1–3; census confers no rank | LEVEL A: AUTHOR | — (argument; §11.3) |
| L12.1-P12 | C23–C30 cover each construction of §§3–10, as named in each condition's own text | LEVEL A: AUTHOR | H.1 (coverage check) |
| L12.2-P12 | All falsification killers are ledger-internal exhibits | LEVEL A: AUTHOR | FW.1 |
| L13.1-P12 | Exports exactly as scoped; threshold point and tick duration untouched | LEVEL A: AUTHOR | G.1, FW.1 |
| L13.2-P12 | Receipts 1–4 state the debts accurately | LEVEL A: AUTHOR | G.1 |
| L13.3-P12 | Firewall kept: no re-derivation, no trespass on Papers 13–16 | LEVEL A: AUTHOR | FW.1, G.1 |
| OR-1 | Molecule definition (vertex-domain conflict) | OPEN RULING — author's word required; not enacted | — |
| OR-2 | Population-level ordering key, if wanted | OPEN RULING — author's word required; not enacted | — |

*Skeleton note:* the L3.\*–L9.\* rows expand to one row per numbered claim when the §§1–9 drafts are assembled; a row with badge "target" is a drafting intention, not a badge — no badge is final until its script runs green on the final tree and H.1 confirms the row points at a script that checks the claim's actual content.

## Appendix C. Script appendix note

The verification scripts of this paper — FW.1, A.1–A.6, G.1, H.1, each carrying its INPUT_PROVENANCE block — are published in full in the Paper 12 verification package (machine-readable listings, run instructions, and manifest, per the series' standing package convention). In the paper itself, listings are embedded in this appendix at build time from the package's canonical files, matched to their slots by content identity, never by header or position (listing-embed discipline).

**Appendix J (ESP) — placeholder.** Per the standing ESP packaging convention, this paper's Appendix J will embed the current ESP engine, **v2.3** (built for this paper: series letter **A** admitted to the script-ID grammar), together with the brief what's-new note. The engine is **not** pasted into this draft: Appendix J is populated at build time from the v2.3 package's canonical engine file, byte-identically, and the published Paper 11.5 ESP v2.2 (DOI 10.5281/zenodo.23628524) remains untouched. Until the v2.3 package is built and verified, this appendix carries this placeholder and no engine text.

---

## Drafting notes for the parent agent (not paper text)

- Label scheme used here is section-scoped (L10.1-P12 etc.); if the §§1–9 drafts use a flat sequence (L1-P12…), Appendix B needs renumbering at assembly — flagged, not resolved.
- §11.1's statement of the Bonded Aggregate definition (V pinned to the 27-state inventory) follows the architecture/V19 analysis; G.1 must verify it against Paper 11 v69 text on disk before v1 is declared — not yet independently re-checked in this draft.
- Ω's exact native definition is, per the architecture, a §§7–9 drafting task under the corrected frame; Appendix A records it as such rather than inventing a definition here.
- One place the plan pressed against a wall: §10.3(a) — whether T_agg factorises over weakly coupled sub-populations (the only visible native route toward anything spectrum-like) is genuinely open; the draft records it as unproved in either direction rather than deferring it silently.
