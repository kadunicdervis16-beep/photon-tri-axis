# Paper 12 — DRAFT C: §§7–9 (Bulk Thermodynamics)

Status: v1 draft sections, written under the corrected relational frame
(ARCHITECTURE_AND_OUTLINE.md, CORRECTION section, Dervis 2026-10-24).
There is no micro level and no macro level in what follows. Every quantity
below is an exact finite count, sum, or ratio over the actual bodies,
junctions, and ticks of a declared population — the same ledger data
Paper 11 keeps, summed (Single-Regime, Paper 11 claim 41 [LEVEL A]).
Frequencies are census ratios of things that happened. No quantity is a
measure over events that did not happen.

Grounding and attribution notes (from the verbatim extraction of the
published Papers 9 and 10; these correct the binder-grade attributions
the architecture draft was built on):

- The 100 CU contact budget is **Paper 10 §2.2, eq. (2.4)** — not
  Paper 9. Paper 9's own budget rule is Paper 8's orthogonal sum rule
  v² + s² = c² over the Circa budget (Paper 9 §1, §5, §8). Paper 9
  supplies the physics of reconcile work (its §8.1, as cited by
  Paper 10); the arithmetic partition is Paper 10's.
- The symbol `T_ledger` occurs in **neither** Paper 9 nor Paper 10.
  Paper 9 defines its temperature verbally (§4, quoted in §7.1 below).
  Where this draft writes `T_ledger`, it is **Paper 12's own notation**
  for Paper 9's verbally defined quantity, introduced as such in §7.1
  and never presented as a Paper 9 symbol or quote.
- The Junction Saturation Threshold is **Paper 7's** construct (cited by
  Paper 9 from Paper 7 §5.1.1). It is not defined in Paper 9 or Paper 10.
  §9 builds the population saturation census on Paper 9 §6's saturation
  cascade (quoted verbatim) and cites the Threshold to Paper 7 without
  redefining it.
- The growth count 3^N is Paper 10 Appendix E, Axiom E.2 (Ω_max = 3^N
  configurations) — a state-space cardinality bound. It is **not** used
  anywhere in §§7–9; no per-tick 3^N claim is made.
- Every quotation below is verbatim from the published texts on disk;
  quote integrity is machine-checked by script G.1 against those files.

Conventions: a *population* P is a finite family of bodies admitted to
the aggregated ledger (§2), held fixed over a declared *tick window* W
(§7.5 states the scope limit this imposes). A *census class* is one of
the count-classes of §3; a *census record* at a tick is the vector of
actual body counts standing in each class at that tick. *Flow counts*
F_{i→j}(τ) are §5's transition-census entries: the exact number of
bodies that move from class i to class j at tick τ.

---

## 7. Reconcile density at population scale

### 7.1 What Paper 9 defined, in Paper 9's words

Paper 9 defines temperature without any symbol, as a count ratio over
ticks (§4, "Temperature as the Density of Rewrite Events"; paper9.txt
L241–250):

> Temperature is the localized density and frequency of chaotic
> creation-geometry rewrite events per tick. A region of the medium in
> which incompatible insertions are frequent and densely packed is
> running many reconciliation cycles per tick — its registers are being
> written with mismatched geometry and recomputed at a high rate. A
> region in which such events are sparse, or in which the geometry
> being written is coherent rather than chaotic, runs few such cycles.
> Temperature is the measure of that congestion: how many chaotic
> rewrites the local medium must execute per tick to keep its registers
> resolved.

The §2 form (paper9.txt L106–108): "The rate of these chaotic rewrite
events per ledger tick is what the observer macroscopically measures as
temperature." And the occasions at which such events occur are defined
in §3 (paper9.txt L180–181): "The intersection of two scans of the kind
established in Paper 7.5 is the occasion; the chaotic character of the
geometry forced into the registers is what makes the occasion thermal."

**Notation (Paper 12's, declared).** This paper writes T_ledger for the
quantity Paper 9 defines in the passage above: a ratio of an actual
rewrite-event count to an actual tick count. The notation is introduced
here, belongs to Paper 12, and abbreviates Paper 9's words — nothing
more is claimed for it. [Definition — notation]

### 7.2 The population reconcile count

Let P be a population of |P| bodies and W a window of |W| consecutive
ticks. For each body b ∈ P and tick τ ∈ W, let

  r_b(τ) = the number of chaotic creation-geometry rewrite events
           (reconcile events) actually booked by b at τ,

read off b's ledger entries. At a tick with no occasion for b, r_b(τ) = 0
— the count is over actual occasions only. The **population reconcile
count** over the window is the exact integer

  R(P, W) = Σ_{b ∈ P} Σ_{τ ∈ W} r_b(τ).        (7.1)

This is a sum of actual counts, nothing else. [LEVEL A: AUTHOR]

At a contact tick, the count r_b(τ) is not free: it is the N_reconcile
entry of Paper 10's contact accounting. Paper 10 §2.2 builds the
partition in steps (paper10.txt L933–985): the hardware budget is
N_total = N_id + C_exec = 3 + 97 = 100 CU; contact reallocates,

  v²_quiescent = v²_contact + N_reconcile,      (2.2a)
  C_exec = v²_contact + s² + N_reconcile,       (2.2b)

and the contact tick's total is the exact integer sum

  N_total = N_id + v²_contact + s² + N_reconcile = 100 CU.   (2.4)

So at any contact tick, since N_id = 3 is invariant,

  r_b(τ) = N_reconcile = 97 − v²_contact − s² ≤ 97,          (7.2)

with the reconcile physics — what the rewrite work *is* — supplied by
Paper 9 (§8.1 as cited by Paper 10; Paper 9's own transactions obey the
Circa rule v² + s² = c², Paper 9 §5, paper9.txt L310–315).

*Worked contact tick.* A body at a contact tick books v²_contact = 40,
s² = 21. Then by (2.4): N_reconcile = 100 − 3 − 40 − 21 = **36**. Check
against (2.2a): v²_quiescent = 40 + 36 = 76; against (2.2c):
N_id + v²_quiescent + s² = 3 + 76 + 21 = 100 ✓. So this body's entry in
the census (7.1) at that tick is r_b(τ) = 36 — bounded, budgeted, and
read off the same accounting Papers 9 and 10 already keep.

### 7.3 The population reconcile density; the local case recovered

Define the **population reconcile density**

  D(P, W) = R(P, W) / (|P| · |W|)  ∈ ℚ,  D ≥ 0,                  (7.3)

an exact rational: total actual reconcile events divided by total
actual body-ticks. Two reductions are immediate arithmetic.

(i) *Local case.* If |P| = 1, D({b}, W) = (Σ_{τ ∈ W} r_b(τ)) / |W| —
rewrite events per tick at the single body taken as the localized
region. This is Paper 9's §4 definition with the body as the region,
and in this paper's notation T_ledger(b, W) := D({b}, W). The
population quantity is the same ratio, summed — one rule for the lone
body and the population (Single-Regime). [LEVEL A]

(ii) *Mean of locals.* Writing D_b = D({b}, W) for each body over the
*same* window W,

  D(P, W) = (1/|P|) Σ_{b ∈ P} D_b,                               (7.4)

because every local ratio shares the denominator |W|:
(1/|P|) Σ_b (R_b/|W|) = (Σ_b R_b)/(|P|·|W|) = R(P, W)/(|P|·|W|). Exact
rational arithmetic; no step is approximate. [LEVEL A: MACHINE / AUTHOR
— arithmetic identity, enumerated by script A.6]

### 7.4 The earned term, and its one bridge sentence

**Construction.** In this paper's construction list, the term
**population temperature** denotes exactly the quantity (7.3):
T_ledger(P, W) := D(P, W), the population reconcile density over a
declared window. The word is earned by the construction: it names a
ratio of actual event counts, computed from ledger entries, with
Paper 9's definition as its one-body case. It is not a primitive, it is
not assigned to a body at an instant without a window, and no use of it
below means anything else.

[BRIDGE — Stage P] The single bridge sentence for this term: at
Stage P, what reconstruction usage calls the temperature of an
aggregate is represented by this population reconcile density evaluated
on the aggregate's window, with any numerical scale attached only at
Stage P through Paper 9's observational reading — natively, D is a pure
count ratio and carries no unit and no scale constant.

### 7.5 Worked example, end to end

Declared population P = {A, B, C, D} (|P| = 4), window W = ticks 1–10
(|W| = 10). The booked reconcile counts r_b(τ), read off the four
ledgers:

| tick τ | A | B | C | D |
|---|---|---|---|---|
| 1 | 2 | 0 | 3 | 1 |
| 2 | 0 | 1 | 2 | 0 |
| 3 | 1 | 0 | 2 | 0 |
| 4 | 3 | 2 | 1 | 1 |
| 5 | 0 | 1 | 2 | 0 |
| 6 | 2 | 0 | 3 | 1 |
| 7 | 1 | 0 | 1 | 0 |
| 8 | 0 | 2 | 2 | 0 |
| 9 | 2 | 1 | 0 | 1 |
| 10 | 1 | 0 | 2 | 0 |
| **body total** | **12** | **7** | **18** | **4** |

Population reconcile count (7.1): R(P, W) = 12 + 7 + 18 + 4 = **41**.
Body-ticks: |P| · |W| = 4 · 10 = 40. Population reconcile density (7.3):

  D(P, W) = 41/40,

already in lowest terms (gcd(41, 40) = 1). Local densities over the
same window: T_ledger(A, W) = 12/10 = 6/5; T_ledger(B, W) = 7/10;
T_ledger(C, W) = 18/10 = 9/5; T_ledger(D, W) = 4/10 = 2/5. Mean of
locals (7.4): (6/5 + 7/10 + 9/5 + 2/5)/4 = (12/10 + 7/10 + 18/10 +
4/10)/4 = (41/10)/4 = 41/40 ✓ — the identity checks on the example, as
it must, since both sides are the same sum grouped two ways.

### 7.6 Scope — where §7 bottoms out, stated

- D(P, W) is a property of the pair (population, window), not of the
  population alone. A different window over the same bodies gives, in
  general, a different rational. This is the relational content of
  Paper 9's definition, not a defect to be repaired: there is no
  window-free density in the ledger, and this paper does not define
  one.
- The population is held fixed over W. Populations that gain or lose
  bodies mid-window must be segmented into fixed-population windows;
  the segmented construction is not built here and no claim below
  depends on it.
- No numerical temperature scale is derived or asserted. The bridge
  sentence of §7.4 is the only contact with Stage P usage; Paper 9's
  observational reading ("what the observer macroscopically measures")
  is inherited, not re-derived.

### §7 claims

- **L7.1-P12** — The population reconcile count R(P, W) (7.1) is an
  exact integer sum of actual booked rewrite events over the declared
  bodies and ticks. [LEVEL A: AUTHOR — definition by summation of
  ledger entries]
- **L7.2-P12** — At a contact tick, r_b(τ) = N_reconcile satisfies
  (7.2) under Paper 10 eq. (2.4) with N_id = 3; the worked tick
  (v²_contact = 40, s² = 21) gives N_reconcile = 36, consistent with
  eqs. (2.2a) and (2.2c). [LEVEL A — inherited accounting, Paper 10
  §2.2; arithmetic shown]
- **L7.3-P12** — D(P, W) (7.3) is an exact rational; for |P| = 1 it
  reduces to Paper 9's §4 definition at the single body, and over a
  shared window it equals the mean of the local densities (7.4). [LEVEL A: MACHINE / AUTHOR — script A.6] Component split — MACHINE (A.6): the (7.4) mean-of-locals identity and the worked example's arithmetic; AUTHOR: the identification of D's |P| = 1 case with Paper 9 §4's verbal definition.
- **L7.4-P12** — "Population temperature" in this paper denotes exactly
  D(P, W); its only Stage P contact is the single bridge sentence of
  §7.4. [Construction — Paper 12; bridge declared]
- **L7.5-P12** — D is (population, window)-relative; no window-free
  density is claimed anywhere in this paper. [Scope statement —
  author]

---

## 8. The arrow without ensembles

### 8.1 What the arrow has to be built from

Three ingredients, all already on the table, and nothing else is used.

1. **Direction of the flow.** By §4, the aggregate τ (the sum of the
   per-junction τ over the population's junctions) never increases
   under the aggregate tick, and drops by exactly 2 for each junction
   that acts. The flow of the population through its census records is
   therefore accompanied by a monotone ledger quantity. [Inherited —
   §4 of this paper]
2. **Where the counts stand.** The census counting of this section:
   exact finite combinatorics over the actual bodies (§8.2–§8.3).
3. **The boundary condition.** Paper 9's asymmetry of occasion, quoted
   in full in §8.5 and assumed there as Paper 9 states it — an
   inherited premise, not re-derived here.

No ensemble is constructed at any point. There is no space of unrealized
populations being averaged; every count below is a count of assignments
**of the actual bodies of one declared population** to its census
classes, or a count of that population's actual flows.

### 8.2 The census record and its assignment count

Declare the toy population used throughout this section: n distinct,
named bodies, and two census classes, A and B (two of §3's
count-classes; the two-class case is the declared test bed — §8.6
states what is and is not claimed beyond it). A census record is a pair
(k, n − k): k of the actual bodies stand in A, n − k in B.

The number of assignments of the actual bodies that stand behind a
record — the number of ways to choose *which* k of the n named bodies
are the ones in A — is the exact integer

  Ω(k; n) = C(n, k) = n! / (k! (n − k)!)
          = [n · (n−1) ··· (n−k+1)] / [k · (k−1) ··· 1].        (8.1)

This is a product and quotient of counts of actual bodies: choose the
bodies for A one at a time (n choices, then n − 1, …), then divide by
the k! orderings of the same choice. Ω is a nonneg integer for every
0 ≤ k ≤ n, with Ω(0; n) = Ω(n; n) = 1 (exactly one assignment puts
every body in one class). The total over all records is

  Σ_{k=0}^{n} C(n, k) = 2ⁿ,                                      (8.2)

because each of the n named bodies independently stands in A or in B
in an assignment — a product over actual bodies, 2 · 2 ··· 2, n times.
[LEVEL A — finite counting, shown]

### 8.3 Concentration, by exact finite counting

Three exact statements. Together they are what "concentration" means
in this paper; §8.6 flags the stronger statement this paper does **not**
prove.

**(a) Counts rise toward balance.** For 0 ≤ k < n,

  C(n, k+1) / C(n, k) = (n − k) / (k + 1),                        (8.3)

by cancelling the shared factors in (8.1). The ratio exceeds 1 exactly
when n − k > k + 1, i.e. k < (n − 1)/2. So the assignment counts
strictly increase as k approaches n/2 from below, are maximal at the
balanced record (k = ⌊n/2⌋, with the two central records tied when n is
odd), and strictly decrease after. Shown arithmetic, n = 6 — records
k = 0…6 have counts 1, 6, 15, 20, 15, 6, 1, with successive ratios
6/1 = 6, 15/6 = 5/2, 20/15 = 4/3, then 3/4, 2/5, 1/6 — each an instance
of (8.3). [LEVEL A]

**(b) The balanced count grows at least exponentially in n/2.**
For even n = 2m,

  C(2m, m) = (2m)! / (m! m!) = Π_{j=1}^{m} (m + j)/j,              (8.4)

since (2m)!/m! = (m+1)(m+2)···(2m) and dividing termwise by
m! = 1·2···m pairs (m + j) with j. Each factor satisfies (m + j)/j =
1 + m/j ≥ 2, because j ≤ m gives m/j ≥ 1. Therefore

  C(2m, m) ≥ 2ᵐ.                                                 (8.5)

Check: m = 1: C(2,1) = 2 ≥ 2 ✓; m = 2: C(4,2) = 6 ≥ 4 ✓; m = 3:
C(6,3) = 20 ≥ 8 ✓. [LEVEL A — product argument, no approximation]

**(c) The polarized records' share collapses exactly.** Call the two
records (n, 0) and (0, n) *polarized*: every body in one class. By
(8.1) they carry 1 assignment each, so by (8.2) their combined share of
all assignments of the actual bodies is exactly

  polarized share = 2 / 2ⁿ = 2^(1−n),                             (8.6)

and the complementary share — assignments in which both classes are
occupied — is exactly 1 − 2^(1−n).

*Finite inequality.* For every n ≥ 1,

  1 − 2^(1−n) ≥ (n − 1)/n.                                        (8.7)

Proof by finite induction, no limits invoked. It suffices to show
2^(1−n) ≤ 1/n. Base n = 1: 2⁰ = 1 ≤ 1/1 ✓. Step: suppose
2^(1−n) ≤ 1/n. Then 2^(1−(n+1)) = 2^(1−n)/2 ≤ 1/(2n) ≤ 1/(n+1),
where the last step is 2n ≥ n + 1, true for n ≥ 1. ∎ So the
non-polarized share is at least (n − 1)/n at every population size —
an exact statement at each finite n, exhaustively checkable at each n,
and the sense in which the share "grows toward 1" is precisely this:
for any named fraction q < 1, every n > 1/(1 − q) has non-polarized
share exceeding q, by (8.7). [LEVEL A: MACHINE / AUTHOR — script A.5
enumerates the finite cases]

*The trend, n = 1…6* (all entries exact; record counts from (8.1)):

| n | record counts C(n, k), k = 0…n | total 2ⁿ | max record count | polarized share 2^(1−n) | non-polarized share | balanced record's own share |
|---|---|---|---|---|---|---|
| 1 | 1, 1 | 2 | 1 | 1 | 0 | 1/2 |
| 2 | 1, 2, 1 | 4 | 2 | 1/2 | 1/2 | 1/2 |
| 3 | 1, 3, 3, 1 | 8 | 3 | 1/4 | 3/4 | 3/8 |
| 4 | 1, 4, 6, 4, 1 | 16 | 6 | 1/8 | 7/8 | 3/8 |
| 5 | 1, 5, 10, 10, 5, 1 | 32 | 10 | 1/16 | 15/16 | 5/16 |
| 6 | 1, 6, 15, 20, 15, 6, 1 | 64 | 20 | 1/32 | 31/32 | 5/16 |

Read the table honestly — it shows two different things. The polarized
share halves with every added body and the non-polarized share obeys
(8.7): that is the concentration this paper proves. The last column is
included precisely because it does **not** grow: the single balanced
record's own share of all assignments is 1/2, 1/2, 3/8, 3/8, 5/16, 5/16
over the shown range. Any phrasing of the form "the population ends up
in the maximal record" would be false to this counting, and this paper
does not make it. Concentration here means: polarized records become an
exactly quantified, vanishing fraction of the assignments, and the
assignment counts peak at balance (8.3) with the peak itself growing by
(8.5).

### 8.4 The native quantity; one bridge sentence

The native quantity of this section is the census record itself — the
vector of actual class counts — together with its assignment count Ω
as defined by (8.1) for the two-class case (and by the same
choose-the-bodies counting, class by class, in general: for a record
(n₁, …, n_r) over r classes with Σ nᵢ = n, Ω = n! / (n₁! ··· n_r!),
an integer counting assignments of the actual bodies consistent with
the record). The record is a ledger entry; Ω is a count taken from it.
No further native quantity is introduced, and no name beyond "census
record" and "assignment count" is used natively for either.

[BRIDGE — Stage P] The single bridge sentence for the locked word this
section discharges: at Stage P only, the assignment count Ω of a census
record is read as entropy through S = k_B ln Ω — a reconstruction
reading of the record, carrying a Stage P scale token, which no native
claim in this paper uses, needs, or restates.

### 8.5 The boundary condition: Paper 9's asymmetry of occasion

The counting of §8.3 says where assignment counts stand. It does not,
by itself, say why the occasions that *produce* disorder are generic
while the occasions that produce order are not. Paper 9 states that
asymmetry mechanically, and names this paper as its venue — quoted in
full (Paper 9, §5; paper9.txt L409–428):

> The asymmetry of occasion — why heat flows hot to cold. The
> underlying mechanisms of heating and cooling are perfectly symmetric
> under the budget rule, but their structural occasions are not, and
> this asymmetry is the mechanical root of the thermodynamic arrow.
> Chaotic, mismatched insertions arise from any generic, unaligned
> [— page header in source —] intersection of manifold scans anywhere
> in the medium — they require no preparation. Forced structural
> cooling, by contrast, requires a highly specific, phase-aligned
> standing structure already in place to compel the surrounding
> registers into order. Chaotic disorder is the default writing of
> random intersection; coherent alignment is the highly specialized
> one. Heat therefore flows spontaneously from hot to cold not because
> of an abstract statistical probability imposed from outside, but
> because disordered creation geometry is the mechanical default of an
> unguided collision, while ordered resolution is the rare, prepared
> exception. This thermodynamic asymmetry of occasion is not a mere
> statistical probability of macroscopic states, but a structural
> necessity driven directly by the mechanics established in Paper 2:
> because open background states (States 2 through 8) are inherently
> unstable and un-anchored, their temporal scans must continuously
> cycle through local coordinates searching for geometric resolution.
> This active, open-state search behavior inherently drives the
> directional, chaotic progression of the manifold, providing the
> explicit geometric anchor for the thermodynamic arrow before any
> statistical averaging takes place. The full statistical aggregation
> of these asymmetric occasions — alongside the mechanical derivation
> of entropy and the thermodynamic arrow — is deferred as a locked
> coordinate and a declared boundary condition to Paper 12,
> constrained by this asymmetry of occasion.

**Status in this paper.** The quotation above is Paper 9's text verbatim,
including Paper 9's own naming of what it defers; Paper 12's native prose
admits that locked word only in §8.4's bridge sentence. The passage is
assumed as a stated boundary
condition, exactly in Paper 9's own scoping: Paper 12 performs "the
full statistical aggregation of these asymmetric occasions" — the
census, flow counts, and exact counting of this paper — *constrained
by* the asymmetry, and does not derive the asymmetry itself. The arrow
as assembled here is therefore: flow direction from τ-monotonicity
(§8.1.1), the standing of the counts from §8.3, and the genericity of
disordering occasions over ordering ones from Paper 9 §5, inherited.
Where any one of the three is absent, this paper claims no arrow.
[Inherited premise — Paper 9 §5; dependence flagged]

For §9 the companion sentence matters (Paper 9 §5; paper9.txt
L435–438): "The Second Law … is the natural dispersal of localized
rewrite cycles into neighbouring coordinates, because the medium
automatically distributes forced geometric backpressure toward regions
with a higher remaining processing budget." Dispersal runs toward
remaining budget — which is why saturation, §9's subject, is where the
dispersal stops being free.

### 8.6 Scope — where §8 bottoms out, stated

- The counting is proved for the declared two-class toy and, for Ω,
  stated for r classes by the same counting. The general band statement
  — that assignments within any fixed proportional band around the
  balanced record exhaust all but a vanishing share, for arbitrary
  bands and class numbers — is **not** proved in this paper. What is
  proved is (8.3), (8.5), (8.6), (8.7), each exact at every finite n.
  Any asymptotic strengthening belongs to Stage P and is not made here,
  in the bridge sentence or anywhere else.
- The asymmetry of occasion is inherited from Paper 9 as a boundary
  condition, per its own deferral sentence. A derivation of it inside
  Paper 12 would exceed the scope Paper 9 set; none is attempted.
- Assignment counts count assignments of the actual bodies of the
  declared population. They are not frequencies of anything, and no
  claim in this section reads them as how often a record occurs; how often records occur is §5's flow census, an actual count over actual ticks.
- **The missing joint, named.** No result in this paper shows that aggregate trajectories drift toward high-Ω records; the arrow of §8.5 is assembled from its three badged ingredients, and the dynamics-to-balance joint is NOT proved here — it is this paper's open joint. For closed populations the dynamics terminates at fixed points (§10), which are equilibria only when (E2) additionally holds.

### §8 claims

- **L8.1-P12** — Ω(k; n) = C(n, k) (8.1) counts the assignments of the
  n actual bodies realizing the record (k, n − k); the records' counts
  sum to exactly 2ⁿ (8.2). [LEVEL A — finite counting shown]
- **L8.2-P12** — Assignment counts strictly increase toward the
  balanced record and strictly decrease after it, by the exact ratio
  (8.3); the balanced count satisfies C(2m, m) ≥ 2ᵐ by the product
  argument (8.4)–(8.5). [LEVEL A]
- **L8.3-P12** — The polarized records' combined share of assignments
  is exactly 2^(1−n), and the non-polarized share satisfies
  1 − 2^(1−n) ≥ (n − 1)/n for all n ≥ 1 (8.6)–(8.7), with the n = 1…6
  trend tabled. [LEVEL A: MACHINE / AUTHOR — script A.5] Component split — MACHINE (A.5): the finite counts, ratios, and inequalities as printed; AUTHOR: the reading of those counts as concentration (and the non-growth honesty entry).
- **L8.4-P12** — The balanced record's own share does not grow toward
  1 over n = 1…6 (1/2, 1/2, 3/8, 3/8, 5/16, 5/16); no claim of that
  form is made. [LEVEL A — read off the same table; honesty entry]
- **L8.5-P12** — The native quantity is the census record and its
  assignment count Ω; the locked word for it is admitted only in the
  single Stage P bridge sentence of §8.4, which no native claim uses.
  [Construction — Paper 12; bridge declared]
- **L8.6-P12** — The arrow of §8 is assembled from τ-monotonicity
  (§4), the exact counting (8.3)–(8.7), and Paper 9 §5's asymmetry of
  occasion as an inherited boundary condition, quoted in full and not
  derived here. [LEVEL A for the counting components; inherited
  premise — Paper 9 §5, flagged]

---

## 9. Equilibrium and regime change

### 9.1 Flow counts, recalled

From §5's transition census: for classes i, j and tick τ,

  F_{i→j}(τ) = the exact number of bodies that stand in class i
               before tick τ and in class j after it,

with F_{i→i}(τ) counting bodies that do not change class. Every body is
counted exactly once among the destinations from its class, so for each
class i,

  Σ_j F_{i→j}(τ) = (number of bodies in class i before τ) =: nᵢ(τ),  (9.1)

and the census after the tick is

  nᵢ(τ+1) = Σ_j F_{j→i}(τ).                                          (9.2)

These are actual counts over the actual population — the census of what
the dynamics did at that tick, not a weighting of what it might do.

### 9.2 Stationary census, defined exactly

A census record is **stationary under one aggregate tick** iff the
record after the tick equals the record before it, class by class:
nᵢ(τ+1) = nᵢ(τ) for every class i. By (9.1)–(9.2), this holds iff for
every class i the out-flow count equals the in-flow count:

  Σ_j F_{i→j}(τ) = Σ_j F_{j→i}(τ)      for every class i,            (9.3)

i.e. every class's net flow count Φᵢ(τ) := Σ_j F_{j→i}(τ) −
Σ_j F_{i→j}(τ) is exactly zero. The definition is a finite system of
integer equations in actual flow counts — checkable on any declared
population by direct census, with no averaging anywhere. [Definition —
Paper 12]

### 9.3 The earned term: equilibrium

**Construction.** In this paper's construction list, **thermal
equilibrium** denotes a census record that is

  (E1) stationary under the aggregate tick, in the exact sense (9.3);
  and
  (E2) not further concentrated by the flow: its assignment count Ω (§8.2) is maximal among ALL census records of the declared population (same census size and class structure) — a counting comparison over the population's records, stated as such.

Both clauses are needed, and they separate two species:

- **Frozen stationary census.** No junction of the population acts at the tick — every junction stands at the fixed point of Paper 11's transition operator T (§4), so every F_{i→j} = 0 for i ≠ j and (9.3) holds trivially. It satisfies (E1); it is an equilibrium only if (E2) also holds — see the counter-example below.
- **Flowing equilibrium.** Junctions act — aggregate τ drops by 2 per
  acting junction (§4) — while the class flows balance exactly, so the
  record stands still while the junctions work. Equilibrium is a
  property of the census, not of junction activity; τ can fall under
  a stationary record, and §9.4's example shows it doing so.

*Worked example.* n = 4 bodies, classes A, B, census (2, 2). At tick τ
exactly two junctions act: one body moves A→B, one body moves B→A.
Flow counts: F_{A→B} = 1, F_{B→A} = 1, F_{A→A} = 1, F_{B→B} = 1.
Stationarity (9.3): class A: out = F_{A→A} + F_{A→B} = 2, in =
F_{A→A} + F_{B→A} = 2 ✓; class B: out = 2, in = 2 ✓. Census after the
tick: (2, 2) — unchanged. Assignment count: Ω(2; 4) = C(4, 2) = 6,
which is maximal among the n = 4 records {1, 4, 6, 4, 1} (§8.3), so
(E2) holds: the record is an equilibrium, of the flowing species.
Aggregate τ drops by 2 × 2 = 4 across the tick while the census does
not move — the two facts coexist because they count different things:
junction actions versus class standings. [LEVEL A — arithmetic shown]

*Counter-example (the definition discriminates).* The frozen census
(4, 0) — all four bodies in A, no junction admissible, no junction
acts. (9.3) holds trivially (every flow is zero between distinct
classes), so the census is stationary; but Ω(0; 4) = 1, the minimum,
not the maximum — (E2) fails, and (4, 0) is **not** an equilibrium
under this construction. It is a polarized frozen census. A definition
of the earned term that could not exclude it would be bookkeeping, not
a construction; this one excludes it by count. [LEVEL A]

*Scope of (E2), stated.* (E2) is a counting comparison over all census records of the declared population — every record with the same census size and class structure — not a question about which records the dynamics can reach. The definition (E1)–(E2) is exact at every population size, as a definition; evaluating (E2) for a given record means comparing its assignment count against that full set of records, which is enumeration-bounded for large populations. For the declared test populations of this paper the comparison is settled by enumeration (scripts A.3/A.5). Where enumeration is infeasible, (E2)'s status for a given record is an open finite question, and this paper says so rather than closing it by convention.

### 9.4 Regime change: saturation at population scale

§8.5's companion sentence sends dispersal "toward regions with a higher
remaining processing budget." What happens when the budget is no longer
remaining is Paper 9 §6's saturation cascade. Its first step, verbatim
(Paper 9 §6; paper9.txt L461–463):

> Step 1, local budget saturation: as chaotic insertions accumulate,
> reconciliation cycles consume the remaining budget until the standing
> scan load plus the chaotic rewrite workload reaches the whole of the
> local processing capacity, and the local ledger hits absolute
> saturation.

The threshold construct itself is Paper 7's: Paper 9's dependency
summary lists "the Junction Saturation Threshold and processing-rate
mechanics governing loaded junctions" among what it takes "From
Paper 7" (paper9.txt L90), and cites "the local Junction Saturation
Threshold (Paper 7, Section 5.1.1)" at the point where axis-tilt
shifts exceed it (paper9.txt L149–150). Paper 12 cites the Threshold
to Paper 7 and does not redefine it; the exact location of the
threshold point is Paper 14's locked debt and is not touched here.
What Paper 12 builds — badged as this paper's construction — is the
population census of saturation, from two licensed ingredients:

1. **Per-junction booking capacity.** At a contact tick, a junction's
   booked load is the Paper 10 eq. (2.4) sum, capped by the budget
   identity itself: booked load ≤ 100 CU, with the reconcile entry
   booking at most N_reconcile = 97 − v²_contact − s² (§7.2). Demand
   beyond the cap is not booked and not destroyed: it remains in the
   ledger as *deferred reconcile demand*, itself an exact count.
2. **Relayed load shares.** A junction's standing scan load includes
   workload relayed from sources at relay distance d, partitioned by
   Paper 10's Uniform Load Partition (§2.4.7; paper10.txt L1381–1386):

   > Theorem (Uniform Load Partition — Exact Architectural Form)
   > [LEVEL A][L1·L2·L3·L4]. For an isolated source configuration, the
   > temporal-scan workload partitions uniformly across all admissible
   > configurations at the same relay distance d that share the same
   > operational state category and local Circa budget.

   with the per-configuration strain S(d) = s²_node / N(d),
   N(d) = 4d² + 2 (eq. 2.7), proved there in five steps (complete
   sweep; S₃ symmetry of the 27-state inventory; equal emission weight
   per axis; no void positions; uniform partition across the complete
   shell), and the shell identity Σ_{shell(d)} S(d) = s²_node
   (eq. 2.6). Scope, respected: the partition is used here only in its
   S₃-symmetric (isotropic) form; Paper 10 defers anisotropic source
   corrections to Paper 23 (§2.4.4), and this paper does not import
   them early.

**Definitions (Paper 12's construction).** A junction is **saturated
at tick τ** iff its demanded load at τ — standing scan load (including
relayed shares under item 2) plus chaotic rewrite demand — reaches the
whole of its local processing capacity, in Paper 9 §6's words; in the
contact accounting of item 1, iff its eq. (2.4) demand meets or exceeds
100 CU. The **saturation census** at τ is

  J_sat(τ) = the number of the population's junctions saturated at τ,

and the saturation fraction J_sat(τ)/J(τ) ∈ ℚ, where J(τ) is the
population's junction count at τ. A **regime change** is a tick at
which J_sat changes value — a junction enters or leaves saturation.
All three are exact counts or ratios over the actual junctions; the
population-level construction is a sum over Paper 9 §6's local
behaviour, per the Single-Regime rule, and is claimed as nothing more.
[Construction — Paper 12, on Paper 9 §6 and Paper 10 §2.2/§2.4.7]

### 9.5 Worked threshold example, arithmetic shown

Population with three junctions J₁, J₂, J₃, each under the contact
accounting (capacity 100 CU per contact tick, Paper 10 eq. (2.4)).
At tick τ − 1 every junction's demand is below 100 CU, so
J_sat(τ − 1) = 0. At tick τ the demands are:

| junction | N_id | v²_contact | s² | reconcile demand | total demand | booked | deferred |
|---|---|---|---|---|---|---|---|
| J₁ | 3 | 55 | 15 | 32 | 105 | 100 | 5 |
| J₂ | 3 | 48 | 12 | 25 | 88 | 88 | 0 |
| J₃ | 3 | 52 | 20 | 25 | 100 | 100 | 0 |

Row arithmetic: J₁: 3 + 55 + 15 + 32 = 105 > 100 — demand exceeds
capacity; booked reconcile = 100 − (3 + 55 + 15) = 27, deferred
reconcile demand = 32 − 27 = 5. J₂: 3 + 48 + 12 + 25 = 88 < 100 —
fully booked. J₃: 3 + 52 + 20 + 25 = 100 — demand meets capacity
exactly; saturated-at, fully booked, nothing deferred.

Population totals: demanded load = 105 + 88 + 100 = 293 CU; booked
load = 100 + 88 + 100 = 288 CU; deferred reconcile demand = 5 CU,
carried in the ledger as a count, not written off. Saturation census:
J₁ and J₃ are saturated at τ, so J_sat goes 0 → 2 at τ, saturation
fraction 2/3 ∈ ℚ. **Tick τ is a regime change** under §9.4's
definition — the first tick of this population's record at which any
junction stands saturated. Note what the census does and does not say:
it says exactly which junctions saturated, at which tick, with how
much deferred demand. The threshold's exact point (Paper 7's
construct, Paper 14's debt) is an input to the per-junction capacity
used here — 100 CU from Paper 10's budget identity — not a quantity
this example derives. [LEVEL A: MACHINE / AUTHOR — accounting checked
by script A.6]

### 9.6 Scope — where §9 bottoms out, stated

- The Threshold itself is Paper 7's; its exact point is Paper 14's
  locked debt. §9 uses per-junction capacity as declared input (the
  100 CU contact cap) and builds only the census over it. Any future
  relocation of the threshold point by Paper 14 changes the census's
  inputs, not its definitions.
- (E2)'s all-records comparison is enumeration-bounded for large populations (§9.3); the definition is exact, its decidability in general is not claimed.
- Deferred reconcile demand is counted and carried; the *dynamics* of
  deferred demand across later ticks (queue discipline at saturated
  junctions) belongs to the aggregate-dynamics development and is not
  stipulated here — no claim in §§7–9 depends on a queue rule.
- **The missing joint, named.** No result in this paper shows that aggregate trajectories drift toward high-Ω records; the arrow of §8.5 is assembled from its three badged ingredients, and the dynamics-to-balance joint is NOT proved here — it is this paper's open joint. For closed populations the dynamics terminates at fixed points (§10), which are equilibria only when (E2) additionally holds.

### §9 claims

- **L9.1-P12** — Flow counts obey (9.1)–(9.2) exactly; a census is
  stationary under one aggregate tick iff every class's net flow count
  is zero (9.3). [LEVEL A — integer bookkeeping]
- **L9.2-P12** — "Thermal equilibrium" in this paper denotes exactly
  (E1) + (E2): a stationary census whose assignment count is maximal among all census records of the declared population; the n = 4 flowing example satisfies both
  clauses with aggregate τ dropping by 4 under an unchanged census.
  [Construction — Paper 12; example LEVEL A]
- **L9.3-P12** — The polarized frozen census (4, 0) is stationary but
  not an equilibrium under (E1)–(E2) (Ω = 1, not maximal); the
  construction discriminates. [LEVEL A]
- **L9.4-P12** — The saturation census J_sat(τ), the saturation
  fraction, and regime change (a tick where J_sat changes) are exact
  counts/ratios built by summation over Paper 9 §6's local saturation
  behaviour, with per-junction capacity from Paper 10 eq. (2.4) and
  relayed shares from Paper 10 §2.4.7 (isotropic form only;
  anisotropic corrections remain Paper 23's). The Threshold is cited
  to Paper 7 and not redefined; its exact point is Paper 14's.
  [Construction — Paper 12; components inherited as cited]
- **L9.5-P12** — In the worked population, demands 105/88/100 CU
  against the 100 CU cap give booked 288 of 293 CU demanded, deferred
  reconcile demand 5 CU carried as a ledger count, J_sat: 0 → 2, and tick τ a regime change. [LEVEL A: MACHINE / AUTHOR — script A.6] Component split — MACHINE (A.6): the §9.5 threshold arithmetic; AUTHOR: the worked example's status as an exhibit of the §9.4 construction.

---

*End of DRAFT C (§§7–9). Open slots for the integrator: none — all
quotations were taken from the verbatim extraction of the published
Papers 9/10 and stand under script G.1's quote-integrity check.
Attribution deltas against the architecture draft are listed in the
header grounding notes.*
