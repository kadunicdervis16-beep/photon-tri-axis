# Paper 12 — Verification Package

**Paper:** *Paper 12: The Aggregated Ledger — Many-Body Statistical
Mechanics and the Emergence of Bulk Thermodynamics* (Departure From
the Photon Baseline series), v4.

This package contains everything needed to re-run the paper's
machine verification suite from scratch:

- `Paper_12_v4.md` — the paper (markdown source; the plain-text
  rendering is produced with the package build). Since the v2
  self-contained build (2026-10-26) the paper is self-contained:
  its Appendix C embeds the whole suite, the source texts below,
  and the ESP v2.3 initiation block, so the paper alone can be
  unpacked to this same layout and run (see §C.1 of the paper).
  This package remains as the convenience copy of the same files.
- `scripts/` — the nineteen verification scripts plus `run_all.py`.
- `battery/` — the Appendix E exhibit files: the GS-1 specification
  and report, the DS-12 report, the comparative report, both GS-1
  reproduction reports, the G8 witness file, and the three-ways
  audit addendum (the paper's Appendix E embeds them byte-identically
  and A.9 sibling-checks them against this folder).
- `draft/` — the four section drafts the paper was assembled from
  (the scripts' `--drafts` modes read these).
- `sources/` — the published texts Paper 12 quotes, included so the
  quotation check (G.1) is self-contained: `paper9.txt` and
  `paper10.txt` (text extractions of the published Papers 9 and 10),
  `paper_11_v69.md` (Paper 11 v69), `paper_11_5_v26.md`
  (Paper 11.5 v26).

## How to run

Requires Python 3 (standard library only — no installs).

```
python3 scripts/run_all.py
```

Expected result on the unmodified package: **19/19 scripts PASS**.

Each script can also be run individually; run with no arguments,
every script checks the assembled paper. Most scripts also accept
`--drafts` to check the section drafts instead.

## What each script checks

- **A.1** — the §3 counting rule: census identities (I)–(III) on the
  worked exhibit and generated populations; Paper 11's worked
  aggregate counts recomputed; taxicab stress aggregates by closed
  form and by direct enumeration (dual oracle).
- **A.2** — the §4 aggregate tick: the parallel tick equals every
  sequential order; Δτ_agg = −2 × acting junctions; a discriminating
  locality check (a deliberately non-local operator fails, with
  witness); a shared-port negative control in the main path.
- **A.3** — the §5/§10 orbit structure: pre-period/cycle
  decomposition of the tick dynamics; every cycle is a fixed point.
- **A.4** — the §6 capability theorem: outcome factorization through
  the presented count profile, checked under two disagreeing outcome
  rules; a carried-capability mutant is caught with a witness.
- **A.5** — the §8 arrow counting: the concentration table reproduced
  by three independent counting routes.
- **A.6** — the §7/§9 budget identities: every printed identity
  recomputed from its printed inputs; Paper 10's ULP shells
  enumerated for d = 1..6.
- **A.7** — the Appendix D worked exhibit: every number of the
  twelve-body end-to-end exhibit recomputed from its declared
  records — census identities, trajectory and τ accounting, flows
  and frequencies, capability factoring, reconcile density,
  assignment counts, equilibrium verdicts — plus a transcription
  seam checking the paper's Appendix D tables against the script's
  records.
- **A.8** — the §11.2 molecule reduction: the reduction identities
  (R1)–(R3) computed from declared records on the §11.2 worked
  example and on generated grouped molecules; grouping-independence
  checked along merging chains; planted mutants (an off-by-one
  inter-atom arity; a non-partition grouping double-counting a
  state) rejected with witnesses; plus a printed-oracle leg parsing
  the worked example's printed tables and summary lines from §11.2.
- **A.9** — embedded-listing integrity (Appendix C): extracts every
  marked block embedded in the paper, verifies each against the
  sha256 and byte count in Appendix C's manifest table, checks the
  extracted set equals the manifest set and the fence rule holds,
  and compares against the canonical files beside the paper when
  they are present. Its coverage is internal consistency and
  extractability; external anchoring is this package's MANIFEST
  and the published record.
- **A.10** — two-level system exhibit (§8.7): recomputes the declared
  twelve-body population's trajectory under the aggregate tick, its
  assignment counts by enumeration and by closed form, and its
  (E1)/(E2) verdicts record by record; planted mutants (a wrong Ω
  cell; a fabricated trajectory step) rejected with witnesses.
- **A.11** — mode exhibit (§10.4): implements the declared
  re-presentation rule on the declared 4-body population, computes
  the orbit and its (0, 2) decomposition by two routes, the
  amplitude and the exact visit frequency, and the frozen T_agg-alone
  control; planted mutants (period mis-stated as 3; amplitude halved)
  rejected with witnesses. The exhibit is an enlarged transition;
  L10.3-P12's completeness scope is not extended by it.
- **A.12** — the §5 joint counts (v4 extension): the three
  standings are total over all 81 local states and refine §8.7's
  feature φ; the G8 witness pair's finest census/flow identity is
  recomputed and its joint answers (1/4 and 0) are returned across
  the full 3×3 standing tables; marginalization and window
  additivity are checked on the witness and generated populations;
  four planted mutants (identity-blind, unordered, binarized,
  census-only) are rejected with witnesses.
- **A.13** — provenance formalization consistency (§0.4): dual-oracle legality over the full attempted per-party spaces of both bonding-mode shapes and the full composed docking space (16,257,024 combinations); bookkeeping invariants on every legal docking transition and on sampled convergence transitions; reachability exact at two nodes.
- **A.14** — population ordering key (§11.3): the §11.3 key computed over the six constructed exemplar representatives (the full induced order, each step's deciding component; the nuclei/atoms step also checked parametrically over u = 0..4 and S = 1..4 at the shared M) and the 3,402-population sigma family (name invariance on every population; transitivity exhaustive over the 81 one-junction triples and sampled over the family; the stability invariants at declaration vs rest); witnesses W1 (stability sharpness) and W4 (silent-slot flip) re-verified; three mutant keys rejected with printed witnesses.
- **A.15** — the Spine exhibits (Appendix F): every printed number of the three end-to-end populations recomputed from the declarations alone by two independent implementations and compared field by field against the printed fixture; the appendix's prose numbers outside the fixture (the all-records counts and totals, the printed net flows, the encounter-taxonomy denominator) are checked against computed values tied to the appendix's text by transcription anchors.
- **FW.1** — the firewall sweep: every controlled term (temperature,
  entropy, ensemble, probability, …) sits in a declared zone
  (quotation / construction / bridge / scope note / table /
  embedded-listing).
- **G.1** — quotation integrity: every blockquote and named
  quotation in the paper is found verbatim (under a disclosed
  typography-only normalization) in its attributed published source.
  G.1 also prints advisory notes on inline (non-block) quotations —
  14 in v2, unchanged from v1: quoted segments that are the paper's
  own definitional prose, or that verify across several listed
  sources rather than a single one. The advisories are printed for
  human adjudication; they do not affect G.1's verdict.
- **H.1** — the claim registry: every claim carries a taxonomy
  badge; every MACHINE-badged claim names a script that exists.
- **H.2** — split agreement, provenance, badge definedness:
  every hybrid claim's component split is identical at home,
  claim list, and registry; every script's INPUT_PROVENANCE
  block stays inside the regime's class vocabulary with its
  via-bindings matching their sources; every badge family in
  use is defined in §0.2 of the paper.

Every script carries an INPUT_PROVENANCE block declaring its input
sources, and a planted-mutant battery: each mutant is a genuine
spec violation and must be rejected with a printed witness.

## Disclosed adjustments

- **G.1 source resolution** tries, in order, this package's
  `sources/` directory, the author's workspace layout, and the
  original absolute workspace paths. Path resolution only; the
  checking logic is unchanged (see the note in `G1_quotes.py`).
- The registry row for claim L7.3-P12 phrases the one-body case in
  words ("for a one-body population…") rather than with the symbol
  |P|, because the registry table's pipe delimiter cannot carry the
  symbol unescaped; the symbol stands verbatim at the claim's home
  in §7.3.

## The ESP engine (Appendix J)

Appendix J of the paper embeds the ESP v2.3 engine byte-identically
(sha256 of the embedded listing:
`517d77f30e45383b2a9a63287bd0458e66bcc66ddfd08648d00d877bbea591d5`).
The full ESP v2.3 package — engine, conformance battery (270 cases),
selftest, and starter packs — ships separately as
`ESP_v2.3_Package.zip` (sha256
`2b364828c04dd99a6d02526023e49520bb61c343e6d61ca900d1acaf72eb88c8`).

## Verification status of this package

The suite was re-run from a fresh extraction of this package by the
author's agent before delivery: 9/9 PASS, with the source-resolution
fallbacks disabled (package-local sources only).

This package was rebuilt on 2026-10-24 from the corrected v1 text
(the paper's version block records the completion of its
verification-status record after an external audit). The suite was
re-run from a fresh extraction of this rebuilt package: 9/9 PASS,
fallbacks disabled, as above.

**v2 (2026-10-25).** The paper gains §§1.7–1.8, the §5 dissolution
statement, the §11.3 quarantine sentence, claim-list scope markers
(L7.6, L8.7, L9.6, L9.7), the subtitle footnote, and Appendix D with
script A.7. Suite on the v2 staging tree: 10/10 PASS (2026-10-25).
A.6's §7.5/§9.5 table extraction is scoped to those sections at v2
(disclosed in the script); the v1 assembly still passes under the
repaired script. The v2 package-extraction re-run belongs to the
v2 package build and is recorded there.

**v2 final build (2026-10-25).** On the author's rulings of that
evening, the paper enacts the molecule definition at §11.2 (OR-1
resolved, two-level reduction form; new script A.8; falsification
condition C31 added), narrows L10.3-P12 to closed trajectories
under T_agg with the matching note at C27, states the §0.5
construction row in full, and scopes the §5 dissolution statement.
Suite on the v2-final staging tree: 11/11 PASS (2026-10-25). The
package-extraction re-run for this build belongs to its package
build and is recorded there.

**v2 self-contained build (2026-10-26).** On the author's order,
the paper itself now carries the verification: Appendix C embeds
all thirteen script files, the four source texts, and the ESP v2.3
initiation block under HTML-comment markers beside a sha256
manifest (new claim LC.1-P12, verified by the new script A.9; the
suite stands at twelve scripts). FW.1 zones the embedded spans as
embedded-listing and G.1 scopes its quotation sweeps to Paper 12's
own prose outside Appendix C (both disclosed in the scripts; G.1's
verdict is unchanged: 29 quotations FOUND, 60 inline checked, 14
advisory anomalies). The four source texts are restored to this
tree's `sources/` directory — earlier v2 packages shipped only
`EXTRACT_ULP_ASYMMETRY.md` there and G.1 passed through its
workspace fallbacks; the package is now self-contained at the
root. Suite on the final tree: 12/12 PASS (2026-10-26), and 12/12
again from an extraction of the paper alone into a fresh layout.
This package continues as the convenience copy.

**v3 wish-list build (2026-10-26).** On the author's endorsement of
the external red-team's Round-2 wish list, the paper gains the §8.7
two-level application (script A.10), the §10.4 mode exhibit (script
A.11), the §2.2 reconciliation, the §8.6 conjecture (L8.10-P12), §1.9,
the §5 steelman paragraph (L5.8-P12), and falsification condition C32;
the suite stands at fourteen scripts, all embedded in Appendix C
(manifest of 20 files). The package-anchor wording of §C.1 and of
A.9's coverage statement is corrected in this build: this package's
integrity rests on its own MANIFEST.sha256, whose listed hashes a
copy's enclosed files must match. Suite on the final tree: 14/14
PASS (2026-10-26).

**v4 build (2026-10-26).** On the author's ruling (extend §5; do
not narrow the discharge), after falsification condition C32 fired
under the gold-standard battery GS-1 (attack G8: a named-pair joint
frequency over Appendix D's population that no census or flow count
expresses — witness answers 1/4 and 0 on populations whose finest
census and flow data are identical). The paper gains Definitions
5.7–5.8 and Proposition 5.9 (the three standings; joint counts over
named tuples; marginalization, additivity, and the fourth case),
script A.12, the §6 gloss correction, C32's firing record at §12,
and Appendix E planting the battery as byte-identical exhibits
(verified by A.9's extended protocol); L5.4-P12 is restated over the
extended instrument family. The suite stands at fifteen scripts.
Suite on the final tree: 15/15 PASS (2026-10-26).
