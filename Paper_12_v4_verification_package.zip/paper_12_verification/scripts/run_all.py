#!/usr/bin/env python3
"""run_all.py — Paper 12 verification suite runner.

Runs all nineteen Paper 12 verification scripts (A.1–A.15, FW.1, G.1,
H.1, H.2) as subprocesses, prints each script's PASS/FAIL with its own
verdict line, and finishes with an exit summary. The paper-reading
scripts default to the assembled paper (the Paper_12_v3.md beside
this script's parent directory, in whatever tree the suite is run
from — the staging tree or a layout extracted from Appendix C);
every script is run with no arguments. Exit code 0 iff every script
exits 0.

SELF-CONTAINED NOTE (2026-10-26, disclosed): A.9 (embedded-listing
integrity) joined the suite with the v2 self-contained build, which
embeds these very files in the paper's Appendix C.

V3 NOTE (2026-10-26, disclosed): A.10 (two-level system exhibit,
§8.7) and A.11 (mode exhibit, §10.4) joined the suite with the v3
wish-list build; the suite stands at fourteen scripts.

V4 NOTE (2026-10-26, disclosed): A.12 (joint counts, §5 extension) joined the suite with the v4 build; the suite stands at fifteen scripts.

ROUND-5 NOTE (2026-10-28, disclosed): A.13 (provenance
formalization consistency, §0.4) joined the suite with
corrections round 5; the suite stands at sixteen scripts.

ROUND-6 NOTE (2026-10-28, disclosed): A.14 (population ordering
key, §11.3) and A.15 (the Spine exhibits, Appendix F) joined
the suite with corrections round 6; the suite stands at
eighteen scripts.

ROUND-11 NOTE (2026-10-31, disclosed): H.2 (hybrid split
agreement, provenance vocabulary, badge definedness) joined
the suite with corrections round 11, closing GS-4's Gate 6;
the suite stands at nineteen scripts. An argument selection
that matches no script now refuses (exit 1) instead of
printing a vacuous 0/0 summary.
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = [
    ("A.1", "A1_counting.py"),
    ("A.2", "A2_parallel_tick.py"),
    ("A.3", "A3_orbits.py"),
    ("A.4", "A4_capability.py"),
    ("A.5", "A5_concentration.py"),
    ("A.6", "A6_budgets.py"),
    ("A.7", "A7_exhibit.py"),
    ("A.8", "A8_molecule.py"),
    ("A.9", "A9_listings.py"),
    ("A.10", "A10_two_level.py"),
    ("A.11", "A11_mode_exhibit.py"),
    ("A.12", "A12_joint_counts.py"),
    ("A.13", "A13_provenance.py"),
    ("A.14", "A14_ordering_key.py"),
    ("A.15", "A15_spine.py"),
    ("FW.1", "FW1_firewall.py"),
    ("G.1", "G1_quotes.py"),
    ("H.1", "H1_registry.py"),
    ("H.2", "H2_split_provenance.py"),
]


def main():
    only = sys.argv[1:]
    results = []
    for sid, fname in SCRIPTS:
        if only and sid not in only:
            continue
        proc = subprocess.run([sys.executable, str(HERE / fname)],
                              capture_output=True, text=True)
        verdict = next((ln.strip() for ln in proc.stdout.splitlines()
                        if "VERDICT:" in ln), "(no verdict line printed)")
        ok = proc.returncode == 0
        results.append((sid, ok))
        print(f"{sid:5} {'PASS' if ok else 'FAIL'} "
              f"(exit {proc.returncode}) — {verdict}")
        if not ok:
            print(f"----- {sid} stdout (tail) -----")
            print("\n".join(proc.stdout.splitlines()[-40:]))
            if proc.stderr:
                print(f"----- {sid} stderr (tail) -----")
                print("\n".join(proc.stderr.splitlines()[-20:]))
    if not results:
        print("=" * 70)
        print("run_all SUMMARY: REFUSED — the selection matched "
              "no scripts; an empty selection verifies nothing")
        return 1
    n_ok = sum(1 for _, ok in results if ok)
    print("=" * 70)
    print(f"run_all SUMMARY: {n_ok}/{len(results)} scripts PASS"
          + ("" if n_ok == len(results) else " — FAILURES PRESENT"))
    return 0 if n_ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
