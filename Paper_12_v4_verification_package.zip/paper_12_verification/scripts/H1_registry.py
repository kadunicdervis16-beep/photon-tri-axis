#!/usr/bin/env python3
"""H.1 — Registry Honesty for Paper 12.

Parses every claim entry in the four staging drafts (claim lists at the
ends of sections, DRAFT_D's in-prose claim statements, and Appendix B's
registry rows) and checks:
  (1) BADGE PRESENCE/TAXONOMY: every claim carries a badge recognized
      by §0.2's taxonomy ([LEVEL A], [LEVEL A: MACHINE],
      [LEVEL A: AUTHOR], [LEVEL A: MACHINE / AUTHOR], [CITED],
      [LEVEL B], [Declared assumption], [LEVEL C], [NO BADGE],
      Denied [Level A]) or one of the paper's declared non-grade
      categories ([Definition], [Construction], [Scope statement],
      [AUTHOR], [Worked instance], [Inherited premise], [Receipt]).
      An unrecognized bracket is reported UNRECOGNIZED.
  (2) MACHINE-BADGE GROUNDING: every claim badged [LEVEL A: MACHINE]
      or [LEVEL A: MACHINE / AUTHOR] must name a verifying script, and
      that script must EXIST in the staging scripts directory under
      its series ID (A.1–A.7, FW.1, G.1, H.1). A MACHINE badge naming
      no script,
      or naming a script file that is absent, is reported MISSING.
  (3) SCOPE FIT (heuristic flag only): a MACHINE-badged claim whose
      named script's declared scope (Appendix B's script key) does not
      cover the claim's section is reported SUSPECT. THIS SCRIPT FLAGS;
      IT DOES NOT JUDGE SEMANTICS. Scope fit is a keyword/range table
      written from Appendix B, nothing more — a SUSPECT here is a
      request for human adjudication, and a clean pass here is not a
      proof that the named script checks the claim's actual content
      (registry honesty in the strong sense remains a human audit,
      backed by each A-script's own docstring).
  (4) REGISTRY-vs-HOME BADGE IDENTITY (round 4): every Appendix B
      registry row's badge cell must reproduce the claim's home-site
      badge in full — the exact bracket string of the claim-list entry
      (conditional clauses, premise flags, and script clauses
      included), or, for a split badge (a CITED component and a LEVEL
      component joined in the entry by a 'for the ...; the ... clause
      is' construction), its two components joined by ' / ', derived
      from the entry itself. A duplicate registry row for one claim is
      likewise reported. A shortened or altered registry badge is
      reported REGISTRY-DIFF and fails the run. Home badges are
      extracted from the claim-list entries by the canonical rule:
      the badge bracket inside the bold label where the entry prints
      one there, else the last non-CITED badge bracket of the entry
      (a CITED-only entry's badge is its CITED bracket).
Appendix B rows badged "(target)" are drafting intentions, not badges:
they are inventoried separately as TARGET rows and never counted as
claims carrying badges.

Exit: FAIL if any MISSING or UNRECOGNIZED item exists, or if the
mutant battery misbehaves. SUSPECT items are reported in full and do
not fail the run (they are adjudication requests, per the design).

INPUT_PROVENANCE:
  - Badge taxonomy: class=paper-defined (Paper 12 §0.2, DRAFT_A).
  - Script-scope table: class=paper-defined (Appendix B script key,
    DRAFT_D).
  - Claim entries: class=paper-defined (the four drafts, parsed at
    run time; nothing about their contents is hardcoded).

ASSEMBLY ADJUSTMENT (2026-10-24, disclosed): the parse target is now
chosen in main() — with no argument, the assembled paper
(staging_v1/Paper_12_v1.md), whose claim labels were unified to the
section-scoped L§.n-P12 scheme at assembly and whose Appendix B is
the rebuilt registry; with "--drafts", the four staging drafts (the
original behaviour); with any other argument, that file. The badge
taxonomy, scope table, and mutant battery are untouched.
  - Script existence: class=control (the live contents of
    staging_v1/scripts/ at run time — the suite's own files, the
    apparatus's data).

V2 ADJUSTMENT (2026-10-25, disclosed): the default parse target is
now the v2 assembly (staging_v3/Paper_12_v2.md). Script A.7 (the
Appendix D worked exhibit) is admitted to the script-ID pattern and
to the scope table, with the scope Appendix B's v2 script key assigns
it (§§3–9, the sections the exhibit instantiates). The claim-label
grammar is extended with the LD series (Appendix D claim labels,
LD.n-P12); LD labels carry no section number, so the scope-fit flag
does not apply to them, while badge presence and MACHINE-badge script
grounding are enforced on them exactly as on L-labels. The badge
taxonomy and the mutant battery are unchanged (M1's ghost script is
still A.99, still unmatched).

V2-FINAL ADJUSTMENT (2026-10-25, disclosed): script A.8 (the §11.2
molecule reduction) is admitted to the script-ID pattern and to the
scope table, with the scope Appendix B's script key assigns it (§11).
The parse target, badge taxonomy, and mutant battery are unchanged.

V2 SELF-CONTAINED ADJUSTMENT (2026-10-26, disclosed): script A.9
(Appendix C embedded-listing integrity) is admitted to the script-ID
pattern and to the scope table. The claim-label grammar is extended
with the LC series (Appendix C claim labels, LC.n-P12), handled
exactly like the LD series: LC labels carry no section number, so
the scope-fit flag does not apply to them, while badge presence and
MACHINE-badge script grounding are enforced on them exactly as on
L-labels. A.9's scope entry is therefore the empty set — its claims
live in the appendix, which has no § number. The parse target, badge
taxonomy, and mutant battery are unchanged.

V3 ADJUSTMENT (2026-10-26, disclosed): scripts A.10 (§8.7 two-level
system exhibit) and A.11 (§10.4 mode exhibit) are admitted to the
script-ID pattern and to the scope table, with the scopes
Appendix B's script key assigns them (§8 and §10 respectively). The
parse target, badge taxonomy, and mutant battery are unchanged
(M1's ghost script is still A.99, still unmatched).

ROUND-4 ADJUSTMENT, LOOP REPAIR (2026-10-28, disclosed): the
split-badge case of check (4) is derived structurally from the claim
entry (no hardcoded badge string), and duplicate registry rows are
flagged REGISTRY-DIFF; mutants M5c (duplicate row) and M5d (split
derivation follows a changed home entry) plant both. This closes two
latent loopholes the round-4 loop pass's evil auditor confirmed with
synthetic witnesses; neither was exercised by the tree the check first
ran on.

ROUND-4 ADJUSTMENT (2026-10-28, disclosed): (a) check (4),
registry-vs-home badge identity, is added (see the checks list above),
with planted mutant M5; (b) parse_claims indexes a registry row's
badge and script cells from the end of the row (status, script, badge)
instead of by fixed position, so a claim cell containing '|' (e.g. a
|P| in claim text) cannot shift the badge cell. Behaviour on rows
without '|' in the claim cell is unchanged. The badge taxonomy, scope
table, and mutants M1-M4 are unchanged.

V4 ADJUSTMENT (2026-10-26, disclosed): (a) the script-ID pattern
now admits A.12 (the A-series alternative extended to admit
1[0-2] in place of 1[01]); (b) the scope table gains
"A.12": {5}, the scope Appendix B's script key assigns it; (c)
the claim-label grammar gains the LE series (Appendix E claim
labels, LE.n-P12), handled exactly like the LC/LD series — the
three label regexes in parse_claims are extended with the LE
alternative, and LE labels carry no section number, so the
scope-fit flag does not apply to them, while badge presence and
MACHINE-badge script grounding are enforced on them exactly as
on L-labels; (d) the default parse target is now the v4 assembly
(STAGING / "Paper_12_v4.md"). The badge taxonomy and the mutant
battery are unchanged (M1's ghost script is still A.99, still
unmatched).

ROUND-5 ADJUSTMENT (2026-10-28, disclosed): script A.13
(provenance formalization consistency, §0.4) is admitted to the
script-ID pattern (the A-series alternative extended to admit
1[0-3] in place of 1[0-2]) and to the scope table, with the
scope {0} Appendix B's script key assigns it (its naming site,
§0.4). No claim cites A.13: it is a suite-level check named at
§0.4(b) and in the key, and the scope entry reserves the
identifier and records its home section; the badge taxonomy,
checks, and mutant battery are unchanged.

ROUND-6 ADJUSTMENT (2026-10-28, disclosed): scripts A.14
(population ordering key, §11.3) and A.15 (the Spine exhibits,
Appendix F) are admitted to the script-ID pattern (the A-series
alternative extended to admit 1[0-5] in place of 1[0-3]) and to
the scope table, with the scopes Appendix B's script key assigns
them: A.14 at {11, 12} (claim L11.4-P12 at §11; condition C33 at
§12), A.15 at the empty scope (it is named at Appendix F, which
has no § number, and is cited by no claim — Appendix F registers
none; the entry reserves the identifier, as A.9's entry does for
Appendix C). The badge taxonomy, checks, and mutant battery are
unchanged.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGING = HERE.parent
DRAFT_DIR = STAGING / "draft"
SCRIPTS_DIR = STAGING / "scripts"

TAXONOMY = [
    "LEVEL A: MACHINE / PROOF / AUTHOR", "LEVEL A: MACHINE / PROOF",
    "LEVEL A: MACHINE / AUTHOR", "LEVEL A: MACHINE", "LEVEL A: AUTHOR",
    "LEVEL A", "CITED", "LEVEL B", "LEVEL C",
    "Declared assumption", "NO BADGE", "Denied [Level A]",
    "Definition", "Construction", "Scope statement", "Scope",
    "AUTHOR", "Worked instance", "Inherited premise", "Receipt",
    "Definition — notation", "Construction — Paper 12",
]
SCRIPT_SCOPE = {  # from Appendix B's script key (DRAFT_D; A.7 per v2 key)
    "A.1": {3, 11}, "A.2": {4, 8, 11}, "A.3": {5, 10, 12},
    "A.4": {6, 12}, "A.5": {8, 12}, "A.6": {7, 9, 11, 12},
    "A.7": {3, 4, 5, 6, 7, 8, 9}, "A.8": {11},
    "A.9": set(),   # Appendix C scope: LC labels carry no § number
    "A.10": {8}, "A.11": {10}, "A.12": {5},
    "A.13": {0},  # §0.4 provenance check; named at §0.4(b), cited by no claim
    "A.14": {11, 12},  # §11.3 ordering key; cited by L11.4-P12 and C33
    "A.15": set(),  # Appendix F spine exhibits; named there, cited by no claim
    "FW.1": set(range(0, 14)), "G.1": set(range(0, 14)),
    "H.1": set(range(0, 14)),
    "H.2": set(range(0, 14)),
}
SCRIPT_ID_RE = re.compile(r"\b(FW\.1|G\.1|H\.[12]|A\.(?:[1-9]|1[0-5]))\b")

CLAIMS = []     # (file, line, label, badge_raw, badge_class, entry_text)
PROBLEMS = []   # (kind, file, line, label, detail)
SUSPECTS = []


def badge_class_of(entry):
    """Find the badge in a claim entry. Returns (raw, class) where class
    is the taxonomy entry matched, or None."""
    brackets = re.findall(r"\[([^\]]{2,60})\]", entry)
    for b in brackets:
        bb = b.strip()
        for t in TAXONOMY:
            if bb == t or bb.startswith(t + " ") or bb.startswith(t + " —") \
                    or bb.startswith(t + ",") or bb.startswith(t + ";"):
                return bb, t
    # Badge stated without brackets (Appendix B registry rows only —
    # the fallback must NOT run when brackets exist, or an invented
    # bracket like [LEVEL A++] would substring-match "LEVEL A").
    if not brackets:
        for t in TAXONOMY:
            if t in entry and t.startswith("LEVEL"):
                return t, t
    return (brackets[0] if brackets else None), None


def script_ids_in(entry):
    ids = []
    for m in SCRIPT_ID_RE.finditer(entry):
        sid = m.group(1)
        # exclude dependency-label lookalikes — L-labels are L<n>-P12,
        # never bare A.n; bare "A.3" in prose is a script reference.
        if sid not in ids:
            ids.append(sid)
    return ids


def script_exists(sid):
    prefix = sid.replace(".", "")
    return any(p.name.startswith(prefix + "_") or p.name == prefix + ".py"
               for p in SCRIPTS_DIR.glob("*.py"))


def section_of(label, entry):
    m = re.match(r"L(\d+)\.", label)
    if m:
        return int(m.group(1))
    m = re.match(r"Claim (\d+)\.", label)
    if m:
        return int(m.group(1))
    return None


def parse_claims(fname, lines):
    """Claim entries: '- **Label** ...' bullets (with wrapped
    continuation lines), DRAFT_D's '**Claim L.. [badge].**' in-prose
    statements, and Appendix B table rows."""
    entries = []
    i = 0
    while i < len(lines):
        ln = lines[i]
        m = re.match(r"\s*-\s+\*\*(Claim [\d.]+|L[\d.]+-P12|LD[\d.]+-P12|LC[\d.]+-P12|LE[\d.]+-P12|OR-\d+)\*\*", ln)
        m2 = re.match(r"\s*-\s+\*\*(Claim (L[\d.]+-P12|LD[\d.]+-P12|LC[\d.]+-P12|LE[\d.]+-P12)|L[\d.]+-P12|LD[\d.]+-P12|LC[\d.]+-P12|LE[\d.]+-P12)\s", ln)
        m3 = re.match(r".*\*\*Claim (L[\d.]+-P12|LD[\d.]+-P12|LC[\d.]+-P12|LE[\d.]+-P12)\s", ln)
        hit = m or m2 or m3
        if hit:
            label = (m.group(1) if m else None) or \
                    (m2.group(1) if m2 else None) or m3.group(1)
            text = [ln]
            j = i + 1
            while j < len(lines) and lines[j].strip() and \
                    not re.match(r"\s*(-\s|#{1,4}\s|\||---)", lines[j]):
                text.append(lines[j])
                j += 1
            entries.append((i + 1, label.replace("Claim ", ""), "\n".join(text)))
            i = j
            continue
        if ln.strip().startswith("| L") and "-P12" in ln:
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if len(cells) >= 4:
                label = cells[0].replace("\\", "")
                entries.append((i + 1, label,
                                f"REGISTRY-ROW badge={cells[-3]} "
                                f"script={cells[-2]}"))
        i += 1
    return entries


BADGE_KW = ("LEVEL", "CITED", "Definition", "Construction",
            "Scope statement", "Scope", "AUTHOR", "Receipt",
            "Inherited premise", "Worked instance", "Denied",
            "NO BADGE", "OPEN RULING")


def canonical_home_badge(label, entry):
    """The claim's home-site badge, as a full bracket string, by the
    canonical rule of check (4). Returns None if no badge bracket is
    found."""
    first = entry.splitlines()[0] if entry else ""
    m = re.match(r"\s*-\s+\*\*(?:Claim )?" + re.escape(label) +
                 r"\s+\[([^\]]+)\]\*\*", first)
    if m:
        return "[" + re.sub(r"\s+", " ", m.group(1)).strip() + "]"
    joined = re.sub(r"\s+", " ", entry)
    brackets = re.findall(r"\[([^\]]{2,240})\]", joined)
    cand = [b.strip() for b in brackets if b.strip().startswith(BADGE_KW)]
    noncited = [b for b in cand if not b.startswith("CITED")]
    # Split-badge entries: a CITED component for one clause and a LEVEL
    # component for another, joined in the text by a 'for the ...; the
    # ... clause is' construction. The canonical badge is the two
    # components joined by ' / ', DERIVED from the entry — never a
    # hardcoded string, so a home-side edit to either component is
    # seen by check (4).
    if cand and cand[0].startswith("CITED") and noncited:
        spans = [m.span() for m in
                 re.finditer(r"\[[^\]]{2,240}\]", joined)]
        cand_spans = [(s, b) for s, b in zip(spans, brackets)
                      if b.strip().startswith(BADGE_KW)]
        first_cited = next(s for s, b in cand_spans
                           if b.strip().startswith("CITED"))
        first_level = next((s for s, b in cand_spans
                            if not b.strip().startswith("CITED")), None)
        if first_level is not None and first_cited[0] < first_level[0]:
            between = joined[first_cited[1]:first_level[0]]
            if re.search(r"for the .*; the .* clause is", between):
                return "[" + cand[0] + "] / [" + noncited[-1] + "]"
    if noncited:
        return "[" + noncited[-1] + "]"
    if cand:
        return "[" + cand[-1] + "]"
    return None


def reg_assign(reg_map, label, badge):
    """Record a registry row's badge. Returns an error string if the
    label already has a registry row (a duplicate row is a registry
    defect, whatever its badge), else None."""
    if label in reg_map:
        return (f"duplicate registry row for {label} "
                f"(badges {reg_map[label]!r} and {badge!r})")
    reg_map[label] = badge
    return None


def badge_identity_problems(home_map, reg_map):
    """Pure comparison for check (4): returns (label, home, registry)
    triples whose badge strings differ, plus labels present on only
    one side."""
    out = []
    for lab in sorted(set(home_map) | set(reg_map)):
        h, r = home_map.get(lab), reg_map.get(lab)
        if h != r:
            out.append((lab, h, r))
    return out


def audit_entry(fname, lno, label, entry):
    raw, cls = badge_class_of(entry)
    is_row = entry.startswith("REGISTRY-ROW")
    if "(target)" in entry or (is_row and "target" in entry):
        CLAIMS.append((fname, lno, label, raw, "TARGET", entry))
        return
    if label.startswith("OR-"):
        CLAIMS.append((fname, lno, label, raw, "OPEN RULING", entry))
        return
    if cls is None:
        PROBLEMS.append(("UNRECOGNIZED", fname, lno, label,
                         f"badge bracket found: {raw!r}"))
        CLAIMS.append((fname, lno, label, raw, None, entry))
        return
    CLAIMS.append((fname, lno, label, raw, cls, entry))
    if cls in ("LEVEL A: MACHINE", "LEVEL A: MACHINE / AUTHOR"):
        ids = script_ids_in(entry)
        if not ids:
            PROBLEMS.append(("MISSING", fname, lno, label,
                             f"badged [{cls}] but names no verifying script"))
            return
        for sid in ids:
            if not script_exists(sid):
                PROBLEMS.append(("MISSING", fname, lno, label,
                                 f"names script {sid}, absent from "
                                 f"the staging scripts directory"))
        sec = section_of(label, entry)
        in_scope = any(sec in SCRIPT_SCOPE.get(sid, set()) for sid in ids)
        if sec is not None and not in_scope:
            SUSPECTS.append((fname, lno, label,
                             f"[{cls}] names {ids}; Appendix B scope table "
                             f"places none of them over §{sec} — human "
                             f"adjudication requested"))


def mutant_battery():
    print("PLANTED MUTANT BATTERY")
    ok = True
    tests = []
    ghost = ("L99.1-P12 [LEVEL A: MACHINE] — verified by script A.99.",
             )
    raw, cls = badge_class_of(ghost[0])
    ids = script_ids_in(ghost[0])
    ghost_flagged = cls == "LEVEL A: MACHINE" and ids == [] or \
        any(not script_exists(s) for s in ids if s in SCRIPT_SCOPE)
    tests.append(("M1 MACHINE badge, no such script (A.99)",
                  ghost_flagged))
    bare = "L99.2-P12 — A claim with no badge at all."
    raw2, cls2 = badge_class_of(bare)
    tests.append(("M2 badgeless claim detected", cls2 is None))
    funny = "L99.3-P12 [LEVEL A++] — An invented badge."
    raw3, cls3 = badge_class_of(funny)
    tests.append(("M3 invented badge [LEVEL A++] unrecognized", cls3 is None))
    scope_entry = "L3.9-P12 [LEVEL A: MACHINE] — census claim, script A.4."
    sec = section_of("L3.9-P12", scope_entry)
    ids4 = script_ids_in(scope_entry)
    tests.append(("M4 scope mismatch flagged (A.4 over §3)",
                  sec == 3 and not any(sec in SCRIPT_SCOPE[s] for s in ids4)))
    short = badge_identity_problems(
        {"L99.4-P12": "[LEVEL A — conditional on Paper 11 §4.3]"},
        {"L99.4-P12": "[LEVEL A]"})
    tests.append(("M5 registry short form flagged (REGISTRY-DIFF)",
                  short == [("L99.4-P12",
                             "[LEVEL A — conditional on Paper 11 §4.3]",
                             "[LEVEL A]")]))
    same = badge_identity_problems(
        {"L99.5-P12": "[LEVEL A: MACHINE — script A.3]"},
        {"L99.5-P12": "[LEVEL A: MACHINE — script A.3]"})
    tests.append(("M5b identical registry badge passes", same == []))
    dup_map = {}
    e1 = reg_assign(dup_map, "L99.6-P12", "[LEVEL A]")
    e2 = reg_assign(dup_map, "L99.6-P12",
                    "[LEVEL A — conditional on Paper 11 §4.3]")
    tests.append(("M5c duplicate registry row flagged",
                  e1 is None and e2 is not None))
    split_entry = ("- **L2.3-P12** — Budgets received. "
                   "**[CITED — L9-P12]** for the budget rules; the "
                   "\"no aggregate budget rule\" clause is **[LEVEL B]** "
                   "by inheritance.")
    tests.append(("M5d split badge derived from the entry, not "
                  "hardcoded",
                  canonical_home_badge("L2.3-P12", split_entry) ==
                  "[CITED — L9-P12] / [LEVEL B]"))
    for name, passed in tests:
        ok &= passed
        print(f"  [{'PASS' if passed else 'FAIL'}] {name}")
    return ok


def main():
    print("=" * 70)
    print("H.1 — REGISTRY HONESTY (Paper 12 claim lists vs §0 taxonomy "
          "and the script tree)")
    print("=" * 70)
    args = sys.argv[1:]
    if args and args[0] == "--drafts":
        files = sorted(DRAFT_DIR.glob("DRAFT_*.md"))
    elif args:
        files = [Path(args[0])]
    else:
        files = [STAGING / "Paper_12_v4.md"]
    for f in files:
        lines = f.read_text(encoding="utf-8").splitlines()
        parsed = parse_claims(f.name, lines)
        for lno, label, entry in parsed:
            audit_entry(f.name, lno, label, entry)
        # Check (4): registry-vs-home badge identity. The registry is
        # the Appendix B span; home entries are the claim lists
        # outside it. (Drafts mode has no Appendix B span; skipped.)
        appb = next((k + 1 for k, l in enumerate(lines)
                     if l.startswith("## Appendix B.")), None)
        appc = next((k + 1 for k, l in enumerate(lines)
                     if l.startswith("## Appendix C.")), None)
        if appb is not None and appc is not None:
            home_map, reg_map = {}, {}
            for lno, label, entry in parsed:
                if label.startswith("OR-"):
                    continue  # ruling entries, not claims; no badge cell
                if entry.startswith("REGISTRY-ROW"):
                    if appb < lno < appc:
                        mb = re.search(r"badge=(.*) script=", entry)
                        err = reg_assign(reg_map, label,
                                         mb.group(1) if mb else None)
                        if err:
                            PROBLEMS.append(("REGISTRY-DIFF", f.name,
                                             lno, label, err))
                elif not (appb < lno < appc):
                    b = canonical_home_badge(label, entry)
                    if label in home_map and home_map[label] != b:
                        PROBLEMS.append(
                            ("REGISTRY-DIFF", f.name, lno, label,
                             f"home badge not unique: {home_map[label]!r} "
                             f"vs {b!r}"))
                    home_map[label] = b
            for lab, h, r in badge_identity_problems(home_map, reg_map):
                PROBLEMS.append(
                    ("REGISTRY-DIFF", f.name, 0, lab,
                     f"registry badge {r!r} != home badge {h!r}"))
    from collections import Counter
    counts = Counter(c[4] for c in CLAIMS if c[4])
    print(f"Claim entries parsed: {len(CLAIMS)}")
    print("Inventory by badge class:")
    for cls, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {cls}: {n}")
    print("\nFull claim inventory:")
    for fname, lno, label, raw, cls, entry in CLAIMS:
        print(f"  {fname}:{lno} {label} [{cls}]")
    if PROBLEMS:
        print("\nPROBLEMS (MISSING / UNRECOGNIZED / REGISTRY-DIFF):")
        for kind, fname, lno, label, detail in PROBLEMS:
            print(f"  [{kind}] {fname}:{lno} {label} — {detail}")
    if SUSPECTS:
        print("\nSUSPECT (scope-fit flags — adjudication requests, "
              "not verdicts):")
        for fname, lno, label, detail in SUSPECTS:
            print(f"  [SUSPECT] {fname}:{lno} {label} — {detail}")
    mutants_ok = mutant_battery()
    print("=" * 70)
    if PROBLEMS or not mutants_ok:
        print(f"H.1 VERDICT: FAIL — {len(PROBLEMS)} problem(s)"
              + ("" if mutants_ok else "; mutant battery failed"))
        return 1
    print(f"H.1 VERDICT: PASS — every claim carries a taxonomy badge; "
          f"every MACHINE-badged claim names an existing script; every "
          f"Appendix B registry badge reproduces its home-site badge in "
          f"full (check 4); {len(SUSPECTS)} SUSPECT scope flag(s) listed "
          f"for human adjudication.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
