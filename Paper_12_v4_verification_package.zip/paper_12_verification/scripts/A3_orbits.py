#!/usr/bin/env python3
"""A.3 — Orbit decomposition and census frequencies: exact rationals.

Verifies Paper 12 §5 Proposition 5.3(iii) (long-run frequencies are period
counts c_X / ell of the eventually periodic aggregate trajectory) and
§10 claims L10.1-P12 / L10.2-P12 (every trajectory of a finite population
under a total deterministic tick decomposes into an exact pre-period p
and cycle length c; per-cycle visit frequency of each record on the
cycle is the exact rational 1/c; records off the cycle have long-run
frequency 0).

WHAT IS COMPUTED (never restated as its own input):
  - The junction operator T is implemented from Paper 11 §7.5's rule
    (canonically first admissible index k with A[k] = -B[k] != 0 is
    zeroed; tau drops by exactly 2 per action) and the decomposition
    (p, c) of every trajectory is COMPUTED from T's transition table.
  - Two independent routes compute the decomposition and must agree on
    every state:
      ORACLE 1 (brute force): per-start trajectory iteration with a
        visited-index map; the first repeated state gives (p, c).
      ORACLE 2 (decomposition arithmetic): global functional-graph
        decomposition — indegree peeling isolates the cycle nodes,
        cycles are walked and measured, transient depths come from a
        reverse-adjacency BFS. No per-start iteration is used.
  - Frequencies are checked as census ratios (Paper 12 §5's form):
    over a window of whole periods taken after the pre-period, the
    count of visits to a class X divided by the window length must
    equal the exact Fraction c_X / c predicted by the decomposition,
    and 1/c for each single record on the cycle, 0 for records off it.

SYSTEMS EXERCISED:
  - T-systems: one junction with m = 1, 2, 3 ports; port values in
    {-1, 0, +1} (unit port values, Paper 11 §7.5: a^2 = 1). State
    counts 9, 81, 729. For T alone every cycle is a fixed point
    (tau strictly drops by 2 until no admissible pair remains) — the
    script verifies that too, rather than assuming it.
  - Multi-junction T_agg systems (round 11): the aggregate tick on
    two junctions at m = 1 and m = 2 (81 and 6,561 states) and on
    three junctions at m = 1 (729 states), in full — the transition
    applies T at every junction (Definition 4.1, over junctions
    sharing no ports by construction). Plus the length-0 system:
    one state, the empty record's constant trajectory.
  - Declared toy transition systems (controls) with genuine cycles of
    length > 1, standing in for the §10 aggregate setting where
    re-presentation across junctions sustains cycles:
      TOY1: a 2-cycle {2,3} fed by two transient tails.
      TOY2: a 5-cycle fed by a two-state tail.
      TOY3: T with a declared re-presentation control on the m=1
        junction (a fixed point with no presented pair is re-presented
        as (1,-1); other fixed points collapse to (0,0)) — a T-based
        system with a genuine 2-cycle, declared here as a control,
        NOT a Paper 11 rule.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: §5 Prop 5.3(iii) and §10 L10.1/L10.2 over
      arbitrary finite populations under T_agg.
  (2) Verified domain: the finite systems above (single-junction
      T-systems in full, the multi-junction T_agg systems named
      above in full, three declared toy systems in full).
  (3) Map: population state -> state of the finite transition system;
      aggregate tick -> the system's transition function (for the
      T-systems, T itself applied at the population's one junction).
  (4) Preserved: determinism, totality, finiteness — the only three
      properties the (p, c) argument (Paper 12 §5 proof of (iii))
      consumes.
  (5) Outside the machine check: that T_agg on a many-junction
      population is well-defined and deterministic (that is Theorem
      4.2, script A.2's remit); populations beyond the enumerated
      junction counts and port lengths are not enumerated here —
      their eventual periodicity in general is §10.1's prose
      argument (the PROOF component of L10.1-P12). The badge this
      script supports is the decomposition/frequency arithmetic,
      conditional on A.2.

INPUT_PROVENANCE:
  - T's rule (admissible iff A[k] = -B[k] != 0; zero the canonically
    first admissible pair; tau = sum of squares of presented entries,
    dropping by exactly 2 per action): class=cited-paper
    (Paper 11 §7.5).
  - Port values in {-1, 0, +1}: class=cited-paper (Paper 11 §7.5 —
    unit port values; the admissible pair contributes 2*a^2 = 2).
  - Proposition 5.3(iii) frequency form c_X / ell and §10's 1/c
    per-record frequency: class=paper-defined (Paper 12 §5, §10) —
    these are the PREDICTIONS UNDER TEST, computed against below,
    never used as inputs to the computation.
  - TOY1, TOY2 transition tables: class=control (declared toy systems,
    chosen to exhibit cycles of length 2 and 5 with transient tails).
  - TOY3 re-presentation rule: class=control (declared toy rule
    layered on T; not a framework rule).
  - The multi-junction T_agg systems' construction (independent
    junctions, T applied at each): class=paper-defined
    (Definition 4.1's aggregate tick over disjoint junctions).
  - Mutant RNG seed: class=control (seeded Mersenne Twister, integer
    draws only).
"""
import itertools
import random
import sys
from collections import Counter, deque
from fractions import Fraction


# ---------------------------------------------------------------- T systems

def tau(state):
    A, B = state
    return sum(a * a for a in A) + sum(b * b for b in B)


def admissible_indices(state):
    A, B = state
    return [k for k in range(len(A)) if A[k] != 0 and A[k] == -B[k]]


def T_step(state):
    """Paper 11 §7.5: zero the canonically FIRST admissible pair."""
    adm = admissible_indices(state)
    if not adm:
        return state
    k = adm[0]
    A, B = list(state[0]), list(state[1])
    A[k] = 0
    B[k] = 0
    return (tuple(A), tuple(B))


def T_system(m):
    """Full transition table of T on one m-port junction."""
    values = (-1, 0, 1)
    states = []

    def build(prefix, depth):
        if depth == 0:
            states.append(tuple(prefix))
            return
        for v in values:
            build(prefix + [v], depth - 1)

    ports = []
    build(ports, m)
    full = [(A, B) for A in states for B in states]
    return {s: T_step(s) for s in full}


def T_agg_system(m, n_junctions):
    """Full transition table of the aggregate tick T_agg on
    n_junctions independent junctions of port-vector length m
    (round 11): states are tuples of per-junction local states;
    the tick applies T at every junction (Definition 4.1 over
    junctions sharing no ports, by construction)."""
    single = T_system(m)
    states = list(single)
    return {combo: tuple(single[s] for s in combo)
            for combo in itertools.product(states,
                                           repeat=n_junctions)}


TOY1 = {0: 1, 1: 2, 2: 3, 3: 2, 4: 3}                    # cycle {2,3}, c=2
TOY2 = {0: 1, 1: 2, 2: 3, 3: 4, 4: 0, 5: 2, 6: 5}        # 5-cycle, tails 6->5->2


def TOY3_system():
    """T on the m=1 junction plus a declared re-presentation control."""
    base = T_system(1)
    out = {}
    for s, nxt in base.items():
        if nxt == s:  # fixed point of T
            if s == ((0,), (0,)):
                out[s] = ((1,), (-1,))       # re-present a fresh pair
            else:
                out[s] = ((0,), (0,))       # collapse to the rest state
        else:
            out[s] = nxt
    return out


# ------------------------------------------------------- decomposition routes

def decompose_bruteforce(trans, start):
    """ORACLE 1: iterate from start; first repeated state gives (p, c)
    and the cycle as an ordered list."""
    seen = {}
    path = []
    s = start
    while s not in seen:
        seen[s] = len(path)
        path.append(s)
        s = trans[s]
    p = seen[s]
    cycle = path[p:]
    return p, len(cycle), cycle


def decompose_global(trans):
    """ORACLE 2: functional-graph decomposition without per-start
    iteration. Indegree peeling isolates cycle nodes; cycles are then
    walked and measured; every node's depth-to-cycle and cycle id come
    from a reverse-adjacency BFS. Returns {state: (p, c, cycle_id)}."""
    indeg = {s: 0 for s in trans}
    radj = {s: [] for s in trans}
    for s, nxt in trans.items():
        indeg[nxt] += 1
        radj[nxt].append(s)
    queue = deque([s for s in trans if indeg[s] == 0])
    on_cycle = {s: True for s in trans}
    while queue:
        s = queue.popleft()
        on_cycle[s] = False
        nxt = trans[s]
        indeg[nxt] -= 1
        if indeg[nxt] == 0:
            queue.append(nxt)
    # walk each cycle once, assign ids and lengths
    cycle_id = {}
    cycle_len = {}
    cid = 0
    for s in trans:
        if on_cycle[s] and s not in cycle_id:
            cur, members = s, []
            while cur not in cycle_id:
                cycle_id[cur] = cid
                members.append(cur)
                cur = trans[cur]
            for m_ in members:
                cycle_len[m_] = len(members)
            cid += 1
    # depths: BFS outward over reverse edges from all cycle nodes
    depth = {s: 0 for s in trans if on_cycle[s]}
    owner = {s: cycle_id[s] for s in trans if on_cycle[s]}
    queue = deque(depth.keys())
    while queue:
        s = queue.popleft()
        for pre in radj[s]:
            if pre not in depth:
                depth[pre] = depth[s] + 1
                owner[pre] = owner[s]
                queue.append(pre)
    result = {}
    for s in trans:
        c = cycle_len[s] if on_cycle[s] else None
        if not on_cycle[s]:
            # length of the cycle this transient drains into
            cur = s
            while not on_cycle[cur]:
                cur = trans[cur]
            c = cycle_len[cur]
        result[s] = (depth[s], c, owner[s])
    return result


# ------------------------------------------------------------- frequency form

def check_system(name, trans, feature=None):
    """Full check of one finite deterministic system. Returns True iff
    every check passes. `feature` maps a state to a ledger-data class
    label; every feature class is checked in the c_X / c form of
    Proposition 5.3(iii). Default feature: the state's tau value for
    T-systems, the state itself mod 2 for integer toy states — set by
    the caller."""
    if not trans:
        print(f"  [{name}] REFUSED: the empty transition system "
              "is not a system of a declared population — no "
              "states, no trajectories; the decomposition claims "
              "quantify over declared finite populations, whose "
              "record sets are nonempty by construction")
        return False
    ok = True
    glob = decompose_global(trans)
    n_cycle_nodes = 0
    n_transient = 0
    for start in trans:
        p1, c1, cycle = decompose_bruteforce(trans, start)
        p2, c2, _cid = glob[start]
        if (p1, c1) != (p2, c2):
            print(f"  [{name}] DECOMPOSITION DISAGREEMENT at {start}: "
                  f"brute force (p={p1}, c={c1}) vs global (p={p2}, c={c2})")
            ok = False
        if p1 == 0:
            n_cycle_nodes += 1
        else:
            n_transient += 1
        # --- census-frequency check, Proposition 5.3(iii) form ---
        # Window: K whole periods after the pre-period. Count visits.
        K = 5
        traj = [start]
        for _ in range(p1 + K * c1):
            traj.append(trans[traj[-1]])
        window = traj[p1:p1 + K * c1]
        counts = Counter(window)
        cycset = set(cycle)
        for x in trans:
            observed = Fraction(counts.get(x, 0), len(window))
            if x in cycset:
                predicted = Fraction(1, c1)
            else:
                predicted = Fraction(0)
            if observed != predicted:
                print(f"  [{name}] FREQUENCY MISMATCH from {start}: record "
                      f"{x}: window census ratio {observed} != predicted "
                      f"{predicted} (p={p1}, c={c1})")
                ok = False
        # class form (Prop 5.3(iii)): for EVERY feature class X,
        # c_X / c — c_X = number of cycle records standing in X —
        # must equal the window census ratio for X exactly.
        if feature is not None:
            for label in {feature(x) for x in trans}:
                c_X = len([x for x in cycle if feature(x) == label])
                class_observed = Fraction(
                    sum(cnt for x, cnt in counts.items()
                        if feature(x) == label), len(window))
                if class_observed != Fraction(c_X, c1):
                    print(f"  [{name}] CLASS FREQUENCY MISMATCH from "
                          f"{start}, class {label!r}: {class_observed} "
                          f"!= c_X/c = {Fraction(c_X, c1)}")
                    ok = False
    print(f"  [{name}] {len(trans)} states: {n_cycle_nodes} on cycles, "
          f"{n_transient} transient; oracles agree on every (p, c); "
          f"window census ratios match 1/c and 0 exactly "
          f"[{'OK' if ok else 'FAIL'}]")
    return ok


# ------------------------------------------------------------------- mutant

def planted_mutants(T_trans):
    """Mutant: a NON-deterministic variant of T that zeroes a uniformly
    random admissible pair instead of the canonically first. §5's
    frequency form is a statement about THE deterministic dynamics;
    the mutant's census ratios over the same windows must FAIL to
    match the exact Fractions the decomposition predicts, with a
    printed witness."""
    print("\n--- PLANTED MUTANT ---")
    rng = random.Random(20261024)

    def T_mut(state):
        adm = admissible_indices(state)
        if not adm:
            return state
        k = adm[rng.randrange(len(adm))]
        A, B = list(state[0]), list(state[1])
        A[k] = 0
        B[k] = 0
        return (tuple(A), tuple(B))

    # Start with both ports admissible: canonical T zeroes k=0 first.
    start = ((1, 1), (-1, -1))
    p, c, cycle = decompose_bruteforce(T_trans, start)
    # Canonical census over window [0, p + 3c):
    W = p + 3 * c
    canon = [start]
    for _ in range(W - 1):
        canon.append(T_trans[canon[-1]])
    canon_counts = Counter(canon)
    # Mutant census over the same window (repeat trials until the
    # mutant takes the non-canonical branch at least once — seeded,
    # so this terminates deterministically).
    witness = None
    for _trial in range(200):
        mut = [start]
        for _ in range(W - 1):
            mut.append(T_mut(mut[-1]))
        if mut != canon:
            mut_counts = Counter(mut)
            for x in set(canon) | set(mut):
                if canon_counts.get(x, 0) != mut_counts.get(x, 0):
                    witness = (x, Fraction(canon_counts.get(x, 0), W),
                               Fraction(mut_counts.get(x, 0), W),
                               canon[1], mut[1])
                    break
        if witness:
            break
    caught = witness is not None
    if caught:
        x, pred, obs, canon1, mut1 = witness
        print(f"  [CAUGHT] M1: non-deterministic T (random admissible pair) "
              f"breaks frequency exactness.")
        print(f"           witness: from start {start}, canonical tick-1 "
              f"state {canon1} vs mutant tick-1 state {mut1};")
        print(f"           record {x}: deterministic census ratio over "
              f"window {W} = {pred}, mutant ratio = {obs} — the exact "
              f"Fraction of Prop 5.3(iii) does not survive replacing "
              f"the canonical-first rule with a draw.")
    else:
        print("  [NOT CAUGHT — INVESTIGATE] M1: mutant trajectories never "
              "diverged from the canonical one in 200 seeded trials.")
    return caught


# --------------------------------------------------------------------- main

def main():
    print("=" * 70)
    print("A.3 — ORBIT DECOMPOSITION AND CENSUS FREQUENCIES (Paper 12 §5, §10)")
    print("  Dual oracle: brute-force trajectory iteration vs global")
    print("  functional-graph decomposition; all frequencies exact Fractions.")
    print("=" * 70)
    all_ok = True

    print("\n--- Step 1: T-systems (Paper 11 §7.5 junction operator) ---")
    T_tables = {}
    for m in (1, 2, 3):
        trans = T_system(m)
        T_tables[m] = trans
        # tau accounting on EVERY transition: drop exactly 2 iff an
        # admissible pair exists, else the state is a fixed point.
        step_ok = True
        for s, nxt in trans.items():
            adm = admissible_indices(s)
            if adm:
                if tau(s) - tau(nxt) != 2:
                    print(f"  [T m={m}] TAU DROP != 2 at {s}: "
                          f"{tau(s)} -> {tau(nxt)}")
                    step_ok = False
                if nxt == s:
                    print(f"  [T m={m}] ADMISSIBLE BUT UNMOVED at {s}")
                    step_ok = False
            else:
                if nxt != s:
                    print(f"  [T m={m}] NO ADMISSIBLE PAIR BUT MOVED at {s}")
                    step_ok = False
        # T alone: every cycle must be a fixed point (tau argument).
        glob = decompose_global(trans)
        for s in trans:
            if glob[s][0] == 0 and trans[s] != s:
                print(f"  [T m={m}] NON-FIXED CYCLE STATE at {s} — "
                      f"T alone should have only fixed-point cycles")
                step_ok = False
        print(f"  [T m={m}] tau drops by exactly 2 per action on all "
              f"{len(trans)} states; no-admissible-pair <=> fixed point; "
              f"all cycles are fixed points [{'OK' if step_ok else 'FAIL'}]")
        all_ok &= step_ok
        all_ok &= check_system(f"T m={m}", trans,
                               feature=lambda s: tau(s) % 3)

    print("\n--- Step 2: declared toy systems with genuine cycles (§10) ---")
    all_ok &= check_system("TOY1 (c=2)", TOY1, feature=lambda s: s % 2)
    all_ok &= check_system("TOY2 (c=5)", TOY2, feature=lambda s: s % 2)
    toy3 = TOY3_system()
    glob3 = decompose_global(toy3)
    cycle_lens = sorted({glob3[s][1] for s in toy3 if glob3[s][0] == 0})
    print(f"  [TOY3] T + declared re-presentation: cycle lengths present "
          f"= {cycle_lens} (a genuine cycle of length > 1 exists: "
          f"{any(c > 1 for c in cycle_lens)})")
    if not any(c > 1 for c in cycle_lens):
        print("  [TOY3] FAIL: re-presentation control produced no cycle > 1")
        all_ok = False
    all_ok &= check_system("TOY3 (T + re-presentation)", toy3,
                           feature=lambda s: tau(s))


    print("\n--- Step 2b: multi-junction T_agg systems (round 11) ---")
    for (m, nj) in ((1, 2), (2, 2), (1, 3)):
        trans = T_agg_system(m, nj)
        glob = decompose_global(trans)
        fixed_ok = all(trans[s] == s for s in trans
                       if glob[s][0] == 0)
        print(f"  [T_agg m={m}, junctions={nj}] {len(trans)} states "
              f"in full; every cycle a fixed point: {fixed_ok}")
        all_ok &= fixed_ok
        all_ok &= check_system(
            f"T_agg m={m} x{nj}", trans,
            feature=lambda s: sum(tau(x) for x in s) % 3)
    t0 = T_system(0)
    print(f"  [T m=0] the length-0 system: {len(t0)} state, the "
          "empty record's constant trajectory, (p, c) = (0, 1)")
    all_ok &= (len(t0) == 1
               and check_system("T m=0 (length-0)", t0,
                                feature=lambda s: 0))
    empty_refused = check_system("empty system (planted)", {}) is False
    print(f"  [empty system] refused, not passed vacuously: "
          f"{empty_refused}")
    all_ok &= empty_refused

    mutants_ok = planted_mutants(T_tables[2])

    print("\n" + "=" * 70)
    if all_ok and mutants_ok:
        print("A.3 VERDICT: PASS — pre-period/cycle decompositions computed")
        print("  exactly and identically by two independent routes on every")
        print("  state of every system; on-cycle long-run frequency is the")
        print("  exact Fraction 1/c, transient frequency exactly 0, and")
        print("  window census ratios match Prop 5.3(iii)'s c_X/c form.")
        print("  T's tau drops by exactly 2 per action everywhere checked.")
        return 0
    print("A.3 VERDICT: FAIL — see witness lines above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
