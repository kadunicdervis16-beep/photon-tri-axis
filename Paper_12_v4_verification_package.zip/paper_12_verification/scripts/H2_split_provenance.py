#!/usr/bin/env python3
"""H.2 — HYBRID SPLIT AGREEMENT, PROVENANCE VOCABULARY, AND BADGE
DEFINEDNESS (Paper 12).

Built in corrections round 11 (2026-10-31) to close GS-4's Gate 6,
whose test-correspondence limb failed: three defect shapes had
recurred across rounds while every checker compared less than the
claim's text — a hybrid claim's component split diverging between
its home entry and its registry row (the F-042 shape: H.1 compared
badge strings only), a compound INPUT_PROVENANCE binding carrying a
per-member class its named via-source does not carry (the round-9
A.15 shape), and a class token outside the provenance regime's
vocabulary passing silently (the round-10 A.14 'declared-
representative' shape). This script checks those three shapes
mechanically, plus the definedness of every badge family in §0.2.

WHAT IS CHECKED:
  (i) SPLIT AGREEMENT. Every hybrid claim ([LEVEL A: MACHINE /
      AUTHOR], [LEVEL A: MACHINE / PROOF / AUTHOR],
      [LEVEL A: MACHINE / PROOF]) carries a component split at its
      home entry and at its Appendix B registry row (most carry a
      third surface, the section claim list). H.2 extracts every
      surface's split and asserts: the surfaces agree exactly
      (whitespace-normalized); the split's components are exactly
      the badge's components; every component segment is
      non-empty; the MACHINE component names a script of the
      suite. A hybrid entry with no split, or a split on a
      non-hybrid entry, is a problem.
  (ii) PROVENANCE. Every suite script's INPUT_PROVENANCE block is
      parsed binding by binding. Every class token must belong to
      the regime vocabulary (paper-defined / cited-paper /
      control / declared-assumption / arbitrary-representative /
      declared exhibit data); a class token followed by
      anything else is a problem, printed with its token. A
      class token trailed by a further class-like word (a
      compound the vocabulary does not name) is likewise a
      problem. Where a binding names a via-source in the suite
      ('via the suite's own A.12', 'via A.15's block'), every
      class token on that binding must appear somewhere in the
      via-source's own block — class-set membership, not a
      per-binding correspondence (see WHAT STAYS OUTSIDE).
  (iii) BADGE DEFINEDNESS. Every badge used at a claim entry or
      registry row (body through Appendix B) must be defined in
      §0.2: its head form (the badge text up to the first ' — '
      or '; ' tail) must occur among the bracket forms printed
      in bold in §0.2's span. The check runs over the extracted
      entries and, since repair batch 2, over a whole-prose
      census as well: every badge-shaped bracket anywhere in
      the paper's prose (embedded blocks blanked; §0.2's own
      span excluded, since the taxonomy's home legitimately
      mentions foreign forms) must reduce to a defined head —
      the in-prose derivation badges of §§3–11 included. An
      undefined family henceforth fails mechanically instead of
      awaiting a reader.

THE MAP (native -> verified): claim entries are extracted in the
shapes Appendix B's own key discloses (labelled bullets with
wrapped continuations, in-prose '**Claim L..**' statements with
their paragraphs, registry rows with wrapped cells joined). A
split is captured from 'Component split —' to the end of its
entry; a registry row's trailing cells and a claim-list entry's
trailing cross-reference tag ('(A.3)', '(L10.1-P12)') are
furniture and are stripped before comparison, as is one
trailing periods (an entry's final punctuation). A split-bearing
plain paragraph — a claim's verdict paragraph at its home
section — attributes to the nearest preceding claim entry.
Provenance blocks
are read from the scripts in this directory (run_all.py, the
runner, carries no block and is exempt, as are the listings in
Appendix C, which are data copies of these same files). The
scan domain for (i) and (iii) is the paper's prose throughout:
only the embedded BEGIN..END blocks are blanked as data, so
Appendix C's own claim entries (LC.1/LC.2) and Appendix E's
prose stand inside the checks.

WHAT STAYS OUTSIDE: whether an allocation both surfaces share is
semantically right — agreement is mechanical; the allocation
itself was settled claim by claim by the author's ruling-2
census (2026-10-31) and stands as human-audited text. Whether a
via-source's own class is honestly earned is the F.49 regime's
audit surface, not this script's; and (ii)'s via-consistency
is class-set membership — that a citing binding's class is the
class its via-source assigns to the corresponding binding is
a correspondence no mechanical pairing defines, and it stands
with the allocation on the human audit's side of the line. §0.2's prose adequacy is the
reader's.

INPUT_PROVENANCE:
  - The paper text (claim entries, registry rows, §0.2's span):
    class=paper-defined (Paper_12_v4.md beside this script's
    parent directory, read at run time; the claims under test).
  - The suite scripts' INPUT_PROVENANCE blocks: class=
    paper-defined (the suite's own files in this directory,
    read at run time; their declared blocks are the claims
    under test).
  - The planted-mutant fixtures (PA-PE): class=control
    (synthetic texts built below; PA is derived from the
    paper's own L8.3-P12 split with one allocation moved).

Run: python3 H2_split_provenance.py
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / "Paper_12_v4.md"

VOCAB = ["paper-defined", "cited-paper", "control",
         "declared-assumption", "arbitrary-representative",
         "declared exhibit data"]
HYBRID_HEADS = {"LEVEL A: MACHINE / AUTHOR",
                "LEVEL A: MACHINE / PROOF / AUTHOR",
                "LEVEL A: MACHINE / PROOF"}
COMPONENTS = ("MACHINE", "PROOF", "AUTHOR")
SUITE_IDS = {"A.1", "A.2", "A.3", "A.4", "A.5", "A.6", "A.7",
             "A.8", "A.9", "A.10", "A.11", "A.12", "A.13", "A.14",
             "A.15", "FW.1", "G.1", "H.1", "H.2"}

LABEL = (r"(?:L\d+\.\d+-P12|LD\.\d+-P12|LC\.\d+-P12|LE\.\d+-P12"
         r"|OR-\d+)")
ENTRY_START = re.compile(
    r"\s*-\s+\*\*(?:Claim )?" + LABEL + r"(?:\*\*|\s)")
CLAIM_STMT = re.compile(r".*\*\*(?:Claim |Verdict )?" + LABEL
                        + r"\b")
BADGE_RE = re.compile(r"\[([^\]]{2,600})\]")
SPLIT_MARK = "Component split —"
TAG_TAIL = re.compile(r"\s*\((?:[A-Z]+\.\d+|L\d+\.\d+-P12)\)\s*$")


def norm(s):
    return re.sub(r"\s+", " ", s).strip()


def badge_head(badge):
    """The badge's head form: text up to the first ' — ' or '; '
    tail separator (whitespace collapsed first — a badge may
    wrap inside its brackets)."""
    badge = norm(badge)
    cuts = [badge.find(sep) for sep in
            (" — ", "; ", " for ", " conditional")]
    cuts = [c for c in cuts if c > 0]
    if cuts:
        return badge[:min(cuts)].strip()
    return badge.strip()


def entries(lines):
    """Claim entries (label, kind, text, start, end) in H.1's
    disclosed shapes; the caller supplies the scan domain."""
    out = []
    i = 0
    while i < len(lines):
        ln = lines[i]
        m = ENTRY_START.match(ln) or CLAIM_STMT.match(ln)
        if m:
            label = re.search(LABEL, ln).group(0)
            buf = [ln]
            j = i + 1
            while j < len(lines) and lines[j].strip() and \
                    not re.match(r"\s*(-\s|#{1,4}\s|\||---)",
                                 lines[j]):
                buf.append(lines[j])
                j += 1
            out.append((label, "home", "\n".join(buf), i, j))
            i = j
            continue
        if re.match(r"\| (?:L|OR-)", ln):
            buf = [ln]
            j = i + 1
            while j < len(lines) and lines[j].strip() and \
                    not lines[j].startswith("|"):
                buf.append(lines[j])
                j += 1
            joined = " ".join(x.strip() for x in buf)
            cells = [c.strip() for c in
                     joined.strip().strip("|").split("|")]
            if len(cells) >= 4:
                out.append((cells[0].replace("\\", ""), "row",
                            joined, i, j))
            i = j
            continue
        i += 1
    return out


def split_of(text, row=False):
    """The component split carried by an entry, or None. Capture:
    from the split marker to the entry's end; registry trailing
    cells and a trailing cross-reference tag are furniture."""
    k = text.find(SPLIT_MARK)
    if k < 0:
        return None
    s = text[k + len(SPLIT_MARK):]
    if row and " | " in s:              # registry row: drop cells
        s = s.split(" | ")[0]
    s = TAG_TAIL.sub("", s.strip())
    s = norm(s)
    return s.rstrip(".")                # entry-final punctuation


def parse_split(split):
    """Split text -> {component: [(paren, segment), ...]}. A
    component may carry several segments (L7.3-P12's split names
    two PROOF segments); every segment is returned and checked —
    keying a dict by component silently dropped all but the last
    (loop charge EA-4). Headers are 'MACHINE (...):',
    'PROOF (...):', 'AUTHOR:'."""
    heads = list(re.finditer(
        r"(MACHINE|PROOF|AUTHOR)\s*(?:\(([^)]*)\))?\s*:", split))
    out = {}
    for idx, h in enumerate(heads):
        end = (heads[idx + 1].start() if idx + 1 < len(heads)
               else len(split))
        seg = split[h.end():end].strip().rstrip(";").strip()
        out.setdefault(h.group(1), []).append((h.group(2) or "", seg))
    return out


def check_split_pair(label, surfaces):
    """surfaces: [(kind, split)] for one claim. Returns problems."""
    problems = []
    texts = {s for _, s in surfaces}
    if len(texts) > 1:
        problems.append(
            f"{label}: split surfaces disagree "
            f"({len(surfaces)} surfaces, {len(texts)} distinct)")
    return problems


def check_split_legal(label, badge, split):
    problems = []
    head = badge_head(badge)
    want = {c for c in COMPONENTS if c in head}
    got = parse_split(split)
    if set(got) != want:
        problems.append(
            f"{label}: split components {sorted(got)} != badge "
            f"components {sorted(want)}")
    for comp, segs in got.items():
        for paren, seg in segs:
            if len(seg) < 8:
                problems.append(f"{label}: {comp} segment is empty "
                                f"or vestigial")
    if "MACHINE" in got:
        paren, _ = got["MACHINE"][0]
        ids = re.findall(r"(?:script\s+)?\b(A\.\d+|FW\.1|G\.1|"
                         r"H\.\d)\b", paren + " " + split[:60])
        if not ids or ids[0] not in SUITE_IDS:
            problems.append(f"{label}: MACHINE component names "
                            f"no suite script ({paren!r})")
    return problems


# ---------------- provenance ----------------

SECTION_HEAD = re.compile(r"^[A-Z][A-Z0-9 ,/&()'.-]+:")
VIA_RE = re.compile(
    r"via (?:the suite's own )?(A\.\d+|FW\.1|G\.1|H\.\d)\b"
    r"|(A\.\d+|FW\.1|G\.1|H\.\d)'s (?:own )?"
    r"(?:block|provenance)")
CLASS_ANY = re.compile(r"class=([^\s(]+(?: [a-z]+){0,2})")


def script_id(fname):
    m = re.match(r"([A-Z]+)(\d+)_", fname)
    if m:
        return f"{m.group(1)}.{m.group(2)}"
    return fname


def module_docstring(text):
    """The module's first string literal (the header docstring
    carrying the provenance), or "" if there is none."""
    start = text.find('"""')
    if start < 0:
        return ""
    end = text.find('"""', start + 3)
    return text[start + 3:end] if end > start else ""


def provenance_blocks(text):
    """ALL INPUT_PROVENANCE blocks' lines (a file carrying more
    than one block — an adjustment-era second block — is parsed
    in full; the union of its bindings is the file's declared
    provenance). Binding bullets that sit elsewhere in the
    module docstring — after adjustment prose, with no second
    header (A.6 and G.1 both carry some; loop charge EA-1) —
    are collected as stray bindings, so no docstring bullet
    carrying a class token stands outside the check."""
    lines = text.splitlines()
    blocks = []
    for i, ln in enumerate(lines):
        if ln.strip().startswith("INPUT_PROVENANCE:"):
            block = []
            rest = lines[i + 1:]
            for k, ln2 in enumerate(rest):
                if ln2.strip() == '"""' or \
                        ln2.startswith(("def ", "class ")):
                    break
                if ln2.strip() and not ln2[0].isspace():
                    break           # column-0 prose / section head
                if not ln2.strip():
                    nxt = next((x for x in rest[k + 1:]
                                if x.strip()), "")
                    if not re.match(r"\s*-\s", nxt):
                        break       # blank line, no further bullet
                block.append(ln2)
            blocks.append(block)
    # Stray binding bullets elsewhere in the module docstring.
    doc = module_docstring(text)
    if doc:
        in_block_text = "\n".join(
            ln for b in blocks for ln in b)
        dlines = doc.splitlines()
        block_first_lines = {ln.strip() for b in blocks
                             for ln in b if ln.strip()}
        i = 0
        while i < len(dlines):
            ln = dlines[i]
            if re.match(r"\s*-\s", ln) \
                    and ln.strip() not in block_first_lines:
                stray = [ln]
                j = i + 1
                while j < len(dlines) and dlines[j].strip() \
                        and not re.match(r"\s*-\s", dlines[j]) \
                        and dlines[j][0].isspace():
                    stray.append(dlines[j])
                    j += 1
                if any("class=" in x for x in stray):
                    blocks.append(stray)
                i = j
            else:
                i += 1
    return blocks


def parse_bindings(block_lines):
    """Bindings: each '  - ' line starts one; continuations join.
    Returns [(binding_text, [class tokens], [via ids])]."""
    raw = []
    cur = None
    for ln in block_lines:
        if re.match(r"\s*-\s", ln):
            if cur is not None:
                raw.append(cur)
            cur = ln
        elif cur is not None and ln.strip():
            if cur.endswith("-") and ln.strip()[0].islower():
                cur += ln.strip()       # wrapped hyphenated word
            else:
                cur += " " + ln.strip()
    if cur is not None:
        raw.append(cur)
    out = []
    for b in raw:
        b = re.sub(r"class=\s+", "class=", b)
        classes = []
        for m in re.finditer(r"class=", b):
            vm = re.match(r"class=(" + "|".join(
                re.escape(v) for v in VOCAB) + r")\b",
                b[m.start():])
            if vm:
                classes.append(vm.group(1))
                tail = b[m.start() + vm.end():]
                if re.match(r"\s+(exhibit data|exhibit|data|"
                            r"representative)\b", tail) and \
                        not any(v.startswith(vm.group(1) + " ")
                                and b[m.start():].startswith(
                                    "class=" + v)
                                for v in VOCAB):
                    classes.append(
                        "UNKNOWN:compound-after-" + vm.group(1))
            else:
                tok = CLASS_ANY.match(b[m.start():])
                classes.append("UNKNOWN:" + (
                    tok.group(1).strip() if tok else "?"))
        vias = []
        for m in VIA_RE.finditer(b):
            vias.append(m.group(1) or m.group(2))
        out.append((b, classes, vias))
    return out


def check_provenance(blocks):
    """blocks: {script_id: [(binding, classes, vias)]}.
    Returns problems."""
    problems = []
    class_sets = {sid: {c for _, cs, _ in bs for c in cs}
                  for sid, bs in blocks.items()}
    for sid, bs in blocks.items():
        if not bs:
            problems.append(f"{sid}: provenance block has no "
                            f"bindings")
        for b, classes, vias in bs:
            if re.match(r"\s*-\s*External data: none", b):
                continue        # explicit nil declaration
            if not classes:
                problems.append(f"{sid}: binding with no class "
                                f"token: {b.strip()[:70]}")
            for c in classes:
                if c.startswith("UNKNOWN:"):
                    problems.append(
                        f"{sid}: class token outside the regime "
                        f"vocabulary: {c[8:]}")
            for via in vias:
                if via not in class_sets:
                    problems.append(f"{sid}: via-source {via} "
                                    f"has no provenance block")
                    continue
                for c in classes:
                    if not c.startswith("UNKNOWN:") and \
                            c not in class_sets[via]:
                        problems.append(
                            f"{sid}: binding class {c} not "
                            f"carried by via-source {via} "
                            f"(its classes: "
                            f"{sorted(class_sets[via])})")
    return problems


# ---------------- badge definedness ----------------

def section_span(lines, number):
    """Lines of the §N.N section (heading to the next ## or #)."""
    start = None
    for i, ln in enumerate(lines):
        if re.match(r"#{1,3}\s+" + re.escape(number) + r"\b", ln):
            start = i
            break
    if start is None:
        return []
    out = [lines[start]]
    for ln in lines[start + 1:]:
        if re.match(r"#{1,2}\s", ln):
            break
        out.append(ln)
    return out


def defined_heads(span_lines):
    text = "\n".join(span_lines)
    heads = set()
    # A form is defined by being printed in bold in §0.2 — the
    # taxonomy's defining typography. A form merely mentioned in
    # §0.2's prose (Paper 11.5's foreign [LEVEL A,
    # author-authorized]) is not thereby defined (loop charge
    # RT-6b).
    for bold in re.findall(r"\*\*([^*]+)\*\*", text):
        for b in BADGE_RE.findall(bold):
            heads.add(badge_head(b))
    # §0.2 also defines families in bold text without brackets.
    for fam in ("Construction", "Definition", "Scope statement",
                "Receipt", "Inherited premise", "Worked instance",
                "Declared assumption"):
        if f"**{fam}" in text:
            heads.add(fam)
    return heads


def main():
    print("=" * 70)
    print("H.2 — SPLIT AGREEMENT / PROVENANCE / BADGE DEFINEDNESS")
    print("=" * 70)
    problems = []
    if not PAPER.exists():
        print("H.2 VERDICT: FAIL — paper not found:", PAPER)
        return 1
    lines = PAPER.read_text(encoding="utf-8").splitlines()
    # Scan domain: the whole paper's prose — only the embedded
    # BEGIN..END blocks ( Appendix C's listings and sources,
    # Appendix E's exhibits) are blanked, as data; §C.1's own
    # claim entries and every appendix's prose are scanned.
    scan = list(lines)
    in_block = False
    for i, ln in enumerate(scan):
        if "<!-- BEGIN " in ln:
            in_block = True
        if in_block:
            scan[i] = ""
        if "<!-- END -->" in ln:
            in_block = False
    ents4 = entries(scan)
    ents = [(label, kind, text) for label, kind, text, _, _
            in ents4]
    # Split-bearing plain paragraphs (a claim's verdict paragraph
    # at its home section) attribute to the nearest preceding
    # claim entry.
    spans = [(s, e) for _, _, _, s, e in ents4]
    last_label = None
    i = 0
    while i < len(scan):
        if not scan[i].strip():
            i += 1
            continue
        j = i
        while j < len(scan) and scan[j].strip():
            j += 1
        block = "\n".join(scan[i:j])
        lab = None
        for label, kind, text, s, e in ents4:
            if s == i:
                lab = label
        if lab:
            last_label = lab
        if SPLIT_MARK in block and not any(
                s < j and i < e for s, e in spans) \
                and last_label is not None:
            ents.append((last_label, "home", block))
        i = j
    print(f"claim entries scanned (embedded blocks blanked): "
          f"{len(ents)}")

    # (iii) first (cheap): badge definedness over all entries.
    heads02 = defined_heads(section_span(lines, "0.2"))
    used = {}
    for label, kind, text in ents:
        for b in BADGE_RE.findall(text):
            h = badge_head(b)
            if h.startswith(("LEVEL", "CITED")) or \
                    h.split(" ")[0] in (
                        "Construction", "Definition", "Scope",
                        "Receipt", "Inherited", "Worked",
                        "Declared", "Denied", "NO", "AUTHOR"):
                used.setdefault(h, set()).add(label)
    for h, labels in sorted(used.items()):
        if h not in heads02:
            problems.append(
                f"(iii) badge head {h!r} used by "
                f"{sorted(labels)[:3]} is not defined in §0.2")
    print(f"(iii) badge heads used: {len(used)}; defined in "
          f"§0.2: {len(heads02 & set(used))}/{len(used)}")

    # (i) split agreement.
    by_label = {}
    for label, kind, text in ents:
        badge = None
        for b in BADGE_RE.findall(text):
            if badge_head(b) in HYBRID_HEADS:
                badge = b
                break
        s = split_of(text, row=(kind == "row"))
        if badge and s is None:
            problems.append(f"(i) {label} ({kind}): hybrid "
                            f"badge with no component split")
        if s is not None and not badge:
            problems.append(f"(i) {label} ({kind}): component "
                            f"split on a non-hybrid entry")
        if badge and s:
            by_label.setdefault(label, []).append((kind, s))
            problems += check_split_legal(label, badge, s)
    n_hybrid = 0
    for label, surfaces in sorted(by_label.items()):
        n_hybrid += 1
        kinds = {k for k, _ in surfaces}
        if "row" not in kinds or "home" not in kinds:
            problems.append(f"(i) {label}: surfaces present: "
                            f"{sorted(kinds)} (need home + row)")
        problems += check_split_pair(label, surfaces)
    print(f"(i) hybrid claims with splits: {n_hybrid}; surfaces "
          f"per claim: "
          f"{sorted({len(v) for v in by_label.values()})}")

    # (ii) provenance.
    blocks = {}
    for f in sorted(HERE.glob("*.py")):
        if f.name == "run_all.py":
            continue
        blks = provenance_blocks(f.read_text(encoding="utf-8"))
        if not blks:
            problems.append(f"(ii) {script_id(f.name)}: no "
                            f"INPUT_PROVENANCE block")
            continue
        bindings = []
        for blk in blks:
            bindings += parse_bindings(blk)
        blocks[script_id(f.name)] = bindings
        doc_class = module_docstring(
            f.read_text(encoding="utf-8")).count("class=")
        parsed_class = sum(b.count("class=")
                            for b, _, _ in bindings)
        if doc_class != parsed_class:
            problems.append(
                f"(ii) {script_id(f.name)}: module docstring "
                f"carries {doc_class} class tokens, "
                f"{parsed_class} inside parsed bindings — a "
                f"binding stands outside the check")
    prov_problems = check_provenance(blocks)
    problems += [f"(ii) {p}" for p in prov_problems]
    print(f"(ii) provenance blocks parsed: {len(blocks)}; "
          f"bindings: {sum(len(v) for v in blocks.values())}")

    # (iii-prose) whole-prose badge census (repair batch 2).
    span02 = section_span(lines, "0.2")
    lo = lines.index(span02[0]) if span02 else -1
    hi = lo + len(span02) if span02 else -1
    prose_used = {}
    for li, ln in enumerate(scan):
        if lo <= li < hi:
            continue            # §0.2's own span: mentions live there
        for b in BADGE_RE.findall(ln):
            h = badge_head(b)
            if h.startswith(("LEVEL", "CITED")) or \
                    h.split(" ")[0] in (
                        "Construction", "Definition", "Scope",
                        "Receipt", "Inherited", "Worked",
                        "Declared", "Denied", "NO", "AUTHOR"):
                prose_used.setdefault(h, 0)
                prose_used[h] += 1
    for h in sorted(prose_used):
        if h not in heads02:
            problems.append(
                f"(iii-prose) badge head {h!r} used in prose "
                f"({prose_used[h]}x) is not defined in §0.2")
    print(f"(iii-prose) prose badge census: "
          f"{sum(prose_used.values())} badge brackets, "
          f"{len(prose_used)} heads")

    # ---- planted mutants ----
    print("-" * 70)
    print("PLANTED MUTANTS:")
    mut_ok = True

    # PA — the round-10 L8.3 shape: one allocation moved between
    # legs on one surface; agreement must fire.
    real = None
    for label, surfaces in by_label.items():
        if label == "L8.3-P12":
            real = surfaces[0][1]
    if real is None:
        print("  [FAIL] PA setup: L8.3-P12 split not found")
        mut_ok = False
    else:
        parsed = parse_split(real)
        doctored = (
            "MACHINE (A.5): " + parsed["MACHINE"][0][1] +
            "; AUTHOR: " + parsed["AUTHOR"][0][1] +
            " — and the all-n generality of (8.7), carried by "
            "§8.3's printed induction.")
        fired = bool(check_split_pair(
            "L8.3-P12", [("home", doctored),
                         ("row", real)]))
        print(f"  [{'PASS' if fired else 'FAIL'}] PA allocation "
              f"moved on one surface (round-10 L8.3 shape): "
              f"agreement {'fires' if fired else 'SILENT'}")
        mut_ok &= fired

    # PB — the round-9 A.15 shape: a binding claiming a class its
    # via-source does not carry.
    pb_blocks = dict(blocks)
    pb_blocks["A.99"] = [(
        "- Fixture: class=arbitrary-representative via the "
        "suite's own A.13 (planted).",
        ["arbitrary-representative"], ["A.13"])]
    fired = any("via-source A.13" in p
                for p in check_provenance(pb_blocks))
    print(f"  [{'PASS' if fired else 'FAIL'}] PB compound class "
          f"beyond its via-source (round-9 A.15 shape): "
          f"{'fires' if fired else 'SILENT'}")
    mut_ok &= fired

    # PC — the round-10 A.14 shape: a class token outside the
    # regime vocabulary.
    pc = parse_bindings([
        "  - Fixture binding: class=declared-representative "
        "(planted)."])
    fired = any(c.startswith("UNKNOWN:")
                for _, cs, _ in pc for c in cs)
    print(f"  [{'PASS' if fired else 'FAIL'}] PC out-of-vocabulary"
          f" class token (round-10 A.14 shape): "
          f"{'fires' if fired else 'SILENT'}")
    mut_ok &= fired

    # PE — the round-9 shape through the possessive via-form:
    # a binding whose class its named source does not carry,
    # cited as 'via A.13's block', must fire exactly as the
    # suite's-own form does.
    pe_blocks = dict(blocks)
    pe_blocks["A.98"] = [(
        "- Fixture: class=arbitrary-representative via "
        "A.13's block (planted).",
        ["arbitrary-representative"], ["A.13"])]
    fired = any("via-source A.13" in p
                for p in check_provenance(pe_blocks))
    print(f"  [{'PASS' if fired else 'FAIL'}] PE possessive "
          f"via-form checked (round-9 shape, second citation "
          f"form): {'fires' if fired else 'SILENT'}")
    mut_ok &= fired

    # PD — a badge family §0.2 does not define: the PROOF forms
    # struck from a doctored §0.2.
    doctored_span = [ln for ln in section_span(lines, "0.2")
                     if "PROOF" not in ln]
    fired = "LEVEL A: MACHINE / PROOF" not in defined_heads(
        doctored_span)
    print(f"  [{'PASS' if fired else 'FAIL'}] PD badge family "
          f"absent from §0.2 (doctored span): "
          f"{'fires' if fired else 'SILENT'}")
    mut_ok &= fired

    print("=" * 70)
    if problems or not mut_ok:
        for p in problems:
            print(f"  PROBLEM: {p}")
        print(f"H.2 VERDICT: FAIL — {len(problems)} problem(s)"
              + ("" if mut_ok else "; mutant battery failed"))
        return 1
    print(f"H.2 VERDICT: PASS — {n_hybrid} hybrid claims' splits "
          f"agree on every surface; {len(blocks)} provenance "
          f"blocks stay inside the regime vocabulary and their "
          f"via-bindings' classes appear in their sources' "
          f"blocks; every badge head "
          f"in use is defined in §0.2; mutants PA–PE all fire.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
