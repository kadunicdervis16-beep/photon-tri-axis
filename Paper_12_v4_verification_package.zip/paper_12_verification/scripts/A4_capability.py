#!/usr/bin/env python3
"""A.4 — Capability factors through presented-count profiles (Paper 12 §6).

Verifies Theorem 6.2 / claim L6.2-P12: if two bodies present equal
count profiles M = (n+, n-) at a tick, then for every role R and every
encounter kind E of the taxonomy,

    (E, t) in Cap(G, R)  <=>  (E, t) in Cap(G', R) —

capability at a tick is a function of the presented-count profile and
of nothing else about the body. Also verifies the §6.3 corollary used
against Paper 11.5 §7.4: with no encounters, the capability set is
empty — no carried residue.

HOW THE CHECK IS MADE NON-VACUOUS:
  The theorem's premise (Paper 11 §8.6, Level A in Paper 11) is that
  encounter OUTCOMES factor through M. This script does not assume a
  single outcome rule: it runs the whole battery under TWO structurally
  different outcome rules, both of them functions of the two presented
  profiles alone (the class §8.6 licenses), and the two rules are
  first shown to DISAGREE on some (body, encounter) pairs — so the
  battery is not testing one rule twice, and agreement of capabilities
  at equal profiles is not an artifact of a trivial rule.
  Bodies are built on Paper 11's three worked aggregates (below), with
  interiors varied along every axis the profile map discards: node
  state labels, junction port indices, node order, interior tags,
  and a stubbed history. Presented tuples are also permuted (order
  discarded by M). The check is pairwise and exhaustive over the
  constructed population: ANY two bodies with equal profiles must have
  identical capability sets, for every role, under both rules.

WORKED AGGREGATES (cited-paper inputs, Paper 11 Appendix B):
  (a) three State-4 nodes, one 3-way center junction consuming one
      port per node (k = 3):            B = 6*3 - 3     = 15.
  (b) State-5 and State-6 nodes, one pairwise junction consuming one
      port per node (k = 2, consume-O):  B = 6*2 - 2     = 10.
  (c) linear chain of three nodes, two junctions of k = 2 each:
                                          B = 6*3 - (2+2) = 14.
  The script recomputes B = 6N - sum(k_j) from the junction tables and
  checks 15 / 10 / 14 rather than taking them on trust.

COVERAGE (verification-rigor disclosure):
  (1) Native domain: Theorem 6.2 over arbitrary bodies and Paper 11's
      full encounter taxonomy.
  (2) Verified domain: bodies built on aggregates (a), (b), (c) with
      the interior/presentation variation axes above; a declared
      finite test taxonomy of encounter kinds (all profiles
      (e+, e-) with e+ + e- <= 4); two representative outcome rules
      from the profile-factoring class.
  (3) Map: native encounter outcome -> outcome rule applied to
      (M(G), M(E)); native body -> (interior record, presented tuple).
  (4) Preserved: exactly the dependence structure the theorem is
      about — what the capability does and does not consult.
  (5) Outside the machine check: §8.6 itself (inherited, Level A in
      Paper 11, machine-checked there over 710,090 encounters);
      whether the two representative rules exhaust the rule class
      (they cannot — the theorem's force is that ANY rule of the
      class inherits the factorization, which is §8.6's content; this
      script verifies the factorization mechanism and its interior-
      independence on the worked aggregates, under two disagreeing
      rules, plus a mutant that steps outside the class and is caught).

INPUT_PROVENANCE:
  - Aggregates (a), (b), (c) — node states, junction tables, B values:
    class=cited-paper (Paper 11 Appendix B.1/B.2/B.3; F.33/F.34/F.35
    document the same constructions; B recomputed here from
    B = 6N - sum(k_j), Paper 11 §4.1).
  - Outcome factors through M = (n+, n-): class=cited-paper
    (Paper 11 §8.6 — the theorem's one premise, inherited).
  - Outcome rules 1 and 2 (below): class=arbitrary-representative
    (two disagreeing members of the profile-factoring class §8.6
    licenses; the claim checked is rule-independent within the class).
  - Test taxonomy (profiles with e+ + e- <= 4): class=control
    (declared finite test set standing in for §8's taxonomy).
  - Interior variation axes (labels, tags, histories, port indices):
    class=control (constructed variation; none of it is framework
    data — that is the point of the probe).
  - Roles {responder, initiator, spin-presenter}: responder/initiator
    are Paper 11's relational active/passive roles read off the
    encounter (class=cited-paper, Paper 11 role taxonomy);
    spin-presenter is the §6.3 worked case (class=paper-defined,
    Paper 12 §6.3: the encounter kinds whose profiles complete the
    spin-presentation outcome class — here, purely complementary
    encounters with at least one complementary pair and no same-sign
    overlap).
"""
import itertools
import random
import sys
from itertools import product

# ------------------------------------------------------- worked aggregates
# Each aggregate: (name, node state labels, junction port-consumptions).
# A junction is a list of (node_index, port_index) it consumes; k_j is
# its length. B = 6N - sum(k_j), recomputed in main.
AGGREGATES = {
    "a": {
        "nodes": ["State-4", "State-4", "State-4"],
        "junctions": [[(0, 4), (1, 4), (2, 4)]],          # one 3-way, k=3
        "B_expected": 15,
    },
    "b": {
        "nodes": ["State-5", "State-6"],
        "junctions": [[(0, 4), (1, 4)]],                  # pairwise, k=2
        "B_expected": 10,
    },
    "c": {
        "nodes": ["State-A", "State-B", "State-C"],
        "junctions": [[(0, 0), (1, 0)], [(1, 5), (2, 0)]],  # two k=2
        "B_expected": 14,
    },
}

ROLES = ("responder", "initiator", "spin-presenter")

# Declared finite test taxonomy of encounter kinds: profiles (e+, e-).
TAXONOMY = [(ep, em) for ep in range(5) for em in range(5) if ep + em <= 4]


def profile(presented):
    """The presented-count map M: counts of +1 and -1 presentations.
    Order, port identity and everything interior are discarded here —
    that discarding IS Paper 11 §8.6's map."""
    return (sum(1 for v in presented if v == 1),
            sum(1 for v in presented if v == -1))


# ------------------------------------------------------------ outcome rules
# Both rules are functions of (M(G), M(E)) ONLY — the class Paper 11
# §8.6 licenses. They are structurally different and disagree.

def outcome_rule_1(MG, ME):
    """Complementary-cover rule: count complementary pairs c and
    same-sign overlaps s between the two presentations."""
    np_, nm_ = MG
    ep, em = ME
    c = min(np_, em) + min(nm_, ep)
    s = min(np_, ep) + min(nm_, em)
    roles = set()
    if c >= 1:
        roles.add("responder")
        if (np_ - nm_) >= (ep - em):
            roles.add("initiator")
    if c >= 1 and s == 0:
        roles.add("spin-presenter")
    return roles


def outcome_rule_2(MG, ME):
    """Surplus/tension rule: roles read off the net surplus of the
    combined presentation and the total presented load."""
    np_, nm_ = MG
    ep, em = ME
    net = (np_ - nm_) + (ep - em)
    total = np_ + nm_ + ep + em
    roles = set()
    if net == 0 and total >= 2:
        roles.add("responder")
        roles.add("spin-presenter")
    if net > 0 and np_ > nm_:
        roles.add("initiator")
    return roles


RULES = {"rule1_cover": outcome_rule_1, "rule2_surplus": outcome_rule_2}


def capability(body, rule, taxonomy=TAXONOMY):
    """Cap(G, .) at one tick, as {role: frozenset of encounter kinds}.
    Computed ONLY from the body's presented profile — the interior is
    accepted as part of the body record and never consulted, which is
    what the probes below attack."""
    MG = profile(body["presented"])
    cap = {r: set() for r in ROLES}
    for E in taxonomy:
        for r in rule(MG, E):
            cap[r].add(E)
    return {r: frozenset(s) for r, s in cap.items()}


def capability_carried_mutant(body, taxonomy=TAXONOMY):
    """MUTANT: 'carried capability' — the outcome rule consults an
    interior label. A body tagged 'carrier' is a spin-presenter in
    EVERY encounter kind; untagged bodies use rule 1. Two bodies with
    equal profiles but different tags get different capabilities:
    exactly the carried picture Theorem 6.2 denies."""
    cap = capability(body, outcome_rule_1, taxonomy)
    if body["interior"]["tag"] == "carrier":
        cap = dict(cap)
        cap["spin-presenter"] = frozenset(taxonomy)
    return cap


# ------------------------------------------------------------ body factory

def make_body(agg_name, interior_variant, presented):
    agg = AGGREGATES[agg_name]
    nodes = list(agg["nodes"])
    junctions = [[tuple(x) for x in j] for j in agg["junctions"]]
    tag = "plain"
    history = ()
    if interior_variant == 1:
        # relabel node states (interior bookkeeping names)
        nodes = [n + "'" for n in nodes]
    elif interior_variant == 2:
        # different consumed port indices, same k_j per junction
        junctions = [[(n_, (p + 1) % 6) for (n_, p) in j]
                     for j in junctions]
    elif interior_variant == 3:
        # reversed node order (junction tables follow their nodes)
        nodes = list(reversed(nodes))
    elif interior_variant == 4:
        tag = "carrier"          # interior label — capability must not care
    elif interior_variant == 5:
        history = ("tick-3 encounter", "tick-2 rest")  # stubbed past
    elif interior_variant == 6:
        tag = "carrier"
        nodes = [n + "*" for n in nodes]
        history = ("tick-9 encounter",)
    return {
        "agg": agg_name,
        "interior": {"nodes": nodes, "junctions": junctions,
                     "tag": tag, "history": history},
        "presented": tuple(presented),
    }


def presented_patterns(B):
    """For every profile (n+, n-) with n+ + n- <= B: the canonical
    presented tuple, plus two permutations of it (order is discarded
    by M, so permutations are interior-side variation for the probe)."""
    rng = random.Random(4177)
    out = []
    for np_ in range(B + 1):
        for nm_ in range(B + 1 - np_):
            base = [1] * np_ + [-1] * nm_ + [0] * (B - np_ - nm_)
            variants = [tuple(base)]
            for _ in range(2):
                perm = list(base)
                rng.shuffle(perm)
                variants.append(tuple(perm))
            out.append(((np_, nm_), variants))
    return out


# ------------------------------------------------------------------- main

def main():
    print("=" * 70)
    print("A.4 — CAPABILITY FACTORS THROUGH PRESENTED-COUNT PROFILES")
    print("  (Paper 12 §6, Theorem 6.2; premise: Paper 11 §8.6)")
    print("=" * 70)
    all_ok = True

    print("\n--- Step 1: boundary accounting of the worked aggregates ---")
    for name, agg in AGGREGATES.items():
        N = len(agg["nodes"])
        sumk = sum(len(j) for j in agg["junctions"])
        B = 6 * N - sumk
        ok = (B == agg["B_expected"])
        all_ok &= ok
        print(f"  aggregate ({name}): N={N}, sum k_j={sumk}, "
              f"B = 6N - sum(k_j) = {B} (Paper 11: {agg['B_expected']}) "
              f"[{'OK' if ok else 'FAIL'}]")

    print("\n--- Step 2: the two outcome rules genuinely disagree ---")
    disagreements = 0
    for MG in TAXONOMY:
        for ME in TAXONOMY:
            if outcome_rule_1(MG, ME) != outcome_rule_2(MG, ME):
                disagreements += 1
    print(f"  rule1 vs rule2 disagree on {disagreements} of "
          f"{len(TAXONOMY)**2} (profile, encounter) pairs — the battery "
          f"is not one rule tested twice.")
    if disagreements == 0:
        print("  FAIL: rules never disagree — battery would be vacuous.")
        all_ok = False

    print("\n--- Step 3: exhaustive pairwise check — equal profiles => "
          "equal capabilities ---")
    bodies = []
    for agg_name, agg in AGGREGATES.items():
        B = agg["B_expected"]
        for prof, variants in presented_patterns(B):
            for pres in variants:
                for iv in range(7):
                    bodies.append(make_body(agg_name, iv, pres))
    print(f"  constructed population: {len(bodies)} bodies over "
          f"aggregates (a), (b), (c); interiors varied on 7 axes "
          f"(labels, port indices, node order, tags, histories); "
          f"presentations permuted.")
    by_profile = {}
    for b in bodies:
        by_profile.setdefault(profile(b["presented"]), []).append(b)
    pair_checks = 0
    violations = []
    for prof, group in by_profile.items():
        for rule_name, rule in RULES.items():
            caps = [capability(b, rule) for b in group]
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    pair_checks += 1
                    if caps[i] != caps[j]:
                        violations.append((prof, rule_name, group[i],
                                           group[j], caps[i], caps[j]))
    print(f"  profile classes: {len(by_profile)}; pairwise comparisons "
          f"(x2 rules): {pair_checks}; violations: {len(violations)}")
    if violations:
        prof, rule_name, b1, b2, c1, c2 = violations[0]
        print(f"  FAIL — witness: profile {prof} under {rule_name}:")
        print(f"    body1 interior={b1['interior']}")
        print(f"    body2 interior={b2['interior']}")
        print(f"    Cap1={c1}\n    Cap2={c2}")
        all_ok = False
    else:
        print("  Theorem 6.2 holds on the whole constructed population, "
              "under both rules: capability consulted the profile only.")

    print("\n--- Step 3b: presentation-invariance through the "
          "exhibit path; the held-fixed boundary control "
          "(round 11, genuine form repair batch 2) ---")
    # The first round-11 form of this step grouped raw tuples by
    # profile and called the rules on the profiles — a function
    # of the profile fed only the profile, which cannot fail.
    # The genuine test goes through capability() itself: bodies
    # built by the exhibit factory presenting DIFFERENT raw
    # tuples of one profile class must return identical
    # capabilities under both rules, for every aggregate; and
    # an order-sensitive mutant profile must DISAGREE inside
    # some class, proving the test can fail.
    tuples_by_profile = {}
    for L in range(0, 5):
        for tup in itertools.product((-1, 0, 1), repeat=L):
            tuples_by_profile.setdefault(profile(tup), []).append(tup)
    exch_ok = True
    exch_n = 0
    for agg_name in AGGREGATES:
        for prof, tups in tuples_by_profile.items():
            if len(tups) < 2:
                continue
            sample = tups[:12]
            for rule in RULES.values():
                caps = [capability(make_body(agg_name, 0, tp), rule)
                        for tp in sample]
                exch_n += 1
                if any(c != caps[0] for c in caps):
                    exch_ok = False
    print(f"  presentation-invariance: bodies presenting different "
          f"raw tuples of one profile class (permutations and "
          f"zero-paddings, lengths 0..4, up to 12 presentations "
          f"per class) return identical capabilities through the "
          f"exhibit path, for every aggregate and both rules — "
          f"{exch_n} (aggregate, profile class, rule) instances "
          f"[{'OK' if exch_ok else 'FAIL'}]")
    all_ok &= exch_ok

    def _profile_mutant(presented):
        # order-sensitive: +1 presentations weighted by position
        return (sum(v for k, v in enumerate(presented)
                    if v == 1 and k % 2 == 0),
                sum(1 for v in presented if v == -1))

    def _capability_mutant(body, rule):
        MG = _profile_mutant(body["presented"])
        cap = {r: set() for r in ROLES}
        for E in TAXONOMY:
            for r in rule(MG, E):
                cap[r].add(E)
        return {r: frozenset(s) for r, s in cap.items()}

    mut_disagrees = False
    for prof, tups in tuples_by_profile.items():
        if len(tups) < 2:
            continue
        caps = [_capability_mutant(make_body("a", 0, tp),
                                   outcome_rule_1)
                for tp in tups[:12]]
        if any(c != caps[0] for c in caps):
            mut_disagrees = True
    print(f"  sensitivity control: an order-sensitive mutant "
          f"profile DISAGREES inside a profile class "
          f"[{'OK' if mut_disagrees else 'FAIL — test would be vacuous'}]")
    all_ok &= mut_disagrees
    wit = None
    for MG in TAXONOMY:
        for ME1 in TAXONOMY:
            for ME2 in TAXONOMY:
                if outcome_rule_1(MG, ME1) != outcome_rule_1(MG, ME2):
                    wit = (MG, ME1, ME2)
                    break
            if wit:
                break
        if wit:
            break
    print(f"  boundary control (the held-fixed clause is "
          f"load-bearing): body profile {wit[0]} answers "
          f"{sorted(outcome_rule_1(wit[0], wit[1]))} against "
          f"encounter profile {wit[1]} but "
          f"{sorted(outcome_rule_1(wit[0], wit[2]))} against "
          f"{wit[2]} — against different counterparts the same "
          f"body stands in different roles, and Theorem 6.2 "
          f"asserts nothing there")
    all_ok &= wit is not None

    print("\n--- Step 4: interior-independence probe (dedicated) ---")
    rng = random.Random(99)
    probe_ok = True
    trials = 0
    for agg_name, agg in AGGREGATES.items():
        B = agg["B_expected"]
        pres = tuple([1, -1, 1] + [0] * (B - 3))   # fixed profile (2,1)
        base_caps = {rn: capability(make_body(agg_name, 0, pres), r)
                     for rn, r in RULES.items()}
        for t in range(60):
            b = make_body(agg_name, rng.randrange(7), pres)
            # extra random interior noise: relabel nodes arbitrarily
            b["interior"]["nodes"] = [n + f"#{t}" for n in
                                      b["interior"]["nodes"]]
            trials += 1
            for rn, r in RULES.items():
                if capability(b, r) != base_caps[rn]:
                    print(f"  FAIL — aggregate ({agg_name}) trial {t}: "
                          f"interior variant changed capability under "
                          f"{rn}: interior={b['interior']}")
                    probe_ok = False
    print(f"  {trials} randomized interior variants at fixed profile "
          f"(2,1) across the three aggregates: capability bit-identical "
          f"in every case [{'OK' if probe_ok else 'FAIL'}]")
    all_ok &= probe_ok

    print("\n--- Step 5: non-vacuity and the no-encounter corollary ---")
    cap_by_profile = {}
    for prof in [(0, 0), (1, 0), (0, 1), (1, 1), (2, 1), (3, 2), (4, 0)]:
        b = {"interior": {"nodes": [], "junctions": [], "tag": "plain",
                          "history": ()},
             "presented": tuple([1] * prof[0] + [-1] * prof[1])}
        cap_by_profile[prof] = capability(b, outcome_rule_1)
    distinct = len({tuple(sorted(c.items())) for c in
                    cap_by_profile.values()})
    empty_profile = (cap_by_profile[(0, 0)] ==
                     {r: frozenset() for r in ROLES})
    spin_somewhere = any(cap_by_profile[p]["spin-presenter"]
                         for p in cap_by_profile)
    print(f"  distinct capability assignments across 7 sample profiles: "
          f"{distinct} (capability genuinely varies with profile)")
    print(f"  profile (0,0) presents nothing => all roles empty: "
          f"{empty_profile}")
    print(f"  spin-presenter capability nonempty for some profile: "
          f"{spin_somewhere}")
    no_enc = capability(bodies[0], outcome_rule_1, taxonomy=[])
    no_residue = all(len(s) == 0 for s in no_enc.values())
    print(f"  empty taxonomy (no encounters) => Cap empty for every "
          f"role, no carried residue (§6.3): {no_residue}")
    if not (distinct >= 3 and empty_profile and spin_somewhere
            and no_residue):
        print("  FAIL: non-vacuity / corollary checks failed.")
        all_ok = False

    print("\n--- PLANTED MUTANT ---")
    b_plain = make_body("a", 0, tuple([1, -1] + [0] * 13))
    b_carrier = make_body("a", 4, tuple([1, -1] + [0] * 13))
    assert profile(b_plain["presented"]) == profile(b_carrier["presented"])
    mut1 = capability_carried_mutant(b_plain)
    mut2 = capability_carried_mutant(b_carrier)
    caught = mut1 != mut2
    if caught:
        diff = [r for r in ROLES if mut1[r] != mut2[r]]
        print(f"  [CAUGHT] M1: carried-capability mutant (spin-presenter "
              f"keyed to the interior tag 'carrier') produces unequal "
              f"capabilities at equal profiles.")
        print(f"           witness: both bodies present profile "
              f"{profile(b_plain['presented'])} on aggregate (a); "
              f"roles differing: {diff};")
        print(f"           untagged spin-presenter set size "
              f"{len(mut1['spin-presenter'])} vs tagged "
              f"{len(mut2['spin-presenter'])} (whole taxonomy) — an "
              f"interior label steering capability, exactly what "
              f"Theorem 6.2 forbids and what the check detects.")
    else:
        print("  [NOT CAUGHT — INVESTIGATE] M1: carried mutant produced "
              "equal capabilities at equal profiles.")
    all_ok &= caught
    # and the honest control: the REAL rule gives these two bodies
    # equal capabilities (already covered by Step 3, restated here so
    # the mutant contrast is on the record).
    real_equal = (capability(b_plain, outcome_rule_1) ==
                  capability(b_carrier, outcome_rule_1))
    print(f"  control: under the real (profile-only) rule the same two "
          f"bodies have equal capabilities: {real_equal}")
    all_ok &= real_equal

    print("\n" + "=" * 70)
    if all_ok:
        print("A.4 VERDICT: PASS — on Paper 11's worked aggregates (a)")
        print("  B=15, (b) B=10, (c) B=14, equal presented-count profiles")
        print("  give equal capability sets at a tick, exhaustively, under")
        print("  two disagreeing outcome rules of the §8.6 class; interior")
        print("  variation never moves capability; the carried-capability")
        print("  mutant is caught with a witness. Theorem 6.2's mechanism")
        print("  is verified at exactly the strength of its §8.6 premise.")
        return 0
    print("A.4 VERDICT: FAIL — see witness lines above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
